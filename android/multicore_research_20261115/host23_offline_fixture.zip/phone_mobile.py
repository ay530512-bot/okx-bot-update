"""Loopback dashboard, optionally reached through private Tailscale HTTPS Serve.

Strategy/engine modules are never patched. Desktop updater is unavailable here.
"""
import types
import time
from functools import lru_cache
from pathlib import Path
from phone_update import PhoneUpdater
from phone_remote import valid_host


def mover_groups(rows):
    return (sorted((r for r in rows if r.get('change', 0) > 0), key=lambda r: -r['change'])[:5],
            sorted((r for r in rows if r.get('change', 0) < 0), key=lambda r: r['change'])[:5])


def mobile_module(source):
    text = (source / 'okx_mobile.py').read_text()
    patches = {
        'from okx_compact_chart import mover_groups': 'from phone_mobile import mover_groups',
        "if received_origin not in (origin,'https://'+service.config['https_host']):":
            'if received_origin != origin:',
        "if received_origin!='https://'+service.config['https_host']:":
            'if received_origin != origin:',
    }
    for old, new in patches.items():
        if text.count(old) != 1:
            raise ValueError('Unsupported mobile source; refusing adaptation')
        text = text.replace(old, new)
    module = types.ModuleType('phone_q2x_mobile')
    exec(compile(text, str(source / 'okx_mobile.py'), 'exec'), module.__dict__)
    module.valid_config = lambda c: (
        (c.get('https_host') == '' or valid_host(c.get('https_host'))) and
        bool(module.re.fullmatch('[0-9a-f]{32}', c.get('salt', ''))) and
        bool(module.re.fullmatch('[0-9a-f]{128}', c.get('password_hash', ''))))
    original_asset = module.asset

    @lru_cache(maxsize=3)
    def asset(name):
        data = original_asset(name).decode('utf-8')
        data = data.replace('PC', '폰').replace('집 폰', '이 폰')
        data = data.replace('폰와 프로그램 및 Tailscale 연결을 유지하세요.', 'Termux와 인터넷 연결을 유지하세요.')
        if name == 'index.html':
            data = data.replace('<main>', '<main><p class="phone-host-notice">OKX Ai trade - 1.2.5</p>', 1)
            data = data.replace('보유·미체결·조건주문이 있으면 설치 보류 · 자동 청산하지 않습니다.',
                '신규 진입 자동 일시정지 · 보유분/거래소 손절 인계 후 기존 운용 복구 · 처리 중인 주문은 인계 보류')
        if name == 'style.css':
            data += '\n.phone-host-notice{padding:12px;border:1px solid #444;border-radius:16px;color:#d0ff61}\n'
        if name == 'app.js':
            data += '\n' + Path(__file__).with_name('phone_update_ui.js').read_text()
        if name == 'index.html':
            import re
            data = re.sub(r'<title>.*?</title>', '<title>OKX · 1.2.5</title>', data)
            data = re.sub(r'(<p id="mobileBuild"[^>]*>).*?(</p>)', r'\g<1>버전 1.2.5 · 15분봉 · KST 09시 기준\g<2>', data)
        if name == 'app.js':
            data += '\nconst versionRender112 = render; render = function(d){versionRender112(d); $("mobileBuild").textContent="버전 1.2.5 · 15분봉 · KST 09시 기준";};\n'
        if name == 'style.css':
            data += '\n#part-settings #programUpdate{margin-top:32px;}\n'
        return data.encode('utf-8')
    module.asset = asset

    class PhoneMobile(module.Mobile):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._view_revision = None
            self.capture_rebuilds = 0
            self.capture_reuses = 0
            self.updater = PhoneUpdater(Path(args[0]).parent, self)
            self.hosts = {f'127.0.0.1:{self.port}', f'localhost:{self.port}'}
            self.set_remote(self.config.get('https_host', ''))

        def set_remote(self, host):
            if host and not valid_host(host):
                raise ValueError('허용되지 않은 원격 주소')
            with self.lock:
                self.config['https_host'] = host
                self.hosts = {f'127.0.0.1:{self.port}', f'localhost:{self.port}'}
                if host:
                    self.hosts.add(host)

        def enqueue_control(self, op, *args, **kwargs):
            if op not in {'update', 'prepare', 'confirm', 'pause', 'entry', 'close_one', 'close_all'}:
                raise ValueError('폰에서는 PC 업데이트를 실행할 수 없습니다.')
            if not self.config.get('controls_enabled', False):
                raise ValueError('조회 모드입니다. PC 종료 후 Termux에서 전환하세요.')
            if self.updater.installing and op in {'prepare', 'confirm', 'entry'}:
                raise ValueError('업데이트 설치 중입니다. 신규 진입을 시작하지 마세요.')
            return super().enqueue_control(op, *args, **kwargs)

        def capture(self, view):
            self.update_state = self.updater.snapshot()
            revision = getattr(view, 'revision', None)
            if revision is None or revision != self._view_revision or not self.snapshot:
                super().capture(view)
                self._view_revision = revision
                self.capture_rebuilds += 1
            else:
                # Reuse presentation arrays only until the next incoming event.
                # Refresh age and controls every loop; never cache market reads.
                with self.lock:
                    self.snapshot['captured_ms'] = int(time.time()*1000)
                    self.snapshot['account_age_seconds'] = max(0,time.monotonic()-view.data_seen) if view.data_seen else None
                    self.snapshot['program_update'] = module.clean(self.update_state,self.hidden)
                    self.snapshot['controls_enabled'] = self.config.get('controls_enabled',True)
                self.capture_reuses += 1
            with self.lock:
                self.snapshot['phone_host'] = True
                self.snapshot['display_work'] = dict(rebuilds=self.capture_rebuilds,reuses=self.capture_reuses)
                if hasattr(self, 'performance'):
                    self.snapshot['performance'] = dict(self.performance.summary_cache)
                self.snapshot['external_access'] = bool(self.config.get('https_host'))

    module.PhoneMobile = PhoneMobile
    return module

"""Read-only UI projection. Never changes exchange/journal state or places orders."""
import hashlib
from okx_click716 import close_key
from okx_core import dec,fmt


def margin_fields(p):
    if not p:return dict(margin=None,margin_basis='미확인')
    from decimal import Decimal,InvalidOperation
    for key,basis in (('margin','거래소 포지션 증거금'),('imr','거래소 초기 필요 증거금')):
        try:
            value=Decimal(str(p.get(key)))
            if value.is_finite() and value>=0:return dict(margin=str(value),margin_basis=basis)
        except (InvalidOperation,ValueError,TypeError):pass
    return dict(margin=None,margin_basis='미확인')

def dashboard_snapshot(snapshot,records,day,market_connected,account_connected,telegram_configured):
    """Explicit display-field allowlist avoids leaking raw account config or credentials."""
    rows=[]
    for record in records:
        p=next((p for p in snapshot['positions'] if (p.get('instId'),p.get('posSide'))==(record['symbol'],record['direction']) and dec(p.get('pos') or 0)!=0),None)
        phase=record.get('phase','active');verified=record.get('protection_verified',False)
        signal=record.get('v4_signal',{})
        reason=record.get('exit_reason') if phase=='closing' else record.get('pending_add',{}).get('kind') if phase=='adding' else signal.get('reason','거래소 보호 상태 확인 중')
        protection_note=''
        guard=record.get('profit_state714',{})
        from okx_channel4h730 import is_owned
        if guard:
            stage=('잔량 보호 중' if record.get('partial_used') else '전량 청산 확인 중' if phase=='closing' else '절반청산 체결 확인 중' if phase=='partial_closing' else '+20% ROE 최초 절반청산 대기')
            protection_note='최고 관측 ROE '+format(float(guard.get('peak_roe',0))*100,'+.2f')+'% · '+stage
            if phase in ('resizing','protecting'):protection_note+=' · SL 변경 확인 중'
            if is_owned(record):protection_note+=' · 삭제된 4H 경로의 기존 보유분 · 6시간 종료'
            reason=(reason or '')+' / '+protection_note
        elif is_owned(record):
            protection_note='기존 4H 보유분만 관리 · +20% 최초 절반익절 · 잔량 수익보호 · 최대6시간'
            reason=(reason or '')+' / '+protection_note
        rows.append(dict(close_key=close_key(record=record),key=hashlib.sha256(record['client_id'].encode()).hexdigest()[:16],symbol=record['symbol'],direction=record['direction'],
            leverage=record['leverage'],entry=p.get('avgPx') if p else None,mark=p.get('markPx') if p else None,
            roe=p.get('uplRatio') if p else None,pnl=p.get('upl') if p else None,target=record.get('holding_rule',{}).get('target') or signal.get('target'),target_mode=record.get('holding_rule',{}).get('target_mode','review'),stop=record.get('stop_px'),quantity=p['pos'] if p else record['quantity'],
            phase=phase,protected=bool(verified and phase=='active'),reason=reason,protection_note=protection_note,source='auto',**margin_fields(p)))
    owned={(r['symbol'],r['direction']) for r in records}
    for p in snapshot['positions']:
        if dec(p.get('pos') or 0)==0 or (p.get('instId'),p.get('posSide')) in owned:continue
        symbol=p.get('instId','');side=p.get('posSide','long')
        if not symbol.endswith('-USDT-SWAP'):continue
        rows.append(dict(close_key=close_key(position=p),key=hashlib.sha256(('manual:'+symbol+':'+side).encode()).hexdigest()[:16],symbol=symbol,direction=side,leverage=p.get('lever'),entry=p.get('avgPx'),mark=p.get('markPx'),roe=p.get('uplRatio'),pnl=p.get('upl'),stop=None,quantity=p.get('pos'),phase='수동 보유',protected=False,reason='수동 진입 포지션입니다. 자동 관리는 하지 않으며 개별 청산 버튼으로 직접 종료할 수 있습니다.',source='manual',**margin_fields(p)))
    return dict(positions=rows,day_profit=fmt(snapshot['equity']-dec(day['base'])) if day else None,
        market_connected=bool(market_connected),account_connected=bool(account_connected),telegram_configured=bool(telegram_configured))

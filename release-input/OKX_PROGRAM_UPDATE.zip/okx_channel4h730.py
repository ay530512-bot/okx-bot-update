"""Retired 4H route: recognize legacy positions, never create a new entry.

The module name remains only for saved-state compatibility and fail-closed
rejection of pending legacy signals. The 55/20 entry algorithm is removed.
"""
from okx_core import BotError
STEP = 14400000
ROUTE = 'donchian55_4h730'
DEFAULTS = dict(enabled=False, retired=True)

def enabled(config):
    return False

def is_signal(signal):
    return bool(signal and (signal.get('channel4h730')
                or signal.get('pattern') == ROUTE
                or str(signal.get('signal_id', '')).startswith('ch4h730-')
                or signal.get('setup_frame') == '4H'
                or signal.get('execution_frame') == '4H'))

def is_owned(record):
    return bool(record and (is_signal(record.get('v4_signal'))
                or record.get('holding_rule', {}).get('channel4h730')))

def setup(bars):
    return None

def reject_entry(*args, **kwargs):
    raise BotError('4시간봉 추가 진입 경로 삭제됨 · V7.32 15분봉 규칙만 허용')

make_signal = check_entry = prepare_plan = submit_check = capped_plan = reject_entry

def management(engine, snapshot, position, record):
    from okx_profit_guard714 import management as common_management
    return common_management(engine, snapshot, position, record)

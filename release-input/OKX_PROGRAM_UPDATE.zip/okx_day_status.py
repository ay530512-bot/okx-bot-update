"""Read-only, explicit daily latch display. Never resets trading state."""
from datetime import datetime,timedelta
from okx_core import dec,fmt,KST,day_key
from okx_daily_goal728 import daily_goal,goal_line

def daily_status(day,equity,now,config,ai_cost='0'):
 r=config['risk'];d=day or {};current=dec(equity) if equity is not None else None
 start=dec(d.get('start_equity',d.get('base','0')));base=dec(d.get('base','0'))
 pnl=current-base if current is not None and d else None;roi=pnl/start if pnl is not None and start>0 else None
 resume=None
 try:resume=int((datetime.strptime(d['date'],'%Y-%m-%d').replace(tzinfo=KST)+timedelta(days=1)).timestamp()*1000)
 except (KeyError,ValueError,TypeError):pass
 return dict(goal=daily_goal(d,equity,ai_cost,day_key(now)),date=d.get('date'),ended=bool(d.get('ended')),reason=d.get('end_reason') or ('중단 사유 미기록: 기록 확인 필요' if d.get('ended') else '일일 한도 내'),
  start_equity=fmt(start) if d else None,adjusted_base=fmt(base) if d else None,current_equity=fmt(current) if current is not None else None,
  net_flow=d.get('net_flow','0') if d else None,pnl=fmt(pnl) if pnl is not None else None,roi=float(roi) if roi is not None else None,
  daily_stop=r['daily_stop'] if r.get('daily_loss_enabled',True) else None,daily_cap=r['daily_cap'] if r.get('daily_profit_cap_enabled',True) else None,resume_ms=resume if d.get('ended') else None,
  observed_roi=d.get('stop_observed_roi'),observed_equity=d.get('stop_observed_equity'),observed_ms=d.get('stop_observed_ms'),
  baseline_source=d.get('baseline_source','기존 기록'),includes_manual=True,flow_status=d.get('flow_status','이체 내역 확인 대기'),recent_transfers=d.get('recent_transfers',[]),transfer_latch_note=d.get('transfer_latch_note',''))

def lines(s):
 def number(x):return '미확인' if x is None else str(x)
 def pct(x):return '미확인' if x is None else f'{float(x)*100:+.2f}%'
 resume=datetime.fromtimestamp(s['resume_ms']/1000,KST).strftime('%m/%d %H:%M KST') if s['resume_ms'] else '해당 없음'
 return [f"거래일 {s['date'] or '미설정'} · {'당일 중단: '+s['reason'] if s['ended'] else '일일 한도 내'}",
  f"시작 {number(s['start_equity'])} / 입출금 보정 기준 {number(s['adjusted_base'])} / 현재 {number(s['current_equity'])} USDT",
  f"보정 매매손익 {number(s['pnl'])} USDT ({pct(s['roi'])}) · 한도 {pct(s['daily_stop']) if s['daily_stop'] is not None else '손실 중단 없음'} / {pct(s['daily_cap']) if s['daily_cap'] is not None else '수익 중단 없음'}",
  f"순이체 {number(s['net_flow'])} USDT · {s['flow_status']}",
  f"중단 당시 {pct(s['observed_roi'])} · 재개 가능 {resume} · 수동 손익 포함 / 재개 전 계정 대조",
  goal_line(s.get('goal')),
  '목표: KST 00시 일일 장부 기준 · 입출금 제외 · 수수료·펀딩 및 당일 AI 비용 추정 반영',
  '미청산 평가손익·수동 손익 포함 · 도달 후에도 변동 가능 · 목표 도달로 자동청산/중단하지 않음']

"""Short-lived admission-only GET reuse and per-account/endpoint read pacing."""
import copy,hashlib,threading,time
from contextlib import contextmanager
from okx_core import BotError

LOCAL=threading.local()
LOCK=threading.Lock();NEXT={};COOLDOWN={}
CACHE_PATHS={'/api/v5/account/config','/api/v5/account/balance','/api/v5/account/positions',
 '/api/v5/trade/orders-pending','/api/v5/trade/orders-algo-pending',
 '/api/v5/account/trade-fee','/api/v5/account/max-size'}

@contextmanager
def account_read_batch(api):
 previous=getattr(LOCAL,'batch',None)
 LOCAL.batch=dict(api=api,rows={})
 try:yield
 finally:LOCAL.batch=previous

def get(api,path,params):
 batch=getattr(LOCAL,'batch',None)
 cache=batch['rows'] if batch and batch['api'] is api and path in CACHE_PATHS else None
 key=(path,tuple(sorted((k,str(v)) for k,v in params.items())))
 if cache is not None:
  item=cache.get(key)
  if item and 0<=time.monotonic()-item[0]<3:return copy.deepcopy(item[1])
 result=api.request('GET',path,params=params)
 if cache is not None:cache[key]=(time.monotonic(),copy.deepcopy(result))
 return result

def invalidate(api):
 batch=getattr(LOCAL,'batch',None)
 if batch and batch['api'] is api:batch['rows'].clear()

def identity(api,path):
 return (hashlib.sha256(str(getattr(api,'key','')).encode()).hexdigest(),path.split('?')[0])

def before_read(api,path):
 key=identity(api,path);now=time.monotonic()
 with LOCK:
  if COOLDOWN.get(key,0)>now:raise BotError('OKX 50011 요청 제한 재시도 대기: '+key[1])
  due=max(now,NEXT.get(key,now));NEXT[key]=due+.5
 delay=due-now
 if delay>0:time.sleep(delay)

def limited(api,path):
 key=identity(api,path)
 with LOCK:COOLDOWN[key]=time.monotonic()+2

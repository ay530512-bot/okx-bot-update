"""Causal, configurable OR entries: relaxed double patterns or trend MA retests."""
from okx_swing_context import evidence,STEPS
DEFAULTS=dict(enabled=True,ma_periods=[15,20,50],touch_bars=3,touch_atr=.6,reclaim_atr=.15,
 slope_atr=.02,impulse_bars=12,impulse_atr=.3,structure_tolerance_atr=.5,
 max_extension_atr=1.8,close_location=.45,stop_buffer_atr=.5,
 double_pivot_wing=1,double_min_gap=2,double_zone_atr=.6,double_minimum_swing_atr=.3,
 double_progress_atr=.05,double_max_age_bars=8)
def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('trend_entry',{}))
def enabled(c):return c.get('signals',{}).get('trend_entry',{}).get('enabled',False)
def validate(p):
 return (all(type(p[k]) is int for k in ('touch_bars','impulse_bars','double_pivot_wing','double_min_gap','double_max_age_bars')) and type(p['enabled']) is bool and set(p['ma_periods'])<=set((15,20,50,100,120,200)) and bool(p['ma_periods'])
  and 1<=p['touch_bars']<=5 and .1<=p['touch_atr']<=1 and 0<=p['reclaim_atr']<=.5
  and 0<=p['slope_atr']<=.5 and 6<=p['impulse_bars']<=30 and .1<=p['impulse_atr']<=2
  and 0<=p['structure_tolerance_atr']<=1 and .5<=p['max_extension_atr']<=3 and .4<=p['close_location']<=.8
  and .25<=p['stop_buffer_atr']<=2 and 1<=p['double_pivot_wing']<=3
  and 2*p['double_pivot_wing']<=p['double_min_gap']<=10 and .1<=p['double_zone_atr']<=1
  and .1<=p['double_minimum_swing_atr']<=2 and 0<p['double_progress_atr']<=.5 and 1<=p['double_max_age_bars']<=12)

def trend_hits(b,frame,m,c):
 if not enabled(c):return {}
 p=settings(c);atr=m['atr'];out={}
 if atr<=0 or len(b)<max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+3:return out
 last=b[-1];recent=b[-p['touch_bars']:];history=b[-p['impulse_bars']:-p['touch_bars']]
 if not history:return out
 span=last[2]-last[3]
 if span<=0:return out
 for side,action in ((1,'LONG'),(-1,'SHORT')):
  # One timeframe's net movement and MA20 slope establish direction; no all-frame alignment.
  if (last[4]-b[-p['impulse_bars']][4])*side<atr*p['impulse_atr'] or m['slopes'][20]*side<p['slope_atr']:continue
  location=(last[4]-last[3])/span if side==1 else (last[2]-last[4])/span
  if location<p['close_location'] or (last[4]-b[-2][4])*side < -atr*.05:continue
  extreme=min(r[3] for r in recent) if side==1 else max(r[2] for r in recent)
  previous=min(r[3] for r in history) if side==1 else max(r[2] for r in history)
  if (extreme-previous)*side < -atr*p['structure_tolerance_atr']:continue
  for period in p['ma_periods']:
   level=m['ma'][period]
   touched=[r for r in recent if r[3]<=level+atr*p['touch_atr'] and r[2]>=level-atr*p['touch_atr']]
   if not touched or (last[4]-level)*side < -atr*p['reclaim_atr'] or (last[4]-level)*side>atr*p['max_extension_atr']:continue
   touch=min(touched,key=lambda r:r[3]) if side==1 else max(touched,key=lambda r:r[2])
   # A retest needs actual movement toward the level, not just candles standing above it.
   if side==1 and not any(r[3]<b[-p['touch_bars']-1][4] for r in recent):continue
   if side==-1 and not any(r[2]>b[-p['touch_bars']-1][4] for r in recent):continue
   target=max(r[2] for r in b[-20:]) if side==1 else min(r[3] for r in b[-20:])
   if (target-last[4])*side<=0:continue
   out[action]=dict(pattern='trend_support' if side==1 else 'trend_resistance',frame=frame,first=level,second=extreme,
    first_ms=history[0][0],second_ms=touch[0],confirmed_ms=last[0]+STEPS[frame],gap_bars=0,
    retracement_atr=abs(last[4]-extreme)/atr,reaction_confirmed=True,ma_period=period,ma_level=level,
    target=target,target_source=frame+' 최근20개 완료봉 반대 극점',stop=extreme-side*atr*p['stop_buffer_atr'],max_hold_seconds=86400)
   break
 return out

def entry_evidence(b,frame,m,c):
 local=c
 if enabled(c):
  p=settings(c);local=dict(c,signals=dict(c['signals'],swing_context=dict(c['signals'].get('swing_context',{}),
   pivot_wing=p['double_pivot_wing'],min_gap=p['double_min_gap'],zone_atr=p['double_zone_atr'],minimum_swing_atr=p['double_minimum_swing_atr'],progress_atr=p['double_progress_atr'],max_age_bars=p['double_max_age_bars'])))
 raw=evidence(b,frame,m['atr'],local)
 doubles={k:v for k,v in raw.items() if v['pattern'] in ('double_top','double_bottom')}
 # Prioritize a confirmed double pattern when both strategies point the same way.
 from okx_double_retest import evidence as retest_evidence
 return dict(trend_hits(b,frame,m,c),**doubles) | retest_evidence(b,frame,m['atr'],c)

"""Higher-timeframe context + closed execution-bar reaction, independent OR setups."""
import statistics
from okx_rules import metrics,pivots

DEFAULTS=dict(enabled=True,context_frames=['1H','4H'],execution_frames=['5m','1m','15m'],
    reference_periods=[5,10,15,20,50,100,120,200],zone_atr=.4,
    reaction_atr=.03,hold_bars=3,min_excursion_atr=.75,max_level_distance_atr=2.,
    band_excursion_atr=.05,band_rejection_atr=.3,max_band_retreat_atr=2.5)
STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}


def validate(p):
    return (type(p['enabled']) is bool and p['context_frames'] and all(x in ('1H','4H') for x in p['context_frames'])
        and p['execution_frames'] and all(x in ('1m','5m','15m') for x in p['execution_frames'])
        and p['reference_periods'] and all(type(x) is int and x in (5,10,15,20,50,100,120,200) for x in p['reference_periods'])
        and 0<p['zone_atr']<=1 and 0<p['reaction_atr']<=.5 and type(p['hold_bars']) is int and 3<=p['hold_bars']<=8
        and 0<p['min_excursion_atr']<=3 and 0<p['max_level_distance_atr']<=4
        and 0<p['band_excursion_atr']<=1 and 0<p['band_rejection_atr']<=2 and 0<p['max_band_retreat_atr']<=4)


def background(b,c):
    n=c['indicators']['bb_period'];shift=c['signals']['slope_bars']
    if len(b)<max(21,n+shift):return None
    values=[r[4] for r in b];mid=statistics.mean(values[-n:]);sd=statistics.pstdev(values[-n:])
    tr=[max(x[2]-x[3],abs(x[2]-a[4]),abs(x[3]-a[4])) for a,x in zip(b,b[1:])]
    atr=statistics.mean(tr[-14:])
    if atr<=0:return None
    p=c['signals']['context_entries']
    ma={v:statistics.mean(values[-v:]) for v in p['reference_periods'] if len(values)>=v+shift}
    slope={v:(ma[v]-statistics.mean(values[-v-shift:-shift]))/atr for v in ma}
    return dict(ma=ma,slopes=slope,atr=atr,mid=mid,upper=mid+sd*c['indicators']['bb_multiplier'],lower=mid-sd*c['indicators']['bb_multiplier'])


def setups(frames,c,now):
    p=c['signals'].get('context_entries',{})
    if not p.get('enabled'):return []
    hits=[];need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1
    for frame in p['execution_frames']:
        step=STEPS[frame];b=[r for r in frames.get(frame,[]) if r[0]+step<=now]
        if len(b)<need+1:continue
        last,prev=b[-1],b[-2]
        if not last[0]+step<=now<last[0]+step+c['signals']['wick15']['entry_window_seconds']*1000:continue
        local=metrics(b[:-1],c);atr=local['atr'];recent=b[-p['hold_bars']:];older=b[-12:-p['hold_bars']]
        low=min(x[3] for x in recent);high=max(x[2] for x in recent)
        for context in p['context_frames']:
            ctx=[r for r in frames.get(context,[]) if r[0]+STEPS[context]<=last[0]]
            m=background(ctx,c)
            if not m:continue
            tol=m['atr']*p['zone_atr']
            levels=pivots(ctx,c)
            for side in (1,-1):
                direction='LONG' if side==1 else 'SHORT';kind='support' if side==1 else 'resistance'
                reaction=(last[4]-last[1])*side>0 and (last[4]-prev[4])*side>=atr*p['reaction_atr']
                stable=(low>=min(x[3] for x in older)-atr*.15 and last[3]>=prev[3]-atr*.1) if side==1 else (high<=max(x[2] for x in older)+atr*.15 and last[2]<=prev[2]+atr*.1)
                if not reaction or not stable:continue
                test=low if side==1 else high
                def add(pattern,level,source,lo=low,hi=high,extra=None):
                    hits.append(dict(direction=direction,pattern=pattern,frame=frame,low=lo,high=hi,
                        anchor=last[0],level=level,source=context+' '+source,shape={},adaptive=True,
                        independent_support=True,context_priority=True,evidence_score=13 if frame in ('5m','15m') else 11,
                        evidence=dict(context_frame=context,context_closed_ms=ctx[-1][0]+STEPS[context],
                            execution_frame=frame,multi_bar_hold=True,reaction_confirmed=True,
                            ma=m['ma'],bb={k:m[k] for k in ('mid','upper','lower')},**(extra or {}))))
                for period,level in m['ma'].items():
                    contacts=sum(x[3]-tol<=level<=x[2]+tol for x in recent)
                    maintained=all((x[4]-level)*side>=-tol for x in recent)
                    if contacts>=2 and maintained and (last[4]-level)*side>0 and m['slopes'][period]*side>=-.1:
                        add('context_ma_support_long' if side==1 else 'context_ma_resistance_short',level,'SMA'+str(period),extra=dict(period=period,contacts=contacts,reference_slope=m['slopes'][period]))
                        break
                prior=[v for v in levels if v['kind']==kind]
                if prior:
                    ref=prior[-1];level=ref['price'];middle=[r for r in ctx if r[0]>ref['time']]
                    excursion=max((r[2]-level if side==1 else level-r[3] for r in middle),default=0)
                    distance=(test-level)*side
                    if (-m['atr']*.15<=distance<=m['atr']*p['max_level_distance_atr'] and excursion>=m['atr']*p['min_excursion_atr'] and (last[4]-level)*side>0):
                        add('context_higher_low_long' if side==1 else 'context_lower_high_short',level,'확정 저점/고점 보존',extra=dict(previous_extreme=level,retest_extreme=test,intermediate_excursion_atr=excursion/m['atr']))
                stairs=(sum((recent[j][2]-recent[j-1][2])*side>0 and (recent[j][3]-recent[j-1][3])*side>=0 for j in range(1,len(recent)))>=2)
                if stairs and (last[4]-m['mid'])*side>=0:
                    support=local['ma'][15]
                    if all((r[4]-support)*side>=-atr*.15 for r in recent) and any(r[3]-atr*.4<=support<=r[2]+atr*.4 for r in recent):
                        add('context_staircase_long' if side==1 else 'context_staircase_short',support,'완만한 고저점 진행·단기 이평 지지/저항',extra=dict(staircase=True,local_ma_period=15))
                # A higher-frame band is frozen before the excursion's lower-frame bar.
                # Excursion is reconstructed only from completed execution bars; no future/unfinished higher candle.
                offsets=sorted(range(2,min(13,len(b)-need)),key=lambda j:b[-j][3] if side==1 else -b[-j][2])
                for offset in offsets:
                    anchor=b[-offset]
                    known=[r for r in frames.get(context,[]) if r[0]+STEPS[context]<=anchor[0]]
                    band=background(known,c)
                    if not band:continue
                    edge=band['lower' if side==1 else 'upper'];extreme=anchor[3] if side==1 else anchor[2]
                    if (edge-extreme)*side<=band['atr']*p['band_excursion_atr']:continue
                    window=b[-offset:];extreme=min(r[3] for r in window) if side==1 else max(r[2] for r in window)
                    retreat=(last[4]-extreme)*side
                    if not atr*p['band_rejection_atr']<=retreat<=band['atr']*p['max_band_retreat_atr']:continue
                    add('context_band_lower_rejection_long' if side==1 else 'context_band_upper_rejection_short',edge,
                        '밴드 이탈 후 확정 가격 거부',min(r[3] for r in window),max(r[2] for r in window),
                        dict(band_reference_ms=known[-1][0]+STEPS[context],excursion_ms=anchor[0],
                        excursion_extreme=extreme,retreat_atr=retreat/atr,band_return=band['lower']<=last[4]<=band['upper']))
                    break
    return hits

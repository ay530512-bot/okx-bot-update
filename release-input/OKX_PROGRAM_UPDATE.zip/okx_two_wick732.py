"""Completed 15m two-wick context entry; frozen research rule, no MA20 chase filter."""
from okx_band_flow import atr
from okx_entry722 import direction, hourly_from_15m

def setup(b, hourly=None):
    if len(b)<55:return None
    c,p=b[-1],b[-2]
    a=atr(b[-300:-1])
    if a<=0:return None
    spans=[r[2]-r[3] for r in (p,c)]
    if min(spans)<=0:return None
    up=[(r[2]-max(r[1],r[4]))/s for r,s in zip((p,c),spans)]
    low=[(min(r[1],r[4])-r[3])/s for r,s in zip((p,c),spans)]
    if min(up)>=.25 and p[2]-.5*a<=c[2]<=p[2] and c[4]<c[1] and c[4]<p[4]:
        side=-1;level=p[2];details=dict(wicks=up,prior_high=p[2],second_high=c[2])
    elif min(low)>=.25 and p[3]<=c[3]<=p[3]+.5*a and c[4]>c[1] and c[4]>p[4]:
        side=1;level=p[3];details=dict(wicks=low,prior_low=p[3],second_low=c[3])
    else:return None
    end=c[0]+900000
    h=hourly_from_15m(b) if hourly is None else [r for r in hourly if r[0]+3600000<=end]
    if len(h)<25 or h[-1][0]+3600000!=end//3600000*3600000:return None
    if any(y[0]-x[0]!=3600000 for x,y in zip(h[-25:],h[-24:])):return None
    hc=[r[4] for r in h[-21:]]
    er=abs(hc[-1]-hc[0])/max(sum(abs(y-x) for x,y in zip(hc,hc[1:])),1e-15)
    ma=sum(r[4] for r in b[-50:])/50
    old=sum(r[4] for r in b[-55:-5])/50
    near=c[3] if side==1 else c[2]
    mean=sum(r[5] for r in b[-21:-1])/20
    if not(er>=.30 and direction(h[-100:])==side and (hc[-1]-hc[0])*side>0 and (ma-old)*side>0):return None
    if abs(near-ma)>.5*a or mean<=0 or c[5]<mean:return None
    return dict(action='LONG' if side==1 else 'SHORT',reference=c[4],atr=a,
        structural_stop=c[4]-side*2*a,channel_high=level,channel_low=level,
        confirmation_ms=c[0],route721='double_wick',pattern_details=details,
        context_er=er,context_ma=ma,context_volume=c[5]/mean)

def combine(base,wick):
    if base and wick:
        if base['action']!=wick['action']:return None,'conflict'
        return dict(base,entry_source732='both_same'),'both_same'
    if base:return dict(base,entry_source732='baseline_only'),'baseline_only'
    if wick:return dict(wick,entry_source732='wick_only'),'wick_only'
    return None,'none'

def select(b,hourly=None):
    from okx_entry725 import setup as baseline
    return combine(baseline(b,hourly,variant='mild726'),setup(b,hourly))

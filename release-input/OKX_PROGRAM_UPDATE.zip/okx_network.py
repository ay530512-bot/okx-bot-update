"""IPv4-only transport scoped to the OKX HTTPS session; retain normal TLS/SNI."""
import socket
from requests.adapters import HTTPAdapter
from urllib3.connection import HTTPSConnection
from urllib3.connectionpool import HTTPSConnectionPool
from urllib3.exceptions import ConnectTimeoutError, NewConnectionError


class IPv4HTTPSConnection(HTTPSConnection):
    def _new_conn(self):
        # Preserve self.host: inherited TLS connect still checks the original hostname.
        try:
            addresses = socket.getaddrinfo(self.host, self.port, socket.AF_INET, socket.SOCK_STREAM)
        except OSError as error:
            raise NewConnectionError(self, 'OKX IPv4 DNS lookup failed') from error
        last_error = None
        for family, kind, protocol, _, address in addresses:
            sock = None
            try:
                sock = socket.socket(family, kind, protocol)
                if self.timeout is None or isinstance(self.timeout, (int, float)):
                    sock.settimeout(self.timeout)
                for option in self.socket_options or ():
                    sock.setsockopt(*option)
                if self.source_address:
                    sock.bind(self.source_address)
                sock.connect(address)
                return sock
            except OSError as error:
                last_error = error
                if sock is not None:
                    sock.close()
        if isinstance(last_error, socket.timeout):
            raise ConnectTimeoutError(self, 'OKX IPv4 connection timed out') from last_error
        raise NewConnectionError(self, 'OKX IPv4 connection failed') from last_error


class IPv4HTTPSPool(HTTPSConnectionPool):
    ConnectionCls = IPv4HTTPSConnection


class OKXIPv4Adapter(HTTPAdapter):
    def init_poolmanager(self, connections, maxsize, block=False, **pool_kwargs):
        super().init_poolmanager(connections, maxsize, block=block, **pool_kwargs)
        # Copy the per-manager mapping; never mutate urllib3's global pool classes.
        classes = dict(self.poolmanager.pool_classes_by_scheme)
        classes['https'] = IPv4HTTPSPool
        self.poolmanager.pool_classes_by_scheme = classes


def okx_session():
    import requests
    session = requests.Session()
    # Do not silently send signed account requests through an environment proxy.
    session.trust_env = False
    session.mount('https://', OKXIPv4Adapter(max_retries=0))
    return session

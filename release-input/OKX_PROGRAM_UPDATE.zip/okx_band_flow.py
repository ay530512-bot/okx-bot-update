"""User-requested intrabar band rejection / volume support profile. No API writes here."""
import copy,hashlib,math,statistics,time
from okx_core import BotError,dec

STEPS={'15m':900000,'1H':3600000,'4H':14400000}
DEFAULTS=dict(enabled=True,wick_body=2.,wick_range=.5,wick_atr=.25,
 volume_multiple=2.,stop_buffer_atr=.35,average_step=.05,max_adds=2,
 base_leverage=4,max_leverage=10,short_minutes=5,volume_fade=.8)
def enabled(c):return c.get('signals',{}).get('band_flow',{}).get('enabled',False)
def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('band_flow',{}))
def is_owned(o):return (o or {}).get('v4_signal',{}).get('strategy')=='band_flow'
def validate(p):
 return (type(p['enabled']) is bool and 1<=p['wick_body']<=5 and .3<=p['wick_range']<=.8
  and .1<=p['wick_atr']<=2 and 1<=p['volume_multiple']<=10 and .1<=p['stop_buffer_atr']<=2
  and .01<=p['average_step']<=.1 and type(p['max_adds']) is int and 0<=p['max_adds']<=2
  and p['base_leverage']==4 and p['max_leverage']==10 and 1<=p['short_minutes']<=30
  and .1<=p['volume_fade']<=1)
def allowed(i):
 return (i.get('instId','').endswith('-USDT-SWAP') and i.get('state')=='live'
  and i.get('settleCcy')=='USDT' and i.get('ctType')=='linear'
  and i.get('ctValCcy')==i.get('instId','').split('-')[0]
  and i.get('instCategory') in ('1','3','4','5','6'))
def stock(i,c):return i.get('instCategory')=='3' or i.get('groupId')=='6' or i.get('instId') in c['selection'].get('stock_linked_symbols',[])
def leverage(i,c,strong=False):
 if stock(i,c):return 5
 base=i['instId'].split('-')[0]
 return {'BTC':30,'ETH':20,'SOL':20}.get(base,settings(c)['max_leverage'] if strong else settings(c)['base_leverage'])
def rows(raw,frame,now):
 step=STEPS[frame];out=[]
 for r in raw:
  if len(r)<9:continue
  t=int(r[0])
  if t>now or t%step:continue
  v=[t]+[float(x) for x in r[1:6]]
  if not all(math.isfinite(x) for x in v) or min(v[1:5])<=0 or v[5]<0 or not v[3]<=min(v[1],v[4])<=max(v[1],v[4])<=v[2]:raise BotError('봉 데이터 오류')
  if t+step<=now and r[8]!='1':continue
  out.append(v)
 out.sort(key=lambda x:x[0])
 if len({r[0] for r in out})!=len(out):raise BotError('중복 봉 데이터')
 return out
def atr(b):
 v=[max(r[2]-r[3],abs(r[2]-a[4]),abs(r[3]-a[4])) for a,r in zip(b[:-1],b[1:])]
 return sum(v[-14:])/14
def ma(b,n):return sum(r[4] for r in b[-n:])/n
def view(b,c):
 n=c['indicators']['bb_period'];k=c['indicators']['bb_multiplier']
 mid=ma(b,n);sd=statistics.pstdev(r[4] for r in b[-n:]);a=atr(b[:-1])
 return dict(mid=mid,upper=mid+k*sd,lower=mid-k*sd,atr=a,
  ma={n:ma(b,n) for n in c['indicators']['ma_periods'] if len(b)>=n})
def signal(frames,c,now,symbol,instrument):
 from okx_oct23 import enabled as oct_enabled,signal as oct_signal
 if oct_enabled(c):return oct_signal(frames,c,now,symbol,instrument)
 p=settings(c);audit={};tails={};outside={};volume_hits=[];flow_hits=[]
 for frame,step in STEPS.items():
  b=[list(r) for r in frames.get(frame,[]) if r[0]<=now]
  if len(b)<22 or now-b[-1][0]>=step or b[-1][0]//step!=now//step:continue
  if any(b[j][0]-b[j-1][0]!=step for j in range(max(1,len(b)-22),len(b))):continue
  m=view(b,c);r=b[-1];a=m['atr'];span=r[2]-r[3];body=abs(r[4]-r[1])
  if a<=0 or span<=0:continue
  lower=min(r[1],r[4])-r[3];upper=r[2]-max(r[1],r[4]);out=[];hits=[]
  for side,w,extreme,band in ((1,lower,r[3],m['lower']),(-1,upper,r[2],m['upper'])):
   if (extreme-band)*side<0:
    out.append(side)
    if w>=max(body*p['wick_body'],span*p['wick_range'],a*p['wick_atr']):hits.append(side)
  outside[frame]=out;tails[frame]=hits
  completed=[r for r in b if r[0]+step<=now]
  from okx_flow_structure import analyse as analyse_flow
  flow_hits.extend(analyse_flow(completed,frame,c))
  if len(completed)>=22:
   prev,last=completed[-2:];base=sum(x[5] for x in completed[-22:-2])/20
   if base>0 and prev[5]>=base*p['volume_multiple']:
    if prev[4]<prev[1] and last[4]<last[1] and last[3]>=prev[3] and abs(last[4]-last[1])<abs(prev[4]-prev[1]):volume_hits.append((1,frame))
    if prev[4]>prev[1] and last[4]>last[1] and last[2]<=prev[2] and abs(last[4]-last[1])<abs(prev[4]-prev[1]):volume_hits.append((-1,frame))
  audit[frame]=dict(m,bar_ms=r[0],in_progress=True,lower_wick=lower,upper_wick=upper,
   body=body,range=span,outside=out,tail_directions=hits,
   relative_volume=r[5]/(sum(x[5] for x in b[-21:-1])/20) if sum(x[5] for x in b[-21:-1])>0 else 0)
 # Four live candle buckets coexist at this instant; their open times need not equal.
 multi=[side for side in (1,-1) if len(audit)==4 and all(side in outside.get(f,[]) for f in STEPS) and any(side in h for h in tails.values())]
 flow=max(flow_hits,key=lambda h:(STEPS[h['frame']],h['confirmed_ms'])) if flow_hits else None
 directions=set(multi or ([flow['side']] if flow else []) or [s for h in tails.values() for s in h] or [s for s,f in volume_hits])
 if len(directions)!=1:return None,'신호 없음 또는 롱·숏 동시 충돌'
 side=directions.pop();long_hold=side in multi
 if long_hold:frame='1H';kind='four_band_rejection'
 elif flow:frame=flow['frame'];kind='flow_rejection';long_hold=True
 elif any(side in h for h in tails.values()):frame=next(f for f in STEPS if side in tails.get(f,[]));kind='single_band_rejection'
 else:frame=next(f for s,f in volume_hits if s==side);kind='volume_support'
 b=[r for r in frames[frame] if r[0]<=now];m=audit[frame];current=b[-1];price=current[4];a=m['atr']
 completed=[r for r in b if r[0]+STEPS[frame]<=now]
 # Only pivots whose right-hand confirmation already exists are eligible.
 piv=[]
 for j in range(1,len(completed)-1):
  before,r,after=completed[j-1:j+2]
  if side==1 and r[3]<before[3] and r[3]<=after[3]:piv.append(r[3])
  if side==-1 and r[2]>before[2] and r[2]>=after[2]:piv.append(r[2])
 extreme=(min if side==1 else max)([current[3 if side==1 else 2],piv[-1] if piv else (min(r[3] for r in completed[-10:]) if side==1 else max(r[2] for r in completed[-10:]))])
 stop=extreme-side*a*p['stop_buffer_atr']
 target=m['upper' if side==1 else 'lower'] if long_hold else m['mid']
 if kind=='flow_rejection':stop=flow['stop'];target=flow['target'];extreme=flow['second_extreme']
 if stop<=0 or (price-stop)*side<=0:return None,'구조 손절가 유효하지 않음'
 lev=leverage(instrument,c,side in multi)
 # A conservative pre-trade check; actual liquidation price is checked again after fill.
 if abs(price-stop)/price>=.85/lev:return None,'구조 손절 전에 강제청산될 위험: 배율·손절 충돌'
 action='LONG' if side==1 else 'SHORT';identity=current[0] if kind!='volume_support' else completed[-1][0]
 if kind=='flow_rejection':identity=flow['second_ms']
 key=f'bandflow:{symbol}:{action}:{frame}:{identity}'
 if kind=='flow_rejection':key+=':flow:'+str(flow['first_ms'])
 label={'four_band_rejection':'4개 시간봉 동시 밴드 이탈·꼬리: 추세 보유','single_band_rejection':'밴드 외부 긴 꼬리: 짧은 매매','volume_support':'거래량 급증 후 저점/고점 유지','flow_rejection':flow['reason'] if flow else ''}[kind]
 if kind=='flow_rejection':label=frame+' '+label+f" / 첫 극점 {flow['first_extreme']:.8g} → 재시험 {flow['second_extreme']:.8g} / MA{flow['ma_periods']}"
 return dict(symbol=symbol,action=action,strategy='band_flow',pattern=kind,leverage=lev,
  signal_id=hashlib.sha256(key.encode()).hexdigest()[:24],stop=stop,target=target,
  atr=a,level=extreme,setup_frame=frame,execution_frame=frame,at_ms=identity,
  valid_from_ms=now,expires_ms=now+30000,entry_reference=price,entry_gap=price,
  reason=label,regime='rejection',ma=m['ma'],bb={k:m[k] for k in ('mid','upper','lower')},rsi={},retest=False,adaptive=True,
  selection=dict(activity={},scope='all_usdt_swaps',asset_category=instrument.get('instCategory')),
  holding_rule=dict(band_flow=True,long_hold=long_hold,flow_structure=kind=='flow_rejection',frame=frame,zone=extreme,target=target),
  decision_record=dict(frames=audit,reason=label,provisional=kind!='flow_rejection',flow_structure=flow if kind=='flow_rejection' else None)),''
def read(api,symbol):
 result={}
 for f in STEPS:
  try:result[f]=rows(api.public('/api/v5/market/candles',instId=symbol,bar=f,limit='300'),f,api.now_ms())
  except Exception:result[f]=[]
 return result
def scan(market):
 from concurrent.futures import ThreadPoolExecutor,as_completed
 import threading
 from okx_core import OKX
 owner=market.owner;state=market.market();started=time.monotonic();local=threading.local();apis=[];lock=threading.Lock()
 generation=getattr(owner,'search_generation',0)
 def interrupted():return owner.stop_event.is_set() or getattr(owner,'search_paused',threading.Event()).is_set() or generation!=getattr(owner,'search_generation',0)
 instruments=list(state['instruments'].values());output=[];errors=0
 from okx_oct23 import enabled as oct_enabled,turnover_ranks
 ranks=turnover_ranks(instruments,state['quotes'],owner.cfg) if oct_enabled(owner.cfg) else {}
 # Publish accumulated valid charts throughout the scan; do not wait for every symbol.
 def publish():
  if interrupted():return None
  value=dict(rows=list(output),completed=time.monotonic(),ms=int(time.time()*1000),whole_market=True,
   universe=len(instruments),all_candidates=len(output),selected_count=len(output),band_flow=True,
   scan_seconds=round(time.monotonic()-started,1),filter_counts={'data_error':errors})
  with owner.lock:
   if interrupted():return None
   owner.result=value;market.progress=dict(processed=len(output)+errors,total=len(instruments),patterns=len(output),seconds=value['scan_seconds'])
  return value
 def one(i):
  if interrupted():return None
  if not hasattr(local,'api'):
   local.api=OKX(owner.settings)
   with lock:apis.append(local.api)
  frames={}
  scan_frames=('15m','1H','4H') if owner.cfg.get('execution',{}).get('rule_channel701') else STEPS
  for f in scan_frames:
   if interrupted():return None
   key=(i['instId'],f);cached=getattr(market,'band_cache',{}).get(key)
   if cached and time.monotonic()-cached[0]<30:frames[f]=cached[1];continue
   owner.throttle()
   if interrupted():return None
   try:
    b=rows(local.api.public('/api/v5/market/candles',instId=i['instId'],bar=f,limit='300'),f,local.api.now_ms())
    frames[f]=b
    with owner.lock:
     if not hasattr(market,'band_cache'):market.band_cache={}
     market.band_cache[key]=(time.monotonic(),b)
   except Exception:frames[f]=[]
  if not any(len(b)>=22 for b in frames.values()):return None
  quote=state['quotes'].get(i['instId'],{});last=float(quote.get('last') or 0);opening=float(quote.get('sodUtc0') or last or 1)
  return dict(ranks.get(i['instId'],{}),symbol=i['instId'],instrument=i,live_frames=frames,bars5=frames.get('5m',[]),bars15=frames.get('15m',[]),
   higher={f:frames.get(f,[]) for f in ('1H','4H')},activity={},turnover=0,change=last/opening-1,
   rank=0,observed_ms=local.api.now_ms())
 try:
  with ThreadPoolExecutor(max_workers=6) as pool:
   futures=[pool.submit(one,i) for i in instruments]
   for future in as_completed(futures):
    if interrupted():
     for task in futures:task.cancel()
     break
    try:r=future.result()
    except Exception:r=None
    if r:output.append(r)
    else:errors+=1
    if (len(output)+errors)%10==0:publish()
  return publish()
 finally:
  for api in apis:api.session.close()
def candidate(e):
 result,_=e.universe.read()
 if not result:return None
 rows_=result.get('rows',[]);e.stream.monitor([r['symbol'] for r in rows_])
 waits=[]
 for row in rows_:
  symbol=row['symbol']
  if symbol in e.blocked_manual_symbols() or any(o['symbol']==symbol for o in e.records()):continue
  quote=e.stream.read(symbol,'tickers',10,e.api.now_ms())
  if not quote:continue
  frames=copy.deepcopy(row.get('live_frames',{}));now=e.api.now_ms();price=float(quote['last'])
  for f,b in frames.items():
   if b and b[-1][0]//STEPS[f]==now//STEPS[f]:
    if hasattr(e.stream,'band_bar'):b[-1]=e.stream.band_bar(symbol,f,b[-1])
    b[-1][2]=max(b[-1][2],price);b[-1][3]=min(b[-1][3],price);b[-1][4]=price
  from okx_oct23 import enabled as oct_enabled,eligible
  selection=None
  if oct_enabled(e.cfg):
   accept,active=eligible(row,e.cfg,now)
   if not accept:continue
   selection=dict(activity=active,turnover_rank=row.get('turnover_rank'),turnover_usdt_estimate=row.get('turnover_usdt_estimate'),scope='24h거래대금순위 OR 자체거래량활성')
  s,why=signal(frames,e.cfg,now,symbol,row['instrument'])
  if s and selection:s['selection']=selection
  if not s:continue
  if symbol+':'+s['signal_id'] in e.journal.data.get('seen_signals',{}):continue
  key=symbol+':'+s['signal_id']
  if not hasattr(e,'band_attempts'):e.band_attempts={}
  if now-e.band_attempts.get(key,0)<30000:continue
  e.band_focus=symbol
  e.stream.watch([symbol]+[r['symbol'] for r in e.records()]+e.chat.watch())
  if not e.stream.ready(symbol,e.cfg,now):waits.append(symbol+' 실시간 체결·호가 구독 준비');continue
  e.band_attempts[key]=now
  if len(e.band_attempts)>5000:e.band_attempts={k:v for k,v in e.band_attempts.items() if now-v<86400000}
  from okx_review_ui import emit_review
  emit_review(e,'밴드·수급 진입 검토',dict(_packets=[dict(symbol=symbol,selection=s['selection'])]),s['reason'])
  e.pipeline('preflight',symbol+' / '+s['reason'],count='signals');return s
 e.pipeline('signal_wait',' | '.join(waits[:2]) or ('10월23일형: 거래대금/자체 거래량·네 전략 OR 탐색' if e.cfg.get('signals',{}).get('oct23_entry',{}).get('enabled') else '전체 USDT 선물: 밴드 꼬리·거래량 지지/저항 탐색'));return None
def context(e,symbol,action):
 frozen=e.executing_signal;frames=read(e.api,symbol)
 i=e.api.public('/api/v5/public/instruments',instType='SWAP',instId=symbol)[0]
 from okx_oct23 import enabled as oct_enabled,eligible
 if oct_enabled(e.cfg):
  result,_=e.universe.read();row=next((r for r in (result or {}).get('rows',[]) if r['symbol']==symbol),None)
  if not row:raise BotError('10월23일 종목 선정 자료 갱신 대기')
  if not eligible(dict(row,live_frames=frames),e.cfg,e.api.now_ms())[0]:raise BotError('거래대금 순위/자체 거래량 조건 변경')
 fresh,why=signal(frames,e.cfg,e.api.now_ms(),symbol,i)
 if fresh and frozen.get('selection'):fresh['selection']=copy.deepcopy(frozen['selection'])
 if not fresh or fresh['signal_id']!=frozen['signal_id'] or fresh['action']!=action or fresh['leverage']!=frozen['leverage'] or fresh['pattern']!=frozen['pattern']:raise BotError('실시간 꼬리/지지 신호 변경: '+why)
 e.prepared_signal=fresh;e.signal_prepared_monotonic=time.monotonic()
 return dict(frames,_v4=fresh)
def add_allowed(o,p,c,now):
 if not is_owned(o) or o.get('phase')!='active' or o.get('partial_used') or o.get('pending_add') or int(o.get('band_add_count',0))>=settings(c)['max_adds']:return False
 sign=1 if o['direction']=='long' else -1;mark=float(p['markPx']);stop=float(o['stop_px'])
 if (mark-stop)*sign<=0:return False
 liq=float(p.get('liqPx') or 0);buffer=c['risk']['liquidation_buffer']
 if liq>0 and (mark<=liq*(1+buffer) if sign==1 else mark>=liq*(1-buffer)):return False
 anchor=float(o.get('band_last_fill_px') or o.get('fill_px') or p['avgPx'])
 return (mark/anchor-1)*sign<=-settings(c)['average_step']
def evaluate(frames,p,o,c,now):
 rule=o['holding_rule'];side=1 if o['direction']=='long' else -1;mark=float(p['markPx']);entry=float(p['avgPx'])
 frame=rule['frame'];b=[r for r in frames.get(frame,[]) if r[0]+STEPS[frame]<=now]
 out=dict(action='HOLD',reason='밴드·거래량 파동 보유 / 구조 SL 유지',trail=None)
 if len(b)<22:return out
 m=view(b,c);post=[r for r in b if r[0]>=o['entry_ms']]
 from okx_wave_mode import net_profitable
 profit=net_profitable(p,o)
 supported=(b[-1][4]-m['ma'][20])*side>=0 and (m['ma'][20]-ma(b[:-3],20))*side>=0
 if (mark-float(rule['target']))*side>=0 and profit:
  if rule['long_hold'] and supported:out['reason']='목표 도달 후 MA20 방향·지지/저항 유지: 잔여 파동 보유'
  else:return dict(out,action='CLOSE',reason='밴드 목표 도달·비용 차감 수익 청산')
 if len(post)>=2:
  prev,last=post[-2:];base=sum(r[5] for r in b[-22:-2])/20
  fade=base>0 and (prev[5]+last[5])/2<base*settings(c)['volume_fade']
  reverse=(last[4]-prev[4])*side<0 and (last[4]-last[1])*side<0
  if fade and reverse:return dict(out,action='CLOSE',reason='거래량 감소와 반대 방향 전환 확인')
  if profit and not supported and all((r[4]-m['ma'][20])*side<0 for r in post[-2:]):return dict(out,action='CLOSE',reason='수익권 MA20 반대편 2봉 확인·파동 정리')
 if not rule['long_hold'] and now-o['entry_ms']>=settings(c)['short_minutes']*60000 and profit:return dict(out,action='CLOSE',reason='짧은 매매 보유시간 도달·순수익 확보')
 if profit and len(post)>=3:
  prev,pivot,last=post[-3:];level=pivot[3] if side==1 else pivot[2]
  confirmed=level<prev[3] and level<=last[3] if side==1 else level>prev[2] and level>=last[2]
  target=level-side*m['atr']*settings(c)['stop_buffer_atr']
  if confirmed and (target-float(o['stop_px']))*side>0 and (target-entry)*side>entry*float(o.get('cost_rate') or .003) and (mark-target)*side>0:out['trail']=target
 return out

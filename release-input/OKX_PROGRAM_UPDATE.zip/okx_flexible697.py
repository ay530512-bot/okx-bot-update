"""Three OR families. Location + observed response are mandatory; indicators are evidence."""
import statistics,math

def reaction(b,j,n,side):
 test=b[j];last=b[n]
 if j==n:
  # A completed reversal bar is enough; no mandatory extra confirmation bar.
  return (last[4]-last[1])*side>0 and (last[4]-b[j-1][4])*side>0
 return (last[4]-last[1])*side>0 and ((last[4]-test[4])*side>0 or (last[4]-test[2 if side==1 else 3])*side>0)

def target_ahead(b,price,side,end):
 from okx_structure694 import swings
 past=b[max(0,end-60):end];kind='high' if side==1 else 'low'
 levels=[v for _,t,v in swings(past) if t==kind and (v-price)*side>0]
 if not levels:levels=[float(r[2 if side==1 else 3]) for r in past if (float(r[2 if side==1 else 3])-price)*side>0]
 return (min(levels) if side==1 else max(levels)) if levels else None

def setups(b,atr,tick=0,c=None):
 from okx_pattern15 import band,avg,vol
 from okx_structure694 import params,swings
 if len(b)<45 or not math.isfinite(atr) or atr<=0:return []
 k=params(c or {});n=len(b)-1;price=float(b[-1][4]);out=[];pad=max(float(tick),atr*k['stop_buffer_atr'])
 def emit(setup,priority,action,side,j,stop,target,variant,**extras):
  if target is None or (target-price)*side<=0 or (price-stop)*side<=0:return
  test=b[j];
  if any((float(row[3 if side==1 else 2])-stop)*side<=0 for row in b[j+1:]):return
  # A response already far from its tested zone is no longer an early entry.
  if j<n and (price-float(test[4]))*side>atr:return
  if j==n and abs(float(test[4])-float(test[1]))>atr*1.5:return
  vr=vol(b,j);span=test[2]-test[3];tail=min(test[1],test[4])-test[3] if side==1 else test[2]-max(test[1],test[4])
  evidence=dict(volume_expansion=bool(vr and vr>=1.5),volume_relative=vr,long_tail=span>0 and tail/span>=.4,confirmation_volume_rise=b[-1][5]>b[j-1][5],volume_contraction=j>0 and test[5]<b[j-1][5])
  score=40+15*evidence['volume_expansion']+10*evidence['long_tail']+10*evidence['confirmation_volume_rise']+5*evidence['volume_contraction']
  threshold=float(test[1] if j==n else test[4])
  out.append(dict(setup=setup,priority=priority,action=action,variant=variant,route='reversal' if setup=='band_double' else 'continuation',test_ms=test[0],confirmation_ms=b[-1][0],signal_ms=b[-1][0],structural_stop=stop,target=target,entry_trigger=threshold,entry_ceiling=price+side*atr*.5,reference=price,atr=atr,stop_buffer_atr=k['stop_buffer_atr'],relative_volume=vr,evidence=evidence,evidence_score=score,confirmation_volume=b[-1][5],retest_volume=test[5],**extras))
 for action,side,field in [('LONG',1,3),('SHORT',-1,2)]:
  for j in (n,n-1,n-2):
   if not reaction(b,j,n,side):continue
   test=b[j];past=b[max(0,j-32):j];prior=(min if side==1 else max)(float(r[field]) for r in past);extreme=float(test[field]);bb=band(b,j)
   # Location at a prior extreme OR Bollinger outer zone. A touch alone never triggers.
   near_prior=abs(extreme-prior)<=atr*1.25
   near_band=bool(bb and (test[3]<=bb[0]+atr*.1 if side==1 else test[2]>=bb[2]-atr*.1))
   retained=all((float(r[field])-extreme)*side>=-atr*.1 for r in b[j+1:])
   known_turn=any(t==('low' if side==1 else 'high') and abs(v-prior)<=atr*.5 for _,t,v in swings(b[max(0,j-32):n+1]))
   approach=(float(b[max(0,j-3)][4])-extreme)*side>=atr*.75
   if ((near_prior and known_turn) or (near_band and approach)) and retained:
    anchor=(min if side==1 else max)([prior,extreme]+[float(r[field]) for r in b[max(0,j-4):n+1]])
    # Price must reject the zone, not close beyond it while still accelerating.
    favorable=(price-extreme)*side>0 and (price-prior)*side>0
    if favorable:
     emit('band_double',0,action,side,j,anchor-side*pad,target_ahead(b,price,side,j),'failed_extreme_rejection',first_ms=test[0],first_extreme=anchor,retest_extreme=extreme)
   # MA zone support/resistance: ordering, slope and cross200 are evidence, not vetoes.
   if j>=200:
    for period in (120,200,100,50):
     zone=avg(b,period,j)
     if test[3]<=zone<=test[2] and (test[4]-zone)*side>0 and (b[j-1][4]-zone)*side>0:
      m=[avg(b,z,j) for z in (50,100,120,200)]
      before=len(out)
      emit('ma_retest',1,action,side,j,extreme-side*pad,target_ahead(b,price,side,j),'ma_zone_reaction',cross_ms=test[0],retest_extreme=extreme,zone=zone,ma_period=period)
      if len(out)>before:out[-1]['evidence']['ma_ordered']=all((m[a]-m[a+1])*side>0 for a in range(3));out[-1]['evidence_score']+=10*int(out[-1]['evidence']['ma_ordered'])
      break
   # Directional long body then opposite pullback, retained structural extreme and response.
   for i in range(j-1,max(20,j-16),-1):
    impulse=b[i];body=abs(impulse[4]-impulse[1]);bodies=sorted(abs(r[4]-r[1]) for r in b[i-20:i]);meaningful=body>0 and body>=max(statistics.median(bodies),bodies[int(.75*(len(bodies)-1))])
    if not meaningful or (impulse[4]-impulse[1])*side<=0:continue
    low,high=impulse[3],impulse[2];base=low if side==1 else high
    if not low<float(test[field])<high or any((r[field]-base)*side<0 for r in b[i+1:]):continue
    if not any((r[4]-impulse[4])*side<0 for r in b[i+1:j+1]):continue
    emit('impulse_retest',2,action,side,j,base-side*pad,high if side==1 else low,'impulse_pullback_reaction',impulse_ms=impulse[0],retest_extreme=extreme)
    break
 # One candidate per family/direction; prefer newest response, then evidence.
 result=[]
 for v in sorted(out,key=lambda v:(v['priority'],-v['test_ms'],-v['evidence_score'])):
  if not any((x['setup'],x['action'])==(v['setup'],v['action']) for x in result):result.append(v)
 return result

def select_regime(p,row):
 from okx_structure694 import regime
 fs=row.get('live_frames',{});r1=regime(fs.get('1H',[]));r4=regime(fs.get('4H',[]));p['market_regime']=dict(hour=r1,four_hour=r4)
 for v in p['entry_setups']:
  own='uptrend' if v['action']=='LONG' else 'downtrend';opp='downtrend' if v['action']=='LONG' else 'uptrend'
  v.setdefault('evidence',{}).update(hour_aligned=r1==own,four_hour_aligned=r4==own,higher_frames_opposed=r1==opp and r4==opp)
  v['evidence_score']=min(100,v.get('evidence_score',40)+10*(r1==own)+10*(r4==own))
  v['market_regime']=r1;v['learning_key']='|'.join((v['setup'],'15m','long' if v['action']=='LONG' else 'short',r1,'697'))
 return p

def diagnose(b,atr,c=None):
 if len(b)<45 or atr<=0:return '15분봉 자료 부족'
 for side in (1,-1):
  if any(reaction(b,j,len(b)-1,side) for j in (len(b)-1,len(b)-2,len(b)-3)):return '회복·거절 반응 있음 / 구조 위치·유효 목표 미확인'
 return '완료 15분봉 회복·거절 반응 미확인'

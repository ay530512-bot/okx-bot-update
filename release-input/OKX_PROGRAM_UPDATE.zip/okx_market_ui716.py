"""Searchable quote table + explicit directional order buttons in the existing dock."""
import tkinter as tk
import time
from okx_ui_theme import BG,PANEL,INNER,BORDER,TEXT,MUTED,GREEN,RED,LONG_BG,SHORT_BG,AMBER
from tkinter import ttk

class MarketPanel(tk.Frame):
    def __init__(self,parent,view,chart):
        super().__init__(parent,bg=BG);self.view=view;self.chart=chart;self.signature=None;self.selected=None
        tk.Label(self,text='전체 USDT 선물',bg=BG,fg=GREEN,font=(view.family,13,'bold')).pack(anchor='w',padx=10,pady=5)
        self.search=tk.StringVar();entry=tk.Entry(self,textvariable=self.search,bg=INNER,fg=TEXT,insertbackground=TEXT,relief='flat');entry.pack(fill='x',padx=8,pady=4);self.search.trace_add('write',lambda *a:self.render(True))
        tools=tk.Frame(self,bg=BG);tools.pack(fill='x',padx=8)
        self.sort=tk.StringVar(value='상승순');combo=ttk.Combobox(tools,textvariable=self.sort,values=['상승순','하락순','종목순'],state='readonly',width=8,style='Market.TCombobox');combo.pack(side='left');combo.bind('<<ComboboxSelected>>',lambda e:self.render(True))
        self.info=tk.StringVar(value='시세 수신 중 · 등락률은KST09시 기준');tk.Label(tools,textvariable=self.info,bg=BG,fg=MUTED,font=(view.family,9)).pack(side='left',padx=5)
        bottom=tk.Frame(self,bg=BG);bottom.pack(side='bottom',fill='x')
        self.selection=tk.StringVar(value='종목을 누르면 위 차트에 표시됩니다.');tk.Label(bottom,textvariable=self.selection,bg=BG,fg=TEXT,font=(view.family,10)).pack(anchor='w',padx=8)
        from tkinter.scrolledtext import ScrolledText
        self.analysis=ScrolledText(bottom,height=10,wrap='word',bg=INNER,fg=TEXT,relief='flat',font=(view.family,10))
        self.analysis.pack(fill='both',expand=True,padx=8,pady=5);self.analysis.configure(state='disabled')
        self.analysis.tag_configure('funding',foreground=AMBER)
        self.analysis_text=None
        self.after(1000,self.refresh_analysis)
        row=tk.Frame(bottom,bg=BG);row.pack(fill='x',padx=8,pady=6);self.buttons=[]
        for label,side,color in [('롱 · 5배 시장가 진입','LONG',LONG_BG),('숏 · 5배 시장가 진입','SHORT',SHORT_BG)]:
            from okx_dashboard import RoundedButton
            b=RoundedButton(row,label,lambda d=side:self.order(d),width=185,kind='long' if side=='LONG' else 'short');b.pack(side='left',fill='x',expand=True,padx=2);self.buttons.append(b)
        tk.Label(bottom,text='직접 진입 · 전 종목5배 / 3 USDT 제외 · 증거금1/4 / 최초2ATR SL / +20% ROE 최초 절반청산',wraplength=340,bg=BG,fg=MUTED,font=(view.family,9),justify='left').pack(anchor='w',padx=8,pady=(0,5))
        frame=tk.Frame(self,bg=BG);frame.pack(fill='both',expand=True,padx=8,pady=5)
        style=ttk.Style(self);style.configure('Market716.Treeview',background=PANEL,fieldbackground=PANEL,foreground=TEXT,rowheight=28,font=(view.family,10));style.map('Market716.Treeview',background=[('selected','#25301b')])
        self.table=ttk.Treeview(frame,columns=('symbol','last','change'),show='headings',style='Market.Treeview',selectmode='browse')
        for key,title,width in [('symbol','종목',135),('last','현재가',105),('change','09시 등락률',90)]:self.table.heading(key,text=title);self.table.column(key,width=width,stretch=True)
        bar=ttk.Scrollbar(frame,orient='vertical',command=self.table.yview);bar.pack(side='right',fill='y');self.table.configure(yscrollcommand=bar.set);self.table.pack(fill='both',expand=True)
        self.table.tag_configure('up',foreground=GREEN);self.table.tag_configure('down',foreground=RED);self.table.bind('<<TreeviewSelect>>',self.choose)
        self.render()
    def refresh_analysis(self):
        if not self.winfo_exists():return
        self.render();self.after(1000,self.refresh_analysis)
    def render(self,force=False):
        g=self.view.state.get('entry_gate') or dict(allowed=False,reason='PC 진입 상태 확인 중')
        from okx_direction732 import describe,fresh
        data=self.chart.data or {}
        a=data.get('analysis') if data.get('symbol')==self.selected and not data.get('stale') and not data.get('error') else None
        now=int(time.time()*1000);valid=fresh(a,now)
        from okx_funding732 import describe as describe_funding
        feed=getattr(self.chart,'feed',None)
        monitor=getattr(feed,'funding',None)
        funding=monitor.snapshot(self.selected) if monitor else self.view.callbacks.get('funding_snapshot',lambda s:None)(self.selected)
        funding_text=describe_funding(funding,g.get('preview_margin'))
        text=funding_text+'\n\n'+describe(a,g.get('preview_margin'),now)
        if text!=self.analysis_text:
            scroll=self.analysis.yview()[0];self.analysis.configure(state='normal');self.analysis.delete('1.0','end');self.analysis.insert('1.0',text);self.analysis.tag_add('funding','1.0',str(funding_text.count('\n')+2)+'.0');self.analysis.configure(state='disabled');self.analysis.yview_moveto(scroll);self.analysis_text=text
        blocked=''
        for b in self.buttons:b.set_enabled(bool(self.selected and not blocked and g['allowed'] and not self.view.demo))
        if self.selected:self.selection.set(self.selected.replace('-USDT-SWAP','/USDT')+' · '+(blocked or g['reason']))
        data=self.view.state.get('futures_market',{});query=self.search.get().upper().strip();rows=[r for r in data.get('rows',[]) if query in r['symbol']]
        rows.sort(key=(lambda r:r['change']) if self.sort.get()=='하락순' else (lambda r:r['symbol']) if self.sort.get()=='종목순' else (lambda r:-r['change']))
        signature=(data.get('observed_ms'),query,self.sort.get(),data.get('stale'))
        if not force and signature==self.signature:return
        self.signature=signature;scroll=self.table.yview()[0];self.table.delete(*self.table.get_children())
        for r in rows:self.table.insert('', 'end',iid=r['symbol'],values=(r['symbol'].replace('-USDT-SWAP','/USDT'),format(r['last'],'.8g'),format(r['change']*100,'+.2f')+'%'),tags=('up' if r['change']>=0 else 'down',))
        self.table.yview_moveto(scroll)
        if self.selected in self.table.get_children():self.table.selection_set(self.selected)
        self.info.set(str(len(rows))+'종목 · KST09시'+(' · 시세 지연' if data.get('stale') else ' · 10초 갱신'))
    def choose(self,event=None):
        rows=self.table.selection()
        if not rows:return
        self.selected=rows[0];self.view.state['market_chart_symbol']=self.selected
        self.selection.set(self.selected.replace('-USDT-SWAP','/USDT')+' · '+(self.view.state.get('entry_gate') or {}).get('reason','진입 상태 확인 중'))
        self.chart.select(self.selected,next((p for p in self.view.positions if p['symbol']==self.selected),None));self.render()
    def order(self,side):
        from okx_direction732 import fresh
        if self.selected:self.view.callbacks.get('click_entry',lambda *a:None)(self.selected,side)

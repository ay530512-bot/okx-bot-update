"""Durable asynchronous Telegram outbox. Does not block exchange protection."""
import hashlib
import json
import logging
import queue
import threading
import time
import uuid
from pathlib import Path
from okx_daily_report import atomic_json, telegram

ALLOWED_EVENTS = frozenset(('AI 승인', '실거래 시작', '진입 체결', '부분 청산 확인', '청산 손익', 'AI 보유 판단', '모바일 운용 제어', 'AI 진입 대기', '진입 거절', '진입 대기 요약', '보호 오류'))


def allowed_pending(item):
    # Older outboxes did not store the event key. Match their exact header.
    key = item.get('event')
    if key is None:
        header = str(item.get('text', '')).split('\n', 1)[0]
        prefix = '[OKX v5.1] '
        key = header[len(prefix):] if header.startswith(prefix) else None
    return key in ALLOWED_EVENTS


class Notifier:
    def __init__(self,root,settings,c):
        self.path=Path(root)/'trade_notifications.json'; self.lock=threading.Lock()
        self.token=settings.get('TELEGRAM_BOT_TOKEN'); self.chat=settings.get('TELEGRAM_CHAT_ID')
        self.enabled=bool(c['notifications']['enabled'] and self.token and self.chat)
        self.identity=hashlib.sha256(f'{self.token}:{self.chat}'.encode()).hexdigest()
        self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {'identity':self.identity,'pending':[],'states':{}}
        if self.data['identity']!=self.identity: raise ValueError('텔레그램 대상 변경: 기존 알림 기록 확인 필요')
        self.data['pending'] = [p for p in self.data['pending'] if allowed_pending(p)]
        from okx_telegram_brief import brief,migrate_pending_label
        for item in self.data['pending']:
            migrate_pending_label(item)
            if not item['text'].startswith(('[진입]','[대기]','[보유중]','[진입 전 대기]','[거절]','[청산]')):item['text']=brief(item.get('event',''),item['text'])
        from okx_notification_digest import migrate
        migrate(self.data,time.time())
        atomic_json(self.path,self.data)
        self.on_success=None;self.on_failure=None
        self.repeat=c['notifications']['repeat_wait_seconds']; self.stop_event=threading.Event()
    def start(self):
        if self.enabled: threading.Thread(target=self.run,daemon=True,name='telegram-outbox').start()
    def emit(self,key,text,state=None):
        if not self.enabled or key not in ALLOWED_EVENTS: return
        try:
            from okx_telegram_brief import brief
            from okx_notification_digest import WAIT_EVENTS,add
            if key in WAIT_EVENTS:
                with self.lock:
                    add(self.data,key,text,time.time());self._flush_digest_locked(time.time());atomic_json(self.path,self.data)
            else:self._enqueue(key,brief(key,text),state)
        except Exception:
            # Notification persistence must not interrupt position protection.
            logging.getLogger(__name__).error('텔레그램 알림 기록 실패: 로컬 파일 권한을 확인하세요.')

    def _enqueue(self,key,text,state=None):
        with self.lock:
            prior=self.data['states'].get(key)
            if state is not None and prior and prior['value']==state: return
            self.data['states'][key]={'value':state,'time':time.time()}
            for offset in range(0,len(text),3000):
                item={'id':uuid.uuid4().hex,'event':key,'text':text[offset:offset+3000]}
                if key in ('진입 체결','부분 청산 확인','청산 손익','보호 오류'):
                    index=next((j for j,p in enumerate(self.data['pending']) if p.get('event') not in ('진입 체결','부분 청산 확인','청산 손익','보호 오류')),len(self.data['pending']))
                    self.data['pending'].insert(index,item)
                else:self.data['pending'].append(item)
            atomic_json(self.path,self.data)
    def _flush_digest_locked(self,now):
        from okx_notification_digest import flush
        text=flush(self.data,now)
        if text:
            self.data['pending']=[p for p in self.data['pending'] if p.get('event')!='진입 대기 요약']
            self.data['pending'].append({'id':uuid.uuid4().hex,'event':'진입 대기 요약','text':text})
            atomic_json(self.path,self.data)

    def run(self):
        import requests
        session=requests.Session()
        while not self.stop_event.is_set():
            with self.lock:
                self._flush_digest_locked(time.time())
                item=self.data['pending'][0] if self.data['pending'] else None
            if not item: self.stop_event.wait(1); continue
            try:
                telegram(session,self.token,'sendMessage',chat_id=self.chat,text=item['text'])
                if self.on_success:self.on_success()
                with self.lock:
                    self.data['pending']=[p for p in self.data['pending'] if p['id']!=item['id']]
                    atomic_json(self.path,self.data)
            except Exception:
                if self.on_failure:self.on_failure()
                # On ambiguous delivery retain message. A retry may duplicate it; never lose risk alerts silently.
                self.stop_event.wait(30)
        session.close()

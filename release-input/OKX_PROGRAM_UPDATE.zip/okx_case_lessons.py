"""Causal observations and user-labelled chart guidance, not trained model weights."""
import statistics
GUIDANCE='''User chart preference revision661 (examples, not performance evidence):
AKE15m and WET1H: an upper-band excursion with a pronounced upper wick and close back inside near resistance is a SHORT candidate; a lower-band sweep with lower wick and close recovery near support is a LONG candidate. The exact extreme is unknowable in advance. A wick is known only when formed; use closed-bar recovery, not a hoped-for future rebound.
CT15m: rising-average pullback, no meaningful loss of the prior swing low, a base and recovered closes can justify LONG before a later breakout candle. Repeated upper-band/high rejection or a lower retest high can justify SHORT. Do not treat all moving averages or all timeframes as mandatory AND gates. Mirror long support for short resistance.
CT historical base and PIEVERSE1H: evaluate the sequence sweep -> base -> failed downside retest -> higher lows/MA reclaim, then breakout -> pullback -> hold. One candle alone misses this structure. Do not infer the later rally from these retrospective screenshots or memorize their symbols/prices. Use only supplied observations available now.
AEON timing correction: never buy solely because price is falling into the lower band. For a rejection LONG, first require observable downside rejection (lower wick with recovered close, or a failed low retest followed by recovery); for a support LONG, require a base/held low and recovery. If still making lower lows with closes near lows and no recovery, WAIT for a named observable recovery level. A later breakout of the recovery candle high is optional, not universally required. No extra waiting is required solely because 4H is bearish when a lower-timeframe reversal already has a clear invalidation and plausible net target. Mirror for premature shorts into rising prices.
1INCH5m support/reversal timing correction (user screenshot, no exact cursor timestamp available): prioritize the sequence sell-off or low sweep -> recovered closes -> pullback/base that holds above the first low -> price reclaim/support at a selected moving average. The first observable recovery from that held pullback is an entry candidate; do not universally wait for a later breakout of the whole range or a large upper-band extension. A single green candle or MA touch is insufficient without the preceding structure. The new sequence_support_long/sequence_resistance_short evidence includes first extreme, intermediate move, retest, held level, recovery close, specific MA and extension in ATR units. A positive reversal_held flag means a local low/high structure reversed, not proof that the entire higher-timeframe trend reversed. A trend_pullback_held flag describes existing directional MA support/resistance. Either may independently justify a thesis, not both required together. Use 15m/1H/4H for context rather than mandatory alignment. Mirror: rally/high sweep -> rejected closes -> rebound failing below the first high -> rejection beneath a selected MA is a SHORT candidate. At the actual current price reassess remaining reward and invalidation; if the move already ran far from the recovery, prefer a new held pullback instead of chasing an old screenshot location. Never add to or enter through a broken support/resistance thesis. Explain the first extreme, retest, selected MA, recovery and invalidation in Korean for this setup.
APR15m screenshot clarification: the lower circled consolidation illustrates a prior uptrend pullback/held-low recovery LONG family; the upper circled peak illustrates high rejection, an upper wick and pushed-down close SHORT family. Evaluate each at its own historical decision time. The later red candle is not evidence available at the earlier high; an active current red candle is not a confirmed close. The screenshot alone does not establish that the bot considered or rejected APR. Do not memorize this symbol or assume every volume spike reverses.
Additional independent OR setup revision661: volume surge plus a pronounced rejection wick. volume_wick.long_candidate means the same token/timeframe volume is at least the configurable multiple of its own prior20 completed bars, with a long lower wick and recovered close; short_candidate mirrors upper wick and pushed-down close. It does not require a Bollinger outside excursion and does not replace any prior setup or become an extra AND requirement for them. A near-zero baseline, absent volume, no close recovery, or both long opposing wicks is not this setup. Treat it as an entry candidate, not a forced trade: inspect preceding trend, held support/resistance, current entry location and executable costs. A large volume wick can also be absorption during continued trend; do not assume reversal without evaluating the observed rejection. Explain timeframe, volume multiple, wick/body/range ratio, recovered close, thesis and invalidation. Only completed candles label a confirmed candidate; forming wicks are not confirmation.
These are independent preferred setups (OR), not a single chain requiring every pattern. Distinguish reversal from band-walking trend continuation. Prioritize recent formed rejection/retest/pullback evidence over chasing an already extended move. Explain selected family, signal timeframe, wick/close recovery, preceding swing/base, invalidation and profit obstacles in Korean. If acting against preferred recovery evidence, explain the alternative observed thesis explicitly. For management assess whether that thesis still holds, tighten stops only favorably, and never add to an invalidated idea. Missing a perfect extreme is acceptable; never claim guaranteed profit or use future outcomes.'''
PARAMETERS=dict(wick_body=1.5,wick_fraction=.4,wick_atr=.25,close_recovery=.6,zone_atr=.5,sequence_lookback=36,sequence_min_gap=3,sequence_retest_bars=3,sequence_move_atr=.8,sequence_ma_tolerance_atr=.6,sequence_max_extension_atr=1.5,volume_wick_relative=2.0)
def observe(b,period=20,multiplier=2,params=None):
 p=dict(PARAMETERS,**(params or {}))
 if len(b)<max(period+15,40):return {}
 def atr(end):
  vals=[max(b[j][2]-b[j][3],abs(b[j][2]-b[j-1][4]),abs(b[j][3]-b[j-1][4])) for j in range(max(1,end-13),end+1)]
  return sum(vals)/len(vals)
 a=atr(len(b)-2)
 if a<=0:return {}
 tail=[]
 for j in range(len(b)-3,len(b)):
  r=b[j];cl=[x[4] for x in b[j-period+1:j+1]];mid=sum(cl)/period;sd=statistics.pstdev(cl);lower=mid-multiplier*sd;upper=mid+multiplier*sd
  span=r[2]-r[3];body=abs(r[4]-r[1]);lo=min(r[1],r[4])-r[3];hi=r[2]-max(r[1],r[4]);loc=(r[4]-r[3])/span if span else .5
  def long_enough(w):return w>=max(body*p['wick_body'],span*p['wick_fraction'],a*p['wick_atr']) and span>0
  tail.append(dict(ms=r[0],lower_wick_fraction=lo/span if span else 0,upper_wick_fraction=hi/span if span else 0,close_location=loc,lower_long=bool(long_enough(lo)),upper_long=bool(long_enough(hi)),lower_wick_body=lo/body if body else None,upper_wick_body=hi/body if body else None,
   lower_rejection=bool(r[3]<lower and r[4]>=lower and long_enough(lo) and loc>=p['close_recovery']),
   upper_rejection=bool(r[2]>upper and r[4]<=upper and long_enough(hi) and loc<=1-p['close_recovery'])))
 # Prior zones use history strictly before the most recent3 bars.
 prior=b[-23:-3];support=min(r[3] for r in prior);resistance=max(r[2] for r in prior);last=b[-1];previous=b[-2]
 recent_low=min(r[3] for r in b[-3:]);recent_high=max(r[2] for r in b[-3:]);tol=a*p['zone_atr']
 recovery=last[4]>previous[4] and last[4]>last[1];rejection=last[4]<previous[4] and last[4]<last[1]
 failed_low=recent_low<=support+tol and last[4]>support+tol and recovery
 failed_high=recent_high>=resistance-tol and last[4]<resistance-tol and rejection
 ma20=sum(r[4] for r in b[-20:])/20;oldma=sum(r[4] for r in b[-23:-3])/20
 holding_low=recent_low>=support-tol
 holding_high=recent_high<=resistance+tol
 pull_long=ma20>oldma and holding_low and min(abs(r[3]-sum(x[4] for x in b[j-19:j+1])/20) for j,r in [(len(b)-k,b[-k]) for k in (1,2,3)])<=tol and recovery
 pull_short=ma20<oldma and holding_high and min(abs(r[2]-sum(x[4] for x in b[j-19:j+1])/20) for j,r in [(len(b)-k,b[-k]) for k in (1,2,3)])<=tol and rejection
 pivots=[]
 for j in range(max(2,len(b)-60),len(b)-1):
  for kind,index,compare in [('low',3,min),('high',2,max)]:
   if b[j][index]==compare(x[index] for x in b[j-2:j+2]):pivots.append(dict(kind=kind,price=b[j][index],at=b[j][0],confirmed_by_bar=b[j+1][0]))
 mean_volume=sum(x[5] for x in b[-21:-1])/20
 vol_ratio=last[5]/mean_volume if mean_volume>0 else None
 wick=tail[-1];surge=bool(vol_ratio is not None and vol_ratio>=p['volume_wick_relative'] and last[5]>0)
 volume_wick=dict(relative_volume=vol_ratio,baseline_bars=20,baseline_mean=mean_volume,threshold=p['volume_wick_relative'],signal_ms=last[0],long_candidate=bool(surge and wick['lower_long'] and not wick['upper_long'] and wick['close_location']>=p['close_recovery']),short_candidate=bool(surge and wick['upper_long'] and not wick['lower_long'] and wick['close_location']<=1-p['close_recovery']))
 return dict(volume_wick=volume_wick,sequence_support_long=sequence_setup(b,a,p,1),sequence_resistance_short=sequence_setup(b,a,p,-1),lookback_bars=min(len(b),60),atr_reference=a,prior_support=support,prior_resistance=resistance,ma20_slope_atr=(ma20-oldma)/a,
  candles=tail,failed_low_recovery=bool(failed_low),failed_high_rejection=bool(failed_high),support_pullback_recovery=bool(pull_long),resistance_pullback_rejection=bool(pull_short),
  falling_without_recovery=bool(last[3]<previous[3] and not recovery and tail[-1]['close_location']<.4),
  rising_without_rejection=bool(last[2]>previous[2] and not rejection and tail[-1]['close_location']>.6),
  recent_extremes=[dict(high=max(r[2] for r in part),low=min(r[3] for r in part)) for part in (b[-30:-20],b[-20:-10],b[-10:])],confirmed_pivots=pivots[-4:])


def sequence_setup(b,atr,p,direction):
 """Completed-bar, mirrored multi-candle observation; not an order trigger."""
 if len(b)<40 or atr<=0:return {}
 # Transform shorts into the same increasing-price geometry as longs.
 q=[(r[0],direction*r[1],r[2] if direction==1 else -r[3],r[3] if direction==1 else -r[2],direction*r[4]) for r in b]
 n=len(q);last=q[-1];zone=atr*p['zone_atr'];recent=int(p['sequence_retest_bars']);gap=int(p['sequence_min_gap']);look=int(p['sequence_lookback'])
 if recent<2 or gap<2 or look<recent+gap+3:return {}
 retest=q[-recent:];touch=min(x[3] for x in retest);recovered=last[4]>last[1] and last[4]>q[-2][4] and last[4]>touch+zone
 if not recovered:return {}
 earliest=max(2,n-look);stop=n-recent-gap+1
 if stop<=earliest:return {}
 first=min(range(earliest,stop),key=lambda j:q[j][3]);level=q[first][3]
 intermediate=q[first+1:n-recent]
 if len(intermediate)<gap-1:return {}
 bounce=max(x[2] for x in intermediate)-level
 held=touch>=level-zone and all(x[4]>level for x in retest)
 higher=touch>level+zone
 before=q[max(0,first-8):first];was_falling=len(before)>=3 and level<min(x[3] for x in before)-zone
 ma_choices=[]
 for period in (15,20,50,100,120,200):
  if n<period+3:continue
  current=sum(x[4] for x in q[-period:])/period;previous=sum(x[4] for x in q[-period-3:-3])/period
  touched=any(x[3]<=sum(v[4] for v in q[j-period+1:j+1])/period+atr*p['sequence_ma_tolerance_atr'] and x[2]>=sum(v[4] for v in q[j-period+1:j+1])/period-atr*p['sequence_ma_tolerance_atr'] for j,x in enumerate(q) if j>=n-recent)
  if touched and last[4]>=current and current>=previous-zone:
   ma_choices.append((abs(last[4]-current),period,current,current-previous))
 if not ma_choices:return {}
 _,period,ma,slope=min(ma_choices)
 extension=(last[4]-ma)/atr;near=extension<=p['sequence_max_extension_atr'];valid=held and bounce>=atr*p['sequence_move_atr'] and near
 def price(x):return direction*x
 return dict(reversal_held=bool(valid and was_falling and higher),trend_pullback_held=bool(valid and slope>0 and higher),first_extreme_ms=q[first][0],first_extreme=price(level),retest_start_ms=retest[0][0],retest_level=price(touch),recovery_ms=last[0],recovery_close=price(last[4]),holding_ma_period=period,holding_ma=price(ma),ma_slope_atr=direction*slope/atr,intermediate_move_atr=bounce/atr,extension_atr=extension,too_extended=not near,held_first_extreme=held,higher_low_or_lower_high=higher,invalidation_reference=price(touch-zone),description='확정 봉 다중 구조 관찰 · 주문/수익 보장 아님')

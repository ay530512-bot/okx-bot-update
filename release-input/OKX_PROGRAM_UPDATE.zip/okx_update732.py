"""GitHub Release updater. No exchange credentials or trading endpoints are used here.
Only a flat-account checkpoint in RuleEngine can initiate a restart.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
import uuid
import zipfile

PRODUCT = 'okx-732-desktop'
VERSION = '7.32-Q2P'
SEQUENCE = 7320216
ASSET = 'OKX_PROGRAM_UPDATE.zip'
MANIFEST = 'update_manifest.json'
MAX_ARCHIVE = 80 * 1024 * 1024
MAX_EXPANDED = 250 * 1024 * 1024
HOSTS = {'api.github.com', 'github.com', 'objects.githubusercontent.com',
         'release-assets.githubusercontent.com', 'github-releases.githubusercontent.com'}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')
    os.replace(tmp, path)


def repository(value):
    value = str(value).strip().removeprefix('https://github.com/').rstrip('/').removesuffix('.git')
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,99}/[A-Za-z0-9][A-Za-z0-9_.-]{0,99}', value):
        raise ValueError('GitHub 저장소를 소유자/저장소 형식으로 입력하세요.')
    return value


def allowed_path(name):
    if not isinstance(name, str) or '\\' in name or ':' in name or name.startswith('/'):
        return False
    p = PurePosixPath(name)
    if any(v in ('..', '.', '') or v.startswith('.') for v in p.parts): return False
    if name != str(p): return False
    if len(p.parts) == 1:
        return (name.endswith('.py') or name.endswith('.bat') or
                name in ('requirements.txt', 'release_info.json')) and bool(re.fullmatch(r'[A-Za-z0-9_.-]+', name))
    return name in ('mobile_assets/app.js', 'mobile_assets/style.css', 'mobile_assets/index.html')


def checked_url(url):
    p = urllib.parse.urlsplit(url)
    if p.scheme != 'https' or p.hostname not in HOSTS or p.username or p.password or p.port not in (None, 443):
        raise ValueError('GitHub 공식 HTTPS 다운로드 주소만 허용합니다.')
    return url


class Redirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        checked_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch(url, limit):
    checked_url(url)
    req = urllib.request.Request(url, headers={'User-Agent':'OKX-Q2H-Updater', 'Accept':'application/vnd.github+json'})
    with urllib.request.build_opener(Redirects()).open(req, timeout=25) as response:
        checked_url(response.url)
        chunks = []; size = 0
        while True:
            data = response.read(min(1024*1024, limit-size+1))
            if not data: break
            size += len(data)
            if size > limit: raise ValueError('업데이트 파일 크기 한도를 초과했습니다.')
            chunks.append(data)
        return b''.join(chunks)


def validate_manifest(m):
    if not isinstance(m, dict) or m.get('product') != PRODUCT or m.get('schema') != 1:
        raise ValueError('이 프로그램용 업데이트가 아닙니다.')
    if type(m.get('sequence')) is not int or m['sequence'] <= 0: raise ValueError('잘못된 버전 순번')
    if not re.fullmatch(r'[A-Za-z0-9.-]{1,40}', str(m.get('version', ''))): raise ValueError('잘못된 버전')
    if not re.fullmatch('[a-f0-9]{64}', str(m.get('sha256', ''))): raise ValueError('해시 누락')
    files = m.get('files')
    if not isinstance(files, dict) or not files or len(files)>500: raise ValueError('파일 목록 확인 실패')
    if not {'okx_bot.py','okx_update732.py','okx_mobile_assets718.py','release_info.json'} <= set(files):
        raise ValueError('필수 실행 파일 누락')
    folded = set()
    for name, h in files.items():
        if not allowed_path(name) or not re.fullmatch('[a-f0-9]{64}', str(h)) or name.lower() in folded:
            raise ValueError('허용하지 않는 파일 경로/중복/해시: '+str(name))
        folded.add(name.lower())
    return m


def stage_archive(archive, manifest, target):
    m=validate_manifest(manifest); archive=Path(archive); target=Path(target)
    if digest(archive)!=m['sha256']: raise ValueError('ZIP SHA256 불일치 · 설치하지 않았습니다.')
    with zipfile.ZipFile(archive) as z:
        infos=z.infolist()
        if len(infos)!=len(m['files']) or len({i.filename for i in infos})!=len(infos): raise ValueError('ZIP 파일 목록 불일치')
        if {i.filename for i in infos}!=set(m['files']): raise ValueError('ZIP 파일 목록 불일치')
        if sum(i.file_size for i in infos)>MAX_EXPANDED: raise ValueError('압축 해제 크기 초과')
        for i in infos:
            if not allowed_path(i.filename) or (i.external_attr>>16)&0o170000 == 0o120000: raise ValueError('링크/경로 차단')
        target.mkdir(parents=True,exist_ok=False)
        try:
            for i in infos:
                dst=target/i.filename; dst.parent.mkdir(parents=True,exist_ok=True)
                with z.open(i) as src, dst.open('wb') as out: shutil.copyfileobj(src,out)
                if digest(dst)!=m['files'][i.filename]: raise ValueError('파일 해시 불일치: '+i.filename)
            info=json.loads((target/'release_info.json').read_text(encoding='utf-8'))
            if info.get('sequence')!=m['sequence'] or info.get('version')!=m['version']: raise ValueError('내부 버전 불일치')
            for p in target.glob('*.py'): compile(p.read_text(encoding='utf-8-sig'),str(p),'exec')
        except Exception:
            shutil.rmtree(target,ignore_errors=True); raise
    return target


def release_metadata(root,repo,progress=lambda _:None):
    root=Path(root);repo=repository(repo)
    info_path=root/'release_info.json'
    current=json.loads(info_path.read_text(encoding='utf-8')) if info_path.exists() else {'sequence':SEQUENCE,'version':VERSION}
    progress('GitHub 최신 정식 릴리스 확인 중…')
    release=json.loads(fetch('https://api.github.com/repos/'+repo+'/releases/latest',2*1024*1024))
    if release.get('draft') or release.get('prerelease'): raise ValueError('정식 릴리스만 설치합니다.')
    assets={a['name']:a['browser_download_url'] for a in release.get('assets',[])}
    if not {MANIFEST,ASSET}<=set(assets): raise ValueError('릴리스에 ZIP과 update_manifest.json 두 파일이 필요합니다.')
    for name in (MANIFEST,ASSET):
        if not assets[name].startswith('https://github.com/'+repo+'/releases/download/'):
            raise ValueError('설정한 저장소 밖의 다운로드 차단')
    m=validate_manifest(json.loads(fetch(assets[MANIFEST],512*1024)))
    return m,assets,int(current['sequence'])


def check_download(root, repo, progress=lambda _:None):
    root=Path(root); repo=repository(repo)
    m,assets,current_sequence=release_metadata(root,repo,progress)
    if m['sequence']<=current_sequence:return None
    folder=root/'updates'/('download-'+uuid.uuid4().hex); folder.mkdir(parents=True)
    progress(m['version']+' 다운로드·무결성 검사 중…')
    archive=folder/ASSET; archive.write_bytes(fetch(assets[ASSET],MAX_ARCHIVE))
    stage_archive(archive,m,folder/'staged'); write_json(folder/MANIFEST,m)
    return str(folder)


def verify_staged(folder):
    folder=Path(folder); m=validate_manifest(json.loads((folder/MANIFEST).read_text(encoding='utf-8')))
    if digest(folder/ASSET)!=m['sha256']: raise ValueError('다운로드 ZIP 변경 감지')
    stage=folder/'staged'
    for name,h in m['files'].items():
        p=stage/name
        if p.is_symlink() or not p.is_file() or digest(p)!=h: raise ValueError('설치 파일 변경 감지')
    return m


def install(root, folder):
    """Called only after parent process exits. Restore every touched file on failure."""
    root=Path(root); folder=Path(folder); m=verify_staged(folder)
    backup=folder/'backup'; backup.mkdir(exist_ok=False); touched=[]
    try:
        for name in m['files']:
            dst=root/name
            if dst.is_symlink() or any(p.is_symlink() for p in dst.parents if p!=root.parent): raise ValueError('설치 경로 링크 차단')
            old=backup/name
            if dst.exists(): old.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(dst,old)
            touched.append((name,dst.exists()))
            dst.parent.mkdir(parents=True,exist_ok=True)
            temp=dst.with_name(dst.name+'.update-tmp'); shutil.copy2(folder/'staged'/name,temp); os.replace(temp,dst)
        write_json(folder/'touched.json',touched)
    except Exception:
        restore(root,folder,touched); raise
    return m


def restore(root,folder,touched=None):
    root=Path(root); folder=Path(folder)
    if touched is None: touched=json.loads((folder/'touched.json').read_text(encoding='utf-8'))
    for name,existed in reversed(touched):
        dst=root/name
        if existed: shutil.copy2(folder/'backup'/name,dst)
        else: dst.unlink(missing_ok=True)
        dst.with_name(dst.name+'.update-tmp').unlink(missing_ok=True)


def pid_alive(pid):
    if os.name=='nt':
        import ctypes
        k=ctypes.windll.kernel32
        k.OpenProcess.restype=ctypes.c_void_p
        handle=k.OpenProcess(0x100000,False,pid)
        if not handle: return False
        try: return k.WaitForSingleObject(ctypes.c_void_p(handle),0)==258
        finally: k.CloseHandle(ctypes.c_void_p(handle))
    try: os.kill(pid,0); return True
    except ProcessLookupError: return False


def worker(root,folder,pid):
    root=Path(root);folder=Path(folder);result=root/'update_result.json'
    try:
        deadline=time.monotonic()+90
        while pid_alive(pid):
            if time.monotonic()>deadline: raise RuntimeError('기존 프로그램이 종료되지 않아 설치를 취소했습니다.')
            time.sleep(.2)
        # Refuse to overwrite an independently launched trading instance.
        probe=socket.socket()
        try:
            probe.bind(('127.0.0.1',48736))
            m=install(root,folder)
        finally: probe.close()
        token=uuid.uuid4().hex
        env=dict(os.environ,OKX_UPDATE_HEALTH_TOKEN=token)
        child=subprocess.Popen([sys.executable,str(root/'okx_bot.py')],cwd=root,env=env)
        deadline=time.monotonic()+90;ok=False
        while time.monotonic()<deadline and child.poll() is None:
            try: ok=json.loads((root/'update_health.json').read_text(encoding='utf-8')).get('token')==token
            except (OSError,ValueError): pass
            if ok: break
            time.sleep(.25)
        if not ok:
            if child.poll() is None: child.terminate();child.wait(timeout=15)
            restore(root,folder)
            write_json(result,{'ok':False,'message':'새 화면 시작 확인 실패 · 이전 파일 복구. 기존 프로그램을 다시 실행하세요.'})
            return
        write_json(result,{'ok':True,'version':m['version'],'message':'업데이트 완료 · 계정/주문 대조 후 이전 운용 상태 복구'})
    except Exception as error:
        write_json(result,{'ok':False,'message':str(error)[:500]})


def launch_worker(root,folder):
    root=Path(root);folder=Path(folder);verify_staged(folder)
    copy=folder/'updater_running.py'; shutil.copy2(Path(__file__),copy)
    flags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0)|getattr(subprocess,'DETACHED_PROCESS',0)
    log=(folder/'update_worker.log').open('ab')
    try: return subprocess.Popen([sys.executable,str(copy),'--apply',str(root),str(folder),str(os.getpid())],
                                 cwd=root,creationflags=flags,stdin=subprocess.DEVNULL,stdout=log,stderr=log)
    finally: log.close()


def flat_checkpoint(engine):
    """Runs on the existing serialized engine thread. Does not submit/cancel orders."""
    from okx_core import dec
    records=engine.records()
    if records:
        return False,f'내부 보유/주문 추적 기록 {len(records)}건이 남아 있습니다. 계정 대조 완료 후 다시 업데이트하세요.'
    if engine.executing_signal:
        return False,'진입 주문 처리 중입니다. 처리 결과 확인 후 다시 업데이트하세요.'
    if engine.approval:
        return False,'진입 승인 처리가 남아 있습니다. 신규 진입 중지 후 처리 완료를 기다려 주세요.'
    # prepared_signal is cached analysis, not an in-flight order. It can survive
    # a completed/rejected entry. Real orders remain checked below on this
    # serialized engine thread; no journal records or exchange orders are cleared.
    snapshot=engine.api.snapshot()
    if snapshot['orders'] or any(dec(p.get('pos') or 0)!=0 for p in snapshot['positions']):
        return False,'실제 계정에 포지션/미체결 주문이 있습니다. 자동 청산하지 않고 설치를 보류합니다.'
    if engine.api.pending_algos(full=True):
        return False,'남은 조건주문이 있습니다. 계정에서 확인 후 업데이트를 다시 누르세요.'
    return True,''


class UpdateWindow:
    def __init__(self,app,root,engine):
        import tkinter as tk
        self.root=Path(root);self.engine=engine;self.app=app;self.folder=None;self.busy=False;self.messages=__import__('queue').Queue()
        self.win=tk.Toplevel(app);self.win.title('프로그램 업데이트');self.win.configure(bg='#000000');self.win.geometry('650x390')
        config=self.root/'update_settings.json'
        try: repo=json.loads(config.read_text(encoding='utf-8')).get('repository','')
        except (OSError,ValueError): repo=''
        self.repo=tk.StringVar(value=repo);self.status=tk.StringVar(value='현재 '+VERSION+' · 최초 한 번 GitHub 저장소를 입력하세요.')
        tk.Label(self.win,text='GITHUB 업데이트',bg='#000000',fg='#ff9f43',font=('',20,'bold')).pack(anchor='w',padx=24,pady=18)
        tk.Label(self.win,text='소유자/저장소 · 공개 Releases 사용',bg='#000000',fg='#eeeeee').pack(anchor='w',padx=24)
        tk.Entry(self.win,textvariable=self.repo,bg='#161616',fg='#ffffff',insertbackground='#ff9f43',font=('',14)).pack(fill='x',padx=24,pady=10)
        self.button=tk.Button(self.win,text='업데이트 확인·설치',command=self.start,bg='#9a4e13',fg='white',font=('',14,'bold'));self.button.pack(anchor='w',padx=24,pady=10)
        tk.Label(self.win,textvariable=self.status,wraplength=590,justify='left',bg='#000000',fg='#ff9f43').pack(anchor='w',padx=24,pady=12)
        tk.Label(self.win,text='보유·미체결 주문이 없을 때만 재시작합니다.\n계정 키·보유기록·모바일 주소·운용설정은 유지합니다.\n등록한 저장소의 코드가 설치됩니다. 본인이 관리하는 저장소를 사용하세요.',wraplength=590,justify='left',bg='#000000',fg='#bbbbbb').pack(anchor='w',padx=24)
        self.win.after(100,self.poll)
    def start(self):
        if self.busy:return
        try:
            repo=repository(self.repo.get());write_json(self.root/'update_settings.json',{'repository':repo})
        except Exception as e:self.status.set(str(e));return
        if getattr(self,'repo_used',repo)!=repo:self.folder=None
        self.busy=True;self.button.configure(state='disabled');self.repo_used=repo
        if self.folder:
            self.engine.send('update_restart',folder=self.folder);self.status.set('실제 포지션·미체결·조건주문 확인 중…');self.busy=False;self.button.configure(state='normal');return
        def download():
            try:self.messages.put(('done',check_download(self.root,repo,lambda t:self.messages.put(('status',t)))))
            except Exception as e:self.messages.put(('error','업데이트 확인 실패: '+str(e)[:250]))
        threading.Thread(target=download,daemon=True,name='release-download').start()
    def poll(self):
        if not self.win.winfo_exists():return
        while not self.messages.empty():
            kind,value=self.messages.get_nowait()
            if kind=='status':self.status.set(value)
            else:
                self.busy=False;self.button.configure(state='normal')
                if kind=='error':self.status.set(value)
                elif value:
                    self.folder=value;self.status.set('검사 완료 · 실제 계정이 비어 있는지 확인 중…');self.engine.send('update_restart',folder=value)
                else:self.status.set('이미 최신 버전입니다. 새 버전이 릴리스되면 이 버튼으로 설치할 수 있습니다.')
        self.win.after(100,self.poll)


if __name__=='__main__' and len(sys.argv)==5 and sys.argv[1]=='--apply':
    worker(sys.argv[2],sys.argv[3],int(sys.argv[4]))


def check_notice(root):
    """Read-only release check: never download ZIP, stage, or install."""
    root=Path(root)
    try:config=json.loads((root/'update_settings.json').read_text(encoding='utf-8'))
    except FileNotFoundError:return dict(available=False,version='',message='GitHub 저장소 미설정')
    repo=repository(config.get('repository',''))
    manifest,_,current=release_metadata(root,repo)
    available=manifest['sequence']>current
    return dict(available=available,version=manifest['version'],repository=repo,
                message=('새 업데이트 '+manifest['version']+' · 업데이트하세요') if available else '최신 버전입니다.',
                checked_ms=int(time.time()*1000))

class UpdateNotice:
    def __init__(self,root,events):
        self.root=root;self.events=events;self.closed=threading.Event()
        self.thread=threading.Thread(target=self.run,daemon=True,name='release-notice')
    def start(self):self.thread.start()
    def stop(self):self.closed.set()
    def run(self):
        last=dict(available=False,version='',message='업데이트 확인 중')
        while not self.closed.is_set():
            try:last=check_notice(self.root)
            except Exception:
                last=dict(last,error='업데이트 확인 지연 · 다음 조회에서 재시도합니다.')
            if not self.closed.is_set():self.events.put(('update_notice',dict(last)))
            self.closed.wait(300 if last.get('checked_ms') else 30)

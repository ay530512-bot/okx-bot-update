"""Native Tk dashboard presentation. No exchange, AI or order API calls."""
from collections import deque
from datetime import datetime,timedelta,timezone
import math
import time
import tkinter as tk
from tkinter import font as tkfont,ttk

KST=timezone(timedelta(hours=9))
from okx_ui_theme import BG,PANEL,INNER,BORDER,TEXT,MUTED,GREEN,RED,AMBER,ACCENT,PRIMARY_BG,HOVER,apply_theme


def numeric(value):
    try:
        value=float(value)
        return value if math.isfinite(value) else None
    except (TypeError,ValueError):return None


def money(value,precision=2,signed=False):
    n=numeric(value)
    return '—' if n is None else format(n,('+' if signed else '')+',.'+str(precision)+'f')


def position_view(position):
    """Return only display fields; never expose account IDs, API keys or client order IDs."""
    side=position.get('direction','long');roe=numeric(position.get('roe'))
    return dict(target=numeric(position.get('target')),symbol=str(position.get('symbol','')).replace('-USDT-SWAP','/USDT'),
        side=side,leverage=position.get('leverage'),margin=numeric(position.get('margin')),margin_basis=str(position.get('margin_basis') or '미확인'),roe=roe,pnl=numeric(position.get('pnl')),source=position.get('source','auto'),
        entry=numeric(position.get('entry')),mark=numeric(position.get('mark')),stop=numeric(position.get('stop')),
        phase=position.get('phase','확인 중'),protected=bool(position.get('protected')),
        quantity=position.get('quantity'),reason=str(position.get('reason') or '보유 상태 확인 중'))


class RoundedButton(tk.Canvas):
    def __init__(self,master,text,command,width=180,kind='normal',**kwargs):
        super().__init__(master,width=width,height=44,bg=BG,highlightthickness=0,takefocus=True,**kwargs)
        self.label=text;self.command=command;self.kind=kind;self.enabled=True;self.hover=False
        self.bind('<Configure>',lambda e:self.draw());self.bind('<Enter>',lambda e:self.highlight(True));self.bind('<Leave>',lambda e:self.highlight(False))
        self.bind('<Button-1>',lambda e:self.invoke());self.bind('<Return>',lambda e:self.invoke());self.bind('<space>',lambda e:self.invoke())
        self.bind('<FocusIn>',lambda e:self.draw());self.bind('<FocusOut>',lambda e:self.draw())
        self.draw()
    def highlight(self,active):self.hover=active;self.configure(cursor='hand2' if self.enabled else '');self.draw()
    def set_enabled(self,enabled):self.enabled=bool(enabled);self.draw()
    def invoke(self):
        if self.enabled:self.command()
    def draw(self):
        self.delete('all');w=max(self.winfo_width(),int(self['width']));h=44
        fill=PRIMARY_BG if self.kind=='primary' else GREEN if self.kind=='long' else RED if self.kind=='short' else PANEL
        fg=BG if self.kind=='primary' else RED if self.kind=='danger' else TEXT
        stroke='#613044' if self.kind=='danger' else PRIMARY_BG if self.kind=='primary' else BORDER
        if self.hover and self.enabled:fill='#d6ff86' if self.kind=='primary' else '#60b46a' if self.kind=='long' else '#cc5578' if self.kind=='short' else HOVER
        if not self.enabled:fill=INNER;fg='#7c8797';stroke=BORDER
        rounded(self,2,2,w-2,h-2,20,fill,stroke)
        if self.focus_get() is self:self.create_rectangle(6,6,w-6,h-6,outline=TEXT,dash=(2,3))
        self.create_text(w/2,h/2,text=self.label,fill=fg,font=('TkDefaultFont',-15,'bold'))


def rounded(canvas,x1,y1,x2,y2,r,fill,outline=BORDER):
    r=max(0,min(r,24,(x2-x1)/2,(y2-y1)/2))
    points=[x1+r,y1,x2-r,y1,x2,y1,x2,y1+r,x2,y2-r,x2,y2,x2-r,y2,x1+r,y2,x1,y2,x1,y2-r,x1,y1+r,x1,y1]
    return canvas.create_polygon(points,smooth=True,splinesteps=20,fill=fill,outline=outline,width=1)


class Dashboard(tk.Frame):
    def __init__(self,master,callbacks,demo=False):
        super().__init__(master,bg=BG);self.pack(fill='both',expand=True)
        families=set(tkfont.families(master))
        self.family=next((s for s in ('Pretendard','Pretendard Variable','Noto Sans KR','Malgun Gothic','Noto Sans CJK KR','Noto Sans CJK JP','NanumGothic','DejaVu Sans') if s in families),'TkDefaultFont')
        apply_theme(self,self.family)
        self.digits=next((s for s in ('Segoe UI Variable Display','Segoe UI','DejaVu Sans',self.family) if s in families),self.family)
        self.callbacks=callbacks;self.demo=demo;self.state={};self.positions=[];self.activities=deque(maxlen=300)
        self.decisions=deque(maxlen=4);self.histories={};self.header_hits=[];self.body_hits=[]
        self.chat_messages=[];self.chat_window=None;self.position_history_window=None;self.credit_window=None
        self.equity_points=[];self.chart_period=1
        from okx_coin_icons import CoinIcons
        self.coin_icons=CoinIcons(self)
        self.position_chart_key=None;self.position_chart_frame='15m';self.position_chart_data={};self.chart_anchor=None;self.chart_count=70;self.chart_price_zoom=1.0;self.chart_drag=None;self.chart_plot_bbox=None
        self.data_seen=0.;self.last_log='';self.status='계정 연결 확인 중 · 신규 진입 정지';self.pending=False;self.active_tab='대시보드'
        self.budget=tk.StringVar(value='6.00');self.hours=tk.StringVar(value='24')
        self.header=tk.Canvas(self,height=68,bg=BG,highlightthickness=0);self.header.pack(fill='x')
        self.footer=tk.Frame(self,bg=BG,height=78);self.footer.pack(side='bottom',fill='x');self.footer.pack_propagate(False)
        self.middle=tk.Frame(self,bg=BG);self.middle.pack(fill='both',expand=True)
        self.rail=tk.Canvas(self.middle,width=176,bg=BG,highlightthickness=0)
        self.workspace=tk.PanedWindow(self.middle,orient='horizontal',bg=BORDER,sashwidth=6,showhandle=False,bd=0);self.workspace.pack(fill='both',expand=True)
        self.dashboard_pane=tk.Frame(self.workspace,bg=BG);self.chat_pane=tk.Frame(self.workspace,bg=BG,width=450)
        self.workspace.add(self.dashboard_pane,minsize=300,stretch='always');self.workspace.add(self.chat_pane,minsize=360,stretch='never',width=600)
        self.body_xscroll=ttk.Scrollbar(self.dashboard_pane,orient='horizontal');self.body_xscroll.pack(side='bottom',fill='x')
        self.scroll=ttk.Scrollbar(self.dashboard_pane,orient='vertical');self.scroll.pack(side='right',fill='y')
        self.body=tk.Canvas(self.dashboard_pane,bg=BG,highlightthickness=0,yscrollcommand=self.scroll.set,xscrollcommand=self.body_xscroll.set);self.body.pack(fill='both',expand=True)
        self.body_xscroll.configure(command=self.body.xview)
        self.scroll.configure(command=self.body.yview)
        for canvas in (self.header,self.body,self.rail):canvas.bind('<Configure>',lambda e:self.schedule())
        self.header.bind('<Button-1>',lambda e:self.click(e,self.header_hits))
        self.body.bind('<Button-1>',lambda e:self.click(e,self.body_hits,True))
        self.body.bind('<MouseWheel>',self.chart_wheel)
        self.body.bind('<ButtonPress-1>',self.chart_press,add='+')
        self.body.bind('<B1-Motion>',self.chart_motion)
        from okx_position_chart import hover_candle
        self.body.bind('<Motion>',lambda e:hover_candle(self,self.body,e))
        self.body.bind('<Leave>',lambda e:hover_candle(self,self.body))
        self.body.bind('<ButtonRelease-1>',lambda e:setattr(self,'chart_drag',None))
        self.body.bind('<Button-4>',lambda e:self.chart_wheel(e,1));self.body.bind('<Button-5>',lambda e:self.chart_wheel(e,-1))
        self.rail.bind('<Button-1>',self.rail_click)
        self.start=RoundedButton(self.footer,'▶  실거래 시작',callbacks['live'],kind='primary',width=190);self.start.pack(side='left',padx=(24,12),pady=16)
        self.pause=RoundedButton(self.footer,'Ⅱ  신규 진입 중지',callbacks['pause'],width=180);self.pause.pack(side='left',padx=(0,12),pady=16)
        self.preview=RoundedButton(self.footer,'규칙 미리보기',callbacks['preview'],width=135);self.preview.pack(side='left',pady=16)
        self.close=RoundedButton(self.footer,'■ 전체 포지션 청산',callbacks['close'],kind='danger',width=160);self.close.pack(side='right',padx=24,pady=16)
        if demo:
            for button in (self.start,self.pause,self.preview,self.close):button.set_enabled(False)
        self._idle_id=None;self._paint_id=self.after(50,self.paint);self._age_id=self.after(1000,self.check_age)
        self.show_chat()
        from pathlib import Path
        from okx_ui_layout import LayoutController
        self.layout_controller=LayoutController(self.winfo_toplevel(),self.workspace,self.chat_window.split,Path(__file__).resolve().parent/'ui_layout.json')
    def check_age(self):
        if not self.winfo_exists():return
        if not self.demo and self.data_seen and time.monotonic()-self.data_seen>30:
            self.state['market_connected']=False;self.state['account_connected']=False
            self.status='데이터 갱신 지연 · 마지막 조회값입니다. 연결 상태를 확인하세요.';self.schedule()
        self.schedule()
        self._age_id=self.after(1000,self.check_age)
    def destroy(self):
        if hasattr(self,'layout_controller'):self.layout_controller.close()
        if self.chat_window:self.chat_window.close()
        if self.position_history_window:self.position_history_window.close()
        if self.credit_window:self.credit_window.close()
        self.callbacks={};self.header_hits=[];self.body_hits=[]
        for button in (self.start,self.pause,self.preview,self.close):button.command=lambda:None
        for key in ('_idle_id','_paint_id','_age_id'):
            value=getattr(self,key,None)
            if value:
                try:self.after_cancel(value)
                except tk.TclError:pass
        super().destroy()
        self.budget=None;self.hours=None # Release Tcl variables on the UI thread.
    def schedule(self):
        if not self.pending:self.pending=True;self._idle_id=self.after_idle(self.paint)
    def display_size(self,size):return max(12,round(size*1.04))
    def text(self,canvas,x,y,text,size=14,color=TEXT,bold=False,anchor='nw',width=None,digits=False):
        args=dict(text=str(text),fill=color,anchor=anchor,font=(self.digits if digits else self.family,-self.display_size(size),'bold' if bold else 'normal'))
        if width:args['width']=width
        return canvas.create_text(x,y,**args)
    def elide(self,text,width,size=12):
        text=str(text).replace('\n',' ');font=tkfont.Font(family=self.family,size=-self.display_size(size))
        if font.measure(text)<=width:return text
        while text and font.measure(text+'…')>width:text=text[:-1]
        return text+'…'
    def fit(self,canvas,x,y,text,maxwidth,size=28,color=TEXT):
        while size>15 and tkfont.Font(family=self.digits,size=-self.display_size(size),weight='bold').measure(text)>maxwidth:size-=1
        self.text(canvas,x,y,text,size,color,True,digits=True)
    def badge(self,c,x,y,label,color=GREEN,fill='#25301b'):
        width=tkfont.Font(family=self.family,size=-self.display_size(12)).measure(label)+22
        rounded(c,x,y,x+width,y+26,6,fill,fill);self.text(c,x+11,y+5,label,12,color,True)
        return width
    def line(self,c,x1,y1,x2,y2,color=BORDER):c.create_line(x1,y1,x2,y2,fill=color)
    def icon(self,c,kind,x,y,color=MUTED):
        if kind=='grid':
            for a,b in ((0,0),(11,0),(0,11),(11,11)):c.create_rectangle(x+a,y+b,x+a+7,y+b+7,fill=color,outline=color)
        elif kind=='chart':
            for a,h in ((0,9),(7,16),(14,22)):c.create_rectangle(x+a,y+22-h,x+a+3,y+22,fill=color,outline=color)
        elif kind=='settings':
            c.create_oval(x,y,x+20,y+20,outline=color,width=2);c.create_oval(x+6,y+6,x+14,y+14,outline=color,width=2)
        else:
            rounded(c,x,y,x+18,y+21,3,BG,color)
            for offset in (6,11,16):self.line(c,x+4,y+offset,x+14,y+offset,color)
    def click(self,event,hits,body=False):
        x=self.body.canvasx(event.x) if body else event.x;y=self.body.canvasy(event.y) if body else event.y
        for x1,y1,x2,y2,command in hits:
            if x1<=x<=x2 and y1<=y<=y2:command();break
    def rail_click(self,event):
        if 30<=event.y<=95:self.active_tab='대시보드';self.body.yview_moveto(0)
        elif 115<=event.y<=185:self.callbacks['history']()
        elif 205<=event.y<=270:self.callbacks['settings']()
        elif 285<=event.y<=370:self.show_chat()
        self.schedule()
    def paint(self):
        self.pending=False
        if not self.winfo_exists():return
        self.paint_header();self.paint_rail();self.paint_body()
    def paint_header(self):
        c=self.header;c.delete('all');w=max(c.winfo_width(),1020);self.header_hits=[]
        self.icon(c,'grid',25,24,TEXT);self.text(c,80,20,getattr(self,'exchange_label','OKX')+' 트레이딩',22,TEXT,True)
        for x,label,key in ((275,'대시보드','dashboard'),(390,'매매 기록','history'),(505,'설정','settings'),(590,'선물 종목','chat')):
            if key=='chat' and w<1240:continue
            self.text(c,x,26,label,14,ACCENT if key=='dashboard' else MUTED,key=='dashboard')
            command=self.schedule if key=='dashboard' else self.show_chat if key=='chat' else self.callbacks[key]
            self.header_hits.append((x-8,16,x+85,55,command))
        self.line(c,275,64,343,64,ACCENT)
        # Connection labels reflect actual runtime state, not a decorative successful connection.
        x=w-415
        market=self.state.get('market_connected',False);account=self.state.get('account_connected',False)
        self.badge(c,x,21,'● '+getattr(self,'exchange_label','OKX')+' '+('연결' if market and account else '확인 중'),GREEN if market and account else AMBER,'#25301b')
        tg=self.state.get('telegram',{}).get('status')
        self.badge(c,x+133,21,'TG '+('전송 확인' if tg=='verified' else '미확인'),GREEN if tg=='verified' else MUTED,'#161616')
        label='미리보기' if self.state.get('preview') else ('실거래 확인 중' if self.state.get('live') and (self.state.get('recovering') or not (market and account)) else '실거래 가동' if self.state.get('live') else '신규 진입 정지')
        ready=bool(self.state.get('live') and not self.state.get('preview') and not self.state.get('recovering') and not self.state.get('ended') and market and account)
        self.badge(c,w-143,21,'예시 데이터' if self.demo else label,GREEN if ready and not self.demo else AMBER,'#25301b' if ready else '#352d21')
        self.line(c,0,67,w,67)
    def paint_rail(self):
        c=self.rail;c.delete('all');self.line(c,175,0,175,max(c.winfo_height(),800))
        rounded(c,9,20,165,85,4,'#161616','#333333')
        for y,icon,label in ((40,'grid','대시보드'),(142,'chart','매매 기록'),(242,'settings','설정'),(337,'chart','선물 종목')):
            color=ACCENT if label=='대시보드' else MUTED
            self.icon(c,icon,23,y,color);self.text(c,57,y+2,label,14,color,label=='대시보드')
        self.text(c,24,430,'v7.32',11,MUTED)
    def running_state(self):
        if self.demo:return '디자인 미리보기 · 예시 데이터',MUTED
        if self.state.get('preview'):return '규칙 미리보기 · 주문 없음',MUTED
        if self.state.get('ended'):return '당일 거래 중단 · 보유 정리 확인',AMBER
        if self.state.get('resume_pending'):
            return '자동 재개 대기 · '+str(self.state.get('pause_reason') or '계정·주문·SL 확인 중'),AMBER
        if self.state.get('live'):
            if self.state.get('recovering') or not (self.state.get('market_connected') and self.state.get('account_connected')):
                return '재연결·계정 확인 중',AMBER
            return '실거래 가동 중',GREEN
        return (str(self.state['pause_reason']) if self.state.get('pause_reason') else '신규 진입 중지 · 보유 포지션 관리 중' if self.positions else '실거래 시작 전 · 신규 진입 정지'),MUTED

    def paint_body(self):
        c=self.body;c.delete('all');w=max(c.winfo_width(),810);self.body_hits=[];pad=24;gap=14;content=w-2*pad
        label,color=self.running_state()
        self.text(c,pad,13,'오늘의 트레이딩',25,TEXT,True)
        self.badge(c,pad+260,14,label,color,fill='#25301b' if color==GREEN else INNER)
        self.small_action(c,w-pad-160,7,160,'프로그램 업데이트','update')
        notice=getattr(self,'update_notice',{})
        if notice.get('available'):
            self.text(c,w-pad,37,'새 업데이트 '+str(notice.get('version',''))+' · 업데이트하세요',10,'#ff5252',True,anchor='ne')
        rounded(c,pad,55,w-pad,91,8,PANEL)
        connected=self.state.get('market_connected') and self.state.get('account_connected')
        self.text(c,pad+12,64,'● '+getattr(self,'exchange_label','OKX')+' '+('연결됨' if connected else '확인 중'),11,GREEN if connected else AMBER,True)
        self.small_action(c,pad+125,57,120,'↻ '+getattr(self,'exchange_label','OKX')+' 재연결','reconnect')
        tg=self.state.get('telegram',{});ts=tg.get('status','unverified' if self.state.get('telegram_configured') else 'missing')
        self.text(c,pad+270,64,'텔레그램 '+{'verified':'전송 확인','checking':'확인 중','failed':'전송 실패','missing':'미설정','unverified':'미확인'}.get(ts,'미확인'),11,GREEN if ts=='verified' else MUTED,True)
        self.small_action(c,w-pad-315,57,120,'휴대폰 조회','mobile_view')
        self.small_action(c,w-pad-183,57,175,'텔레그램 연결·테스트','telegram_test')
        cardwidth=(content-3*gap)/4;top=103
        profit=numeric(self.state.get('day_profit'));roi=numeric(self.state.get('roi'))
        values=[('총자산',money(self.state.get('equity'))+' USDT',TEXT),('오늘 손익',money(profit,signed=True)+' USDT',GREEN if profit is not None and profit>=0 else RED),('가용 잔고',money(self.state.get('available'))+' USDT',TEXT),('과거 AI 비용 · 신규 호출 없음','$'+money(self.state.get('api_spent'),3),TEXT)]
        for idx,(title,value,fg) in enumerate(values):
            xx=pad+idx*(cardwidth+gap);rounded(c,xx,top,xx+cardwidth,top+78,9,PANEL)
            self.text(c,xx+14,top+10,title,11,MUTED)
            self.fit(c,xx+14,top+35,value,cardwidth-28,23,fg)
            if idx==3:self.small_action(c,xx+cardwidth-99,top+6,89,'충전/잔액',self.show_api_credit)
        risk=self.state.get('daily_risk',{})
        from okx_day_status import lines as day_lines
        risk_lines=day_lines(risk) if risk else ['일일 기준·이체 장부 확인 대기']
        rounded(c,pad,194,w-pad,233,8,PANEL)
        from okx_daily_goal728 import goal_line
        goal_text=goal_line(risk.get('goal'))
        if not self.data_seen or time.monotonic()-self.data_seen>30:goal_text='자료 지연 · '+goal_text
        self.text(c,pad+14,204,self.elide(goal_text,content-125,10),10,MUTED)
        self.small_action(c,w-pad-101,198,90,'일일 상세','history')
        py=246;left=content;right=content;rx=pad;rows=max(1,len(self.positions));height=124+rows*43
        rounded(c,pad,py,pad+left,py+height,10,PANEL)
        self.text(c,pad+18,py+18,'보유 포지션 · '+str(len(self.positions))+'개',17,TEXT,True)
        self.text(c,pad+left-18,py+22,'상세 보기 ›',11,MUTED,anchor='ne')
        self.body_hits.append((pad+left-105,py+10,pad+left-10,py+45,self.callbacks['positions']))
        self.small_action(c,pad+left-310,py+12,180,'이전 포지션 내역',self.show_position_history)
        today=self.state.get('position_history_days',{}).get(datetime.now(KST).strftime('%Y-%m-%d'))
        summary=(today or {}).get('summary',{})
        self.text(c,pad+18,py+51,'당일 확정 손익',11,MUTED)
        for fraction,label,field in ((.22,'수동','manual'),(.43,'자동','auto'),(.64,'합산','total')):
            value=numeric(summary.get(field));fg=GREEN if value is not None and value>0 else RED if value is not None and value<0 else MUTED
            self.text(c,pad+left*fraction,py+51,label+' '+money(value,signed=True)+' USDT',11,fg,True)
        note='한국시간 청산일 기준'
        if not today:note+=' · 내역 조회 대기'
        elif today.get('loading'):note+=' · 조회 중'
        elif today.get('error'):note+=' · 캐시/일부 내역'
        if today and today.get('unknown_count'):note+=' · 미분류 '+money(summary.get('unknown'),signed=True)+' USDT 포함'
        self.text(c,pad+18,py+75,note,10,MUTED,width=left-36)
        fractions=(.02,.165,.23,.32,.41,.51,.62,.72,.82);cols=[pad+left*f for f in fractions]
        for x,title in zip(cols,('종목','구분','방향·배율','진입가','현재가','증거금(USDT)','ROE','손익(USDT)','보호 SL')):self.text(c,x,py+96,title,10,MUTED)
        for idx,raw in enumerate(self.positions):
            p=position_view(raw);yy=py+124+idx*43
            if raw.get('key',raw['symbol'])==self.position_chart_key:c.create_rectangle(pad+8,yy-7,pad+left-8,yy+32,fill='#25301b',outline='#43806a')
            self.line(c,pad+15,yy-9,pad+left-15,yy-9)
            self.coin_icons.draw(c,cols[0]+14,yy+10,raw['symbol'])
            values=(p['symbol'],'수동' if p['source']=='manual' else '자동',('롱' if p['side']=='long' else '숏')+' '+str(p['leverage'])+'x',self.price(p['entry']),self.price(p['mark']),money(p['margin']),money(None if p['roe'] is None else p['roe']*100,signed=True)+'%',money(p['pnl'],signed=True),('외부 관리' if p['source']=='manual' else '확인됨' if p['protected'] else '확인 중'))
            for j,(x,value) in enumerate(zip(cols,values)):
                fg=TEXT
                if j==1 and p['source']=='manual':fg=AMBER
                elif j==2:fg=GREEN if p['side']=='long' else RED
                elif j in (6,7):
                    amount=p['roe'] if j==6 else p['pnl']
                    fg=GREEN if amount is not None and amount>0 else RED if amount is not None and amount<0 else TEXT
                elif j==8 and p['protected']:fg=GREEN
                if j==0:x+=35
                self.text(c,x,yy,self.elide(value,left*(.155 if j==0 else .065 if j==1 else .095 if j==2 else .10 if j in (3,4,7) else .11 if j in (5,6) else .075)-6,11),11,fg,j in (0,5,6,7))
            if raw.get('close_key') and not self.demo:
                self.small_action(c,pad+left*.92,yy-4,max(45,left*.065),'청산',lambda r=dict(raw):self.callbacks.get('close_one',lambda *a:None)(r))
            self.body_hits.append((pad+12,yy-8,pad+left-12,yy+31,lambda key=raw.get('key',raw['symbol']):self.select_position_chart(key)))
        if not self.positions:self.text(c,pad+left/2,py+135,'보유 포지션이 없습니다 · 진입하면 차트가 표시됩니다',13,MUTED,anchor='center')
        py+=height+gap
        py=self.paint_movers(c,pad,py,content)+gap
        activity_height=218;activity_bg=rounded(c,rx,py,rx+right,py+activity_height,10,PANEL)
        self.text(c,rx+18,py+18,'최근 활동',17,TEXT,True)
        self.body_hits.append((rx+10,py+10,rx+right-10,py+46,self.callbacks['history']))
        review=self.state.get('review_activity',{});review_rows=review.get('items',[])
        names=', '.join(r['symbol'].replace('-USDT-SWAP','/USDT') for r in review_rows)
        yy=py+59
        if names:
            item=self.text(c,rx+18,yy,review.get('stage','검토')+' · '+names,13,GREEN,True,width=max(100,right-36))
            box=c.bbox(item);yy=(box[3] if box else yy+24)+18
        for stamp,text,fg in list(self.activities)[:3]:
            self.text(c,rx+18,yy,stamp,10,MUTED)
            item=self.text(c,rx+18,yy+25,text,12,fg,width=max(100,right-36))
            box=c.bbox(item);end=box[3] if box else yy+50
            self.body_hits.append((rx+12,yy,rx+right-12,end+10,lambda t=text,s=stamp:self.show_activity(s,t)))
            yy=end+24
        activity_height=max(activity_height,yy-py+6)
        c.delete(activity_bg);activity_bg=rounded(c,rx,py,rx+right,py+activity_height,10,PANEL);c.tag_lower(activity_bg)
        y=py+activity_height+20;left=(content-gap)*.65;right=content-gap-left;rx=pad+left+gap
        rounded(c,pad,y,pad+left,y+267,10,PANEL)
        self.text(c,pad+18,y+18,'자산 흐름',18,TEXT,True)
        for idx,(period,title) in enumerate(((1,'오늘'),(7,'7일'),(30,'30일'))):
            x=pad+left-167+idx*50
            self.small_action(c,x,y+12,46,title,lambda p=period:self.change_period(p),selected=self.chart_period==period)
        self.draw_equity(c,pad+52,y+66,left-77,140)
        self.text(c,pad+18,y+242,'실제 계정 조회 이력 · 입출금 포함 · '+('예시 데이터' if self.demo else '5분 간격 저장'),10,MUTED)
        rounded(c,rx,y,rx+right,y+267,10,PANEL);self.text(c,rx+18,y+18,'시간봉별 분석',17,TEXT,True)
        tf=self.state.get('timeframes',{});frame_data=tf.get('frames',{})
        self.text(c,rx+18,y+46,self.elide(tf.get('symbol','분석 데이터 대기').replace('-USDT-SWAP','/USDT'),right-35,10),10,MUTED)
        names={'15m':'15분','1H':'1시간','4H':'4시간'}
        trends={'uptrend':'상승 추세','downtrend':'하락 추세','range':'횡보','unclear':'불명확','unknown':'이력/연결 대기'}
        for idx,(frame,name) in enumerate(names.items()):
            yy=y+76+idx*34;row=frame_data.get(frame,{})
            self.text(c,rx+18,yy,name,12,TEXT,True)
            trend=row.get('trend','unknown');fg=GREEN if trend=='uptrend' else RED if trend=='downtrend' else MUTED
            self.text(c,rx+right-18,yy,self.elide(trends.get(trend,trend)+(' / RSI '+str(round(row['rsi14'],1)) if row.get('rsi14') is not None else '')+(' / 거래량 '+str(round(row['relative_volume'],2))+'배' if row.get('relative_volume') is not None else ''),right-82,11),11,fg,anchor='ne')
            if idx<4:self.line(c,rx+18,yy+24,rx+right-18,yy+24)
        bottom=y+286
        report=self.state.get('report_state',{})
        self.text(c,pad,bottom,self.elide(report.get('detail','일일 보고 00:10 KST · 텔레그램 상태를 확인하세요'),content-10,11),11,MUTED)
        self.text(c,pad,bottom+24,((('10월23일 네 전략 OR · 알트만 · 손익비1.1' if self.state['profile_name']=='OCT23' else '추세 눌림·확정 반전 · 수익성 검증 미통과 · 종목별 배율 · 3 USDT 제외 · 증거금1/4 · 손실액은 SL 거리에 따라 변동 · 최대4개 · 6시간 종료 · 초기2ATR / +20% ROE 최초 절반청산 · 청산 후 재탐색 · AI 호출 없음') if self.state.get('profile_name') else 'v6.43 전체 USDT 선물 · 재상승/재하락 실패 · 밴드 꼬리/수급 지지·저항 · 최초⅓ · 5% 역행 추가 · 구조 SL 유지') if self.state.get('band_flow_profile') else '새 진입 3원칙: 수급 상위권 · 추세 눌림/돌파 재확인 · 손실액 기준 수량 / 최초 증거금1/3 상한'),10,MUTED)
        c.configure(scrollregion=(0,0,w,bottom+62))

    def selected_chart_position(self):
        return next((p for p in self.positions if p.get('key',p['symbol'])==self.position_chart_key),None)
    def select_position_chart(self,key):
        self.state.pop('market_chart_symbol',None)
        self.position_chart_key=key;self.chart_anchor=None;self.request_position_chart();self.schedule()
    def change_chart_frame(self,frame):
        self.position_chart_frame=frame;self.chart_anchor=None;self.request_position_chart();self.schedule()
    def request_position_chart(self):
        p=self.selected_chart_position()
        symbol=self.state.get('market_chart_symbol') or (p['symbol'] if p else None)
        if self.chat_window and self.chat_window.exists():self.chat_window.chart.select(symbol,next((x for x in self.positions if x['symbol']==symbol),None))
    def paint_movers(self,c,x,y,w):
        from okx_compact_chart import mover_groups
        groups=mover_groups(self.state.get('market_table',{}).get('rows',[]))
        rounded(c,x,y,x+w,y+112,10,PANEL)
        for j,(label,rows) in enumerate(zip(('상승권','하락권'),groups)):
            yy=y+16+j*49;color=GREEN if j==0 else RED
            self.text(c,x+12,yy,label,12,color,True)
            cw=max(50,(w-85)/5)
            for i,row in enumerate(rows):
                xx=x+78+i*cw
                value=row['symbol'].replace('-USDT-SWAP','')+' '+format(row['change']*100,'+.2f')+'%'
                self.text(c,xx,yy,self.elide(value,cw-8,11),11,color,True)
                from okx_mover_price import price_label
                self.text(c,xx,yy+19,self.elide(price_label(row.get('last')),cw-8,10),10,MUTED)
                self.body_hits.append((xx,yy-5,xx+cw-5,yy+30,lambda symbol=row['symbol']:self.open_symbol_chart(symbol)))
        return y+112
    def open_symbol_chart(self,symbol):
        from okx_compact_chart import CompactChart
        win=tk.Toplevel(self);win.title(symbol.replace('-USDT-SWAP','/USDT')+' · 차트');win.geometry('900x560');win.minsize(500,350)
        panel=CompactChart(win,self);panel.pack(fill='both',expand=True)
        position=next((p for p in self.positions if p['symbol']==symbol),None)
        panel.select(symbol,position)
    def chart_data(self):
        p=self.selected_chart_position();return self.position_chart_data.get((p['symbol'],self.position_chart_frame),{}) if p else {}
    def more_chart(self):
        p=self.selected_chart_position()
        if p and not self.chart_data().get('history_end'):self.callbacks.get('chart_older',lambda **kw:None)(symbol=p['symbol'],frame=self.position_chart_frame)
    def chart_latest(self):self.chart_anchor=None;self.request_position_chart();self.schedule()
    def pan_chart(self,delta):
        from okx_position_chart import window_bounds
        bars=self.chart_data().get('bars',[])
        if not bars:return
        start,end=window_bounds(bars,self.chart_anchor,self.chart_count)
        new=max(min(self.chart_count,len(bars)),min(len(bars),end+delta))
        self.chart_anchor=None if new==len(bars) else bars[new-1][0]
        if new-self.chart_count<5:self.more_chart()
        self.schedule()
    def zoom_chart(self,direction):
        self.chart_count=max(20,min(200,self.chart_count-10*direction));self.schedule()
    def zoom_chart_price(self,direction):
        self.chart_price_zoom=max(.5,min(4.0,self.chart_price_zoom*(1.2 if direction>0 else 1/1.2)));self.schedule()
    def reset_chart_price(self):
        self.chart_price_zoom=1.0;self.schedule()
    def chart_inside(self,event):
        x=self.body.canvasx(event.x);y=self.body.canvasy(event.y);b=self.chart_plot_bbox
        return bool(b and b[0]<=x<=b[2] and b[1]<=y<=b[3])
    def chart_press(self,event):
        if self.chart_inside(event):self.chart_drag=event.x
    def chart_motion(self,event):
        if self.chart_drag is None:return
        width=max(100,self.chart_plot_bbox[2]-self.chart_plot_bbox[0]);count=int((self.chart_drag-event.x)*self.chart_count/width)
        if count:self.pan_chart(count);self.chart_drag=event.x
    def chart_wheel(self,event,direction=None):
        direction=direction if direction is not None else (1 if event.delta>0 else -1)
        if self.chart_inside(event):self.zoom_chart(direction)
        else:self.body.yview_scroll(-3*direction,'units')
        return 'break'

    def paint_position_chart(self,c,x,y,w):
        from okx_position_chart import draw
        h=420;p=self.selected_chart_position();rounded(c,x,y,x+w,y+h+134,10,PANEL)
        self.chart_plot_bbox=(x+12,y+131,x+w-12,y+h+119)
        title=(p['symbol'].replace('-USDT-SWAP','/USDT')+' · '+('수동' if p.get('source')=='manual' else '자동')) if p else '보유 포지션'
        self.coin_icons.draw(c,x+29,y+28,p['symbol']) if p else None
        self.text(c,x+52,y+14,title+' · 차트',16,TEXT,True)
        for j,(frame,name) in enumerate((('5m','5분'),('15m','15분'),('1H','1시간'),('4H','4시간'))):
            self.small_action(c,x+w-300+j*70,y+9,64,name,lambda f=frame:self.change_chart_frame(f),selected=frame==self.position_chart_frame)
        data=self.position_chart_data.get((p['symbol'],self.position_chart_frame)) if p else None
        if data and not self.demo and time.monotonic()-data.get('_received_monotonic',0)>35:data=dict(data,stale=True)
        for j,(label,fn) in enumerate((('←',lambda:self.pan_chart(-20)),('→',lambda:self.pan_chart(20)),('＋',lambda:self.zoom_chart(1)),('－',lambda:self.zoom_chart(-1)),('최신',self.chart_latest),('이전 봉 더 보기',self.more_chart))):
            self.small_action(c,x+12+j*115,y+49,106,label,fn)
        if w>=1100:self.text(c,x+w-16,y+62,'좌우 드래그 · 휠 확대/축소',10,MUTED,anchor='ne')
        for j,(label,fn) in enumerate((('세로 ＋',lambda:self.zoom_chart_price(1)),('세로 －',lambda:self.zoom_chart_price(-1)),('세로 원래대로',self.reset_chart_price))):
            self.small_action(c,x+12+j*140,y+89,130,label,fn)
        self.text(c,x+440,y+104,f'세로 배율 {self.chart_price_zoom:.2f}×',10,MUTED)
        draw(self,c,x+12,y+131,w-24,h-12,p,data,self.position_chart_frame)
        if data and data.get('history_end'):self.text(c,x+16,y+h+118,'거래소가 제공하는 과거 데이터의 끝입니다',10,AMBER)
        return y+h+134

    def small_action(self,c,x,y,width,label,key,selected=False):
        enabled=not self.demo
        rounded(c,x,y,x+width,y+32,7,'#25301b' if selected else INNER,GREEN if selected else BORDER)
        self.text(c,x+width/2,y+16,label,11,TEXT if enabled else MUTED,selected,anchor='center')
        if enabled:
            callback=key if callable(key) else self.callbacks.get(key,lambda:None)
            self.body_hits.append((x,y,x+width,y+32,callback))
    def change_period(self,period):self.chart_period=period;self.schedule()
    def price(self,value):return money(value,2 if value is not None and abs(value)>=10 else 5)
    def draw_equity(self,c,x,y,width,height):
        now=time.time()*1000;start=(now+9*3600000)//86400000*86400000-9*3600000 if self.chart_period==1 else now-self.chart_period*86400000
        points=[p for p in self.equity_points if p[0]>=start and p[0]<=now]
        if len(points)<2:
            self.text(c,x+width/2,y+height/2,'자산 조회 이력을 수집하고 있습니다' if not self.demo else '예시 데이터',13,MUTED,anchor='center');return
        low=min(p[1] for p in points);high=max(p[1] for p in points);span=max(high-low,abs(high)*.001,.0001)
        low-=span*.12;high+=span*.12
        for i in range(4):
            yy=y+i*height/3;self.line(c,x,yy,x+width,yy,'#333333')
            self.text(c,x-8,yy,money(high-(high-low)*i/3,1),10,MUTED,anchor='e')
        t0=points[0][0];ts=max(points[-1][0]-t0,1);coords=[]
        for stamp,value in points:coords.extend((x+(stamp-t0)/ts*width,y+height-(value-low)/(high-low)*height))
        c.create_line(coords,fill=GREEN,width=2)
        for stamp,anchor,xx in ((points[0][0],'nw',x),(points[-1][0],'ne',x+width)):
            label=datetime.fromtimestamp(stamp/1000,KST).strftime('%H:%M' if self.chart_period==1 else '%m/%d')
            self.text(c,xx,y+height+10,label,10,MUTED,anchor=anchor)
    def position_card(self,c,x,y,w,raw):
        p=position_view(raw);color=GREEN if p['side']=='long' else RED
        rounded(c,x,y,x+w,y+137,9,INNER)
        c.create_oval(x+17,y+18,x+53,y+54,fill='#293542',outline='')
        self.text(c,x+35,y+36,p['symbol'][:1],20,TEXT,True,anchor='center')
        self.text(c,x+66,y+17,p['symbol'],17,TEXT,True)
        bw=self.badge(c,x+66,y+44,'LONG' if p['side']=='long' else 'SHORT',color,'#25301b' if p['side']=='long' else '#3c2630')
        self.text(c,x+76+bw,y+51,str(p['leverage'] or '—')+'x',12,MUTED,True)
        roex=x+w*.58;self.text(c,roex,y+17,'ROE',11,MUTED)
        value='—' if p['roe'] is None else f'{p["roe"]*100:+.2f}%'
        self.fit(c,roex,y+37,value,w*.38,25,GREEN if p['roe'] is not None and p['roe']>=0 else RED if p['roe'] is not None else TEXT)
        if w>650:
            points=list(self.histories.get(raw.get('key',p['symbol']),[]))[-30:]
            if len(points)>1:
                lower,upper=min(points),max(points);span=max(upper-lower,.00000001)
                xx=x+w-134;yy=y+47;coords=[]
                for i,n in enumerate(points):coords.extend((xx+i*110/max(1,len(points)-1),yy-(n-lower)/span*24))
                c.create_line(coords,fill=color,width=2,smooth=False)
        status='손절 확인' if p['protected'] else ('청산 확인 중' if p['phase']=='closing' else '보호 확인 중')
        self.text(c,x+67,y+68,'● '+status,10,GREEN if p['protected'] else AMBER)
        self.line(c,x+16,y+83,x+w-16,y+83)
        for idx,(label,value) in enumerate((('진입가',p['entry']),('현재가',p['mark']),('보호 SL',p['stop']))):
            xx=x+20+idx*(w-38)/3;self.text(c,xx,y+91,label,10,MUTED)
            precision=2 if value is not None and abs(value)>=10 else 4
            self.text(c,xx,y+109,money(value,precision),14,TEXT,True,digits=True)
        self.body_hits.append((x,y,x+w,y+137,self.callbacks['positions']))
    def receive(self,kind,value):
        if kind=='position_live':
            from okx_live_display732 import apply_position
            row=value.get('row',{});key=(row.get('instId'),row.get('posSide'))
            cache=getattr(self,'live_display_cache',{})
            cache[key]=value
            self.live_display_cache={k:v for k,v in cache.items() if int(time.time()*1000)-v.get('received_ms',0)<=5000}
            if apply_position(self.positions,value):self.schedule()
            return
        if kind=='click_gate':
            self.state['entry_gate']=value
            if self.chat_window:self.chat_window.update_market(value)
            return
        if kind=='futures_market':
            self.state['futures_market']=value
            if self.chat_window:self.chat_window.update_market(value)
            return
        if kind=='futures_market_error':
            self.state.setdefault('futures_market',{})['stale']=True
            if self.chat_window:self.chat_window.update_market(value)
            return
        if kind=='position_chart':
            key=(value['symbol'],value['frame'])
            if value.get('error') and key in self.position_chart_data:
                self.position_chart_data[key].update(stale=True,error=value['error'])
            else:self.position_chart_data[key]=dict(value,_received_monotonic=time.monotonic())
            if len(self.position_chart_data)>24:self.position_chart_data={key:self.position_chart_data[key]}
            if self.chat_window and self.chat_window.exists():
                chart=self.chat_window.chart
                if value.get('symbol')==(chart.position or {}).get('symbol') and value.get('frame')==chart.frame:
                    chart.data=self.position_chart_data[key];chart.paint()
        elif kind=='telegram':
            self.state['telegram']=dict(value)
            self.add_activity(datetime.now(KST).strftime('%H:%M:%S'),'텔레그램 · '+str(value.get('detail') or value.get('status','미확인')))
        elif kind=='report_state':self.state['report_state']=dict(value)
        elif kind=='equity_history':self.equity_points=value
        elif kind=='budget_pacing':self.state['budget_pacing']=value
        elif kind=='model_usage':self.state['model_usage']=value
        elif kind=='api_credit':
            self.state['api_credit']=value
            if self.credit_window:self.credit_window.render(value)
        elif kind=='api_credit_error':
            if self.credit_window:self.credit_window.detail.configure(text=value)
            self.add_activity(datetime.now(KST).strftime('%H:%M:%S'),value)
        elif kind=='position_history':
            self.state.setdefault('position_history_days',{})[value['date']]=value
            if self.position_history_window:self.position_history_window.render(value)
        elif kind=='review_activity':
            self.state['review_activity']=value
            rows=value.get('items',[])
            names=', '.join(r['symbol'] for r in rows) or '검토 종목 미확인'
            plans=' | '.join(r['symbol'].replace('-USDT-SWAP','')+': '+', '.join(r.get('plans',[])[:4]) for r in rows if r.get('plans'))
            message=value.get('stage','검토')+' / '+names
            if plans:message+='\n'+plans
            if value.get('reason'):message+='\n'+value['reason']
            stamp=datetime.fromtimestamp(value['ms']/1000,KST).strftime('%H:%M:%S') if value.get('ms') else datetime.now(KST).strftime('%H:%M:%S')
            self.add_activity(stamp,message)
        elif kind=='market_table':
            self.state['market_table']=value
            if self.chat_window and self.chat_window.exists():self.chat_window.update_market(value)
        elif kind=='chat_symbols':self.state['chat_symbols']=value
        elif kind=='chat_reply':
            self.chat_messages.append(value);self.chat_messages=self.chat_messages[-100:]
            if self.chat_window and self.chat_window.exists():self.chat_window.add(value)
        elif kind=='chat_intent_ready':
            self.state['chat_intent_ready']=bool(value)
            if self.chat_window and self.chat_window.exists():pass
        elif kind=='chat_proposal':
            self.state['chat_proposal']=value
            if self.chat_window and self.chat_window.exists():self.chat_window.set_proposal(value)
        elif kind=='timeframes':self.state['timeframes']=value
        elif kind=='daily_risk':self.state['daily_risk']=value
        elif kind=='entry_cadence':self.state['entry_cadence']=value
        elif kind in ('session_ui','entry_control'):self.state.update(value)
        elif kind=='connection_reset':self.state.update(recovering=True,market_connected=False,account_connected=False)
        elif kind=='pipeline':
            self.state['execution']=value
            counts=value.get('counts',{})
            self.status='규칙 검사 · AI 호출 '+str(counts.get('ai_requests',0))+' / 진입 선택 '+str(counts.get('ai_selected',counts.get('signals',0)))+' / 주문 승인 '+str(counts.get('ai_approved',0))+' / 신규 주문 '+str(counts.get('orders',0))+' / 진입 체결 '+str(counts.get('fills',0))+' · '+value['label']+' · '+value.get('reason','')[:135]
            self.schedule();return
        if kind=='status':
            self.state.update(value);self.status=value.get('mode',self.status)+' · '+value.get('updated','—')+' KST'
            self.state['error']=None
        elif kind=='dashboard':
            self.data_seen=time.monotonic()
            self.state.update({k:v for k,v in value.items() if k!='positions'});self.positions=value.get('positions',[])
            from okx_live_display732 import apply_position
            for event in getattr(self,'live_display_cache',{}).values():apply_position(self.positions,event)
            keys={p.get('key',p['symbol']) for p in self.positions}
            if self.position_chart_key not in keys:self.chart_anchor=None;self.position_chart_key=next(iter([p.get('key',p['symbol']) for p in self.positions]),None)
            self.request_position_chart()
            for p in self.positions:
                key=p.get('key',p['symbol']);mark=numeric(p.get('mark'))
                if mark is not None:self.histories.setdefault(key,deque(maxlen=60)).append(mark)
            active={p.get('key',p['symbol']) for p in self.positions}
            self.histories={k:v for k,v in self.histories.items() if k in active}
        elif kind=='v5mode':
            self.state.update(recovering=bool(value.get('recovering')),ended=bool(value.get('ended')))
            if value.get('ended'):self.status=value.get('reason','当日 중단')+' · 보유 정리 확인 중'
            elif value.get('recovering'):self.status='연결·계정·보호 주문 대조 중 · 신규 진입 대기'
        elif kind=='error':self.state.update(error=str(value),market_connected=False,account_connected=False);self.status='신규 진입 정지 · '+str(value)
        elif kind=='log':
            text=str(value);stamp=text[6:14] if len(text)>15 else datetime.now(KST).strftime('%H:%M:%S')
            self.add_activity(stamp,text[16:] if len(text)>16 else text)
        elif kind=='decision':
            pair=(str(value.get('title','전략 판단')),str(value.get('text','')).replace('\n',' '))
            if not self.decisions or self.decisions[0]!=pair:
                self.decisions.appendleft(pair);self.add_activity(datetime.now(KST).strftime('%H:%M:%S'),pair[0]+' · '+pair[1])
        ready=bool(self.state.get('live') and not self.state.get('preview'))
        self.start.label='● 실거래 가동 중' if ready and not self.state.get('recovering') and self.state.get('market_connected') and self.state.get('account_connected') else '연결·계정 확인 중' if ready else '▶  실거래 시작'
        self.start.set_enabled(not self.demo and not ready)
        self.schedule()
    def add_activity(self,stamp,text):
        if self.activities and self.activities[0][1]==text:
            if text.startswith('규칙 상태'):self.activities[0]=(stamp,text,self.activities[0][2])
            return
        color=RED if any(s in text for s in ('실패','손절','오류')) else GREEN if any(s in text for s in ('확인','체결','상향','시작')) else MUTED
        self.activities.appendleft((stamp,text,color))
    def dialog(self,title):
        win=tk.Toplevel(self);win.title(title);win.configure(bg=BG);win.geometry('1120x760');win.transient(self.winfo_toplevel())
        label=tk.Label(win,text=title,bg=BG,fg=TEXT,font=(self.family,17,'bold'));label.pack(anchor='w',padx=24,pady=20)
        return win
    def show_chat(self):
        if self.chat_window and self.chat_window.exists():self.chat_window.focus_chat();return
        from okx_chat_ui import ChatWindow
        self.chat_window=ChatWindow(self,self.callbacks,parent=self.chat_pane)
    def show_activity(self,stamp,text):
        win=self.dialog('활동 상세 · '+stamp)
        box=tk.Text(win,bg=INNER,fg=TEXT,wrap='word',font=(self.family,15),padx=18,pady=18)
        box.pack(fill='both',expand=True,padx=20,pady=(0,20));box.insert('1.0',text);box.configure(state='disabled')
    def show_history(self):
        win=self.dialog('매매 기록 · 프로그램 활동')
        box=tk.Text(win,bg=INNER,fg=TEXT,insertbackground=TEXT,relief='flat',wrap='word',font=(self.family,14),padx=18,pady=15)
        box.pack(fill='both',expand=True,padx=20,pady=(0,20))
        execution=self.state.get('execution',{})
        header='현재 단계: '+str(execution.get('label','확인 중'))+'\n'+str(execution.get('reason',''))+'\n마지막 진입 차단: '+str(execution.get('last_blocker') or '없음')+'\n단계별 건수: '+str(execution.get('counts',{}))+'\n\n'
        from okx_day_status import lines as day_lines
        risk=self.state.get('daily_risk',{})
        if risk:header+='\n'.join(day_lines(risk))+'\n'+str(risk.get('transfer_latch_note',''))+'\n최근 이체: '+str(risk.get('recent_transfers',[]))+'\n\n'
        cadence=self.state.get('entry_cadence',{})
        header+='무체결 '+str(cadence.get('minutes_without_fill','미확인'))+'분 / 30분 우선 재검토 '+str(cadence.get('review_due',False))+' / 마지막 차단 '+str(cadence.get('last_blocker','없음'))+'\n\n'
        box.insert('1.0',header+('\n\n'.join(stamp+'  '+text for stamp,text,_ in self.activities) or '기록이 아직 없습니다.'));box.configure(state='disabled')
    def show_api_credit(self):
        if self.credit_window:
            self.credit_window.win.lift();return
        from okx_api_credit_ui import ApiCreditWindow
        self.credit_window=ApiCreditWindow(self)
    def show_position_history(self):
        if self.position_history_window:
            self.position_history_window.win.lift();return
        from okx_position_history_ui import PositionHistoryWindow
        self.position_history_window=PositionHistoryWindow(self)
    def show_positions(self):
        win=self.dialog('보유 포지션 · 보호 상태')
        box=tk.Text(win,bg=INNER,fg=TEXT,relief='flat',wrap='word',font=(self.family,14),padx=18,pady=15);box.pack(fill='both',expand=True,padx=20,pady=(0,20))
        for raw in self.positions:
            p=position_view(raw)
            box.insert('end',f"{p['symbol']}  {'수동·조회 전용' if p['source']=='manual' else '자동'}  {p['side'].upper()}  {p['leverage']}x\nROE {money(None if p['roe'] is None else p['roe']*100,signed=True)}% / 미실현 손익 {money(p['pnl'],signed=True)} USDT / 증거금 {money(p['margin'])} USDT ({p['margin_basis']}) / 수량 {p['quantity']}계약\n진입 {p['entry']} / 현재 {p['mark']} / SL {p['stop']}\n보호 {'거래소에서 직접 확인' if p['source']=='manual' else '확인됨' if p['protected'] else '확인 중'} / {p['phase']}\n{p['reason']}\n\n")
        if not self.positions:box.insert('end','보유 포지션이 없습니다. 진행 중인 주문은 계정 상태와 함께 확인하세요.')
        box.configure(state='disabled')
    def show_settings(self):
        win=self.dialog('운용 설정 · 예산')
        for label,var in (('과거 AI 예산 설정 (규칙 모드에서는 사용 안 함)',self.budget),):
            tk.Label(win,text=label,bg=BG,fg=MUTED,font=(self.family,14)).pack(anchor='w',padx=26,pady=(12,6))
            tk.Entry(win,textvariable=var,bg=INNER,fg=TEXT,insertbackground=TEXT,relief='flat',font=(self.family,17),width=20).pack(anchor='w',padx=26,ipady=8)
        tk.Label(win,text='V7.32-Q2U · 기존 15분봉 OR 두꼬리 / 4H 추가 진입 삭제\nBTC20 · ETH/SOL15 · 기타10배 / 격리 주문 확인\n자동 운용 시드에서 3 USDT 유보 후 1/4씩 / 최대4개\n최초2ATR SL / +20% ROE 최초 절반청산 / 잔량 수익보호 / 최대6시간\n유료 AI 호출 없음 · 수익성 검증 미통과',justify='left',bg=BG,fg=MUTED,font=(self.family,14)).pack(anchor='w',padx=26,pady=20)
        pace=self.state.get('budget_pacing') or {}
        tk.Label(win,text='V7.32-Q2U · 15분 완료봉·1H 확인 · 4H는 보조 분석만\n기존 3배 보유분의 실제 배율과 수량은 유지합니다. 보호 관리와 6시간 종료는 적용됩니다.\n최근24시간 사용 $'+money(pace.get('rolling_spent',0),4),bg=BG,fg=GREEN,font=(self.family,12),justify='left').pack(anchor='w',padx=26,pady=8)
        usage=self.state.get('model_usage',{})
        tk.Label(win,text='모델 GPT-6.1 Sol · 최근60분 '+str(usage.get('hour_calls',0))+'회 / 확정 $'+money(usage.get('hour_billed_cost',0),4)+' / 미확정 예약 $'+money(usage.get('hour_unknown_reserve',0),4)+'\n자동 진입 $'+money(usage.get('channels',{}).get('auto_entry',0),4)+' / 보유 판단 $'+money(usage.get('channels',{}).get('auto_manage',0),4)+' / 채팅 $'+money(usage.get('channels',{}).get('chat',0),4),bg=BG,fg=TEXT,font=(self.family,13),justify='left').pack(anchor='w',padx=26,pady=10)
        row=tk.Frame(win,bg=BG);row.pack(fill='x',padx=25,pady=10)
        RoundedButton(row,'상태 새로고침',self.callbacks['refresh'],width=170).pack(side='left')
        check=RoundedButton(row,'실거래 사전점검',self.callbacks.get('preflight',lambda:None),width=180);check.pack(side='left',padx=10)
        if self.demo:check.set_enabled(False)
        RoundedButton(row,'닫기',win.destroy,width=150).pack(side='right')

"""V732 admission and sizing. No strategy/stop changes, no network writes.

Continuous operation: daily PnL never suspends entries in this profile.
Risk amounts are estimates, not guaranteed loss ceilings.
"""
from decimal import ROUND_DOWN, ROUND_UP
from okx_core import BotError, dec, fmt

DEFAULTS = dict(enabled=True, trade_risk_fraction=.005,
                total_risk_fraction=.02,
                max_single_notional=20., max_total_notional=20.,
                slippage_reserve=.0005, max_spread=.0005, max_slippage=.0005)


def enabled(c):
    return bool(c.get('execution', {}).get('rule_channel701')
                and c.get('risk', {}).get('admission732', {}).get('enabled'))


def configure(c):
    c['version'] = '7.32-Q2-15m-only'
    c['risk']['admission732'] = dict(DEFAULTS)
    c['risk'].update(initial_size_mode='up_to_third',
                     max_position_loss_fraction=.005,
                     max_open_stop_loss_fraction=.02,
                     max_total_notional_fraction=20., daily_loss_enabled=False,
                     daily_profit_cap_enabled=False)
    return c


def validate(c):
    p = c['risk'].get('admission732', {})
    if p != DEFAULTS or c['risk'].get('initial_size_mode') != 'up_to_third':
        raise BotError('V732 위험 예산 설정 오류')
    if c['risk'].get('daily_loss_enabled') is not False or c['risk'].get('daily_profit_cap_enabled') is not False:
        raise BotError('V732 24시간 연속 운용 설정 오류')
    for key, value in (('max_position_loss_fraction', .005),
                       ('max_open_stop_loss_fraction', .02),
                       ('max_total_notional_fraction', 20.)):
        if c['risk'].get(key) != value:
            raise BotError('V732 공용 위험 한도 설정 불일치')


def clear_daily_halt(e):
    """Apply the user's continuous-operation choice, preserving unrelated halts."""
    if not enabled(e.cfg):
        return
    d = e.journal.data.get('day') or {}
    reasons = ('일일 -21% 손실 한도', '일일 +200% 상한', '일일 +1000% 상한')
    changed = False
    if d.get('ended') and d.get('end_reason') in reasons:
        d['previous_pnl_halt732'] = d['end_reason']
        d['ended'] = False; d.pop('end_reason', None); changed = True
    if d.pop('entry_pause732', None) is not None:
        changed = True
    if changed:
        e.journal.save()
        e.log('24시간 운용 설정: 일일 손익 중단 해제 · 기존 보호주문·계정 대조 유지')


def portfolio(e, snapshot):
    """Count all owned slots and in-flight entries exactly once.

    Manual exposure uses account notional; manual stop risk is not invented.
    Its reserved margin is already removed by allocation_seed().
    """
    raw = getattr(e, 'raw_snapshot', None) or snapshot
    live = {(p['instId'], p['posSide']): p for p in raw['positions']
            if dec(p.get('pos') or 0)}
    exposure = dec(0); risk = dec(0)
    records = e.records()
    for key, p in live.items():
        value = p.get('notionalUsd')
        if value in (None, ''):
            o = next((r for r in records if (r['symbol'], r['direction']) == key), None)
            ct = o.get('ct_val') if o else None
            if not ct:
                ct = e.api.public('/api/v5/public/instruments', instType='SWAP', instId=key[0])[0]['ctVal']
            value = abs(dec(p['pos'])) * dec(ct) * dec(p['markPx'])
        exposure += abs(dec(value))
    for o in records:
        if o.get('pending_add'):
            raise BotError('V732 이전 추가 주문 대조 중 · 신규 진입 보류')
        p = live.get((o['symbol'], o['direction']))
        if p:
            mark, stop, ct = dec(p['markPx']), dec(o['stop_px']), dec(o['ct_val'])
            side = 1 if o['direction'] == 'long' else -1
            cost = max(dec(o.get('cost_rate') or 0), dec('.002'))
            if min(mark, stop, ct) <= 0:
                raise BotError('V732 보유 위험 계산 자료 오류')
            risk += abs(dec(p['pos']))*ct*(max(dec(0), (mark-stop)*side)+mark*cost)
            # A partial opening fill still reserves the unfilled remainder.
            if o.get('phase') == 'submitted':
                intended = dec(o.get('quantity') or 0)
                remain = max(dec(0), intended-abs(dec(p['pos'])))
                risk += remain*ct*(abs(mark-stop)+mark*cost)
                exposure += remain*ct*mark
        else:
            reserved = dec(o.get('estimated_loss') or o.get('original_risk_budget') or 0)
            nominal = dec(o.get('committed_margin') or 0)*dec(o['leverage'])
            if min(reserved, nominal) <= 0:
                raise BotError('V732 미체결/종료 대조 기록 위험 확인 대기')
            risk += reserved; exposure += nominal
    return risk, exposure


def cap_plan(e, plan, i, s, direction, snapshot, fee):
    from okx_pattern15 import risk as price_risk
    from okx_channel4h730 import is_signal, reject_entry
    if is_signal(s):
        reject_entry()
    side = 1 if direction == 'long' else -1
    price = dec(plan['buy' if side == 1 else 'sell'])
    tick, lot, ct, minimum = (dec(i[k]) for k in ('tickSz', 'lotSz', 'ctVal', 'minSz'))
    leverage = dec(s['leverage'])
    equity = min(dec(snapshot['equity']), dec(e.allocation_seed(snapshot)))
    if min(price, tick, lot, ct, minimum, leverage, equity) <= 0:
        raise BotError('V732 수량 계산 자료 오류')
    stop = (dec(s['stop'])/tick).to_integral_value(rounding=ROUND_DOWN if side == 1 else ROUND_UP)*tick
    if stop <= 0 or (price-stop)*side <= 0:
        raise BotError('V732 구조 손절가 이탈')
    cost = 2*(abs(dec(fee))+dec(DEFAULTS['slippage_reserve']))
    loss_unit = ct*(abs(price-stop)+price*cost)
    open_risk, exposure = portfolio(e, snapshot)
    # allocation_seed already subtracts the account reserve exactly once.
    target = equity / 4
    reserve = dec(e.cfg.get('risk', {}).get('entry_cash_reserve_usdt', 3))
    available = max(dec(0), dec(snapshot['available']) - reserve)
    if len(e.records()) >= 4:
        raise BotError('최대 4포지션 · 신규 진입 대기')
    quantity = (target*leverage/(ct*price)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
    margin = quantity*ct*price/leverage
    if quantity < minimum or (i.get('maxMktSz') and quantity > dec(i['maxMktSz'])):
        raise BotError('시드 1/4 주문 수량이 거래소 허용 범위 밖 · 소액 대체 진입 안 함')
    if target-margin > max(target*dec('.03'), dec('0.00000001')):
        raise BotError('계약 단위 때문에 시드 1/4 오차 3% 초과 · 진입 대기')
    if margin > dec(e.margin_room(snapshot)) or margin+quantity*ct*price*abs(dec(fee)) > available:
        raise BotError('3USDT 유보 및 시드 1/4 증거금·수수료 부족 · 소액 대체 진입 안 함')
    budget = quantity*loss_unit
    updated = price_risk(dict(plan, quantity=fmt(quantity)), i, s, direction,
                         equity, snapshot['available'], fee, 0, e.cfg)
    updated.update(fixed_initial=True, initial_size_mode='fixed_quarter732q',
                   initial_margin_target=fmt(target), initial_quantity=fmt(quantity),
                   estimated_loss=fmt(budget), cost_rate=fmt(cost),
                   _initial_risk_budget=fmt(budget), _allocation_seed=fmt(equity),
                   _account_equity=fmt(snapshot['equity']), _fee=fmt(fee),
                   _funding='0', _ct=i['ctVal'],
                   risk732=dict(sizing='fixed_quarter732q', target_margin=fmt(target),
                                estimated_loss=fmt(budget), open_risk=fmt(open_risk),
                                total_notional=fmt(exposure),
                                route='4h55_20' if is_signal(s) else
                                s.get('decision_record', {}).get('volume_wick_proof', {}).get('route721', 'direct')))
    return updated


def check_liquidity(check):
    if dec(check['spread']) > dec(DEFAULTS['max_spread']) or dec(check['slippage']) > dec(DEFAULTS['max_slippage']):
        raise BotError('V732 스프레드/예상 슬리피지 0.05% 초과')


def prepare_plan(e, plan, i, ticker, frames, direction, snapshot, fee):
    from okx_pattern15 import allowed, book, leverage
    from okx_execution_status import check_permissions
    from okx_channel4h730 import is_signal, reject_entry
    check_permissions(snapshot['config']); e.risk_snapshot(snapshot)
    s = frames['_v4']
    required = 5 if s.get('click716') else leverage(i['instId'])
    if not allowed(i, e.cfg) or s['leverage'] != required or dec(i.get('lever') or 0) < required:
        raise BotError('V732 허용 종목/배율 불일치')
    if is_signal(s):
        reject_entry()
    if not s.get('click716') and not e.stream.ready(i['instId'], e.cfg, e.api.now_ms()):
        raise BotError('V732 실시간 시세 확인 대기')
    field = 'buy' if direction == 'long' else 'sell'
    plan = dict(plan); plan[field] = ticker['askPx' if direction == 'long' else 'bidPx']
    plan = cap_plan(e, plan, i, s, direction, snapshot, fee)
    raw = e.api.public('/api/v5/market/books', instId=i['instId'], sz='400')[0]
    check = book(raw, i, plan['quantity'], direction, e.api.now_ms(), e.cfg)
    (None if s.get('click716') else check_liquidity(check)); plan[field] = check['limit_px']
    plan = cap_plan(e, plan, i, s, direction, snapshot, fee)
    check = book(raw, i, plan['quantity'], direction, e.api.now_ms(), e.cfg)
    (None if s.get('click716') else check_liquidity(check)); plan[field] = check['limit_px']
    plan = cap_plan(e, plan, i, s, direction, snapshot, fee)
    plan.update(_liquidity=check, _selection=e.selection_row(i['instId']))
    return plan


def submit_check(e, plan, i, direction):
    from okx_pattern15 import book, check_entry
    snapshot = e.snapshot(); e.risk_snapshot(snapshot)
    if i['instId'] in e.blocked_manual_symbols():
        raise BotError('V732 수동 동일 종목 진입 금지')
    if not e.prepared_signal.get('click716') and not e.stream.ready(i['instId'], e.cfg, e.api.now_ms()):
        raise BotError('V732 주문 직전 시세 지연')
    raw = e.api.public('/api/v5/market/books', instId=i['instId'], sz='400')[0]
    check = book(raw, i, plan['quantity'], direction, e.api.now_ms(), e.cfg)
    if not e.prepared_signal.get('click716'):check_liquidity(check)
    check_entry(e, e.prepared_signal, float(check['limit_px']))
    candidate = dict(plan); candidate['buy' if direction == 'long' else 'sell'] = check['limit_px']
    candidate = cap_plan(e, candidate, i, e.prepared_signal, direction, snapshot, plan['_fee'])
    if dec(candidate['quantity']) != dec(plan['quantity']):
        raise BotError('V732 주문 직전 위험/잔고 변경 · 재산정 대기')
    plan.update(candidate); plan['_liquidity'] = check

"""Independent support/resistance and trend-base entries, closed bars only."""
from okx_rules import metrics,zones,regime

STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}
DEFAULTS=dict(enabled=True,frames=['1m','5m','15m','1H','4H'],zone_atr=.5,
    rejection_atr=.2,close_fraction=.6,base_bars=3,base_width_atr=1.5,
    break_tolerance_atr=.15,min_touches=2,day_change_fraction=.001,
    max_recovery_atr=2.5,context_enabled=True,major_leverages={'BTC':30,'ETH':20,'SOL':20})


def validate(p):
    return (type(p['enabled']) is bool and type(p['context_enabled']) is bool
        and p['frames'] and len(set(p['frames']))==len(p['frames']) and all(x in STEPS for x in p['frames'])
        and 0<p['zone_atr']<=2 and 0<p['rejection_atr']<=2 and .5<=p['close_fraction']<1
        and type(p['base_bars']) is int and 3<=p['base_bars']<=10 and 0<p['base_width_atr']<=4
        and 0<=p['break_tolerance_atr']<=.5 and type(p['min_touches']) is int
        and 2<=p['min_touches']<=p['base_bars'] and 0<=p['day_change_fraction']<=.05
        and 0<p['max_recovery_atr']<=5
        and p['major_leverages']=={'BTC':30,'ETH':20,'SOL':20})


def context(b,c):
    """Show available longer averages honestly; missing MA200 is never invented."""
    if len(b)<21:return dict(trend='unknown',reason='완료 봉 이력 부족',closed=True,bars=len(b))
    if len(b)>=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1:
        m=metrics(b,c)
        return dict(trend=regime(m,c),ma=m['ma'],bb={k:m[k] for k in ('mid','upper','lower')},
            volume_relative=m['relative_volume'],rsi=m['rsi'],closed=True,last_bar_ms=b[-1][0],bars=len(b))
    import statistics
    closes=[x[4] for x in b];mid=statistics.mean(closes[-20:]);sd=statistics.pstdev(closes[-20:])
    ma={n:statistics.mean(closes[-n:]) for n in c['indicators']['ma_periods'] if len(closes)>=n}
    shift=c['signals']['slope_bars'];old=statistics.mean(closes[-20-shift:-shift]) if len(closes)>=20+shift else mid
    return dict(trend='uptrend' if mid>old else 'downtrend' if mid<old else 'range',ma=ma,
        bb=dict(mid=mid,upper=mid+2*sd,lower=mid-2*sd),closed=True,last_bar_ms=b[-1][0],bars=len(b),
        unavailable_ma=[n for n in c['indicators']['ma_periods'] if n not in ma],reason='가용 이평선 분석 / MA200 포함 전체 지표 이력 미충족')


def setups(frames,c,now):
    p=c['signals'].get('support_entries',{})
    if not p.get('enabled'):return []
    out=[];need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1
    day_start=(now+32400000)//86400000*86400000-32400000
    day=[b for b in frames.get('5m',[]) if day_start<=b[0] and b[0]+300000<=now]
    # Do not label the day direction unless the actual first completed KST-day candle is present.
    day_open=day[0][1] if day and day[0][0]==day_start else None
    for frame in p['frames']:
        step=STEPS[frame];b=[x for x in frames.get(frame,[]) if x[0]+step<=now]
        if len(b)<need+p['base_bars']:continue
        last=b[-1];end=last[0]+step
        if not end<=now<end+c['signals']['wick15']['entry_window_seconds']*1000:continue
        prior=metrics(b[:-1],c);m=metrics(b,c);atr=prior['atr'];tol=atr*p['zone_atr']
        # All support zones existed before the reaction candle; base reference excludes its whole base.
        levels=[dict(x,source=frame+' confirmed pivot') for x in zones(b[:-1],c)]
        for side in (1,-1):
            kind='support' if side==1 else 'resistance';extreme=last[3] if side==1 else last[2]
            span=last[2]-last[3]
            if span<=0:continue
            location=(last[4]-last[3])/span if side==1 else (last[2]-last[4])/span
            reaction=(last[4]-last[1])*side>=0 and (last[4]-extreme)*side>=atr*p['rejection_atr'] and location>=p['close_fraction']
            nearby=[x for x in levels if x['kind']==kind and abs(extreme-x['price'])<=tol and (last[4]-x['price'])*side>0]
            def add(pattern,level,source,low,high,score,evidence):
                out.append(dict(direction='LONG' if side==1 else 'SHORT',pattern=pattern,frame=frame,
                    low=low,high=high,anchor=last[0],level=level,source=source,shape={},adaptive=True,
                    evidence_score=score,evidence=evidence,independent_support=True))
            if reaction and nearby and (last[4]-extreme)*side<=atr*p['max_recovery_atr']:
                level=min(nearby,key=lambda x:abs(extreme-x['price']))
                add('support_hold_long' if side==1 else 'resistance_hold_short',level['price'],level['source'],
                    last[3],last[2],8,dict(confirmed_level=True,close_recovered=True,close_location=location,
                    volume_relative=m['relative_volume'],long_wick_required=False))
            n=p['base_bars'];base=b[-n:];history=b[:-n];old=metrics(history,c)
            # Independent trend-base route: no wick or band excursion required.
            aligned=(old['ma'][15]-old['ma'][20])*side>0 and old['slopes'][20]*side>0
            day_aligned=day_open is not None and (last[4]/day_open-1)*side>=p['day_change_fraction']
            if not aligned or not day_aligned:continue
            prior_zones=[x for x in zones(history,c) if x['kind']==kind]
            if not prior_zones:continue
            previous=prior_zones[-1]['price']
            base_extreme=min(x[3] for x in base) if side==1 else max(x[2] for x in base)
            intact=(base_extreme-previous)*side>=-atr*p['break_tolerance_atr']
            width=max(x[2] for x in base)-min(x[3] for x in base)
            if not intact or width>atr*p['base_width_atr']:continue
            for period in (15,20,50,100,120,200):
                level=old['ma'][period]
                touches=sum(abs((x[3] if side==1 else x[2])-level)<=tol for x in base)
                holds=all((x[4]-level)*side>=-atr*p['break_tolerance_atr'] for x in base)
                if touches>=p['min_touches'] and holds and (last[4]-level)*side>=0:
                    add('rising_day_ma_base_long' if side==1 else 'falling_day_ma_base_short',level,frame+' SMA'+str(period),
                        min(x[3] for x in base),max(x[2] for x in base),9,
                        dict(day_open=day_open,day_change=last[4]/day_open-1,previous_extreme=previous,
                        extreme_intact=True,base_bars=n,base_width_atr=width/atr,touches=touches,
                        long_wick_required=False,breakout_required=False,trend_aligned=True))
                    break
    return out


def flow_assessment(frames,side,c):
    """Separate established flow from a multi-bar stabilization; a lone tail is insufficient."""
    votes={};structures={};need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1
    for frame in ('5m','15m','1H','4H'):
        b=frames.get(frame,[])
        if len(b)<need:
            votes[frame]=None;continue
        m=metrics(b,c)
        aligned=(m['ma'][15]-m['ma'][20])*side>=0 and m['slopes'][20]*side>0
        adverse=(m['ma'][15]-m['ma'][20])*side<0 and m['slopes'][20]*side<0
        votes[frame]=1 if aligned else -1 if adverse else 0
        ps=zones(b,c);hi=[x for x in ps if x['kind']=='resistance'][-2:];lo=[x for x in ps if x['kind']=='support'][-2:]
        structures[frame]=dict(highs=[x['price'] for x in hi],lows=[x['price'] for x in lo])
    b=frames.get('1m') or frames.get('5m',[])
    stable=False
    if len(b)>=need:
        m=metrics(b[:-1],c);recent=b[-3:];older=b[-9:-3];tol=m['atr']*.15
        if side==1:
            stable=min(x[3] for x in recent)>=min(x[3] for x in older)-tol and recent[-1][4]>recent[0][4]
        else:
            stable=max(x[2] for x in recent)<=max(x[2] for x in older)+tol and recent[-1][4]<recent[0][4]
    # At least one established timeframe supports direction, or a three-bar base has recovered.
    trend=any(v==1 for v in votes.values())
    strong_conflict=sum(v==-1 for v in votes.values())>=3 and not stable
    return dict(allowed=(trend or stable) and not strong_conflict,
        mode='trend_follow' if trend and not strong_conflict else 'stabilizing_reversal' if stable else 'conflict',
        timeframe_votes=votes,confirmed_swings=structures,multi_bar_stabilization=stable)

"""Three-principle entry reset. Numerical thresholds are test settings, not claims by traders."""
import copy,hashlib,math,time
from okx_core import BotError
from okx_market import closed_candles

DEFAULTS=dict(enabled=True,trend_ma=20,zone_atr=.35,rejection_atr=.10,
 close_fraction=.55,pullback_bars=3,range_bars=20,breakout_lookback=3,
 stop_buffer_atr=.35,max_chase_atr=.5,signal_ttl_seconds=240,
 risk_fraction=.005,min_net_rr=1.2,leverage=3)

def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('research_entry',{}))
def enabled(c):return c.get('signals',{}).get('research_entry',{}).get('enabled',False)
def validate(p):
 return (type(p['enabled']) is bool and p['trend_ma']==20 and .1<=p['zone_atr']<=1
  and .01<=p['rejection_atr']<=1 and .5<=p['close_fraction']<=.9
  and type(p['pullback_bars']) is int and 1<=p['pullback_bars']<=5
  and type(p['range_bars']) is int and 10<=p['range_bars']<=50
  and type(p['breakout_lookback']) is int and 2<=p['breakout_lookback']<=5
  and .1<=p['stop_buffer_atr']<=1.5 and .1<=p['max_chase_atr']<=1.5
  and 30<=p['signal_ttl_seconds']<=300 and .001<=p['risk_fraction']<=.02
  and 1<=p['min_net_rr']<=3 and type(p['leverage']) is int and 3<=p['leverage']<=10)

def sma(b,n=20):return sum(r[4] for r in b[-n:])/n
def atr(b,n=14):
 values=[max(r[2]-r[3],abs(r[2]-a[4]),abs(r[3]-a[4])) for a,r in zip(b[:-1],b[1:])]
 return sum(values[-n:])/n
def basic(b):return dict(atr=atr(b),close=b[-1][4])
def clean(b):
 return len(b)>=60 and all(len(r)>=6 and all(math.isfinite(float(x)) for x in r[:6])
  and min(r[1:5])>0 and r[3]<=min(r[1],r[4])<=max(r[1],r[4])<=r[2] and r[5]>=0 for r in b)

def setups(frames,c):
 p=settings(c);b=frames.get('5m',[]);higher=frames.get('15m',[])
 if not clean(b) or not clean(higher):return {},'5분/15분 완료봉 이력·가격 데이터 부족'
 a=atr(b[:-1]);last=b[-1];close=last[4]
 if a<=0:return {},'변동성 계산 불가'
 direction=1 if higher[-1][4]>sma(higher) and sma(higher)>sma(higher[:-3]) else -1 if higher[-1][4]<sma(higher) and sma(higher)<sma(higher[:-3]) else 0
 if not direction:return {},'15분 가격·SMA20 추세 방향 불명확'
 action='LONG' if direction==1 else 'SHORT';hits=[]
 def add(name,level,extreme,target,first_ms,second_ms,source):
  if target<=0 or (target-close)*direction<=0:return
  stop=extreme-direction*a*p['stop_buffer_atr']
  if stop<=0 or (close-stop)*direction<=0:return
  hits.append(dict(pattern=name,frame='5m',first=level,second=extreme,
   first_ms=first_ms,second_ms=second_ms,confirmed_ms=last[0]+300000,
   retracement_atr=abs(close-extreme)/a,reaction_confirmed=True,
   target=target,target_source=source,stop=stop,level=level,atr=a,max_hold_seconds=86400))
 span=last[2]-last[3]
 location=(close-last[3])/span if direction==1 and span>0 else (last[2]-close)/span if span>0 else 0
 reaction=(close-last[1])*direction>0 or (close-b[-2][4])*direction>0
 # Pullback: historical MA for each touch uses only data preceding that touch.
 if reaction and location>=p['close_fraction']:
  for index in range(len(b)-p['pullback_bars'],len(b)):
   test=b[index];level=sma(b[:index])
   if not test[3]<=level+a*p['zone_atr'] or not test[2]>=level-a*p['zone_atr']:continue
   if (close-level)*direction<a*p['rejection_atr'] or abs(close-level)>a*2:continue
   recent=b[index:];extreme=min(r[3] for r in recent) if direction==1 else max(r[2] for r in recent)
   prior=b[max(0,index-p['range_bars']):index]
   target=max(r[2] for r in prior) if direction==1 else min(r[3] for r in prior)
   add('research_pullback',level,extreme,target,prior[0][0],test[0],'5m 눌림 이전 관측 파동 극점')
   break
 # Breakout and retest: breakout and test must be different completed bars.
 start=len(b)-p['breakout_lookback'];base=b[start-p['range_bars']:start]
 high=max(r[2] for r in base);low=min(r[3] for r in base);level=high if direction==1 else low
 for index in range(start,len(b)-1):
  broken=(b[index][4]-level)*direction>a*p['rejection_atr']
  if not broken:continue
  if (close-level)*direction<a*p['rejection_atr'] or abs(close-level)>a*2:continue
  touch=last[3]<=level+a*p['zone_atr'] and last[2]>=level-a*p['zone_atr']
  if not touch or not reaction or location<p['close_fraction']:continue
  recent=b[index+1:];extreme=min(r[3] for r in recent) if direction==1 else max(r[2] for r in recent)
  # The prior box height is a declared projection, never enlarged to pass R/R.
  target=level+direction*(high-low)
  add('research_breakout_retest',level,extreme,target,base[0][0],last[0],'돌파 이전20봉 박스 높이 1배 측정 목표(추정)')
  break
 if not hits:return {},'15분 추세는 확인·5분 눌림 회복 또는 돌파 재확인 미충족'
 # Pick an independently valid setup, not a requirement that both be present.
 best=max(hits,key=lambda h:(h['target']-close)*direction/abs(close-h['stop']))
 return {action:best},''

def signal(frames,c,now,symbol,selection=None):
 completed={}
 for frame,step in (('5m',300000),('15m',900000)):
  b=[list(r) for r in frames.get(frame,[]) if r[0]+step<=now]
  if not b or now-(b[-1][0]+step)>=step:return None,frame+' 최신 완료봉 갱신 대기'
  if any(b[n][0]-b[n-1][0]!=step for n in range(max(1,len(b)-25),len(b))):return None,frame+' 완료봉 간격 오류'
  completed[frame]=b
 hits,why=setups(completed,c)
 if not hits:return None,why
 action,h=next(iter(hits.items()));p=settings(c);end=completed['5m'][-1][0]+300000
 if now>end+p['signal_ttl_seconds']*1000:return None,'새 규칙 신호 유효시간 경과'
 close=completed['5m'][-1][4]
 return dict(h,symbol=symbol,action=action,strategy='research_momentum',leverage=p['leverage'],
  signal_id=hashlib.sha256(f"research:{symbol}:{h['pattern']}:{h['second_ms']}:{action}".encode()).hexdigest()[:24],
  setup_frame='5m',execution_frame='5m',valid_from_ms=end,expires_ms=end+p['signal_ttl_seconds']*1000,
  entry_reference=close,entry_gap=h['atr']*p['max_chase_atr'],at_ms=end-300000,
  reason='①KST09 거래대금 상위권 ②15분 추세·5분 '+('눌림 회복' if h['pattern']=='research_pullback' else '돌파 재확인')+' ③구조 손절·비용·위험 수량 검사',
  regime='uptrend' if action=='LONG' else 'downtrend',ma={20:sma(completed['5m'])},bb={},rsi={},retest=True,
  adaptive=True,selection=selection or {},holding_rule=dict(wave=True,no_time_exit=True,frame='5m',ma_period=20,
   zone=h['level'],tolerance=h['atr']*.35,target=h['target'],source=h['pattern'],max_hold_seconds=86400),
  decision_record=dict(strategy_logic='RESEARCH_THREE',reason=h['pattern'],target_source=h['target_source'])),''

def check(s,now,price):
 if not s['valid_from_ms']<=now<=s['expires_ms']:raise BotError('새 진입 규칙 신호 만료')
 if abs(float(price)-s['entry_reference'])>s['entry_gap']:raise BotError('새 진입 규칙: 허용 추격 범위 초과')

def candidate(engine):
 result,error=engine.universe.read();now=engine.api.now_ms()
 if not result or time.monotonic()-result['completed']>engine.cfg['execution']['scan_max_age_seconds']:
  engine.pipeline('scan','새 진입 규칙: 거래대금·차트 자료 준비 중');return None
 if not result.get('turnover_ready'):
  engine.pipeline('scan','거래대금 순위 준비 / '+result.get('turnover_error',''));return None
 rows=result['rows'];engine.stream.watch([r['symbol'] for r in rows]+[r['symbol'] for r in engine.records()]+engine.chat.watch())
 waits=[]
 for row in rows:
  symbol=row['symbol']
  if symbol in engine.blocked_manual_symbols() or any(r['symbol']==symbol for r in engine.records()):continue
  if not engine.stream.ready(symbol,engine.cfg,now):waits.append(symbol+' / 실시간 호가 준비 중');continue
  s,why=signal({'5m':row['bars5'],'15m':row['bars15']},engine.cfg,now,symbol,
   {k:row[k] for k in ('turnover_rank','kst_turnover_usdt') if k in row})
  if not s:waits.append(symbol+' / '+why);continue
  if symbol+':'+s['signal_id'] in engine.journal.data.get('seen_signals',{}):continue
  quote=engine.stream.read(symbol,'tickers',3,now)
  if not quote:continue
  try:check(s,now,quote['last'])
  except BotError as e:waits.append(symbol+' / '+str(e));continue
  from okx_review_ui import emit_review
  emit_review(engine,'새 규칙 진입 선택',dict(_packets=[dict(symbol=symbol,selection=s['selection'])]),s['reason'])
  key=symbol+':'+s['signal_id']
  if not hasattr(engine,'traced_signals'):engine.traced_signals=set()
  if key not in engine.traced_signals:
   engine.traced_signals.add(key);engine.pipeline('preflight',symbol+' / 새 3원칙 진입 신호 선택',count='signals')
  return s
 engine.pipeline('signal_wait',' | '.join(waits[:3]) or '거래대금 상위권에서 새 규칙 신호 탐색 중');return None

def context(engine,symbol,action):
 frozen=engine.executing_signal
 if not frozen or frozen.get('strategy')!='research_momentum' or frozen['symbol']!=symbol or frozen['action']!=action:raise BotError('새 진입 규칙 확정 신호 불일치')
 engine.selection_row(symbol)
 frames={}
 for frame in ('5m','15m'):
  rows=engine.api.public('/api/v5/market/candles',instId=symbol,bar=frame,limit='80')
  rows=[list(r) for r in rows]
  for r in rows:r[7]=r[5]
  frames[frame]=closed_candles(rows,frame,engine.api.now_ms())
 fresh,why=signal(frames,engine.cfg,engine.api.now_ms(),symbol,frozen.get('selection'))
 if not fresh or fresh['signal_id']!=frozen['signal_id']:raise BotError('새 규칙 차트 변경: '+why)
 check(frozen,engine.api.now_ms(),frames['5m'][-1][4])
 engine.prepared_signal=copy.deepcopy(frozen);engine.signal_prepared_monotonic=time.monotonic()
 return dict(frames,_v4=engine.prepared_signal)

"""Right dock: compact position chart above subscription ChatGPT web."""
import tkinter as tk
from okx_ui_theme import BG,PANEL,INNER,BORDER,TEXT,MUTED,GREEN,RED
from okx_compact_chart import CompactChart
from okx_market_ui716 import MarketPanel
class ChatWindow:
 def __init__(self,view,callbacks,parent=None):
  self.view=view;self.callbacks=callbacks;self.proposal=None
  self.win=tk.Frame(parent or view,bg=BG);self.win.pack(fill='both',expand=True)
  self.split=tk.PanedWindow(self.win,orient='vertical',bg=BORDER,sashwidth=7);self.split.pack(fill='both',expand=True)
  self.chart=CompactChart(self.split,view,external=True);self.web_chat=MarketPanel(self.split,view,self.chart)
  self.split.add(self.chart,minsize=240,height=580,stretch='always');self.split.add(self.web_chat,minsize=300,height=450,stretch='always')
 def exists(self):
  try:return bool(self.win.winfo_exists())
  except tk.TclError:return False
 def close(self):
  if self.exists():self.win.destroy()
  if self.view.chat_window is self:self.view.chat_window=None
 def add(self,item):pass
 def set_proposal(self,p):pass
 def update_market(self,value):self.web_chat.render()
 def focus_chat(self):self.web_chat.focus_set()

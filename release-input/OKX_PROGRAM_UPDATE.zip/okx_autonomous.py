"""AI wave selection with causal packets and deterministic execution boundaries."""
import copy,hashlib,json,math,time
from okx_core import BotError
from okx_review_ui import emit_review,review_names
from okx_rules import metrics,regime
STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}
DEFAULTS=dict(enabled=True,entry_interval_seconds=60,manage_interval_seconds=120,
              batch_size=3,review_due_seconds=1800,urgent_interval_seconds=30,max_hold_seconds=600,max_output_tokens=450,max_payload_chars=20000)
INSTRUCTIONS='''당신은 OKX 단타 스캘핑 의사결정자다. 제공된 완료봉과 지표로 파동 전체를 보고 롱/숏/대기를 선택한다.
고정 꼬리 비율/거래량 급증/모든 시간봉 정렬을 진입 필수로 요구하지 않는다. 근거 일부가 엇갈려도 중간 정도의 방향 우위와 가격 반응, 타당한 구조 손절이 있으면 진입을 선택할 수 있다. 완벽한 확신이나 추가 지표 일치를 기다리지 마라. long/short 각각 근거의 수보다 가격 반응과 위험 대비 보상을 평가하라. review_due이면 30분 무진입 재검토 대상으로, 진행 중 파동을 우선 검토하되 진입을 강제하지 않는다. 1H/4H는 큰 흐름,15m는 파동,5m/1m는 가격 반응을 본다.
지지 회복,저점 상승,저항 거부,고점 하락,돌파 유지,반전 등 다봉 흐름을 종합하라. structures의 lower_high/double_top은 재반등 실패 숏, higher_low/double_bottom은 재하락 실패 롱의 우선 근거다. 현재가만 직전 고점 아래/저점 위라는 이유로 진입하지 마라. 첫 극점→중간 파동→두 번째 극점→거부 반응을 구분하라. stop_plans에 제시한 시간봉과 구조를 검토해 stop_index를 고르며 분봉은 짧게, 시간봉은 구조가 유지되는 동안 길게 보유하라. 단순 과매수/과매도나 밴드 접촉만으로 역진입하지 않는다.
ENTRY: stop_plans에 admitted_leverages가 있으면 해당 배율 중에서만 선택한다. 제공 후보 중 하나의 symbol과 LONG/SHORT 또는 WAIT. 가능한 방향의 제공 stop_options 인덱스만 선택하며 target은 제공된 목표를 그대로 사용한다.
leverage는 제공한 3~leverage_cap 정수 중 손절 거리/변동성/상위 흐름을 고려해 고른다. 배율 상한까지 채울 필요가 없다.
확실한 확률을 지어내거나 수익을 보장하지 마라. 선택한 근거와 무효화 이유를 reason 160자 이내로 쓴다.
wave_mode.enabled가 true이면 신규 진입은 제공된5분/15분/1H/4H 계획 중 double_top 숏 OR double_bottom 롱 OR trend_support 롱 OR trend_resistance 숏으로 선택하라. 이들은 독립적인 OR 전략이다. 추세 지지/저항 계획에는 쌍고점·쌍저점이나 다음 봉 고점/저점 돌파를 추가로 요구하지 마라. lower_high/higher_low 단독이나1분 스캘핑은 진입 근거로 쓰지 않는다. 손절은 두 극점 바깥의 해당 시간봉 변동성 여유다. 파동 보유 중1분 MA5나 몇 분의 진행 부족만으로 청산하지 말고 기준 시간봉에서 파동 실패를 판단하라.
MANAGE: holding_rule의 진입 시간봉과 구조를 고정해 현재 자동 포지션만 HOLD/CLOSE/PARTIAL 중 선택한다. 시간봉 진입은 1분 흔들림만으로 정리하지 말고 기준 시간봉의 지지/저항 붕괴와 파동 실패를 확인하라. 파동 진행이면 HOLD,지지/저항 붕괴나 파동 실패면 CLOSE,수익 중 반전 우려면 PARTIAL.
PARTIAL은 잔여 수량의60% 1회만 가능하다. 손실 중 부분 익절을 제안하지 마라. 손절을 넓히지 마라.
WAIT/HOLD/CLOSE/PARTIAL일 때도 모든 JSON 필드에 값이 필요하다. entry 외에는 leverage=3,stop_index=0을 사용한다.'''
SCHEMA={'type':'object','properties':{'action':{'type':'string','enum':['WAIT','LONG','SHORT','HOLD','CLOSE','PARTIAL']},'symbol':{'type':'string'},'leverage':{'type':'integer'},'stop_index':{'type':'integer'},'reason':{'type':'string'}},'required':['action','symbol','leverage','stop_index','reason'],'additionalProperties':False}

def enabled(c):return c.get('execution',{}).get('autonomous_scalp',{}).get('enabled',False)
def settings(c):return dict(DEFAULTS,**c.get('execution',{}).get('autonomous_scalp',{}))
def validate(p):
 return (type(p['enabled']) is bool and 30<=p['entry_interval_seconds']<=3600 and 60<=p['manage_interval_seconds']<=3600
  and 900<=p['review_due_seconds']<=3600 and 30<=p['urgent_interval_seconds']<=p['entry_interval_seconds']
  and type(p['batch_size']) is int and 1<=p['batch_size']<=3 and 120<=p['max_hold_seconds']<=1800
  and 300<=p['max_output_tokens']<=800 and 10000<=p['max_payload_chars']<=30000)
def leverage_cap(symbol,c):
 if c.get('execution',{}).get('pattern15_only'):
  from okx_pattern15 import leverage
  return leverage(symbol)
 if c.get('execution',{}).get('free_ai',{}).get('enabled'):return 5
 return int(c['signals'].get('support_entries',{}).get('major_leverages',{}).get(symbol.split('-')[0],c['risk']['max_leverage']))
def valid_leverage(s,c):
 from okx_channel4h730 import is_signal
 if is_signal(s):return False
 if s.get("click716"):return type(s.get("leverage")) is int and s["leverage"]==5
 if c.get('execution',{}).get('pattern15_only'):
  from okx_pattern15 import leverage
  return type(s.get('leverage')) is int and s['leverage']==leverage(s['symbol'])
 if c.get('execution',{}).get('free_ai',{}).get('enabled'):return type(s.get('leverage')) is int and s['leverage']==5
 if s.get('strategy')=='band_flow':
  base=s['symbol'].split('-')[0];category=s.get('selection',{}).get('asset_category')
  if category=='3':return s['leverage']==5
  if base in ('BTC','ETH','SOL'):return s['leverage']=={'BTC':30,'ETH':20,'SOL':20}[base]
  return type(s['leverage']) is int and 4<=s['leverage']<=10
 if c['signals'].get('research_entry',{}).get('enabled') and (s.get('selected_ai_order') or s.get('user_chat_order')):return type(s.get('leverage')) is int and 3<=s['leverage']<=10
 if s.get('strategy')=='research_momentum':return s.get('leverage')==c['signals']['research_entry']['leverage']
 if enabled(c) and s.get('autonomous'):
  return type(s.get('leverage')) is int and c['risk']['min_leverage']<=s['leverage']<=leverage_cap(s['symbol'],c)
 override=c['signals'].get('support_entries',{}).get('major_leverages',{}).get(s['symbol'].split('-')[0])
 return s['leverage']==override if override is not None else c['risk']['min_leverage']<=s['leverage']<=c['risk']['max_leverage']

def packet(symbol,raw,c,now):
 frames={};summary={}
 for f,step in STEPS.items():
  b=[list(r) for r in raw.get(f,[]) if r[0]+step<=now]
  if len(b)<max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+2:continue
  if now-(b[-1][0]+step)>=step or any(b[j][0]-b[j-1][0]!=step for j in range(-20,0)):continue
  if any(not all(math.isfinite(float(x)) for x in r[:6]) or min(r[1:5])<=0 or r[2]<max(r[1],r[3],r[4]) or r[3]>min(r[1],r[2],r[4]) or r[5]<0 for r in b[-24:]):continue
  m=metrics(b,c);frames[f]=b
  summary[f]=dict(completed_ms=b[-1][0]+step,trend=regime(m,c),ma=m['ma'],bb={k:m[k] for k in ('mid','upper','lower')},atr=m['atr'],rsi=m['rsi'],volume_relative=m['relative_volume'],recent=b[-8:])
 if '1m' not in frames or '5m' not in frames or '15m' not in frames:raise BotError('자율 스캘핑 최신1분·5분·15분 완료봉 대기')
 b=frames['1m'];price=b[-1][4];atr=metrics(b[:-1],c)['atr']
 if atr<=0:raise BotError('자율 스캘핑 변동성 데이터 부족')
 from okx_swing_context import evidence as swing_evidence
 from okx_trend_entry import entry_evidence,enabled as trend_enabled
 structures={f:(entry_evidence(rows,f,metrics(rows,c),c) if trend_enabled(c) and f!='1m' else swing_evidence(rows,f,summary[f]['atr'],c)) for f,rows in frames.items()}
 structures={f:h for f,h in structures.items() if h}
 directions={}
 for sign,action in ((1,'LONG'),(-1,'SHORT')):
  stops=sorted(set((min(r[3] for r in b[-n:])-atr*c['risk']['stop_buffer_atr']) if sign>0 else (max(r[2] for r in b[-n:])+atr*c['risk']['stop_buffer_atr']) for n in (3,6,12)))
  stops=[v for v in stops if v>0 and (price-v)*sign>0]
  obstacles=[]
  for f in ('5m','15m','1H','4H'):
   if f in frames:
    v=frames[f][-20:];obstacles.append(max(r[2] for r in v) if sign>0 else min(r[3] for r in v))
  obstacles=[v for v in obstacles if (v-price)*sign>atr*.1]
  if not stops:continue
  if obstacles:target=min(obstacles) if sign>0 else max(obstacles);source='관측된 최근20봉 고점/저점 중 가장 가까운 가격'
  else:
   # One fixed wave projection, never expanded to make cost tests pass.
   m5=metrics(frames['5m'],c)
   if regime(m5,c)!=('uptrend' if sign>0 else 'downtrend'):continue
   target=price+sign*m5['atr']*1.5;source='실제 장애물 미확인: 5분 ATR1.5 고정 파동 측정 목표'
  if target<=0:continue
  plans=[dict(frame='1m',stop=v,source='최근1분 극점',max_hold_seconds=settings(c)['max_hold_seconds']) for v in stops]
  for frame,hits in structures.items():
   hit=hits.get(action)
   if hit and hit['stop']>0 and (price-hit['stop'])*sign>0:plans.append(dict(frame=frame,stop=hit['stop'],source=hit['pattern'],structure=hit,max_hold_seconds=hit['max_hold_seconds']))
  from okx_wave_mode import enabled as wave_enabled,plans as wave_plans
  if wave_enabled(c):
   plans=wave_plans(structures,summary,action,price,c)
   if not plans:continue
  directions[action]=dict(stop_options=[v['stop'] for v in plans],stop_plans=plans,target=target,target_source=source)
 if not directions:raise BotError('쌍고점·쌍저점 또는 추세 지지/저항과 손절·목표 확인 대기' if c['signals'].get('wave_mode',{}).get('enabled') else '자율 스캘핑 손절·목표 구성 불가')
 return dict(symbol=symbol,observed_ms=now,price=price,atr=atr,leverage_cap=leverage_cap(symbol,c),directions=directions,frames=summary,structures=structures,wave_mode=c['signals'].get('wave_mode',{}),
   risk_policy=dict(initial_margin_fraction=c['risk']['initial_margin_fraction'],max_total_notional_fraction=c['risk']['max_total_notional_fraction'],final_stop_roe=c['risk']['final_stop_roe'],min_net_reward_risk=c['risk']['min_reward_risk']))

def make_signal(result,p,c):
 if result['action'] not in ('LONG','SHORT') or result['symbol']!=p['symbol']:raise BotError('자율 AI 종목·방향 불일치')
 side=1 if result['action']=='LONG' else -1;d=p['directions'].get(result['action'])
 idx=result['stop_index'];lev=result['leverage']
 if not d or type(idx) is not int or not 0<=idx<len(d['stop_options']):raise BotError('자율 AI 손절 선택 범위 밖')
 if type(lev) is not int or not c['risk']['min_leverage']<=lev<=p['leverage_cap']:raise BotError('자율 AI 배율 범위 밖')
 plan=d.get('stop_plans',[{}]*len(d['stop_options']))[idx]
 if 'admitted_leverages' in plan and lev not in plan['admitted_leverages']:raise BotError('AI가 사전 주문 검사 미통과 배율 선택')
 price=p['price'];stop=d['stop_options'][idx];target=plan.get('target',d['target']);gap=min(p['atr']*.5,price*.005)
 if ((abs(price-stop)+gap)/price)*lev>abs(c['risk']['final_stop_roe']):raise BotError('자율 AI 선택 배율의 구조 손절이 -30%ROE 초과')
 end=p['frames']['1m']['completed_ms'];reason=result['reason'][:160]
 chart={f:dict(close=p['price'],atr=v['atr'],relative_volume=v['volume_relative']) for f,v in p['frames'].items()}
 s=dict(symbol=p['symbol'],action=result['action'],strategy='wick15_rejection',pattern='ai_wave_scalp',autonomous=True,
   setup_frame='1m',execution_frame='1m',stop=stop,target=target,reason=reason,regime=p['frames']['5m']['trend'],
   level=stop+side*p['atr']*c['risk']['stop_buffer_atr'],ma=p['frames']['5m']['ma'],bb=p['frames']['5m']['bb'],rsi=p['frames']['5m']['rsi'],
   relative_volume=p['frames']['5m']['volume_relative'],chart_context=chart,retest=False,at_ms=end-60000,atr=p['atr'],adaptive=True,
   higher_confirmation=True,valid_from_ms=end,expires_ms=end+60000,entry_reference=price,entry_gap=gap,
   tail_low=stop if side<0 else stop+p['atr']*c['risk']['stop_buffer_atr'],tail_high=stop-p['atr']*c['risk']['stop_buffer_atr'] if side<0 else stop,
   leverage=lev,holding_rule=dict(mode='scalp',autonomous=True,fast_scalp=True,execution_frame='1m',frame='5m',ma_period=5,
     target=target,max_hold_seconds=settings(c)['max_hold_seconds'],zone=price,tolerance=p['atr']*.7,armed=False,source='AI 다봉 파동 판단'),
   decision_record=dict(strategy_logic='AI_WAVE',frames=p['frames'],reason=reason,target_source=plan.get('target_source',d['target_source']),direction=result['action']),
   signal_id=hashlib.sha256(f"aiwave:{p['symbol']}:{end}:{result['action']}".encode()).hexdigest()[:24])
 if plan.get('structure'):
  hit=plan['structure'];s['setup_frame']=plan['frame'];s['pattern']='ai_'+hit['pattern']
  s['signal_id']=hashlib.sha256(f"swing:{p['symbol']}:{plan['frame']}:{hit['second_ms']}:{result['action']}".encode()).hexdigest()[:24]
  s['decision_record']['swing_structure']=hit
  if plan['frame']!='1m':
   frame_atr=p['frames'][plan['frame']]['atr']
   s['holding_rule'].update(fast_scalp=False,swing_structure=hit,frame=plan['frame'],execution_frame=plan['frame'],zone=hit['second'],tolerance=frame_atr*.15,max_hold_seconds=plan['max_hold_seconds'],source=hit['pattern'])
 if plan.get('wave'):
  hit=plan['structure'];frame=plan['frame'];frame_atr=p['frames'][frame]['atr']
  if hit.get('ma_period'):s['holding_rule']['ma_period']=hit['ma_period']
  s['holding_rule'].update(wave=True,no_time_exit=True,zone=hit['wave_extreme'],tolerance=frame_atr*.15,source=hit['pattern']+' '+frame)
  s['tail_low']=hit['wave_extreme'] if side==1 else stop
  s['tail_high']=hit['wave_extreme'] if side==-1 else stop
  s['reason']=frame+' '+hit['pattern']+' 파동 / '+reason
 return s

def cadence_status(engine):
 now=engine.api.now_ms();session=engine.journal.data.get('session') or {}
 baseline=max(session.get('start_ms',now),engine.journal.data.get('auto_last_entry_fill_ms',0))
 elapsed=max(0,now-baseline);p=settings(engine.cfg)
 return dict(minutes_without_fill=round(elapsed/60000,1),review_due=elapsed>=p['review_due_seconds']*1000,
  target_minutes=p['review_due_seconds']/60,forced_entry=False,last_blocker=getattr(engine,'last_entry_blocker',''),
  review_interval_seconds=p['urgent_interval_seconds'] if elapsed>=p['review_due_seconds']*1000 else p['entry_interval_seconds'])

class AutonomousMixin:
 def _autonomous_candidate(self):
  p=settings(self.cfg);now=self.api.now_ms()
  from okx_double_retest import direct
  if now<getattr(self,'admission_retry_ms',0):return None
  if not direct(self.cfg) and now<self.journal.data.get('auto_next_entry_ms',0):return None
  if now%60000>40000:
   self.pipeline('signal_wait','다음1분 파동 갱신 대기: 만료 직전 유료 호출 방지');return None
  rows,error=self.universe.read()
  if not rows or time.monotonic()-rows['completed']>self.cfg['execution']['scan_max_age_seconds']:
   self.pipeline('scan','자율 스캘핑 후보 조회 지연 / '+str(error));return None
  if rows.get('turnover_scope'):
   if not rows.get('turnover_ready'):
    self.pipeline('scan','KST09 거래대금 순위 준비 중 / '+str(rows.get('turnover_error','')));return None
   rank_key=(rows.get('turnover_start_ms'),rows.get('turnover_observed_ms'))
   if getattr(self,'last_turnover_rank_key',None)!=rank_key:
    self.last_turnover_rank_key=rank_key
    self.log('KST09 거래대금 상위 '+str(len(rows.get('ranked_symbols',[])))+'개 안에서 진입 탐색 / 신호 후보 '+str(len(rows['rows']))+'개')
  self.stream.watch([r['symbol'] for r in rows['rows']]+[k for k,v in getattr(self,'entry_candidate_leases',{}).items() if 0<=now-v['ms']<=60000]+[r['symbol'] for r in self.records()]+(self.chat.watch() if hasattr(self,'chat') else []))
  available=[r for r in rows['rows'] if r['symbol'] not in self.blocked_manual_symbols() and not any(o['symbol']==r['symbol'] for o in self.records())]
  if not available:self.pipeline('signal_wait','자율 스캘핑 후보 없음 또는 수동/자동 보유 종목 제외');return None
  offset=getattr(self,'auto_cursor',0)%len(available);available=available[offset:]+available[:offset];packets=[];local_waits=[]
  for row in available:
   if not self.stream.ready(row['symbol'],self.cfg,now):
    local_waits.append(row['symbol']+' / 실시간 시세·호가 수신 대기');continue
   try:
    raw=self.chart_job(row['symbol'])
    if not raw:
     local_waits.append(row['symbol']+' / 완료봉 조회 대기');continue
    value=packet(row['symbol'],raw,self.cfg,now);value['leverage_cap']=min(value['leverage_cap'],int(float(row['instrument']['lever'])))
    if value['leverage_cap']<self.cfg['risk']['min_leverage']:continue
    if self.cfg['signals'].get('wave_mode',{}).get('enabled'):
     for action,direction in list(value['directions'].items()):
      eligible_plans=[]
      for plan in direction['stop_plans']:
       h=plan['structure'];sid=hashlib.sha256(f"swing:{row['symbol']}:{plan['frame']}:{h['second_ms']}:{action}".encode()).hexdigest()[:24]
       if row['symbol']+':'+sid not in self.journal.data.get('seen_signals',{}) and row['symbol']+':'+sid not in self.ai_reviewed:eligible_plans.append(plan)
      if eligible_plans:direction.update(stop_plans=eligible_plans,stop_options=[q['stop'] for q in eligible_plans])
      else:value['directions'].pop(action)
     if not value['directions']:
      local_waits.append(row['symbol']+' / 이미 검토·진입한 신호');continue
    # Initial margin stays one third: an AI leverage choice must fit the unchanged gross exposure cap.
    value['leverage_cap']=min(value['leverage_cap'],int(self.cfg['risk']['max_total_notional_fraction']/self.cfg['risk']['initial_margin_fraction']+1e-9))
    value['selection']={k:row.get(k) for k in ('mover_group','mover_rank','change','activity','turnover_rank','kst_turnover_usdt','turnover_start_ms')}
    if len(json.dumps(dict(mode='ENTRY',candidates=packets+[value]),ensure_ascii=False))>p['max_payload_chars']-1800:
     if packets:break
     for f in value['frames'].values():f['recent']=f['recent'][-4:]
     if len(json.dumps(value,ensure_ascii=False))>p['max_payload_chars']-1800:raise BotError('파동 구조 요약 크기 초과: 유료 호출 보류')
    packets.append(value)
   except BotError as e:local_waits.append(row['symbol']+' / '+str(e))
   if len(packets)>=p['batch_size']:break
  if not packets:
   reason=' | '.join(local_waits[:3]) or '검토 가능한 신규 구조 없음'
   emit_review(self,'로컬 검사 대기',dict(_packets=[dict(symbol=r['symbol']) for r in available]),reason)
   self.pipeline('signal_wait',reason);return None
  self.auto_cursor=offset+len(packets)
  return dict(symbol=packets[0]['symbol'],action='REVIEW',strategy='ai_wave_review',signal_id='review-'+str(now//60000),_packets=packets)

 def _autonomous_schedule(self,s):
  if not self.enabled or self.preview or self.recovering or self.entry_cancel.is_set() or not self.within_session():return False
  p=settings(self.cfg);now=self.api.now_ms()
  from okx_double_retest import direct,select_direct
  if now<getattr(self,'admission_retry_ms',0):return False
  if not direct(self.cfg) and now<self.journal.data.get('auto_next_entry_ms',0):return False
  from okx_execution_status import check_permissions
  try:
   snap=self.snapshot();check_permissions(snap['config']);self.risk_snapshot(snap)
   if not self.can_open_position() or self.margin_room(snap)<=0:raise BotError('증거금/보유 한도 대기')
  except Exception as e:
   emit_review(self,'AI 호출 전 대기',s,str(e))
   self.pipeline('preflight_rejected',review_names(s)+' / AI 호출 전 계정 점검: '+str(e)[:180]);return False
  from okx_entry_admission import admit
  s=admit(self,s)
  from okx_double_retest import settings as retest_settings
  self.admission_retry_ms=self.api.now_ms()+retest_settings(self.cfg)['retry_seconds']*1000
  local=select_direct(self,s)
  if local:
   self.approval_result=local;return True
  if now<self.journal.data.get('auto_next_entry_ms',0):return False
  if not s['_packets']:
   self.journal.data['auto_next_entry_ms']=self.api.now_ms()+30000;self.journal.save()
   self.pipeline('preflight_rejected','AI 호출 없음 / 주문 가능한 사전검사 계획 없음');return False
  cadence=cadence_status(self)
  interval=p['urgent_interval_seconds'] if cadence['review_due'] else p['entry_interval_seconds']
  self.journal.data['auto_next_entry_ms']=now+interval*1000;self.journal.save()
  self.approval_signal=s;self.approval_epoch=self.epoch
  self.approval=self.approval_pool.submit(self.autonomous_call,dict(mode='ENTRY',candidates=s['_packets'],review_due=cadence['review_due'],minutes_without_fill=cadence['minutes_without_fill'],last_blocker=getattr(self,'last_entry_blocker','')[:200]),self.epoch)
  emit_review(self,'AI 검토 중',s,'롱·숏·대기와 배율 판단 요청')
  self.pipeline('ai_pending',review_names(s)+' / AI가 파동을 비교해 롱·숏·대기와 배율 선택 중',count='ai_requests');return True

 def autonomous_call(self,payload,epoch):
  from openai import OpenAI
  p=settings(self.cfg)
  def clean(x):
   if isinstance(x,float):return float(format(x,'.7g'))
   if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
   if isinstance(x,list):return [clean(v) for v in x]
   return x
  text=json.dumps(clean(payload),ensure_ascii=False,separators=(',',':'),allow_nan=False)
  if len(text)>p['max_payload_chars']:raise BotError('자율 AI 자료 크기 초과: 유료 호출 없음')
  from okx_model_runtime import enabled as model_enabled,request as model_request
  if model_enabled(self.cfg):
   out=model_request(self,payload,INSTRUCTIONS,SCHEMA,'auto_entry' if payload.get('mode')=='ENTRY' else 'auto_manage',epoch)
   if (set(out)-{'cost','reserved','billing_day','completed','accounted'}!=set(SCHEMA['required']) or out.get('action') not in SCHEMA['properties']['action']['enum'] or type(out.get('leverage')) is not int or type(out.get('stop_index')) is not int or not isinstance(out.get('symbol'),str) or not isinstance(out.get('reason'),str) or not out['reason'].strip()):raise BotError('자율 AI 응답 형식 오류')
   return out
  reserved=(len(text.encode())+len(INSTRUCTIONS.encode())+4096)*.4/1e6+p['max_output_tokens']*1.6/1e6
  day=self.reserve_api(reserved,epoch)
  client=OpenAI(api_key=self.settings.get('OPENAI_API_KEY'),max_retries=0,timeout=15)
  r=client.responses.create(model='gpt-4.1-mini',max_output_tokens=p['max_output_tokens'],instructions=INSTRUCTIONS,input=text,
   text={'format':{'type':'json_schema','name':'wave','strict':True,'schema':SCHEMA}})
  out=json.loads(r.output_text)
  if set(out)!=set(SCHEMA['required']) or out['action'] not in SCHEMA['properties']['action']['enum'] or not isinstance(out['symbol'],str) or not isinstance(out['reason'],str) or not out['reason'].strip() or type(out['leverage']) is not int or type(out['stop_index']) is not int:raise BotError('자율 AI 응답 형식 오류')
  out.update(cost=r.usage.input_tokens*.4/1e6+r.usage.output_tokens*1.6/1e6,reserved=reserved,billing_day=day,completed=time.monotonic());return out

 def autonomous_account(self,result):
  if result.get('accounted'):return
  delta=result['cost']-result['reserved'];self.journal.data['api_total_spent']+=delta
  if result['billing_day']==self.journal.data['api_day']:self.journal.data['api_spent']+=delta
  self.journal.save()

 def _autonomous_process(self):
  if not self.approval or not self.approval.done():return
  future=self.approval;review=self.approval_signal;epoch=self.approval_epoch
  self.approval=None;self.approval_signal=None
  try:
   result=future.result();self.autonomous_account(result)
   if epoch!=self.epoch or not self.enabled or self.recovering or self.entry_cancel.is_set() or not self.within_session():raise BotError('AI 판단 중 운용·연결 상태 변경')
   if result['action']=='WAIT':
    emit_review(self,'AI 대기',review,result['reason'])
    self.pipeline('signal_wait',review_names(review)+' / 자율 AI 대기: '+result['reason'],count='ai_wait');return
   p=next((v for v in review['_packets'] if v['symbol']==result['symbol']),None)
   if not p:raise BotError('AI가 감시 후보 외 종목 선택')
   review=dict(_packets=[p]);emit_review(self,'진입 선택 '+result['action'],review,result['reason'])
   self.pipeline('preflight',p['symbol']+' / AI 진입 선택 '+result['action']+' / '+result['reason'],count='ai_selected')
   s=make_signal(result,p,self.cfg)
   self.pipeline('preflight',s['symbol']+' / 자율 진입 신호 확인',count='signals')
   if self.api.now_ms()>s['expires_ms']-5000:raise BotError('AI 판단 후1분 파동 신호 만료 임박')
   self.auto_frozen=s
   from okx_ai_cost import precheck
   receipt=precheck(self,s);fresh=receipt.pop('_fresh_signal',s)
   self.approval_result=dict(fresh,_ai_precheck=receipt)
   self.ai_reviewed[s['symbol']+':'+s['signal_id']]=True
   self.notify('AI 승인',s['symbol']+' / '+s['action']+' / '+str(s['leverage'])+'배 / '+s['setup_frame']+' '+s['pattern']+'\n'+s['reason']+'\n손절 '+str(s['stop'])+' / 목표 '+str(s['target'])+'\n주문 전 점검 통과. 최종 재검증 후 주문하며 체결을 보장하지 않습니다.',state=s['symbol']+':'+s['signal_id'])
   self.pipeline('approved',s['symbol']+' / 자율 '+s['action']+' / '+str(s['leverage'])+'배 / '+s['reason'],count='ai_approved')
  except Exception as e:
   self.approval_result=None;self.pipeline('preflight_rejected',review_names(review)+' / 자율 진입 대기: '+str(e)[:250])
   emit_review(self,'주문 점검 대기',review,str(e))

 def _autonomous_context(self,symbol,action):
  frozen=getattr(self,'executing_signal',None) or getattr(self,'auto_frozen',None)
  if not frozen or not frozen.get('autonomous'):raise BotError('자율 확정 계획 없음')
  if frozen['symbol']!=symbol or frozen['action']!=action:raise BotError('자율 신호 종목/방향 불일치')
  if symbol in self.blocked_manual_symbols():raise BotError('수동 포지션/주문 종목 제외')
  self.selection_row(symbol);bars=self.fresh_bars(symbol);now=self.api.now_ms()
  if not bars.get('1m') or bars['1m'][-1][0]+60000!=now//60000*60000:raise BotError('자율 최신1분 마감 데이터 대기')
  from okx_wick import check_entry
  price=bars['1m'][-1][4]
  if frozen.get('selected_ai_order'):
   quote=self.stream.read(symbol,'tickers',15,now)
   if not isinstance(quote,dict):quote=self.api.public('/api/v5/market/ticker',instId=symbol)[0]
   price=float(quote.get('last') or (float(quote['bidPx'])+float(quote['askPx']))/2)
  check_entry(frozen,now,price)
  if symbol+':'+frozen['signal_id'] in self.journal.data['seen_signals']:raise BotError('자율 확정 신호 중복 주문 차단')
  self.signal_prepared_monotonic=time.monotonic();self.prepared_signal=frozen
  from okx_market import summarize
  out={bar:summarize(b) if len(b)>=60 else None for bar,b in bars.items()};out['_v4']=copy.deepcopy(frozen);return out

 def autonomous_manage(self,snapshot,position,owned):
  if not (owned.get('holding_rule') or {}).get('autonomous'):return False
  task=getattr(self,'auto_manage_task',None)
  if task and task['future'].done() and task['client_id']==owned['client_id']:
   self.auto_manage_task=None
   try:
    result=task['future'].result();self.autonomous_account(result)
    if task['epoch']!=self.epoch or not self.enabled or self.recovering or not self.account_stream.fresh() or not self.stream.ready(owned['symbol'],self.cfg,self.api.now_ms()) or time.monotonic()-result['completed']>30 or task['quantity']!=position['pos']:raise BotError('보유 판단 후 상태/수량/연결 변경')
    if result['symbol']!=owned['symbol'] or result['action'] not in ('HOLD','CLOSE','PARTIAL'):raise BotError('자율 보유 응답 불일치')
    from okx_dynamic_exit import enabled as dynamic_enabled,evaluate as dynamic_evaluate
    if dynamic_enabled(self.cfg) and result['action'] in ('CLOSE','PARTIAL'):
     verdict=dynamic_evaluate(self.chart_job(owned['symbol']) or {},position,owned,self.cfg,self.api.now_ms())
     if verdict['action']!=result['action']:
      self.log(owned['symbol']+' / 추세 보유: AI 청산 제안은 구조·위험 대비 수익 검증 미충족');return False
    if result['action']=='PARTIAL':
     from okx_dynamic_exit import ai_partial_allowed
     if not ai_partial_allowed(self.chart_job(owned['symbol']) or {},position,owned,self.cfg,self.api.now_ms()):
      self.log(owned['symbol']+' / 부분 익절 보류: ROE 기준·강한 추세 또는 완료 데이터 확인');return False
    self.log(owned['symbol']+' / 자율 보유 판단 '+result['action']+' / '+result['reason'])
    if result['action'] in ('CLOSE','PARTIAL') and (owned.get('holding_rule') or {}).get('wave'):
     from okx_wave_mode import ai_exit_allowed
     if not ai_exit_allowed(self.chart_job(owned['symbol']) or {},position,owned,self.cfg,self.api.now_ms(),result['action']):
      self.log('파동 보유 유지: 기준 시간봉의 반전/붕괴 미확인 또는 비용 차감 수익 부족');return False
    if result['action']=='CLOSE':self.close(snapshot,'자율 파동 종료: '+result['reason']);return True
    if result['action']=='PARTIAL' and float(position['uplRatio'])>0 and not owned.get('partial_used') and not owned.get('partial_unsplittable'):
     self.partial_close(snapshot,'자율 수익 파동 약화: '+result['reason'],fraction=self.cfg['risk']['dynamic_exit']['partial_fraction']);return True
   except Exception as e:self.log('자율 보유 판단 대기 / '+str(e)[:180])
  # Retire a completed task belonging to an already closed position.
  task=getattr(self,'auto_manage_task',None)
  if task and task['future'].done() and not any(o['client_id']==task['client_id'] for o in self.records()):
   self.auto_manage_task=None
   try:self.autonomous_account(task['future'].result())
   except Exception:pass
  now=self.api.now_ms();p=settings(self.cfg)
  if not enabled(self.cfg) or not self.enabled or self.recovering or self.preview or self.entry_cancel.is_set() or getattr(self,'auto_manage_task',None) or self.approval:return False
  if self.cfg['execution'].get('budget_pacing',{}).get('enabled'):
   timers=self.journal.data.setdefault('auto_next_manage',{})
   if owned['client_id'] not in timers:
    timers[owned['client_id']]=owned.get('entry_ms',now)+p['manage_interval_seconds']*1000;self.journal.save()
  if now<self.journal.data.get('auto_next_manage',{}).get(owned['client_id'],0):return False
  if not self.stream.ready(owned['symbol'],self.cfg,now):return False
  bars=self.chart_job(owned['symbol'])
  if not bars:return False
  try:context=packet(owned['symbol'],bars,self.cfg,now)
  except BotError:return False
  self.journal.data.setdefault('auto_next_manage',{})[owned['client_id']]=now+p['manage_interval_seconds']*1000;self.journal.save()
  payload=dict(mode='MANAGE',context=context,position={k:position.get(k) for k in ('instId','posSide','avgPx','markPx','uplRatio','pos')},stop=owned['stop_px'],holding_rule=owned.get('holding_rule',{}),partial_used=bool(owned.get('partial_used')))
  self.auto_manage_task=dict(client_id=owned['client_id'],quantity=position['pos'],epoch=self.epoch,future=self.approval_pool.submit(self.autonomous_call,payload,self.epoch))
  return False

"""Double-top/bottom waves; timeframe structure sets invalidation, not minute noise."""
DEFAULTS=dict(enabled=True,frames=['5m','15m','1H','4H'],stop_buffer_atr=.5,min_net_reward_risk=2.)

def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('wave_mode',{}))
def enabled(c):return c.get('signals',{}).get('wave_mode',{}).get('enabled',False)
def validate(p):return type(p['enabled']) is bool and bool(p['frames']) and set(p['frames'])<=set(('5m','15m','1H','4H')) and len(set(p['frames']))==len(p['frames']) and .25<=p['stop_buffer_atr']<=2 and .4<=p['min_net_reward_risk']<=5

def plans(structures,summary,action,price,c):
 p=settings(c);side=1 if action=='LONG' else -1;out=[]
 for frame,hits in structures.items():
  hit=hits.get(action)
  if c['execution'].get('structure_runner_revision_v638'):
   trend=summary.get('15m') or {}
   if not trend or trend.get('trend')==('downtrend' if side==1 else 'uptrend'):continue
  allowed={('double_bottom' if side==1 else 'double_top')}
  if c['signals'].get('trend_entry',{}).get('enabled'):allowed.add('trend_support' if side==1 else 'trend_resistance')
  if frame not in p['frames'] or not hit or hit['pattern'] not in allowed:continue
  extreme=min(hit['first'],hit['second']) if side==1 else max(hit['first'],hit['second'])
  atr=summary[frame]['atr'];buffer=p['stop_buffer_atr']
  if hit['pattern'].startswith('trend_'):
   from okx_trend_entry import settings as trend_settings
   buffer=trend_settings(c)['stop_buffer_atr']
  stop=extreme-side*atr*buffer
  if stop<=0 or (price-stop)*side<=0:continue
  structure=dict(hit,stop=stop,wave_extreme=extreme)
  plan=dict(frame=frame,stop=stop,source=hit['pattern'],structure=structure,wave=True,max_hold_seconds=hit['max_hold_seconds'])
  if hit.get('target'):plan.update(target=hit['target'],target_source=hit['target_source'])
  out.append(plan)
 return out

def net_profitable(position,owned):
 entry=float(position.get('avgPx') or 0);mark=float(position.get('markPx') or 0);side=1 if owned['direction']=='long' else -1
 return entry>0 and (mark/entry-1)*side>float(owned.get('cost_rate') or .003)

def ai_exit_allowed(frames,position,owned,c,now,action):
 rule=owned.get('holding_rule') or {}
 if action=='PARTIAL':
  from okx_dynamic_exit import ai_partial_allowed
  if not ai_partial_allowed(frames,position,owned,c,now):return False
 if not rule.get('wave'):return True
 side=1 if owned['direction']=='long' else -1
 if action=='PARTIAL' and (float(position['markPx'])-rule['target'])*side>=0:return net_profitable(position,owned)
 from okx_swing_context import STEPS
 frame=rule['frame'];step=STEPS[frame];b=[r for r in frames.get(frame,[]) if r[0]+step<=now]
 if len(b)<max(c['indicators']['ma_periods'])+3 or now-(b[-1][0]+step)>=step or b[-1][0]+step<=owned.get('entry_ms',now):return False
 from okx_rules import metrics
 atr=metrics(b,c)['atr'];prev,last=b[-2:]
 adverse=(last[4]-prev[4])*side < -.2*atr
 structure=(last[3]-prev[3])*side<0 if side==1 else (last[2]-prev[2])*side<0
 broken=(last[4]-rule['zone'])*side < -rule['tolerance']
 return bool((broken or (adverse and structure)) and (action!='PARTIAL' or net_profitable(position,owned)))

"""Causal peak -> pullback -> failed rebound, mirrored for support longs.

Only completed bars identify pivots. This is an explicit approximation of the
user's annotated example, not proof of a profitable pattern.
"""
import math

DEFAULTS=dict(enabled=True,lookback=60,pivot_gap_min=3,pivot_gap_max=36,
 impulse_lookback=12,impulse_atr=2.,middle_move_atr=.5,rebound_atr=.5,
 peak_tolerance_atr=.25,rejection_atr=.25,ma_zone_atr=.75,ma_reclaim_tolerance_atr=.15,
 signal_life_bars=6,stop_buffer_atr=.35)
def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('flow_structure',{}))
def validate(p):
 return (type(p['enabled']) is bool and all(type(p[k]) is int for k in ('lookback','pivot_gap_min','pivot_gap_max','impulse_lookback','signal_life_bars'))
  and 30<=p['lookback']<=120 and 2<=p['pivot_gap_min']<p['pivot_gap_max']<=60
  and 5<=p['impulse_lookback']<=30 and 1<=p['signal_life_bars']<=12
  and 1<=p['impulse_atr']<=6 and .2<=p['middle_move_atr']<=3
  and .2<=p['rebound_atr']<=3 and 0<=p['peak_tolerance_atr']<=1
  and 0<=p['ma_reclaim_tolerance_atr']<=1 and .1<=p['rejection_atr']<=2 and .1<=p['ma_zone_atr']<=2 and .1<=p['stop_buffer_atr']<=2)
def atr(b):
 values=[max(r[2]-r[3],abs(r[2]-a[4]),abs(r[3]-a[4])) for a,r in zip(b[:-1],b[1:])]
 return sum(values[-14:])/14
def analyse(b,frame,c):
 p=settings(c)
 if not p['enabled'] or len(b)<max(30,p['impulse_lookback']+5):return []
 if any(len(r)<6 or not all(math.isfinite(float(x)) for x in r[:6]) or r[3]>min(r[1],r[4]) or max(r[1],r[4])>r[2] for r in b):return []
 result=[]
 for side in (-1,1):
  # In canonical coordinates both sides are a failed rebound from a peak.
  g=1 if side==-1 else -1
  q=[[r[0],g*r[1],max(g*r[2],g*r[3]),min(g*r[2],g*r[3]),g*r[4],r[5]] for r in b]
  a=atr(q[:-1])
  if a<=0:continue
  start=max(1,len(q)-p['lookback']);pivots=[]
  for j in range(start,len(q)-1):
   if q[j][2]>q[j-1][2] and q[j][2]>=q[j+1][2]:pivots.append(j)
  for second in reversed(pivots):
   if len(q)-1-second>p['signal_life_bars']:break
   for first in reversed([j for j in pivots if p['pivot_gap_min']<=second-j<=p['pivot_gap_max']]):
    anchor,peak=q[first],q[second];middle=q[first+1:second]
    before=q[max(0,first-p['impulse_lookback']):first]
    if len(before)<p['impulse_lookback'] or not middle:continue
    impulse=anchor[2]-min(r[3] for r in before)
    if impulse<a*p['impulse_atr']:continue
    floor=min(r[3] for r in middle)
    if anchor[2]-floor<a*p['middle_move_atr'] or peak[2]-floor<a*p['rebound_atr']:continue
    if peak[2]>anchor[2]+a*p['peak_tolerance_atr']:continue
    # A higher close after the second peak invalidates the already-known rejection.
    after=q[second+1:]
    if any(r[4]>peak[2]+a*p['peak_tolerance_atr'] for r in after):continue
    last=q[-1]
    if peak[2]-last[4]<a*p['rejection_atr']:continue
    if not (last[4]<last[1] or last[4]<q[-2][4]):continue
    # Historical MA per tested bar, never today's MA projected into earlier bars.
    tests=[]
    for j in range(second,len(q)):
     for n in c['indicators']['ma_periods']:
      if n>50 or j+1<n:continue
      average=sum(r[4] for r in q[j-n+1:j+1])/n
      if q[j][3]<=average+a*p['ma_zone_atr'] and q[j][2]>=average-a*p['ma_zone_atr']:
       tests.append((j,n,average))
    periods=sorted(set(n for j,n,avg in tests))
    if not periods:continue
    current_ma={n:sum(r[4] for r in q[-n:])/n for n in periods}
    if not any(last[4]<=v+a*p['ma_reclaim_tolerance_atr'] for v in current_ma.values()):continue
    # Do not chase a move already through the observed intermediate target.
    price=g*last[4];target=g*floor;stop=g*(peak[2]+a*p['stop_buffer_atr'])
    if (target-price)*side<=0 or (price-stop)*side<=0 or min(price,target,stop)<=0:continue
    peak_volume=sum(r[5] for r in q[max(0,first-1):first+2])/3
    rebound_volume=sum(r[5] for r in q[max(first+1,second-1):second+2])/len(q[max(first+1,second-1):second+2])
    result.append(dict(side=side,frame=frame,first_ms=anchor[0],second_ms=peak[0],
     confirmed_ms=q[second+1][0]+{'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}[frame],first_extreme=g*anchor[2],second_extreme=g*peak[2],
     middle_level=target,stop=stop,target=target,atr=a,ma_periods=periods,
     impulse_atr=impulse/a,rebound_volume_vs_first=rebound_volume/peak_volume if peak_volume>0 else None,
     reason=('고점 형성→낮은/비슷한 재상승 고점→이평 저항·반등 약화' if side==-1 else '저점 형성→높은/비슷한 재하락 저점→이평 지지·하락 약화')))
    break
   if any(r['side']==side for r in result):break
 return result

"""Explicit PC/mobile order commands, processed only by the serialized engine worker."""
import copy,hashlib,math,re,time,uuid
from okx_entry_gate720 import gate
from okx_core import BotError,Rejected,UnknownOutcome,dec

def close_key(record=None,position=None):
    if record:return hashlib.sha256(('owned:'+record['client_id']).encode()).hexdigest()[:24]
    p=position or {}
    if not p.get('posId'):return None
    return hashlib.sha256('|'.join(str(p.get(k,'')) for k in ('instId','posSide','posId','cTime')).encode()).hexdigest()[:24]

def check(e,s,price):
    now=e.api.now_ms()
    if not s.get('click716') or s['signal_id']!=getattr(e,'click_authorized_signal716',None):raise BotError('직접 진입 요청 인증 불일치')
    if not s['valid_from_ms']<=now<=s['expires_ms']:raise BotError('직접 진입 요청 만료')
    side=1 if s['action']=='LONG' else -1
    if not math.isfinite(float(price)) or (float(price)-s['stop'])*side<=0:raise BotError('직접 진입 시세/손절 유효성 오류')
    return s['decision_record']['volume_wick_proof']

def quote(e,symbol):
    """Use a fresh ticker immediately; no dependency on trades/mark subscriptions."""
    def valid(q):
        try:
            return (isinstance(q,dict) and 0<=e.api.now_ms()-int(q['ts'])<=3000
                    and math.isfinite(float(q['last'])) and float(q['last'])>0)
        except (KeyError,ValueError,TypeError,OverflowError):return False
    q=e.stream.read(symbol,'tickers',3,e.api.now_ms())
    if valid(q):return q
    data=e.api.public('/api/v5/market/ticker',instId=symbol)
    q=data[0] if data else None
    if not valid(q):raise BotError('직접 진입 가격 조회 지연/오류 · 주문하지 않았습니다.')
    return q

def signal(e,symbol,action):
    from okx_band_flow import rows,atr
    from okx_channel701 import closed,packet,make_signal,STEP
    instrument=e.api.public('/api/v5/public/instruments',instType='SWAP',instId=symbol)[0]
    from okx_pattern15 import allowed,leverage
    if instrument.get('instId')!=symbol or not allowed(instrument,e.cfg) or instrument.get('state')!='live' or float(instrument.get('lever') or 0)<5:raise BotError('5배 운용 가능한 USDT 선물이 아닙니다.')
    candles=e.api.public('/api/v5/market/candles',instId=symbol,bar='15m',limit='300')
    now=e.api.now_ms()
    b=closed(rows(candles,'15m',now),now)
    q=quote(e,symbol);now=e.api.now_ms()
    price=float(q['last']);a=atr(b);side=1 if action=='LONG' else -1;stop=price-side*2*a
    if not math.isfinite(a) or a<=0 or stop<=0:raise BotError('최초2ATR 손절 산정 불가')
    p=packet(dict(symbol=symbol,instrument=instrument,live_frames={'15m':b}),e.cfg,now,q)
    v=dict(setup='channel20_10',action=action,confirmation_ms=b[-1][0],structural_stop=stop,reference=price,atr=a,evidence704={'score':0})
    p['entry_setups']=[v]
    # Construct a compatible order envelope without claiming a breakout happened.
    s=make_signal(dict(action=action),p,e.cfg,b[-1][0]+STEP,manual=True)
    s.update(click716=True,leverage=5,signal_id='click716-'+uuid.uuid4().hex[:22],valid_from_ms=now,expires_ms=now+15000,at_ms=now,
             reason='사용자 직접 '+('롱' if side==1 else '숏')+' 버튼 · 시드1/4 수량 · 자동 신호 조건 미사용',regime='사용자 직접 진입')
    s['decision_record']['source']='USER_CLICK716'
    s['decision_record']['volume_wick_proof']=dict(v,setup='manual_click716')
    s['selection']['origin']='USER_CLICK716'
    return s

def result(e,r,status,message):
    e.events.put(('click_result',dict(request_id=r.get('request_id'),op=r.get('op'),status=status,message=message,entry_gate=gate(e))))
    if r.get('owner'):
        e.events.put(('mobile_control_result',dict(request_id=r['request_id'],owner=r['owner'],op=r.get('op'),status=status,message=message,entry_gate=gate(e))))
    e.log(message)

def accept(e,r):
    now=time.monotonic()
    if not 0<=now-r.get('issued_at',0)<=15:raise BotError('버튼 요청이 만료됐습니다. 화면을 새로고침하세요.')
    seen=e.journal.data.setdefault('click_requests716',{})
    rid=r.get('request_id','')
    if not re.fullmatch(r'[A-Za-z0-9_-]{12,80}',rid):raise BotError('요청 식별자 오류')
    if rid in seen:return
    if r.get('op') not in ('entry','close_one','close_all'):raise BotError('주문 종류 오류')
    if r['op']=='close_all':
        return close_all(e,r,seen)
    if r['op']=='entry':
        if getattr(e,'click_pending716',None):raise BotError('앞선 직접 진입 처리 중입니다.')
        g=gate(e)
        if not g['allowed']:raise BotError('['+g['code']+'] '+g['reason'])
        symbol=r.get('symbol','');action=r.get('direction')
        if not re.fullmatch(r'[A-Z0-9]+-USDT-SWAP',symbol) or action not in ('LONG','SHORT'):raise BotError('종목/방향 오류')
        e.snapshot()
        if not e.can_open_position() or symbol in {o['symbol'] for o in e.records()} or symbol in e.blocked_manual_symbols():raise BotError('최대4개 한도 또는 동일 종목 보유/주문 중')
        seen[rid]=dict(at=e.api.now_ms(),op='entry');e.journal.save()
        e.click_pending716=dict(r,deadline=time.monotonic()+20)
        e.stream.watch([symbol]+[o['symbol'] for o in e.records()]+e.chat.watch())
        result(e,r,'queued','직접 진입 요청 접수 · 가격·손절·계정 확인 중')
        # Already in the serialized worker: process before the next full strategy scan.
        return poll(e)
    # Closing is permitted while entries are paused. It never changes another slot.
    e.snapshot();raw=e.raw_snapshot;key=r.get('key')
    for slot in range(e.slot_count()):
        with e.selected(slot):
            o=e.journal.data['owned']
            if o and close_key(record=o)==key:
                seen[rid]=dict(at=e.api.now_ms(),op='close_one');e.journal.save()
                e.close(e.snapshot(),'사용자 개별 전량 청산 버튼')
                result(e,r,'submitted','선택 포지션 전량 청산 요청 · 체결 확인 중');return
    p=next((p for p in raw['positions'] if close_key(position=p)==key and dec(p.get('pos') or 0)>0),None)
    if not p:raise BotError('선택 포지션이 변경됐거나 이미 종료됐습니다.')
    if p.get('posSide') not in ('long','short') or p.get('mgnMode') not in ('isolated','cross') or not p['instId'].endswith('-USDT-SWAP'):raise BotError('수동 포지션 모드 확인 필요')
    pending=e.journal.data.setdefault('manual_closes716',{})
    if key in pending:raise BotError('이미 해당 포지션 청산 확인 중입니다. 중복 주문하지 않습니다.')
    cid='MC716'+uuid.uuid4().hex[:26]
    pending[key]=dict(symbol=p['instId'],direction=p['posSide'],posId=p['posId'],client_id=cid,at=e.api.now_ms())
    seen[rid]=dict(at=e.api.now_ms(),op='close_one');e.journal.save()
    e.api.post('/api/v5/trade/order',dict(instId=p['instId'],tdMode=p['mgnMode'],posSide=p['posSide'],side='sell' if p['posSide']=='long' else 'buy',sz=str(p['pos']),ordType='market',clOrdId=cid))
    result(e,r,'submitted','선택 수동 포지션 전량 청산 요청 · 체결 확인 중')

def poll(e):
    # Observe external close results, preserving unknown writes across restarts.
    pending=e.journal.data.get('manual_closes716',{})
    raw=e.raw_snapshot or {}
    for key,task in list(pending.items()):
        p=next((p for p in raw.get('positions',[]) if str(p.get('posId'))==str(task['posId']) and dec(p.get('pos') or 0)>0),None)
        if not p:
            first=task.get('flat_ms')
            if first is None:task['flat_ms']=e.api.now_ms();e.journal.save()
            elif e.api.now_ms()-first>=1000:pending.pop(key);e.journal.save();e._search_resume_requested=True;e.log(task['symbol']+' / 개별 수동 청산 잔량0 확인')
    r=getattr(e,'click_pending716',None)
    if not r:return False
    try:
        if time.monotonic()>r['deadline']:raise BotError('시세 자료 준비 시간 초과 · 주문하지 않았습니다. 다시 선택하세요.')
        g=gate(e)
        if not g['allowed']:raise BotError('['+g['code']+'] '+g['reason'])
        e.click_pending716=None
        if not e.can_open_position():raise BotError('포지션4개 한도')
        s=signal(e,r['symbol'],r['direction'])
        if time.monotonic()>r['deadline']:raise BotError('직접 진입 자료 조회 시간 초과 · 주문하지 않았습니다.')
        e.click_authorized_signal716=s['signal_id']
        with e.selected(e.empty_slot()):
            try:e.executing_signal=s;e.entry(s)
            finally:e.executing_signal=None;e.click_authorized_signal716=None
        if any(o.get('v4_signal',{}).get('signal_id')==s['signal_id'] for o in e.records()):result(e,r,'submitted','직접 진입 주문 요청 · 실제 체결/보호SL 확인 중')
        else:raise BotError('직접 진입이 제출되지 않았습니다. 잔고/포지션 상태를 확인하세요.')
    except Exception as ex:
        e.click_pending716=None
        result(e,r,'failed',('주문 결과 미확인 · 재클릭 금지·계정 확인' if isinstance(ex,UnknownOutcome) else str(ex) if isinstance(ex,BotError) else '직접 진입 처리 오류 · 계정 확인'))
        if isinstance(ex,UnknownOutcome):raise
    return True


def close_all(e,r,seen):
    # Snapshot the targets once, pause new entries, and reuse exact-position close paths.
    e.handle('pause',{});e.mobile_entry_pause=True;e.click_pending716=None
    e.snapshot()
    owned=list(e.records());keys=[close_key(record=o) for o in owned]
    pairs={(o['symbol'],o['direction']) for o in owned}
    keys += [close_key(position=p) for p in e.raw_snapshot['positions']
             if dec(p.get('pos') or 0)>0 and (p.get('instId'),p.get('posSide')) not in pairs
             and p.get('instId','').endswith('-USDT-SWAP')]
    keys=[k for k in keys if k]
    seen[r['request_id']]=dict(at=e.api.now_ms(),op='close_all');e.journal.save()
    errors=[]
    for n,key in enumerate(keys):
        child=dict(op='close_one',key=key,request_id=hashlib.sha256((r['request_id']+':'+str(n)).encode()).hexdigest(),issued_at=time.monotonic())
        try:accept(e,child)
        except Exception as ex:errors.append(str(ex) if isinstance(ex,BotError) else type(ex).__name__)
    result(e,r,'failed' if errors else 'submitted',
           '전체 청산 요청 '+str(len(keys))+'개 · 신규 진입 중지 · 실제 잔량 확인 필요'+(' / 처리 보류: '+'; '.join(errors) if errors else ''))

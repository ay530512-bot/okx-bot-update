"""Journaled scale-in state machine. No blind write retries or unprotected size doubling."""
import time
import uuid
from okx_core import (BotError, Rejected, dec, fmt, owned_position, size_plan, protective_order)
from okx_scale import legs_for, eligible_additions, tightened_stop
from okx_market import closed_candles, summarize, allowed_altcoin
from okx_strategy import load_frames, verified_altcoin


class Additions:
    def scale(self, action):
        owned = self.journal.data["owned"]
        if (not self.enabled or self.entry_cancel.is_set() or not owned or owned["phase"] != "active"
                or (self.journal.data["day"] and self.journal.data["day"]["ended"])):
            return
        snapshot = self.snapshot()
        position = owned_position(owned, snapshot["positions"])
        if not position or snapshot["orders"]:
            raise BotError("추가 진입 전 포지션/주문 확인 실패")
        if self.margin_room(snapshot) <= 0:
            self.log("공용 증거금 한도 도달. 물타기/불타기를 보류합니다.")
            return
        _, other = self.algos(full=True)
        if other:
            raise BotError("추가 진입 전 기존 조건주문 발견")
        symbol, leverage = owned["symbol"], owned["leverage"]
        market = {"frames": self.addition_frames(symbol) if hasattr(self, "addition_frames") else load_frames(self.api, symbol)}
        if action not in (self.addition_allowed(owned, position, market) if hasattr(self, "addition_allowed") else eligible_additions(owned, position, market)):
            self.log("최신 차트/수익률이 추가 진입 조건을 충족하지 않아 생략합니다.")
            return
        instrument = self.api.public("/api/v5/public/instruments", instType="SWAP", instId=symbol)[0]
        if not (self.is_allowed_instrument(instrument) if hasattr(self, "is_allowed_instrument") else verified_altcoin(self.api, instrument)):
            raise BotError("추가 진입 종목 상태 변경")
        ticker = self.api.public("/api/v5/market/ticker", instId=symbol)[0]
        if not 0 <= self.api.now_ms() - int(ticker["ts"]) <= 10000:
            raise BotError("추가 진입 호가가 오래됐습니다.")
        fee = self.api.taker_fee(instrument)
        seed = dec(owned["entry_seed"])
        band=owned.get('v4_signal',{}).get('strategy')=='band_flow'
        remaining = seed * (1 if band else dec(2)/3) - dec(owned['committed_margin'])
        if remaining <= 0:
            raise BotError("추가 진입 최대 증거금 도달")
        plan = size_plan(instrument, seed, snapshot["available"], leverage,
                         ticker["bidPx"], ticker["askPx"], fee, margin_cap=self.addition_margin_cap(snapshot, market, fee) if hasattr(self, "addition_margin_cap") else min(seed / 6, remaining, self.margin_room(snapshot)),band_flow=band,initial_fraction=1 if owned.get('v4_signal',{}).get('free_ai') else None)
        if hasattr(self, "prepare_add_plan"):
            plan = self.prepare_add_plan(plan, instrument, ticker, market, snapshot, position, fee)
        limits = self.api.get("/api/v5/account/max-size", instId=symbol, tdMode="isolated", leverage=str(leverage))[0]
        if dec(plan["quantity"]) > dec(limits["maxBuy"] if owned["direction"] == "long" else limits["maxSell"]):
            raise BotError("계정의 추가 진입 가능 수량 부족")
        lever_rows = self.api.get("/api/v5/account/leverage-info", instId=symbol, mgnMode="isolated")
        if not any(row.get("posSide") == owned["direction"] and dec(row.get("lever")) == leverage for row in lever_rows):
            raise BotError("추가 진입 레버리지 불일치")
        fresh = self.snapshot()
        position = owned_position(owned, fresh["positions"])
        if not position or action not in (self.addition_allowed(owned, position, market) if hasattr(self, "addition_allowed") else eligible_additions(owned, position, market)):
            self.log("추가 진입 직전 조건이 바뀌어 생략합니다.")
            return
        if self.entry_cancel.is_set() or not self.enabled:
            return
        if hasattr(self, "final_add_check"):
            self.final_add_check(fresh, plan, market)
        session = self.journal.data.get("session")
        if session and not session.get('continuous') and self.api.now_ms() >= session["end_ms"]:
            return
        # Keep existing protection in place. New contracts get their own attached stop.
        pending = {"kind": action, "quantity": plan["quantity"],
                   "client_id": "OA" + uuid.uuid4().hex[:28], "algo_client_id": "OS" + uuid.uuid4().hex[:28],
                   "stop_px": owned["stop_px"], "margin": plan["margin_bound"],
                   "prior_quantity": owned["quantity"], "prior_average_px": position["avgPx"],
                   "planned_entry_px": plan["buy" if owned["direction"]=="long" else "sell"],
                   "fee": fmt(fee), "started_ms": self.api.now_ms(), "entry_order_type": "market"}
        owned["legs"] = legs_for(owned)
        owned["pending_add"], owned["phase"] = pending, "adding"
        self.journal.save()
        self.invalidate()
        plan[owned["direction"] + "_stop"] = owned["stop_px"]
        body = protective_order(symbol, owned["direction"], leverage, plan, pending["client_id"], pending["algo_client_id"])
        self.log("추가 진입 요청: " + action + " / " + symbol + " / " + pending["quantity"] + "계약 / 시장가")
        try:
            self.api.post("/api/v5/trade/order", body)
        except Rejected:
            owned.pop("pending_add", None)
            owned["phase"] = "active"
            self.journal.save()
            raise

    def reconcile_addition(self, snapshot):
        owned = self.journal.data["owned"]
        pending = owned["pending_add"]
        position = owned_position(owned, snapshot["positions"])
        try:
            order = self.api.get("/api/v5/trade/order", instId=owned["symbol"], clOrdId=pending["client_id"])[0]
        except Rejected:
            raise BotError("추가 진입 응답 미확인. 중복 추가 없이 주문 내역 확인을 기다립니다.") from None
        filled = dec(order.get("accFillSz") or "0")
        if order.get("state") == "canceled" and filled == 0:
            if position and dec(position["pos"]) != dec(owned["quantity"]):
                raise BotError("추가 주문 취소 후 포지션 수량 불일치")
            owned.pop("pending_add")
            owned["phase"] = "active"
            self.journal.save()
            self.log("추가 진입 주문 미체결 취소 확인. 횟수는 사용하지 않았습니다.")
            return position
        if order.get("state") != "filled":
            if self.api.now_ms() - pending["started_ms"] > 15000:
                raise BotError("추가 진입 주문이 종결되지 않았습니다. 신규 진입 차단.")
            return position
        if filled != dec(pending["quantity"]):
            raise BotError("추가 체결 수량 불일치")
        if not position:
            if self.api.now_ms() - pending["started_ms"] > 15000:
                self.finish_position()
            return None
        expected = dec(owned["quantity"]) + filled
        leg = {"algo_client_id": pending["algo_client_id"], "quantity": pending["quantity"], "stop_px": pending["stop_px"]}
        if dec(position["pos"]) != expected:
            # Original stop can race an opening add order during a gap. Verify our fill,
            # then close only the newly created quantity instead of treating it as a new trade.
            if dec(position["pos"]) != filled:
                raise BotError("추가 체결 후 포지션이 기록과 다릅니다.")
            owned["cleanup_legs"] = legs_for(owned)
            owned["legs"] = [leg]
            owned["quantity"], owned["posId"] = fmt(filled), position["posId"]
            owned["phase"] = "active"
            owned.pop("pending_add")
            self.journal.save()
            self.pause("기존 손절과 추가 진입이 겹쳐 추가분을 정리합니다")
            self.close(snapshot, "손절/추가 주문 경합 정리")
            return position
        if owned.get('v4_signal',{}).get('strategy')=='band_flow':
            owned['band_add_count']=int(owned.get('band_add_count',0))+1
            owned['band_last_fill_px']=fmt(dec(order.get('avgPx') or ((dec(position['avgPx'])*expected-dec(pending['prior_average_px'])*dec(pending['prior_quantity']))/filled)))
        owned["legs"] = legs_for(owned) + [leg]
        owned["quantity"] = fmt(expected)
        owned["average_used" if pending["kind"] == "ADD_AVERAGE" else "pyramid_used"] = True
        owned["committed_margin"] = fmt(dec(owned["committed_margin"]) + dec(pending["margin"]))
        owned["peak_roe"] = float(dec(position["uplRatio"]))
        owned.pop("profit_floor_roe", None)
        owned["phase"], owned["protection_verified"] = "protecting", False
        owned["protection_started_ms"] = self.api.now_ms()
        fee = pending["fee"]
        owned.pop("pending_add")
        self.journal.save()
        self.invalidate()
        self.next_ai = time.monotonic() + 300
        instrument = self.api.public("/api/v5/public/instruments", instType="SWAP", instId=owned["symbol"])[0]
        try:
            owned["target_stop_px"] = tightened_stop(owned, position, instrument, fee)
        except BotError:
            self.pause("추가 체결 후 보호 가격 확보 불가")
            self.close(snapshot, "보호 가격 도달로 청산")
            return position
        self.journal.save()
        self.log("추가 체결 확인. 총 " + owned["quantity"] + "계약 / 보호 주문 범위 재확인 중.")
        return position

    def reconcile_protection(self, snapshot):
        owned = self.journal.data["owned"]
        position = owned_position(owned, snapshot["positions"])
        if not position:
            self.finish_position()
            return None
        if owned.get('close_requested') or (owned.get('v4_signal',{}).get('strategy')!='band_flow' and dec(position['uplRatio']) <= dec('-.30')):
            self.close(snapshot, owned.get("close_requested", "추가 체결 후 -30% 손절"))
            return position
        if not owned.get("target_stop_px"):
            # Crash between fill bookkeeping and target calculation: don't guess a stop.
            self.pause("추가 체결 후 보호 목표 기록 미확인")
            self.close(snapshot, "보호 목표 미확인")
            return position
        mine, other = self.algos()
        if other:
            raise BotError("보호 수정 중 다른 조건주문 발견")
        by_client = {row.get("algoClOrdId"): row for row in mine}
        complete = True
        for leg in legs_for(owned):
            row = by_client.get(leg["algo_client_id"])
            valid = bool(row and row.get("state") == "live" and dec(row.get("sz") or "0") == dec(leg["quantity"])
                         and row.get("slOrdPx") == "-1" and row.get("slTriggerPxType") == "mark")
            if not valid:
                complete = False
                continue
            target = owned["target_stop_px"]
            if dec(row["slTriggerPx"]) == dec(target):
                leg["stop_px"] = target
                continue
            complete = False
            if leg.get("amend_requested") == target:
                continue  # Unknown write outcome: query, don't blindly repeat the amendment.
            leg["amend_requested"] = target
            self.journal.save()
            self.api.post("/api/v5/trade/amend-algos", {
                "instId": owned["symbol"], "algoId": row["algoId"], "cxlOnFail": False,
                "reqId": "OM" + uuid.uuid4().hex[:28], "newSlTriggerPx": target,
                "newSlOrdPx": "-1", "newSlTriggerPxType": "mark"})
        if complete:
            owned["stop_px"] = owned.pop("target_stop_px")
            owned["phase"], owned["protection_verified"] = "active", True
            self.journal.save()
            self.log("전체 수량의 거래소 보호 SL 확인: " + owned["stop_px"])
        elif self.api.now_ms() - owned["protection_started_ms"] > 15000:
            self.pause("추가분 포함 보호 등록/수정 확인 실패")
            self.close(snapshot, "전체 보호 범위 미확인")
        return position

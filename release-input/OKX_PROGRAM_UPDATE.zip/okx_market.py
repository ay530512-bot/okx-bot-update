"""OKX market + AI analysis smoke test. No trading or private OKX calls.

Run beside .env: python okx_scan.py
Offline verification: python okx_scan.py --self-test
"""
import json
import math
import sys
import time
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_DOWN
from pathlib import Path

BASE = "https://openapi.okx.com"
MODEL = "gpt-4.1-mini"  # Connection/analysis test; not a validated trading strategy.
REFERENCE_EQUITY = Decimal("48")  # Estimate only; no account balance is read.
MAX_SPREAD_BPS = 15
KST = timezone(timedelta(hours=9))
BAR_MS = {"1m": 60000, "5m": 300000, "15m": 900000, "1H": 3600000, "4H": 14400000}
FRAMES = ("5m", "15m", "1H", "4H")
EXCLUDED_BASES = {"BTC", "ETH", "SOL", "AAPL", "TSLA", "NVDA", "MSFT", "AMZN",
                  "GOOG", "GOOGL", "META", "COIN", "MSTR", "SNDK", "SPY", "QQQ",
                  "CL", "BZ", "XAU", "XAG", "XAUT", "XCU"}


def number(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("Non-finite market data")
    return result


def allowed_altcoin(instrument):
    """Require explicit crypto classification; fee groups alone are insufficient."""
    symbol = instrument.get("instId", "")
    base = symbol.split("-")[0]
    return (base not in EXCLUDED_BASES
            and instrument.get("instCategory") == "1"
            and instrument.get("groupId") in ("4", "5")
            and symbol.endswith("-USDT-SWAP")
            and instrument.get("state") == "live"
            and instrument.get("settleCcy") == "USDT"
            and instrument.get("ctType") == "linear"
            and instrument.get("ctValCcy") == base)


def candidate(instrument, ticker, now_ms, reference_equity=REFERENCE_EQUITY):
    symbol = instrument["instId"]
    if not allowed_altcoin(instrument):
        return None
    bid, ask, last = [number(ticker[k]) for k in ("bidPx", "askPx", "last")]
    if bid <= 0 or ask < bid or last <= 0:
        return None
    if not 0 <= now_ms - int(ticker["ts"]) <= 60000:
        return None
    spread = (ask - bid) / ((ask + bid) / 2) * 10000
    if spread > MAX_SPREAD_BPS:
        return None
    volume = number(ticker["vol24h"]) * number(instrument["ctVal"]) * last
    if volume <= 0:
        return None
    ct_val = Decimal(instrument["ctVal"])
    lot, minimum = Decimal(instrument["lotSz"]), Decimal(instrument["minSz"])
    if min(ct_val, lot, minimum) <= 0:
        return None
    sizing = {}
    for leverage in (3, 4, 5):
        if number(instrument.get("lever") or "0") < leverage:
            continue
        budget = Decimal(str(reference_equity)) / 3
        quantity = (budget * leverage / (ct_val * Decimal(str(ask))) / lot)
        quantity = quantity.to_integral_value(rounding=ROUND_DOWN) * lot
        if quantity >= minimum:
            sizing[str(leverage)] = str(quantity)
    if not sizing:
        return None
    return {
        "symbol": symbol, "last": last,
        "spread_bps": round(spread, 3),
        "approx_24h_turnover_usdt": round(volume, 2),
        "reference_contracts_by_leverage": sizing,
        "min_contracts": str(minimum),
        "min_margin_usdt_at_3x": float(minimum * ct_val * Decimal(str(ask)) / 3),
    }


def closed_candles(rows, bar, now_ms):
    parsed = {}
    for row in rows:
        if len(row) < 9 or row[8] != "1":
            continue
        stamp = int(row[0])
        o, h, low, close, volume = [number(row[i]) for i in (1, 2, 3, 4, 7)]
        if min(o, h, low, close) <= 0 or volume < 0:
            raise ValueError("Invalid candle values")
        if not (low <= min(o, close) <= max(o, close) <= h):
            raise ValueError("Invalid OHLC ordering")
        parsed[stamp] = [stamp, o, h, low, close, volume]
    candles = sorted(parsed.values())
    step = BAR_MS[bar]
    if len(candles) < 60:
        raise ValueError("Not enough closed candles")
    if any(b[0] - a[0] != step for a, b in zip(candles, candles[1:])):
        raise ValueError("Candle gap")
    if not 0 <= now_ms - (candles[-1][0] + step) <= step + 60000:
        raise ValueError("Stale or future candles")
    return candles


def ema(values, period):
    result = values[0]
    for value in values[1:]:
        result += 2 / (period + 1) * (value - result)
    return result


def rsi(values, period=14):
    if len(values) <= period:
        raise ValueError("Not enough RSI history")
    changes = [b - a for a, b in zip(values, values[1:])]
    gain = sum(max(change, 0) for change in changes[:period]) / period
    loss = sum(max(-change, 0) for change in changes[:period]) / period
    for change in changes[period:]:
        gain = (gain * (period - 1) + max(change, 0)) / period
        loss = (loss * (period - 1) + max(-change, 0)) / period
    if gain == loss == 0:
        return 50.0
    if loss == 0:
        return 100.0
    return 100 - 100 / (1 + gain / loss)


def summarize(candles):
    closes = [r[4] for r in candles]
    previous_volumes = [r[5] for r in candles[-21:-1]]
    baseline = sum(previous_volumes) / len(previous_volumes)
    last, previous = candles[-1], candles[-2]
    prior_high = max(r[2] for r in candles[-21:-1])
    prior_low = min(r[3] for r in candles[-21:-1])
    ranges = [max(b[2] - b[3], abs(b[2] - a[4]), abs(b[3] - a[4]))
              for a, b in zip(candles, candles[1:])]
    atr = sum(ranges[:14]) / 14
    for value in ranges[14:]:
        atr = (atr * 13 + value) / 14
    span = last[2] - last[3]
    swings_low = [r[3] for a, r, b in zip(candles[-23:-2], candles[-22:-1], candles[-21:])
                  if r[3] < a[3] and r[3] < b[3]]
    swings_high = [r[2] for a, r, b in zip(candles[-23:-2], candles[-22:-1], candles[-21:])
                   if r[2] > a[2] and r[2] > b[2]]
    result = {
        "ema20": ema(closes, 20), "ema50": ema(closes, 50),
        "rsi14": rsi(closes), "rsi14_previous": rsi(closes[:-1]), "atr14": atr,
        "prior20_high": prior_high, "prior20_low": prior_low,
        "breakout20_up": last[4] > prior_high,
        "breakout20_down": last[4] < prior_low,
        "bullish_engulfing": previous[4] < previous[1] and last[4] > last[1] and last[1] <= previous[4] and last[4] >= previous[1],
        "bearish_engulfing": previous[4] > previous[1] and last[4] < last[1] and last[1] >= previous[4] and last[4] <= previous[1],
        "last_volume_vs_previous20": candles[-1][5] / baseline if baseline else None,
        "change_over_10_bars_pct": (closes[-1] / closes[-11] - 1) * 100,
        "columns": ["open_time_ms", "open", "high", "low", "close", "volume_usdt"],
        "last_24_closed_bars": candles[-24:],
        "ema20_previous": ema(closes[:-1], 20),
        "ema50_previous": ema(closes[:-1], 50),
        "last_close": last[4], "previous_close": previous[4],
        "upper_wick_fraction": (last[2] - max(last[1], last[4])) / span if span else 0,
        "lower_wick_fraction": (min(last[1], last[4]) - last[3]) / span if span else 0,
        "body_fraction": abs(last[4] - last[1]) / span if span else 0,
        "confirmed_swing_low": swings_low[-1] if swings_low else None,
        "confirmed_swing_high": swings_high[-1] if swings_high else None,
        "previous_5_low": min(r[3] for r in candles[-6:-1]),
        "previous_5_high": max(r[2] for r in candles[-6:-1]),
        "closed_at_ms": last[0],
    }
    for period in (6, 24):
        result[f"rsi{period}"] = rsi(closes, period)
        result[f"rsi{period}_previous"] = rsi(closes[:-1], period)
    return result


def validate_decision(result, markets):
    if set(result) != {"action", "symbol", "leverage", "reason", "risk"}:
        raise ValueError("Invalid AI response fields")
    if result["action"] not in ("LONG", "SHORT", "WAIT"):
        raise ValueError("Invalid AI action")
    if type(result["leverage"]) is not int or result["leverage"] not in (3, 4, 5):
        raise ValueError("Invalid leverage")
    if not all(isinstance(result[k], str) and result[k].strip() for k in ("reason", "risk")):
        raise ValueError("Missing explanation")
    if result["action"] == "WAIT":
        if result["symbol"] != "NONE":
            raise ValueError("WAIT must use NONE")
    else:
        chosen = next((m for m in markets if m["symbol"] == result["symbol"]), None)
        if not chosen or str(result["leverage"]) not in chosen["reference_contracts_by_leverage"]:
            raise ValueError("Symbol or sizing is outside supplied candidates")
    return result


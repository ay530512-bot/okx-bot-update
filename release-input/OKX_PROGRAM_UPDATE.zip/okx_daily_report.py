"""Read-only OKX daily reports. Run separately from the trading process.

No exchange writes, no AI calls. Telegram is the only outgoing write.
"""
import hashlib
import json
import os
import socket
import sys
import time
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

from okx_core import OKX, BotError, KST, dec, fmt, day_key

ROOT = Path(__file__).resolve().parent


class ReadOnlyOKX(OKX):
    def request(self, method, *args, **kwargs):
        if method != 'GET':
            raise BotError('보고서 프로그램은 OKX 조회만 허용합니다.')
        return super().request(method, *args, **kwargs)


def atomic_json(path, data):
    temp = path.with_suffix('.tmp')
    with temp.open('w', encoding='utf-8') as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temp, path)


def bounds(date):
    start = datetime.strptime(date, '%Y-%m-%d').replace(tzinfo=KST)
    return int(start.timestamp() * 1000), int((start + timedelta(days=1)).timestamp() * 1000)


def fetch_bills(api, start, end):
    """Half-open interval, billId pagination, deduplication; never silently truncate."""
    rows, seen, cursor = [], set(), None
    for _ in range(500):
        params = {'ccy': 'USDT', 'begin': str(start), 'end': str(end - 1), 'limit': '100'}
        if cursor is not None:
            params['after'] = cursor
        page = api.get('/api/v5/account/bills', **params)
        for row in page:
            key = row['billId']
            if key not in seen:
                seen.add(key)
                if row.get('ccy') == 'USDT' and start <= int(row['ts']) < end:
                    rows.append(row)
        if len(page) < 100:
            return rows
        next_cursor = page[-1]['billId']
        if next_cursor == cursor:
            raise BotError('거래 내역 페이지가 반복되어 보고서를 보류합니다.')
        cursor = next_cursor
        time.sleep(.15)
    raise BotError('거래 내역이 너무 많아 보고서를 보류합니다.')


def transfers(rows, start, end):
    return sum((dec(r['balChg']) for r in rows
                if r.get('type') == '1' and start < int(r['ts']) < end), dec(0))


def aggregate(rows):
    coins = defaultdict(lambda: {'pnl': dec(0), 'fee': dec(0), 'funding': dec(0), 'fills': set()})
    other = 0
    for row in rows:
        if row.get('ccy') != 'USDT' or row.get('type') == '1':
            continue
        symbol, kind = row.get('instId', ''), row.get('type')
        if row.get('instType') == 'SWAP' and symbol.endswith('-USDT-SWAP') and kind in ('2', '5', '9', '8'):
            coin = coins[symbol]
            if kind == '8':
                coin['funding'] += dec(row['balChg'])
            else:
                coin['pnl'] += dec(row.get('pnl') or '0')
                coin['fee'] += dec(row.get('fee') or '0')
                coin['fills'].add(row.get('tradeId') or row['billId'])
        elif dec(row.get('balChg') or '0') != 0:
            other += 1
    return coins, other


def sample(snapshot):
    return {'ms': snapshot['ms'], 'equity': fmt(snapshot['equity']),
            'positions': [{'symbol': p['instId'], 'side': p.get('posSide', ''),
                           'upl': str(p.get('upl') or '0')}
                          for p in snapshot['positions']
                          if dec(p.get('pos') or '0') != 0 and p.get('ccy') == 'USDT']}


def money(value):
    return f'{dec(value):,.6f}'


def make_report(date, record, bills, ai_cost):
    start, end = bounds(date)
    coins, other = aggregate(bills)
    lines = [f'[OKX 일일 보고서 · {date} KST]', '대상: 00:00~23:59 / 거래 계정 USDT 전체', '']
    seed, finish = record.get('seed'), record.get('last')
    if seed is not None and finish:
        flow = transfers(bills, record['start_ms'], finish['ms'] + 1)
        base = dec(seed) + flow
        profit = dec(finish['equity']) - base
        net = profit - dec(ai_cost)
        lines += [f'시작 시드: {money(seed)} USDT', f'종료 관측 자산: {money(finish["equity"])} USDT',
                  f'순입출금: {flow:+.6f} USDT (수익 제외)',
                  f'계정 손익: {profit:+.6f} USDT',
                  f'AI 비용 추정: ${dec(ai_cost):.6f}',
                  f'AI 비용 차감 손익 추정: {net:+.6f} USDT']
        denominator = dec(seed)
        if denominator > 0:
            lines += [f'수익률: {profit / denominator * 100:+.2f}% / AI 차감 추정 {net / denominator * 100:+.2f}%',
                      f'+6% 목표 수익: {denominator * dec(".06"):.6f} USDT',
                      f'+6% 목표 총액(AI 차감 기준): {base + denominator * dec(".06") + dec(ai_cost):.6f} USDT',
                      '목표 상태: ' + ('평가 기준 도달' if net >= denominator * dec('.06') else '미도달') + ' · 수익 보장 아님',
                      f'목표까지 부족액(AI 차감 기준): {max(dec(0), denominator * dec(".06") - net):.6f} USDT']
        else:
            lines.append('기준 자산이 0 이하라 수익률·목표를 계산하지 않았습니다.')
        lines.append('관측 구간: ' + datetime.fromtimestamp(record['start_ms'] / 1000, KST).strftime('%m-%d %H:%M:%S')
                     + ' ~ ' + datetime.fromtimestamp(finish['ms'] / 1000, KST).strftime('%m-%d %H:%M:%S'))
        lines.append('시드 기준: ' + record.get('source', '보고서 조회'))
        if end - finish['ms'] > 90000:
            lines.append('주의: 종료 관측에 공백이 있어 위 자산 손익은 당일 전체 성과가 아닙니다.')
        lines.append('평가자산은 조회 시각의 값입니다. 자정 정각 값과 차이가 있을 수 있습니다.')
        if flow:
            lines.append('수익률 분모·목표 수익은 시작 총자산 기준이며 순입출금은 손익에서 제외했습니다.')
    else:
        lines += ['시작·종료 시드 기록 부족: 자산 증감률과 +6% 목표 총액은 계산하지 않았습니다.',
                  f'AI 비용 관측 추정: ${dec(ai_cost):.6f}']
    lines += ['', '코인별 확정 손익 (당일 전체 거래소 내역)']
    if not coins:
        lines.append('USDT 무기한 선물 거래·펀딩 기록 없음')
    total = dec(0)
    for symbol, coin in sorted(coins.items(), key=lambda item: sum(item[1][k] for k in ('pnl', 'fee', 'funding')), reverse=True):
        amount = coin['pnl'] + coin['fee'] + coin['funding']
        total += amount
        lines += [f'{symbol}: {amount:+.6f} USDT / 체결기록 {len(coin["fills"])}건',
                  f'  청산손익 {coin["pnl"]:+.6f} · 수수료/리베이트 {coin["fee"]:+.6f} · 펀딩 {coin["funding"]:+.6f}']
    lines.append(f'코인별 합계(수수료·펀딩 포함, AI 제외): {total:+.6f} USDT')
    if other:
        lines.append(f'기타 자산변동 {other}건: 코인별 합계에서 제외. 계정 전체 손익과 차이가 날 수 있습니다.')
    if finish and finish['positions']:
        lines += ['', '마지막 관측 보유분 평가손익 (확정 손익과 별도)']
        for p in finish['positions']:
            lines.append(f'{p["symbol"]} {p["side"]}: {dec(p["upl"]):+.6f} USDT')
    lines += ['', 'AI 비용은 로컬 기록 관측 추정(실패 요청 예약분 포함), USD=USDT 가정입니다.',
              '코인별 내역은 수동매매도 포함하며 미청산 평가손익은 합계에 더하지 않았습니다.',
              '첫날·중단 구간은 기록 범위를 확인하세요. 거래소 명세서와 대조할 수 있습니다.']
    return '\n'.join(lines)


def telegram(session, token, method, **params):
    try:
        response = session.post('https://api.telegram.org/bot' + token + '/' + method,
                                json=params, timeout=20)
        data = response.json()
        if not response.ok or not data.get('ok'):
            raise BotError('텔레그램 응답 오류 HTTP ' + str(response.status_code))
        return data['result']
    except BotError:
        raise
    except Exception:
        raise BotError('텔레그램 응답 확인 실패. 토큰/주소는 출력하지 않습니다.') from None


class Reporter:
    def __init__(self, root, api, send, identity):
        self.root, self.api, self.send = Path(root), api, send
        self.path = self.root / 'daily_report_state.json'
        self.data = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {'version': 1, 'identity': identity, 'days': {}}
        if self.data.get('version') != 1 or self.data.get('identity') != identity:
            raise BotError('보고서 계정/봇/수신자가 기존 기록과 다릅니다. 설정을 확인하세요.')
        self.retry_after = 0

    def save(self):
        atomic_json(self.path, self.data)

    def observe(self, snapshot, journal):
        today = day_key(snapshot['ms'])
        days = self.data['days']
        record = days.setdefault(today, {'seed': None, 'start_ms': snapshot['ms'], 'last': None, 'ai': '0', 'sent': False})
        day = journal.get('day')
        if record['seed'] is None:
            if day and day['date'] == today:
                # The trading journal adds transfers to its base. Remove those to recover its initial seed.
                bills = fetch_bills(self.api, day['started_ms'], snapshot['ms'] + 1)
                record.update(seed=fmt(dec(day['base']) - sum((dec(b['balChg']) for b in bills if b.get('type') == '1' and b['billId'] in set(day.get('flow_ids', []))), dec(0))),
                              start_ms=day['started_ms'], source='매매 프로그램의 당일 기준; 첫날은 최초 시작 시점')
            elif any(r.get('seed') is not None for key, r in days.items() if key < today):
                record.update(seed=fmt(snapshot['equity']), start_ms=snapshot['ms'], source='자정 이후 첫 보고서 조회')
        record['last'] = sample(snapshot)
        api_day = journal.get('api_day')
        if api_day in days:
            days[api_day]['ai'] = fmt(max(dec(days[api_day]['ai']), dec(journal.get('api_spent', 0))))
        self.save()

    def due(self, now):
        today = day_key(now)
        if time.monotonic() < self.retry_after:
            return
        for date, record in sorted(self.data['days'].items()):
            if date >= today or record['sent']:
                continue
            start, end = bounds(date)
            if now < end + 600000:
                continue
            if now - end > 6 * 86400000:
                raise BotError('미발송 보고서가 거래소 7일 조회 범위를 벗어났습니다. 수동 확인이 필요합니다.')
            bills = fetch_bills(self.api, start, end)
            report = make_report(date, record, bills, record['ai'])
            folder = self.root / 'daily_reports'
            folder.mkdir(exist_ok=True)
            path = folder / (date + '.txt')
            # Store progress per part. Network uncertainty may duplicate one part on retry.
            progress = record.setdefault('parts_sent', 0)
            record.setdefault('report_text', report)
            path.write_text(record['report_text'], encoding='utf-8')
            from okx_telegram_brief import daily
            outgoing = daily(record['report_text']) if progress == 0 else record.get('telegram_text',record['report_text'])
            record['telegram_text']=outgoing
            chunks = [outgoing[i:i + 3000] for i in range(0, len(outgoing), 3000)]
            self.save()
            for index in range(progress, len(chunks)):
                try:
                    self.send(chunks[index])
                except Exception:
                    self.retry_after = time.monotonic() + 300
                    raise
                record['parts_sent'] = index + 1
                self.save()
            record['sent'] = True
            self.save()
            print(date + ' 보고서 발송 확인 완료. 파일: daily_reports/' + date + '.txt', flush=True)


def load_journal(root):
    path = root / 'bot_state.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}


def main():
    from dotenv import dotenv_values
    import requests
    lock = socket.socket()
    try:
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            lock.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        lock.bind(('127.0.0.1', 48737))
    except OSError:
        raise BotError('보고서 프로그램이 이미 실행 중이거나 전용 포트가 사용 중입니다.') from None
    settings = dotenv_values(ROOT / '.env', encoding='utf-8-sig', interpolate=False)
    token, chat = settings.get('TELEGRAM_BOT_TOKEN'), settings.get('TELEGRAM_CHAT_ID')
    if not token or not chat or not chat.isdigit():
        raise BotError('먼저 텔레그램 연결 테스트로 TELEGRAM_CHAT_ID를 저장하세요.')
    api = ReadOnlyOKX(settings)
    snapshot = api.snapshot()
    uid = snapshot['config'].get('uid')
    if not uid:
        raise BotError('OKX 계정 식별값을 확인하지 못했습니다.')
    session = requests.Session()
    bot = telegram(session, token, 'getMe')
    target = telegram(session, token, 'getChat', chat_id=chat)
    if target.get('type') != 'private' or str(target.get('id')) != chat:
        raise BotError('연결 테스트에서 확인한 개인 대화방만 허용합니다.')
    identity = hashlib.sha256((uid + ':' + str(bot['id']) + ':' + chat).encode()).hexdigest()
    reporter = Reporter(ROOT, api, lambda text: telegram(session, token, 'sendMessage', chat_id=chat, text=text), identity)
    reporter.observe(snapshot, load_journal(ROOT))
    print('보고서 가동 확인. 매일 한국시간 00:10 (조회 지연 시 늦어질 수 있음)', flush=True)
    print('이 창을 켜 두세요. 자동매매 창과 별도로 동작합니다. 종료: Ctrl+C', flush=True)
    while True:
        try:
            snapshot = api.snapshot()
            journal = load_journal(ROOT)
            if hashlib.sha256((snapshot['config']['uid'] + ':' + str(bot['id']) + ':' + chat).encode()).hexdigest() != identity:
                raise BotError('계정이 변경되어 보고서 처리를 보류합니다.')
            reporter.observe(snapshot, journal)
            reporter.due(snapshot['ms'])
        except Exception as error:
            # Do not print arbitrary exception strings: requests exceptions may include the token URL.
            print('보고서 처리 보류 (' + type(error).__name__ + '). 30초 후 재확인. 설정·연결을 확인하세요.', flush=True)
        time.sleep(30)


if __name__ == '__main__':
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    try:
        main()
    except KeyboardInterrupt:
        print('보고서 프로그램 종료. 매매 프로그램에는 영향을 주지 않습니다.')
    except BotError as error:
        print('설정 확인: ' + str(error))
    except Exception as error:
        print('보고서 시작 실패 (' + type(error).__name__ + '). 비밀키를 공유하지 말고 설정을 확인하세요.')

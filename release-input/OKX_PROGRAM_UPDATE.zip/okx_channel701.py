"""V7.32 15m regime entries only. Retired 4H entries are rejected. No model requests."""
import hashlib, math
from okx_core import BotError
from okx_pattern15 import leverage
STEP=900000

def enabled(c):return c.get('execution',{}).get('rule_channel701',False)

def closed(b,now,step=STEP,required=22):
 a=[r for r in b if int(r[0])+step<=now]
 if len(a)<required:raise BotError('규칙 완료봉 자료 부족')
 if a[-1][0]!=now//step*step-step:raise BotError('규칙 최신 완료봉 대기')
 for r in a:
  if len(r)<6 or not all(math.isfinite(float(x)) for x in r[:6]) or min(r[1:5])<=0 or r[5]<0 or not r[3]<=min(r[1],r[4])<=max(r[1],r[4])<=r[2]:raise BotError('규칙 봉 수치 오류')
 if any(a[j][0]-a[j-1][0]!=step for j in range(1,len(a))):raise BotError('규칙 봉 연속성 오류')
 return a

def setup(b,hourly=None):
 from okx_two_wick732 import select
 return select(b,hourly)[0]

def window(v,price):
 side=1 if v['action']=='LONG' else -1;price=float(price);stop=float(v['structural_stop'])
 # Same stop/entry validity bound used by the replay; not a pattern/RSI veto.
 return math.isfinite(price) and price>0 and 0<(price-stop)*side/price<.09 and abs(price-v["reference"])<=.5*v["atr"]

def evidence(b,v,frames,now):
 # A bounded, symmetric tie breaker; no threshold can veto a qualified breakout.
 side=1 if v['action']=='LONG' else -1
 last=b[-1];close=last[4];span=last[2]-last[3]
 strength=((close-last[3]) if side==1 else (last[2]-close))/span if span else .5
 mean=sum(x[5] for x in b[-21:-1])/20
 volume=last[5]/mean if mean>0 else None
 distance=(close-(v['channel_high'] if side==1 else v['channel_low']))*side/v['atr']
 votes={}
 for frame,step in [('1H',3600000),('4H',14400000)]:
  a=frames.get(frame,{})
  trend=a.get('analysis',{}).get('trend','unknown') if a.get('completed_ms')==now//step*step else 'unknown'
  votes[frame]=side*{'uptrend':1,'downtrend':-1}.get(trend,0)
 score=sum(votes.values())+(1 if volume is not None and volume>=1 else 0)+(1 if strength>=.75 else 0)+(1 if 0<distance<=1 else 0)
 return dict(score=score,volume_ratio=volume,close_strength=strength,break_atr=distance,higher_votes=votes)

def rank_item(item):
 symbol,s=item
 return (s['valid_from_ms'],-s['decision_record']['evidence704']['score'],symbol)

def packet(row,c,now,quote=None,swing_frame=None):
 from okx_pattern15 import summary,STEPS
 from okx_band_flow import view
 frames={};b=closed(row.get('live_frames',{}).get('15m',[]),now)
 from okx_two_wick732 import select
 v,or_status=select(b,row.get('live_frames',{}).get('1H'))
 for f,step in STEPS.items():
  a=b if f=='15m' else [r for r in row.get('live_frames',{}).get(f,[]) if r[0]+step<=now]
  if len(a)<21:
   frames[f]=dict(analysis=dict(trend='unknown',reason='보조봉 자료 대기'),completed_ms=0);continue
  m=view(a,c);frames[f]=dict(analysis=summary(a),ma=m['ma'],bollinger={k:m[k] for k in ('mid','upper','lower')},atr=m['atr'],recent=a[-24:],completed_ms=a[-1][0]+step)
 if v:v['evidence704']=evidence(b,v,frames,now)
 frames['15m']['entry_setups']=[v] if v else []
 return dict(symbol=row['symbol'],price=float((quote or {}).get('last') or (v['reference'] if v else b[-1][4] if b else 0)),asset_category=row.get('instrument',{}).get('instCategory','1'),required_leverage=leverage(row['symbol']),or_status=or_status,frames=frames,entry_setups=[v] if v else [],selection='V7.32 기존15m OR 두꼬리',policy='15m: 기존 규칙 OR 두꼬리·1H 확인; MA20 추격 제한 없음; 4H 진입 삭제')

def make_signal(out,p,c,now,manual=False):
 v=next((v for v in p['entry_setups'] if v['action']==out['action']),None)
 from okx_channel4h730 import is_signal, reject_entry
 if is_signal(v):reject_entry()
 if not v or (not manual and not window(v,p['price'])):raise BotError('통로 신호 또는 2ATR 손절 유효성 미충족')
 start=int(v['confirmation_ms'])+STEP
 # Live market execution cannot guarantee historical next-open prices. Never enter a stale signal.
 if not 0<=now-start<=90000:raise BotError('통로 돌파 후 다음 봉 초기90초 만료 · 다음 신호 대기')
 identity='ch701-'+hashlib.sha256((p['symbol']+'|'+v['action']+'|'+str(v['confirmation_ms'])).encode()).hexdigest()[:24]
 return dict(symbol=p['symbol'],action=v['action'],leverage=leverage(p['symbol']),strategy='band_flow',pattern='channel20_10',rule_channel701=True,free_ai=True,pattern15=True,stop=v['structural_stop'],target=None,margin_fraction=.25,signal_id=identity,atr=v['atr'],level=v['structural_stop'],reason=str(v.get('lookback721',20))+'봉 '+v.get('route721','직접진입')+' '+v['action']+' / 후보 우선점수 '+str(v['evidence704']['score'])+' / 초기2ATR·10봉 추적SL',regime='추세 눌림 / 확정 반전',ma=p['frames']['15m']['ma'],bb=p['frames']['15m']['bollinger'],rsi={f:p['frames'][f]['analysis'].get('rsi14') for f in p['frames']},retest=False,adaptive=False,setup_frame='15m',execution_frame='15m',at_ms=now,valid_from_ms=start,expires_ms=start+90000,entry_reference=p['price'],entry_gap=p['price'],selection=dict(activity={},asset_category=p['asset_category']),holding_rule=dict(band_flow=True,free_ai=True,pattern15=True,rule_channel701=True,frame='15m',zone=v['structural_stop'],target=None,target_mode='channel10'),decision_record=dict(source='CHANNEL701',frames=p['frames'],volume_wick_proof=v,evidence704=v['evidence704']))

def check_entry(e,s,price):
 from okx_channel4h730 import is_signal,reject_entry
 if is_signal(s):reject_entry()
 from okx_band_flow import rows
 now=e.api.now_ms()
 b=closed(rows(e.api.public('/api/v5/market/candles',instId=s['symbol'],bar='15m',limit='300'),'15m',now),now)
 hourly=rows(e.api.public('/api/v5/market/candles',instId=s['symbol'],bar='1H',limit='100'),'1H',now)
 v=setup(b,hourly);original=s.get('decision_record',{}).get('volume_wick_proof',{})
 if not s.get('rule_channel701') or not v or v['action']!=s['action'] or v['confirmation_ms']!=original.get('confirmation_ms'):raise BotError('통로 원래 완료봉 신호 변경')
 if not s['valid_from_ms']<=now<=s['expires_ms']:raise BotError('통로 진입 신호 만료')
 if v.get('route721')!=original.get('route721') or v.get('lookback721')!=original.get('lookback721') or v.get('variant724')!=original.get('variant724'):raise BotError('진입 경로 변경 · 새 신호 대기')
 if not window(original,price):raise BotError('통로 진입 호가/손절 유효성 미충족')
 # A post-signal stop touch invalidates the pending entry, including during subscription warmup.
 active=[r for r in rows(e.api.public('/api/v5/market/candles',instId=s['symbol'],bar='15m',limit='2'),'15m',now) if r[0]>=s['valid_from_ms']]
 side=1 if s['action']=='LONG' else -1
 if any((r[3]<=s['stop'] if side==1 else r[2]>=s['stop']) for r in active):raise BotError('진입 대기 중 초기SL 도달 · 신호 폐기')
 return v

def candidate(e):
 now=e.api.now_ms()
 if not e.can_open_position():e.pipeline('holding','포지션 개수 한도 · 신규 탐색 중지');return None
 result,_=e.universe.read()
 if not result:e.pipeline('scan','통로 규칙 차트 수신 대기 · AI 호출 없음');return None
 rows_=result.get('rows',[])
 from okx_pattern15 import allowed
 if not hasattr(e,'channel_pending'):e.channel_pending={}
 held={o['symbol'] for o in e.records()};manual=e.blocked_manual_symbols()
 checked=breakouts=0
 # All cached symbols checked locally each pass: no learned ranking or old pattern gate.
 for row in rows_:
  symbol=row['symbol']
  if symbol in held or symbol in manual or not allowed(row['instrument'],e.cfg):continue
  try:
   p=packet(row,e.cfg,now);v=p['entry_setups'];checked+=1
   if not v:
    if p.get('or_status')=='conflict':e.channel_pending.pop(symbol,None)
    continue
   breakouts+=1
   s=make_signal(dict(action=v[0]['action']),p,e.cfg,now)
   if float(row['instrument'].get('lever') or 0)<s['leverage']:continue
   if symbol+':'+s['signal_id'] in e.journal.data.get('seen_signals',{}):continue
   e.channel_pending[symbol]=s
  except (BotError,ValueError,KeyError):continue
 from okx_channel4h730 import is_signal as retired_signal
 e.channel_pending={k:s for k,s in e.channel_pending.items() if not retired_signal(s) and now<=s['expires_ms'] and k not in held and k not in manual and k+':'+s['signal_id'] not in e.journal.data.get('seen_signals',{})}
 e.last_channel_scan=(now,len(rows_),checked,breakouts,len(e.channel_pending))
 watches=list(e.channel_pending)+list(held)
 e.stream.watch(watches+e.chat.watch())
 for symbol,s in sorted(e.channel_pending.items(),key=rank_item):
  if not e.stream.ready(symbol,e.cfg,now):continue
  q=e.stream.read(symbol,'tickers',15,now)
  if not q or not q.get('last'):continue
  try:check_entry(e,s,float(q['last']))
  except BotError as err:
   e.channel_pending.pop(symbol,None);e.pipeline('signal_wait',symbol+' / '+str(err));continue
  e.band_focus=symbol
  e.events.put(('timeframes',dict(symbol=symbol,frames={f:x['analysis'] for f,x in s['decision_record']['frames'].items()})))
  e.pipeline('approved',symbol+' / '+s['reason']+' · AI 호출 없음',count='signals')
  return s
 e.pipeline('signal_wait','V7.32 15분봉 규칙 확인 대기 / 준비 신호 '+str(len(e.channel_pending))+'개 / AI 호출 없음');return None

def profit_guard(e,snap,p,o,price,side,old):
 # Activation survives restarts and is based only on observed marks.
 entry=float(p.get('avgPx') or 0);lev=float(o.get('leverage') or 0)
 if not entry or not lev:return False
 if not o.get('profit_guard705') and (price-entry)*side*lev/entry>=.30-1e-10:
  rate=max(.0017,float(o.get('cost_rate') or 0)+.0007)
  o['profit_guard705']=entry*(1+side*rate);e.journal.save()
 floor=o.get('profit_guard705')
 if floor is None or (floor-old)*side<=0:return False
 if (price-floor)*side<=0:e.close(snap,'수익 보호선 이탈 · 청산 요청')
 else:
  e.trail(snap,p,o,floor)
  return o.get('phase')=='protecting'
 return True

def legacy_management713(e,snap,p,o):
 now=e.api.now_ms();side=1 if o['direction']=='long' else -1;price=float(p['markPx']);old=float(o['stop_px'])
 if (price-old)*side<=0:e.close(snap,'통로 보호 SL 도달');return True
 entry=float(p.get('avgPx') or 0);lev=float(o.get('leverage') or 0)
 if o.get('entry_ms') and now-int(o['entry_ms'])>=21600000:
  e.close(snap,'보유 6시간 만료');return True
 if entry>0 and lev>0 and not o.get('partial_used') and (price-entry)*side*lev/entry>=.30-1e-10:
  if 'profit_guard705' not in o:
   rate=max(.0017,float(o.get('cost_rate') or 0)+.0007)
   o['profit_guard705']=entry*(1+side*rate);e.journal.save()
  if not o.get('partial_unsplittable'):
   e.partial_close(snap,'+30% 도달 · 절반 수익 실현 요청',fraction=.5)
  if o.get('partial_unsplittable'):e.close(snap,'+30% 도달 · 분할 불가로 전량 청산 요청')
  return True
 if profit_guard(e,snap,p,o,price,side,old):return True
 if now-o.get('channel_check_ms',0)<10000:return False
 o['channel_check_ms']=now
 bars=e.chart_job(o['symbol']) or {}
 try:b=closed(bars.get('15m',[]),now,required=10)
 except BotError:return False
 from okx_pattern15 import summary,STEPS
 e.events.put(('timeframes',dict(symbol=o['symbol'],frames={f:summary([r for r in bars.get(f,[]) if r[0]+step<=now]) for f,step in STEPS.items()})))
 # Pre-entry bars can be in the 10-bar window, but don't move initial SL at entry.
 if b[-1][0]+STEP<=int(o.get('entry_ms',now)):return False
 if o.get('partial_used') and len(b)>=21 and b[-1][0]>=int(o.get('entry_ms',now)):
  last=b[-1];prev=b[-21:-1];edge=min(r[3] for r in prev) if side<0 else max(r[2] for r in prev)
  reversal=(last[3]<edge<last[4] and last[4]>last[1]) if side<0 else (last[2]>edge>last[4] and last[4]<last[1])
  avgvol=sum(r[5] for r in prev)/20
  if reversal and avgvol>0 and last[5]>avgvol and (price-float(p['avgPx']))*side>0:
   e.close(snap,'절반 익절 후 거래량 동반 극점 돌파 실패 · 잔량 청산 요청');return True
 level=min(r[3] for r in b[-10:]) if side==1 else max(r[2] for r in b[-10:])
 if (level-old)*side<=0:return False
 if (price-level)*side<=0:
  e.close(snap,'완료봉 10봉 추적 경계 이탈');return True
 # Existing positions migrate to this exit rule without loosening their current protection.
 o.setdefault('channel_exit_revision',701);o['holding_rule'].update(target=None,target_mode='channel10');e.journal.save()
 e.trail(snap,p,o,level);return True

def management(e,snap,p,o):
 from okx_channel4h730 import is_owned,management as four_manage
 if is_owned(o):return four_manage(e,snap,p,o)
 from okx_profit_guard714 import enabled,management as guard_management
 if enabled(e.cfg):return guard_management(e,snap,p,o)
 return legacy_management713(e,snap,p,o)

def configure(c):
 c['version']='7.30-or4h-goal6';c['indicators']['ma_periods']=[50,100,120,150,200,240];ex=c['execution'];ex['rule_channel701']=True
 ex['ai_confirmation']=False;ex['autonomous_scalp']['enabled']=False;ex['profile']='RULE_CHANNEL_20_10'
 from okx_channel4h730 import DEFAULTS as FOUR_DEFAULTS
 ex['channel4h730']=dict(FOUR_DEFAULTS) # Remove the route even from older saved enabled=True configs.
 ex['budget_pacing']['enabled']=False
 from okx_profit_guard714 import DEFAULTS
 c['risk']['profit_guard714']=dict(DEFAULTS)
 c['risk'].update(max_positions=4,leverage=10,min_leverage=10,max_leverage=20,initial_margin_fraction=.25,entry_cash_reserve_usdt=3);c['selection']['include_majors']=True
 from okx_risk732 import configure as configure_risk
 return configure_risk(c)

def validate(c):
 from okx_profit_guard714 import validate as guard_validate
 guard_validate(c)
 from okx_channel4h730 import DEFAULTS as FOUR_DEFAULTS
 four=c['execution'].get('channel4h730',{})
 if four != FOUR_DEFAULTS:raise BotError('4H 진입 경로는 삭제되었습니다. START_HERE로 설정을 갱신하세요.')
 if not c["execution"].get("pattern15_only") or not c["execution"].get("free_ai",{}).get("enabled"):raise BotError("규칙 실행 경로 설정 필요")
 if c["indicators"]["frames"]!=["15m","1H","4H"] or c["risk"].get("daily_loss_enabled") or c["risk"].get("final_roe_enabled"):raise BotError("통로 봉/손절 설정 오류")
 if c['risk']['leverage']!=10 or c['risk']['max_positions']!=4 or c['execution']['ai_confirmation']:raise BotError('통로 규칙10배·최대4개·AI해제 설정 필요')
 from okx_risk732 import enabled as risk_enabled,validate as risk_validate
 if risk_enabled(c):risk_validate(c)
 elif c['risk']['initial_size_mode']!='fixed_third':raise BotError('통로 규칙 수량 설정 오류')
 if abs(c['risk']['initial_margin_fraction']-.25)>1e-12:raise BotError('통로 규칙 증거금 상한 설정 오류')


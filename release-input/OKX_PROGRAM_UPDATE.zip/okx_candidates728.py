"""Frozen research hypotheses; not imported by the order engine.

Each function only uses completed input candles. No parameter search or leverage
increase. Production adoption requires a separate validation decision.
"""
import math

CANDIDATES=('ema_pullback5','channel_break15','bb_reclaim5','vwap_reclaim5','squeeze_break5','regime_mix5')


def features(rows):
    out=[];c=[];vol=[];trs=[];gains=losses=0.;e20=e50=None;session=None;pv=vv=0.
    for i,r in enumerate(rows):
        t,o,h,l,x,v=r
        tr=max(h-l,abs(h-c[-1]),abs(l-c[-1])) if c else h-l
        delta=x-c[-1] if c else 0
        c.append(x);vol.append(v);trs.append(tr)
        e20=x if e20 is None else e20+(x-e20)*2/21
        e50=x if e50 is None else e50+(x-e50)*2/51
        gains=(gains*13+max(0,delta))/14;losses=(losses*13+max(0,-delta))/14
        rs=100-100/(1+gains/losses) if losses else (100. if gains else 50.)
        if t//86400000!=session:session=t//86400000;pv=vv=0.
        pv+=(h+l+x)/3*v;vv+=v
        mid=sum(c[-20:])/min(20,len(c));sd=math.sqrt(sum((a-mid)**2 for a in c[-20:])/min(20,len(c)))
        path=sum(abs(b-a) for a,b in zip(c[-21:],c[-20:])) if len(c)>=21 else 0
        er=abs(c[-1]-c[-21])/path if path else 0.
        out.append(dict(ema20=e20,ema50=e50,rsi=rs,atr=sum(trs[-15:-1])/14 if i>=14 else 0.,
                        mid=mid,upper=mid+2*sd,lower=mid-2*sd,width=4*sd/mid,
                        volume=v/(sum(vol[-21:-1])/20) if i>=20 and sum(vol[-21:-1])>0 else 0.,
                        vwap=pv/vv if vv else x,er=er))
    return out


def signal(b,f,j,b15,f15,k,bh,fh,q,variant):
    if variant not in CANDIDATES:raise ValueError(variant)
    if j<60 or k<60 or q<25:return None
    r=b[j];p=b[j-1];a=f[j];old=f[j-1];hour=fh[q];m=f15[k]
    t=r[0]+300000
    if b15[k][0]+900000>t or bh[q][0]+3600000>t:return None
    if variant=='regime_mix5':variant='ema_pullback5' if hour['er']>=.30 else 'bb_reclaim5'
    use15=variant=='channel_break15'
    if use15:
        if b15[k][0]+900000!=t:return None
        r=b15[k];p=b15[k-1];a=f15[k];old=f15[k-1];rows=b15;ix=k
    else:rows=b;ix=j
    op,hi,lo,cl,vol=r[1:];atr=a['atr'];span=hi-lo
    if not all(math.isfinite(v) for v in (op,hi,lo,cl,atr,span)) or atr<=0 or span<=0:return None
    if span>2.5*atr:return None
    for side in (1,-1):
        strength=(cl-lo if side==1 else hi-cl)/span
        if (cl-op)*side<=0 or strength<.60:continue
        trend=(m['ema20']-m['ema50'])*side>0 and (b15[k][4]-m['ema20'])*side>0
        hourtrend=(hour['ema20']-hour['ema50'])*side>0 and (bh[q][4]-hour['ema20'])*side>0
        ok=False;stopdist=1.5*atr;reward=2.;minutes=60
        if variant=='ema_pullback5':
            edge=p[2] if side==1 else p[3];near=p[3] if side==1 else p[2]
            ok=(trend and hourtrend and a['volume']>=1. and (a['ema20']-a['ema50'])*side>0
                and -.5*atr<=(near-old['ema20'])*side<=.25*atr
                and (p[4]-p[1])*side<0 and (cl-edge)*side>0 and abs(cl-a['ema20'])<=1.5*atr
                and (45<=a['rsi']<=70 if side==1 else 30<=a['rsi']<=55))
        elif variant=='channel_break15':
            recent=rows[ix-20:ix];edge=max(z[2] for z in recent) if side==1 else min(z[3] for z in recent)
            ok=(hourtrend and hour['er']>=.30 and a['volume']>=1.2
                and (p[4]-edge)*side<=0 and .05*atr<(cl-edge)*side<=atr)
            stopdist=2*atr;reward=3.;minutes=120
        elif variant=='bb_reclaim5':
            edge=old['lower'] if side==1 else old['upper'];near=p[3] if side==1 else p[2]
            ok=(hour['er']<.30 and (near-edge)*side<0 and a['lower']<cl<a['upper']
                and (cl-(p[1]+p[4])/2)*side>0 and a['volume']>=1.
                and (a['rsi']-old['rsi'])*side>0 and (old['rsi']<40 if side==1 else old['rsi']>60))
            stopdist=max(1.5*atr,(cl-(min(lo,p[3]) if side==1 else max(hi,p[2])))*side+.1*atr)
            reward=1.5;minutes=45
        elif variant=='vwap_reclaim5':
            ok=(r[0]//86400000==p[0]//86400000 and r[0]%86400000>=3600000
                and trend and a['volume']>=1.2 and (p[4]-old['vwap'])*side<=0
                and .05*atr<(cl-a['vwap'])*side<=atr and (45<=a['rsi']<=70 if side==1 else 30<=a['rsi']<=55))
        elif variant=='squeeze_break5':
            widths=sorted(z['width'] for z in f[j-61:j-1]);recent=rows[ix-10:ix]
            edge=max(z[2] for z in recent) if side==1 else min(z[3] for z in recent)
            ok=(old['width']<=widths[len(widths)//5] and trend and a['volume']>=1.5
                and (p[4]-edge)*side<=0 and .05*atr<(cl-edge)*side<=atr)
            minutes=30
        # Profit distance must exceed twice the assumed round-trip friction.
        if not ok or stopdist/cl>.04 or stopdist*reward/cl<=.004:continue
        stop=cl-side*stopdist
        if stop<=0:continue
        return dict(action='LONG' if side==1 else 'SHORT',reference=cl,structural_stop=stop,atr=atr,
                    signal_ms=r[0],confirmation_ms=r[0],route721=variant,lookback721=20,
                    reward_r=reward,max_hold_minutes=minutes,frame='15m' if use15 else '5m',
                    target=cl+side*stopdist*reward)
    return None

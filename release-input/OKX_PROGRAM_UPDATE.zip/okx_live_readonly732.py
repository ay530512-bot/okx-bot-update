"""Read-only diagnosis. No engine construction, account changes, or order submission."""
import json
import os
import re
import time
from pathlib import Path
from datetime import datetime, timezone, timedelta

from okx_core import OKX, BotError, dec

BUILD = '7.32-Q2G'
ALLOWED_GET = frozenset({
    '/api/v5/public/time', '/api/v5/account/config', '/api/v5/account/positions',
    '/api/v5/trade/order', '/api/v5/trade/orders-algo-pending',
})


class ReadOnlyOKX(OKX):
    def __new__(cls, settings):
        if str(settings.get('TRADING_EXCHANGE') or 'okx').lower() != 'okx':
            raise BotError('OKX 설정만 점검할 수 있습니다.')
        return object.__new__(cls)

    def __init__(self, settings):
        super().__init__(settings)
        self.read_efficiency = False

    def request(self, method, path, params=None, body=None, private=True):
        if method != 'GET' or path not in ALLOWED_GET or body is not None:
            raise BotError('읽기 전용 점검: 허용되지 않은 요청을 차단했습니다.')
        return super().request(method, path, params, body, private)


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.' + str(os.getpid()) + '.tmp')
    try:
        temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def runtime_snapshot(view, mobile=None):
    """Only whitelisted GUI facts, never credentials, raw logs, or connection config."""
    now = int(time.time() * 1000)
    from okx_direction732 import fresh
    gate = view.state.get('entry_gate') or {}
    dock = getattr(view, 'chat_window', None)
    panel = getattr(dock, 'web_chat', None)
    chart = getattr(panel, 'chart', None)
    data = getattr(chart, 'data', None) or {}
    selected = getattr(panel, 'selected', None)
    a = data.get('analysis') or {}
    valid = bool(selected and data.get('symbol') == selected and not data.get('stale')
                 and not data.get('error') and fresh(a, now))
    reason = ('종목을 선택하세요.' if not selected else gate.get('reason', 'PC 주문 허용 상태 미확인'))
    blocked=a.get('entry_block_reason','') if valid else ''
    if blocked:reason=blocked
    enabled = bool(selected and gate.get('allowed') and not view.demo)
    age = max(0, time.monotonic() - view.data_seen) if view.data_seen else None
    result = dict(build=BUILD, captured_ms=now, selected_symbol=selected,
                  pc_button_enabled=enabled, pc_reason=reason,
                  gate_code=gate.get('code'), gate_allowed=bool(gate.get('allowed')),
                  analysis_ready=valid, account_age_seconds=age,
                  live=bool(view.state.get('live')), preview=bool(view.state.get('preview')),
                  run_requested=bool(view.state.get('run_requested')),
                  resume_pending=bool(view.state.get('resume_pending')),
                  pause_reason=view.state.get('pause_reason',''),
                  account_connected=bool(view.state.get('account_connected')),
                  market_connected=bool(view.state.get('market_connected')),
                  mobile_server_available=mobile is not None,
                  browser_click_verified=False)
    if mobile:
        with mobile.lock:
            snapshot = mobile.snapshot
            result['mobile_server_build'] = snapshot.get('ui_version')
            result['mobile_controls_enabled'] = bool(snapshot.get('controls_enabled'))
            result['mobile_snapshot_ms'] = snapshot.get('captured_ms')
    return result


def number(value):
    try:
        return dec(value)
    except Exception:
        return None


def owned_records(journal):
    rows = [journal.get('owned'), journal.get('extra_owned')] + list(journal.get('additional_owned') or [])
    return [r for r in rows if isinstance(r, dict) and r.get('symbol') and r.get('direction')]


def order_evidence(record, rows):
    row = next((r for r in rows if r.get('instId') == record['symbol']
                and r.get('clOrdId') == record['client_id']), None)
    if not row:
        return dict(symbol=record['symbol'], status='미확인', reason='주문 조회 결과에 일치하는 주문 없음')
    filled = number(row.get('accFillSz'))
    avg = number(row.get('avgPx'))
    has_fill = filled is not None and filled > 0 and avg is not None and avg > 0
    return dict(symbol=record['symbol'], client_id=record['client_id'], state=row.get('state'),
                status='체결 확인' if has_fill else '체결 미확인',
                filled_quantity=str(filled) if filled is not None else None,
                average_fill_price=str(avg) if avg is not None else None,
                position_side=row.get('posSide'), margin_mode=row.get('tdMode'),
                created_ms=row.get('cTime'), updated_ms=row.get('uTime'),
                fully_filled=bool(has_fill and row.get('state') == 'filled'),
                has_fill=has_fill)


def sl_evidence(record, positions, algos):
    matches = [p for p in positions if p.get('instId') == record['symbol']
               and p.get('posSide') == record['direction'] and p.get('mgnMode') == 'isolated'
               and (number(p.get('pos')) or 0) > 0]
    base = dict(symbol=record['symbol'], direction=record['direction'])
    if len(matches) != 1:
        return dict(base, status='미확인', reason='정확히 일치하는 격리 포지션 없음 또는 중복')
    p = matches[0]
    if record.get('posId') and str(record['posId']) != str(p.get('posId')):
        return dict(base, status='미확인', reason='포지션 ID 불일치')
    ids = {record.get('algo_client_id')}
    ids.update(r.get('algo_client_id') for r in record.get('legs', []) if isinstance(r, dict))
    ids.discard(None); ids.discard('')
    quantity, mark = number(p.get('pos')), number(p.get('markPx'))
    covered = dec(0)
    accepted, issues, seen = [], [], set()
    close_side = 'sell' if record['direction'] == 'long' else 'buy'
    for a in algos:
        if a.get('algoClOrdId') not in ids or a.get('instId') != record['symbol']:
            continue
        # An absent/duplicate exchange ID cannot prove distinct SL coverage.
        identity = a.get('algoId')
        if not identity or identity in seen:
            continue
        seen.add(identity)
        trigger, size = number(a.get('slTriggerPx')), number(a.get('sz'))
        compatible = (a.get('posSide') == record['direction'] and a.get('tdMode') == 'isolated'
                      and a.get('side') == close_side and a.get('state') == 'live'
                      and a.get('slTriggerPxType') == 'mark' and str(a.get('slOrdPx')) == '-1'
                      and trigger is not None and trigger > 0 and mark is not None and mark > 0
                      and (trigger < mark if record['direction'] == 'long' else trigger > mark))
        if not compatible:
            issues.append('방향/모드/상태/시장가 SL/트리거 위치 중 불일치')
            continue
        if str(a.get('closeFraction')) == '1':
            size = quantity
        if size is None or size <= 0:
            issues.append('SL 수량 미확인')
            continue
        covered += size
        accepted.append(dict(algo_id=identity, trigger=str(trigger), quantity=str(size)))
    full = covered >= quantity
    return dict(base, status='등록 범위 확인' if full else '보호 범위 미확인',
                position_quantity=str(quantity), covered_quantity=str(covered),
                full_coverage=full, stops=accepted, issues=issues,
                actual_leverage=p.get('lever'), configured_leverage=record.get('leverage'),
                leverage_matches=str(p.get('lever')) == str(record.get('leverage')),
                note='조회 시점의 주문 등록 확인입니다. 향후 손절 체결/체결가격 보장이 아닙니다.')


def safe_error(error):
    # Do not copy arbitrary exception text, request headers, URLs or account IDs.
    code = re.search(r'OKX (\d{5,6})', str(error))
    return 'OKX ' + code.group(1) if code else type(error).__name__


def collect(api, journal, heartbeat=None, now_ms=None):
    start = int(time.time()*1000) if now_ms is None else now_ms
    report = dict(build=BUILD, started_ms=start, read_only=True, new_order_sent=False,
                  new_live_fill_test_performed=False, account_status='미확인',
                  orders=[], protection=[], errors=[], runtime=heartbeat or {},
                  limitations=['새 실주문을 생성하는 체결 검사는 수행하지 않음',
                               'PC·모바일 실제 클릭/렌더링/외부 접속은 별도 확인 필요',
                               '서로 다른 조회 시점 사이에 체결/수동청산이 생길 수 있음'])
    if heartbeat:
        age = start - int(heartbeat.get('captured_ms') or 0)
        report['runtime_fresh'] = 0 <= age <= 15000 and heartbeat.get('build') == BUILD
    else:
        report['runtime_fresh'] = False
    def read(path, **params):
        try:
            return api.request('GET', path, params=params or None, private=path != '/api/v5/public/time')
        except Exception as error:
            report['errors'].append(dict(endpoint=path, code=safe_error(error)))
            return None
    times = read('/api/v5/public/time')
    if times:
        server = int(times[0]['ts'])
        current = int(time.time()*1000) if now_ms is None else now_ms
        report['local_clock_offset_ms'] = current - server
    config = read('/api/v5/account/config')
    if config:
        report['account_status'] = '인증 조회 성공'
        report['position_mode'] = config[0].get('posMode')
        report['api_permissions'] = config[0].get('perm')
    positions = read('/api/v5/account/positions', instType='SWAP')
    # Paginate conditional orders, capped explicitly; no protection verdict on incomplete reads.
    algos, after, complete = [], None, False
    for _ in range(5):
        params = dict(ordType='conditional', instType='SWAP', limit='100')
        if after: params['after'] = after
        rows = read('/api/v5/trade/orders-algo-pending', **params)
        if rows is None: break
        algos.extend(rows)
        if len(rows) < 100:
            complete = True; break
        cursor = rows[-1].get('algoId')
        if not cursor or cursor == after: break
        after = cursor
    report['sl_query_complete'] = complete
    owned = owned_records(journal)
    # Current owned entries + up to 8 recent closed entries whose exact IDs are in local journal.
    candidates = owned + list(reversed(journal.get('settlements') or []))[:8]
    used = set()
    for record in candidates[:16]:
        if not isinstance(record, dict) or not record.get('symbol') or not record.get('client_id'): continue
        key = (record['symbol'], record['client_id'])
        if key in used: continue
        used.add(key)
        rows = read('/api/v5/trade/order', instId=key[0], clOrdId=key[1])
        report['orders'].append(order_evidence(record, rows or []))
    for record in owned:
        if positions is None or not complete:
            report['protection'].append(dict(symbol=record['symbol'], status='미확인', reason='포지션/SL 조회가 완전하지 않음'))
        else:
            report['protection'].append(sl_evidence(record, positions, algos))
    report['existing_filled_orders_confirmed'] = sum(bool(r.get('has_fill')) for r in report['orders'])
    report['completed_ms'] = int(time.time()*1000) if now_ms is None else now_ms
    return report


def korean_report(report):
    runtime = report.get('runtime') or {}
    stamp = datetime.fromtimestamp(report['started_ms']/1000, timezone(timedelta(hours=9))).isoformat(timespec='seconds')
    lines = [BUILD + ' 읽기 전용 점검 · ' + stamp,
             '새 실주문/청산/배율 변경: 실행하지 않음. 신규 실체결 검증 완료 아님.',
             '계정: ' + report['account_status'],
             '실행 중 PC 상태: ' + ('최신' if report.get('runtime_fresh') else '미확인/오래됨 · 새 버전 실행 및 종목 선택 후 재검사'),
             'PC 버튼: ' + ('활성 조건 충족' if report.get('runtime_fresh') and runtime.get('pc_button_enabled') else '미확인/비활성'),
             '최근 PC 차단 사유: ' + str(runtime.get('pc_reason') or '실행 상태 없음'),
             '모바일 서버: ' + str(runtime.get('mobile_server_build') or '미확인') + ' / 제어 허용: ' + str(runtime.get('mobile_controls_enabled', '미확인')),
             '기존 진입 주문 체결 확인: ' + str(report.get('existing_filled_orders_confirmed', 0)) + '건',
             '수동 체결·과거 주문 전체를 전수 검사한 결과는 아닙니다.']
    if 'local_clock_offset_ms' in report:
        lines.append('PC 시계 − 거래소 시계(응답지연 포함): ' + str(report['local_clock_offset_ms']) + 'ms')
    for o in report.get('orders', []):
        lines.append('주문 ' + o['symbol'] + ' · ' + o['status'] + ' · 상태 ' + str(o.get('state')) + ' · 체결량 ' + str(o.get('filled_quantity')))
    for p in report.get('protection', []):
        lines.append('SL ' + p['symbol'] + ' · ' + p['status'] + ' · 등록 ' + str(p.get('covered_quantity')) + ' / 포지션 ' + str(p.get('position_quantity')))
        if p.get('actual_leverage'):
            lines.append('실제 배율 ' + str(p['actual_leverage']) + ' / 프로그램 기록 ' + str(p.get('configured_leverage')))
    if not report.get('protection'): lines.append('보유 SL 대조: 프로그램 소유 포지션 기록 없음 또는 자료 없음')
    lines.extend('조회 실패: ' + e['endpoint'] + ' · ' + e['code'] for e in report.get('errors', []))
    lines.extend(report.get('limitations', []))
    lines.append('SL 등록 확인은 실제 손절 체결 시험이나 가격 보장을 뜻하지 않습니다.')
    return '\n'.join(lines) + '\n'


def main(root=None):
    root = Path(root) if root else Path(__file__).resolve().parent
    report = dict(build=BUILD, started_ms=int(time.time()*1000), read_only=True,
                  new_order_sent=False, new_live_fill_test_performed=False,
                  account_status='미확인', errors=[], orders=[], protection=[])
    api = None
    try:
        from dotenv import dotenv_values
        settings = dotenv_values(root/'.env' if (root/'.env').exists() else root.parent/'.env', encoding='utf-8-sig', interpolate=False)
        api = ReadOnlyOKX(settings)
        journal = json.loads((root/'bot_state.json').read_text(encoding='utf-8-sig')) if (root/'bot_state.json').exists() else {}
        heartbeat = None
        try: heartbeat = json.loads((root/'runtime_diagnostic732.json').read_text(encoding='utf-8'))
        except (OSError, ValueError): pass
        report = collect(api, journal, heartbeat)
    except Exception as error:
        report['errors'].append(dict(endpoint='준비 단계', code=safe_error(error)))
    finally:
        if api is not None: api.session.close()
    atomic_json(root/'LIVE_CHECK_RESULT.json', report)
    text = korean_report(report)
    (root/'LIVE_CHECK_RESULT.txt').write_text(text, encoding='utf-8-sig')
    print(text)
    print('LIVE_CHECK_RESULT.txt 및 .json 저장 완료. API 키는 보고서에 포함하지 않습니다.')
    return report


if __name__ == '__main__':
    main()

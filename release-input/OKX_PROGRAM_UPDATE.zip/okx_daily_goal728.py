"""Read-only daily goal accounting; no order, sizing or latch side effects."""
from decimal import Decimal, InvalidOperation

RATE = Decimal('0.06')


def finite(value):
    try:
        result = Decimal(str(value))
        return result if result.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None


def cost_for_day(journal, date):
    """Historical API spend must not be charged to the current trading day."""
    if journal.get('api_day') != date:
        return '0'
    return journal.get('api_spent', '0')


def daily_goal(day, equity, ai_cost='0', expected_date=None):
    d = day or {}
    result = dict(rate=str(RATE), policy='observe_only', status='unavailable',
                  date=d.get('date'), includes_unrealized=True, guaranteed=False,
                  seed=None, target_profit=None, target_equity=None, net_profit=None,
                  net_roi=None, remaining=None, ai_cost=None, progress=None,
                  basis_source=d.get('baseline_source', '기존 일일 장부'),
                  flow_status=d.get('flow_status', '이체 내역 확인 대기'))
    if not d or (expected_date is not None and d.get('date') != expected_date):
        return result
    seed = finite(d.get('start_equity', d.get('base')))
    base, current, cost = map(finite, (d.get('base'), equity, ai_cost))
    if any(v is None for v in (seed, base, current, cost)) or seed <= 0 or cost < 0:
        return result
    target = seed * RATE
    # Exchange equity already incorporates trading fees and funding. Only the
    # separately billed same-day API estimate is subtracted (USD=USDT).
    net = current - base - cost
    result.update(status='reached' if net >= target else 'tracking',
                  seed=str(seed), target_profit=str(target),
                  target_equity=str(base + target + cost), net_profit=str(net),
                  net_roi=float(net / seed), remaining=str(max(Decimal(0), target - net)),
                  ai_cost=str(cost), progress=float(net / target))
    return result


def goal_line(goal):
    if not goal or goal.get('status') == 'unavailable':
        return '하루 +6% 목표 · 당일 기준 자산 확인 대기'
    return ('하루 +6% 목표 +' + f"{finite(goal['target_profit']):.2f} USDT"
            + ' · 순손익 ' + f"{finite(goal['net_profit']):+.2f}"
            + ' · 남은 ' + f"{finite(goal['remaining']):.2f} USDT"
            + (' · 평가 기준 도달' if goal['status'] == 'reached' else ''))

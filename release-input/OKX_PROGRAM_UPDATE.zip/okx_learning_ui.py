"""Read-only learning panel; no model calls or order actions."""
import tkinter as tk
from tkinter import ttk
from pathlib import Path
from datetime import datetime,timedelta
from okx_learning_history import KST,day_view,describe
class LearningPanel(tk.Frame):
 def __init__(self,parent,root=None):
  super().__init__(parent,bg='#050505');self.root_path=Path(root or Path(__file__).resolve().parent);self.job=None
  tk.Label(self,text='AI 학습 내역',fg='#36d5b0',bg='#050505',font=('Malgun Gothic',13,'bold')).pack(anchor='w',padx=8,pady=6)
  row=tk.Frame(self,bg='#050505');row.pack(fill='x');self.date=tk.StringVar(value=datetime.now(KST).strftime('%Y-%m-%d'))
  self.dates=ttk.Combobox(row,textvariable=self.date,width=12,state='readonly');self.dates.pack(side='left',padx=6);self.dates.bind('<<ComboboxSelected>>',lambda e:self.render())
  for name,fn in [('오늘',self.today),('이전 날짜',self.previous),('새로고침',self.render)]:ttk.Button(row,text=name,command=fn,width=9).pack(side='left',padx=2)
  self.tabs=ttk.Notebook(self);self.tabs.pack(fill='both',expand=True,padx=6,pady=6);self.texts={}
  for source,label in [('auto','자동 학습'),('manual','수동 학습')]:
   frame=tk.Frame(self.tabs,bg='#050505');self.tabs.add(frame,text=label)
   bar=ttk.Scrollbar(frame);bar.pack(side='right',fill='y')
   text=tk.Text(frame,wrap='word',bg='#0d1010',fg='#d9e7e3',font=('Malgun Gothic',11),relief='flat',yscrollcommand=bar.set,padx=10,pady=10);text.pack(fill='both',expand=True);bar.config(command=text.yview);self.texts[source]=text
  self.bind('<Destroy>',self.cleanup,add='+');self.render();self.poll()
 def today(self):self.date.set(datetime.now(KST).strftime('%Y-%m-%d'));self.render()
 def previous(self):
  try:d=datetime.strptime(self.date.get(),'%Y-%m-%d')-timedelta(days=1)
  except ValueError:return
  self.date.set(d.strftime('%Y-%m-%d'));self.render()
 def render(self):
  for source,text in self.texts.items():
   data=day_view(self.root_path,self.date.get(),source)
   self.dates['values']=sorted(set(data['dates']+[self.date.get(),datetime.now(KST).strftime('%Y-%m-%d')]),reverse=True)
   header=self.date.get()+' KST · 학습 반영 '+str(data['count'])+'건\n확정 손익 기반 통계 · 수익/손실만으로 진입의 정답 여부를 단정하지 않습니다.\n\n'
   body='\n\n────────────\n\n'.join(describe(i) for i in data['items']) or '이 날짜에 기록된 학습 표본이 없습니다.'
   text.config(state='normal');text.delete('1.0','end');text.insert('1.0',header+body);text.config(state='disabled')
 def poll(self):self.render();self.job=self.after(15000,self.poll)
 def cleanup(self,event):
  if event.widget is self and self.job:
   try:self.after_cancel(self.job)
   except tk.TclError:pass

"""Single-machine, single-process-at-a-time budget shared across the two profiles.
Only cost fields are copied; exchange ownership/state never leaves its journal.
"""
import hashlib,json
from pathlib import Path
from okx_core import BotError
FIELDS=('api_day','api_spent','api_calls','api_total_spent','model_usage','budget_pacing','budget_pacing_initialized')
def path(e):
 setting=e.cfg.get('execution',{}).get('budget_shared_root')
 if setting not in ('.','..'):return None
 root=getattr(e,'settings',{}).get('_SHARED_BUDGET_ROOT')
 return (Path(root).resolve() if root else (Path(e.root)/setting).resolve())/'shared_ai_budget.json'
def read(e):
 file=path(e)
 if file is None or getattr(e,'shared_budget_loaded',False):return
 identity=hashlib.sha256((e.settings.get('OPENAI_API_KEY') or '').encode()).hexdigest()
 if file.exists():
  data=json.loads(file.read_text(encoding='utf-8'))
  if data.get('identity')!=identity:raise BotError('공용 AI 예산 API 키 변경: shared_ai_budget.json 기록 확인 필요')
 else:
  source=file.parent/'bot_state.json'
  data=json.loads(source.read_text(encoding='utf-8')) if source.exists() else dict(e.journal.data)
 for k in FIELDS:
  if k in data:e.journal.data[k]=data[k]
 e.shared_budget_loaded=True
def write(e):
 file=path(e)
 if file is None:return
 from okx_daily_report import atomic_json
 data={k:e.journal.data[k] for k in FIELDS if k in e.journal.data}
 data['identity']=hashlib.sha256((e.settings.get('OPENAI_API_KEY') or '').encode()).hexdigest()
 atomic_json(file,data)

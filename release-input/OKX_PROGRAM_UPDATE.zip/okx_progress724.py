"""Early thesis failure on completed bars, restricted to newly opted-in signals."""
def failed_progress(owned, post, mark, entry, side):
    proof = owned.get('v4_signal', {}).get('decision_record', {}).get('volume_wick_proof', {})
    if not proof.get('progress_exit724') or owned.get('partial_used') or len(post) < 4:
        return False
    a = float(proof.get('atr') or 0)
    if a <= 0:
        return False
    peak = float(owned.get('profit_state714', {}).get('peak_mark') or entry)
    # No stop is raised from a pre-entry candle extreme or estimated peak.
    return ((peak-entry)*side < a and (mark-entry)*side < 0 and
            all((float(r[4])-entry)*side < 0 for r in post[-2:]))

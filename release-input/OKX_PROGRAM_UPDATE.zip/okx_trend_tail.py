"""Closed-bar trend pullback rejection. References frozen before the tail opens."""
from okx_rules import metrics, zones

DEFAULTS = dict(enabled=True, frames=['15m','5m'], reference_periods=[5,10,15,20,50],
    body_ratio=1.5, range_fraction=.4, atr_fraction=.35, close_fraction=.65,
    opposite_fraction=.25, zone_atr=.5, min_relative_volume=.8,
    max_recovery_atr=2.5, max_reference_extension_atr=2.,
    global_extension_atr=3., max_global_body_atr=2.)


def validate(p):
    if type(p.get('enabled')) is not bool:return False
    if p.get('frames') not in (['15m','5m'],['15m'],['5m']):return False
    periods=p.get('reference_periods',[])
    if not periods or any(type(n) is not int or n not in (5,10,15,20,50,100,120,200) for n in periods):return False
    return (p['body_ratio']>0 and 0<p['range_fraction']<1 and 0<p['atr_fraction']<=2
        and .5<p['close_fraction']<1 and 0<p['opposite_fraction']<.5 and 0<p['zone_atr']<=2
        and 0<p['min_relative_volume']<=5 and 0<p['max_recovery_atr']<=5
        and 0<p['max_reference_extension_atr']<=5 and 0<p['global_extension_atr']<=6
        and 0<p['max_global_body_atr']<=5)


def setups(b5,b15,c):
    p=c['signals'].get('trend_tail',{})
    if not p.get('enabled'):return []
    now=b5[-1][0]+300000;out=[]
    need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1
    for frame,step,bars in [('15m',900000,b15),('5m',300000,b5)]:
        if frame not in p['frames']:continue
        closed=[b for b in bars if b[0]+step<=now]
        if len(closed)<need+1:continue
        tail=closed[-1];start=tail[0];end=start+step
        if not end<=now<end+c['signals']['wick15']['entry_window_seconds']*1000:continue
        prior=metrics(closed[:-1],c);current=metrics(closed,c);atr=prior['atr']
        context=[b for b in b15 if b[0]+900000<=start]
        if len(context)<need:continue
        m=metrics(context,c)
        _,o,h,l,cl,v=tail;span=h-l;body=abs(cl-o)
        if span<=0:continue
        low=min(o,cl)-l;up=h-max(o,cl)
        if min(low,up)/span>=p['opposite_fraction']:continue
        levels=[dict(price=sum(b[4] for b in context[-n:])/n,source='15m SMA'+str(n),kind='average') for n in p['reference_periods']]
        levels += [dict(x,source='15m confirmed pivot') for x in zones(context,c)]
        for side in (1,-1):
            # Trend known before entry candle; no future swing confirmation.
            aligned=((m['ma'][15]-m['ma'][20])*side>0 and m['slopes'][20]*side>0
                and m['mid_slope']*side>0 and (cl-m['ma'][20])*side>0)
            if not aligned:continue
            wick=low if side==1 else up;extreme=l if side==1 else h
            location=(cl-l)/span if side==1 else (h-cl)/span
            if not (wick>=body*p['body_ratio'] and wick>=span*p['range_fraction']
                and wick>=atr*p['atr_fraction'] and location>=p['close_fraction']):continue
            if current['relative_volume']<p['min_relative_volume']:continue
            kind='support' if side==1 else 'resistance'
            nearby=[x for x in levels if x['kind'] in (kind,'average')
                and abs(extreme-x['price'])<=atr*p['zone_atr'] and (cl-x['price'])*side>0]
            if not nearby:continue
            level=min(nearby,key=lambda x:abs(extreme-x['price']))
            if (cl-extreme)*side>atr*p['max_recovery_atr']:continue
            if (cl-level['price'])*side>atr*p['max_reference_extension_atr']:continue
            # Must actually pull back from an earlier price, not merely print a tiny wick at a new extreme.
            history=closed[-7:-1]
            excursion=(max(b[2] for b in history)-l) if side==1 else (h-min(b[3] for b in history))
            if excursion<atr*.5:continue
            shape=dict(lower_body=low/max(body,atr*1e-8),upper_body=up/max(body,atr*1e-8),
                lower_fraction=low/span,upper_fraction=up/span,close_location=(cl-l)/span,
                lower_atr=low/atr,upper_atr=up/atr,band_return=current['lower']<=cl<=current['upper'])
            out.append(dict(direction='LONG' if side==1 else 'SHORT',pattern='trend_tail_reclaim',frame=frame,
                low=l,high=h,anchor=start,level=level['price'],source=level['source'],shape=shape,
                adaptive=True,preferred_tail=True,evidence_score=10,
                evidence=dict(trend_aligned=True,closed_tail=True,no_breakout_required=True,
                    relative_volume=current['relative_volume'],tail_atr=wick/atr,close_location=location,
                    band_return=shape['band_return'],bb_mid_slope=m['mid_slope'],reference_frozen_ms=start,
                    recovery_atr=(cl-extreme)*side/atr)))
    return out


def late_entry_reason(hit,last,m5,m15,c):
    p=c['signals'].get('trend_tail',{})
    if not p.get('enabled'):return None
    if hit.get('independent_case'):return None  # Its own execution-frame extension/body/recovery checks already passed.
    side=1 if hit['direction']=='LONG' else -1
    # A late impulse can masquerade as a reversal or shallow pullback in another strategy.
    extension=(last[4]-m5['ma'][20])*side/m5['atr']
    body=abs(last[4]-last[1])/m5['atr']
    if not hit.get('preferred_tail') and (extension>p['global_extension_atr'] or body>p['max_global_body_atr']):
        return '추격 제한: 5m MA20 이격 또는 진입 봉 몸통 과대'
    return None

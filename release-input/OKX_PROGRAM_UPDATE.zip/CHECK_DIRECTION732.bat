@echo off
setlocal
cd /d "%~dp0"
set "BOT_PY=.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=..\.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=python"
set "PYTHONPATH=%CD%;%CD%\tests"
"%BOT_PY%" -m unittest test_click_feedback732 test_live_readonly732 test_direction732 test_direction_mobile732 test_mobile716 test_entry_gate720 test_route_removed732q2 test_quarter732q test_profit_guard714 test_entry722 test_mild726 test_orders714 test_mobile714 test_mobile718 test_click716 test_market717 -v
if errorlevel 1 (
 echo Offline checks failed. Keep the error output.
 pause
 exit /b 1
)
echo Offline regression checks passed. No live orders were sent.
pause

"""60-second whole-universe ranks plus own-token relative-volume screening."""
import math
import threading
import time
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from okx_core import OKX
from okx_market import allowed_altcoin, closed_candles
from okx_rules import metrics, allowed_instrument


def activity(bars,c):
    s=c['selection']; n=s['volume_recent_bars']; history=s['volume_history_bars']
    if len(bars)<history+n: raise ValueError('거래량 비교 이력 부족')
    own=[b[5] for b in bars[-history-n:-n]]
    windows=[sum(own[i:i+n])/n for i in range(len(own)-n+1)]
    recent=sum(b[5] for b in bars[-n:])/n
    prior=sum(b[5] for b in bars[-2*n:-n])/n
    baseline=sum(own)/len(own)
    percentile=100*sum(v<=recent for v in windows)/len(windows)
    relative=recent/baseline if baseline>0 else 0
    growth=recent/prior if prior>0 else 0
    active=percentile>=s['volume_percentile'] and relative>=s['relative_volume']
    if s.get('volume_growth_required',True):active=active and growth>=s['volume_growth']
    return dict(percentile=percentile,relative=relative,growth=growth,active=active)


def qualifies(rank, a, c):
    if c['selection'].get('mode') in ('hourly_volume','scalp_volume'): return a['active']
    return rank<=c['selection']['turnover_top_n'] or a['active']


def candidate_score(rank, count, a, c):
    if c['selection'].get('mode') in ('hourly_volume','scalp_volume'):
        return a['relative']+min(a['growth'],10)*.25+a['percentile']/100
    return 1-rank/max(1,count)+(min(a['relative'],5)/5 if a['active'] else 0)


def mover_selection(valid, tickers, now, c):
    """UTC00 = KST09. Never substitute rolling24h or fill one side from the other."""
    start=now//86400000*86400000
    positive=[];negative=[];invalid=0
    for turnover,i in valid:
        t=tickers[i['instId']]
        try:
            opening=float(t['sodUtc0']);last=float(t['last'])
            if not (math.isfinite(opening) and math.isfinite(last) and opening>0 and last>0
                    and int(t['ts'])//86400000*86400000==start):raise ValueError('기준 시가 미확인')
            change=last/opening-1
            if not math.isfinite(change):raise ValueError('등락률 미확인')
        except (KeyError,TypeError,ValueError,OverflowError):
            invalid+=1;continue
        item=dict(symbol=i['instId'],change=change,ranking_start_ms=start)
        if change>0:positive.append(item)
        elif change<0:negative.append(item)
    positive.sort(key=lambda x:(-x['change'],x['symbol']))
    negative.sort(key=lambda x:(x['change'],x['symbol']))
    positive=positive[:c['selection']['gainers_count']];negative=negative[:c['selection']['losers_count']]
    selected=[]
    for n in range(max(len(positive),len(negative))):
        for group,items in (('gainer',positive),('loser',negative)):
            if n<len(items):selected.append(dict(items[n],mover_group=group,mover_rank=n+1))
    return selected,invalid


class Universe:
    def __init__(self,settings,c):
        self.settings=settings; self.cfg=c; self.lock=threading.RLock()
        self.result=None; self.error=None; self.stop_event=threading.Event();self.search_paused=threading.Event();self.search_wake=threading.Event();self.search_generation=0
        self.rate_lock=threading.Lock(); self.last_request=0
        self.full_market=None
        if c['execution'].get('whole_market'):
            from okx_full_market import FullMarket
            self.full_market=FullMarket(self)
    def set_search_paused(self,paused):
        if bool(paused)==self.search_paused.is_set():return
        self.search_generation+=1
        if paused:self.search_paused.set()
        else:self.search_paused.clear()
        self.search_wake.set()
    def request_rescan(self):
        with self.lock:
            self.search_generation+=1
            self.result=None
        self.search_wake.set()
    def start(self):
        if self.full_market:threading.Thread(target=self.full_market.quote_loop,daemon=True,name='whole-market-quotes').start()
        threading.Thread(target=self.run,daemon=True,name='universe-refresh').start()
    def market_read(self):return self.full_market.market() if self.full_market else None
    def throttle(self,requests_per_second=None):
        with self.rate_lock:
            delay=max(0,1/(requests_per_second or self.cfg['selection']['rest_requests_per_second'])-(time.monotonic()-self.last_request))
            if delay: self.stop_event.wait(delay)
            self.last_request=time.monotonic()
    def bars(self,api,symbol,bar='5m',token_volume=False):
        if self.stop_event.is_set() or self.search_paused.is_set():raise RuntimeError('신규 탐색 중지')
        self.throttle()
        from okx_entry_pipeline import candle_rows
        rows=candle_rows(api,symbol,bar,self.cfg)
        if token_volume:
            rows=[list(r) for r in rows]
            for r in rows: r[7]=r[5]  # Own-token contracts, never cross-token raw quantity ranking.
        now=api.now_ms(); bars=closed_candles(rows,bar,now)
        step={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}[bar]
        if bars[-1][0]!=now//step*step-step: raise ValueError('최신 마감 봉 대기')
        return bars
    def scan(self):
        if self.full_market:return self.full_market.scan()
        started=time.monotonic(); counts=Counter(); count_lock=threading.Lock()
        def count(reason):
            with count_lock:counts[reason]+=1
        api=OKX(self.settings);worker_apis=[]
        try:
            now=api.now_ms(); c=self.cfg
            instruments=api.public('/api/v5/public/instruments',instType='SWAP')
            tickers={r['instId']:r for r in api.public('/api/v5/market/tickers',instType='SWAP')}
            # Explicit crypto category excludes stock/index/ETF linked products, regardless of issuer name.
            valid=[]
            for i in instruments:
                t=tickers.get(i['instId'])
                if not allowed_instrument(i,c) or not t: continue
                if not i.get('listTime') or now-int(i['listTime'])<c['selection']['min_listing_days']*86400000: continue
                if not 0<=now-int(t['ts'])<=60000: continue
                # SWAP volCcy24h is base asset volume; conversion is explicitly approximate at last price.
                try: turnover=float(t['volCcy24h'])*float(t['last'])
                except (KeyError,ValueError,TypeError): turnover=0
                if c['selection'].get('mode') not in ('hourly_volume','scalp_volume','kst09_movers') and turnover<=0: continue
                valid.append((turnover,i))
            valid.sort(key=lambda x:x[0],reverse=True)
            mover_mode=c['selection'].get('mode')=='kst09_movers'
            metadata={}; selected_count=0
            if mover_mode:
                selected,invalid=mover_selection(valid,tickers,now,c)
                metadata={r['symbol']:r for r in selected};counts['ranking_invalid']=invalid
                ranks={i['instId']:(rank,(turnover,i)) for rank,(turnover,i) in enumerate(valid,1)}
                work=[ranks[r['symbol']] for r in selected];selected_count=len(work)
            else:work=list(enumerate(valid,1))
            workers=threading.local()
            def one(item):
                if self.stop_event.is_set():return None
                rank,(turnover,i)=item
                if not hasattr(workers,'api'):
                    workers.api=OKX(self.settings)
                    with count_lock:worker_apis.append(workers.api)
                try:
                    frame=c['selection'].get('volume_timeframe','5m')
                    volume_bars=self.bars(workers.api,i['instId'],frame,token_volume=True)
                    a=activity(volume_bars,c)
                    a.update(timeframe=frame,closed_at_ms=volume_bars[-1][0])
                    if not mover_mode and not qualifies(rank,a,c):
                        count('volume_filter');return None
                    b=volume_bars if frame=='5m' else self.bars(workers.api,i['instId'],token_volume=True)
                    m=metrics(b,c)
                    jump=max(abs(x[4]/p[4]-1) for p,x in zip(b[-7:-1],b[-6:]))
                    abnormal=(jump>c['selection']['max_bar_return'] or m['atr']/m['close']>c['selection']['max_atr_fraction']
                              or a['relative']>c['selection']['max_volume_ratio'])
                    if abnormal:
                        count('abnormal_volatility');return None
                    return dict(metadata.get(i['instId'],{}),symbol=i['instId'],instrument=i,turnover=turnover,rank=rank,activity=a,
                                volume_bars=volume_bars,
                                bars5=b,observed_ms=workers.api.now_ms(),
                                score=candidate_score(rank,len(valid),a,c))
                except Exception as error:
                    count('screen_error_'+type(error).__name__);return None
            with ThreadPoolExecutor(max_workers=6) as pool:
                rows=[r for r in pool.map(one,work) if r]
            if not mover_mode:rows.sort(key=lambda r:r['score'],reverse=True)
            # Refresh focus 15m closed charts. The trade engine revalidates immediately before orders.
            focus=[]
            for r in rows:
                if self.stop_event.is_set():break
                try:
                    r['bars15']=self.bars(api,r['symbol'],'15m')
                    metrics(r['bars15'],c)
                    scalp=c['signals'].get('wick15',{}).get('scalp_enabled',False) and c['signals'].get('entry_mode')=='wick15'
                    r['higher']={}
                    extra_frames=('1m','1H','4H') if c['signals'].get('support_entries',{}).get('enabled') else ('1H','4H')
                    for bar in extra_frames:
                        try:
                            b=(r['volume_bars'] if bar==c['selection'].get('volume_timeframe','5m') else self.bars(api,r['symbol'],bar))
                            if not scalp:metrics(b,c)
                            r['higher'][bar]=b
                            if scalp and len(b)<max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1:
                                count('optional_'+bar+'_short_history')
                        except Exception:
                            if not scalp:raise
                            r['higher'][bar]=[];count('optional_'+bar+'_unavailable')
                    r['observed_ms']=api.now_ms();focus.append(r)
                    if len(focus)>=c['selection']['focus_count']:break
                except Exception as error:
                    count('focus_error_'+type(error).__name__);continue
            return dict(rows=focus,all_candidates=len(rows),universe=len(valid),completed=time.monotonic(),ms=api.now_ms(),
                        scan_seconds=round(time.monotonic()-started,2),filter_counts=dict(counts),selected_count=selected_count,
                        ranking_start_ms=now//86400000*86400000 if mover_mode else None)
        finally:
            api.session.close()
            for worker_api in worker_apis:worker_api.session.close()
    def run(self):
        while not self.stop_event.is_set():
            if self.search_paused.is_set():self.stop_event.wait(.5);continue
            self.search_wake.clear()
            start=time.monotonic();generation=self.search_generation
            try:
                result=self.scan()
                with self.lock:
                    if not self.search_paused.is_set() and generation==self.search_generation:self.result=result; self.error=None
            except Exception as error:
                with self.lock:
                    if not self.search_paused.is_set() and generation==self.search_generation:self.error=type(error).__name__; self.result=None
            delay=max(0,self.cfg['selection']['refresh_seconds']-(time.monotonic()-start))
            if self.cfg.get('execution',{}).get('rule_channel701'):
                # Retry missing exchange confirmations promptly inside the existing
                # 90-second entry window. Completed frames are reused without REST.
                wall=time.time();phase=wall%900
                delay=min(delay,0.5 if phase<90 else 900-phase+.1)
            end=time.monotonic()+delay
            while not self.stop_event.is_set() and not self.search_wake.wait(min(.5,max(0,end-time.monotonic()))):
                if time.monotonic()>=end:break
    def read(self):
        with self.lock: return self.result,self.error

"""Native child WebView only. No external browser, DOM bridge or trading callbacks."""
import os
from pathlib import Path
import tkinter as tk
from urllib.parse import urlsplit

URL='https://chatgpt.com/'
def web_options(profile,new_window):
 return dict(url=URL,user_data_dir=str(profile),untrusted=True,open_external=False,
             devtools=False,clipboard=True,on_new_window=new_window,
             on_navigation=lambda event:urlsplit(event.url).scheme=='https')

class ChatGPTDock(tk.Frame):
 def __init__(self,parent):
  super().__init__(parent,bg='#050505');self.web=None;self.destroyed=False
  bar=tk.Frame(self,bg='#101112');bar.pack(fill='x')
  for label,fn in [('ChatGPT 시작',self.start),('새로고침',self.reload),('입력',self.focus_browser)]:
   tk.Button(bar,text=label,command=fn,bg='#173a31',fg='white',relief='flat').pack(side='left',padx=3,pady=4)
  self.status=tk.StringVar(value='구독 ChatGPT · 창 내부 표시 · 최초 로그인 필요')
  tk.Label(self,textvariable=self.status,bg='#050505',fg='#a8b4b0',wraplength=420,justify='left').pack(fill='x')
  self.host=tk.Frame(self,bg='#050505');self.host.pack(fill='both',expand=True)
  self.bind('<Destroy>',self.cleanup,add='+')
 def start(self):
  if self.destroyed:return
  if self.web is not None:self.focus_browser();return
  if os.name!='nt':self.status.set('이 내장 버전은 Windows용입니다.');return
  try:
   from tkwry import WebView,NewWindowResponse
   profile=Path(os.environ['LOCALAPPDATA'])/'OKXChatGPTWebView2';profile.mkdir(parents=True,exist_ok=True)
   # Deny separate top-level popups; follow HTTPS links in the existing view.
   def new_window(event):
    if urlsplit(event.url).scheme=='https':self.after_idle(lambda url=event.url:self.navigate(url))
    return NewWindowResponse.Deny
   self.web=WebView(self.host,**web_options(profile,new_window))
   self.web.when_failed(self.failed)
   self.status.set('내장 ChatGPT · 이 칸에서 로그인 후 대화하세요')
  except Exception as error:
   self.failed(error)
 def failed(self,error):
  if self.destroyed:return
  old=self.web;self.web=None
  if old is not None:
   try:old.destroy()
   except Exception:pass
  self.status.set('내장 브라우저 시작 실패 ('+type(error).__name__+') · SETUP_EMBEDDED_CHAT.bat 실행 및 WebView2 Runtime 확인')
 def navigate(self,url):
  if self.web is not None and not self.destroyed:
   try:self.web.load_url(url)
   except Exception:self.status.set('페이지 이동 실패 · 새로고침 후 다시 로그인하세요')
 def reload(self):
  if self.web is None:self.start();return
  try:self.web.reload()
  except Exception:self.status.set('새로고침 실패 · 프로그램을 다시 실행하세요')
 def focus_browser(self):
  if self.web is not None:
   try:self.web.focus()
   except Exception:pass
 def cleanup(self,event):
  if event.widget is not self:return
  self.destroyed=True
  if self.web is not None:
   try:self.web.destroy()
   except Exception:pass
   self.web=None

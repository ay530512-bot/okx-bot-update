"""USDT order-book arithmetic and loss-limited plans, shared by live/replay tests."""
from decimal import ROUND_DOWN, ROUND_UP
from okx_core import BotError, dec, fmt


def book_check(book, instrument, quantity, direction, now_ms, cfg):
    from okx_pattern15 import enabled,book as selected
    if enabled(cfg):return selected(book,instrument,quantity,direction,now_ms,cfg)
    c=cfg['liquidity']; ct=dec(instrument['ctVal']); q=dec(quantity)
    if q<=0 or ct<=0: raise BotError('주문 수량/계약 승수 오류')
    if not -500<=now_ms-int(book['ts'])<=c['max_book_age_ms']: raise BotError('호가 지연')
    sides={}
    for name in ('bids','asks'):
        levels=[(dec(r[0]),dec(r[1])) for r in book[name]]
        if not levels or any(p<=0 or n<0 for p,n in levels): raise BotError('호가 데이터 오류')
        if levels!=sorted(levels,reverse=name=='bids'): raise BotError('호가 순서 오류')
        sides[name]=levels
    bid=sides['bids'][0][0]; ask=sides['asks'][0][0]; mid=(bid+ask)/2
    spread=(ask-bid)/mid
    if spread<0: raise BotError('호가 데이터 오류: 매수·매도 가격 역전')
    band=cfg.get('signals',{}).get('band_flow',{}).get('enabled',False) and not cfg.get('signals',{}).get('oct23_entry',{}).get('enabled',False)
    if not band and spread>dec(c['max_spread']):
        raise BotError(f"유동성 부족: 스프레드 {spread*100:.4f}% > 허용 {dec(c['max_spread'])*100:.4f}%")
    notional=q*ct*(ask if direction=='long' else bid)
    band=dec(c['depth_band'])
    depths={name:sum((p*n*ct for p,n in levels if mid*(1-band)<=p<=mid*(1+band)),dec(0)) for name,levels in sides.items()}
    if not band and any(v<notional*dec(c['depth_multiple']) for v in depths.values()):
        raise BotError(f"유동성 부족: ±{band*100:.3f}% 양쪽 잔량 / 매수 {fmt(depths['bids'])}, 매도 {fmt(depths['asks'])} USDT / 필요 {fmt(notional*dec(c['depth_multiple']))} USDT")
    left=q; cost=dec(0); worst=None
    for p,n in sides['asks' if direction=='long' else 'bids']:
        used=min(left,n); cost+=used*ct*p; left-=used
        if used: worst=p
        if left==0: break
    if left>0: raise BotError('호가 부족: 주문 전체 체결 추정 불가')
    average=cost/(q*ct); touch=ask if direction=='long' else bid
    slip=abs(average/touch-1)
    if not band and slip>dec(c['max_slippage']): raise BotError('예상 슬리피지 초과')
    # Estimate a conservative entry price for risk arithmetic; market orders cannot enforce this cap.
    tick=dec(instrument['tickSz']); limit=touch*(1+dec(c['max_slippage']) if direction=='long' else 1-dec(c['max_slippage']))
    limit=(limit/tick).to_integral_value(rounding=ROUND_DOWN if direction=='long' else ROUND_UP)*tick
    if band:limit=worst
    if (direction=='long' and (limit<ask or worst>limit)) or (direction=='short' and (limit>bid or worst<limit)):
        raise BotError('호가 단위/최악 체결가가 슬리피지 한도 초과')
    return dict(spread=float(spread),slippage=float(slip),bid_depth_usdt=fmt(depths['bids']),
                ask_depth_usdt=fmt(depths['asks']),notional=fmt(notional),limit_px=fmt(limit),mid=fmt(mid))


def risk_plan(plan,instrument,signal,direction,equity,available,fee,funding,cfg,open_risk=0,day_room=None):
    from okx_pattern15 import enabled,risk as selected
    if enabled(cfg):return selected(plan,instrument,signal,direction,equity,available,fee,funding,cfg,open_risk,day_room)
    r=cfg['risk']; ct=dec(instrument['ctVal']); lot=dec(instrument['lotSz']); tick=dec(instrument['tickSz'])
    sign=1 if direction=='long' else -1; lev=r['leverage']
    price=dec(plan['buy' if sign==1 else 'sell']); stop=dec(signal['stop'])
    band=signal.get('strategy')=='band_flow'
    hard=stop if band else price*(1+dec(r['final_stop_roe'])/lev if sign==1 else 1-dec(r['final_stop_roe'])/lev)
    if signal.get('strategy')=='wick15_rejection' and (stop-hard)*sign<0:
        raise BotError('꼬리 밖 SL과 ROE 최종 손절 한도 충돌: 배율 축소 또는 진입 취소')
    stop=max(stop,hard) if sign==1 else min(stop,hard)
    rounding=(ROUND_DOWN if sign==1 else ROUND_UP) if signal.get('adaptive') else (ROUND_UP if sign==1 else ROUND_DOWN)
    stop=(stop/tick).to_integral_value(rounding=rounding)*tick
    if not band and signal.get('adaptive') and (stop-hard)*sign<0:
        raise BotError('구조 손절의 호가 반올림 후 최종 손실 한도 초과')
    if signal.get('strategy')=='wick15_rejection':
        extreme=dec(signal['tail_low' if sign==1 else 'tail_high'])
        if (stop-extreme)*sign>=0:raise BotError('호가 단위로 꼬리 밖 SL 확보 불가: 진입 취소')
    distance=(price-stop)*sign
    if distance<=0: raise BotError('진입 전 손절가 도달')
    # Funding can change: reserve absolute current rate for configured holding periods, never count rebates as profit.
    cost_rate=2*abs(dec(fee))+abs(dec(funding))*r['max_holding_funding_periods']+dec(cfg['liquidity']['max_slippage'])+dec(r['stop_slippage_buffer'])
    per_contract=ct*(distance+price*cost_rate)
    allowance=min(dec(equity)*dec(r['max_position_loss_fraction']),
                  dec(equity)*dec(r['max_open_stop_loss_fraction'])-dec(open_risk))
    if day_room is not None: allowance=min(allowance,dec(day_room))
    if allowance<=0: raise BotError('위험 한도: 남은 손실 허용액 없음')
    q=min(dec(plan['quantity']),(allowance/per_contract/lot).to_integral_value(rounding=ROUND_DOWN)*lot,
          (dec(available)*(dec(1) if plan.get('fixed_initial') else dec(r['initial_margin_fraction']))*lev/(ct*price)/lot).to_integral_value(rounding=ROUND_DOWN)*lot)
    if plan.get('fixed_initial') and q!=dec(plan['initial_quantity']):
        raise BotError('설정 비율 고정 진입 불가: 손절 위험 또는 가용잔고 한도로 수량 축소 필요')
    if q<dec(instrument['minSz']): raise BotError(f"위험 한도로 최소 주문 수량 미달: 계산 {fmt(q)}계약 / 최소 {instrument['minSz']}계약")
    reward=(dec(signal['target'])-price)*sign-price*cost_rate
    ratio=reward/(distance+price*cost_rate)
    if reward<=0 or ratio<dec(r['min_reward_risk']): raise BotError(f"수수료·슬리피지·펀딩비 반영 기대 손익비 미달: {ratio:.3f} / 필요 {r['min_reward_risk']} / 진입 {fmt(price)} / 손절 {fmt(stop)} / 목표 {signal['target']}")
    plan=dict(plan); plan.update(quantity=fmt(q),margin_bound=fmt(q*ct*price/lev),estimated_loss=fmt(q*per_contract),
                    cost_rate=fmt(cost_rate),reward_risk=fmt(reward/(distance+price*cost_rate)))
    plan[direction+'_stop']=fmt(stop)
    return plan


def fit_book_quantity(book,instrument,quantity,direction,now_ms,cfg):
    """Reduce size to unchanged depth/slippage limits; never trade below exchange minimum."""
    if cfg.get('execution',{}).get('pattern15_only'):
        q=dec(quantity);lot=dec(instrument['lotSz']);minimum=dec(instrument['minSz'])
        q=(q/lot).to_integral_value(rounding=ROUND_DOWN)*lot
        if q<minimum:raise BotError('최소 주문 수량 미달')
        return fmt(q),book_check(book,instrument,q,direction,now_ms,cfg)
    minimum=dec(instrument['minSz']);lot=dec(instrument['lotSz']);ct=dec(instrument['ctVal'])
    desired=dec(quantity)
    if desired<minimum:raise BotError('유동성 조정 전 최소 주문 수량 미달')
    # Validates freshness, ordering, spread and the feasibility of even the smallest order.
    tiny=book_check(book,instrument,minimum,direction,now_ms,cfg)
    side='asks' if direction=='long' else 'bids';touch=dec(book[side][0][0]);limit=dec(tiny['limit_px'])
    depth_cap=min(dec(tiny['bid_depth_usdt']),dec(tiny['ask_depth_usdt']))/dec(cfg['liquidity']['depth_multiple'])/(ct*touch)
    executable=sum((dec(r[1]) for r in book[side] if (dec(r[0])<=limit if direction=='long' else dec(r[0])>=limit)),dec(0))
    q=(min(desired,depth_cap,executable)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
    if q<minimum:raise BotError('유동성 조정 후 최소 주문 수량 미달')
    check=book_check(book,instrument,q,direction,now_ms,cfg)
    return fmt(q),check

"""Selected-exchange public WebSocket plus read-only account polling.

Public data is never substituted with OKX or another exchange. Account freshness
is based on a completed REST snapshot, explicitly labelled as REST in the UI.
"""
import json,threading,time
from okx_stream import MarketStream,AccountStream
from okx_exchange_adapter import FuturesAdapter,exchange_id

class FuturesMarketStream(MarketStream):
 def __init__(self,settings,api_factory=None):
  super().__init__();self.settings=dict(settings);self.exchange=exchange_id(settings);self.factory=api_factory or (lambda:FuturesAdapter(settings));self.native={};self.book={};self.last_trade={}
 def monitor(self,symbols):pass # Whole-universe tickers remain the exchange's REST feed.
 def _put(self,s,ch,row):
  # Reuse timestamp/sequence/freshness checks and band-bar updates from the engine.
  super().feed(json.dumps({'arg':{'channel':ch,'instId':s},'data':[row]}))
 def feed_native(self,message):
  if message=='pong':return
  obj=json.loads(message)
  if obj.get('event')=='error' or obj.get('code') not in (None,'0',0):raise ValueError('선택 거래소 WS 구독 거절')
  if self.exchange=='binance':
   r=obj.get('data',obj);s=self.native.get(str(r.get('s','')).upper())
   if not s:
    stream=obj.get('stream','').split('@')[0].upper();s=self.native.get(stream)
   if not s:return
   event=r.get('e');stamp=str(r.get('T') or r.get('E') or '')
   if not stamp:return
   if event=='aggTrade':
    self.last_trade[s]=(r['p'],stamp);self._put(s,'trades',dict(ts=stamp,px=r['p'],sz=r['q'],side='sell' if r.get('m') else 'buy'));self._ticker(s)
   elif event=='bookTicker':self.book[s]=(r['b'],r['a'],stamp);self._ticker(s)
   elif event=='markPriceUpdate':self._put(s,'mark-price',dict(ts=stamp,markPx=r['p']))
   elif 'bids' in r or 'b' in r and isinstance(r['b'],list):
    bids=r.get('bids',r.get('b'));asks=r.get('asks',r.get('a'));self._put(s,'books5',dict(ts=stamp,bids=bids,asks=asks))
  else:
   channel=obj.get('arg',{}).get('channel');s=self.native.get(str(obj.get('arg',{}).get('instId','')).upper())
   if not s:return
   for r in obj.get('data',[]):
    stamp=str(r.get('ts') or obj.get('ts') or '')
    if not stamp:continue
    if channel=='ticker':
     self._put(s,'tickers',dict(ts=stamp,last=r['lastPr'],bidPx=r['bidPr'],askPx=r['askPr']))
     if r.get('markPrice'):self._put(s,'mark-price',dict(ts=stamp,markPx=r['markPrice']))
    elif channel=='trade':self._put(s,'trades',dict(ts=stamp,px=r['price'],sz=r['size'],side=r['side']))
    elif channel=='books5':self._put(s,'books5',dict(ts=stamp,bids=r['bids'],asks=r['asks']))
 def _ticker(self,s):
  if s not in self.book or s not in self.last_trade:return
  bid,ask,bts=self.book[s];last,tts=self.last_trade[s]
  self._put(s,'tickers',dict(ts=str(min(int(bts),int(tts))),last=last,bidPx=bid,askPx=ask))
 def run(self):
  import websocket
  api=None
  try:
   api=self.factory()
   while not self.stop_event.is_set():
    try:
     with self.lock:symbols=tuple(sorted(self.symbols))
     if not symbols:self.stop_event.wait(.2);continue
     native={api.market(s)['id'].upper():s for s in symbols};self.native=native
     if self.exchange=='binance':
      streams=[n.lower()+'@'+ch for n in native for ch in ('bookTicker','aggTrade','depth5@100ms','markPrice@1s')]
      url='wss://fstream.binance.com/stream?streams='+'/'.join(streams)
     else:url='wss://ws.bitget.com/v2/ws/public'
     if str(self.settings.get('EXCHANGE_DEMO','0'))=='1':
      # Use the explicitly documented demo endpoint only, never production fallback.
      url=url.replace('fstream.binance.com','demo-fstream.binance.com') if self.exchange=='binance' else 'wss://wspap.bitget.com/v2/ws/public'
     ws=websocket.create_connection(url,timeout=10);ws.settimeout(1)
     with self.lock:self.ws=ws;self.connected=True;self.generation+=1;self.data={};self.book={};self.last_trade={};self.error=None
     if self.exchange=='bitget':ws.send(json.dumps({'op':'subscribe','args':[dict(instType='USDT-FUTURES',channel=ch,instId=n) for n in native for ch in ('ticker','trade','books5')]}))
     ping=time.monotonic()
     while not self.stop_event.is_set():
      with self.lock:changed=tuple(sorted(self.symbols))!=symbols and time.monotonic()-self.watch_changed>2
      if changed:break
      if self.exchange=='bitget' and time.monotonic()-ping>=20:ws.send('ping');ping=time.monotonic()
      try:
       msg=ws.recv()
       if not msg:raise OSError('WS 종료')
       self.feed_native(msg);self.retry_delay=2
      except websocket.WebSocketTimeoutException:continue
    except Exception as e:self.error=type(e).__name__
    finally:
     with self.lock:
      self.connected=False
      if self.ws:
       try:self.ws.close()
       except Exception:pass
      self.ws=None
    if self.error:self.stop_event.wait(self.retry_seconds())
  finally:
   if api:api.session.close()

class FuturesAccountStream(AccountStream):
 def __init__(self,settings,callback,api_factory=None):
  super().__init__(settings,callback);self.factory=api_factory or (lambda:FuturesAdapter(settings));self.transport='REST';self.reconnect_event=threading.Event()
 def reconnect(self):
  self.connected=False;self.equity=None;self.received=0;self.generation+=1;self.reconnect_event.set();self.error='계정 REST 재연결'
 def run(self):
  api=None
  try:
   api=self.factory()
   while not self.stop_event.is_set():
    try:
     s=api.snapshot()
     if not self.connected:self.generation+=1
     self.connected=True;self.equity=float(s['equity']);self.received=time.monotonic();self.error=None
     self.callback('equity',dict(equity=self.equity,ms=s['ms']))
     for p in s['positions']:self.callback('position',p)
    except Exception as e:self.connected=False;self.received=0;self.error=type(e).__name__
    self.reconnect_event.wait(3);self.reconnect_event.clear()
  finally:
   if api:api.session.close()
 def stop(self):self.stop_event.set();self.reconnect_event.set()

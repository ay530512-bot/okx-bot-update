'use strict';
let activePart='home';
const partKeys=['home','market','chart','positions','settings'];
const UI_BUILD='7.32-Q2O';
const $=id=>document.getElementById(id),state={data:{},symbol:null,frame:'15m',bars:[],end:null,count:65,scale:1,chartKey:'',chartData:null,busy:false,chartBusy:false,historyBusy:false,shift:0};
const num=v=>v===null||v===undefined||v===''||!Number.isFinite(Number(v))?null:Number(v);
const cash=(v,signed=false,digits=2)=>{v=num(v);return v===null?'—':(signed&&v>0?'+':'')+v.toLocaleString('en-US',{minimumFractionDigits:digits,maximumFractionDigits:digits})};
const price=v=>num(v)===null?'—':Number(v).toLocaleString('en-US',{maximumSignificantDigits:7,useGrouping:false});
const color=(el,v)=>{el.classList.toggle('positive',num(v)>0);el.classList.toggle('negative',num(v)<0)};
const kst=ms=>new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false}).format(new Date(ms));
const node=(tag,text,cls)=>{let e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e};
async function api(path,options={}){const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),10000);let r,d;try{r=await fetch(path,{cache:'no-store',credentials:'same-origin',...options,signal:controller.signal});d=await r.json()}finally{clearTimeout(timer)};if(r.status===401){showLogin();throw Error(d.error||'다시 로그인하세요.')}if(!r.ok)throw Error(d.error||'조회 실패');return d}
function showLogin(){cancelControl();$('login').hidden=false;$('dashboard').hidden=true;$('logout').hidden=true;state.symbol=null;state.bars=[]}
function showDashboard(){$('login').hidden=true;$('dashboard').hidden=false;$('logout').hidden=false}
$('loginForm').onsubmit=async e=>{e.preventDefault();$('loginError').textContent='';try{await api('/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});$('password').value='';showDashboard();await refresh()}catch(e){$('loginError').textContent=e.message}};
$('logout').onclick=async()=>{try{await api('/logout',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})}finally{showLogin()}};
function render(d){state.data=d;renderUpdateNotice(d.update_notice);const u=d.program_update||{};$('mobileUpdateButton').disabled=!d.controls_enabled||!!u.busy;$('mobileUpdateStatus').textContent=u.message||'PC 업데이트 상태 대기';$('livePrepare').disabled=!d.controls_enabled||controlBusy;$('pauseEntries').disabled=!d.controls_enabled||controlBusy;const s=d.state||{};const versionMatch=d.ui_version===UI_BUILD;if(!versionMatch)syncVersion(d.ui_version);$('mobileBuild').textContent=versionMatch?'모바일 V7.32-Q2O 다크 · 15m 전용 · PC 연결 버전 일치 · KST09시 기준':'버전 불일치 · PC '+(d.ui_version||'확인 중')+' / 모바일 '+UI_BUILD+' · 화면 다시 불러오기 필요';const age=d.account_age_seconds;const old=!versionMatch||!d.captured_ms||Date.now()-d.captured_ms>15000||age===null||age>30;$('status').textContent=(old?'자료 지연 · ':'')+(d.status||'PC 계정 자료 대기');$('status').classList.toggle('warning',old||s.recovering||!s.account_connected);$('fresh').textContent=d.captured_ms?'PC 화면 갱신 '+kst(d.captured_ms)+' KST · 계정 자료 '+(age===null?'미확인':Math.round(age)+'초 전')+' · 0.5초 간격 조회 · 실제 수신은 연결 상태에 따라 지연':'PC 프로그램을 실행하세요.';$('equity').textContent=cash(s.equity);$('profit').textContent=cash(s.day_profit,true);color($('profit'),s.day_profit);$('available').textContent=cash(s.available);$('cost').textContent='$'+cash(s.api_spent,false,3);
renderGoal(s.daily_goal,old||!s.account_connected);
let positions=d.positions||[];$('closeAll').disabled=tradeBusy||!d.controls_enabled||old||!positions.length;$('count').textContent=positions.length;if(![...positions,...(d.movers||[]),...(d.futures?.rows||[])].some(p=>p.symbol===state.symbol)){state.symbol=positions[0]?.symbol||null;state.bars=[];state.end=null;state.chartKey=''}
$('positions').replaceChildren();for(let p of positions){let e=node('button',undefined,'position'+(p.symbol===state.symbol?' selected':''));e.type='button';e.onclick=()=>{setPart('chart');chooseChart(p.symbol);render(state.data)};let row=node('div',undefined,'row');row.append(node('span',p.symbol.replace('-USDT-SWAP','/USDT'),'symbol'),node('span',(p.source==='manual'?'수동':'자동')+' · '+(p.direction==='short'?'숏':'롱')+' '+p.leverage+'×','badge'));e.append(row);let metrics=node('div',undefined,'metrics');for(let [title,value,v] of [['증거금 USDT',cash(p.margin),null],['ROE',cash(num(p.roe)===null?null:num(p.roe)*100,true)+'%',p.roe],['손익 USDT',cash(p.pnl,true),p.pnl],['진입가',price(p.entry),null],['현재가',price(p.mark),null],['보호 SL',price(p.stop),null]]){let box=node('div');box.append(node('span',title));let b=node('b',value);if(v!==null)color(b,v);box.append(b);metrics.append(box)}e.append(metrics);if(p.protection_note)e.append(node('p',p.protection_note,'muted'));$('positions').append(e);if(p.close_key){let close=node('button','이 포지션 전량 청산','danger closeone');close.disabled=tradeBusy||!d.controls_enabled||old||p.phase==='closing';close.onclick=()=>trade('close_one',{key:p.close_key});$('positions').append(close)}}if(!positions.length)$('positions').append(node('p','보유 포지션이 없습니다.','muted'));
renderMovers(d.movers||[]);renderMarket();renderActivities(d.activities||[]);}
async function refresh(){if(document.hidden||state.busy)return;state.busy=true;try{let d=await api('/api/snapshot');showDashboard();render(d);if(activePart==='chart'&&!state.chartKey)void refreshChart()}catch(e){if(!$('dashboard').hidden){$('status').textContent='연결 지연 · '+e.message;$('status').classList.add('warning');renderGoal(state.data.state?.daily_goal,true)}}finally{state.busy=false}}
async function refreshChart(older=false){if(!state.symbol||state.chartBusy||document.hidden)return;state.chartBusy=true;state.lastChartRequest=Date.now();const key=state.symbol+':'+state.frame;try{let d=await api('/api/chart?symbol='+encodeURIComponent(state.symbol)+'&frame='+state.frame+(older?'&older=1':''));if(key!==state.symbol+':'+state.frame)return;state.chartKey=key;state.chartData=d;state.fundingReceivedAt=Date.now();state.bars=d.bars||[];draw();updateTradeButtons()}catch(e){$('chartInfo').textContent=e.message}finally{state.chartBusy=false}}
function draw(){chartGeometry=null;$('candleTip').hidden=true;let canvas=$('chart'),ctx=canvas.getContext('2d');let w=canvas.clientWidth,h=canvas.clientHeight;if(!w)return;let ratio=window.devicePixelRatio||1;canvas.width=w*ratio;canvas.height=h*ratio;ctx.scale(ratio,ratio);ctx.fillStyle='#0c0c0c';ctx.fillRect(0,0,w,h);let data=state.bars;let p=(state.data.positions||[]).find(p=>p.symbol===state.symbol)||([...(state.data.movers||[]),...(state.data.futures?.rows||[])].some(p=>p.symbol===state.symbol)?{symbol:state.symbol}:null);$('chartTitle').textContent=p?p.symbol.replace('-USDT-SWAP','/USDT')+' · '+state.frame:'포지션 차트';if(!p||!data.length){$('chartInfo').textContent=p?(state.chartData?.error||'차트 조회 중'):'보유 포지션이 없습니다.';return}let end=state.end===null?data.length:data.findIndex(b=>b[0]>state.end);if(end<0)end=data.length;end=Math.max(1,end);let start=Math.max(0,end-state.count),bars=data.slice(start,end),n=bars.length;const cfg=state.data.indicators||{},bbn=cfg.bb_period||20,k=cfg.bb_multiplier||2,periods=cfg.ma_periods||[50,100,120,150,200,240],series=[];for(let period of periods){let line=[];for(let j=start;j<end;j++)line.push(j+1>=period?data.slice(j-period+1,j+1).reduce((s,r)=>s+r[4],0)/period:null);series.push(line)}let mid=[],upper=[],lower=[];for(let j=start;j<end;j++){let a=data.slice(Math.max(0,j-bbn+1),j+1).map(r=>r[4]);if(a.length<bbn){mid.push(null);upper.push(null);lower.push(null);continue}let m=a.reduce((s,x)=>s+x,0)/a.length,sd=Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/a.length);mid.push(m);upper.push(m+k*sd);lower.push(m-k*sd)}let values=bars.flatMap(b=>[b[2],b[3]]).concat(upper.filter(x=>x!==null),lower.filter(x=>x!==null));let low=Math.min(...values),high=Math.max(...values),center=(low+high)/2,half=Math.max(high-low,high*.002)*.57/state.scale;low=center-half;high=center+half;let offset=state.shift*(high-low);low+=offset;high+=offset;let right=w-68,top=16,bottom=h-70,volTop=h-57,volBottom=h-23;let x=j=>8+(j+.5)*(right-8)/(n+10),y=v=>top+(high-v)/(high-low)*(bottom-top);ctx.font='10px system-ui';for(let j=0;j<5;j++){let v=low+(high-low)*j/4,yy=y(v);ctx.strokeStyle='#333333';ctx.beginPath();ctx.moveTo(8,yy);ctx.lineTo(right,yy);ctx.stroke();ctx.fillStyle='#bcbcbc';ctx.fillText(price(v),right+5,yy+3)}ctx.save();ctx.beginPath();ctx.rect(8,top,right-8,bottom-top);ctx.clip();let line=(a,col,dash=[])=>{ctx.strokeStyle=col;ctx.lineWidth=1;ctx.setLineDash(dash);ctx.beginPath();let open=false;for(let j=0;j<a.length;j++){if(a[j]===null){open=false;continue}if(open)ctx.lineTo(x(j),y(a[j]));else ctx.moveTo(x(j),y(a[j]));open=true}ctx.stroke();ctx.setLineDash([])};[mid,upper,lower].forEach(a=>line(a,'#e5bd72'));series.forEach((a,i)=>line(a,['#e5bd72','#63c8da','#b293ed','#ed9dad','#80c6a2','#a4b4cf'][i%6]));let bw=Math.max(1,(right-8)/(n+10)*.6);bars.forEach((b,j)=>{ctx.strokeStyle=ctx.fillStyle=b[4]>=b[1]?'#50d7b1':'#ff8296';ctx.beginPath();ctx.moveTo(x(j),y(b[2]));ctx.lineTo(x(j),y(b[3]));ctx.stroke();ctx.fillRect(x(j)-bw/2,Math.min(y(b[1]),y(b[4])),bw,Math.max(1,Math.abs(y(b[4])-y(b[1]))))});for(let [field,label,col] of [['entry','진입','#50d7b1'],['stop','SL','#ff8296'],['target','재평가','#e5bd72']]){let v=num(p[field]);if(v===null||v<low||v>high)continue;line(Array(n).fill(v),col,[4,4]);ctx.fillStyle=col;ctx.fillText(label+' '+price(v),12,y(v)-4)}ctx.restore();let maxVol=Math.max(...bars.map(b=>b[5]),1);bars.forEach((b,j)=>{ctx.fillStyle=b[4]>=b[1]?'#50d7b1':'#ff8296';let vh=(volBottom-volTop)*b[5]/maxVol;ctx.fillRect(x(j)-bw/2,volBottom-vh,bw,vh)});ctx.fillStyle='#bcbcbc';ctx.fillText(kst(bars[0][0]),8,h-5);ctx.textAlign='right';ctx.fillText(kst(bars[n-1][0]),right,h-5);ctx.textAlign='left';chartGeometry={bars,n,x,y,right,top,bottom,volBottom};paintCandleTip(ctx,w,h);$('chartInfo').textContent=(state.end===null?'최신 구간':'과거 구간')+' · '+(state.chartData?.observed_ms?kst(state.chartData.observed_ms)+' KST':'')+((state.chartData?.stale||Date.now()-(state.chartData?.observed_ms||0)>35000)?' · 차트 자료 지연':'')+' · 마지막 봉 '+(bars[n-1][6]?'마감':'진행 중');}
function pan(delta){let b=state.bars;if(!b.length)return;let end=state.end===null?b.length:b.findIndex(r=>r[0]>state.end);if(end<0)end=b.length;end=Math.max(Math.min(state.count,b.length),Math.min(b.length,end+delta));state.end=end===b.length?null:b[end-1][0];if(end-state.count<5)refreshChart(true);draw()}
$('left').onclick=()=>pan(-15);$('right').onclick=()=>pan(15);$('latest').onclick=()=>{state.end=null;state.scale=1;state.shift=0;draw();refreshChart()};$('older').onclick=()=>refreshChart(true);$('zoomIn').onclick=()=>{state.count=Math.max(20,state.count-10);draw()};$('zoomOut').onclick=()=>{state.count=Math.min(200,state.count+10);draw()};$('verticalIn').onclick=()=>{state.scale=Math.min(4,state.scale*1.2);draw()};$('verticalOut').onclick=()=>{state.scale=Math.max(.5,state.scale/1.2);draw()};$('frame').onchange=()=>{state.frame=$('frame').value;state.end=null;state.bars=[];state.chartKey='';draw();updateTradeButtons();refreshChart()};let fingers=new Map(),drag=null,pinch=null;
const chart=$('chart');
let chartGeometry=null,candleSelection=null,pressPoint=null,holdTimer=null,inspecting=false;
function clearCandle(){candleSelection=null;$('candleTip').hidden=true;}
function selectCandle(clientX,clientY){
 const r=chart.getBoundingClientRect(),g=chartGeometry;if(!g)return;
 const xx=clientX-r.left,yy=clientY-r.top,step=(g.right-8)/(g.n+10),i=Math.floor((xx-8)/step);
 if(xx<8||xx>=8+g.n*step||yy<g.top||yy>g.volBottom){clearCandle();draw();return}
 candleSelection={time:g.bars[i][0],symbol:state.symbol,frame:state.frame};draw();
}
function paintCandleTip(ctx,w,h){
 const tip=$('candleTip'),g=chartGeometry,sel=candleSelection;
 if(!sel||!g||sel.symbol!==state.symbol||sel.frame!==state.frame){tip.hidden=true;return}
 const i=g.bars.findIndex(b=>b[0]===sel.time);if(i<0){tip.hidden=true;return}
 const b=g.bars[i],xx=g.x(i),yy=Math.max(g.top,Math.min(g.bottom,g.y(b[4])));
 ctx.save();ctx.strokeStyle='#ffab54';ctx.setLineDash([4,4]);ctx.beginPath();ctx.moveTo(xx,g.top);ctx.lineTo(xx,g.volBottom);ctx.moveTo(8,yy);ctx.lineTo(g.right,yy);ctx.stroke();ctx.restore();
 const base=(state.symbol||'').replace('-USDT-SWAP',''),change=b[4]-b[1],pct=100*change/b[1];
 tip.replaceChildren(node('strong',kst(b[0])+' KST · '+(b[6]?'확정봉':'진행봉')));
 const rows=[['시가',price(b[1])],['고가',price(b[2])],['저가',price(b[3])],['종가',price(b[4])],['등락',price(change)],['등락률',cash(pct,true)+'%'],['진폭',cash((b[2]-b[3])/b[1]*100)+'%'],['거래량 (계약)',cash(b[5])]];
 if(num(b[7])!==null)rows.push(['거래량 ('+base+')',cash(b[7])]);
 if(num(b[8])!==null)rows.push(['거래대금 (USDT)',cash(b[8])]);
 for(const [label,value] of rows){const row=node('div',undefined,'tip-row'),v=node('span',value);if(label==='등락률')color(v,pct);row.append(node('span',label),v);tip.append(row)}
 tip.hidden=false;const tw=tip.offsetWidth,th=tip.offsetHeight;
 tip.style.left=Math.max(4,Math.min(w-tw-4,xx>w/2?xx-tw-12:xx+12))+'px';
 tip.style.top=Math.max(4,Math.min(h-th-4,yy-th/2))+'px';
}
chart.addEventListener('pointerdown',e=>{
 chart.setPointerCapture(e.pointerId);fingers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 clearTimeout(holdTimer);inspecting=false;pressPoint={x:e.clientX,y:e.clientY,moved:false};
 drag={x:e.clientX,y:e.clientY,axis:e.offsetX>chart.clientWidth-68};
 if(fingers.size===2){clearCandle();let p=[...fingers.values()];pinch={distance:Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y),count:state.count};pressPoint.moved=true}
 else if(e.pointerType==='touch'){holdTimer=setTimeout(()=>{inspecting=true;selectCandle(e.clientX,e.clientY)},280)}
 else selectCandle(e.clientX,e.clientY);
});
chart.addEventListener('pointermove',e=>{
 if(!fingers.has(e.pointerId)){if(e.pointerType==='mouse')selectCandle(e.clientX,e.clientY);return}
 fingers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(fingers.size===2&&pinch){let p=[...fingers.values()],d=Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y);state.count=Math.max(20,Math.min(200,Math.round(pinch.count*pinch.distance/Math.max(1,d))));draw();return}
 if(inspecting){selectCandle(e.clientX,e.clientY);return}
 if(pressPoint&&!pressPoint.moved){if(Math.hypot(e.clientX-pressPoint.x,e.clientY-pressPoint.y)<8)return;pressPoint.moved=true;clearTimeout(holdTimer);clearCandle()}
 if(!drag)return;let dx=e.clientX-drag.x,dy=e.clientY-drag.y;
 if(drag.axis)state.scale=Math.max(.5,Math.min(4,state.scale*Math.exp(dy*.008)));
 else{let step=Math.round(-dx*(state.count+10)/Math.max(100,chart.clientWidth-76));if(step)pan(step);state.shift+=dy/Math.max(100,chart.clientHeight-86)}
 drag={x:e.clientX,y:e.clientY,axis:drag.axis};draw();
});
for(let type of ['pointerup','pointercancel','lostpointercapture'])chart.addEventListener(type,e=>{
 clearTimeout(holdTimer);if(type==='pointerup'&&fingers.size===1&&pressPoint&&!pressPoint.moved&&!inspecting)selectCandle(e.clientX,e.clientY);
 fingers.delete(e.pointerId);drag=null;pinch=null;pressPoint=null;inspecting=false;
});
chart.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'&&!fingers.size){clearCandle();draw()}});
chart.addEventListener('wheel',e=>{e.preventDefault();state.count=Math.max(20,Math.min(200,state.count+(e.deltaY>0?5:-5)));draw()},{passive:false});
window.addEventListener('resize',draw);
$('positionsTab').onclick=()=>{$('current').hidden=false;$('history').hidden=true;$('positionsTab').classList.add('selected');$('historyTab').classList.remove('selected');draw();refreshChart()};$('historyTab').onclick=()=>{$('current').hidden=true;$('history').hidden=false;$('historyTab').classList.add('selected');$('positionsTab').classList.remove('selected');loadHistory()};$('historyDate').value=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
async function loadHistory(){if(state.historyBusy)return;state.historyBusy=true;$('historySummary').textContent='조회 중';try{let d=await api('/api/history?date='+$('historyDate').value+'&source='+$('historySource').value);$('historySummary').textContent=d.count+'건 · 수익 '+cash(d.summary.profit,true)+' / 손실 '+cash(d.summary.loss,true)+' / 순손익 '+cash(d.summary.total,true)+' USDT';$('historyBasis').textContent=d.basis;$('historyRows').replaceChildren();for(let p of d.rows){let e=node('article',undefined,'historyrow'),row=node('div',undefined,'row'),v=node('b',cash(p.pnl,true)+' USDT');color(v,p.pnl);row.append(node('b',p.symbol.replace('-USDT-SWAP','/USDT')),v);e.append(row,node('small',({auto:'자동',manual:'수동',unknown:'미분류',mixed:'혼합'})[p.source]+' · '+(p.direction==='short'?'숏':'롱')),node('p','진입 '+p.entry_time+' KST\n청산 '+p.exit_time+' KST'));$('historyRows').append(e)}}catch(e){$('historySummary').textContent=e.message}finally{state.historyBusy=false}}
$('historyRefresh').onclick=loadHistory;$('historySource').onchange=loadHistory;$('historyDate').onchange=loadHistory;document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh()});

let controlBusy=false,controlTicket=null,confirmDeadline=0;
function cancelControl(){controlTicket=null;confirmDeadline=0;$('confirmPanel').hidden=true;}
function clientId(){const c=globalThis.crypto;if(c?.randomUUID)return c.randomUUID().replaceAll('-','');if(c?.getRandomValues){const b=new Uint8Array(16);c.getRandomValues(b);return Array.from(b,x=>x.toString(16).padStart(2,'0')).join('')}throw Error('보안 요청 ID를 만들 수 없습니다. HTTPS 모바일 주소로 다시 접속하세요.');}
async function control(op,ticket){let queued=await api('/api/control/'+op,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:clientId(),...(ticket?{ticket}:{} )})});$('controlStatus').textContent=queued.message;for(let i=0;i<40;i++){await new Promise(r=>setTimeout(r,1000));let result=await api('/api/control/result?id='+queued.request_id);if(result.status!=='queued')return result;}throw Error('PC 응답 지연 · 현재 실거래 상태를 확인하세요. 성공으로 확인되지 않았습니다.');}
async function runControl(op,ticket){controlBusy=true;$('livePrepare').disabled=true;$('pauseEntries').disabled=true;try{let result=await control(op,ticket);$('controlStatus').textContent=result.message;if(result.status==='prepared'){controlTicket=result.ticket;confirmDeadline=Date.now()+result.expires_in*1000;$('controlSummary').replaceChildren();for(let [key,value] of result.summary){let r=node('div',undefined,'row');r.append(node('span',key),node('span',value));$('controlSummary').append(r)}$('confirmWarning').textContent=result.message;$('confirmPanel').hidden=false;$('confirmPanel').scrollIntoView({behavior:'smooth',block:'center'});}else{cancelControl();await refresh();}}catch(e){cancelControl();$('controlStatus').textContent=e.message;}finally{controlBusy=false;$('livePrepare').disabled=!state.data.controls_enabled;$('pauseEntries').disabled=!state.data.controls_enabled;}}
$('livePrepare').onclick=()=>{cancelControl();runControl('prepare')};$('liveCancel').onclick=cancelControl;$('liveConfirm').onclick=()=>{if(controlBusy)return;if(!controlTicket||Date.now()>confirmDeadline){cancelControl();$('controlStatus').textContent='확인 시간이 지났습니다. 다시 시작을 눌러 설정을 조회하세요.';return}let ticket=controlTicket;cancelControl();runControl('confirm',ticket)};$('pauseEntries').onclick=()=>{cancelControl();runControl('pause')};

function chooseChart(symbol){state.symbol=symbol;state.end=null;state.shift=0;state.bars=[];state.chartData=null;state.chartKey='';draw();updateTradeButtons();refreshChart()}
function renderMovers(rows){for(let [id,positive,label] of [['moversUp',true,'상승'],['moversDown',false,'하락']]){let box=$(id);box.replaceChildren(node('b',label));for(let row of rows.filter(r=>positive?r.change>0:r.change<0).slice(0,5)){let b=node('button',row.symbol.replace('-USDT-SWAP','')+' '+cash(row.change*100,true)+'%',positive?'positive':'negative');b.append(node('small','현재가 '+price(row.last)+' USDT'));b.onclick=()=>{setPart('chart');chooseChart(row.symbol);requestAnimationFrame(draw)};box.append(b)}}}
function closeChart(){$('chartHome').after($('chartPanel'));if($('chartDialog').open)$('chartDialog').close();chooseChart(state.symbol||state.data.positions?.[0]?.symbol||null);requestAnimationFrame(draw)}
$('chartClose').onclick=closeChart;$('chartDialog').addEventListener('cancel',e=>{e.preventDefault();closeChart()});


let tradeBusy=false,marketSignature='';
function analysisReady(){let a=state.chartData?.analysis;return !!(a?.ready&&a.symbol===state.symbol&&!state.chartData?.stale&&!state.chartData?.error&&Date.now()-a.observed_ms>=0&&Date.now()-a.observed_ms<35000&&Date.now()-a.quote_ms>=0&&Date.now()-a.quote_ms<35000&&[['15m',900000],['1H',3600000]].every(([f,t])=>a.frames?.[f]?.close_ms===Math.floor(Date.now()/t)*t));}
function renderFunding(){
 const f=state.chartData?.funding,elapsed=Date.now()-(state.fundingReceivedAt||0),el=$('fundingPreview');
 if(!state.symbol||f?.symbol!==state.symbol){el.textContent='선택 종목 펀딩 자료 조회 중';return}
 if(!f.usable){el.textContent=state.chartData.funding_text||'펀딩 자료 확인 중 · 예상액 미표시';return}
 if(elapsed<0||elapsed>=Math.min(30000,f.valid_for_ms||0)){el.textContent='펀딩 자료 지연 또는 정산 시각 경과 · 새 값 확인 중 · 예상액 미표시';return}
 el.textContent=state.chartData.funding_text;
}
function renderAnalysis(){renderFunding();let a=state.chartData?.analysis,ready=analysisReady();$('longScore').textContent=ready?'롱 '+a.long_score.toFixed(1)+'%':'롱 —';$('shortScore').textContent=ready?'숏 '+a.short_score.toFixed(1)+'%':'숏 —';$('directionAnalysis').textContent=ready?state.chartData.analysis_text:('분석 대기 · '+(a?.reason||'최신 확정봉·시세 수신 중'));}
function entryBlockReason(){let d=state.data,s=d.state||{},f=d.futures||{};
if(!state.symbol)return '먼저 종목을 선택하세요.';


if(tradeBusy)return '앞선 주문 요청을 처리 중입니다.';
if(d.ui_version!==UI_BUILD)return '버전 불일치 · PC '+(d.ui_version||'확인 중')+' / 모바일 '+UI_BUILD+' · 상단 화면 다시 불러오기를 누르세요.';
if(!d.controls_enabled)return '모바일 운용 제어가 꺼져 있습니다.';
if(!d.entry_gate)return 'PC 주문 허용 상태를 확인 중입니다.';
if(!d.entry_gate.allowed)return '['+d.entry_gate.code+'] '+d.entry_gate.reason;
if(!s.live||s.preview)return '상단 실거래 시작을 눌러 활성화하세요.';
if(s.recovering||!s.account_connected)return '계정 연결·기존 주문 대조 중입니다.';
if(s.ended)return '당일 운용이 중단된 상태입니다.';
if(!d.captured_ms||Date.now()-d.captured_ms>15000||!Number.isFinite(Number(d.account_age_seconds))||d.account_age_seconds===null||Number(d.account_age_seconds)>30)return 'PC 계정 자료가 지연됐습니다. 연결을 확인하세요.';
if(f.stale||Date.now()-(f.observed_ms||0)>30000||!(f.rows||[]).some(r=>r.symbol===state.symbol))return '선택 종목의 최신 전체 시세 수신을 기다리는 중입니다.';
if((d.positions||[]).some(p=>p.symbol===state.symbol))return '이미 보유하거나 주문 중인 종목입니다. 동일 종목 중복 진입은 하지 않습니다.';
if((d.positions||[]).length>=4)return '최대4개 보유 한도입니다. 개별 청산 후 진입할 수 있습니다.';
return '';}
function entryAllowed(){return !entryBlockReason();}
function updateTradeButtons(){renderAnalysis();let symbol=state.symbol,reason=entryBlockReason(),label=symbol?symbol.replace('-USDT-SWAP','/USDT')+' · 직접 진입':'종목 선택';
$('chartTradeSymbol').textContent=label+' · '+(reason||'롱·숏 요청 가능 · 주문 전 최종 점검');$('marketSelected').textContent=label+' · '+(reason||'롱·숏 요청 가능 · 주문 전 최종 점검');
for(let id of ['marketLong','marketShort','chartLong','chartShort'])$(id).disabled=!!reason;}
function renderMarket(force=false){let d=state.data,f=d.futures||{},query=$('marketSearch').value.trim().toUpperCase(),sort=$('marketSort').value;let rows=(f.rows||[]).filter(r=>r.symbol.includes(query));rows.sort(sort==='name'?((a,b)=>a.symbol.localeCompare(b.symbol)):sort==='up'?((a,b)=>a.change-b.change):((a,b)=>b.change-a.change));$('marketSummary').textContent=rows.length+'종목 · KST09시 등락률 · '+(f.stale||Date.now()-(f.observed_ms||0)>30000?'시세 지연':kst(f.observed_ms)+' 갱신');let sig=[f.observed_ms,query,sort,state.symbol].join('|');if(force||sig!==marketSignature){marketSignature=sig;let box=$('marketRows'),scroll=box.scrollTop;box.replaceChildren();for(let r of rows){let b=node('button',undefined,'marketrow'+(r.symbol===state.symbol?' selected':''));b.append(node('span',r.symbol.replace('-USDT-SWAP','/USDT')),node('span',price(r.last)),node('b',cash(r.change*100,true)+'%',r.change>=0?'positive':'negative'));b.onclick=()=>{state.symbol=r.symbol;$('marketSelected').textContent=r.symbol.replace('-USDT-SWAP','/USDT')+' · 직접 진입';setPart('chart');chooseChart(r.symbol);renderMarket(true);$('chartPanel').scrollIntoView({behavior:'smooth',block:'start'})};box.append(b)}box.scrollTop=scroll;}updateTradeButtons();}
function setTradeStatus(message,op='entry'){const ids=op==='entry'?['tradeStatus','chartTradeStatus']:[op==='close_all'?'closeAllStatus':'closeOneStatus'];for(const id of ids){const el=$(id);if(el)el.textContent=message;}}
async function trade(op,fields){
 if(tradeBusy)return;
 const feedback=message=>setTradeStatus(message,op);
 if(op==='entry'){const reason=entryBlockReason();if(reason){feedback(reason);return}}
 tradeBusy=true;
 try{
  feedback('요청 전송 중 · '+(fields.symbol||'선택 포지션')+' · 아직 주문/체결 완료가 아닙니다.');
  renderMarket();document.querySelectorAll('.closeone').forEach(b=>b.disabled=true);
  const id=clientId();
  const q=await api('/api/control/'+op,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:id,...fields})});
  feedback(q.message);
  for(let j=0;j<80;j++){
   await new Promise(r=>setTimeout(r,500));
   const d=await api('/api/control/result?id='+q.request_id);
   feedback(d.message||'PC 처리 확인 중');
   if(d.status!=='queued'){if(d.entry_gate)state.data.entry_gate=d.entry_gate;updateTradeButtons();return}
  }
  feedback('PC 응답 지연 · 재클릭 전에 실제 포지션과 주문 내역을 확인하세요.');
 }catch(e){feedback('요청 확인: '+e.message)}
 finally{tradeBusy=false;try{renderMarket();await refresh()}catch(e){feedback('화면 갱신 실패 · 재클릭 전에 주문 내역 확인: '+e.message)}}
}

$('chartLong').onclick=()=>trade('entry',{symbol:state.symbol,direction:'LONG'});$('chartShort').onclick=()=>trade('entry',{symbol:state.symbol,direction:'SHORT'});
$('marketSearch').oninput=()=>renderMarket(true);$('marketSort').onchange=()=>renderMarket(true);$('marketLong').onclick=()=>trade('entry',{symbol:state.symbol,direction:'LONG'});$('marketShort').onclick=()=>trade('entry',{symbol:state.symbol,direction:'SHORT'});
refresh();setInterval(refresh,500);setInterval(()=>{if(!document.hidden&&activePart==='chart'&&!$('dashboard').hidden)refreshChart()},500);

setInterval(()=>{if(!$('dashboard').hidden){updateTradeButtons();const d=state.data,s=d.state||{},elapsed=(Date.now()-(d.captured_ms||0))/1000;renderGoal(s.daily_goal,d.ui_version!==UI_BUILD||!d.captured_ms||elapsed>15||num(d.account_age_seconds)===null||num(d.account_age_seconds)+elapsed>30||!s.account_connected)}},1000);

// Goal display has no control or order side effects.
function renderGoal(g,stale){
 const output=$('dailyGoalValue'),note=$('dailyGoalNote');
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 const valid=g&&g.date===today&&g.status!=='unavailable'&&num(g.target_profit)!==null&&num(g.remaining)!==null;
 output.classList.remove('positive','negative');
 if(!valid){output.textContent='당일 기준 자산 확인 대기';note.textContent='KST 00시 일일 장부 기준 · 목표 수익은 보장되지 않습니다.';return;}
 output.textContent=(stale?'자료 지연 · 마지막 관측 ':'')+'목표 +'+cash(g.target_profit)+' / 순손익 '+cash(g.net_profit,true)+' / 남은 '+cash(g.remaining)+' USDT';
 note.textContent=(g.status==='reached'&&!stale?'평가 기준 도달 · ':'')+'입출금 제외 · 수수료·펀딩 반영 · 미청산·수동 손익 포함 · 당일 AI 비용 추정 $'+cash(g.ai_cost,false,3)+' 차감. 도달 후에도 변동하며 자동 중단하지 않습니다.';
 if(!stale)color(output,g.net_profit);
}

$('reloadView').onclick=()=>{if(tradeBusy||controlBusy){setTradeStatus('주문 처리 결과 확인 후 화면을 다시 불러오세요.');return}location.reload()};
document.addEventListener('visibilitychange',()=>{if(!document.hidden){void refresh();void refreshChart()}});

$('closeAll').onclick=()=>{if(!tradeBusy&&confirm('수동 보유를 포함한 모든 USDT 선물 포지션을 시장가로 청산하고 신규 진입을 중지할까요?'))trade('close_all',{})};

// Stable address; static assets and snapshots are no-store at the server.
{const u=new URL(location.href);if(u.searchParams.has('v')){u.searchParams.delete('v');history.replaceState(null,'',u.pathname+u.search+u.hash)}}
function syncVersion(remote){
 if(!remote||tradeBusy||controlBusy)return;
 const key='okx-reloaded-build';
 try{if(sessionStorage.getItem(key)===remote)return;sessionStorage.setItem(key,remote)}catch(e){return}
 location.reload();
}
function renderActivities(rows){
 const box=$('activities'),sig=JSON.stringify(rows);if(box.dataset.signature===sig)return;
 const atTop=box.scrollTop<8,previous=box.scrollTop;const anchor=[...box.children].find(e=>e.offsetTop+e.offsetHeight>box.offsetTop+previous);const anchorText=anchor?.textContent,anchorY=anchor?.getBoundingClientRect().top;
 box.dataset.signature=sig;box.replaceChildren();
 for(const a of rows){const e=node('article',undefined,'activity');e.append(node('time',a.time+' KST'),node('p',a.text));box.append(e)}
 box.scrollTop=atTop?0:previous;const same=[...box.children].find(e=>e.textContent===anchorText);if(!atTop&&same&&Number.isFinite(anchorY))box.scrollTop+=same.getBoundingClientRect().top-anchorY;
}

$('mobileUpdateButton').onclick=async()=>{
 if(!confirm('PC에 저장한 GitHub 저장소에서 새 버전을 확인하고 설치할까요? 보유 포지션·미체결·조건주문이 없을 때 PC 프로그램이 재시작됩니다.'))return;
 const button=$('mobileUpdateButton');button.disabled=true;
 try{
  const client_id='update_'+crypto.randomUUID().replaceAll('-','');
  const r=await api('/api/control/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id})});
  $('mobileUpdateStatus').textContent=r.message;
  for(let i=0;i<35;i++){
   await new Promise(resolve=>setTimeout(resolve,1000));
   const status=await api('/api/control/result?id='+encodeURIComponent(r.request_id));
   if(status.status!=='queued'){
    $('mobileUpdateStatus').textContent=status.message;
    if(status.status==='failed'||status.status==='timeout')alert(status.message);
    break;
   }
  }
 }catch(e){$('mobileUpdateStatus').textContent='응답 미확인 · 연결 복구 후 버전을 확인하세요: '+e.message}
 finally{button.disabled=false;}
};

function renderUpdateNotice(n){
 const el=$('updateNotice');el.hidden=!n?.available;$('globalUpdateNotice').hidden=!n?.available;$('nav-settings').classList.toggle('has-update',!!n?.available);
 el.textContent=n?.available?'새 업데이트 '+(n.version||'')+' · 업데이트하세요':'';
}

function setPart(key){
 if(!partKeys.includes(key))return;
 activePart=key;
 for(const part of partKeys){
  $('part-'+part).hidden=part!==key;
  $('nav-'+part).classList.toggle('active',part===key);
  $('nav-'+part).setAttribute('aria-pressed',String(part===key));
 }
 window.scrollTo({top:0,behavior:'instant'});
 if(key==='chart'){requestAnimationFrame(draw);void refreshChart()}
}
for(const key of partKeys)$('nav-'+key).onclick=()=>setPart(key);
$('globalUpdateNotice').onclick=()=>setPart('settings');

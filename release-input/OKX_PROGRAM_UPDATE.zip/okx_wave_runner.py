"""Causal swing context and structure-bounded trailing for autonomous positions."""
import math
from okx_band_flow import STEPS

def wave_context(packet,position,order,now):
 side=1 if order['direction']=='long' else -1
 signal=order.get('v4_signal',{});frame=signal.get('setup_frame') or order.get('holding_rule',{}).get('frame')
 data=packet.get('frames',{}).get(frame,{})
 bars=data.get('swing_recent') or data.get('recent',[])
 atr=float(data.get('atr') or 0);step=STEPS.get(frame,0);completed=data.get('completed_ms',0)
 if not bars or not math.isfinite(atr) or atr<=0 or not step or not 0<=now-completed<step:return dict(available=False,reason='진입 시간봉의 최신 완료봉 자료 부족')
 # Only a pivot with two later completed bars is confirmed. No future/live candles.
 entry_ms=int(order.get('entry_ms') or 0)
 bars=[b for b in bars if b[0]+step<=now]
 if not bars or any(bars[i][0]-bars[i-1][0]!=step for i in range(1,len(bars))):return dict(available=False,reason='연속 완료봉 자료 부족')
 pivots=[];field=3 if side==1 else 2
 for i in range(2,len(bars)-2):
  b=bars[i];v=float(b[field]);neighbours=[float(bars[j][field]) for j in (i-2,i-1,i+1,i+2)]
  if b[0]<entry_ms or not all((v-n)*side<=0 for n in neighbours) or not any((v-n)*side<0 for n in neighbours):continue
  pivots.append(dict(ms=b[0],price=v))
 mark=float(position['markPx']);entry=float((order.get('quality_context') or {}).get('entry') or position['avgPx']);initial=float((order.get('quality_context') or {}).get('initial_stop') or signal.get('stop') or order['stop_px'])
 distance=abs(entry-initial);progress=(mark-entry)*side/distance if distance>0 else None
 pivot=pivots[-1] if pivots else None
 buffer=max(.35*atr,mark*.001)
 boundary=pivot['price']-side*buffer if pivot else None
 close=float(bars[-1][4]);broken=bool(pivot and (close-pivot['price'])*side<0)
 return dict(available=True,frame=frame,completed_ms=completed,atr=atr,progress_initial_r=progress,pivot=pivot,structure_stop=boundary,structure_broken_on_close=broken,initial_invalidation=initial,
  policy='One wave is not guaranteed. Hold valid structure through ordinary pullbacks. Target touch, one weak candle, or small PnL alone is not a full exit. CLOSE on genuine invalidation remains allowed; never delay the server SL. Trail only after >=1 initial price-risk progress, behind a post-entry pivot confirmed by two later completed bars, with volatility room. Never widen an existing stop.')

def guarded_trail(proposed,packet,position,order,now):
 ctx=wave_context(packet,position,order,now)
 old=float(order['stop_px']);side=1 if order['direction']=='long' else -1;mark=float(position['markPx'])
 if not ctx.get('available'):return None,ctx['reason']
 if ctx.get('progress_initial_r') is None or ctx['progress_initial_r']<1:return None,'첫 가격위험 1R 진행 전 · 기존 SL 유지'
 boundary=ctx.get('structure_stop')
 if boundary is None:return None,'진입 후 확정된 눌림 저점·반등 고점 대기 · 기존 SL 유지'
 # Do not put a new stop inside the normal swing or within .75 ATR of the mark.
 limit=min(boundary,mark-.75*ctx['atr']) if side==1 else max(boundary,mark+.75*ctx['atr'])
 value=min(float(proposed),limit) if side==1 else max(float(proposed),limit)
 if not math.isfinite(value) or value<=0 or (value-old)*side<=0 or (mark-value)*side<=0:return None,'구조 여유를 확보하면 유리한 SL 조정 불가 · 기존 SL 유지'
 return value,'진입 시간봉 확정 스윙 바깥·변동성 여유 반영'

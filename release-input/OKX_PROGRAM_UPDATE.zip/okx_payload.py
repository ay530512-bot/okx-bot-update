"""Bound model input without modifying original local evidence or protective state."""
import copy,json

def dumps(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)
def size(value):return len(dumps(value))

def prepare(payload,limit):
 wire=copy.deepcopy(payload);before=size(wire)
 # The derived wave_runner already contains the selected causal pivot/ATR/levels.
 for candidate in wire.get('candidates',[]):
  for frame in candidate.get('frames',{}).values():frame.pop('swing_recent',None)
 if size(wire)<=limit:return wire,dict(before=before,after=size(wire),compacted=before!=size(wire))
 # Remove repeated explanatory prose, never market levels, risk amounts or the thesis.
 def prune(value):
  if isinstance(value,dict):
   return {k:prune(v) for k,v in value.items() if k not in ('note','description','policy','basis','cost_policy','funding_policy','selection','fraction_basis')}
  if isinstance(value,list):return [prune(v) for v in value]
  return value
 wire=prune(wire)
 for candidate in wire.get('candidates',[]):
  learn=candidate.get('outcome_learning',{})
  learn['quality_review']=learn.get('quality_review',[])[-1:]
  learn['quality_feedback']=dict(list(learn.get('quality_feedback',{}).items())[:3])
  for review in learn['quality_review']:
   if isinstance(review.get('analysis'),dict):review['analysis']['notes']=review['analysis'].get('notes',[])[:1]
 # At most the affordable number of candidates is reviewed in this scheduled call.
 while len(wire.get('candidates',[]))>1 and size(wire)>limit:wire['candidates'].pop()
 if size(wire)<=limit:return wire,dict(before=before,after=size(wire),compacted=True)
 # Preserve OHLCV and indicators; compact redundant derived pattern summaries.
 keep={'volume_wick','prior_support','prior_resistance','ma20_slope_atr','failed_low_recovery','failed_high_rejection','support_pullback_recovery','resistance_pullback_rejection','falling_without_recovery','rising_without_rejection','sequence_support_long','sequence_resistance_short'}
 for candidate in wire.get('candidates',[]):
  for frame in candidate.get('frames',{}).values():
   h=frame.get('chart_evidence',{});frame['chart_evidence']={k:v for k,v in h.items() if k in keep}
  learn=candidate.get('outcome_learning',{})
  # Keep counts and normalized outcomes, omit repeated uncertainty/reference detail.
  keys={'setup','frame','direction','samples','wins','expected_net_r','ready','priority_adjustment','manual_reference'}
  learn['setups']=[{k:v for k,v in s.items() if k in keys} for s in learn.get('setups',[])]
 if size(wire)<=limit:return wire,dict(before=before,after=size(wire),compacted=True)
 return None,dict(before=before,after=size(wire),compacted=True)

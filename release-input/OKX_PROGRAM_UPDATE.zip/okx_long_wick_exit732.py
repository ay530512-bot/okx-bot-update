"""Q2X: completed 15m long-wick profit exit, on the existing order worker.

Pattern matches long_wick_research/features.py. Live guards additionally require
fresh account/quote data and positive estimated remaining PnL at execution.
Market fills can differ; this is not a guaranteed profit floor.
"""
import math

STEP = 900000
SIGNAL_MAX_DELAY_MS = 60000
SNAPSHOT_MAX_AGE_MS = 15000
QUOTE_MAX_AGE_SECONDS = 5
SLIPPAGE_RESERVE = .0005  # Same one-way reserve as admission732 and base replay.


def number(value):
    try:
        v = float(value)
        return v if math.isfinite(v) else None
    except (ValueError, TypeError, OverflowError):
        return None


def signal(bars, direction, entry_ms, now):
    """Input is exchange-confirmed OHLCV; never use unfinished bars or pivots."""
    from okx_channel701 import closed
    from okx_core import BotError
    entry_ms = number(entry_ms)
    if direction not in ('long', 'short') or entry_ms is None or not 0 < entry_ms <= now:
        return None
    try:
        b = closed(bars, now, required=2)
    except (BotError, ValueError, TypeError, IndexError, OverflowError):
        return None
    last = b[-1]
    if last[0] < entry_ms or not 0 <= now - (last[0] + STEP) <= SIGNAL_MAX_DELAY_MS:
        return None
    short = direction == 'short'
    wick = lambda r: min(r[1], r[4])-r[3] if short else r[2]-max(r[1], r[4])
    body = abs(last[4]-last[1]); length = wick(last)
    if length <= body + max(abs(last[4]), 1e-12)*1e-12:
        return None
    prior = next((r for r in reversed(b[:-1]) if wick(r) > 0), None)
    if prior is None or not (last[3] > prior[3] if short else last[2] < prior[2]):
        return None
    return dict(bar_ms=last[0], close_ms=last[0]+STEP, close=last[4],
                reference_ms=prior[0], reference_extreme=prior[3] if short else prior[2],
                extreme=last[3] if short else last[2], wick=length, body=body,
                direction=direction, frame='15m')


def partial_cost_snapshot(position, owned):
    """Persist BEFORE partial request; credit only the remaining funding share."""
    qty = number(position.get('pos')); funding = number(position.get('fundingFee'))
    fee = number(position.get('fee'))
    return dict(quantity=qty, funding=funding, fee=fee,
                client_id=owned.get('client_id'), entry=number(position.get('avgPx')))


def remaining_net(position, owned, price, slippage=SLIPPAGE_RESERVE):
    """Estimate remainder alone: allocated entry cost/funding + adverse exit cost.

    Partial-close PnL and closing fees are not used as entry costs. If a legacy
    partial has no funding snapshot, charge all net funding debits and ignore
    funding credits, a conservative fallback. Missing funding is NOT zero.
    """
    side = {'long': 1, 'short': -1}.get(owned.get('direction'))
    values = [number(v) for v in (position.get('pos'), owned.get('quantity'),
              owned.get('ct_val'), position.get('avgPx'), price,
              owned.get('entry_taker_fee'), position.get('fundingFee'), slippage)]
    if not side or any(v is None for v in values):
        return None
    qty, expected, ct, entry, price, rate, funding, slip = values
    if min(qty, expected, ct, entry, price) <= 0 or abs(qty-expected) > max(qty, expected)*1e-10:
        return None
    if abs(rate) > .01 or not 0 <= slip <= .01:
        return None
    rate = abs(rate)
    entry_fee = qty*ct*entry*rate
    if owned.get('partial_used'):
        basis = owned.get('long_wick_partial_cost732') or {}
        before, oldfund, oldfee = (number(basis.get(k)) for k in ('quantity', 'funding', 'fee'))
        if (basis.get('client_id') == owned.get('client_id') and before is not None
                and before > qty and oldfund is not None
                and number(basis.get('entry')) == entry):
            funding -= oldfund*(1-qty/before)
            if oldfee is not None:
                entry_fee = max(entry_fee, max(0., -oldfee)*qty/before)
        else:
            funding = min(0., funding)
    else:
        actual_fee = number(position.get('fee'))
        if actual_fee is not None:
            entry_fee = max(entry_fee, max(0., -actual_fee))
    fill = price*(1-side*slip)
    exit_fee = qty*ct*fill*rate
    gross = qty*ct*(fill-entry)*side
    return dict(net=gross-entry_fee-exit_fee+funding, gross=gross,
                entry_fee=entry_fee, exit_fee=exit_fee, funding=funding,
                fill_estimate=fill, slippage=slip, quantity=qty)


def management(engine, snapshot, position, owned, completed, now):
    """Return True only when the normal serialized close has been requested."""
    if owned.get('phase') != 'active':
        return False
    proof = signal(completed, owned.get('direction'), owned.get('entry_ms'), now)
    if not proof:
        return False
    # Ownership checks are also performed by the engine. Do not use another slot.
    if (position.get('instId'), position.get('posSide')) != (owned.get('symbol'), owned.get('direction')):
        return False
    if (position.get('mgnMode') != 'isolated'
            or owned.get('posId') and position.get('posId') != owned['posId']):
        return False
    stamp = number(snapshot.get('ms'))
    if stamp is None or not 0 <= now-stamp <= SNAPSHOT_MAX_AGE_MS:
        return False
    stream = getattr(engine, 'stream', None)
    try:
        quote = stream.read(owned['symbol'], 'tickers', QUOTE_MAX_AGE_SECONDS, now) if stream else None
    except (ValueError, TypeError, KeyError, OverflowError):
        return False
    if not quote:
        return False
    ts, bid, ask, mark = (number(v) for v in (quote.get('ts'), quote.get('bidPx'),
                                            quote.get('askPx'), position.get('markPx')))
    if (any(v is None for v in (ts, bid, ask, mark)) or min(bid, ask, mark) <= 0
            or bid > ask or not 0 <= now-ts <= QUOTE_MAX_AGE_SECONDS*1000):
        return False
    # Confirm profitability both at the signal and at the current executable side.
    price = min(mark, bid) if owned['direction'] == 'long' else max(mark, ask)
    slip = max(SLIPPAGE_RESERVE, number(engine.cfg.get('liquidity', {}).get('max_slippage')) or 0.)
    at_signal = remaining_net(position, owned, proof['close'], slip)
    current = remaining_net(position, owned, price, slip)
    if at_signal is None or current is None or min(at_signal['net'], current['net']) <= 1e-10:
        return False
    owned['long_wick_exit732'] = dict(proof, evaluated_ms=now, costs=current,
                                     signal_net=at_signal['net'], quote_ms=ts)
    engine.journal.save()
    why = '저점 상승·긴 아랫꼬리' if owned['direction'] == 'short' else '고점 하락·긴 윗꼬리'
    engine.close(snapshot, '15분 확정봉 '+why+' · 비용 반영 잔량 수익 보호 청산')
    return True

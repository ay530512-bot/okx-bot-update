"""Manual-trade isolation and a remaining-capital allocation reference. No writes."""
from okx_core import dec


def allocation_seed(snapshot,records):
    # Available already reflects exchange-frozen manual margin/orders. Add back only bot commitments.
    reserved=sum((dec(r.get('committed_margin') or 0)+dec(r.get('pending_add',{}).get('margin') or 0)
                  for r in records),dec(0))
    return max(dec(0),min(dec(snapshot['equity']),max(dec(0),dec(snapshot['available']))+reserved))


def order_keys(records):
    return {(r['symbol'],v) for r in records for v in (r.get('client_id'),r.get('close_id'),
        r.get('pending_add',{}).get('client_id'),r.get('partial',{}).get('client_id')) if v}

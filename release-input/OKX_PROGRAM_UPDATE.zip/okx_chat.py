"""In-app explanation chat and explicit-confirmation entry proposals. No model tool can place orders."""
import copy,json,re,time,uuid
from concurrent.futures import ThreadPoolExecutor
from okx_core import BotError,dec,fmt
INSTRUCTIONS='''당신은 이 OKX 매매 프로그램의 한국어 설명/주문 의도 도우미다. 제공된 상태만 사실로 사용하고 시각이 오래됐거나 데이터가 없으면 명시한다.
ANSWER는 설명, CLARIFY는 불명확한 요청의 질문, ORDER는 사용자가 명확히 요청한 신규 롱/숏 주문 의도다. 분석/가정/인용/질문을 실제 주문 요청으로 해석하지 마라.
"이거 사자"는 selected_symbol이 명시되어 있을 때만 그 종목 LONG으로 해석한다. 종목이 없으면 CLARIFY. 종목은 정확한 OKX SYMBOL-USDT-SWAP 형식이다.
신규 포지션 명령만 지원한다. 청산/손절 변경/설정 변경은 ANSWER로 지원 범위를 설명하며 실행됐다고 말하지 마라.
주문 증거금은 기존 자동 자금1/3 고정이며 요청이 전액/다른 수량이면 CLARIFY한다. 배율 미지정은3배, 현재 실질 허용 범위3~10배다. 범위 밖 배율을 임의로 낮추지 말고 CLARIFY한다.
ORDER는 실행이 아니다. 프로그램이 실시간 잔고/차트/호가로 손절·목표·수량을 계산해 확인안을 만들며 사용자가 버튼으로 확정해야 실제 주문한다.
사용자의 지시를 받아 수익을 보장하거나 보호 손절/일일 한도/예산을 우회하지 마라. 다른 ChatGPT 대화나 거래소에 접근한다고 말하지 마라.
모든 필드를 JSON으로 출력한다. ANSWER/CLARIFY의symbol/side는빈문자열,leverage=3. answer는 한국어1200자 이내.'''
SCHEMA={'type':'object','properties':{'kind':{'type':'string','enum':['ANSWER','CLARIFY','ORDER']},'answer':{'type':'string'},'symbol':{'type':'string'},'side':{'type':'string','enum':['','LONG','SHORT']},'leverage':{'type':'integer'}},'required':['kind','answer','symbol','side','leverage'],'additionalProperties':False}

def context(engine,selected):
 from okx_day_status import daily_status
 from okx_daily_goal728 import cost_for_day
 snap=engine.raw_snapshot or {};universe=engine.universe.read()[0] or {};rows=universe.get('rows',[])
 positions=[{k:r.get(k) for k in ('symbol','direction','leverage','quantity','stop_px','phase')} for r in engine.records()]
 return dict(observed_ms=snap.get('ms'),selected_symbol=selected,live=engine.enabled,recovering=engine.recovering,
  account=dict(equity=fmt(snap['equity']) if snap.get('equity') is not None else None,available=fmt(snap['available']) if snap.get('available') is not None else None),
  daily=daily_status(engine.journal.data.get('day'),snap.get('equity'),engine.api.now_ms(),engine.cfg,cost_for_day(engine.journal.data,(engine.journal.data.get('day') or {}).get('date'))),positions=positions,
  candidates=[{k:r.get(k) for k in ('symbol','mover_group','mover_rank','change','activity')} for r in rows],
  execution=engine.execution_status.snapshot(),last_blocker=getattr(engine,'last_entry_blocker',''),
  constraints=dict(margin='자동 자금1/3',leverage='3~10',chat_orders='확인 버튼 필수',manual_positions='수동 보유분 조작 안 함'))

class ChatService:
 def __init__(self,engine):
  self.engine=engine;self.pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='bot-chat');self.future=None;self.history=[];self.pending=None;self.last_intent=None;self.used=set();self.focus=None;self.selection=None;self.queued_selected=None
 def stop(self):self.pool.shutdown(wait=False,cancel_futures=True)
 def watch(self):
  if self.focus and self.engine.api.now_ms()<self.focus['until']:return [self.focus['symbol']]
  return []
 def allowed_row(self,symbol):
  return self.focus['row'] if self.focus and self.focus['symbol']==symbol and self.engine.api.now_ms()<self.focus['until'] else None
 def message(self,text,selected):
  e=self.engine;text=str(text).strip();selected=str(selected or '').strip().upper()
  if not text or len(text)>2000:raise BotError('채팅은1~2000자로 입력하세요.')
  if self.selection or self.queued_selected or (self.future and not self.future.done()):raise BotError('이전 AI 요청을 기다려주세요.')
  # Do not send known credentials even if accidentally pasted into chat.
  for value in e.settings.values():
   if isinstance(value,str) and len(value)>8:text=text.replace(value,'[숨김]')
  if selected and not re.fullmatch(r'[A-Z0-9]+-USDT-SWAP',selected):raise BotError('선택 종목 형식을 확인하세요.')
  self.pending=None;self.last_intent=None;e.events.put(('chat_proposal',None));e.events.put(('chat_intent_ready',False))
  payload=dict(question=text,history=self.history[-6:],context=context(e,selected))
  e.events.put(('chat_reply',dict(role='user',text=text)))
  self.history.append(dict(role='user',text=text))
  def run():
   from okx_model_runtime import request
   try:
    reply=request(e,payload,INSTRUCTIONS,SCHEMA,'chat')
    e.send('chat_result',reply=reply)
   except Exception as error:e.events.put(('chat_reply',dict(role='assistant',text='채팅 처리 실패: '+(str(error) if isinstance(error,BotError) else type(error).__name__),done=True)))
  self.future=self.pool.submit(run)
 def result(self,reply):
  if reply.get('kind') not in ('ANSWER','CLARIFY','ORDER') or not isinstance(reply.get('answer'),str):raise BotError('채팅 AI 응답 형식 오류')
  answer=reply['answer'][:2400];self.history.append(dict(role='assistant',text=answer));self.history=self.history[-8:]
  self.engine.events.put(('chat_reply',dict(role='assistant',text=answer,done=True)))
  if reply['kind']=='ORDER':self.prepare(reply)
 def prepare(self,intent):
  e=self.engine;symbol=str(intent.get('symbol','')).upper();side=intent.get('side');lev=intent.get('leverage')
  if not re.fullmatch(r'[A-Z0-9]+-USDT-SWAP',symbol) or side not in ('LONG','SHORT') or type(lev) is not int or not 3<=lev<=10:raise BotError('명확한 종목·롱/숏·3~10배를 지정하세요.')
  self.last_intent=copy.deepcopy(intent);e.events.put(('chat_intent_ready',True))
  if not e.enabled or e.preview or e.recovering or e.entry_cancel.is_set() or not e.within_session():raise BotError('실거래 시작 및 연결 대조 완료 후 주문 확인안을 만들 수 있습니다.')
  if symbol in e.blocked_manual_symbols() or any(r['symbol']==symbol for r in e.records()):raise BotError('수동/자동 보유 또는 주문이 있는 종목입니다. 채팅은 신규 진입만 지원합니다.')
  i=e.api.public('/api/v5/public/instruments',instType='SWAP',instId=symbol)[0]
  if not e.is_allowed_instrument(i) or int(float(i['lever']))<lev:raise BotError('허용된 암호화폐 USDT 무기한/배율이 아닙니다.')
  self.focus=dict(symbol=symbol,until=e.api.now_ms()+120000,row=dict(symbol=symbol,instrument=i,source='user_chat',activity={}))
  rows=e.universe.read()[0] or {};e.stream.watch(list(dict.fromkeys([r['symbol'] for r in rows.get('rows',[])]+[r['symbol'] for r in e.records()]+[symbol])))
  if not e.stream.ready(symbol,e.cfg,e.api.now_ms()):raise BotError('해당 종목 시세·호가 구독 준비 중입니다. 잠시 후 채팅창의 주문안 재조회 버튼을 누르세요(추가 AI 호출 없음).')
  from okx_autonomous import packet,make_signal
  p=packet(symbol,e.fresh_bars(symbol),e.cfg,e.api.now_ms());d=p['directions'].get(side)
  if not d:raise BotError('요청 방향의 구조 손절·목표를 구성할 수 없습니다.')
  # Nearest real 3/6/12-minute extreme, not an invented arbitrary stop.
  candidates=[(v,n) for n,v in enumerate(d['stop_options']) if (e.cfg['signals'].get('wave_mode',{}).get('enabled') or not d.get('stop_plans',[{}]*len(d['stop_options']))[n].get('structure')) and (p['price']-v)*(1 if side=='LONG' else -1)>0]
  if not candidates:raise BotError('요청 방향의 손절 후보가 없습니다.')
  _,index=min(candidates,key=lambda item:abs(p['price']-item[0]))
  s=make_signal(dict(action=side,symbol=symbol,leverage=lev,stop_index=index,reason='사용자 채팅 신규 진입 요청·실행 버튼 확인 대기'),p,e.cfg)
  s['user_chat_order']=True;s['signal_id']='chat-'+uuid.uuid4().hex[:24]
  old=getattr(e,'auto_frozen',None);e.auto_frozen=s
  from okx_ai_cost import precheck
  try:receipt=precheck(e,s)
  finally:e.auto_frozen=old
  fresh=receipt.pop('_fresh_signal',s);token=uuid.uuid4().hex
  self.pending=dict(token=token,signal=fresh,receipt=receipt,epoch=e.epoch,expires_ms=min(s['expires_ms'],e.api.now_ms()+45000))
  e.events.put(('chat_proposal',dict(token=token,symbol=symbol,side=side,leverage=lev,quantity=receipt['quantity'],margin=receipt['margin'],stop=s['stop'],target=s['target'],estimated_loss=receipt['estimated_loss'],frame=s['setup_frame'],pattern=s['pattern'],expires_ms=self.pending['expires_ms'])))
 def start_selected(self,symbol):
  e=self.engine;symbol=str(symbol).strip().upper()
  if self.selection or self.queued_selected or (self.future and not self.future.done()):raise BotError('이전 AI 요청을 기다려주세요.')
  if not re.fullmatch(r'[A-Z0-9]+-USDT-SWAP',symbol):raise BotError('종목을 선택하세요.')
  if not e.enabled or e.preview or e.recovering or e.entry_cancel.is_set() or not e.within_session():raise BotError('실거래 시작과 연결 대조 완료 후 사용할 수 있습니다.')
  if symbol in e.blocked_manual_symbols() or any(r['symbol']==symbol for r in e.records()):raise BotError('이미 수동/자동 보유·주문 중인 종목입니다.')
  from okx_execution_status import check_permissions
  check_permissions(e.snapshot()['config'])
  i=e.api.public('/api/v5/public/instruments',instType='SWAP',instId=symbol)[0]
  if not e.is_allowed_instrument(i):raise BotError('허용 암호화폐 USDT 무기한이 아닙니다.')
  self.focus=dict(symbol=symbol,until=e.api.now_ms()+120000,row=dict(symbol=symbol,instrument=i,source='selected_ai',activity={}))
  rows=e.universe.read()[0] or {};e.stream.watch(list(dict.fromkeys([r['symbol'] for r in rows.get('rows',[])]+[r['symbol'] for r in e.records()]+[symbol])))
  if not e.stream.ready(symbol,e.cfg,e.api.now_ms()):
   self.queued_selected=dict(symbol=symbol,until=e.api.now_ms()+15000)
   e.events.put(('chat_reply',dict(role='assistant',text='선택 종목 시세·호가 구독 준비 중입니다. 최대15초 대조 후 자동으로 AI 판단을 시도합니다. 아직 유료 호출/주문 없음.')));return
  from okx_selected_entry import build_choices,INSTRUCTIONS as selected_instructions,SCHEMA as selected_schema
  options,payload=build_choices(e,symbol,i);identity=uuid.uuid4().hex
  self.pending=None;self.last_intent=None;e.events.put(('chat_proposal',None));e.events.put(('chat_intent_ready',False))
  self.selection=dict(id=identity,epoch=e.epoch,options=options,created_ms=e.api.now_ms())
  e.events.put(('chat_reply',dict(role='user',text=symbol+' 선택 종목 AI 판단·진입 시도 요청')))
  def run():
   from okx_model_runtime import request
   try:
    result=request(e,payload,selected_instructions,selected_schema,'chat')
    e.send('chat_selected_result',identity=identity,reply=result)
   except Exception as error:e.send('chat_selected_error',identity=identity,error=str(error) if isinstance(error,BotError) else type(error).__name__)
  self.future=self.pool.submit(run)
 def poll_selected(self):
  q=self.queued_selected;e=self.engine
  if not q:return
  if not e.enabled or e.entry_cancel.is_set() or e.recovering or e.api.now_ms()>q['until']:
   self.queued_selected=None;e.events.put(('chat_reply',dict(role='assistant',text='선택 진입 보류: 운용/연결 상태 또는 시세 구독 준비 시간 초과. 유료 호출 없음.',done=True)));return
  if e.stream.ready(q['symbol'],e.cfg,e.api.now_ms()):
   self.queued_selected=None
   try:self.start_selected(q['symbol'])
   except Exception as error:e.events.put(('chat_reply',dict(role='assistant',text='선택 진입 보류: '+str(error)[:300],done=True)))
 def cancel_selected(self):
  self.selection=None;self.queued_selected=None
  self.engine.events.put(('chat_reply',dict(role='assistant',text='아직 주문하지 않은 선택 진입 요청을 취소했습니다. 이미 시작한 AI 호출 비용은 발생할 수 있습니다.',done=True)))
 def finish_selected(self,identity,reply=None,error=None):
  e=self.engine;job=self.selection
  if not job or job['id']!=identity:raise BotError('이미 처리했거나 유효하지 않은 선택 진입 결과입니다.')
  self.selection=None
  if error:raise BotError('선택 진입 AI 실패: '+error)
  if job['epoch']!=e.epoch or not e.enabled or e.recovering or e.entry_cancel.is_set() or not e.within_session():raise BotError('AI 판단 중 운용/연결 상태 변경')
  index=reply.get('choice')
  if type(index) is not int or not 0<=index<len(job['options']) or not isinstance(reply.get('reason'),str):raise BotError('AI 선택 결과 형식 오류')
  s=copy.deepcopy(job['options'][index]['signal']);s['reason']='사용자 선택 AI: '+reply['reason'][:160]
  if e.api.now_ms()>=s['expires_ms']:raise BotError('선택 판단 유효시간이 지났습니다. 새 진입 시도를 요청하세요.')
  old=getattr(e,'auto_frozen',None);e.auto_frozen=s
  try:
   from okx_ai_cost import precheck
   receipt=precheck(e,s)
   e.notify('AI 승인',s['symbol']+' / '+s['action']+' / '+str(s['leverage'])+'배 / 사용자 선택 진입\n'+s['reason']+'\n최종 점검 후 시장가 주문 시도',state=identity)
   e.executing_signal=s
   with e.selected(e.empty_slot()):e.entry(s)
   e.events.put(('chat_reply',dict(role='assistant',text=s['symbol']+' / '+s['action']+' / '+str(s['leverage'])+'배 / '+s['setup_frame']+'\n'+s['reason']+'\nSL '+str(s['stop'])+' / 목표 '+str(s['target'])+' / 예상 손실 '+str(receipt['estimated_loss'])+' USDT\n주문 처리 경로로 전달했습니다. 실제 체결과 보호 손절 상태를 확인하세요.',done=True)))
  finally:e.executing_signal=None;e.auto_frozen=old
 def confirm(self,token):
  e=self.engine;proposal=self.pending
  if not proposal or proposal['token']!=token or token in self.used:raise BotError('이미 사용했거나 유효하지 않은 주문 확인안입니다.')
  self.pending=None;self.last_intent=None;e.events.put(('chat_intent_ready',False));self.used.add(token);self.used=set(list(self.used)[-1000:]);e.events.put(('chat_proposal',None))
  if e.api.now_ms()>=proposal['expires_ms'] or e.epoch!=proposal['epoch']:raise BotError('주문 확인 시간이 지났거나 운용 상태가 바뀌었습니다. 새 확인안을 요청하세요.')
  s=proposal['signal'];old=getattr(e,'auto_frozen',None);e.auto_frozen=s
  try:
   from okx_ai_cost import precheck
   receipt=precheck(e,s)
   if receipt['quantity']!=proposal['receipt']['quantity'] or receipt['margin']!=proposal['receipt']['margin']:raise BotError('잔고/수량/증거금이 바뀌었습니다. 새 확인안으로 확인하세요.')
   e.executing_signal=s
   with e.selected(e.empty_slot()):e.entry(s)
   e.events.put(('chat_reply',dict(role='assistant',text='확인한 주문을 주문 처리 경로로 전달했습니다. 실제 체결·보호 손절 상태를 확인하세요.',done=True)))
  finally:e.executing_signal=None;e.auto_frozen=old

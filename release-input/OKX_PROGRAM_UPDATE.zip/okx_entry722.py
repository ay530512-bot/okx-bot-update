"""V722: 20-bar regime, 10/15/20 timing, completed hourly trend.
Policy thresholds are explicit design choices, not a guarantee of profitability.
"""
from okx_entry721 import analyze as base_analyze

def hourly_from_15m(b):
    groups={}
    for r in b:groups.setdefault(r[0]//3600000*3600000,[]).append(r)
    out=[]
    for t,g in sorted(groups.items()):
        if len(g)==4 and [r[0] for r in g]==[t+i*900000 for i in range(4)]:
            out.append([t,g[0][1],max(r[2] for r in g),min(r[3] for r in g),g[-1][4],sum(r[5] for r in g)])
    return out

def direction(b):
    if len(b)<25:return 0
    c=[float(x[4]) for x in b]
    ma=sum(c[-20:])/20;old=sum(c[-25:-5])/20
    return 1 if c[-1]>ma>old else -1 if c[-1]<ma<old else 0

def analyze(b,hourly=None):
    result=base_analyze(b)
    if not result['setups']:return result
    # Never include a partially completed hour, even if caller supplies it.
    end=b[-1][0]+900000
    h=hourly_from_15m(b) if hourly is None else [r for r in hourly if r[0]+3600000<=end]
    if len(h)<25 or h[-1][0]+3600000!=end//3600000*3600000 or any(y[0]-x[0]!=3600000 for x,y in zip(h[-25:],h[-24:])):
        return dict(setups=[],reason='최신 완료1시간봉 대기')
    d=direction(b);hd=direction(h)
    selected=[]
    for v in result['setups']:
        side=1 if v['action']=='LONG' else -1
        if d!=side or hd!=side:continue
        v=dict(v,policy_version=722,regime20=d,hourly_direction=hd)
        # The invalidation belongs to the actual entry thesis, not a different route.
        v['failure_level722']=(b[-1][3] if side==1 else b[-1][2]) if v['route721']=='ma_retest' else v['channel_high' if side==1 else 'channel_low']
        v['failure_kind722']='지지·저항 재시험 실패' if v['route721']=='ma_retest' else '돌파 실패'
        selected.append(v)
    return dict(setups=selected,reason='20봉·1H 방향 확인' if selected else '20봉·1H 방향과 진입 방향 불일치 대기')

def setup(b,hourly=None):
    values=analyze(b,hourly)['setups']
    return min(values,key=lambda v:(v['priority'],-v['lookback721'])) if values else None

def failure_level(proof,side):
    if proof.get('failure_level722') is not None:return float(proof['failure_level722'])
    # Existing V721 retests have no thesis level. Do not invent a breakout failure.
    if proof.get('route721')=='ma_retest':return 0.
    return float(proof.get('channel_high' if side==1 else 'channel_low') or 0)

def confirmed_pivot(post,side,atr):
    """Two bars left and right; only post-entry bars. No future candle lookahead."""
    if len(post)<5 or atr<=0:return None
    field=3 if side==1 else 2
    for j in range(len(post)-3,1,-1):
        v=float(post[j][field]);others=[float(post[k][field]) for k in (j-2,j-1,j+1,j+2)]
        if all((x-v)*side>0 for x in others):return v-side*.25*atr
    return None

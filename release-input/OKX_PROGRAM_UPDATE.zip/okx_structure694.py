"""Closed-bar hypotheses, structure execution, and outcome ranking. No profit claim."""
import math,statistics
from decimal import ROUND_DOWN,ROUND_UP
from okx_core import BotError,dec,fmt
DEFAULTS=dict(double_tolerance_atr=.75,min_separation=3,max_separation=32,min_rebound_atr=.75,wick_fraction=.45,wick_range_atr=.6,volume_ratio=1.5,volume_percentile=.8,confirmation_extension_atr=.25,stop_buffer_atr=.15,risk_fraction=.005,fill_reserve_fraction=.1,max_total_risk_fraction=.01)
def params(c):return dict(DEFAULTS,**c.get('execution',{}).get('structure694',{}))
def quantile(a,p):
 a=sorted(float(v) for v in a);return a[min(len(a)-1,int((len(a)-1)*p))] if a else 0.
def wick(r,side,atr,k):
 o,h,l,cl=map(float,r[1:5]);span=h-l;tail=min(o,cl)-l if side==1 else h-max(o,cl)
 return span>=k['wick_range_atr']*atr and tail>=span*k['wick_fraction'] and (cl-l if side==1 else h-cl)>=span*.6

def volume_event(b,j,k):
 a=[float(r[5]) for r in b[max(0,j-40):j]];v=float(b[j][5])
 return len(a)>=20 and v>=statistics.mean(a)*k['volume_ratio'] and v>=quantile(a,k['volume_percentile'])
def swings(b):
 return [(j,'low',float(b[j][3])) for j in range(1,len(b)-1) if b[j][3]<b[j-1][3] and b[j][3]<=b[j+1][3]]+[(j,'high',float(b[j][2])) for j in range(1,len(b)-1) if b[j][2]>b[j-1][2] and b[j][2]>=b[j+1][2]]
def regime(b):
 piv=sorted(swings(b[-60:]));hi=[v for j,t,v in piv if t=='high'];lo=[v for j,t,v in piv if t=='low']
 if len(hi)>=2 and len(lo)>=2:
  if hi[-1]>hi[-2] and lo[-1]>lo[-2]:return 'uptrend'
  if hi[-1]<hi[-2] and lo[-1]<lo[-2]:return 'downtrend'
 return 'range'
def strict_setups694(b,atr,tick=0,c=None):
 from okx_pattern15 import avg,band,vol
 k=params(c or {});out=[]
 if len(b)<45 or not math.isfinite(atr) or atr<=0:return out
 n=len(b)-1;test=b[-2];confirm=b[-1];pad=max(float(tick),atr*k['stop_buffer_atr'])
 for action,side,field in [('LONG',1,3),('SHORT',-1,2)]:
  threshold=float(test[2 if side==1 else 3]);price=float(confirm[4])
  if not wick(test,side,atr,k) or (price-threshold)*side<=0 or (float(confirm[4])-float(confirm[1]))*side<=0 or float(confirm[5])<=float(test[5]):continue
  common=dict(action=action,signal_ms=confirm[0],test_ms=test[0],confirmation_ms=confirm[0],entry_trigger=threshold,entry_ceiling=price+side*atr*k['confirmation_extension_atr'],reference=price,atr=atr,stop_buffer_atr=k['stop_buffer_atr'],confirmation_volume=float(confirm[5]),retest_volume=float(test[5]))
  second=float(test[field])
  for i in range(n-1-k['min_separation'],max(19,n-2-k['max_separation']),-1):
   first=b[i];extreme=float(first[field]);bb=band(b,i)
   if not bb or not wick(first,side,atr,k) or not volume_event(b,i,k):continue
   if not (first[3]<bb[0]<=first[4] if side==1 else first[2]>bb[2]>=first[4]):continue
   if not 0<=(second-extreme)*side<=atr*k['double_tolerance_atr'] or float(test[5])>=float(first[5]):continue
   if any((float(r[field])-extreme)*side<0 for r in b[i+1:]):continue
   between=b[i+1:-2]
   if not between:continue
   target=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in between)
   if (target-extreme)*side<atr*k['min_rebound_atr'] or (target-price)*side<=0:continue
   out.append(dict(common,setup='band_double',priority=0,first_ms=first[0],first_extreme=extreme,retest_extreme=second,structural_stop=extreme-side*pad,target=target,relative_volume=vol(b,i),route='reversal'));break
  if len(b)>=242:
   m=[avg(b[:-1],j) for j in (50,100,120,200)];ordered=all((m[j]-m[j+1])*side>0 for j in range(3));slope=(avg(b[:-1],50)-avg(b[:-4],50))*side>0
   crosses=[j for j in range(max(200,n-40),n-1) if (float(b[j-1][4])-avg(b,200,j-1))*side<=0 and (float(b[j][4])-avg(b,200,j))*side>0]
   if ordered and slope and crosses and float(test[3])<=m[2]<=float(test[2]) and (float(test[4])-m[2])*side>0:
    segment=b[crosses[-1]:-2];target=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in segment)
    if float(test[5])<max(float(r[5]) for r in segment) and (target-price)*side>0:out.append(dict(common,setup='ma_retest',priority=1,cross_ms=b[crosses[-1]][0],retest_extreme=second,structural_stop=second-side*pad,target=target,zone=m[2],route='continuation'))
  for i in range(n-3,max(40,n-20),-1):
   impulse=b[i];baseline=b[i-20:i];body=abs(float(impulse[4])-float(impulse[1]))
   if (float(impulse[4])-float(impulse[1]))*side<=0 or not volume_event(b,i,k):continue
   if body<max(atr,1.5*statistics.median(abs(float(r[4])-float(r[1])) for r in baseline)):continue
   low,high=float(impulse[3]),float(impulse[2]);target=high if side==1 else low;extreme=low if side==1 else high
   if not low<second<high or (target-price)*side<=0 or any((float(r[field])-extreme)*side<0 for r in b[i+1:]):continue
   pullback=b[i+1:-1]
   if not pullback or statistics.mean(float(r[5]) for r in pullback)>=float(impulse[5]) or not any((float(r[4])-float(impulse[4]))*side<0 for r in pullback):continue
   out.append(dict(common,setup='impulse_retest',priority=2,impulse_ms=impulse[0],retest_extreme=second,structural_stop=extreme-side*pad,target=target,relative_volume=vol(b,i),route='continuation'));break
 return sorted(out,key=lambda v:v['priority'])
def strict_select_regime694(p,row):
 fs=row.get('live_frames',{});r1=regime(fs.get('1H',[]));r4=regime(fs.get('4H',[]));p['market_regime']=dict(hour=r1,four_hour=r4);candidates=[]
 for v in p['entry_setups']:
  own='uptrend' if v['action']=='LONG' else 'downtrend';opp='downtrend' if v['action']=='LONG' else 'uptrend'
  if v['route']=='continuation' and (r1!=own or r4==opp):continue
  if v['route']=='reversal' and r1==opp and r4==opp:continue
  v['market_regime']=r1;v['learning_key']='|'.join((v['setup'],'15m','long' if v['action']=='LONG' else 'short',r1,'694'));candidates.append(v)
 p['entry_setups']=candidates;return p
def setups(b,atr,tick=0,c=None):
 from okx_flexible697 import setups as flexible
 return flexible(b,atr,tick,c)
def select_regime(p,row):
 from okx_flexible697 import select_regime as flexible
 return flexible(p,row)
def entry_window(v,price):
 if v.get("setup")=="manual_click716":
  side=1 if v["action"]=="LONG" else -1
  return float(v["structural_stop"])>0 and (float(price)-float(v["structural_stop"]))*side>0
 if v.get("setup")=="channel20_10":
  from okx_channel701 import window
  return window(v,price)
 side=1 if v['action']=='LONG' else -1
 return (float(price)-v['entry_trigger'])*side>0 and (v['entry_ceiling']-float(price))*side>=0 and (v.get('target') is None or (float(v['target'])-float(price))*side>0)

def fit(rows):
 groups={};seen=set()
 for row in sorted(rows,key=lambda r:int(r.get('end_ms') or 0)):
  m=row.get('learning') or {};key=m.get('key694');identity=(row.get('source'),row.get('client_id'))
  if not key or identity in seen or row.get('source') not in ('auto','manual'):continue
  try:
   risk=float(row.get('learning_risk_usdt') or 0);pnl=float(row['realizedPnl'])
   if risk<=0 or not all(map(math.isfinite,(risk,pnl))):continue
  except (ValueError,TypeError,KeyError):continue
  seen.add(identity);name=('manual|' if row['source']=='manual' else '')+key;groups.setdefault(name,[]).append(row)
 result={}
 for name,values in groups.items():
  values=values[-200:];rs=[max(-5,min(5,float(v['realizedPnl'])/float(v['learning_risk_usdt']))) for v in values];n=len(rs);mean=statistics.mean(rs);se=statistics.stdev(rs)/math.sqrt(n) if n>1 else float('inf');lower=mean-1.96*se
  buffers=[float(v.get('observed_excursion',{}).get('adverse_atr',0)) for v in values if float(v['realizedPnl'])>0 and v.get('observed_excursion',{}).get('samples',0)>=3]
  result[name]=dict(samples=n,ready=n>=30,mean_net_r=mean,lower_approx=lower if math.isfinite(lower) else None,priority_adjustment=max(-.5,min(.5,lower)) if n>=30 else 0.,stop_buffer_atr=max(.15,min(.5,quantile(buffers,.8)*.25)) if n>=30 and len(buffers)>=10 else None,net_usdt=sum(float(v['realizedPnl']) for v in values),last_end_ms=max(int(v.get('end_ms') or 0) for v in values))
 return result

def learning_adjust(p,state,c):
 scores=[];detail=[]
 for v in p['entry_setups']:
  name=v['learning_key'];s=state.get('groups694',{}).get(name,{});score=s.get('priority_adjustment',0) if s.get('ready') else 0.;v['learned_priority']=score;scores.append(score)
  detail.append(dict(key=name,automatic=s,manual_reference=state.get('groups694',{}).get('manual|'+name,{})))
  buffer=s.get('stop_buffer_atr')
  if buffer is not None and s.get('ready'):
   side=1 if v['action']=='LONG' else -1;v['structural_stop']-=side*(buffer-v['stop_buffer_atr'])*v['atr'];v['stop_buffer_atr']=buffer
 p['outcome_learning']=dict(setups=detail,note='자동/수동 분리, 동일 조건30건 전 중립, 신경망 재훈련 아님');return max(scores,default=0.)
def cap_quantity(plan,i,s,direction,equity,available,fee,c):
 side=1 if direction=='long' else -1;price=dec(plan['buy' if side==1 else 'sell']);ct=dec(i['ctVal']);lot=dec(i['lotSz']);lev=dec(s.get('leverage') or c['risk']['leverage']);target=dec(equity)*dec(c['risk'].get('initial_margin_fraction',1/3));tick=dec(i.get('tickSz') or '.00000001')
 stop=(dec(s['stop'])/tick).to_integral_value(rounding=ROUND_DOWN if side==1 else ROUND_UP)*tick
 if min(price,ct,lot,lev,target)<=0 or (price-stop)*side<=0:raise BotError('구조 손절 또는 주문 단위 오류')
 if dec(available)<target*(1+abs(dec(fee))*lev*2):raise BotError('시드 1/4 증거금과 수수료 가용잔고 부족')
 q=(target*lev/(ct*price)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
 if q<dec(i['minSz']):raise BotError('시드 1/4으로 최소 수량 미달')
 if i.get('maxMktSz') and q>dec(i['maxMktSz']):raise BotError('시드 1/4 수량이 거래소 시장가 상한 초과')
 if (target-q*ct*price/lev)/target>dec(c['risk'].get('fixed_initial_max_rounding_fraction',.03)):raise BotError('시드 1/4 주문 단위 오차 초과')
 return dict(plan,quantity=fmt(q),fixed_initial=True,initial_quantity=fmt(q),initial_size_mode='fixed_third',initial_margin_target=fmt(target),risk_budget=fmt(q*ct*(abs(price-stop)+price*2*abs(dec(fee)))))
def total_risk(e,snap):
 total=dec(0)
 for o in e.records():
  for p in snap.get('positions',[]):
   if p.get('instId')==o['symbol'] and p.get('posSide')==o['direction']:
    price=dec(p['markPx']);stop=dec(o['stop_px']);side=1 if o['direction']=='long' else -1;total+=abs(dec(p['pos']))*dec(o['ct_val'])*(max(dec(0),(price-stop)*side)+price*dec(o.get('cost_rate') or 0))
 return total

def management(e,snap,p,o):
 now=e.api.now_ms()
 if now-o.get('structure694_check_ms',0)<10000:return False
 o['structure694_check_ms']=now;side=1 if o['direction']=='long' else -1;price=float(p['markPx']);stop=float(o['stop_px']);entry=float(p['avgPx'])
 if (price-stop)*side<=0:
  from okx_profit_structure700 import trace
  trace(e,o,p,'CLOSE','현재 보호 구조 SL 이탈')
  e.close(snap,'현재 보호 구조 SL 이탈');return True
 b=[r for r in (e.chart_job(o['symbol']) or {}).get('15m',[]) if r[0]+900000<=now]
 if len(b)<24:return False
 from okx_band_flow import view
 atr=view(b,e.cfg)['atr'];signal=o.get('v4_signal',{});proof=signal.get('decision_record',{}).get('volume_wick_proof',{});target=float(proof.get('target') or o.get('holding_rule',{}).get('target') or signal.get('target') or 0)
 if target<=0:return False
 o.setdefault('quality_context',dict(atr=atr,entry=entry,initial_stop=float(signal.get('stop') or stop),tags=[],frame='15m',direction=o['direction'],regime=proof.get('market_regime')))
 ex=o.setdefault('observed_excursion',dict(samples=0,favorable_atr=0.,adverse_atr=0.));move=(price-entry)*side/float(o['quality_context'].get('atr') or atr);ex.update(samples=ex['samples']+1,favorable_atr=max(ex['favorable_atr'],move),adverse_atr=max(ex['adverse_atr'],-move));o['last_quality_mark']=p['markPx']
 post=[r for r in b if r[0]>=int(o['entry_ms'])];last=post[-1] if post else None;at_target=(price-target)*side>=0
 if at_target:o.setdefault('structure694_target_seen_ms',now)
 if at_target and not o.get('partial_used') and not o.get('partial_unsplittable'):
  from okx_profit_structure700 import trace
  trace(e,o,p,'PARTIAL','직전 구조 극점 도달',target=target,fraction=.5)
  e.partial_close(snap,'직전 구조 극점 도달 · 절반 확보·잔량 추세 관리',fraction=.5);return True
 # Earned post-entry structure can protect gains BEFORE an old target is broken.
 from okx_profit_structure700 import candidate as profit_candidate,trace
 protective=profit_candidate(b,int(o['entry_ms']),entry,stop,price,side,atr,float(o.get('cost_rate') or 0))
 if protective:
  proposed=protective['stop'];o['structure694_trail_candidate']=proposed
  o['structure700_profit_protection']=protective
  trace(e,o,p,'TRAIL',protective['reason'],proposed_stop=proposed,pivot_ms=protective['pivot_ms'],net_floor=protective['net_floor'])
  e.trail(snap,p,o,proposed);return True
 if last:
  reject=(float(last[2 if side==1 else 3])-target)*side>=0 and (float(last[4])-target)*side<0 and wick(last,-side,atr,params(e.cfg))
  if reject:o['structure694_rejection']=dict(ms=last[0],level=float(last[3 if side==1 else 2]))
  rejected=o.get('structure694_rejection')
  if rejected and (price-rejected['level'])*side<0:e.close(snap,'직전 고점·저점 돌파 실패 후 국소 지지·저항 이탈');return True
  if (float(last[4])-target)*side>0:o.setdefault('structure694_breakout_ms',last[0]);o.pop('structure694_rejection',None)
  recent=post[-40:];piv=sorted(swings(recent));kind='low' if side==1 else 'high';levels=[v for j,t,v in piv if t==kind];confirmed=[v for j,t,v in piv if t==kind and recent[j][0]>o.get('structure694_breakout_ms',now)]
  if o.get('structure694_breakout_ms') and confirmed:
   proposed=confirmed[-1]-side*atr*.15;o['structure694_trail_candidate']=proposed
   if (proposed-stop)*side>0 and (price-proposed)*side>0:e.trail(snap,p,o,proposed);return True
  opps=[v for j,t,v in piv if t!=kind]
  if len(levels)>=2 and len(opps)>=2 and (levels[-1]-levels[-2])*side<0 and (opps[-1]-opps[-2])*side<0 and (price-levels[-1])*side<0:e.close(snap,'완료봉 추세 구조 반전 확인');return True
 e.journal.save();return False

def corroborate_management(out,p,o,c):
 if not c.get('execution',{}).get('structure694'):return out
 side=1 if o['direction']=='long' else -1;price=float(p['markPx']);old=float(o['stop_px']);v=o.get('v4_signal',{}).get('decision_record',{}).get('volume_wick_proof',{});target=float(v.get('target') or o.get('holding_rule',{}).get('target') or 0);action=out['action'];allowed=action=='HOLD'
 if action=='PARTIAL':allowed=target>0 and (price-target)*side>=0 and not o.get('partial_used') and not o.get('partial_unsplittable')
 if action=='CLOSE':
  rejection=o.get('structure694_rejection');allowed=(price-old)*side<=0 or bool(rejection and (price-rejection['level'])*side<0)
 if action=='TRAIL':
  candidate=float(o.get('structure694_trail_candidate') or old);allowed=(out['stop']-old)*side>0 and (candidate-out['stop'])*side>=0 and (price-out['stop'])*side>0
 return out if allowed else dict(out,action='HOLD',stop=0,reason='구조 실행 근거 미확인 · 기존 보호 SL 유지 / '+out['reason'][:120])
STRICT_INSTRUCTIONS_694='''694: only supplied three CLOSED15m setups with local-turn confirmation and bounded entry window. No chasing. Regime first; RSI secondary; All new automatic entries10x including BTC/ETH/SOL. Existing positions KEEP actual persisted leverage; never change them to10x. Initial margin AT MOST one-third, sized by structural-stop loss0.5% auto seed including estimated fees, total1%;10% of risk budget reserved for fills. Never widen SL. No fixed ROE profit target. At prior structural extreme secure HALF regardless ROE; breakout plus confirmed NEW favorable pivot trails runner. A wick/touch alone is not failure; confirmed rejection plus local support loss exits. CLOSE/PARTIAL/TRAIL need engine structural corroboration. ADD disabled in694 pending risk-controlled reentry. Learning ranks only comparable completed observations, >=30 per regime/pattern, manual separate reference. No model retraining/profit claim. No arbitrary spread/RR veto; actual fees/impact/funding must be counted in net evaluation. Concise Korean JSON15m schema.'''

INSTRUCTIONS="""700: Three OR families: failed extreme/Bollinger rejection (includes adjacent top/bottom retest; no mandatory double geometry), MA zone support/resistance response, directional impulse pullback response. Mandatory price location, retained structural invalidation and actual favorable completed-bar response. Volume, wick ratios, MA ordering, RSI and1H/4H are EVIDENCE BONUS, NOT individual vetoes for alts. Do not silently restore old conjunctive thresholds. Initial margin is fixed at one-third of auto allocation seed,10x. No stop-distance quantity shrink or0.5%/1% risk veto. Insufficient margin means WAIT, never silently downsize. High evidence score alone does not authorize order; review combined evidence, WAIT if uncertain. Do not promise profit or enter merely because touching a band. New auto leverage10x, fixed one-third margin quantity. At most0.5ATR beyond confirmation reference, no chasing completed large moves. Majors still require explicit directional policy. Only supplied eligible candidates; no new signal types outside three families. HOLD/exit use structural half/runner/protective logic. A new post-entry completed support/resistance with favorable response may tighten SL into estimated net-profit territory BEFORE target breakout; do not wait to give all gains back. Do not close on small ROE fluctuation. Protective intentions are not fills. ADD disabled; never widen SL. Learning697 separate from old strict694, not neural retraining. Concise Korean JSON15m response."""

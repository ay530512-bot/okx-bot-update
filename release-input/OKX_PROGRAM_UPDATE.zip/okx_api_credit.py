"""User-calibrated credit estimate only. No billing/paid API requests or payments."""
import hashlib,webbrowser
from decimal import Decimal,InvalidOperation
from okx_core import BotError
BILLING_URL='https://platform.openai.com/settings/organization/billing/overview'
USAGE_URL='https://platform.openai.com/usage'
def number(v):
 try:
  n=Decimal(str(v))
  if n.is_finite():return n
 except (InvalidOperation,ValueError,TypeError):pass
 return None

def identity(engine):return hashlib.sha256(str(engine.settings.get('OPENAI_API_KEY') or '').encode()).hexdigest()
def open_page(kind='billing'):
 url={'billing':BILLING_URL,'usage':USAGE_URL}.get(kind)
 if url is None:raise ValueError('unknown billing page')
 return webbrowser.open_new_tab(url)

def calibrate(engine,balance):
 n=number(balance)
 if n is None or not 0<=n<=Decimal('1000000000'):raise BotError('OpenAI 공식 페이지에서 확인한 잔액을 0 이상의 달러 숫자로 입력하세요.')
 with engine.lock:
  d=engine.journal.data
  pending={r['id']:str(r['cost']) for r in d.get('model_usage',[]) if r.get('id') and r.get('status')!='billed'}
  d['api_credit_estimate']=dict(balance=str(n),baseline=str(d.get('api_total_spent',0)),pending=pending,ms=engine.api.now_ms(),identity=identity(engine))
  engine.journal.save()
 return estimate(engine)

def estimate(engine):
 with engine.lock:
  d=engine.journal.data;q=d.get('api_credit_estimate')
  result=dict(estimated_balance=None,recorded_balance=None,recorded_ms=None,spent_since=None,estimated=True,status='공식 잔액 미등록 · 충전/잔액에서 입력')
  if not isinstance(q,dict):return result
  result.update(recorded_balance=q.get('balance'),recorded_ms=q.get('ms'))
  if q.get('identity')!=identity(engine):result['status']='API 키 변경 · 공식 잔액 재입력 필요';return result
  baseline=number(q.get('baseline'));balance=number(q.get('balance'));current=number(d.get('api_total_spent'))
  if None in (baseline,balance,current):result['status']='사용 장부 확인 필요 · 공식 잔액 재입력';return result
  # Old in-flight requests can settle below their reservation. Correct only the calibration baseline,
  # never the usage/budget ledger, so refunds do not look like new credit purchases.
  changed=False;pending=q.setdefault('pending',{})
  for row in d.get('model_usage',[]):
   if row.get('id') in pending:
    old=number(pending[row['id']]);new=number(row.get('cost'))
    if old is not None and new is not None:
     baseline+=new-old
     if row.get('status')=='billed':pending.pop(row['id'])
     else:pending[row['id']]=str(new)
     changed=changed or new!=old or row.get('status')=='billed'
  if changed:q['baseline']=str(baseline);engine.journal.save()
  spent=current-baseline
  if spent<Decimal('-.000001'):result['status']='사용 장부 변경 감지 · 공식 잔액 재입력 필요';return result
  spent=max(Decimal(0),spent)
  result.update(estimated_balance=str(balance-spent),spent_since=str(spent),status='추정 잔액 · 이 프로그램 사용액만 반영 / 미확정 예약 포함')
  return result

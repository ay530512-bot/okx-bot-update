"""Predeclared rule combinations; profitability remains an empirical question."""
from okx_entry724 import analyze as analyze724, efficiency, _frames

VARIANTS=('baseline_regime724','balanced725','trend725','blend725','mild726')
DEFAULT_VARIANT='balanced725'  # Candidate default; frozen after development selection.


def analyze(b,hourly=None,variant=None):
    variant=variant or DEFAULT_VARIANT
    if variant not in VARIANTS:raise ValueError('Unknown V725 variant: '+variant)
    if variant=='mild726':
        result=analyze724(b,hourly,'regime724',relaxed=True)
        return dict(result,setups=[dict(v,entry_profile='mild726') for v in result['setups']])
    if variant=='baseline_regime724':return analyze724(b,hourly,'regime724')
    h,error=_frames(b,hourly)
    if h is None:return dict(setups=[],reason=error)
    if variant=='balanced725':values=analyze724(b,h,'regime724')['setups']
    elif variant=='trend725':values=analyze724(b,h,'smooth724')['setups']
    else:
        trend=analyze724(b,h,'smooth724')['setups']
        reversal=analyze724(b,h,'exhaustion724')['setups'] if efficiency([r[4] for r in h])<=.5 else []
        if len({v['action'] for v in trend+reversal})>1:
            return dict(setups=[],reason='추세/반전 방향 충돌 대기')
        values=trend or reversal
    values=[dict(v,policy_version=725,variant725=variant,
                 progress_exit724=True,early_lock725=True) for v in values]
    return dict(setups=values,reason='완료봉 확인' if values else '추세 눌림/확정 반전 대기')


def setup(b,hourly=None,variant=None):
    values=analyze(b,hourly,variant)['setups']
    return max(values,key=lambda v:v['lookback721']) if values else None

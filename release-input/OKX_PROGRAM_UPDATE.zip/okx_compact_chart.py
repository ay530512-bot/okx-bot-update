"""Reusable read-only chart panel for dock and symbol popups."""
import math,queue,tkinter as tk
from tkinter import ttk
from okx_ui_theme import BG,PANEL,INNER,BORDER,TEXT,MUTED,GREEN,RED
from okx_position_chart import draw,window_bounds,hover_candle

def gesture(zoom,dy):return max(.5,min(4.,zoom*math.exp(max(-300,min(300,dy))*.008)))
def mover_groups(rows):
 return (sorted((r for r in rows if r.get('change',0)>0),key=lambda r:-r['change'])[:5],sorted((r for r in rows if r.get('change',0)<0),key=lambda r:r['change'])[:5])
class CompactChart(tk.Frame):
 def __init__(self,parent,view,external=False):
  super().__init__(parent,bg=BG);self.view=view;self.external=external;self.chart_right_bars=10;self.state=view.state;self.demo=view.demo;self.chart_anchor=None;self.chart_count=60;self.chart_price_zoom=1.;self.chart_price_shift=0.;self.frame='15m';self.position=None;self.data={};self.feed=None;self.events=queue.Queue();self.drag=None;self.timer=None;self.closed=False
  bar=tk.Frame(self,bg=PANEL);bar.pack(fill='x');self.title=tk.StringVar(value='차트 · 보유 종목 또는 등락률 종목 선택')
  tk.Label(bar,textvariable=self.title,bg=PANEL,fg=TEXT,font=(view.family,11,'bold')).pack(side='left')
  tools=tk.Frame(self,bg=BG);tools.pack(fill='x')
  for f in ('1m','5m','15m','1H','4H','1D','1W'):tk.Button(tools,text=f,command=lambda f=f:self.change_frame(f),bg=INNER,fg=TEXT,relief='flat',padx=8,pady=6).pack(side='left',padx=2)
  tk.Label(tools,text='드래그 이동 · 휠 확대 · 가격축 세로조절 · 더블클릭 초기화',bg=BG,fg=MUTED,font=(view.family,9)).pack(side='right')
  self.canvas=tk.Canvas(self,bg=BG,highlightthickness=0);self.canvas.pack(fill='both',expand=True)
  self.canvas.bind('<Configure>',lambda e:self.paint());self.canvas.bind('<MouseWheel>',self.wheel)
  self.canvas.bind('<Button-4>',lambda e:self.wheel(e,1));self.canvas.bind('<Button-5>',lambda e:self.wheel(e,-1))
  self.canvas.bind('<ButtonPress-1>',self.press);self.canvas.bind('<B1-Motion>',self.motion);self.canvas.bind('<ButtonRelease-1>',lambda e:setattr(self,'drag',None))
  self.canvas.bind('<Double-Button-1>',lambda e:self.reset())
  self.canvas.bind('<Motion>',lambda e:hover_candle(self,self.canvas,e))
  self.canvas.bind('<Leave>',lambda e:hover_candle(self,self.canvas))
  self.bind('<Destroy>',self.cleanup,add='+');self.timer=self.after(300,self.poll)
 def text(self,c,x,y,text,size,color,bold=False,**kw):return c.create_text(x,y,text=text,fill=color,font=(self.view.family,size,'bold' if bold else 'normal'),anchor=kw.pop('anchor','nw'),**kw)
 def select(self,symbol,position=None):
  previous=(self.position or {}).get('symbol');self.position=dict(position or {},symbol=symbol) if symbol else None
  if previous!=symbol:self.chart_anchor=None;self.chart_price_shift=0.;self.data={}
  from okx_position_chart import NAMES
  self.title.set((symbol or '보유 종목 없음').replace('-USDT-SWAP','/USDT')+' · '+NAMES.get(self.frame,self.frame))
  self.ensure_feed()
  if self.external:self.view.callbacks.get('chart_select',lambda **kw:None)(symbol=symbol,frame=self.frame)
  elif self.feed:self.feed.select(symbol,self.frame)
  self.paint()
 def ensure_feed(self):
  if self.external:return
  factory=self.view.callbacks.get('chart_feed_factory')
  if self.feed is None and factory:self.feed=factory(self.events);self.feed.start()
 def change_frame(self,frame):
  self.frame=frame;self.chart_anchor=None;self.chart_price_shift=0.;self.data={};self.select((self.position or {}).get('symbol'),self.position)
 def poll(self):
  if self.closed:return
  self.ensure_feed()
  if self.position:
   if self.external:self.view.callbacks.get('chart_select',lambda **kw:None)(symbol=self.position['symbol'],frame=self.frame)
   elif self.feed:self.feed.select(self.position['symbol'],self.frame)
  for _ in range(30):
   try:kind,value=self.events.get_nowait()
   except queue.Empty:break
   if kind=='timeframes':
    self.view.receive('timeframes',value);continue
   if value.get('symbol')==(self.position or {}).get('symbol') and value.get('frame')==self.frame:self.data=value;self.paint()
  self.timer=self.after(300,self.poll)
 def reset(self):self.chart_count=60;self.chart_anchor=None;self.chart_price_shift=0.;self.chart_price_zoom=1.;self.paint()
 def paint(self):
  c=self.canvas;c.delete('all');w=c.winfo_width();h=c.winfo_height()
  if w>120 and h>150:draw(self,c,0,0,w,h,self.position,self.data,self.frame)
 def wheel(self,event,direction=None):
  direction=direction if direction is not None else (1 if event.delta>0 else -1)
  if event.x>=self.canvas.winfo_width()-88:self.chart_price_zoom=gesture(self.chart_price_zoom,15*direction)
  else:self.chart_count=max(15,min(250,self.chart_count-5*direction))
  self.paint();return 'break'
 def press(self,event):self.drag_residual=0.;self.drag=(event.x,event.y,'scale' if event.x>=self.canvas.winfo_width()-88 else 'pan')
 def motion(self,event):
  if self.drag is None:return
  x,y,mode=self.drag
  if mode=='scale':self.chart_price_zoom=gesture(self.chart_price_zoom,event.y-y)
  else:
   bars=self.data.get('bars',[]);movement=getattr(self,'drag_residual',0.)+(x-event.x)*(self.chart_count+self.chart_right_bars)/max(1,self.canvas.winfo_width()-98);count=math.trunc(movement);self.drag_residual=movement-count
   if bars and count:
    _,end=window_bounds(bars,self.chart_anchor,self.chart_count);end=max(min(self.chart_count,len(bars)),min(len(bars),end+count));self.chart_anchor=None if end==len(bars) else bars[end-1][0]
    if end-self.chart_count<5:
     if self.external:self.view.callbacks.get('chart_older',lambda **kw:None)(symbol=self.position['symbol'],frame=self.frame)
     elif self.feed:self.feed.load_older(self.position['symbol'],self.frame)
   self.chart_price_shift+=(event.y-y)/max(100,self.canvas.winfo_height()-105)
  self.drag=(event.x,event.y,mode);self.paint()
 def cleanup(self,event):
  if event.widget is not self:return
  self.closed=True
  if self.timer:
   try:self.after_cancel(self.timer)
   except tk.TclError:pass
  if self.feed:self.feed.stop()

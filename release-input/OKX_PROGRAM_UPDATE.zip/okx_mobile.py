"""Private loopback dashboard with authenticated, queued start/pause controls. No direct order endpoint."""
import copy,hashlib,hmac,json,math,queue,re,secrets,threading,time
from collections import deque
from http.cookies import SimpleCookie,CookieError
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from okx_mobile_assets718 import UI_VERSION,asset
PORT=8766
POSITION_KEYS=('close_key','key','symbol','direction','source','leverage','entry','mark','stop','target','target_mode','roe','pnl','margin','margin_basis','quantity','phase','protected','reason','protection_note','stop_note','partial_price','partial_note','exit_estimate_note')
STATE_KEYS=('equity','day_profit','available','api_spent','live','preview','recovering','ended','market_connected','account_connected','run_requested','resume_pending','pause_reason','user_paused')

def clean(value,secrets_to_hide=()):
 if isinstance(value,dict):return {str(k):clean(v,secrets_to_hide) for k,v in value.items()}
 if isinstance(value,(list,tuple)):return [clean(v,secrets_to_hide) for v in value]
 if isinstance(value,bool) or value is None:return value
 if isinstance(value,(float,int)):return value if math.isfinite(value) else None
 text=str(value)
 for secret in secrets_to_hide:text=text.replace(secret,'[숨김]')
 return text

def credential(password):
 salt=secrets.token_hex(16)
 return dict(salt=salt,password_hash=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=16384,r=8,p=1).hex())

def valid_config(config):
 host=config.get('https_host','')
 return bool(re.fullmatch(r'[a-zA-Z0-9.-]+\.ts\.net:8443',host) and re.fullmatch(r'[0-9a-f]{32}',config.get('salt','')) and re.fullmatch(r'[0-9a-f]{128}',config.get('password_hash','')))

class Mobile:
 def __init__(self,root,settings,config,feed_factory=None,port=PORT):
  if not valid_config(config):raise ValueError('모바일 조회 설정 오류')
  self.root=Path(root);self.config=config;self.lock=threading.RLock();self.snapshot={};self.chart_cache={};self.sessions={};self.attempts=deque();self.closed=threading.Event();self.touched=0;self.control_commands=queue.Queue(maxsize=16);self.control_results={}
  self.hidden=tuple(str(v) for k,v in settings.items() if v and len(str(v))>=6 and any(t in k.upper() for t in ('KEY','SECRET','PASS','TOKEN','CHAT_ID')))
  self.events=queue.Queue()
  from okx_position_chart import ChartFeed
  self.feed=(feed_factory or ChartFeed)(settings,self.events)
  self.server=ThreadingHTTPServer(('127.0.0.1',port),self.handler());self.server.daemon_threads=True
  self.port=self.server.server_address[1]
  self.hosts={f'127.0.0.1:{self.port}',f'localhost:{self.port}',config['https_host']}
 def start(self):
  self.feed.start();threading.Thread(target=self.server.serve_forever,daemon=True,name='mobile-readonly').start();threading.Thread(target=self.consume,daemon=True,name='mobile-chart-readonly').start()
 def stop(self):
  self.closed.set();self.feed.stop();self.server.shutdown();self.server.server_close()
 def consume(self):
  while not self.closed.is_set():
   try:
    kind,data=self.events.get(timeout=1)
    if kind=='position_chart':
     with self.lock:self.chart_cache[(data['symbol'],data['frame'])]=clean(data)
   except queue.Empty:pass
   with self.lock:
    if self.touched and time.monotonic()-self.touched>60:self.feed.select(None,'5m');self.touched=0
 def capture(self,view):
  # Called by Tk thread; HTTP threads never touch Tk or the trading engine.
  state={k:view.state.get(k) for k in STATE_KEYS};positions=[{k:p.get(k) for k in POSITION_KEYS} for p in view.positions]
  state['daily_goal']=copy.deepcopy((view.state.get('daily_risk') or {}).get('goal'))
  from okx_compact_chart import mover_groups
  up,down=mover_groups(view.state.get('market_table',{}).get('rows',[]))
  movers=[{k:row.get(k) for k in ('symbol','change','last')} for row in up+down]
  futures=view.state.get('futures_market',{})
  futures=dict(rows=[{k:r.get(k) for k in ('symbol','last','change','ts')} for r in futures.get('rows',[])],observed_ms=futures.get('observed_ms'),basis='KST09시',stale=futures.get('stale',True))
  data=dict(entry_gate=copy.deepcopy(view.state.get('entry_gate')),ui_version=UI_VERSION,futures=futures,controls_enabled=self.config.get('controls_enabled',True),state=state,positions=positions,movers=movers,activities=[dict(time=s,text=t) for s,t,_ in list(view.activities)[:80]],status=view.running_state()[0],captured_ms=int(time.time()*1000),account_age_seconds=max(0,time.monotonic()-view.data_seen) if view.data_seen else None,indicators={k:view.state.get('chart_indicators',{}).get(k) for k in ('ma_periods','bb_period','bb_multiplier')})
  with self.lock:
   data['update_notice']=copy.deepcopy(getattr(view,'update_notice',{}))
   data['program_update']=copy.deepcopy(getattr(self,'update_state',{}))
   self.snapshot=clean(data,self.hidden)
   active={p['symbol'] for p in positions+movers+futures['rows']}
   self.chart_cache={k:v for k,v in self.chart_cache.items() if k[0] in active}
 def history(self,day,source):
  from okx_position_history import report,filter_report
  def read(name):
   p=self.root/name
   if not p.exists():return {}
   value=json.loads(p.read_text(encoding='utf-8'))
   if not isinstance(value,dict):raise ValueError('history cache invalid')
   return value
  settled=[];results=self.root/'position_results.jsonl'
  if results.exists():
   for line in results.read_text(encoding='utf-8').splitlines():
    try:
     value=json.loads(line)
     if isinstance(value,dict):settled.append(value)
    except ValueError:pass
  data=filter_report(report(day,read('position_history_cache.json'),read('position_sources.json'),settled),source)
  data['basis']+=' · PC에 저장된 조회 내역만 표시, 누락 가능'
  return clean(data,self.hidden)
 def session_owner(self,cookie):
  token=SimpleCookie(cookie)['mobile_session'].value
  return hashlib.sha256(token.encode()).hexdigest()
 def enqueue_control(self,op,owner,client_id,ticket=None,**fields):
  if not re.fullmatch(r'[A-Za-z0-9_-]{12,80}',client_id):raise ValueError('request id')
  request_id=hashlib.sha256((owner+':'+client_id).encode()).hexdigest()[:32]
  with self.lock:
   if request_id in self.control_results:return copy.deepcopy(self.control_results[request_id]['public'])
   now=time.monotonic();self.control_results={k:v for k,v in self.control_results.items() if now-v['at']<600}
   if len(self.control_results)>=128:raise ValueError('요청이 많습니다. 잠시 후 다시 시도하세요.')
   command=dict(op=op,owner=owner,request_id=request_id,ticket=ticket,issued_at=now,**fields)
   self.control_commands.put_nowait(command)
   public=dict(request_id=request_id,status='queued',message='PC 처리 대기 · 아직 실행 완료가 아닙니다.')
   self.control_results[request_id]=dict(owner=owner,at=now,public=public)
  return public
 def complete_control(self,data):
  with self.lock:
   record=self.control_results.get(data.get('request_id'))
   if record and record['owner']==data.get('owner'):record['public']=clean({k:v for k,v in data.items() if k!='owner'},self.hidden)
 def control_result(self,request_id,owner):
  with self.lock:
   record=self.control_results.get(request_id)
   if not record or record['owner']!=owner:raise ValueError('request owner')
   data=copy.deepcopy(record['public'])
   if data['status']=='queued' and time.monotonic()-record['at']>35:data.update(status='timeout',message='PC 응답이 지연되었습니다. 실행 상태를 확인하세요. 아직 성공으로 확인되지 않았습니다.')
   return data
 def handler(self):
  service=self
  class Handler(BaseHTTPRequestHandler):
   server_version='Readonly';sys_version=''
   def setup(self):super().setup();self.connection.settimeout(5)
   def log_message(self,*args):pass # No credential/session data in request logs.
   def reply(self,status,data,kind='application/json; charset=utf-8',cookie=None):
    body=data if isinstance(data,bytes) else json.dumps(data,ensure_ascii=False,allow_nan=False).encode()
    self.send_response(status);self.send_header('Content-Type',kind);self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Frame-Options','DENY');self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'")
    if self.headers.get('Host')==service.config['https_host']:self.send_header('Strict-Transport-Security','max-age=31536000')
    if cookie:self.send_header('Set-Cookie',cookie)
    self.end_headers();self.wfile.write(body)
   def host_ok(self):
    if self.headers.get('Host') not in service.hosts:self.reply(403,{'error':'허용되지 않은 주소'});return False
    return True
   def authorized(self):
    try:c=SimpleCookie(self.headers.get('Cookie',''));token=c['mobile_session'].value
    except (KeyError,ValueError,CookieError):return False
    with service.lock:
     expiry=service.sessions.get(token,0)
     if expiry<=time.monotonic():service.sessions.pop(token,None);return False
    return True
   def do_GET(self):
    if not self.host_ok():return
    parsed=urlsplit(self.path);path=parsed.path
    assets={'/':'index.html','/app.js':'app.js','/style.css':'style.css'}
    if path in assets:
     content=asset(assets[path]);kind={'/':'text/html','/app.js':'text/javascript','/style.css':'text/css'}[path]+'; charset=utf-8';self.reply(200,content,kind);return
    if path=='/api/version':
     self.reply(200,dict(ui_version=UI_VERSION,features=['kst09_market','symbol_chart','quarter_entry','close_one']));return
    if not self.authorized():self.reply(401,{'error':'로그인이 필요합니다.'});return
    try:
     args=parse_qs(parsed.query)
     if path=='/api/control/result':
      self.reply(200,service.control_result(args.get('id',[''])[0],service.session_owner(self.headers.get('Cookie',''))))
     elif path=='/api/snapshot':
      with service.lock:data=copy.deepcopy(service.snapshot)
      self.reply(200,data)
     elif path=='/api/learning':
      from okx_learning_history import day_view,describe
      day=args.get('date',[''])[0];source=args.get('source',['auto'])[0]
      if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day):raise ValueError('date')
      data=day_view(service.root,day,source)
      data['items']=[dict(text=describe(i),recorded_ms=i['recorded_ms']) for i in data['items']]
      self.reply(200,data)
     elif path=='/api/history':
      day=args.get('date',[''])[0];source=args.get('source',['all'])[0]
      if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',day):raise ValueError('date')
      self.reply(200,service.history(day,source))
     elif path=='/api/chart':
      symbol=args.get('symbol',[''])[0];frame=args.get('frame',['15m'])[0]
      with service.lock:
       if symbol not in {p['symbol'] for p in service.snapshot.get('positions',[])+service.snapshot.get('movers',[])+service.snapshot.get('futures',{}).get('rows',[])}:raise ValueError('position')
       if frame not in ('1m','5m','15m','1H','4H','1D','1W'):raise ValueError('frame')
       service.touched=time.monotonic();service.feed.select(symbol,frame)
       if args.get('older')==['1']:service.feed.load_older(symbol,frame)
       data=copy.deepcopy(service.chart_cache.get((symbol,frame),{'symbol':symbol,'frame':frame,'bars':[],'error':'차트 조회 중'}))
      from okx_direction732 import describe
      data['analysis_text']=describe(data.get('analysis'),(service.snapshot.get('entry_gate') or {}).get('preview_margin'),int(time.time()*1000))
      from okx_funding732 import describe as describe_funding
      monitor=getattr(service.feed,'funding',None)
      data['funding']=monitor.snapshot(symbol) if monitor else None
      if data['funding'] is not None:data['funding']['symbol']=symbol
      data['funding_text']=describe_funding(data['funding'],(service.snapshot.get('entry_gate') or {}).get('preview_margin'))
      self.reply(200,data)
     else:self.reply(404,{'error':'조회 경로가 없습니다.'})
    except (ValueError,KeyError,TypeError,json.JSONDecodeError):self.reply(400,{'error':'조회 조건 또는 PC 저장 내역을 확인하세요.'})
    except OSError:self.reply(503,{'error':'PC 저장 자료를 읽지 못했습니다.'})
   def do_POST(self):
    if not self.host_ok():return
    host=self.headers['Host'];origin=('https://' if host==service.config['https_host'] else 'http://')+host
    received_origin=self.headers.get('Origin')
    if received_origin not in (origin,'https://'+service.config['https_host']):self.reply(403,{'error':'동일 주소에서 요청하세요.'});return
    control_paths={'/api/control/prepare':'prepare','/api/control/confirm':'confirm','/api/control/pause':'pause','/api/control/entry':'entry','/api/control/close_one':'close_one','/api/control/close_all':'close_all','/api/control/update':'update'}
    if self.path in control_paths:
     if received_origin!='https://'+service.config['https_host']:self.reply(403,{'error':'HTTPS 모바일 주소에서만 운용 제어할 수 있습니다.'});return
     if not self.authorized():self.reply(401,{'error':'로그인이 필요합니다.'});return
     if not service.config.get('controls_enabled',True):self.reply(403,{'error':'운용 제어가 비활성화되어 있습니다.'});return
     try:
      length=int(self.headers.get('Content-Length','0'))
      if not 0<length<=4096 or self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('body')
      body=json.loads(self.rfile.read(length))
      if not isinstance(body,dict) or set(body)-{'client_id','ticket','symbol','direction','key'}:raise ValueError('fields')
      result=service.enqueue_control(control_paths[self.path],service.session_owner(self.headers.get('Cookie','')),body.get('client_id',''),body.get('ticket'),**{k:body[k] for k in ('symbol','direction','key') if k in body})
      self.reply(202,result)
     except (ValueError,TypeError,queue.Full):self.reply(400,{'error':'요청이 많거나 형식이 올바르지 않습니다.'})
     return
    if self.path not in ('/login','/logout'):self.reply(405,{'error':'허용되지 않은 제어 경로입니다.'});return
    suffix='; Path=/; HttpOnly; SameSite=Strict'+('; Secure' if received_origin=='https://'+service.config['https_host'] else '')
    if self.path=='/logout':
     if self.authorized():
      c=SimpleCookie(self.headers.get('Cookie',''))
      with service.lock:service.sessions.pop(c['mobile_session'].value,None)
     self.reply(200,{'ok':True},cookie='mobile_session=; Max-Age=0'+suffix);return
    try:
     length=int(self.headers.get('Content-Length','0'))
     if not 0<length<=4096:raise ValueError()
     if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError()
     password=json.loads(self.rfile.read(length)).get('password')
     if not isinstance(password,str) or len(password)>256:raise ValueError()
    except (ValueError,TypeError,AttributeError):self.reply(400,{'error':'로그인 입력 오류'});return
    with service.lock:
     now=time.monotonic()
     while service.attempts and service.attempts[0]<now-60:service.attempts.popleft()
     if len(service.attempts)>=5:self.reply(429,{'error':'로그인 시도가 많습니다. 1분 후 다시 시도하세요.'});return
     service.attempts.append(now)
     actual=hashlib.scrypt(password.encode(),salt=bytes.fromhex(service.config['salt']),n=16384,r=8,p=1).hex()
     if not hmac.compare_digest(actual,service.config['password_hash']):self.reply(401,{'error':'비밀번호를 확인하세요.'});return
     service.sessions={k:v for k,v in service.sessions.items() if v>now}
     if len(service.sessions)>=64:service.sessions.pop(next(iter(service.sessions)))
     token=secrets.token_urlsafe(32);service.sessions[token]=now+43200
    self.reply(200,{'ok':True},cookie='mobile_session='+token+'; Max-Age=43200'+suffix)
  return Handler

def start_mobile(root,settings):
 path=Path(root)/'mobile_access.json'
 if not path.exists():return None
 config=json.loads(path.read_text(encoding='utf-8'))
 if not config.get('enabled'):return None
 service=Mobile(root,settings,config);service.start();return service

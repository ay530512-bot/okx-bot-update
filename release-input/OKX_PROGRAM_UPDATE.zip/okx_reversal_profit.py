"""Causal, profitable reversal partial exit; no exchange calls."""
from okx_rules import metrics


def reason(frames,position,owned,c,now):
    cfg=c['risk'].get('reversal_profit',{})
    if not cfg.get('enabled') or owned.get('partial_used') or owned.get('partial_unsplittable'):
        return None
    if float(position.get('uplRatio') or 0)<=0:return None
    rule=owned.get('holding_rule') or {}
    if rule.get('wave'):
        from okx_wave_mode import net_profitable
        if not net_profitable(position,owned):return None
    frame=rule['frame'] if rule.get('wave') else cfg.get('timeframe','5m');step={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}[frame]
    bars=[r for r in frames.get(frame,[]) if r[0]+step<=now]
    need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+2
    if len(bars)<need:return None
    prev,last=bars[-2:]
    if prev[0]<owned.get('entry_ms',0) or now-(last[0]+step)>step:return None
    m=metrics(bars[:-1],c);atr=m['atr']
    if atr<=0:return None
    side=1 if position['posSide']=='long' else -1
    body=abs(prev[4]-prev[1]);span=prev[2]-prev[3]
    tail=prev[2]-max(prev[1],prev[4]) if side==1 else min(prev[1],prev[4])-prev[3]
    rejection=(tail>=body*cfg['wick_body_ratio'] and tail>=span*cfg['wick_range_fraction']
               and tail>=atr*cfg['wick_atr'])
    follow=(last[4]-prev[4])*side<-atr*cfg['reaction_atr'] and (last[4]-last[1])*side<0
    level=m['ma'][20]
    ma_failure=(prev[4]-level)*side<0 and (last[4]-level)*side<0
    structure=(last[2]-prev[2])*side<0 and (last[3]-prev[3])*side<0
    if follow and (rejection or (ma_failure and structure)):
        return frame+' 수익 중 반전 확인: '+('반대 꼬리·후속 역방향 마감' if rejection else 'MA20 2봉 이탈·고저점 악화')
    return None

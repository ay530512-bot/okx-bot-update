"""Causal target selection and immutable public-candle cache. No trading writes."""
import copy,threading,time,math
from okx_core import BotError

_CACHE={};_LOCK=threading.RLock()
STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}


def enabled(c):return c.get('execution',{}).get('entry_pipeline',{}).get('enabled',False)


def clear_candles(api):
    namespace=getattr(api,'candle_cache_namespace',id(api))
    with _LOCK:
        for k in list(_CACHE):
            if k[0]==namespace:_CACHE.pop(k,None)


def candle_rows(api,symbol,bar,c):
    if not enabled(c):return api.public('/api/v5/market/candles',instId=symbol,bar=bar,limit='300')
    now=api.now_ms();step=STEPS[bar];bucket=now//step;key=(getattr(api,'candle_cache_namespace',id(api)),symbol,bar)
    with _LOCK:
        old=_CACHE.get(key)
        if old and old[0]==bucket and time.monotonic()-old[1]<60:
            return copy.deepcopy(old[2])
    rows=api.public('/api/v5/market/candles',instId=symbol,bar=bar,limit='300')
    # Cache only a complete current closed-bar snapshot and actual next-bar open.
    end=api.now_ms();current=end//step
    if current==bucket and any(int(r[0])==(current-1)*step and r[8]=='1' for r in rows):
        with _LOCK:
            _CACHE[key]=(bucket,time.monotonic(),copy.deepcopy(rows))
            if len(_CACHE)>1000:
                oldest=min(_CACHE,key=lambda k:_CACHE[k][1]);_CACHE.pop(oldest,None)
    return copy.deepcopy(rows)


def funding_rate(api,symbol,c):
    row=api.public('/api/v5/public/funding-rate',instId=symbol)[0]
    age=api.now_ms()-int(row['ts'])
    limit=c.get('execution',{}).get('entry_pipeline',{}).get('funding_max_age_seconds',60)
    if not 0<=age<=limit*1000:raise BotError(f'펀딩비 데이터 지연: 경과 {age/1000:.1f}초 / 허용{limit:g}초')
    if not math.isfinite(float(row['fundingRate'])):raise BotError('펀딩비 수치 오류')
    return row


def target_for(hit,frames,metrics5,metrics15,levels,c,price,atr):
    side=1 if hit['direction']=='LONG' else -1
    if not enabled(c):return None,None
    if hit.get('fast_scalp'):
        target=hit.get('target')
        return target,'기존 스캘핑 고정 목표'
    pattern=hit['pattern']
    reversal=any(v in pattern for v in ('rejection','reversal','single_wick','two_bar_reclaim','tail_turn'))
    # Confirmed price extremes are obstacles; an internal MA is not automatically a trend take-profit.
    refs=[(p['price'],'15m 확정 가격 구간') for p in levels]
    for f in ('5m','15m','1H','4H'):
        step=STEPS[f];known=[r for r in frames.get(f,[]) if r[0]+step<=hit['anchor']]
        if len(known)>=20:
            refs.append((max(r[2] for r in known[-20:]) if side==1 else min(r[3] for r in known[-20:]),f+' 직전20봉 극점'))
    if reversal:
        if hit['frame']=='1m':
            from okx_rules import metrics
            source=metrics(frames['1m'],c)
        else:source=metrics5 if hit['frame']=='5m' else metrics15
        refs.append((source['mid'],'반전 경로 밴드 중심선'))
        refs.append((source['upper'] if side==1 else source['lower'],'반전 경로 반대 밴드'))
    viable=[(float(v),src) for v,src in refs if math.isfinite(float(v)) and (float(v)-price)*side>0]
    if not viable:
        if pattern in ('trend_breakout_adaptive','case_breakout_long','case_breakdown_short','breakout_retest'):
            # A fixed chart range projection, never increased until reward/risk passes.
            known=[r for r in frames.get('5m',[]) if r[0]+300000<=hit['anchor']][-20:]
            if len(known)==20:
                high=max(r[2] for r in known);low=min(r[3] for r in known)
                target=high+(high-low) if side==1 else low-(high-low)
                if (target-price)*side>0:return target,'5m 직전20봉 범위1배 측정 목표(실제 저항/지지 아님)'
        return None,'유리한 방향의 실제 목표 구간 없음'
    best=min(viable,key=lambda x:(x[0]-price)*side)
    return best


def approximate_ratio(hit,price,c):
    side=1 if hit['direction']=='LONG' else -1
    cost=c['execution']['entry_pipeline']['estimated_cost_rate'];loss=(price-hit['stop'])*side+price*cost
    return ((hit['target']-price)*side-price*cost)/loss if loss>0 and hit.get('target') is not None else -float('inf')

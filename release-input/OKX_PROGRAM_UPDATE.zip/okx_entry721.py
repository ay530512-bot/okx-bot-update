"""Deterministic completed-15m entry policy; not a fitted/proven profit model."""
from okx_band_flow import atr
from okx_market import rsi
PERIODS=(50,100,120,150,200,240)
LOOKBACKS=(20,15,10)

def analyze(b):
    if len(b)<241:return dict(setups=[],reason='완료봉241개 필요')
    last=b[-1];o,h,l,c,v=map(float,last[1:6]);a=atr(b[:-1]);span=h-l
    if a<=0 or span<=0:return dict(setups=[],reason='ATR/캔들 범위 오류')
    closes=[float(x[4]) for x in b];rs=rsi(closes,14)
    mas={n:sum(closes[-n:])/n for n in PERIODS}
    slopes={n:mas[n]-sum(closes[-n-1:-1])/n for n in PERIODS}
    setups=[]
    for n in LOOKBACKS:
        prior=b[-n-1:-1];hi=max(x[2] for x in prior);lo=min(x[3] for x in prior)
        volume=sum(x[5] for x in prior)/n
        if volume<=0:continue
        ratio=v/volume
        for side in (1,-1):
            momentum=rs>=50 if side==1 else rs<=50
            strength=(c-l if side==1 else h-c)/span
            votes=sum((c-mas[p])*side>0 and slopes[p]*side>0 for p in PERIODS)
            if not momentum or (c-o)*side<=0 or strength<.65 or span>3*a:continue
            edge=hi if side==1 else lo
            breakout=(c-edge)*side>0 and (c-edge)*side<=a and ratio>=1.2 and votes>=3
            # Retest of a sloping MA: rejection wick + directional close + volume.
            wick=(min(o,c)-l if side==1 else h-max(o,c))/span
            touched=[p for p in PERIODS if slopes[p]*side>0
                     and (c-mas[p])*side>0
                     and (l<=mas[p]+.25*a and l>=mas[p]-.5*a if side==1
                          else h>=mas[p]-.25*a and h<=mas[p]+.5*a)]
            prior_trend=sum((x[4]-prior[0][4])*side>0 for x in prior[1:])>=max(1,(n-1)//2)
            retest=bool(touched) and votes>=2 and ratio>=1 and wick>=.30 and prior_trend
            if not (breakout or retest):continue
            stop=c-side*2*a
            if stop<=0:continue
            route='breakout' if breakout else 'ma_retest'
            setups.append(dict(setup='channel20_10',action='LONG' if side==1 else 'SHORT',priority=0 if breakout else 1,
                route721=route,lookback721=n,ma_touched721=touched,confirmation_ms=last[0],signal_ms=last[0],test_ms=last[0],
                structural_stop=stop,target=None,atr=a,reference=c,channel_high=hi,channel_low=lo,
                learning_key='rule721|'+route+'|'+str(n)+'|'+str(side),
                confirmation721=dict(volume_ratio=ratio,rsi14=rs,ma=mas,ma_slopes=slopes,ma_votes=votes,close_strength=strength,wick_fraction=wick)))
    # One symbol, one direction. Conflicting interpretations wait rather than guess.
    if len({v['action'] for v in setups})>1:return dict(setups=[],reason='롱·숏 경로 충돌 대기')
    return dict(setups=setups,reason='신호 확인' if setups else '10/15/20봉 돌파·이평 지지저항 및 거래량/RSI 확인 대기')

def setup(b):
    candidates=analyze(b)['setups']
    return min(candidates,key=lambda x:(x['priority'],-x['lookback721'])) if candidates else None

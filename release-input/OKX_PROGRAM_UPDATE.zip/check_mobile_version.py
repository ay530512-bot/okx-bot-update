"""Read-only local mobile deployment diagnosis. No keys, orders or process kills."""
import json
from pathlib import Path
from urllib.request import urlopen

def main():
    from okx_mobile_assets718 import UI_VERSION,asset
    print('Packaged mobile version:',UI_VERSION)
    print('Packaged UI: marketPanel / chartLong / marketShort / closeone; no learning panel')
    try:
        with urlopen('http://127.0.0.1:8766/api/version',timeout=3) as r:version=json.load(r)
        running=version.get('ui_version')
        print('Running mobile server:',running)
        print('VERSION MATCH' if running==UI_VERSION else 'VERSION MISMATCH: close the previous program normally, then launch START_HERE.bat from this folder.')
    except Exception:
        print('OLD SERVER OR SERVER NOT RUNNING. Close previous program normally, then launch START_HERE.bat from this folder.')
    config=Path(__file__).resolve().with_name('mobile_access.json')
    if config.exists():
        d=json.loads(config.read_text(encoding='utf-8'));host=d.get('https_host','')
        if host:print('Open this fresh address in Safari: https://'+host+'/')
    print('Do not delete .env or bot_state.json. This check does not stop or close positions.')
if __name__=='__main__':main()

"""Causal alternative setups; deterministic evidence selection, followed by AI review.
Only completed bars are supplied. No exchange calls, no orders.
"""
from okx_rules import metrics, zones


def setups(b5, b15, c):
    last, prev = b5[-1], b5[-2]
    m = metrics(b5[:-1], c)
    atr = m['atr']
    tol = atr * .65
    # Freeze reference levels before the confirmation candle starts.
    known15 = [b for b in b15 if b[0] + 900000 <= last[0]]
    context = None
    levels = [dict(p, source='5m confirmed pivot') for p in zones(b5[:-1], c)]
    if len(known15) >= 205:
        levels += [dict(p, source='15m confirmed pivot') for p in zones(known15, c)]
        context = metrics(known15, c)
        levels += [dict(price=v, kind='average', source='15m SMA'+str(k))
                   for k, v in context['ma'].items() if k in (15,20,50)]
    hits = []
    for side in (1, -1):
        kind = 'support' if side == 1 else 'resistance'
        # At least one closed directional reaction; a wick by itself is insufficient.
        follow = ((last[4]-last[1])*side > 0 and
                  (last[4]-prev[4])*side >= atr*c['signals']['follow_atr'])
        if not follow:
            continue
        test = min(b[3] for b in b5[-3:]) if side == 1 else max(b[2] for b in b5[-3:])
        body = abs(prev[4]-prev[1])
        wick = min(prev[1],prev[4])-prev[3] if side == 1 else prev[2]-max(prev[1],prev[4])
        rejection = wick >= max(body*.6, atr*.15)
        improves = last[3] > prev[3] if side == 1 else last[2] < prev[2]
        turn = (last[4]-prev[2])*side > 0 if side == 1 else (last[4]-prev[3])*side > 0
        volume = last[5] >= sum(b[5] for b in b5[-21:-1])/20
        confirms = sum((rejection, improves, turn, volume))
        def add(pattern, level, source, anchor_extreme=test):
            # The structural extreme is retained for independent stop validation.
            low = min(test, anchor_extreme) if side == 1 else min(b[3] for b in b5[-3:])
            high = max(test, anchor_extreme) if side == -1 else max(b[2] for b in b5[-3:])
            hits.append(dict(direction='LONG' if side == 1 else 'SHORT', pattern=pattern,
                frame='5m', low=low, high=high, anchor=last[0], level=level,
                source=source, shape={}, adaptive=True, evidence_score=2+confirms,
                evidence=dict(rejection=rejection, improved_extreme=improves,
                              micro_break=turn, active_volume=volume)))
        # Symmetric band exhaustion: first closed reaction, no band re-entry/MA turn required.
        for offset in (1,2,3):
            anchor = b5[-offset]
            before = b5[:-offset]
            if len(before) < max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1:
                continue
            prior_band = metrics(before,c)
            edge_key = 'lower' if side == 1 else 'upper'
            references = [('5m '+edge_key+' band',prior_band[edge_key])]
            known = [b for b in b15 if b[0]+900000 <= anchor[0]]
            if len(known) >= max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1:
                references.append(('15m '+edge_key+' band',metrics(known,c)[edge_key]))
            extreme = anchor[3] if side == 1 else anchor[2]
            breached = [(name,edge) for name,edge in references if (edge-extreme)*side > atr*.05]
            window = b5[-offset:]
            extreme = min(b[3] for b in window) if side == 1 else max(b[2] for b in window)
            retreat = (last[4]-extreme)*side
            no_new_extreme = last[3] >= anchor[3]-atr*.1 if side == 1 else last[2] <= anchor[2]+atr*.1
            reacted = ((last[4]-last[1])*side > 0 and (last[4]-prev[4])*side > atr*.03 and
                       atr*.3 <= retreat <= atr*2.5 and no_new_extreme)
            if breached and reacted:
                name,edge = breached[0]
                pattern = 'lower_band_reversal_long' if side == 1 else 'upper_band_reversal_short'
                add(pattern,edge,name+' excursion / first closed 5m reaction',extreme)
                hits[-1]['evidence_score'] += 1
                hits[-1]['evidence'].update(band_break=True,closed_reaction=True,
                    excursion_ms=anchor[0],reference_edge=edge,retreat_atr=retreat/atr)
                break
        if not confirms:
            continue
        for p in levels:
            if p['kind'] not in (kind, 'average'):
                continue
            level = p['price']
            if abs(test-level) <= tol and (last[4]-level)*side > 0:
                add('level_reversal', level, p['source'])
                break
        # Trend entries are alternatives to reversal entries, not additional requirements.
        if context is not None:
            aligned = ((context['ma'][15]-context['ma'][20])*side > 0 and
                       context['slopes'][20]*side > 0 and context['mid_slope']*side > 0 and
                       (last[4]-context['ma'][20])*side > 0)
            local = ((m['ma'][15]-m['ma'][20])*side > 0 and m['slopes'][20]*side > 0)
            extension = abs(last[4]-m['ma'][20])/atr
            if aligned and local and extension <= c['signals']['max_extension_atr']:
                # A shallow 5m pullback can enter even without reaching a 15m average.
                reference = m['ma'][15]
                touched = any(b[3]-tol <= reference <= b[2]+tol for b in b5[-4:-1])
                pause = any((b[4]-b[1])*side <= 0 for b in b5[-4:-1])
                if touched and pause and (last[4]-reference)*side > 0 and (improves or turn):
                    add('trend_pullback_adaptive', reference, '15m trend / 5m shallow pullback')
                    hits[-1]['evidence_score'] += 2
                    hits[-1]['evidence']['trend_aligned'] = True
                # A closed range break may enter directly; a retest is optional.
                window = b5[-9:-1]
                edge = max(b[2] for b in window) if side == 1 else min(b[3] for b in window)
                breakout = (last[4]-edge)*side >= atr*.05 and (prev[4]-edge)*side <= 0
                if breakout and volume and abs(last[4]-last[1]) <= atr*1.5:
                    add('trend_breakout_adaptive', edge, '15m trend / closed 5m range breakout')
                    hits[-1]['evidence_score'] += 2
                    hits[-1]['evidence']['trend_aligned'] = True
        # Local base/top stabilization: reference excludes the reaction's last 3 bars.
        history = b5[-15:-3]
        level = min(b[3] for b in history) if side == 1 else max(b[2] for b in history)
        excursion = max(b[2] for b in history)-level if side == 1 else level-min(b[3] for b in history)
        touches = sum(abs((b[3] if side == 1 else b[2])-level) <= tol for b in b5[-6:-1])
        if abs(test-level) <= tol and excursion >= atr and touches >= 2 and improves and (last[4]-level)*side > atr*.15:
            add('base_reversal', level, 'local base/top with repeated tests')
        # Previously confirmed break, followed by a test on a later candle.
        for p in levels:
            if p['kind'] != ('resistance' if side == 1 else 'support'):
                continue
            level = p['price']
            known = p.get('confirmed', last[0])+ (900000 if p['source'].startswith('15m') else 300000)
            broken = any(b[0] >= known and (b[4]-level)*side > atr*.15 for b in b5[-8:-2])
            test_prev = prev[3] if side == 1 else prev[2]
            if broken and abs(test_prev-level) <= tol and (prev[4]-level)*side >= 0 and (last[4]-level)*side > 0:
                add('breakout_retest_adaptive', level, p['source'], test_prev)
                break
    return hits

@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PY=.venv\Scripts\python.exe") else (set "PY=python")
"%PY%" -m unittest discover -s tests -p test_quarter732q.py -v
pause

"""Trading-account USDT transfers. Verified ledger only; no guessed cash flows."""
import time
from okx_core import BotError,dec,fmt

def fetch_transfers(api,start,end):
 rows=[];seen=set();cursor=None
 for _ in range(20):
  params=dict(ccy='USDT',type='1',begin=str(start),end=str(end),limit='100')
  if cursor is not None:params['after']=cursor
  page=api.get('/api/v5/account/bills',**params)
  for row in page:
   if row['billId'] not in seen:
    seen.add(row['billId'])
    if row.get('type')=='1' and row.get('ccy')=='USDT' and start<int(row['ts'])<=end:
     if not dec(row['balChg']).is_finite():raise BotError('이체 금액 형식 오류: 손익 대조 대기')
     rows.append(row)
  if len(page)<100:return rows
  next_cursor=page[-1]['billId']
  if next_cursor==cursor:raise BotError('이체 내역 페이지 반복: 손익 대조 대기')
  cursor=next_cursor;time.sleep(.35)
 raise BotError('이체 조회 범위 초과: 손익 대조 대기')

def correct_transfer_latch(day,new_rows,risk):
 if not day.get('ended') or not new_rows:return False
 if day.get('end_reason')!='일일 -21% 손실 한도':return False
 if not all(k in day for k in ('stop_observed_ms','stop_observed_equity','stop_observed_base','stop_observed_start')):
  day['transfer_latch_note']='이체 보정 완료 / 기존 중단 당시 자산·시각 미기록: 자동 해제 보류';return False
 delta=sum((dec(b['balChg']) for b in new_rows if int(b['ts'])<=day['stop_observed_ms']),dec(0))
 if delta==0:return False
 base=dec(day['stop_observed_base'])+delta;start=dec(day['stop_observed_start'])
 day['stop_observed_base']=fmt(base)
 if start<=0:return False
 roi=(dec(day['stop_observed_equity'])-base)/start
 day['stop_corrected_roi']=float(roi)
 if dec(risk['daily_stop'])<roi<dec(risk['daily_cap']):
  day.update(ended=False,previous_end_reason=day.pop('end_reason'),transfer_latch_note='중단 당시 이전 이체 누락 확인: 보정 후 한도 내, 이체 오인 중단 해제')
  return True
 day['transfer_latch_note']='이체 보정 후에도 중단 당시 매매 손익 한도 초과: 중단 유지';return False


def reconcile_legacy_transfer_stop(day,rows,equity,risk,authorized,now):
 """User-authorized recheck of legacy latches with no original observation.

 This is current-ledger revalidation, not a claim about unrecorded past PnL.
 Recorded genuine loss latches remain governed by correct_transfer_latch.
 """
 if not authorized or not day.get('ended') or day.get('end_reason')!='일일 -21% 손실 한도':return False
 observed=('stop_observed_ms','stop_observed_equity','stop_observed_base','stop_observed_start')
 if any(k in day for k in observed):return False
 start=dec(day.get('start_equity',0));base=dec(day['base']);current=dec(equity)
 if start<=0:return False
 flow=sum((dec(r['balChg']) for r in rows),dec(0))
 if flow>=0 or flow!=dec(day.get('net_flow',0)) or base!=start+flow:return False
 corrected=(current-base)/start;unadjusted=(current-start)/start
 if unadjusted>dec(risk['daily_stop']) or not dec(risk['daily_stop'])<corrected<dec(risk['daily_cap']):return False
 day.update(ended=False,previous_end_reason=day.pop('end_reason'),legacy_transfer_revalidated_ms=now,
  legacy_transfer_revalidated_equity=fmt(current),legacy_transfer_revalidated_flow=fmt(flow),
  legacy_transfer_revalidated_roi=float(corrected),transfer_latch_note='사용자 요청에 따른 이전 중단 재점검: 확인된 순출금 제외 후 현재 매매손익 한도 내, 신규 진입 차단 해제')
 return True

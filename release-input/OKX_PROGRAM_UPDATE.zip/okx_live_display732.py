"""Private WS display overlay only; never grants freshness to order/account gates."""
import time
from decimal import Decimal,InvalidOperation

def apply_position(positions,event,now_ms=None):
    now_ms=int(time.time()*1000) if now_ms is None else now_ms
    try:
        received=int(event['received_ms']);row=event['row']
        if not 0<=now_ms-received<=5000:return False
        def number(v):
            x=Decimal(str(v))
            if not x.is_finite():raise ValueError('nonfinite')
            return x
        qty=number(row.get('pos'))
        if qty<=0:return False # REST reconciliation handles closures/size changes.
        for p in positions:
            if (p.get('symbol'),p.get('direction'))!=(row.get('instId'),row.get('posSide')):continue
            if number(p.get('quantity'))!=qty or number(p.get('entry'))!=number(row.get('avgPx')):continue
            if received<int(p.get('live_received_ms',0)):return False
            patch={}
            for dst,src in [('mark','markPx'),('roe','uplRatio'),('pnl','upl')]:
                v=number(row.get(src))
                if dst=='mark' and v<=0:return False
                patch[dst]=str(v)
            p.update(patch,live_received_ms=received)
            return True
    except (ValueError,TypeError,KeyError,InvalidOperation):pass
    return False

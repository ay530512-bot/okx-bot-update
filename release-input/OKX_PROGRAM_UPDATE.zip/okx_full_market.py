"""All eligible crypto USDT swaps: public quotes and causal local double-wave scans."""
import math,time,threading
from concurrent.futures import ThreadPoolExecutor,as_completed
from collections import Counter
from okx_core import OKX
from okx_rules import allowed_instrument,metrics
from okx_market import closed_candles
from okx_swing_context import evidence,STEPS

def rank_quotes(tickers,now):
 start=now//86400000*86400000;rows=[]
 for symbol,t in tickers.items():
  try:
   last=float(t['last']);base=float(t['sodUtc0']);ts=int(t['ts'])
   if not all(math.isfinite(v) and v>0 for v in (last,base)) or ts//86400000*86400000!=start or not 0<=now-ts<=60000:continue
   rows.append(dict(symbol=symbol,last=last,opening=base,change=last/base-1,ms=ts,ranking_start_ms=start))
  except (KeyError,TypeError,ValueError,OverflowError):continue
 ordered=sorted(rows,key=lambda r:(-r['change'],r['symbol']))
 gain=[r for r in ordered if r['change']>0];loss=sorted([r for r in ordered if r['change']<0],key=lambda r:(r['change'],r['symbol']))
 for n,r in enumerate(ordered,1):r['rank']=n
 for n,r in enumerate(gain,1):r.update(mover_group='gainer',mover_rank=n)
 for n,r in enumerate(loss,1):r.update(mover_group='loser',mover_rank=n)
 for r in ordered:r.setdefault('mover_group','flat');r.setdefault('mover_rank',None)
 return ordered

class FullMarket:
 def __init__(self,owner):self.owner=owner;self.cache={};self.quotes={};self.instruments={};self.last_instruments=0;self.quote_error='첫 전체 시세 대기';self.progress={}
 def quote_loop(self):
  api=OKX(self.owner.settings)
  try:
   while not self.owner.stop_event.is_set():
    try:
     if not self.instruments or time.monotonic()-self.last_instruments>600:
      instruments=api.public('/api/v5/public/instruments',instType='SWAP')
      self.instruments={i['instId']:i for i in instruments if allowed_instrument(i,self.owner.cfg)};self.last_instruments=time.monotonic()
     data=api.public('/api/v5/market/tickers',instType='SWAP');now=api.now_ms()
     with self.owner.lock:self.quotes={t['instId']:dict(t) for t in data if t['instId'] in self.instruments};self.quote_ms=now;self.quote_error=None
    except Exception as error:
     with self.owner.lock:self.quote_error=type(error).__name__
    self.owner.stop_event.wait(10)
  finally:api.session.close()
 def market(self):
  with self.owner.lock:return dict(quotes={k:dict(v) for k,v in self.quotes.items()},instruments={k:dict(v) for k,v in self.instruments.items()},ms=getattr(self,'quote_ms',0),error=self.quote_error,progress=dict(self.progress))
 def bars(self,api,symbol,frame):
  now=api.now_ms();step=STEPS[frame];expected=now//step*step-step;key=(symbol,frame)
  with self.owner.lock:cached=self.cache.get(key)
  if cached and cached[-1][0]==expected:return cached
  self.owner.throttle()
  if self.owner.stop_event.is_set() or self.owner.search_paused.is_set():raise RuntimeError('신규 탐색 중지')
  raw=api.public('/api/v5/market/candles',instId=symbol,bar=frame,limit='300')
  raw=[list(r) for r in raw]
  for r in raw:r[7]=r[5]
  rows=closed_candles(raw,frame,api.now_ms())
  if not rows or rows[-1][0]!=api.now_ms()//step*step-step:raise ValueError('최신 완료봉 대기')
  with self.owner.lock:self.cache[key]=rows
  return rows
 def scan(self):
  from okx_band_flow import enabled as band_enabled,scan as band_scan
  if band_enabled(self.owner.cfg):return band_scan(self)
  owner=self.owner;started=time.monotonic()
  while not self.quotes and not owner.stop_event.is_set():owner.stop_event.wait(.3)
  state=self.market();now=state['ms'];quotes=rank_quotes(state['quotes'],now);by_symbol={r['symbol']:r for r in quotes};counts=Counter();matched=[];worker=threading.local();apis=[];api_lock=threading.Lock()
  instruments=[i for i in state['instruments'].values() if i['instId'] in by_symbol and i.get('listTime') and now-int(i['listTime'])>=owner.cfg['selection']['min_listing_days']*86400000]
  from okx_kst_turnover import enabled as turnover_enabled,collect as turnover_collect
  turnover_rank=None
  if turnover_enabled(owner.cfg):
   try:
    turnover_rank=turnover_collect(self,instruments)
    ranked={r['symbol']:r for r in turnover_rank['rows']}
    instruments=[i for i in instruments if i['instId'] in ranked]
    for symbol,rank in ranked.items():by_symbol[symbol].update(rank)
   except Exception as error:
    value=dict(rows=[],completed=time.monotonic(),ms=now,whole_market=True,all_candidates=0,universe=len(instruments),selected_count=0,
     turnover_scope=True,turnover_ready=False,ranked_symbols=[],turnover_error=str(error))
    with owner.lock:owner.result=value
    return value
  total=len(instruments);processed=0
  def one(i):
   if owner.stop_event.is_set() or owner.search_paused.is_set():return None
   if not hasattr(worker,'api'):
    worker.api=OKX(owner.settings)
    with api_lock:apis.append(worker.api)
   frames={};hits={};q=by_symbol[i['instId']]
   from okx_research_entry import enabled as research_enabled
   for frame in (('5m','15m') if research_enabled(owner.cfg) else ('5m','15m','1H','4H')):
    try:
     b=self.bars(worker.api,i['instId'],frame)
     from okx_research_entry import enabled as research_enabled,basic as research_basic
     need=60 if research_enabled(owner.cfg) else max(owner.cfg['indicators']['ma_periods'])+owner.cfg['signals']['slope_bars']+3
     if len(b)<need:continue
     m=research_basic(b) if research_enabled(owner.cfg) else metrics(b,owner.cfg);frames[frame]=b
     if frame=='5m':
      jump=max(abs(x[4]/p[4]-1) for p,x in zip(b[-7:-1],b[-6:]))
      if jump>owner.cfg['selection']['max_bar_return'] or m['atr']/m['close']>owner.cfg['selection']['max_atr_fraction']:return None
     from okx_trend_entry import entry_evidence
     if not research_enabled(owner.cfg):
      h=entry_evidence(b,frame,m,owner.cfg)
      if h:hits[frame]=h
    except Exception:continue
   from okx_research_entry import enabled as research_enabled,setups as research_setups
   if research_enabled(owner.cfg):
    h,_=research_setups(frames,owner.cfg);hits={'5m':h} if h else {}
   if not hits or '5m' not in frames or '15m' not in frames:return None
   return dict(q,symbol=i['instId'],instrument=i,turnover=q.get('kst_turnover_usdt',0),activity={},bars5=frames['5m'],bars15=frames['15m'],higher={f:frames.get(f,[]) for f in ('1H','4H')},local_frames=frames,
    local_patterns=hits,observed_ms=worker.api.now_ms(),score=max(10-(worker.api.now_ms()-h['confirmed_ms'])/STEPS[f]+min(h['retracement_atr'],5)*.2 for f,hs in hits.items() for h in hs.values()))
  def publish(api):
   focus=[]
   for row in sorted(matched,key=lambda r:(-r['score'],r['symbol'])):
    if owner.stop_event.is_set() or owner.search_paused.is_set():break
    try:
     row=dict(row);symbol=row['symbol'];row['bars5']=self.bars(api,symbol,'5m');row['bars15']=self.bars(api,symbol,'15m')
     from okx_research_entry import enabled as research_enabled
     if not research_enabled(owner.cfg):row['higher']=dict(row['higher'],**{'1m':self.bars(api,symbol,'1m')})
     row.pop('local_frames',None);row['observed_ms']=api.now_ms();focus.append(row)
     if len(focus)>=15:break
    except Exception:continue
   value=dict(rows=focus,all_candidates=len(matched),universe=total,completed=time.monotonic(),ms=api.now_ms(),scan_seconds=round(time.monotonic()-started,1),filter_counts=dict(counts),selected_count=len(focus),whole_market=True,ranking_start_ms=api.now_ms()//86400000*86400000)
   if turnover_rank:
    value.update(turnover_scope=True,turnover_ready=True,ranked_symbols=[r['symbol'] for r in turnover_rank['rows']],
     turnover_start_ms=turnover_rank['start_ms'],turnover_observed_ms=turnover_rank['observed_ms'],turnover_universe=turnover_rank['universe'])
   with owner.lock:owner.result=value;self.progress=dict(processed=processed,total=total,patterns=len(matched),focus=len(focus),seconds=value['scan_seconds'])
   return value
  api=OKX(owner.settings)
  try:
   with ThreadPoolExecutor(max_workers=6) as pool:
    futures=[pool.submit(one,i) for i in instruments]
    for future in as_completed(futures):
     processed+=1
     try:r=future.result()
     except Exception:r=None;counts['scan_error']+=1
     if r:matched.append(r)
     if processed%20==0 or (r and len(matched)<=3):publish(api)
   return publish(api)
  finally:
   api.session.close()
   for a in apis:a.session.close()

def market_view(engine):
 source=engine.universe.market_read() if hasattr(engine.universe,'market_read') else None
 if not isinstance(source,dict):return dict(rows=[],progress={},error='전체 시세 준비 중')
 now=engine.api.now_ms();quotes=source['quotes']
 if hasattr(engine.stream,'monitor'):engine.stream.monitor(quotes.keys())
 for symbol,old in list(quotes.items()):
  live=engine.stream.read(symbol,'tickers',15,now)
  if isinstance(live,dict):
   # Never carry yesterday's09:00 reference into a new Korean session.
   if int(live.get('ts',0))//86400000==int(old.get('ts',0))//86400000:
    quotes[symbol]=dict(old,**live)
   elif live.get('sodUtc0'):quotes[symbol]=live
 rows=rank_quotes(quotes,now)
 for r in rows:r['source']='WS' if isinstance(engine.stream.read(r['symbol'],'tickers',15,now),dict) else 'REST'
 return dict(rows=rows,progress=source.get('progress',{}),error=source.get('error'),now_ms=now,ranking_start_ms=now//86400000*86400000)

"""Independent fixed-5x model decisions. All writes still use the journaled exchange engine."""
import copy,hashlib,math,time,uuid
from okx_core import BotError,dec
DEFAULTS=dict(enabled=True,entry_seconds=300,manage_seconds=300,batch_size=3,max_payload_chars=22000,decision_ttl_seconds=90,min_active_bar_fraction=.5)
from okx_pattern15 import INSTRUCTIONS
SCHEMA={'type':'object','properties':{
 'action':{'type':'string','enum':['WAIT','LONG','SHORT','HOLD','CLOSE','PARTIAL','ADD','TRAIL']},
 'symbol':{'type':'string'},'leverage':{'type':'integer','enum':[5,10,15,30]},
 'stop':{'type':'number'},'target':{'type':'number'},'margin_fraction':{'type':'number'},'close_fraction':{'type':'number'},
 'frame':{'type':'string','enum':['15m']},'target_mode':{'type':'string','enum':['fixed','review']},'reason':{'type':'string'}},
 'required':['action','symbol','leverage','stop','target','margin_fraction','close_fraction','frame','target_mode','reason'],'additionalProperties':False}
def enabled(c):return c.get('execution',{}).get('free_ai',{}).get('enabled',False)
def allowed(i,c):
 from okx_pattern15 import allowed as selected
 return selected(i,c)
def settings(c):return dict(DEFAULTS,**c.get('execution',{}).get('free_ai',{}))
def validate(p):return 0<=p.get('min_active_bar_fraction',.5)<=1 and type(p['enabled']) is bool and 300<=p['entry_seconds']<=3600 and 300<=p['manage_seconds']<=3600 and type(p['batch_size']) is int and 1<=p['batch_size']<=5 and 6000<=p['max_payload_chars']<=26000 and 30<=p['decision_ttl_seconds']<=180
def owned(o):return bool((o or {}).get('v4_signal',{}).get('free_ai'))
def packet(row,c,now,quote=None,swing_frame=None):
 from okx_pattern15 import packet as selected
 return selected(row,c,now,quote,swing_frame)
def response(out,mode,allowed_symbols):
 data={k:out[k] for k in SCHEMA['required'] if k in out}
 if set(data)!=set(SCHEMA['required']) or data['symbol'] not in allowed_symbols or type(data['leverage']) is not int or data['leverage'] not in (5,10,15,30) or data['frame']!='15m' or not isinstance(data['reason'],str) or not data['reason'].strip():raise BotError('AI 자율 응답 형식/종목/배율 검증 실패')
 if mode=='FREE_ENTRY' and data['leverage']!=10:raise BotError('신규 자동 진입은10배만 허용')
 actions=('LONG','SHORT','WAIT') if mode=='FREE_ENTRY' else ('HOLD','CLOSE','PARTIAL','ADD','TRAIL')
 if data['target_mode'] not in ('fixed','review'):raise BotError('AI 목표 관리 방식 오류')
 if data['action'] not in actions:raise BotError('AI 운용 단계에 맞지 않는 행동')
 for k in ('stop','target','margin_fraction','close_fraction'):
  if type(data[k]) not in (float,int) or not math.isfinite(data[k]):raise BotError('AI 가격/비율 수치 오류')
 if data['action']=='ADD' and not 0<data['margin_fraction']<=1:raise BotError('AI 추가 비율은 남은 추가 가능 증거금의 0초과~100%')
 if data['action'] in ('LONG','SHORT'):data['margin_fraction']=1/3
 if data['action']=='PARTIAL':data['close_fraction']=.5
 if data['action']=='PARTIAL' and not .1<=data['close_fraction']<=.9:raise BotError('AI 부분 청산 비율 오류')
 data['target_mode']='review'
 return data
def make_signal(out,p,c,now):
 from okx_pattern15 import make_signal as selected
 return selected(out,p,c,now)
def account_context(e,snap):
 owned_keys={(o['symbol'],o['direction']) for o in e.records()}
 positions=[dict(symbol=p.get('instId'),direction=p.get('posSide'),quantity=p.get('pos'),margin=p.get('imr'),unrealized=p.get('upl'),source='automatic' if (p.get('instId'),p.get('posSide')) in owned_keys else 'manual_external_read_only') for p in snap.get('positions',[]) if float(p.get('pos') or 0)!=0]
 return dict(initial_margin_policy='Current V732: size by structural-stop distance and fees/slippage; expected risk <=0.5% allocation, portfolio <=2%, single/gross notional <=1x/2x. Round DOWN; skip if below minimum. Existing SL and actual leverage remain. ADD disabled. Continuous24h; daily PnL does not pause entries.',equity=str(snap['equity']),available=str(snap['available']),allocation_seed=str(e.allocation_seed(snap)),margin_room=str(e.margin_room(snap)),positions=positions,positions_count=len(positions),manual_policy='Manual/external positions explain reserved margin; never manage them. Trade other symbols using verified remaining available funds only.',open_orders_count=len(snap.get('orders',[])))
def addition_budget(e,snap,o):
 seed=dec(o['entry_seed']);used=dec(o.get('committed_margin') or 0)
 remaining=max(dec(0),min(seed-used,e.margin_room(snap),dec(snap['available'])))
 return dict(remaining_add_margin_usdt=str(remaining),original_seed=str(seed),committed_margin=str(used),original_risk_budget=o.get('original_risk_budget'),current_estimated_stop_loss=o.get('estimated_loss'),fraction_basis='remaining_add_margin_usdt; engine reserves fees and enforces original risk/exposure before order',stop_must_not_widen=o['stop_px'])
def execution_context(e,row,snap):
 from okx_pattern15 import leverage
 from decimal import ROUND_DOWN
 i=row['instrument'];symbol=row['symbol'];lev=leverage(symbol)
 book=e.api.public('/api/v5/market/books',instId=symbol,sz='400')[0];now=e.api.now_ms()
 if not -500<=now-int(book['ts'])<=15000:raise BotError('최신 주문 호가 대기')
 if not book.get('asks') or not book.get('bids'):raise BotError('주문 호가 없음')
 ask=dec(book['asks'][0][0]);ct=dec(i['ctVal']);lot=dec(i['lotSz']);minimum=dec(i['minSz'])
 cap=e.allocation_seed(snap)/3
 if dec(snap['available'])<cap or e.margin_room(snap)<cap:raise BotError('시드 1/3 고정 증거금 부족 · 유료 호출 생략')
 qty=(cap*lev/(ask*ct)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
 if qty<minimum:raise BotError('실제 증거금으로 최소 주문 미달')
 return dict(observed_ms=now,required_leverage=lev,contract_value=str(ct),minimum_contracts=str(minimum),max_affordable_contracts=str(qty),max_initial_margin_usdt=str(cap),policy='실제 잔고/최소 주문 확인; 비용·손익비 심사 없음')
def entry_fingerprint(p):
 import json
 # Closed observations identify a decision; ticker noise does not justify a paid repeat.
 values=dict(symbol=p['symbol'],frames={k:v.get('completed_ms') for k,v in p.get('frames',{}).items()},setups=[{k:v.get(k) for k in ('setup','action','test_ms','confirmation_ms','structural_stop','target')} for v in p.get('entry_setups',[])])
 return hashlib.sha256(json.dumps(values,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def reviewable_setups(p):
 from okx_structure694 import entry_window
 price=float(p['price'])
 return [v for v in p.get('entry_setups',[]) if (price-float(v['structural_stop']))*(1 if v['action']=='LONG' else -1)>0 and entry_window(v,price)]

def call(e,payload,epoch,channel):
 from okx_model_runtime import request
 from okx_case_lessons import GUIDANCE
 return request(e,payload,INSTRUCTIONS,SCHEMA,channel,epoch)
def jobs(e):
 if not hasattr(e,'free_jobs'):e.free_jobs={}
 return e.free_jobs
def schedule(e,key,payload,seconds,channel):
 from okx_channel701 import enabled
 if enabled(e.cfg):raise BotError("규칙 전용 모드: 유료 AI 호출 차단")
 import json
 if key=='ENTRY' and not e.can_open_position():return False
 now=e.api.now_ms();pending=jobs(e)
 nexts=e.journal.data.setdefault('free_ai_next',{})
 if key in pending or now<nexts.get(key,0):return False
 if not e.settings.get('OPENAI_API_KEY'):raise BotError('AI 자율형은 OPENAI_API_KEY가 필요합니다.')
 from okx_payload import prepare
 wire,stats=prepare(payload,settings(e.cfg)['max_payload_chars'])
 if wire is None:
  # Oversize is a local preflight WAIT, not an account/order recovery error.
  nexts[key]=now+30000
  if key=='ENTRY':
   e.journal.data['free_ai_cursor']=e.journal.data.get('free_ai_cursor',0)+max(1,len(payload.get('candidates',[])))
   e.journal.data['free_ai_last_batch']=[v['symbol'] for v in payload.get('candidates',[])]
  e.journal.save()
  e.pipeline('preflight_rejected','AI 자료 요약 후에도 한도 초과 / '+str(stats['after'])+'자 / 유료 호출 없음·30초 후 재검토')
  return False
 symbols={v['symbol'] for v in wire.get('candidates',[])}
 payload=dict(payload,candidates=[v for v in payload.get('candidates',[]) if v['symbol'] in symbols])
 if stats['compacted']:e.log('AI 자료 요약 / '+str(stats['before'])+' → '+str(stats['after'])+'자 / 원본 차트·학습 기록 보존')
 nexts[key]=now+seconds*1000;e.journal.save()
 pending[key]=dict(future=e.approval_pool.submit(call,e,wire,e.epoch,channel),epoch=e.epoch,ms=now,payload=payload)
 e.pipeline('ai_pending','AI 분석 요청 중·아직 승인 아님 / 종목별 배율 / '+', '.join(p['symbol'] for p in payload['candidates']),count='ai_requests');return True
def take(e,key):
 job=jobs(e).get(key)
 if not job:return None
 if not job['future'].done():
  age=e.api.now_ms()-job['ms']
  e.pipeline('ai_pending',key+' / AI 응답 대기 '+str(int(age/1000))+'초')
  if age>120000:
   job['discard']=True
   # A running request may still be charged. Never duplicate it or reset its reserve.
   if job['future'].cancel():jobs(e).pop(key,None)
   e.pipeline('preflight_rejected',key+' / AI 작업 120초 초과·만료 처리 / 중복 호출 없이 기존 요청 종료 대기')
  return None
 jobs(e).pop(key)
 out=job['future'].result()
 if job.get('discard'):raise BotError('장시간 지연 AI 결과 폐기·다음 검토에서 재개')
 if job['epoch']!=e.epoch or e.recovering or (e.entry_cancel.is_set() and not (key!='ENTRY' and getattr(e,'mobile_entry_pause',False))):
  e.journal.data['free_ai_next'][key]=e.api.now_ms()+30000;e.journal.save();raise BotError('AI 판단 도중 계정/연결 상태 변경·주문 없음')
 if e.api.now_ms()-job['ms']>settings(e.cfg)['decision_ttl_seconds']*1000:raise BotError('AI 자율 판단 만료·주문 없음')
 parsed=response(out,job['payload']['mode'],[p['symbol'] for p in job['payload']['candidates']])
 import json
 with (e.root/'free_ai_decisions.jsonl').open('a',encoding='utf-8') as log:log.write(json.dumps(dict(ms=e.api.now_ms(),mode=job['payload']['mode'],decision=parsed,lesson_revision=694),ensure_ascii=False)+'\n')
 return parsed,job
def ranking_score(row,c,now):
 from okx_case_lessons import observe
 activity=0.;pattern=False;volume_wick=False
 for frame,step in (('5m',300000),('15m',900000)):
  bars=[r for r in row.get('live_frames',{}).get(frame,[]) if r[0]+step<=now]
  if len(bars)<21 or not 0<=now-(bars[-1][0]+step)<step:continue
  mean=sum(r[5] for r in bars[-21:-1])/20
  activity=max(activity,min(10,bars[-1][5]/mean if mean>0 else 0))
  hints=observe(bars,c['indicators']['bb_period'],c['indicators']['bb_multiplier'],c['execution'].get('chart_lessons',{}))
  recent=hints.get('candles',[])[-1:]
  pattern=pattern or any(x.get('lower_rejection') or x.get('upper_rejection') for x in recent) or any(hints.get(k) for k in ('failed_low_recovery','failed_high_rejection','support_pullback_recovery','resistance_pullback_rejection')) or any(hints.get(k,{}).get('reversal_held') or hints.get(k,{}).get('trend_pullback_held') for k in ('sequence_support_long','sequence_resistance_short'))
  wick=hints.get('volume_wick',{});volume_wick=volume_wick or wick.get('long_candidate') or wick.get('short_candidate')
 return activity+(3 if pattern else 0)+(3 if volume_wick else 0)

def rotate_reviewed(rows,previous):
 recent=set(previous)
 return [r for r in rows if r['symbol'] not in recent]+[r for r in rows if r['symbol'] in recent]

def migrate_schedule(e):
 if e.journal.data.get('cadence_revision_v666')==1:return
 now=e.api.now_ms()
 due=e.journal.data.setdefault('free_ai_next',{})
 for key in due:due[key]=min(due[key],now+300000)
 e.journal.data['cadence_revision_v666']=1;e.journal.save()

def monitor_double_patterns(e,result,now):
 if now-getattr(e,'_double_monitor_ms',-10000)<10000:return
 e._double_monitor_ms=now;rows=result.get('rows',[]);cursor=getattr(e,'_double_monitor_cursor',0)%max(1,len(rows));chosen=(rows[cursor:]+rows[:cursor])[:40];e._double_monitor_cursor=cursor+40
 cache={k:v for k,v in getattr(e,'_double_monitor_cache',{}).items() if now-v['confirmed_ms']<1800000}
 for row in chosen:
  try:p=packet(row,e.cfg,now)
  except (BotError,ValueError):continue
  cache.pop(row['symbol'],None)
  if p['entry_setups']:cache[row['symbol']]=dict(symbol=row['symbol'],confirmed_ms=p['frames']['15m']['completed_ms'],priority=min(v['priority'] for v in p['entry_setups']))
 e._double_monitor_cache=cache

def candidate(e):
 from okx_channel701 import enabled,candidate as rules_candidate
 if enabled(e.cfg):return rules_candidate(e)
 import json
 now=e.api.now_ms()
 if not e.can_open_position():e.pipeline('holding','2개 보유 · 신규 탐색/신규 AI 호출 중지 · 보유 관리 계속');return None
 if e.preview:return None
 migrate_schedule(e)
 live={o['client_id'] for o in e.records()}
 for key in list(jobs(e)):
  if key!='ENTRY' and key not in live and jobs(e)[key]['future'].done():jobs(e).pop(key)
 try:ready=take(e,'ENTRY')
 except Exception as err:e.pipeline('preflight_rejected',str(err));return None
 if ready:
  out,job=ready
  # Preserve observations and verdict together for later outcome evaluation; no keys/account data.
  with (e.root/'entry_review_evidence.jsonl').open('a',encoding='utf-8') as audit:
   audit.write(json.dumps(dict(ms=now,revision=694,decision=out,candidates=job['payload']['candidates']),ensure_ascii=False)+'\n')
  if out['action']=='WAIT':
   reviewed=e.journal.data.setdefault('entry_wait_reviews699',{})
   for candidate in job['payload']['candidates']:reviewed[candidate['symbol']]=entry_fingerprint(candidate)
   if len(reviewed)>500:
    for symbol in list(reviewed)[:-500]:reviewed.pop(symbol,None)
   e.log('AI 판단 결과 / 대기 / '+out['symbol']+' / '+out['reason'])
   e.notify('AI 진입 대기',out['symbol']+' / '+out['reason'],state=out['symbol']+':'+out['reason'])
   e.journal.data['free_ai_followup']=dict(symbol=out['symbol'],reason=out['reason'][:500],ms=now);e.journal.save()
   e.pipeline('signal_wait','AI 자율 대기: '+out['reason'],count='ai_wait');return None
  p=next(p for p in job['payload']['candidates'] if p['symbol']==out['symbol'])
  try:s=make_signal(out,p,e.cfg,now)
  except BotError as error:
   e.pipeline('preflight_rejected',out['symbol']+' / '+str(error))
   e.notify('AI 진입 대기',out['symbol']+' / '+str(error),state=out['symbol']+':'+str(error))
   with (e.root/'entry_structure_audit.jsonl').open('a',encoding='utf-8') as audit:audit.write(json.dumps(dict(ms=now,symbol=out['symbol'],action=out['action'],approved=False,reason=str(error)),ensure_ascii=False)+'\n')
   return None
  with (e.root/'entry_structure_audit.jsonl').open('a',encoding='utf-8') as audit:audit.write(json.dumps(dict(ms=now,symbol=s['symbol'],action=s['action'],approved=True,plan=s['decision_record'].get('structural_wave_plan')),ensure_ascii=False)+'\n')
  if s['decision_record'].get('structural_wave_plan'):e.log('진입 구조 계획 / '+s['symbol']+' / '+s['decision_record']['structural_wave_plan']['summary'])
  e.band_focus=s['symbol'];e.stream.watch([s['symbol']]+[r['symbol'] for r in e.records()]+e.chat.watch())
  s['entry_guard_execution']=p.get('execution',{})
  e.free_ready=s
 if getattr(e,'free_ready',None):
  s=e.free_ready
  if now>s['expires_ms']:e.log('AI 진입 결정 만료 / '+s['symbol']+' / 주문 없음');e.free_ready=None;return None
  if not e.stream.ready(s['symbol'],e.cfg,now):
   missing=e.stream.missing(s['symbol'],e.cfg,now)
   e.pipeline('signal_wait',s['symbol']+' / AI 진입 결정 후 실시간 자료 대기 / 누락·지연: '+', '.join(missing));return None
  quote=e.stream.read(s['symbol'],'tickers',e.cfg['liquidity']['ws_max_age_seconds'],now)
  if not quote or not quote.get('last'):
   e.pipeline('signal_wait',s['symbol']+' / 최신 현재가 수신 대기·주문 없음');return None
  from okx_pattern15 import check_entry
  try:check_entry(e,s,float(quote['last']))
  except BotError as error:e.free_ready=None;e.pipeline('preflight_rejected',str(error));return None
  e.notify('AI 승인',s['symbol']+' / 종목별 배율 / '+s['reason']+' / 손절 '+str(s['stop'])+' / 목표 '+str(s['target'])+' / 최종 주문 점검 대기',state=s['signal_id'])
  e.free_ready=None;e.pipeline('approved',s['symbol']+' / '+s['reason'],count='signals');return s
 result,_=e.universe.read()
 if not result:e.pipeline('scan','후보 자료 수신 대기·AI 호출 없음');return None
 monitor_double_patterns(e,result,now)
 if 'ENTRY' in jobs(e):return None
 if now<e.journal.data.get('free_ai_next',{}).get('ENTRY',0):
  e.pipeline('signal_wait','다음 신규 검토까지 '+str(max(0,int((e.journal.data['free_ai_next']['ENTRY']-now)/1000)))+'초');return None
 snap=e.snapshot();e.risk_snapshot(snap)
 available=[r for r in result.get('rows',[]) if allowed(r['instrument'],e.cfg) and r['symbol'] not in e.blocked_manual_symbols() and not any(o['symbol']==r['symbol'] for o in e.records())]
 e.stream.monitor([r['symbol'] for r in available]);packets=[]
 from okx_online_learning import refresh,annotate
 try:learning=refresh(e)
 except Exception:learning=dict(groups={},accepted_trades=0)

 offset=e.journal.data.get('free_ai_cursor',0)%max(1,len(available));ordered=available[offset:]+available[:offset]
 priority={v['symbol'] for v in getattr(e,'_double_monitor_cache',{}).values()}
 leaders=sorted(available,key=lambda row:(row['symbol'] in priority,abs(float(row.get('change') or 0))),reverse=True)[:max(0,settings(e.cfg)['batch_size']-1)]
 chosen={r['symbol'] for r in leaders};ordered=leaders+[r for r in ordered if r['symbol'] not in chosen]
 follow=e.journal.data.get('free_ai_followup',{})
 # WAIT is context, not a permanent first-place reservation.
 ordered=rotate_reviewed(ordered,e.journal.data.get('free_ai_last_batch',[]))
 blocked=[]
 for row in ordered[:12]:
  quote=e.stream.read(row['symbol'],'tickers',15,now)
  if not quote:continue
  try:
   value=packet(row,e.cfg,now,quote)
   initial_candidates=bool(value['entry_setups'])
   value['entry_setups']=reviewable_setups(value)
   if initial_candidates and not value['entry_setups']:value['frames']['15m']['entry_diagnostic']='현재가가 확인 진입 구간/구조 SL 이탈 · 추격 검토 유료 호출 생략'
   if e.journal.data.get('entry_wait_reviews699',{}).get(value['symbol'])==entry_fingerprint(value):
    blocked.append(row['symbol']+' / 동일 완료봉 AI 대기 판단 유지 · 새 봉 확인까지 호출 생략');continue
   e.events.put(('timeframes',dict(symbol=value['symbol'],frames={f:v['analysis'] for f,v in value['frames'].items()})))
   if not value['entry_setups']:
    blocked.append(row['symbol']+' / '+value['frames']['15m'].get('entry_diagnostic','15분봉 구조·반응 확인 대기'));continue
   from okx_structure694 import learning_adjust
   value['_learned_priority']=learning_adjust(value,learning,e.cfg)
   value['execution']=execution_context(e,row,snap)
   if row['symbol']==follow.get('symbol'):value['previous_wait']=dict(reason=follow['reason'],ms=follow['ms'])
  except Exception as err:
   blocked.append(row['symbol']+' / '+str(err));continue
  if packets and len(json.dumps(packets+[value],ensure_ascii=False,separators=(',',':')))>settings(e.cfg)['max_payload_chars']-1800:break
  packets.append(value)
  if len(packets)>=max(settings(e.cfg)['batch_size'],6):break
 if not packets:
  e.journal.data['free_ai_cursor']=offset+12;e.journal.save()
  why=' | '.join(blocked[:3]) or '최신 OHLCV/시세 준비 중'
  e.pipeline('preflight_rejected','유료 AI 호출 생략 / '+why);return None
 # Preserve one rotating candidate for exploration; remaining slots favor learned outcomes.
 limit=settings(e.cfg)['batch_size'];explore=packets[-1]
 ranked=sorted(packets,key=lambda p:(p['_learned_priority'],min(v['priority'] for v in p['entry_setups'])*-1,max(v.get('evidence_score',0) for v in p['entry_setups'])),reverse=True)
 packets=ranked[:limit]
 if limit>1 and explore not in packets:packets[-1]=explore
 for p in packets:p.pop('_learned_priority',None)
 e.log('자동학습 참고 / 확정 표본 '+str(learning.get('accepted_trades',0))+'건 / 후보 '+', '.join(p['symbol'] for p in packets))
 snap=e.snapshot();e.risk_snapshot(snap)
 payload=dict(mode='FREE_ENTRY',candidates=packets,account=account_context(e,snap),leverage_policy='ALL_NEW_ENTRIES_10X; existing positions keep their actual leverage')
 # Warm all execution channels while the paid decision is running.
 e.stream.watch([p['symbol'] for p in packets]+[o['symbol'] for o in e.records()]+e.chat.watch())
 if schedule(e,'ENTRY',payload,settings(e.cfg)['entry_seconds'],'auto_entry'):
  e.journal.data['free_ai_cursor']=offset+1;e.journal.data['free_ai_last_batch']=[p['symbol'] for p in packets];e.journal.save()
 return None
def context(e,symbol,action):
 s=e.executing_signal
 if not s or not s.get('free_ai') or s['symbol']!=symbol or s['action']!=action or e.api.now_ms()>s['expires_ms']:raise BotError('AI 자율 확정 신호 불일치/만료')
 e.prepared_signal=copy.deepcopy(s);e.signal_prepared_monotonic=time.monotonic()
 return dict(_v4=e.prepared_signal)

def notify_management(e,p,o,out):
 """One message for a changed model decision, never an execution acknowledgement."""
 import json
 fields={k:out.get(k) for k in ('action','reason','stop','target','target_mode','margin_fraction','close_fraction')}
 signature=hashlib.sha256(json.dumps(fields,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
 if o.get('management_notice_signature')==signature:return
 labels={'HOLD':'보유 유지','ADD':'추가 진입 검토','PARTIAL':'부분 청산 판단','CLOSE':'전량 청산 판단','TRAIL':'보호 손절 조정 판단'}
 title=labels.get(out['action'],out['action'])
 text=o['symbol']+' / '+('롱' if o['direction']=='long' else '숏')+' / AI '+out['action']+' · '+title+'\n'+out['reason']
 text+='\n현재가 '+str(p.get('markPx','미확인'))+' / ROE '+str(round(float(p['uplRatio'])*100,2))+'%' if p.get('uplRatio') not in (None,'') else '\n현재가 '+str(p.get('markPx','미확인'))
 text+='\n현재 보호 SL '+str(o.get('stop_px','미확인'))+' / 목표(재평가) '+str(o['holding_rule'].get('target') or '미설정')
 if out['action']=='TRAIL':text+=' / 제안 SL '+str(out['stop'])
 text+='\nAI 판단 알림입니다. 주문·보호 주문 변경의 체결/성공 확인과 구분하세요.'
 e.notify('AI 보유 판단',text,state=o['client_id']+':'+signature)
 o['management_notice_signature']=signature;e.journal.save()

def manage(e,snap,p,o):
 from okx_channel701 import enabled,management as rules_manage
 if enabled(e.cfg):return rules_manage(e,snap,p,o)
 from okx_pattern15 import management
 if management(e,snap,p,o):return
 from okx_trade_quality import context as quality_context
 if not o.get('quality_context'):
  signal=o.get('v4_signal',{});frames=signal.get('decision_record',{}).get('frames',{})
  o['quality_context']=quality_context(frames,signal.get('setup_frame'),p.get('avgPx'),signal.get('stop'),o['direction'])
 q=o.get('quality_context',{})
 if q:
  move=(float(p['markPx'])-q['entry'])*(1 if o['direction']=='long' else -1)/q['atr']
  ex=o.setdefault('observed_excursion',dict(samples=0,favorable_atr=0.,adverse_atr=0.))
  ex.update(samples=ex['samples']+1,favorable_atr=max(ex['favorable_atr'],move),adverse_atr=max(ex['adverse_atr'],-move));o['last_quality_mark']=p['markPx']
 migrate_schedule(e)
 key=o['client_id'];now=e.api.now_ms()
 # Migrate pre-update owned positions too; never remove protective stops.
 if o['holding_rule'].get('target_mode')!='review':
  o['holding_rule']['target_mode']='review';e.journal.save()
  e.log(o['symbol']+' / 목표가를 AI 재평가 구간으로 전환 · 보호 손절 유지')
 # Old persisted 30-minute due times are capped once to the new review interval.
 if o.get('review_revision_v654')!=1:
  due=e.journal.data.setdefault('free_ai_next',{});due[key]=min(due.get(key,now),now+settings(e.cfg)['manage_seconds']*1000)
  o['review_revision_v654']=1;e.journal.save()
 try:ready=take(e,key)
 except Exception as err:e.log('AI 보유 대기: '+str(err));return
 if ready:
  out,job=ready;out=dict(out);action=out['action']
  from okx_structure694 import corroborate_management
  out=corroborate_management(out,p,o,e.cfg);action=out['action']
  if action=='TRAIL':
   old=float(o['stop_px']);mark=float(p['markPx']);side=1 if o['direction']=='long' else -1
   if (out['stop']-old)*side<=0 or (mark-out['stop'])*side<=0:out.update(action='HOLD',stop=0,reason='기존 SL 확대/현재가 교차 금지')
   action=out['action']
  try:
   import json
   with (e.root/'management_review_evidence.jsonl').open('a',encoding='utf-8') as audit:
    audit.write(json.dumps(dict(ms=now,revision=684,symbol=o['symbol'],requested=ready[0],applied=out,entry_frame=o.get('v4_signal',{}).get('setup_frame'),current_stop=o['stop_px']),ensure_ascii=False)+'\n')
  except OSError:e.log(o['symbol']+' / 보유 판단 기록 저장 실패 · 보호·매매 관리 계속')
  if not e.cfg['execution'].get('structure694') and out['target']>0 and (out['target']-float(p['avgPx']))*(1 if o['direction']=='long' else -1)>0:
   o['holding_rule'].update(target=out['target'],target_mode='review');o['v4_signal']['target']=out['target'];e.journal.save()
  e.log(o['symbol']+' / AI '+action+' / '+out['reason'])
  try:notify_management(e,p,o,out)
  except Exception:e.log(o['symbol']+' / AI 보유 판단 알림 준비 실패 · 매매 관리는 계속합니다')
  if action=='CLOSE':e.close(snap,'AI 자율 청산: '+out['reason']);return
  if action=='PARTIAL':e.partial_close(snap,'AI 자율 부분 청산: '+out['reason'],fraction=.5);return
  if action=='TRAIL':
   old=float(o['stop_px']);mark=float(p['markPx']);side=1 if o['direction']=='long' else -1
   if (out['stop']-old)*side<=0 or (mark-out['stop'])*side<=0:raise BotError('AI SL 확대/현재가 교차 차단')
   e.trail(snap,p,o,out['stop']);return
  if action=='ADD' and e.enabled and not e.cfg['execution'].get('structure694'):
   observations=next((v for v in job.get('payload',{}).get('candidates',[]) if v.get('symbol')==o['symbol']),{})
   if not any(v.get('action')==('LONG' if o['direction']=='long' else 'SHORT') for v in observations.get('entry_setups',[])):return
   if dec(addition_budget(e,snap,o)['remaining_add_margin_usdt'])<=0:
    e.log(o['symbol']+' / AI 추가 진입 생략: 남은 가용 증거금 없음');return
   o['free_add_decision']=dict(out,issued_ms=now,id=uuid.uuid4().hex[:16]);e.journal.save()
   e.scale('ADD_AVERAGE');return
 if not e.recovering and (not e.entry_cancel.is_set() or getattr(e,'mobile_entry_pause',False)):
  if key in jobs(e) or now<e.journal.data.get('free_ai_next',{}).get(key,0):return
  frames=e.chart_job(o['symbol']) or {}
  # chart_job returns completed OHLCV; the packet needs no live candle or local trigger.
  row=dict(symbol=o['symbol'],instrument={'instCategory':o.get('selection',{}).get('asset_category','1')},live_frames=frames)
  try:value=packet(row,e.cfg,now,{'last':p['markPx']},swing_frame=o.get('v4_signal',{}).get('setup_frame') or o['holding_rule'].get('frame'))
  except BotError:return
  e.events.put(('timeframes',dict(symbol=o['symbol'],frames={f:v['analysis'] for f,v in value['frames'].items()})))
  payload=dict(mode='FREE_MANAGE',candidates=[value],addition_budget=addition_budget(e,snap,o),position=dict(symbol=o['symbol'],direction=o['direction'],quantity=p['pos'],entry=p['avgPx'],mark=p['markPx'],price_return_from_average=(float(p['markPx'])/float(p['avgPx'])-1)*(1 if o['direction']=='long' else -1),liquidation_price=p.get('liqPx'),roe=p['uplRatio'],stop=o['stop_px'],margin=o['committed_margin'],cost_rate=o.get('cost_rate'),estimated_stop_loss=o.get('estimated_loss'),target=o['holding_rule'].get('target',o['v4_signal'].get('target')),target_mode='review',target_reached=(float(p['markPx'])-float(o['holding_rule'].get('target') or o['v4_signal'].get('target') or p['markPx']))*(1 if o['direction']=='long' else -1)>=0,realized_pnl=p.get('realizedPnl'),leverage=int(o['leverage'])),account=account_context(e,snap))
  from okx_trade_context import position_context
  payload['management_context']=position_context(p,o)
  payload['management_context']['new_and_add_entries_paused']=bool(getattr(e,'mobile_entry_pause',False))
  schedule(e,key,payload,settings(e.cfg)['manage_seconds'],'auto_manage')
def addition(o,p,c,now):
 from okx_channel701 import enabled
 if enabled(c):return False
 d=o.get('free_add_decision') or {};side=1 if o['direction']=='long' else -1
 return bool(not c['execution'].get('structure694') and owned(o) and d and 0<=now-d.get('issued_ms',0)<=settings(c)['decision_ttl_seconds']*1000 and not o.get('pending_add') and (float(p['markPx'])-float(o['stop_px']))*side>0)


def execution_watch_symbols(e,base):
 """Keep execution subscriptions alive across engine ticks while AI/pending entry runs."""
 symbols=list(base)
 click=getattr(e,'click_pending716',None)
 if click:symbols.append(click['symbol'])
 symbols.extend(getattr(e,'channel_pending',{}))
 # jobs() owns the actual pending dictionary; avoid creating it on read-only callers.
 pending=jobs(e)
 job=pending.get('ENTRY',{})
 symbols.extend(p['symbol'] for p in job.get('payload',{}).get('candidates',[]))
 ready=getattr(e,'free_ready',None)
 if ready:symbols.append(ready['symbol'])
 return list(dict.fromkeys(symbols))

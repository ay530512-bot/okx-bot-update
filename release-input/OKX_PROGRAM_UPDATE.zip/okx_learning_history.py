"""Persistent KST learning updates, not invented narrative or trading instructions."""
import json,math
from pathlib import Path
from datetime import datetime,timezone,timedelta
KST=timezone(timedelta(hours=9))
LABELS={'band_double':'확인 쌍바닥·쌍고점','ma_retest':'추세 이평 재시험 확인','impulse_retest':'장대봉 눌림 회복 확인','manual_unclassified':'수동 진입·새 패턴 미분류(통계 순위 제외)','role_flip_retest':'지지·저항 역할 전환 재시험','ma_zone_retest':'이평선 구간 반등·눌림 재시험','volume_wick':'거래량 동반 꼬리 반전','ma200_pullback':'MA200 돌파 눌림','trend_ma_retest':'추세 이평 지지·저항','failed_extreme_recovery':'고점·저점 돌파 실패','sequence_held_retest':'연속 지지·저항 재시험','breakout_retest':'돌파 후 재시험'}
def load(root):
 try:
  d=json.loads((Path(root)/'learning_daily_history.json').read_text(encoding='utf-8'))
  if not isinstance(d.get('days'),dict) or not isinstance(d.get('seen'),list):raise ValueError()
  return d
 except (OSError,ValueError,TypeError,AttributeError):return dict(days={},seen=[])

def record(root,rows,state,now_ms):
 data=load(root);seen=set(data['seen']);day=datetime.fromtimestamp(now_ms/1000,KST).strftime('%Y-%m-%d');changed=False
 for row in rows:
  source=row.get('source');meta=row.get('learning') or {};identity=row.get('client_id')
  if source not in ('auto','manual') or not identity or not meta.get('setup'):continue
  import hashlib
  assessment=row.get('quality_analysis',{})
  revision=hashlib.sha256(json.dumps(assessment,sort_keys=True,ensure_ascii=False).encode()).hexdigest()[:12]
  token=source+':'+identity+':'+revision
  if token in seen:continue
  try:
   pnl=float(row['realizedPnl']);risk=float(row['estimated_loss'])
   if not math.isfinite(pnl) or not math.isfinite(risk) or risk<0 or (risk==0 and source!='manual'):continue
  except (KeyError,TypeError,ValueError):continue
  name=('manual|' if source=='manual' else '')+'|'.join(str(v) for v in (meta['setup'],meta.get('frame'),row.get('direction')))
  group=state.get('groups694',{}).get(('manual|' if source=='manual' else '')+meta.get('key694',''),state.get('groups',{}).get(name,{}))
  item=dict(risk_missing=not row.get('learning_risk_usdt'),quality_analysis=assessment,id=identity,symbol=row.get('symbol') or '종목 미기록',setup=meta['setup'],frame=meta.get('frame'),direction=row.get('direction'),net_pnl=pnl,recorded_ms=now_ms,closed_ms=row.get('end_ms'),samples=group.get('samples',0),priority=group.get('priority_adjustment',0),ready=group.get('ready',False))
  data['days'].setdefault(day,{'auto':[],'manual':[]})[source].append(item);seen.add(token);changed=True
 if changed:
  data['seen']=sorted(seen);path=Path(root)/'learning_daily_history.json';tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');tmp.replace(path)
 return data

def day_view(root,day,source):
 if source not in ('auto','manual'):raise ValueError('invalid source')
 data=load(root);items=data['days'].get(day,{}).get(source,[])
 return dict(date=day,source=source,dates=sorted(data['days'],reverse=True),count=len(items),items=list(reversed(items)))

def describe(item):
 direction={'long':'롱','short':'숏'}.get(item.get('direction'),'방향 미확인')
 label=LABELS.get(item.get('setup'),item.get('setup','구조 미확인'))
 outcome='수익' if item['net_pnl']>0 else '손실' if item['net_pnl']<0 else '본전'
 effect=('우선순위 상향' if item['priority']>0 else '우선순위 하향' if item['priority']<0 else '우선순위 유지') if item['ready'] else '표본 축적 중 · 20건 전 가중치 미적용'
 if item.get('risk_missing'):effect='초기 구조 위험액 미기록 · R 가중치 제외 · 품질 피드백은 유지'
 quality= '\n'.join(item.get('quality_analysis',{}).get('notes',[]))
 return f"{item['symbol']} · {item.get('frame','')} {direction}\n{label} / 확정 {outcome} {item['net_pnl']:+.2f} USDT\n유형 누적 {item['samples']}건 · {effect}\n{quality}"

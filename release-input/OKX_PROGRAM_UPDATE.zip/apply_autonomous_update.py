"""Explicit autonomous mode opt-in launcher. No network/orders/state or secrets changed."""
import json,os,shutil,socket,tempfile
from pathlib import Path
from apply_adaptive_update import configure
from okx_autonomous import DEFAULTS
from okx_rules import load_config

def autonomous_config(data):
 data=configure(data);data['risk']['max_positions']=2;data['version']='6.97-free5-multi-exchange'
 from okx_double_retest import DEFAULTS as RETEST
 if data['execution'].get('double_retest_revision_v636',0)<1:
  data['signals']['double_retest']=dict(RETEST)
  data['execution']['double_retest_revision_v636']=1
 data['execution'].setdefault('autonomous_scalp',dict(DEFAULTS))
 for key,value in DEFAULTS.items():data['execution']['autonomous_scalp'].setdefault(key,value)
 data['execution']['autonomous_scalp']['enabled']=True
 from okx_swing_context import DEFAULTS as SWING_DEFAULTS
 data['signals'].setdefault('swing_context',dict(SWING_DEFAULTS))
 from okx_model_runtime import DEFAULTS as MODEL_DEFAULTS
 data['execution'].setdefault('model_runtime',dict(MODEL_DEFAULTS))
 from okx_budget_pacing import DEFAULTS as PACING_DEFAULTS
 data['execution']['budget_pacing']=dict(PACING_DEFAULTS)
 data['execution']['model_runtime']['max_daily_budget']=6.
 if data['execution'].get('pacing_revision_v621',0)<1:
  data['execution']['autonomous_scalp'].update(entry_interval_seconds=600,urgent_interval_seconds=600,manage_interval_seconds=900)
  data['execution']['pacing_revision_v621']=1
 if data['execution'].get('pacing_revision_v622',0)<1:
  data['execution']['autonomous_scalp'].update(entry_interval_seconds=900,urgent_interval_seconds=900,manage_interval_seconds=1800)
  data['execution']['pacing_revision_v622']=1
 from okx_wave_mode import DEFAULTS as WAVE_DEFAULTS
 data['signals'].setdefault('wave_mode',dict(WAVE_DEFAULTS))
 if data['execution'].get('wave_revision_v623',0)<1:
  data['risk']['min_reward_risk']=max(2.,data['risk']['min_reward_risk'])
  data['execution']['wave_revision_v623']=1
 from okx_trend_entry import DEFAULTS as TREND_DEFAULTS
 data['signals'].setdefault('trend_entry',dict(TREND_DEFAULTS))
 from okx_dynamic_exit import DEFAULTS as EXIT_DEFAULTS
 data['risk'].setdefault('dynamic_exit',dict(EXIT_DEFAULTS))
 if data['execution'].get('dynamic_exit_revision_v630',0)<1:
  data['signals']['trend_entry'].update(touch_atr=.75,reclaim_atr=.2,slope_atr=.01,impulse_atr=.2,structure_tolerance_atr=.6,close_location=.4,touch_bars=4,double_zone_atr=.7,double_minimum_swing_atr=.25,double_progress_atr=.03,stop_buffer_atr=.8)
  data['signals']['wave_mode']['stop_buffer_atr']=.8
  data['risk']['profit_review_roe']=.10
  data['execution']['dynamic_exit_revision_v630']=1
 if data['execution'].get('reward_risk_revision_v631',0)<1:
  data['risk']['min_reward_risk']=1.
  data['signals']['wave_mode']['min_net_reward_risk']=1.
  data['execution']['reward_risk_revision_v631']=1
 if data['execution'].get('read_efficiency_revision_v637',0)<1:
  data['risk']['min_reward_risk']=.4
  data['signals']['wave_mode']['min_net_reward_risk']=.4
  data['execution']['read_efficiency_revision_v637']=1
 if data['execution'].get('structure_runner_revision_v638',0)<1:
  data['risk']['dynamic_exit'].update(enabled=True,partial_fraction=.35,trail_buffer_atr=.8)
  data['risk']['min_reward_risk']=1.2
  data['signals']['wave_mode'].update(frames=['5m'],min_net_reward_risk=1.2)
  data['execution']['structure_runner_revision_v638']=1
 if data['execution'].get('kst_turnover_revision_v639',0)<1:
  from okx_kst_turnover import DEFAULTS as KST_TURNOVER
  data['selection']['kst_turnover']=dict(KST_TURNOVER)
  data['execution']['kst_turnover_revision_v639']=1
 data['execution']['whole_market']=True
 data['selection']['rest_requests_per_second']=min(6,data['selection']['rest_requests_per_second'])
 data['execution']['continuous_trading']=True
 data['execution']['ai_confirmation']=True
 from okx_research_entry import DEFAULTS as RESEARCH,settings as research_settings,enabled as research_enabled
 if data['execution'].get('research_entry_revision_v640',0)<1:
  data['signals']['research_entry']=dict(RESEARCH)
  data['execution']['research_entry_revision_v640']=1
 if research_enabled(data):
  research=research_settings(data)
  data['execution']['ai_confirmation']=False
  data['execution']['autonomous_scalp']['enabled']=False
  data['signals']['double_retest']['enabled']=False
  data['signals']['trend_entry']['enabled']=False
  data['signals']['support_entries']['enabled']=False
  data['signals']['wave_mode']['enabled']=False
  data['risk'].update(initial_size_mode='up_to_third',leverage_mode='fixed',leverage=research['leverage'],
   min_reward_risk=research['min_net_rr'],max_position_loss_fraction=research['risk_fraction'])

 from okx_band_flow import DEFAULTS as BAND_FLOW
 if data['execution'].get('band_flow_revision_v641',0)<1:
  data['signals']['band_flow']=dict(BAND_FLOW)
  data['execution']['band_flow_revision_v641']=1
 if data['signals'].get('band_flow',{}).get('enabled'):
  data['signals']['research_entry']['enabled']=False
  data['execution']['ai_confirmation']=False
  data['execution']['autonomous_scalp']['enabled']=False
  data['selection']['kst_turnover']['enabled']=False
  data['selection'].update(include_majors=True,mode='turnover_or_volume')
  data['risk'].update(initial_size_mode='fixed_third',leverage=4,leverage_mode='auto',
   daily_loss_enabled=False,final_roe_enabled=False,max_position_loss_fraction=1.,max_open_stop_loss_fraction=1.,
   max_total_margin_fraction=1.,max_position_margin_fraction=1.,max_total_notional_fraction=30.)
 if data['signals'].get('band_flow',{}).get('enabled') and data['execution'].get('reward_risk_revision_v642',0)<1:
  data['risk']['min_reward_risk']=1.1
  data['execution']['reward_risk_revision_v642']=1
 from okx_flow_structure import DEFAULTS as FLOW_STRUCTURE
 if data['execution'].get('flow_structure_revision_v643',0)<1:
  data['signals']['flow_structure']=dict(FLOW_STRUCTURE)
  data['execution']['flow_structure_revision_v643']=1
 from okx_oct23 import DEFAULTS as OCT23
 from okx_free_ai import DEFAULTS as FREE_AI
 if data['execution'].get('dual_profile_revision_v644',0)<1:
  data['signals']['oct23_entry']=dict(OCT23)
  data['execution']['free_ai']=dict(FREE_AI)
  data['execution']['dual_profile_revision_v644']=1
 data['execution']['profile']='FREE5'
 data['execution']['subscription_chat_only']=True
 data['signals']['oct23_entry']['enabled']=False
 data['execution']['free_ai']['enabled']=True
 if data['execution'].get('review_revision_v654',0)<1:
  data['execution']['free_ai']['manage_seconds']=600
  data['execution']['review_revision_v654']=1
 if data['execution'].get('cadence_revision_v666')!=1:
  data['execution']['free_ai'].update(entry_seconds=300,manage_seconds=300)
  data['execution']['cadence_revision_v666']=1
 data['selection']['include_majors']=False
 from okx_case_lessons import PARAMETERS
 lesson_settings=data['execution'].setdefault('chart_lessons',{})
 for key,value in PARAMETERS.items():lesson_settings.setdefault(key,value)
 data['execution']['budget_shared_root']='..'
 data['signals']['flow_structure']['enabled']=False
 data['risk']['min_reward_risk']=1e-06
 if True:
  data['risk'].update(leverage=5,leverage_mode='fixed',initial_size_mode='fixed_third',initial_margin_fraction=1/3)
  data['risk'].update(min_leverage=5,max_leverage=5)
 data['execution']['legacy_transfer_recheck_authorized']=True
 from okx_pattern15 import configure as configure_pattern15
 return configure_pattern15(data)

def apply(root,check_running=True):
 root=Path(root);lock=None
 try:
  if check_running:
   lock=socket.socket()
   if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):lock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
   try:lock.bind(('127.0.0.1',48736))
   except OSError:raise ValueError('자동매매 창을 먼저 종료한 뒤 다시 실행하세요.') from None
  path=root/'strategy_config.json';source=path if path.exists() else root/'strategy_config.default.json'
  data=autonomous_config(json.loads(source.read_text(encoding='utf-8-sig')))
  with tempfile.TemporaryDirectory() as d:
   (Path(d)/'strategy_config.json').write_text(json.dumps(data),encoding='utf-8');load_config(d)
  risk_backup=root/'strategy_config_before_v732.json'
  if path.exists() and not risk_backup.exists():shutil.copy2(path,risk_backup)
  or_backup=root/'strategy_config_before_v730.json'
  if path.exists() and not or_backup.exists():shutil.copy2(path,or_backup)
  release_backup=root/'strategy_config_before_v725.json'
  if path.exists() and not release_backup.exists():shutil.copy2(path,release_backup)
  channel_backup=root/'strategy_config_before_channel_v701.json'
  if path.exists() and not channel_backup.exists():shutil.copy2(path,channel_backup)
  third_backup=root/'strategy_config_before_third_v649.json'
  if path.exists() and not third_backup.exists():shutil.copy2(path,third_backup)
  half_backup=root/'strategy_config_before_fixed_half_v646.json'
  if path.exists() and not half_backup.exists():shutil.copy2(path,half_backup)
  profile_backup=root/'strategy_config_before_dual_profile_v644.json'
  if path.exists() and not profile_backup.exists():shutil.copy2(path,profile_backup)
  flow_backup=root/'strategy_config_before_flow_structure_v643.json'
  if path.exists() and not flow_backup.exists():shutil.copy2(path,flow_backup)
  band_backup=root/'strategy_config_before_band_flow_v641.json'
  if path.exists() and not band_backup.exists():shutil.copy2(path,band_backup)
  reset_backup=root/'strategy_config_before_entry_reset_v640.json'
  if path.exists() and not reset_backup.exists():shutil.copy2(path,reset_backup)
  turnover_backup=root/'strategy_config_before_kst_turnover_v639.json'
  if path.exists() and not turnover_backup.exists():shutil.copy2(path,turnover_backup)
  runner_backup=root/'strategy_config_before_structure_runner_v638.json'
  if path.exists() and not runner_backup.exists():shutil.copy2(path,runner_backup)
  relaxed_backup=root/'strategy_config_before_rr04_v637.json'
  if path.exists() and not relaxed_backup.exists():shutil.copy2(path,relaxed_backup)
  rr_backup=root/'strategy_config_before_rr_one_v631.json'
  if path.exists() and not rr_backup.exists():shutil.copy2(path,rr_backup)
  dynamic_backup=root/'strategy_config_before_dynamic_exit_v630.json'
  if path.exists() and not dynamic_backup.exists():shutil.copy2(path,dynamic_backup)
  trend_backup=root/'strategy_config_before_relaxed_trend_v628.json'
  if path.exists() and not trend_backup.exists():shutil.copy2(path,trend_backup)
  market_backup=root/'strategy_config_before_whole_market_v624.json'
  if path.exists() and not market_backup.exists():shutil.copy2(path,market_backup)
  four_backup=root/'strategy_config_before_pacing_v622.json'
  if path.exists() and not four_backup.exists():shutil.copy2(path,four_backup)
  paced_backup=root/'strategy_config_before_pacing_v621.json'
  if path.exists() and not paced_backup.exists():shutil.copy2(path,paced_backup)
  newer_backup=root/'strategy_config_before_sol_chat_v620.json'
  if path.exists() and not newer_backup.exists():shutil.copy2(path,newer_backup)
  backup=root/'strategy_config_before_autonomous_v616.json'
  if path.exists() and not backup.exists():shutil.copy2(path,backup)
  tmp=path.with_suffix('.auto.tmp')
  with tmp.open('w',encoding='utf-8') as out:
   json.dump(data,out,ensure_ascii=False,indent=2,allow_nan=False);out.write('\n');out.flush();os.fsync(out.fileno())
  os.replace(tmp,path);return data
 finally:
  if lock:lock.close()
if __name__=='__main__':
 try:apply(Path(__file__).resolve().parent);print('Trading profile configured. No order sent.')
 except Exception as e:print('Update failed:',str(e));raise SystemExit(1)

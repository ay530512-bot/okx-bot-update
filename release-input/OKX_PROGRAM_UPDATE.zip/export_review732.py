"""Export only confirmed trade outcomes and risk arithmetic; no keys/API access."""
import json
from pathlib import Path
from datetime import datetime, timezone

FIELDS=('symbol','direction','entry_ms','end_ms','source','reason','realizedPnl',
        'fee','fundingFee','estimated_loss','exit_price','risk732','market_fill_stats')
RISK_FIELDS=('trade_budget','admitted_budget','open_risk','total_risk_limit','total_notional','route')
FILL_FIELDS=('avg_px','quantity','notional_usdt','margin_usdt','estimated_stop_loss',
             'stop_roe','adverse_vs_estimate')


def export(root):
    root=Path(root);rows=[];skipped=0
    path=root/'position_results.jsonl'
    if path.exists():
        for line in path.read_text(encoding='utf-8-sig').splitlines():
            if not line.strip():continue
            try:
                value=json.loads(line)
                if not isinstance(value,dict):raise ValueError('record')
            except (ValueError,TypeError):skipped+=1;continue
            if not value.get('risk732'):continue
            row={k:value[k] for k in FIELDS if k in value}
            row['risk732']={k:value['risk732'][k] for k in RISK_FIELDS if k in value['risk732']}
            row['market_fill_stats']={k:(value.get('market_fill_stats') or {})[k] for k in FILL_FIELDS if k in (value.get('market_fill_stats') or {})}
            rows.append(row)
    result=dict(version='7.32',generated_utc=datetime.now(timezone.utc).isoformat(),
                basis='Exchange-confirmed closed trades only; excludes open/unsettled positions. realizedPnl includes fees/funding; do not subtract them twice.',
                trades=rows,confirmed_count=len(rows),skipped_invalid_lines=skipped)
    output=root/'TRADE_REVIEW_V732.json'
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    return output,len(rows)


if __name__=='__main__':
    path,count=export(Path(__file__).resolve().parent)
    print(f'{path.name}: {count} confirmed closed trades. No account keys included.')

"""Display last traded USDT price without rounding small coins to zero."""
from decimal import Decimal,InvalidOperation

def price_label(value):
 try:
  n=Decimal(str(value))
  if not n.is_finite() or n<=0:return '현재가 —'
  value=format(n,'f')
  if '.' in value:value=value.rstrip('0').rstrip('.')
  return value+' USDT'
 except (InvalidOperation,ValueError,TypeError):return '현재가 —'

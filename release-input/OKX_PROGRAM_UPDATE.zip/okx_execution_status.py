"""Plain execution status and read-only chart loading; never submits orders."""
import time
from collections import Counter
from okx_market import closed_candles
from okx_core import BotError

LABELS={'paused':'신규 진입 정지','preview':'미리보기 · 주문 없음','recovery':'연결·계정 대조',
        'scan':'종목 탐색','signal_wait':'진입 신호 대기','ws_wait':'실시간 데이터 대기',
        'ai_pending':'AI 승인 확인','ai_rejected':'AI 거부','approved':'AI 승인 완료',
        'preflight':'주문 전 점검','preflight_rejected':'주문 전 조건 미충족','submitted':'주문 결과 확인',
        'filled':'체결 확인·손절 대조','holding':'보유·보호 관리','day_stop':'당일 거래 중단','error':'복구 확인 필요'}

class ExecutionStatus:
    def __init__(self):
        self.phase='paused';self.reason='실거래 시작 전';self.updated=time.monotonic();self.counts={};self.block_reasons=Counter()
    def set(self,phase,reason='',count=None):
        if count:self.counts[count]=self.counts.get(count,0)+1
        if phase=='preflight_rejected':
            text=str(reason)
            tags=[('손익비','비용 반영 손익비'),('유동성','호가 유동성'),('만료','신호 만료'),('시간 초과','신호 만료'),('펀딩비','펀딩 데이터'),('WebSocket','시세 수신'),('반올림','계약 수량 단위'),('PermissionError','파일 저장 권한'),('한도','운용 한도')]
            group=next((v for k,v in tags if k in text),'기타 주문 전 점검')
            self.block_reasons[group]+=1
        changed=(self.phase,self.reason)!=(phase,str(reason))
        self.phase=phase;self.reason=str(reason)[:320];self.updated=time.monotonic()
        return changed
    def snapshot(self):return dict(phase=self.phase,label=LABELS.get(self.phase,self.phase),reason=self.reason,counts=dict(self.counts),block_reasons=dict(self.block_reasons))

def check_permissions(config):
    raw=config.get('perm')
    if raw is not None and 'trade' not in {x.strip() for x in str(raw).split(',')}:
        raise BotError('API 키 Trade 권한 없음: OKX API 권한을 확인하세요. 주문 없음.')
    return raw is not None

def read_frames(api,symbol,c):
    """Scalping needs full 5m/15m history; optional higher frames cannot block order/exit analysis."""
    scalp=c['signals'].get('wick15',{}).get('scalp_enabled',False) and c['signals'].get('entry_mode')=='wick15'
    frames={};opens={}
    bars_to_read=list(c['indicators']['frames'])
    if c['signals'].get('support_entries',{}).get('enabled') and '1m' not in bars_to_read:bars_to_read.insert(0,'1m')
    for bar in bars_to_read:
        try:
            from okx_entry_pipeline import candle_rows
            rows=[list(r) for r in candle_rows(api,symbol,bar,c)]
            opens[bar]={int(r[0]):float(r[1]) for r in rows}
            for row in rows:row[7]=row[5]
            frames[bar]=closed_candles(rows,bar,api.now_ms())
        except (BotError,ValueError,IndexError,KeyError):
            if not scalp or bar not in ('1m','1H','4H'):raise
            frames[bar]=[];opens[bar]={}
    return frames,opens

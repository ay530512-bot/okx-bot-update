"""Bounded, read-only order admission before paid AI, with expiring candidate leases."""
import copy,time
from okx_core import BotError

def retained_selection(engine,symbol):
    lease=getattr(engine,'entry_candidate_leases',{}).get(symbol)
    if not lease:return None
    now=engine.api.now_ms()
    if not 0<=now-lease['ms']<=60000:return None
    if lease['epoch']!=engine.epoch:return None
    if lease['day']!=now//86400000:return None
    return dict(lease['row'])

def admit(engine,review):
    from okx_ai_cost import precheck
    from okx_autonomous import make_signal
    from okx_review_ui import emit_review
    from collections import Counter
    output=[];admitted=[];rate_limited=False;attempts=0;failures=[];started=time.monotonic();groups=[]
    leases=getattr(engine,'entry_candidate_leases',{})
    engine.entry_candidate_leases=leases
    source,_=engine.universe.read()
    rows={r['symbol']:r for r in (source or {}).get('rows',[])}
    previous=getattr(engine,'auto_frozen',None)
    for original in review['_packets']:
        symbol=original['symbol'];row=rows.get(symbol)
        if row:
            leases[symbol]=dict(ms=engine.api.now_ms(),epoch=engine.epoch,
                day=engine.api.now_ms()//86400000,row={k:row[k] for k in
                ('rank','turnover','activity','change','ranking_start_ms','mover_group','mover_rank','turnover_rank','kst_turnover_usdt','turnover_start_ms','turnover_observed_ms') if k in row})
        elif not retained_selection(engine,symbol):
            failures.append(symbol+' / 후보 갱신: 다음 검사 대기');continue
        value=copy.deepcopy(original);value['directions']={};output.append(value)
        for action,direction in original['directions'].items():
            low=engine.cfg['risk']['min_leverage'];cap=original['leverage_cap']
            leverages=[v for v in sorted(set((low,min(5,cap),cap))) if v>=low]
            # Each symbol/direction gets one attempt before any gets a second.
            options=[(index,lev) for lev in leverages for index in range(len(direction['stop_plans']))]
            if options:groups.append(dict(original=original,value=value,action=action,
                direction=direction,options=options,next=0,passed=False))
    offset=getattr(engine,'admission_cursor',0)%max(1,len(groups))
    groups=groups[offset:]+groups[:offset];last_group=None
    from okx_read_control import account_read_batch
    batch=account_read_batch(engine.api);batch.__enter__()
    try:
        while not rate_limited and attempts<6 and time.monotonic()-started<=12:
            pending=[g for g in groups if not g['passed'] and g['next']<len(g['options'])]
            if not pending:break
            for g in pending:
                if attempts>=6 or time.monotonic()-started>12:break
                original=g['original'];symbol=original['symbol'];action=g['action']
                index,leverage=g['options'][g['next']];g['next']+=1;attempts+=1;last_group=g
                try:
                    signal=make_signal(dict(symbol=symbol,action=action,leverage=leverage,
                        stop_index=index,reason='유료 호출 전 주문 가능 검사'),original,engine.cfg)
                    engine.auto_frozen=signal
                    receipt=precheck(engine,signal)
                    fresh=receipt.pop('_fresh_signal',signal)
                    admitted.append(dict(signal=fresh,receipt=receipt))
                    item=copy.deepcopy(g['direction']['stop_plans'][index]);item['admitted_leverages']=[leverage]
                    g['value']['directions'][action]=dict(g['direction'],stop_plans=[item],stop_options=[item['stop']])
                    g['passed']=True
                except BotError as error:
                    failures.append(symbol+' '+action+' / '+str(error))
                    if '50011' in str(error) or '50040' in str(error):
                        rate_limited=True;break
    finally:
        batch.__exit__(None,None,None)
        engine.auto_frozen=previous
        # Advance past the last attempted group, including time-budget exhaustion.
        if last_group is not None:
            engine.admission_cursor=(offset+next(n for n,g in enumerate(groups) if g is last_group)+1)%len(groups)
    now=engine.api.now_ms()
    engine.entry_candidate_leases={k:v for k,v in leases.items() if 0<=now-v['ms']<=60000}
    output=[v for v in output if v['directions']]
    if rate_limited:output=[];admitted=[]
    summary=dict(attempts=attempts,passed=sum(g['passed'] for g in groups),
        rate_limited=rate_limited,deferred=sum(not g['passed'] and g['next']<len(g['options']) for g in groups),
        elapsed_seconds=round(time.monotonic()-started,2),reasons=dict(Counter(failures)))
    engine.last_admission_summary=summary
    message='사전검사 '+str(attempts)+'회 / 통과 '+str(summary['passed'])+'방향 / 미검사 잔여 '+str(summary['deferred'])+'방향'
    if rate_limited:message+=' / OKX 요청 제한: 이번 회차 신규 진입·유료 호출 보류'
    if failures:message+=' / '+' | '.join(dict.fromkeys(failures))[:900]
    emit_review(engine,'사전검사 통과' if output else 'AI 호출 전 대기',review,message)
    if hasattr(engine,'log'):engine.log(message)
    return dict(review,_packets=output,_admitted=admitted)

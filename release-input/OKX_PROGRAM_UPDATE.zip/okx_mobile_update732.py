"""Authenticated mobile requests use the PC repository and serialized install checkpoint."""
import json,queue,threading,time
from pathlib import Path
from okx_update732 import VERSION,repository,check_download

class MobileUpdater:
    def __init__(self,root,engine,mobile):
        self.root=Path(root);self.engine=engine;self.mobile=mobile
        self.messages=queue.Queue();self.busy=False
        self.publish('idle','현재 '+VERSION+' · PC에 저장한 GitHub 저장소를 사용합니다.')
    def publish(self,status,message):
        with self.mobile.lock:
            self.mobile.update_state=dict(status=status,message=message,busy=self.busy,version=VERSION)
    def request(self,command):
        def result(status,message):
            self.mobile.complete_control(dict(request_id=command['request_id'],owner=command['owner'],status=status,message=message))
        age=time.monotonic()-command['issued_at']
        if not 0<=age<=30:result('failed','요청이 만료되었습니다. 다시 눌러주세요.');return
        if self.busy:result('failed','업데이트 처리 중입니다. 아래 진행 상태를 확인하세요.');return
        try:
            config=json.loads((self.root/'update_settings.json').read_text(encoding='utf-8'))
            repo=repository(config.get('repository',''))
        except Exception:
            result('failed','PC 업데이트 창에서 GitHub 저장소를 먼저 저장하세요.');return
        self.busy=True;self.publish('checking','저장된 GitHub 저장소의 새 버전을 확인합니다.')
        result('accepted','업데이트 요청 접수 · 아래 진행 상태를 확인하세요.')
        def work():
            try:self.messages.put(('done',check_download(self.root,repo,lambda msg:self.messages.put(('progress',msg)))))
            except Exception as exc:self.messages.put(('error','업데이트 확인 실패: '+str(exc)[:200]))
        threading.Thread(target=work,daemon=True,name='mobile-release-download').start()
    def poll(self):
        while True:
            try:kind,value=self.messages.get_nowait()
            except queue.Empty:break
            if kind=='progress':self.publish('checking',value)
            elif kind=='error':self.busy=False;self.publish('failed',value)
            elif value:
                self.publish('checking_account','파일 검사 완료 · 보유·미체결·조건주문 확인 중입니다.')
                self.engine.send('update_restart',folder=value,mobile_update=True)
            else:
                self.busy=False;self.publish('latest','이미 최신 버전입니다.')
    def engine_result(self,data):
        self.busy=data['status']=='installing'
        self.publish(data['status'],data['message'])

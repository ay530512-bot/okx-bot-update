"""Read-only AI admission checks, compact review payload and persistent call throttles."""
import json,time
from okx_core import BotError,dec,size_plan,fmt
from okx_execution_status import check_permissions

DEFAULTS=dict(symbol_direction_cooldown_seconds=300,min_interval_seconds=30,
              precheck_retry_seconds=60,max_payload_chars=10000,max_output_tokens=220)
INSTRUCTIONS=('당신은 선물 진입의 보조 검토자다. 입력은 로컬 규칙과 주문 전 조회 점검을 통과한 후보의 요약이다. '
'사례 참고 지지 롱·저항 숏·밴드 반전·돌파 재확인은 독립 경로이며 거래량 급증이나 상위 시간봉 방향 일치는 공통 필수가 아니다. 구체적인 반전·구조 근거를 우선 검토하라. '
'전략들은 OR 관계이며 선택된 전략만 검토한다. 지지 회복·이평 횡보·추세 꼬리·돌파·밴드 반전은 독립 전략이다. '
'다른 전략의 꼬리/밴드 복귀/추가 봉 돌파를 필수 조건으로 요구하지 마라. '
' tail_turn은 사전 추세·꼬리·MA5/몸통 회복과 확인봉으로 전환을 확인한 전략이다. scalp_ma는5m추세와1m지지회복, scalp_range는5m횡보와1m밴드복귀 전략이다. 스캘핑은 별도 목표가/설정된 시간 제한/빠른 청산을 쓰며 +10%ROE까지 기다리지 않는다. '
'context_ 전략은1H/4H 배경을1m/5m/15m 완료봉 반응으로 실행한다. MA 지지·직전 극점 보존·밴드 가격거부 중 선택한 하나를 검토하며 상위 봉이 방금 마감했을 것을 요구하지 않는다. '
'방향, 여러 시간봉의 흐름과 확정 스윙, 선택 전략의 근거, 진입/손절/목표/비용/주문 계획의 모순을 확인하라. '
'선택 전략이 완성되고 사전 점검을 통과했으며 구체적 모순이 없으면 승인하라. 완벽한 확신이나 모든 지표 일치를 추가 요구하지 말고, 일반적인 실패 가능성만으로 거절하지 마라. 확인된 데이터·방향·위험 계획에 구체적 모순이 있으면 거절 사유를 명시하라. '
'상위 추세 반대라도 기록된 다봉 안정화·지지저항 반전 근거를 검토하라. '
'가격·종목·손절·수익 확률을 새로 만들지 말고 손절을 넓히지 마라. 수익을 보장하지 않는다. '
'approve 불리언과 reason 문자열 JSON만 출력하고 reason은80자 이내로 간결히 작성하라.')


def validate(p):
    return (60<=p['symbol_direction_cooldown_seconds']<=3600 and 5<=p['min_interval_seconds']<=300
        and 10<=p['precheck_retry_seconds']<=600 and 5000<=p['max_payload_chars']<=20000
        and type(p['max_output_tokens']) is int and 120<=p['max_output_tokens']<=350)


def limits(c):return dict(DEFAULTS,**c.get('execution',{}).get('ai_cost_control',{}))


def key(s):return s['symbol']+':'+s['action']


def wait_reason(engine,s):
    now=engine.api.now_ms();k=key(s);control=engine.journal.data.get('ai_call_control',{})
    if now<control.get('directions',{}).get(k,0):return 'AI 절약: 같은 종목·방향 재호출 대기'
    if now<control.get('global_next_ms',0):return 'AI 절약: 전체 호출 간격 대기'
    if now<getattr(engine,'pre_ai_retry',{}).get(k,0):return 'AI 호출 전 주문 가능 점검 재시도 대기'
    return None


def mark_call(engine,s):
    now=engine.api.now_ms();p=limits(engine.cfg)
    control=engine.journal.data.setdefault('ai_call_control',{'directions':{},'global_next_ms':0})
    control['directions']={k:v for k,v in control.get('directions',{}).items() if v>now}
    control['directions'][key(s)]=now+p['symbol_direction_cooldown_seconds']*1000
    control['global_next_ms']=now+p['min_interval_seconds']*1000
    engine.journal.save()


def precheck(engine,s):
    """GET/public calls only: no leverage changes, orders, cancellation, AI or Telegram."""
    if not engine.enabled or engine.preview or engine.recovering or engine.entry_cancel.is_set() or not engine.within_session():
        raise BotError('AI 호출 전: 운용·연결·세션 상태 대기')
    if not engine.can_open_position() or any(r['symbol']==s['symbol'] for r in engine.records()):
        raise BotError('AI 호출 전: 보유 종목 중복 또는 포지션 수 한도')
    slot=engine.empty_slot()
    with engine.selected(slot):
        snapshot=engine.snapshot();check_permissions(snapshot['config'])
        if snapshot['positions'] or snapshot['orders']:raise BotError('AI 호출 전: 기존 포지션/일반 주문 대조 필요')
        _,other=engine.algos(full=True)
        if other:raise BotError('AI 호출 전: 기록 외 조건주문 발견')
        engine.risk_snapshot(snapshot)
        if not engine.account_stream.fresh():raise BotError('AI 호출 전: 계정 데이터 지연')
        i=engine.api.public('/api/v5/public/instruments',instType='SWAP',instId=s['symbol'])[0]
        if not engine.is_allowed_instrument(i):raise BotError('AI 호출 전: 허용 거래 대상 아님')
        lev=s['leverage'];override=engine.cfg['signals'].get('support_entries',{}).get('major_leverages',{}).get(s['symbol'].split('-')[0])
        from okx_autonomous import valid_leverage
        if not valid_leverage(s,engine.cfg):
            raise BotError('AI 호출 전: 종목별 배율 설정 불일치')
        old=engine.executing_signal;engine.executing_signal=None
        try:frames=engine.entry_context(s['symbol'],s['action'])
        finally:engine.executing_signal=old
        # No AI approval exists yet: select the latest same-direction signal, then freeze it for review.
        fresh=dict(frames['_v4'],symbol=s['symbol'],selection=engine.selection_row(s['symbol']))
        from okx_rules import select_leverage
        lev=select_leverage(fresh,engine.cfg)
        cap=int(float(i['lever']))
        if override is not None and lev>cap:raise BotError('거래소 허용 배율 미달')
        lev=min(lev,cap);fresh['leverage']=lev
        if lev<engine.cfg['risk']['min_leverage']:raise BotError('AI 호출 전: 배율 하한 미달')
        fresh_id=s['symbol']+':'+fresh['signal_id']
        if fresh_id in engine.journal.data.get('seen_signals',{}) or fresh_id in engine.ai_reviewed:raise BotError('AI 호출 전: 최신 신호 중복 검토/주문')
        if fresh.get('expires_ms',engine.api.now_ms()+60000)-engine.api.now_ms()<(5000 if fresh.get('autonomous') else 25000):raise BotError('AI 호출 전: 최신 신호 만료 임박')
        ticker=engine.api.public('/api/v5/market/ticker',instId=s['symbol'])[0]
        if not 0<=engine.api.now_ms()-int(ticker['ts'])<=10000:raise BotError('AI 호출 전: 시세 지연')
        fee=engine.api.taker_fee(i)
        plan=size_plan(i,engine.allocation_seed(snapshot),snapshot['available'],lev,ticker['bidPx'],ticker['askPx'],fee,margin_cap=engine.initial_margin_cap(snapshot),
            strict_initial=engine.cfg['risk'].get('initial_size_mode')=='fixed_third',
            max_rounding_fraction=engine.cfg['risk'].get('fixed_initial_max_rounding_fraction',.03))
        engine.prepared_symbol=s['symbol'];engine.entry_leverage=lev
        plan=engine.prepare_entry_plan(plan,i,ticker,frames,'long' if s['action']=='LONG' else 'short',snapshot,fee)
        maximum=engine.api.get('/api/v5/account/max-size',instId=s['symbol'],tdMode='isolated',leverage=str(lev))[0]
        if dec(plan['quantity'])>dec(maximum['maxBuy' if s['action']=='LONG' else 'maxSell']):
            raise BotError('AI 호출 전: 거래소 최대 주문 가능 수량 미달')
        if engine.entry_cancel.is_set() or not engine.within_session():raise BotError('AI 호출 전: 사용자 중지 또는 세션 종료')
        return dict(checked_ms=engine.api.now_ms(),quantity=plan['quantity'],margin=plan['margin_bound'],
            estimated_loss=plan['estimated_loss'],reward_risk=plan['reward_risk'],cost_rate=plan['cost_rate'],
            liquidity=plan['_liquidity'],_fresh_signal=fresh)


def compact(s,receipt,c):
    audit=s.get('decision_record',{});frames={}
    for name,m in audit.get('frames',{}).items():
        frames[name]={k:m[k] for k in ('trend','structure','ma','bb','rsi','volume_relative','last_bar_ms','reason','unavailable_ma') if k in m}
    out={k:s[k] for k in ('symbol','action','strategy','pattern','setup_frame','execution_frame','leverage','entry_reference','stop','target','level','signal_id','valid_from_ms','expires_ms','holding_rule') if k in s}
    out.update(frames=frames,flow=audit.get('market_flow',{}),evidence=audit.get('evidence',{}),
        reason=s.get('reason',''),selection={k:v for k,v in s.get('selection',{}).items() if k in ('activity','change','ranking_start_ms','mover_group','mover_rank')},
        recent_5m=s.get('chart_context',{}).get('recent_5m',[])[-4:],precheck={k:v for k,v in receipt.items() if not k.startswith('_')})
    def clean(x):
        if isinstance(x,float):return float(format(x,'.7g'))
        if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
        if isinstance(x,list):return [clean(v) for v in x]
        return x
    out=clean(out);text=json.dumps(out,ensure_ascii=False,separators=(',',':'),allow_nan=False)
    if len(text)>limits(c)['max_payload_chars']:raise BotError('AI 요약 자료 크기 초과: 유료 호출 보류')
    return text

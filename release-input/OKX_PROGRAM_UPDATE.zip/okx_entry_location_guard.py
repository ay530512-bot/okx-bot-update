"""New-entry veto shared by ALL setup routes; never changes an existing stop."""
import math
from okx_core import BotError

def validate(frame,action,price,proof):
 side=1 if action=='LONG' else -1;bars=frame.get('recent',[]);atr=float(frame.get('atr') or 0)
 if len(bars)<4 or atr<=0 or not math.isfinite(atr):raise BotError('진입 위치 확인 자료 부족')
 last=bars[-1];close=float(last[4]);price=float(price)
 if not math.isfinite(price) or price<=0:raise BotError('진입 현재가 오류')
 if (close-float(last[1]))*side<=0 or (close-float(bars[-2][4]))*side<=0:raise BotError('확정봉 회복·거절 미확인 · 이평선 접촉만으로 진입 금지')
 if not -.10*atr<=(price-close)*side<=.30*atr:raise BotError('확인봉 가격 이탈 또는 늦은 추격 · 새 재시험 대기')
 field=3 if side==1 else 2;extreme=(min if side==1 else max)(float(r[field]) for r in bars[-3:])
 distance=(price-extreme)*side/atr
 if distance>1.25:raise BotError('지지·저항 재시험에서 1.25ATR 이상 이격 · 반등/하락 뒤 추격 금지')
 zone=proof.get('neckline',proof.get('zone'))
 if zone is not None:
  gap=(price-float(zone))*side/atr
  if gap<=0 or gap>.75:raise BotError('재시험 지지·저항 이탈 또는 0.75ATR 이상 추격 · 가까운 새 타점 대기')
 strong_wick=proof.get('setup')=='volume_wick' and float(proof.get('relative_volume') or 0)>=2
 # A high-volume sweep/recovery has its own explicitly validated wick proof.
 # Other entries must hold the latest retest extreme, not buy a fresh falling low.
 if not strong_wick and (float(last[field])-float(bars[-2][field]))*side<-.1*atr:raise BotError('최근 재시험 저점/고점 훼손 · 회복 봉만 보고 진입 금지')
 return dict(proof,entry_location_guard=dict(retest_distance_atr=distance,confirmation_gap_atr=(price-close)*side/atr,policy='completed recovery/rejection, held extreme, bounded distance; all OR routes'))

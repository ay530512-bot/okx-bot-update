"""Completed-bar support/resistance role-flip and moving-average zone retests."""
import math
from okx_core import BotError

def setups(bars,atr):
 result={}
 if len(bars)<30 or not math.isfinite(atr) or atr<=0:return result
 end=len(bars)-1;last=bars[-1];previous=bars[-2]
 totals=[0.]
 for row in bars:totals.append(totals[-1]+float(row[4]))
 def avg(i,n):return (totals[i+1]-totals[i-n+1])/n
 for action,side in [('LONG',1),('SHORT',-1)]:
  # A touch is not a rejection/recovery: require directional body AND close progress.
  if (float(last[4])-float(last[1]))*side<=0 or (float(last[4])-float(previous[4]))*side<=0:continue
  candidates=[];recent=bars[-3:];extreme=(min if side==1 else max)(float(r[3 if side==1 else 2]) for r in recent)
  for cross in range(max(20,end-45),end-3):
   before=bars[cross-20:cross]
   level=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in before)
   touches=[j for j,r in enumerate(before) if abs(float(r[2 if side==1 else 3])-level)<=.2*atr]
   if not touches or touches[-1]-touches[0]<3:continue
   if (float(bars[cross-1][4])-level)*side>0 or (float(bars[cross][4])-level)*side<=.15*atr:continue
   leg=bars[cross:end-2]
   peak=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in leg)
   if (peak-level)*side<atr:continue
   # At least one intervening impulse bar precedes a later retest.
   if abs(extreme-level)>.5*atr or (float(last[4])-level)*side<=.1*atr:continue
   if any((float(r[4])-level)*side<-.25*atr for r in bars[cross+1:end-2]):continue
   candidates.append(dict(setup='role_flip_retest',break_ms=bars[cross][0],zone=level,zone_basis='preceding20 range boundary fixed before break',ma_period=None))
  for n in (15,20,50,100,120,200):
   if len(bars)<n+8:continue
   level=avg(end,n)
   if (level-avg(end-3,n))*side<=0 or abs(extreme-level)>.5*atr or (float(last[4])-level)*side<=.1*atr:continue
   for cross in range(max(n,end-30),end-3):
    if (float(bars[cross-1][4])-avg(cross-1,n))*side>0 or (float(bars[cross][4])-avg(cross,n))*side<=.15*atr:continue
    leg=bars[cross:end-2]
    excursion=max((float(r[2 if side==1 else 3])-avg(cross,n))*side for r in leg)
    if excursion<atr:continue
    # Avoid treating an already reclaimed MA as intact resistance/support.
    if any((float(bars[i][4])-avg(i,n))*side<-.25*atr for i in range(cross+1,end-2)):continue
    candidates.append(dict(setup='ma_zone_retest',break_ms=bars[cross][0],zone=level,zone_basis='current selected MA after prior cross and impulse',ma_period=n))
  if candidates:
   # Prefer explicit role-flip evidence, then the most recent crossed zone.
   candidates.sort(key=lambda p:(p['setup']=='role_flip_retest',p['break_ms']),reverse=True)
   result[action]=dict(candidates[0],signal_ms=last[0],retest_extreme=extreme,frame_close=float(last[4]),impulse_min_atr=1.,confirmation='completed directional body and close progress after retest')
 return result

def evidence(frame,action,price):
 proof=frame.get('role_retests',{}).get(action)
 if not proof:raise BotError('이탈/돌파 후 지지·저항 재시험 확인 대기')
 side=1 if action=='LONG' else -1;atr=float(frame['atr']);last=frame['recent'][-1]
 if proof['signal_ms']!=last[0]:raise BotError('역할 전환 재시험 증거 만료')
 if not -.15*atr<=(price-float(proof['frame_close']))*side<=.5*atr:raise BotError('재시험 확인 가격 회복 실패 또는 추격 구간')
 if (price-float(proof['zone']))*side<=0:raise BotError('재시험 구간 반대편으로 재돌파·재이탈')
 stop=float(proof['retest_extreme'])-side*max(.25*atr,price*.001)
 if stop<=0 or (price-stop)*side<=0:raise BotError('재시험 고점·저점 손절 방향 오류')
 return dict(proof,structural_stop=stop)

"""Risk rules, durable journal and authenticated OKX transport.

Nothing executes on import. Network libraries are loaded only when constructing OKX.
"""
import base64
import hashlib
import hmac
import json
import os
import time
import threading
import tempfile
from datetime import datetime, timezone, timedelta
from decimal import Decimal, ROUND_DOWN, ROUND_UP
from pathlib import Path
from urllib.parse import urlencode

KST = timezone(timedelta(hours=9))
BASE = "https://openapi.okx.com"
STOP_ROE = Decimal("-0.30")
DAILY_AI_THRESHOLD = Decimal("0.06")
DAILY_CAP = Decimal("2.00")


class BotError(Exception):
    pass


class Rejected(BotError):
    """Exchange explicitly rejected a request. No automatic POST retries."""


class UnknownOutcome(BotError):
    """A write may have reached OKX. Reconcile using persisted client ID."""


def dec(value):
    if value is None or value == "":
        raise BotError("필수 수치가 비어 있습니다.")
    result = Decimal(str(value))
    if not result.is_finite():
        raise BotError("유효하지 않은 수치입니다.")
    return result


def fmt(value):
    return format(dec(value), "f")


def day_key(ms):
    return datetime.fromtimestamp(ms / 1000, KST).strftime("%Y-%m-%d")


def signed_header(secret, timestamp, method, request_path, body=""):
    message = timestamp + method + request_path + body
    return base64.b64encode(hmac.new(secret.encode(), message.encode(), hashlib.sha256).digest()).decode()


def valid_order_leverage(symbol,leverage):
    if type(leverage) is not int:return False
    return 3<=leverage<=10 or leverage=={'BTC-USDT-SWAP':30,'ETH-USDT-SWAP':15,'SOL-USDT-SWAP':15}.get(symbol)


def size_plan(instrument, equity, available, leverage, bid, ask, fee, margin_cap=None, strict_initial=False, max_rounding_fraction=.03, band_flow=False, initial_fraction=None):
    """Bound initial margin to 1/3 equity. The sizing price is an estimate, not a market execution cap.

    Reserve fees separately. Do not spend the other 2/3 or round size upward.
    """
    equity, available, bid, ask, fee = map(dec, (equity, available, bid, ask, fee))
    if not valid_order_leverage(instrument.get('instId',''),leverage):
        raise BotError('종목별 허용 배율 오류: 알트3~10 / BTC30 / ETH·SOL15')
    if min(equity, available, bid, ask) <= 0 or ask < bid:
        raise BotError("잔고 또는 호가가 올바르지 않습니다.")
    if dec(instrument.get("lever")) < leverage:
        raise BotError("해당 종목이 선택한 레버리지를 지원하지 않습니다.")
    if not band_flow and (ask - bid) / ((ask + bid) / 2) > Decimal("0.0015"):
        raise BotError("호가 간격이 너무 넓습니다.")
    tick, lot, ct, minimum = [dec(instrument[k]) for k in ("tickSz", "lotSz", "ctVal", "minSz")]
    if min(tick, lot, ct, minimum) <= 0:
        raise BotError("주문 단위 오류")
    # For price rounding, a positive direction is a buy, negative is a sell.
    buy = (ask * Decimal("1.001") / tick).to_integral_value(rounding=ROUND_UP) * tick
    sell = (bid * Decimal("0.999") / tick).to_integral_value(rounding=ROUND_DOWN) * tick
    if sell <= 0:
        raise BotError("허용 가격을 계산할 수 없습니다.")
    target=equity*(dec(initial_fraction) if initial_fraction is not None else dec(1)/3)
    if strict_initial:
        if available<target*(1+abs(fee)*leverage*2):
            raise BotError('설정 비율 고정 진입 불가: 목표 증거금과 수수료 여유보다 가용잔고 부족')
        if margin_cap is not None and dec(margin_cap)<target:
            raise BotError('설정 비율 고정 진입 불가: 전체 증거금 한도 부족')
        margin=target
    else:
        margin = min(target, available / (1 + abs(fee) * leverage * 2))
        if margin_cap is not None:
            margin = min(margin, dec(margin_cap))
    quantity = (margin * leverage / (ct * buy) / lot).to_integral_value(rounding=ROUND_DOWN) * lot
    if quantity < minimum:
        raise BotError("설정 증거금으로 최소 주문 수량을 충족하지 못합니다.")
    if instrument.get("maxMktSz") and quantity > dec(instrument["maxMktSz"]):
        if strict_initial:raise BotError("설정 비율 고정 진입 불가: 거래소 시장가 수량 상한")
        quantity = (dec(instrument["maxMktSz"]) / lot).to_integral_value(rounding=ROUND_DOWN) * lot
    if quantity < minimum:
        raise BotError("허용 주문 수량이 최소 수량 미만입니다.")
    if strict_initial and (not band_flow or initial_fraction is not None) and (target-quantity*ct*buy/leverage)/target>dec(max_rounding_fraction):
        raise BotError('설정 비율 고정 진입 불가: 주문 단위 반올림 오차 허용치 초과')
    # Initial stop uses an estimated adverse price; actual market fill must be checked separately.
    long_stop = (buy * (1 + STOP_ROE / leverage) / tick).to_integral_value(rounding=ROUND_UP) * tick
    short_stop = (sell * (1 - STOP_ROE / leverage) / tick).to_integral_value(rounding=ROUND_DOWN) * tick
    if band_flow:long_stop=bid/2;short_stop=ask*2  # Temporary sizing fields; structural SL replaces these before any write.
    if not (0 < long_stop < bid and short_stop > ask):
        raise BotError("손절 가격을 안전하게 계산할 수 없습니다.")
    result = {"quantity": fmt(quantity), "buy": fmt(buy), "sell": fmt(sell),
            "long_stop": fmt(long_stop), "short_stop": fmt(short_stop),
            "margin_bound": fmt(quantity * ct * buy / leverage)}
    if strict_initial:result.update(fixed_initial=True,initial_margin_target=fmt(target),initial_quantity=fmt(quantity))
    return result


def protective_order(symbol, direction, leverage, plan, client_id, algo_client_id):
    if direction not in ("long", "short") or not valid_order_leverage(symbol,leverage):
        raise BotError("진입 방향 또는 레버리지 오류")
    return {
        "instId": symbol, "tdMode": "isolated", "posSide": direction,
        "side": "buy" if direction == "long" else "sell", "ordType": "market",
        "sz": plan["quantity"], "clOrdId": client_id,
        "attachAlgoOrds": [{"attachAlgoClOrdId": algo_client_id,
                            "slTriggerPx": plan[direction + "_stop"],
                            "slTriggerPxType": "mark", "slOrdPx": "-1"}],
    }


def owned_position(owned, positions):
    active = [p for p in positions if dec(p.get("pos", "0")) != 0]
    if not owned:
        if active:
            raise BotError("프로그램 소유가 아닌 포지션이 있습니다. 신규 진입을 중단합니다.")
        return None
    matching = []
    for position in active:
        if (position.get("instId") != owned["symbol"]
                or position.get("posSide") != owned["direction"]
                or position.get("mgnMode") != "isolated"):
            raise BotError("기존 또는 수동 포지션 발견. 자동으로 청산하지 않습니다.")
        allowed = {dec(owned["quantity"])}
        pending = owned.get("pending_add") if owned.get("phase") == "adding" else None
        if pending:
            allowed.add(dec(owned["quantity"]) + dec(pending["quantity"]))
            allowed.add(dec(pending["quantity"]))
        closing_partial = owned.get("phase") in ("closing", "partial_closing", "submitted") and 0 < dec(position["pos"]) <= dec(owned["quantity"])
        adding_partial = pending and (dec(owned["quantity"]) < dec(position["pos"]) <= dec(owned["quantity"]) + dec(pending["quantity"]) or 0 < dec(position["pos"]) <= dec(pending["quantity"]))
        if dec(position["pos"]) not in allowed and not closing_partial and not adding_partial:
            raise BotError("포지션 수량이 기록과 다릅니다. 수동 변경 여부 확인 필요.")
        if owned.get("posId") and position.get("posId") != owned["posId"] and not (pending and 0 < dec(position["pos"]) <= dec(pending["quantity"])):
            raise BotError("포지션 ID가 변경됐습니다. 다른 포지션은 청산하지 않습니다.")
        if dec(position.get("lever")) != owned["leverage"]:
            raise BotError("레버리지가 변경됐습니다. 수동 확인 필요.")
        matching.append(position)
    if len(matching) > 1:
        raise BotError("포지션이 둘 이상입니다.")
    return matching[0] if matching else None


def initial_state():
    return {"version": 1, "account": None, "owned": None, "day": None,
            "api_day": None, "api_spent": 0.0, "api_calls": 0, "session": None, "api_total_spent": 0.0}


class Journal:
    def __init__(self, path):
        self.path = Path(path)
        self.data = initial_state()
        self.save_lock=threading.RLock()
        if self.path.exists():
            try:
                stored = json.loads(self.path.read_text(encoding="utf-8"))
                if stored.get("version") != 1:
                    raise ValueError("Version mismatch")
                stored.setdefault("session", None)  # Upgrade v1 without discarding order records.
                stored.setdefault("api_total_spent", stored.get("api_spent", 0.0))
                for field in self.data:
                    if field not in stored:
                        raise ValueError("Missing field")
                self.data = stored
            except Exception:
                raise BotError("bot_state.json을 읽을 수 없습니다. 삭제하지 말고 확인해 주세요.") from None

    def save(self):
        # Unique temp names and a save lock prevent competing saves sharing one .tmp.
        # Retry only local atomic replacement, never an exchange order.
        with self.save_lock:
            fd,name=tempfile.mkstemp(prefix=self.path.name+'.',suffix='.tmp',dir=self.path.parent)
            temp=Path(name)
            try:
                with os.fdopen(fd,'w',encoding='utf-8') as stream:
                    json.dump(self.data,stream,ensure_ascii=False,indent=2,allow_nan=False)
                    stream.flush();os.fsync(stream.fileno())
                for attempt in range(4):
                    try:os.replace(temp,self.path);break
                    except PermissionError:
                        if attempt==3:raise
                        time.sleep(.05*2**attempt)
            finally:
                try:temp.unlink(missing_ok=True)
                except OSError:pass

    def roll_day(self, ms, equity, initialize=False):
        today = day_key(ms)
        current = self.data["day"]
        if current is None and not initialize:
            return False
        if current is None or current["date"] != today:
            self.data["day"] = {"date": today, "base": fmt(equity), "ended": False,
                                "started_ms": ms, "flow_ids": [], "partial_first_day": current is None,
                                "start_equity": fmt(equity), "net_flow": "0", "baseline_source": "first_observation"}
            self.save()
            return True
        return False

    def daily_return(self, equity):
        current = self.data["day"]
        if not current:
            return None
        denominator = dec(current.get("start_equity", current["base"]))
        return (dec(equity) - dec(current["base"])) / denominator if denominator > 0 else None

    def apply_transfers(self, bills):
        current = self.data["day"]
        if not current:
            return
        seen = set(current["flow_ids"])
        for bill in bills:
            if (bill.get("ccy") != "USDT" or bill.get("type") != "1"
                    or int(bill["ts"]) <= current["started_ms"]):
                continue
            if bill["billId"] not in seen:
                current.setdefault("start_equity", current["base"])
                current["net_flow"] = fmt(dec(current.get("net_flow", 0)) + dec(bill["balChg"]))
                current["base"] = fmt(dec(current["base"]) + dec(bill["balChg"]))
                seen.add(bill["billId"])
        current["flow_ids"] = sorted(seen)
        if dec(current.get("start_equity",current["base"])) <= 0:
            raise BotError("일일 시작 자산을 확인할 수 없습니다.")
        self.save()


class OKX:
    def __new__(cls, settings):
        selected=str(settings.get('TRADING_EXCHANGE') or 'okx').lower()
        if selected!='okx':
            from okx_exchange_adapter import FuturesAdapter
            return FuturesAdapter(settings,execution=settings.get('_EXCHANGE_EXECUTION') is True and cls is OKX)
        return super().__new__(cls)

    def __init__(self, settings):
        if str(settings.get('TRADING_EXCHANGE') or 'okx').lower()!='okx':raise BotError('OKX 전용 연결입니다. 선택 거래소를 확인하세요.')
        import requests
        from okx_network import okx_session
        self.requests = requests
        self.candle_cache_namespace=BASE
        self.session = okx_session()
        self.key, self.secret, self.passphrase = [settings.get(k) for k in
                ("OKX_API_KEY", "OKX_SECRET_KEY", "OKX_PASSPHRASE")]
        if not all((self.key, self.secret, self.passphrase)):
            raise BotError(".env의 OKX 설정 세 항목을 확인해 주세요.")
        self.server_ms, self.anchor, self.synced = 0, 0, 0
        self.read_efficiency=True

    def safe(self, message):
        for key in (self.key, self.secret, self.passphrase):
            message = str(message).replace(key, "[숨김]")
        return message[:500]

    def now_ms(self):
        if not self.server_ms:
            self.sync()
        return self.server_ms + int((time.monotonic() - self.anchor) * 1000)

    def sync(self):
        data = self.request("GET", "/api/v5/public/time", private=False)
        self.server_ms = int(data[0]["ts"])
        self.anchor = self.synced = time.monotonic()

    def request(self, method, path, params=None, body=None, private=True):
        if private and time.monotonic() - self.synced > 300:
            self.sync()
        if private and method=='GET' and getattr(self,'read_efficiency',False):
            from okx_read_control import before_read
            before_read(self,path)
        if method!='GET':
            from okx_read_control import invalidate
            invalidate(self)
        endpoint=path
        path += ("?" + urlencode(params)) if params else ""
        raw = json.dumps(body, separators=(",", ":"), ensure_ascii=False) if body is not None else ""
        headers = {"Content-Type": "application/json"}
        if private:
            stamp = datetime.fromtimestamp(self.now_ms() / 1000, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            headers.update({"OK-ACCESS-KEY": self.key, "OK-ACCESS-PASSPHRASE": self.passphrase,
                            "OK-ACCESS-TIMESTAMP": stamp,
                            "OK-ACCESS-SIGN": signed_header(self.secret, stamp, method, path, raw)})
        try:
            response = self.session.request(method, BASE + path, data=raw or None, headers=headers, timeout=10)
            if method=='GET' and response.status_code==429:
                if private and getattr(self,'read_efficiency',False):
                    from okx_read_control import limited
                    limited(self,endpoint)
                raise Rejected('OKX 50011: HTTP429 요청 제한. 재전송 없이 다음 검사 대기')
            data = response.json()
        except (self.requests.RequestException, ValueError):
            error = UnknownOutcome if method != "GET" else BotError
            raise error("OKX 응답 미확인. 쓰기 요청은 자동 재전송하지 않습니다.") from None
        if response.status_code >= 500:
            error = UnknownOutcome if method != "GET" else BotError
            raise error("OKX 서버 오류. 체결 여부 재확인 필요.")
        if response.status_code >= 400 and data.get("code") == "0":
            error = UnknownOutcome if method != "GET" else BotError
            raise error("HTTP 상태와 API 응답이 일치하지 않습니다. 결과 재확인 필요.")
        if data.get('code') in ('50011','50040') or response.status_code==429:
            if private and method=='GET' and getattr(self,'read_efficiency',False):
                from okx_read_control import limited
                limited(self,endpoint)
        if data.get("code") != "0":
            raise Rejected("OKX " + str(data.get("code")) + ": " + self.safe(data.get("msg", "")))
        rows = data.get("data")
        if not isinstance(rows, list):
            error = UnknownOutcome if method != "GET" else BotError
            raise error("예상과 다른 OKX 응답 형식입니다.")
        if method != "GET":
            for row in rows:
                if row.get("sCode") not in (None, "", "0"):
                    raise Rejected("주문 거절 " + str(row.get("sCode")) + ": " + self.safe(row.get("sMsg", "")))
        return rows

    def get(self, path, **params):
        from okx_read_control import get
        return get(self,path,params)

    def public(self, path, **params):
        return self.request("GET", path, params=params, private=False)

    def post(self, path, body):
        return self.request("POST", path, body=body)

    def snapshot(self):
        config = self.get("/api/v5/account/config")[0]
        balances = self.get("/api/v5/account/balance", ccy="USDT")
        details = [d for b in balances for d in b.get("details", []) if d.get("ccy") == "USDT"]
        if not details:
            equity = available = Decimal(0)
        else:
            equity = dec(details[0]["eq"])
            available = dec(details[0]["availBal"])
        positions = self.get("/api/v5/account/positions")
        orders = self.get("/api/v5/trade/orders-pending", limit="100")
        if len(orders) >= 100:
            raise BotError("미체결 주문이 너무 많아 전체 확인이 불가능합니다.")
        return {"config": config, "equity": equity, "available": available,
                "positions": positions, "orders": orders, "ms": self.now_ms()}

    def pending_algos(self, full=False):
        types = ("conditional", "oco", "trigger", "move_order_stop") if full else ("conditional",)
        result = []
        for kind in types:
            rows = self.get("/api/v5/trade/orders-algo-pending", ordType=kind, limit="100")
            if len(rows) >= 100:
                raise BotError("조건주문을 모두 확인할 수 없습니다.")
            result.extend(rows)
            time.sleep(0.08)
        return result

    def taker_fee(self, instrument):
        rows = self.get("/api/v5/account/trade-fee", instType="SWAP", instFamily=instrument["instFamily"])
        for row in rows:
            for group in row.get("feeGroup", []):
                if group.get("groupId") == instrument.get("groupId"):
                    return abs(dec(group["taker"]))
        for row in rows:
            if row.get("takerU") not in (None, ""):
                return abs(dec(row["takerU"]))
        raise BotError("USDT 선물 수수료를 확인할 수 없습니다. 진입 생략.")

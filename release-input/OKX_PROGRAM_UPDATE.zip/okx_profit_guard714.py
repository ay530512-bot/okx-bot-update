"""Observed-mark profit protection. Orders stay in the existing serialized engine.

Thresholds are an explicit operating policy, not a fitted or proven trading edge.
Only the worker writes the journal; the WS guard buffers observations under a lock.
"""
import math
import threading

from okx_core import BotError

DEFAULTS = dict(enabled=True, full_take_profit_roe=.20, partial_roe=.20, partial_fraction=.5,
                runner_start_roe=.60, peak_keep_fraction=.5,
                trail_atr=1.5, minimum_gap_atr=.75, minimum_gap_roe=.05,
                minimum_trail_roe=.10, structure_buffer_atr=.25,
                false_break_buffer_atr=.25, reversal_body_atr=.5,
                reversal_volume_ratio=1.2, amendment_seconds=10,
                amendment_step_atr=.10, max_hold_seconds=21600)


def settings(cfg):
    return dict(DEFAULTS, **cfg.get('risk', {}).get('profit_guard714', {}))


def enabled(cfg):
    return bool(cfg.get('execution', {}).get('rule_channel701') and settings(cfg)['enabled'])


def validate(cfg):
    s = settings(cfg)
    if s['full_take_profit_roe'] != .20:
        raise BotError('V7.15: +20% ROE 최초 절반청산 설정 필요')
    if s['partial_roe'] != .20 or s['partial_fraction'] != .5:
        raise BotError('V7.22: +20% 절반 청산 설정 필요')
    for key, value in s.items():
        if key == 'enabled':
            continue
        if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise BotError('수익 보호 설정 오류: ' + key)
    if not 0 < s['peak_keep_fraction'] < 1 or s['runner_start_roe'] < s['partial_roe']:
        raise BotError('수익 보호 시작/비율 설정 오류')


def _number(value, default=0.):
    try:
        n = float(value)
        return n if math.isfinite(n) else default
    except (TypeError, ValueError):
        return default


def best(side, values):
    return max(values) if side == 1 else min(values)


def init_buffer(engine):
    engine.profit_marks714 = {}
    engine.profit_lock714 = threading.Lock()


def buffer_mark(engine, guard, row):
    """Called on the WS watchdog thread. Never mutate owned records or place orders."""
    if not enabled(engine.cfg) or not isinstance(row, dict):
        return
    mark = _number(row.get('markPx')); stamp = int(_number(row.get('ts')))
    now = engine.api.now_ms()
    if mark <= 0 or not 0 <= now - stamp <= 15000:
        return
    identity = guard['client_id']; side = 1 if guard['direction'] == 'long' else -1
    with engine.profit_lock714:
        old = engine.profit_marks714.get(identity)
        if old and stamp <= old['last_ms']:
            return
        peak = best(side, [mark, old['peak']]) if old else mark
        engine.profit_marks714[identity] = dict(peak=peak, last=mark, last_ms=stamp,
                                               entry=guard['avg_px'], side=side)
        if len(engine.profit_marks714) > 32:
            for key in sorted(engine.profit_marks714, key=lambda k: engine.profit_marks714[k]['last_ms'])[:-16]:
                engine.profit_marks714.pop(key, None)


def observe(engine, snapshot, position, owned):
    """Record actual observed marks even while partial fills/SL amendments are pending."""
    entry = _number(position.get('avgPx')); mark = _number(position.get('markPx'))
    lev = _number(owned.get('leverage')); side = 1 if owned['direction'] == 'long' else -1
    if min(entry, mark, lev) <= 0:
        return position
    now = engine.api.now_ms(); marks = [mark]; buf = None
    if hasattr(engine, 'profit_lock714') and owned.get('client_id'):
        with engine.profit_lock714:
            buf = engine.profit_marks714.pop(owned['client_id'], None)
    if (buf and 0 <= now - buf['last_ms'] and buf['last_ms'] >= int(owned.get('entry_ms') or 0)
            and buf['side'] == side and abs(_number(buf['entry']) - entry) <= entry * 1e-8):
        # An already validated historical observation is still a valid peak.
        # A stale last quote, however, must never replace the current snapshot.
        marks.append(buf['peak'])
        if now - buf['last_ms'] <= 15000:
            mark = buf['last']
            position = dict(position, markPx=str(mark))
    state = owned.setdefault('profit_state714', {})
    before = dict(state)
    # Never reconstruct a historical peak from candle highs/lows or a screenshot.
    prior = _number(state.get('peak_mark'), entry)
    peak = best(side, marks + [prior, entry])
    roe = max(0., (peak / entry - 1) * side * lev)
    state.update(peak_mark=peak, peak_roe=roe, entry=entry, side=side)
    # Latch only newly observed prices; do not turn a pre-upgrade historical peak into a new exit.
    observed_roe = max((v / entry - 1) * side * lev for v in marks)
    if observed_roe >= settings(engine.cfg)['full_take_profit_roe'] - 1e-10:
        state['partial_due721'] = True
    if observed_roe >= settings(engine.cfg)['partial_roe'] - 1e-10:
        state['partial_latched'] = True
    # Keep the pending replacement stop current while order reconciliation is busy.
    signal = owned.get('v4_signal', {})
    atr = _number(state.get('atr') or signal.get('atr') or
                  signal.get('decision_record', {}).get('volume_wick_proof', {}).get('atr'))
    target, why = desired_stop(owned, entry, side, atr, settings(engine.cfg))
    state.update(desired_stop=target, stop_reason=why)
    if state != before:
        state['observed_ms'] = now
        engine.journal.save()
    return position


def observe_snapshot(engine, snapshot, owned):
    """Capture before reconciliation can create a replacement SL from old values."""
    from okx_core import owned_position
    position = owned_position(owned, snapshot['positions'])
    if not position or not position.get('avgPx'):
        return snapshot, position
    updated = observe(engine, snapshot, position, owned)
    if updated is not position:
        snapshot = dict(snapshot, positions=[updated if p is position else p for p in snapshot['positions']])
    return snapshot, updated


def effective_stop(owned):
    side = 1 if owned['direction'] == 'long' else -1
    values = [_number(owned['stop_px'])]
    for v in (owned.get('target_stop_px'), owned.get('profit_guard705'),
              owned.get('profit_state714', {}).get('desired_stop')):
        n = _number(v)
        if n > 0:
            values.append(n)
    return best(side, values)


def _completed(engine, owned, now):
    from okx_channel701 import closed
    if not owned.get('symbol'):
        return [], {}
    bars = engine.chart_job(owned['symbol']) or {}
    try:
        return closed(bars.get('15m', []), now, required=15), bars
    except BotError:
        return [], bars


def _atr(owned, completed):
    from okx_band_flow import atr
    state = owned['profit_state714']
    if completed:
        value = atr(completed)
        if value > 0:
            state['atr'] = value
    signal = owned.get('v4_signal', {})
    return _number(state.get('atr') or signal.get('atr') or
                   signal.get('decision_record', {}).get('volume_wick_proof', {}).get('atr'))


def desired_stop(owned, entry, side, atr, policy):
    """Monotone cost floor, then volatility-aware runner; no optimistic candle peak."""
    state = owned['profit_state714']; old = effective_stop(owned)
    reason = state.get('stop_reason', '최초/구조 SL 유지')
    if not (state.get('partial_latched') or owned.get('partial_used')):
        proof=owned.get('v4_signal',{}).get('decision_record',{}).get('volume_wick_proof',{})
        peak=_number(state.get('peak_mark'),entry)
        cost_rate=max(.0017,_number(owned.get('cost_rate'))+.0007)
        floor=entry*(1+side*cost_rate)
        if (proof.get('early_lock725') and atr>0
                and _number(state.get('peak_roe'))>=.10-1e-10
                and (peak-entry)*side>=atr
                and (peak-floor)*side>=policy['minimum_gap_atr']*atr):
            target=best(side,[old,floor])
            if (target-old)*side>0:
                return target,'+10% 관측·1ATR 진행 확인 후 비용 포함 본전 보호'
        return old, reason
    cost_rate = max(.0017, _number(owned.get('cost_rate')) + .0007)
    floor = entry * (1 + side * cost_rate)
    target = best(side, [old, floor])
    if (floor - old) * side > 0:
        reason = '절반 청산 구간 · 비용 포함 본전 보호'
    peak = state['peak_mark']; lev = _number(owned.get('leverage'))
    if atr > 0 and state['peak_roe'] >= policy['runner_start_roe'] - 1e-10:
        allowance = max(policy['trail_atr'] * atr, entry * policy['minimum_trail_roe'] / lev)
        volatility = peak - side * allowance
        retained = entry + (peak - entry) * policy['peak_keep_fraction']
        # A volatility buffer prevents a tiny fixed giveback from hugging the peak.
        gap = max(policy['minimum_gap_atr'] * atr, entry * policy['minimum_gap_roe'] / lev)
        candidate = best(side, [volatility, retained])
        candidate = min(candidate, peak - gap) if side == 1 else max(candidate, peak + gap)
        if (candidate - target) * side > 0:
            target = candidate; reason = '최고 관측 수익 · ATR 여유를 둔 잔량 추적'
    return target, reason


def management(engine, snapshot, position, owned):
    if owned.get("phase", "active") != "active":return False
    now = engine.api.now_ms(); side = 1 if owned['direction'] == 'long' else -1
    mark = _number(position['markPx']); old = _number(owned['stop_px'])
    if (mark - old) * side <= 0:
        engine.close(snapshot, '거래소 보호 SL 도달'); return True
    if _number(position.get('avgPx')) <= 0 or _number(owned.get('leverage')) <= 0:
        return False
    position = observe(engine, snapshot, position, owned); mark = _number(position['markPx'])
    entry = _number(position['avgPx']); state = owned['profit_state714']; policy = settings(engine.cfg)
    if state.get('partial_due721') and not owned.get('partial_used') and not owned.get('partial_unsplittable'):
        engine.partial_close(snapshot, '+20% ROE 관측 · 최초 50% 익절', fraction=.5)
        return True
    if owned.get('entry_ms') and now - int(owned['entry_ms']) >= policy['max_hold_seconds'] * 1000:
        engine.close(snapshot, '보유 6시간 만료'); return True
    completed, frames = _completed(engine, owned, now)
    atr = _atr(owned, completed)
    if completed and state.get('analysis_bar_ms') != completed[-1][0]:
        from okx_pattern15 import summary, STEPS
        engine.events.put(('timeframes', dict(symbol=owned['symbol'], frames={
            f: summary([r for r in frames.get(f, []) if r[0] + step <= now])
            for f, step in STEPS.items()})))
        state['analysis_bar_ms'] = completed[-1][0]
        engine.journal.save()
    target, reason = desired_stop(owned, entry, side, atr, policy)
    if target != state.get('desired_stop') or reason != state.get('stop_reason'):
        state.update(desired_stop=target, stop_reason=reason)
        engine.journal.save()
    if (mark - target) * side <= 0:
        engine.close(snapshot, '관측 수익 보호선 이탈 · 잔여 청산 요청'); return True
    # Loss exits use completed closes, not a momentary wick or a fixed negative ROE.
    post = [r for r in completed if r[0] >= int(owned.get('entry_ms') or now)]
    from okx_progress724 import failed_progress
    if failed_progress(owned, post, mark, entry, side):
        engine.close(snapshot, '완료15분봉 4개 이후 추세 진행 부재·연속 손실 종가 확인'); return True
    proof = owned.get('v4_signal', {}).get('decision_record', {}).get('volume_wick_proof', {})
    from okx_entry722 import failure_level,confirmed_pivot
    edge = failure_level(proof,side)
    if edge > 0 and atr > 0 and len(post) >= 2 and (mark - entry) * side <= 0:
        failed = all((r[4] - edge) * side < -policy['false_break_buffer_atr'] * atr for r in post[-2:])
        if failed and (mark - edge) * side < -policy['false_break_buffer_atr'] * atr:
            engine.close(snapshot, '완료15분봉 2개로 '+proof.get('failure_kind722','돌파 실패')+' 확인'); return True
    # After a partial exit, only a completed directional break with volume is a reversal exit.
    if owned.get('partial_used') and atr > 0 and len(completed) >= 21 and post and (mark - entry) * side > 0:
        last = completed[-1]; prev = completed[-21:-1]
        mean = sum(r[5] for r in prev) / len(prev)
        local = min(r[3] for r in completed[-4:-1]) if side == 1 else max(r[2] for r in completed[-4:-1])
        if ((last[4] - last[1]) * side <= -policy['reversal_body_atr'] * atr
                and mean > 0 and last[5] >= policy['reversal_volume_ratio'] * mean
                and (last[4] - local) * side < 0 and (mark - local) * side < 0):
            engine.close(snapshot, '절반 청산 후 완료봉·거래량 동반 추세 반전 확인'); return True
    # Structural trailing uses a buffer and two post-entry closes, leaving normal pullbacks room.
    if len(post) >= 2 and atr > 0 and (mark - entry) * side > 0:
        level = (min(r[3] for r in completed[-10:]) - policy['structure_buffer_atr'] * atr
                 if side == 1 else max(r[2] for r in completed[-10:]) + policy['structure_buffer_atr'] * atr)
        if (mark - level) * side >= policy['minimum_gap_atr'] * atr and (level - target) * side > 0:
            target = level; reason = '완료10봉 구조 + ATR 완충 추적'
            state.update(desired_stop=target, stop_reason=reason); engine.journal.save()
    # After the first partial, protect a confirmed post-entry higher low/lower high.
    if owned.get('partial_used') and (mark-entry)*side>0:
        pivot=confirmed_pivot(post,side,atr)
        if pivot is not None and (pivot-target)*side>0 and (mark-pivot)*side>=policy['minimum_gap_atr']*atr:
            target=pivot;reason='절반 익절 후 확인된 저점·고점 구조 보호'
            state.update(desired_stop=target,stop_reason=reason);engine.journal.save()
    if (target - old) * side <= 0:
        return False
    first_floor = not owned.get('guard714_amend_ms')
    if not first_floor:
        if now - owned['guard714_amend_ms'] < min(policy['amendment_seconds'], getattr(engine,'guard_amend_seconds',policy['amendment_seconds'])) * 1000:
            return False
        if atr > 0 and abs(target - old) < policy['amendment_step_atr'] * atr:
            return False
    engine.trail(snapshot, position, owned, target)
    owned['guard714_amend_ms'] = now
    engine.journal.save()
    return True


def take_profit_due(owned):
    return False  # Full take-profit retired in V721.

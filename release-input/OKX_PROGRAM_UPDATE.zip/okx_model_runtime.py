"""Model-specific Responses calls and one shared, separately classified budget."""
import json,time,uuid
from okx_core import BotError,day_key
DEFAULTS=dict(model='gpt-6.1-sol',reasoning_effort='low',max_output_tokens=2048,
 timeout_seconds=25,input_per_million=2.,cached_input_per_million=.1,output_per_million=10.,max_daily_budget=200.)

def settings(c):return dict(DEFAULTS,**c.get('execution',{}).get('model_runtime',{}))
def enabled(c):return 'model_runtime' in c.get('execution',{})
def validate(p):
 return (p['model']=='gpt-6.1-sol' and p['reasoning_effort'] in ('low','medium','high')
  and type(p['max_output_tokens']) is int and 1024<=p['max_output_tokens']<=8192 and 10<=p['timeout_seconds']<=60
  and p['input_per_million']==2 and p['cached_input_per_million']==.1 and p['output_per_million']==10
  and 2<=p['max_daily_budget']<=200)

def usage_cost(usage,p):
 details=getattr(usage,'input_tokens_details',None);cached=int(getattr(details,'cached_tokens',0) or 0)
 inputs=int(usage.input_tokens);outputs=int(usage.output_tokens)
 if min(inputs,outputs,cached)<0 or cached>inputs:raise BotError('API 토큰 사용량 형식 오류')
 return ((inputs-cached)*p['input_per_million']+cached*p['cached_input_per_million']+outputs*p['output_per_million'])/1e6

def request(engine,payload,instructions,schema,channel,epoch=None):
 if engine.cfg.get("execution",{}).get("rule_channel701"):raise BotError("규칙 전용 모드: 유료 AI 호출 비활성화")
 from openai import OpenAI
 p=settings(engine.cfg)
 if channel=='auto_entry' and payload.get('mode')=='ENTRY':
  now=engine.api.now_ms()
  candidates=[v for v in payload.get('candidates',[]) if 0<=now-v.get('frames',{}).get('1m',{}).get('completed_ms',0)<=40000]
  if not candidates:raise BotError('AI 호출 전 파동 자료 만료: 유료 호출 보류')
  payload=dict(payload,candidates=candidates)
 text=json.dumps(payload,ensure_ascii=False,separators=(',',':'),allow_nan=False)
 if len(text)>30000:raise BotError('AI 자료 크기 초과: 유료 호출 보류')
 # Byte count is a conservative pre-call token bound, not an actual token measurement.
 reserve=((len(text.encode())+len(instructions.encode())+4096)*p['input_per_million']+p['max_output_tokens']*p['output_per_million'])/1e6
 with engine.lock:
  if channel=='auto_entry' and not engine.can_open_position():raise BotError('포지션2개 보유·신규 진입 유료 호출 취소')
  now=engine.api.now_ms();today=day_key(now);data=engine.journal.data
  if channel!='chat' and (epoch!=engine.epoch or not (engine.enabled or engine.preview or engine.records())):raise BotError('상태 변경: AI 호출 취소')
  from okx_shared_budget import read as shared_read
  shared_read(engine)
  from okx_budget_pacing import guard as pace_guard
  pace_guard(engine,reserve,channel)
  if channel=='chat':
   if data['api_day']!=today:data.update(api_day=today,api_spent=0.,api_calls=0)
   if data['api_spent']+reserve>engine.budget:raise BotError('AI 하루 공용 예산 부족: 설정에서 예산을 확인하세요.')
   data['api_spent']+=reserve;data['api_total_spent']+=reserve;data['api_calls']+=1
  else:today=engine.reserve_api(reserve,epoch)
  item=dict(id=uuid.uuid4().hex,ms=now,day=today,channel=channel,model=p['model'],cost=reserve,status='reserved',input_tokens=None,output_tokens=None)
  data.setdefault('model_usage',[]).append(item);data['model_usage']=data['model_usage'][-10000:];engine.journal.save()
  from okx_shared_budget import write as shared_write
  shared_write(engine)
 timeout=p['timeout_seconds']
 if channel=='auto_entry' and payload.get('mode')=='ENTRY':timeout=max(5,min(timeout,(60000-engine.api.now_ms()%60000)/1000-7))
 try:
  client=OpenAI(api_key=engine.settings.get('OPENAI_API_KEY'),max_retries=0,timeout=timeout)
  r=client.responses.create(model=p['model'],reasoning={'effort':p['reasoning_effort']},max_output_tokens=p['max_output_tokens'],service_tier='default',store=False,
   instructions=instructions,input=text,text={'format':{'type':'json_schema','name':'bot_reply','strict':True,'schema':schema}})
  cost=usage_cost(r.usage,p)
  with engine.lock:
   d=engine.journal.data;d['api_total_spent']+=cost-reserve
   if d['api_day']==today:d['api_spent']+=cost-reserve
   item.update(cost=cost,status='billed',input_tokens=r.usage.input_tokens,output_tokens=r.usage.output_tokens)
   from okx_budget_pacing import settle as pace_settle
   pace_settle(engine,reserve,cost,channel)
   engine.journal.save();shared_write(engine)
  if getattr(r,'status','completed')!='completed' or not r.output_text:raise BotError('AI 응답 미완료: 추론/출력 한도 또는 응답 상태 확인. 자동 주문 없음.')
  result=json.loads(r.output_text)
  result.update(cost=cost,reserved=reserve,billing_day=today,completed=time.monotonic(),accounted=True)
  return result
 except Exception as error:
  with engine.lock:
   if item['status']=='reserved':item['status']='charge_unknown';engine.journal.save();shared_write(engine)
  if isinstance(error,BotError):raise
  safe=str(error)
  for value in engine.settings.values():
   if isinstance(value,str) and len(value)>8:safe=safe.replace(value,'[숨김]')
  raise BotError('AI API 요청 실패: '+safe[:300]) from None

def summary(engine):
 now=engine.api.now_ms();day=day_key(now);all_rows=engine.journal.data.get('model_usage',[])
 today=[r for r in all_rows if r['day']==day];hour=[r for r in all_rows if now-3600000<=r['ms']<=now]
 total=sum(r['cost'] for r in today);actual=sum(r['cost'] for r in today if r['status']=='billed')
 channels={k:sum(r['cost'] for r in today if r['channel']==k) for k in ('auto_entry','auto_manage','chat')}
 return dict(model=settings(engine.cfg)['model'],hour_calls=sum(r['status']!='carried' for r in hour),hour_cost=sum(r['cost'] for r in hour),hour_billed_cost=sum(r['cost'] for r in hour if r['status']=='billed'),hour_unknown_reserve=sum(r['cost'] for r in hour if r['status']!='billed'),day_calls=sum(r['status']!='carried' for r in today),
  day_recorded_cost=total,day_billed_cost=actual,day_unconfirmed_reserve=total-actual,channels=channels,
  prior_unclassified=max(0,engine.journal.data.get('api_spent',0)-total),day_budget=engine.budget,
  hourly_projection_24h=sum(r['cost'] for r in hour)*24)

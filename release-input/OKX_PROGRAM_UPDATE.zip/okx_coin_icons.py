"""Bundled local PNG icons; unavailable assets use a symbol badge. No network."""
from pathlib import Path
import tkinter as tk
ROOT=Path(__file__).resolve().parent/'assets'/'coin_icons'
def base(symbol):return str(symbol).split('-')[0].split('/')[0].upper()
class CoinIcons:
 def __init__(self,master):self.master=master;self.cache={}
 def get(self,symbol):
  name=base(symbol)
  if not name.isalnum():return None
  if name not in self.cache:
   try:self.cache[name]=tk.PhotoImage(master=self.master,file=str(ROOT/(name.lower()+'.png')))
   except (tk.TclError,OSError):self.cache[name]=None
  return self.cache[name]
 def draw(self,canvas,x,y,symbol):
  image=self.get(symbol)
  if image is not None:canvas.create_image(x,y,image=image)
  else:
   canvas.create_oval(x-14,y-14,x+14,y+14,fill='#21352f',outline='#37604f')
   canvas.create_text(x,y,text=base(symbol)[:2],fill='#d7f7e9',font=('TkDefaultFont',-11,'bold'))

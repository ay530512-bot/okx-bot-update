"""Read-only OKX funding preview. No order, entry gate or strategy mutations.

OKX fundingRate applies to fundingTime (the upcoming settlement), not the later
nextFundingTime. Estimates use target margin * manual leverage, BEFORE lot
rounding and future mark-price changes; they are not booked PnL.
"""
import math
import threading
import time
from datetime import datetime, timedelta, timezone

KST = timezone(timedelta(hours=9))
CACHE_MS = 60000
SOURCE_MS = 180000
MANUAL_LEVERAGE = 5


def number(value):
    if value is None or value == '' or isinstance(value, bool):
        raise ValueError('missing number')
    n = float(value)
    if not math.isfinite(n):
        raise ValueError('nonfinite number')
    return n


def parse(rows, symbol, now):
    row = next((r for r in rows if r.get('instId') == symbol), None)
    if row is None or not symbol.endswith('-USDT-SWAP'):
        raise ValueError('funding instrument mismatch')
    if row.get('method') not in (None, '', 'current_period'):
        raise ValueError('unsupported funding method')
    rate = number(row.get('fundingRate'))
    settlement = int(number(row.get('fundingTime')))
    source = int(number(row.get('ts')))
    if not 0 <= now-source <= SOURCE_MS or not now < settlement <= now+86400000:
        raise ValueError('stale funding or settlement')
    try:
        interval = int(number(row.get('nextFundingTime')))-settlement
        if not 0 < interval <= 86400000:interval = None
    except (ValueError, TypeError, OverflowError):interval = None
    return dict(symbol=symbol, rate=rate, settlement_ms=settlement,
                source_ms=source, observed_ms=now, interval_ms=interval)


def evaluate(record, now):
    out = dict(record or {})
    out.update(as_of_ms=now, usable=False, valid_for_ms=0)
    if not record or record.get('error'):
        out['reason'] = (record or {}).get('error') or '펀딩 자료 조회 중 · 0원으로 간주하지 마세요.'
        return out
    left = min(CACHE_MS-(now-record['observed_ms']),
               SOURCE_MS-(now-record['source_ms']), record['settlement_ms']-now)
    if now < record['source_ms'] or now < record['observed_ms']:
        out['reason'] = '펀딩 시간 확인 중 · 예상액 미표시'
    elif now >= record['settlement_ms']:
        out['reason'] = '정산 시각 경과 · 새 펀딩률 확인 중 · 이전 예상액 미표시'
    elif left <= 0:
        out['reason'] = '펀딩 자료 지연 · 새 값 확인 중 · 예상액 미표시'
    else:
        out.update(usable=True, valid_for_ms=left,
                   remaining_ms=record['settlement_ms']-now, reason='')
    return out


def preview(snapshot, margin, leverage=MANUAL_LEVERAGE):
    if not snapshot or not snapshot.get('usable'):return None
    try:
        margin, leverage = number(margin), number(leverage)
        if margin <= 0 or leverage <= 0:return None
        notional = margin*leverage
        fee = notional*number(snapshot['rate'])
        if not math.isfinite(fee) or not math.isfinite(notional):return None
    except (KeyError, ValueError, TypeError, OverflowError):return None
    return dict(margin=margin, leverage=leverage, notional=notional,
                long_cashflow=-fee, short_cashflow=fee)


def describe(snapshot, margin=None):
    if not snapshot or not snapshot.get('usable'):
        return '펀딩비 · '+str((snapshot or {}).get('reason') or '종목 선택 후 조회합니다.')
    r = snapshot['rate'];seconds = max(0, int(snapshot['remaining_ms']/1000))
    stamp = datetime.fromtimestamp(snapshot['settlement_ms']/1000,KST).strftime('%m/%d %H:%M:%S')
    interval = snapshot.get('interval_ms')
    cadence = f" · 현재 {interval/3600000:g}시간 간격" if interval else ' · 정산 간격 미확인'
    lines = [f'다음 1회 예상 펀딩률 {r*100:+.5f}%',
             f'정산 {stamp} KST · 남은 {seconds//3600:02}:{seconds//60%60:02}:{seconds%60:02}'+cadence]
    p = preview(snapshot, margin)
    if p:
        lines.append(f"목표 증거금 {p['margin']:.2f} × 수동 {p['leverage']:g}배 = 추정 명목금액 {p['notional']:.2f} USDT")
        def flow(label, value):
            action = '수취' if value > 0 else '지급' if value < 0 else '지급·수취 없음'
            return f"{label} {action} {abs(value):.6f} USDT (증거금 대비 {value/p['margin']*100:+.4f}%)"
        lines.append(flow('롱',p['long_cashflow'])+' / '+flow('숏',p['short_cashflow']))
    else:
        lines.append(('양수: 롱 지급 / 숏 수취' if r>0 else '음수: 롱 수취 / 숏 지급' if r<0 else '현재 예상률 0%')+' · 증거금 확인 전 예상액 미산정')
    age = max(0,int((snapshot['as_of_ms']-snapshot['source_ms'])/1000))
    lines += [f'거래소 자료 {age}초 전 · 정산 시 보유할 때 적용되는 1회 예상치',
              '진입 전 목표금액 기준 · 계약 수량 반올림·부분청산·마크가격·펀딩률 변동으로 실제 금액은 달라집니다.',
              '6시간 누적비용 아님 · 아래 TP/SL 손익 예시에는 펀딩 미포함']
    return '\n'.join(lines)


class FundingFeed:
    """Separate lazy worker: slow public data never blocks chart/order/UI threads."""
    def __init__(self, settings, api_factory=None):
        self.settings=dict(settings);self.factory=api_factory
        self.condition=threading.Condition();self.symbol=None;self.closed=False
        self.thread=None;self.cache={};self.last={};self.anchor=None

    def select(self, symbol):
        with self.condition:
            if self.closed:return
            if symbol != self.symbol:self.symbol=symbol;self.condition.notify_all()
            if symbol and self.thread is None:
                self.thread=threading.Thread(target=self.run,daemon=True,name='readonly-funding')
                self.thread.start()

    def snapshot(self, symbol):
        with self.condition:
            now = int(self.anchor[0]+(time.monotonic()-self.anchor[1])*1000) if self.anchor else int(time.time()*1000)
            return evaluate(self.cache.get(symbol), now)

    def stop(self):
        with self.condition:self.closed=True;self.condition.notify_all()

    def run(self):
        api=None
        try:
            while True:
                with self.condition:
                    if self.closed:return
                    symbol=self.symbol
                    if not symbol:self.condition.wait(1);continue
                    cached=self.snapshot(symbol)
                    interval=5 if cached.get('usable') and cached['remaining_ms']<60000 else 15
                    remaining=interval-(time.monotonic()-self.last.get(symbol,-1e20))
                    if remaining>0:self.condition.wait(min(remaining,1));continue
                    self.last[symbol]=time.monotonic()
                try:
                    if str(self.settings.get('TRADING_EXCHANGE') or 'okx').lower()!='okx':
                        raise ValueError('OKX funding preview only')
                    if api is None:
                        from okx_core import OKX
                        api=(self.factory or OKX)(self.settings)
                    rows=api.public('/api/v5/public/funding-rate',instId=symbol)
                    now=api.now_ms();record=parse(rows,symbol,now);anchor=(now,time.monotonic())
                except Exception:
                    # Do not re-stamp old values as fresh or expose raw API errors.
                    record=dict(symbol=symbol,error='펀딩 조회 실패 또는 정산 전환 중 · 자동 재조회 · 예상액 미표시')
                    anchor=None
                with self.condition:
                    if self.closed:return
                    self.cache[symbol]=record
                    if anchor:self.anchor=anchor
                    if len(self.cache)>8:
                        first=next(k for k in self.cache if k!=symbol)
                        self.cache.pop(first);self.last.pop(first,None)
        finally:
            if api:api.session.close()

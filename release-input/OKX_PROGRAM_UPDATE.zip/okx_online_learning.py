"""Online, outcome-based setup ranking. No model weights or risk limits are changed."""
import json,math
from collections import defaultdict,deque
from pathlib import Path
MIN_SAMPLES=20

def key(setup,frame,direction):return '|'.join((str(setup),str(frame),str(direction)))

def fit(rows):
 groups=defaultdict(lambda:deque(maxlen=200));seen=set();accepted=0
 for row in rows:
  identity=row.get('client_id');meta=row.get('learning') or {}
  if not identity or identity in seen or row.get('source') not in ('auto','manual') or not meta.get('setup'):continue
  try:
   pnl=float(row['realizedPnl']);risk=float(row.get('learning_risk_usdt') or (row.get('estimated_loss') if row.get('source')=='manual' else 0))
   if not math.isfinite(pnl) or not math.isfinite(risk) or risk<=0:continue
  except (KeyError,ValueError,TypeError):continue
  seen.add(identity);accepted+=1
  groups[('manual|' if row.get('source')=='manual' else '')+key(meta['setup'],meta.get('frame'),row.get('direction'))].append(max(-5.,min(5.,pnl/risk)))
 stats={}
 for name,values in groups.items():
  n=len(values);total=sum(values);wins=sum(v>0 for v in values)
  # Zero-mean ten-observation prior shrinks small-sample estimates.
  expected=total/(n+10);mean=total/n;variance=sum((v-mean)**2 for v in values)/max(1,n-1)
  uncertainty=1.96*math.sqrt(variance/n) if n>1 else None
  ready=n>=MIN_SAMPLES
  stats[name]=dict(samples=n,wins=wins,smoothed_win_rate=(wins+2)/(n+4),expected_net_r=expected,mean_net_r=mean,uncertainty_approx=uncertainty,
   ready=ready,priority_adjustment=max(-.5,min(.5,expected)) if ready else 0.)
 return dict(version=2,accepted_trades=accepted,min_samples=MIN_SAMPLES,groups=stats,
  policy='Automatic rows missing original structural-risk denominator are excluded from normalized ranking, but retained for quality review. Final attributed automatic/manual results, separate groups; net fees/funding included, AI cost excluded. Clipped net R, rolling200 per setup/frame/direction. Ranking only; never removes protection or forces orders. Observational selection bias; not proof of profitability.')

def refresh(engine):
 path=Path(engine.root)/'position_results.jsonl'
 try:signature=(path.stat().st_mtime_ns,path.stat().st_size)
 except OSError:signature=None
 manual=Path(engine.root)/'manual_learning_results.json'
 try:manual_sig=(manual.stat().st_mtime_ns,manual.stat().st_size)
 except OSError:manual_sig=None
 market,_=engine.universe.read() if hasattr(engine,'universe') else (None,None)
 signature=(signature,manual_sig,(market or {}).get('completed'))
 if getattr(engine,'_learning_signature',object())==signature:return engine._learning_state
 rows=[]
 if signature[0]:
  with path.open(encoding='utf-8') as stream:
   for line in stream:
    try:rows.append(json.loads(line))
    except (ValueError,TypeError):continue
 try:
  rows.extend(json.loads(manual.read_text(encoding='utf-8')))
 except (OSError,ValueError,TypeError):pass
 from okx_learning_history import record
 from okx_trade_quality import enrich,feedback
 rows=enrich(engine,rows)
 state=fit(rows)
 from okx_structure694 import fit as structure_fit
 state['groups694']=structure_fit(rows)
 state['structure_revision']=694
 state['quality_feedback']=feedback(rows)
 state['quality_review']=[dict(source=r.get('source'),setup=(r.get('learning') or {}).get('setup'),analysis=r['quality_analysis']) for r in rows if r.get('quality_analysis')][-50:]
 try:record(engine.root,rows,state,engine.api.now_ms())
 except Exception:pass
 engine._learning_signature=signature;engine._learning_state=state
 destination=Path(engine.root)/'online_learning_state.json';temporary=destination.with_suffix('.tmp')
 try:temporary.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8');temporary.replace(destination)
 except OSError:pass
 return state

def annotate(packet,state):
 from okx_volume_entry import evidence
 scores=[];learned=[]
 for frame,data in packet['frames'].items():
  for action,direction in [('LONG','long'),('SHORT','short')]:
   try:proof=evidence(data,action,packet['price'])
   except Exception:continue
   name=key(proof['setup'],frame,direction);stats=state['groups'].get(name,dict(samples=0,ready=False,priority_adjustment=0.))
   manual=state['groups'].get('manual|'+name,dict(samples=0,ready=False,priority_adjustment=0.))
   learned.append(dict(setup=proof['setup'],frame=frame,direction=direction,manual_reference=manual,**stats))
   scores.append(stats['priority_adjustment']+.3*manual['priority_adjustment'])
 matching=[(k,v) for k,v in state.get('quality_feedback',{}).items() if any(x.get('setup')==k.split('|')[1] for x in learned) and len(k.split('|'))>=4]
 matching.sort(key=lambda item:item[1].get('samples',0),reverse=True)
 packet['outcome_learning']=dict(quality_feedback=dict(matching[:6]),quality_review=state.get('quality_review',[])[-2:],setups=learned,min_samples=MIN_SAMPLES,note='Historical outcome feedback, not a forecast or an instruction. Small samples have neutral priority.')
 return max(scores,default=0.)

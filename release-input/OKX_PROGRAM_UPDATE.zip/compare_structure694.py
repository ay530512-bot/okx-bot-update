"""Offline causal comparison of four local-rule variants, NOT a historical LLM backtest.
python compare_structure694.py candles.json --output comparison694.json
Input: symbol, fee_rate, spread_rate, slippage_rate, candles:{15m,1H,4H}, optional funding:[{ms,rate}].
Rows [UTC_ms,open,high,low,close,volume], ascending. Fees/rates are explicit fractions.
"""
import argparse,json,math,statistics,queue
from pathlib import Path
from types import SimpleNamespace as NS
from okx_structure694 import setups,select_regime,entry_window,fit,learning_adjust,management
from okx_pattern15 import legacy_setups,legacy_management,STEPS,major_direction,summary
from okx_band_flow import view
from apply_autonomous_update import autonomous_config

def validate(d):
 for k in ('fee_rate','spread_rate','slippage_rate'):
  if k not in d or not isinstance(d[k],(float,int)) or not math.isfinite(d[k]) or d[k]<0:raise ValueError(k+' explicit nonnegative fraction required')
 for f,step in STEPS.items():
  for j,r in enumerate(d['candles'][f]):
   if len(r)!=6 or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in r) or min(r[1:5])<=0 or r[5]<0 or not r[3]<=min(r[1],r[4])<=max(r[1],r[4])<=r[2]:raise ValueError('invalid OHLCV '+f)
   if j and r[0]-d['candles'][f][j-1][0]!=step:raise ValueError('missing/duplicate candle '+f)
 if len(d['candles']['15m'])<300:raise ValueError('at least300 completed15m bars required')
 for r in d.get('funding',[]):
  if any(k not in r or not isinstance(r[k],(float,int)) or not math.isfinite(r[k]) for k in ('ms','rate')):raise ValueError('funding invalid')

def simulate(d,c,entry_mode,exit_mode,start,end):
 bars=d['candles']['15m'];equity=1000.;peak=equity;dd=0.;trades=[];o=None;pending=None;fee=d['fee_rate'];friction=d['spread_rate']/2+d['slippage_rate'];symbol=d.get('symbol','ALT-USDT-SWAP');now=0;frames={};actions=[];skips=0
 e=NS(cfg=c,events=queue.Queue(),journal=NS(save=lambda:None),api=NS(now_ms=lambda:now),chart_job=lambda s:frames)
 e.close=lambda snap,reason:actions.append(('CLOSE',None,reason));e.partial_close=lambda snap,reason,**kw:actions.append(('PARTIAL',kw.get('fraction',.5),reason));e.trail=lambda snap,p,o,value:actions.append(('TRAIL',value,'structure trail'))
 def close(qty,price,reason):
  nonlocal equity,o
  px=price*(1-o['side']*friction);pnl=qty*(px-o['entry'])*o['side']-qty*px*fee;equity+=pnl;o['pnl']+=pnl;o['qty']-=qty
  if o['qty']<=1e-10:
   v=o['v4_signal']['decision_record']['volume_wick_proof'];trades.append(dict(client_id=str(o['entry_ms']),source='auto',symbol=symbol,direction=o['direction'],end_ms=now,realizedPnl=o['pnl'],learning_risk_usdt=o['risk'],learning={'setup':v['setup'],'frame':'15m','key694':v.get('learning_key')},observed_excursion=o.get('observed_excursion',{}),entry=o['entry'],exit=px,reason=reason));o=None
 for j in range(max(260,start),min(end,len(bars))):
  bar=bars[j];now=bar[0];actions.clear()
  if pending and not o:
   v=pending;pending=None;side=1 if v['action']=='LONG' else -1;px=bar[1]*(1+side*friction)
   if entry_mode=='confirmed' and not entry_window(v,px):skips+=1
   elif (px-v['structural_stop'])*side>0:
    qty=min(equity*.005*.9/(abs(px-v['structural_stop'])+2*px*fee),equity/3*10/px);cost=qty*px*fee;equity-=cost;o=dict(symbol=symbol,direction='long' if side==1 else 'short',side=side,entry=px,entry_ms=now,qty=qty,stop_px=v['structural_stop'],holding_rule={'target':v['target']},risk=qty*abs(px-v['structural_stop']),pnl=-cost,v4_signal={'stop':v['structural_stop'],'setup_frame':'15m','decision_record':{'volume_wick_proof':v}})
  if o:
   side=o['side'];stop=float(o['stop_px'])
   for f in d.get('funding',[]):
    if now<=f['ms']<now+900000:cost=-o['qty']*bar[4]*f['rate']*side;equity+=cost;o['pnl']+=cost
   if bar[3]<=stop if side==1 else bar[2]>=stop:close(o['qty'],min(bar[1],stop) if side==1 else max(bar[1],stop),'structural stop')
  now=bar[0]+900000;frames={f:[r for r in d['candles'][f] if r[0]+step<=now][-300:] for f,step in STEPS.items()}
  if o:
   p=dict(markPx=str(bar[4]),avgPx=str(o['entry']),uplRatio=str((bar[4]/o['entry']-1)*o['side']*10));(management if exit_mode=='structure' else legacy_management)(e,{},p,o)
   for action,value,reason in actions:
    if not o:break
    if action=='TRAIL':o['stop_px']=value
    elif action=='PARTIAL':close(o['qty']*value,bar[4],reason);o and o.update(partial_used=True)
    else:close(o['qty'],bar[4],reason)
  marked=equity+(o['qty']*(bar[4]-o['entry'])*o['side'] if o else 0);peak=max(peak,marked);dd=max(dd,(peak-marked)/peak)
  if not o and len(frames['15m'])>=242 and all(len(frames[f])>=24 for f in STEPS):
   b=frames['15m'];atr=view(b,c)['atr'];vs=setups(b,atr,0,c) if entry_mode=='confirmed' else legacy_setups(b,atr)
   if entry_mode=='confirmed':
    packet=select_regime({'entry_setups':vs},{'live_frames':frames});learning_adjust(packet,{'groups694':fit(trades)},c);vs=sorted(packet['entry_setups'],key=lambda v:(-v.get('learned_priority',0),v['priority']))
   if symbol.split('-')[0] in ('BTC','ETH','SOL'):vs=[v for v in vs if major_direction({f:{'analysis':summary(frames[f])} for f in STEPS},v['action'])]
   if vs:pending=vs[0]
 if o:close(o['qty'],bars[min(end,len(bars))-1][4],'end of evaluation window')
 wins=[r['realizedPnl'] for r in trades if r['realizedPnl']>0];losses=[r['realizedPnl'] for r in trades if r['realizedPnl']<0]
 return dict(trades=len(trades),net_usdt=equity-1000,max_drawdown_fraction=dd,net_expectancy_usdt=(equity-1000)/len(trades) if trades else None,win_rate=len(wins)/len(trades) if trades else None,average_win=statistics.mean(wins) if wins else None,average_loss=statistics.mean(losses) if losses else None,profit_factor=sum(wins)/abs(sum(losses)) if losses else None,skipped_entry_window=skips,results=trades)

def compare(d,c):
 validate(d);n=len(d['candles']['15m']);folds=[]
 for a,b in ((.6,.8),(.8,1.)):
  start=max(260,int(n*a));end=int(n*b)
  if end>start:folds.append(dict(start_index=start,end_index=end,variants={entry+'_'+exit:simulate(d,c,entry,exit,start,end) for entry in ('legacy','confirmed') for exit in ('legacy','structure')}))
 return dict(status='offline_local_rule_comparison_not_profit_certification',capital_per_fold=1000,common_leverage=10,common_risk_fraction=.005,margin_cap=1/3,parameters_frozen=True,costs={k:d[k] for k in ('fee_rate','spread_rate','slippage_rate')},funding='provided' if d.get('funding') else 'NOT PROVIDED: excluded',folds=folds,limitations=['Local rules only, not historical LLM decisions.','All variants use common risk sizing/10x to isolate entry and exit.','Signals at closed bar; fill next open; ambiguous stop before target.','No orderbook queue, historical spreads or delisting universe modeled.','Two chronological holdouts, no parameter tuning, no proof of profitability.','AI operating cost excluded; add actual allocated API spend to economic evaluation.'])
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('--output',default='comparison694.json');a=p.parse_args();c=autonomous_config(json.loads(Path(__file__).with_name('strategy_config.default.json').read_text(encoding='utf-8-sig')));d=json.loads(Path(a.input).read_text(encoding='utf-8-sig'));Path(a.output).write_text(json.dumps(compare(d,c),ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8');print(a.output)

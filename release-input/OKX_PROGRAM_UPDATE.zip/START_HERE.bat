@echo off
setlocal
cd /d "%~dp0"
set "BOT_PY=.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=..\.venv\Scripts\python.exe"
if not exist "%BOT_PY%" (
 echo Place AI_FREE_5X inside your existing OKX_BOT folder.
 pause
 exit /b 1
)
"%BOT_PY%" apply_autonomous_update.py
if errorlevel 1 (
 pause
 exit /b 1
)
"%BOT_PY%" okx_bot.py
pause

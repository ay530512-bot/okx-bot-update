"""Deterministic evidence checks for new entries, never for existing stops."""
from okx_core import BotError

def wick_evidence(frame,action,price):
 side=1 if action=='LONG' else -1
 hint=frame.get('chart_evidence',{}).get('volume_wick',{})
 if not hint.get('long_candidate' if side==1 else 'short_candidate'):
  raise BotError('거래량 동반 긴 꼬리·회복/거절 확인 없음')
 if float(hint.get('relative_volume') or 0)<2:raise BotError('자체 직전20봉 대비 거래량 2배 미만')
 bars=frame.get('recent',[])
 if len(bars)<3:raise BotError('꼬리 전후 흐름 자료 부족')
 last=bars[-1]
 if hint.get('signal_ms')!=last[0]:raise BotError('최신 확정봉 꼬리 증거 불일치')
 atr=float(frame['atr']);span=float(last[2])-float(last[3]);close=float(last[4])
 if atr<=0 or span<=0:raise BotError('변동성 자료 오류')
 # Require live retention of the recovery, and reject already extended entries.
 if (price-close)*side < -.15*atr:raise BotError('꼬리 회복/거절이 현재 시세에서 유지되지 않음')
 if (price-close)*side > .5*atr:raise BotError('꼬리 확인 가격에서 이미 추격 구간')
 buffer=max(.25*atr,price*.001)
 extreme=float(last[3] if side==1 else last[2])
 stop=extreme-side*buffer
 return dict(signal_ms=last[0],relative_volume=hint['relative_volume'],structural_stop=stop,frame_close=close)

def has_setup(packet):
 for frame in packet['frames'].values():
  for action in ('LONG','SHORT'):
   try:evidence(frame,action,packet['price']);return True
   except (BotError,ValueError,KeyError,TypeError):pass
 return False


def trend_setups(bars,atr):
 """Completed-bar MA200 break followed by a held, higher/lower pullback."""
 result={}
 if len(bars)<205 or atr<=0:return result
 def avg(i,n):return sum(float(r[4]) for r in bars[i-n+1:i+1])/n
 end=len(bars)-1
 for action,side in [('LONG',1),('SHORT',-1)]:
  crosses=[i for i in range(max(200,end-30),end-2) if (float(bars[i-1][4])-avg(i-1,200))*side<=0 and (float(bars[i][4])-avg(i,200))*side>0]
  if not crosses:continue
  cross=crosses[-1];last=bars[-1];recent=bars[-3:]
  line=avg(end,200)
  if (float(last[4])-line)*side<=0 or (line-avg(end-3,200))*side<0:continue
  # A rally/decline must precede a pullback; the pullback must preserve its prior low/high.
  pre=bars[max(0,cross-8):cross+1];leg=bars[cross:end-2]
  if not leg:continue
  extreme=(min if side==1 else max)(float(r[3 if side==1 else 2]) for r in recent)
  prior=(min if side==1 else max)(float(r[3 if side==1 else 2]) for r in pre)
  if (extreme-prior)*side<=0:continue
  peak=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in leg)
  if (peak-extreme)*side<.5*atr:continue
  supported=[]
  for n in (15,20,50,200):
   level=avg(end,n)
   if abs(extreme-level)<=.6*atr and (float(last[4])-level)*side>=0 and (level-avg(end-3,n))*side>=0:supported.append(n)
  if not supported or (float(last[4])-float(bars[-2][4]))*side<=0:continue
  result[action]=dict(signal_ms=last[0],pullback_extreme=extreme,prior_extreme=prior,ma200=line,support_ma=supported,frame_close=float(last[4]),setup='ma200_pullback')
 return result

def prior_evidence(frame,action,price):
 try:
  proof=wick_evidence(frame,action,price);proof['setup']='volume_wick';return proof
 except BotError:pass
 side=1 if action=='LONG' else -1
 proof=frame.get('trend_setups',{}).get(action)
 if not proof:raise BotError('거래량 꼬리 또는 MA200 돌파 후 지지/저항 확인 대기')
 last=frame['recent'][-1];atr=float(frame['atr']);close=float(proof['frame_close'])
 if proof['signal_ms']!=last[0]:raise BotError('눌림목 증거 만료')
 if not -.15*atr <= (price-close)*side <= .5*atr:raise BotError('눌림 회복 실패 또는 추격 구간')
 extreme=float(proof['pullback_extreme'])
 if (price-extreme)*side<=0:raise BotError('눌림 저점/반등 고점 이탈')
 return dict(proof,structural_stop=extreme-side*max(.25*atr,price*.001))


def structure_evidence(frame,action,price):
 side=1 if action=='LONG' else -1
 h=frame.get('chart_evidence',{});b=frame.get('recent',[]);atr=float(frame.get('atr') or 0)
 if len(b)<5 or atr<=0:raise BotError('연속 봉 자료 부족')
 sequence=h.get('sequence_support_long' if side==1 else 'sequence_resistance_short',{})
 labels=[]
 if h.get('failed_low_recovery' if side==1 else 'failed_high_rejection'):labels.append('failed_extreme_recovery')
 if h.get('support_pullback_recovery' if side==1 else 'resistance_pullback_rejection'):labels.append('trend_ma_retest')
 if sequence.get('reversal_held') or sequence.get('trend_pullback_held'):labels.append('sequence_held_retest')
 # Break of the preceding local range, followed by a later retest and recovery.
 level=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in b[:-3])
 if (float(b[-3][4])-level)*side>0 and abs(float(b[-2][3 if side==1 else 2])-level)<=.5*atr and (float(b[-1][4])-level)*side>0 and (float(b[-1][4])-float(b[-2][4]))*side>0:labels.append('breakout_retest')
 if not labels:raise BotError('지지·저항·돌파 재시험 증거 없음')
 if h.get('falling_without_recovery' if side==1 else 'rising_without_rejection'):raise BotError('반대 추세 회복/거절 미확인')
 close=float(b[-1][4])
 if not -.15*atr<=(price-close)*side<=.5*atr:raise BotError('구조 회복 실패 또는 추격 구간')
 extreme=(min if side==1 else max)(float(r[3 if side==1 else 2]) for r in b[-3:])
 if (price-extreme)*side<=0:raise BotError('구조 무효화 가격 이탈')
 return dict(setup=labels[0],alternatives=labels,signal_ms=b[-1][0],structural_stop=extreme-side*max(.25*atr,price*.001),frame_close=close)

def evidence(frame,action,price):
 from okx_structural_wave import evidence as double_evidence
 from okx_role_retest import evidence as role_evidence
 from okx_entry_location_guard import validate as location_guard
 errors=[];veto=[]
 for route in (double_evidence,role_evidence,prior_evidence,structure_evidence):
  try:
   proof=route(frame,action,price)
  except BotError as error:
   errors.append(str(error));continue
  try:return location_guard(frame,action,price,proof)
  except BotError as error:veto.append(str(error))
 raise BotError(veto[0] if veto else '쌍바닥·쌍고점/지지·저항 재시험 확인 대기')

@echo off
setlocal
cd /d "%~dp0"
set "BOT_PY=.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=..\.venv\Scripts\python.exe"
if not exist "%BOT_PY%" (
 echo Existing Python environment was not found. Keep this folder inside OKX_BOT.
 pause
 exit /b 1
)
"%BOT_PY%" export_review732.py
pause

"""Closed 15m band-tail rejection with causal 1H/4H context. No network or orders."""
import hashlib,json,math
from okx_rules import metrics,regime,pivots,zones
from okx_core import BotError

DEFAULTS=dict(body_ratio=2.,range_fraction=.5,close_fraction=2/3,atr_fraction=.5,
              outside_atr=.05,max_opposite_wick_fraction=.25,sr_zone_atr=.5,
              entry_window_seconds=120,max_entry_gap_atr=.25,max_entry_gap_fraction=.003,
              holding_frame='1H',holding_ma_period=20)

def validate(w):
    return (type(w.get('adaptive_enabled',False)) is bool and type(w.get('scalp_enabled',False)) is bool and all(type(w[k]) in (int,float) and math.isfinite(w[k]) for k in DEFAULTS if k!='holding_frame')
        and w['body_ratio']>0 and 0<w['range_fraction']<1 and .5<w['close_fraction']<1
        and w['atr_fraction']>0 and 0<w['outside_atr']<=1 and 0<w['max_opposite_wick_fraction']<.5
        and 0<w['sr_zone_atr']<=2 and 10<=w['entry_window_seconds']<=300
        and 0<w['max_entry_gap_atr']<=1 and 0<w['max_entry_gap_fraction']<=.01
        and w['holding_frame'] in ('15m','1H','4H') and w['holding_ma_period'] in (15,20,50,100,120,200))

def shape(b,previous_atr,band,w):
    _,o,h,l,cl,v=b;span=h-l;body=abs(cl-o)
    lower=min(o,cl)-l;upper=h-max(o,cl)
    if span<=0 or previous_atr<=0:return dict(direction=None,reason='零波幅',lower=lower,upper=upper)
    mixed=min(lower,upper)/span>=w['max_opposite_wick_fraction']
    result=dict(direction=None,lower=lower,upper=upper,body=body,range=span,
                lower_body=lower/max(body,previous_atr*1e-8),upper_body=upper/max(body,previous_atr*1e-8),
                lower_fraction=lower/span,upper_fraction=upper/span,close_location=(cl-l)/span,
                lower_atr=lower/previous_atr,upper_atr=upper/previous_atr,
                band_return=band['lower']<=cl<=band['upper'],mixed=mixed,
                outside_lower=l<band['lower']-previous_atr*w['outside_atr'],
                outside_upper=h>band['upper']+previous_atr*w['outside_atr'])
    if mixed or not result['band_return']:return result
    for side,length,opposite in ((1,lower,upper),(-1,upper,lower)):
        location=result['close_location'] if side==1 else 1-result['close_location']
        outside=result['outside_lower' if side==1 else 'outside_upper']
        if (outside and length>=body*w['body_ratio'] and length>=span*w['range_fraction']
            and length>=previous_atr*w['atr_fraction'] and location>=w['close_fraction']):
            result['direction']='LONG' if side==1 else 'SHORT'
    return result

def structure(b,c):
    ps=pivots(b,c);hi=[p for p in ps if p['kind']=='resistance'][-2:];lo=[p for p in ps if p['kind']=='support'][-2:]
    if len(hi)<2 or len(lo)<2:return 'unknown'
    if hi[-1]['price']>hi[-2]['price'] and lo[-1]['price']>lo[-2]['price']:return 'rising'
    if hi[-1]['price']<hi[-2]['price'] and lo[-1]['price']<lo[-2]['price']:return 'falling'
    return 'mixed'

def retest(b,p,side,atr,c):
    """A level already known before the tail, with distinct excursion and no settled break."""
    last=b[-1];level=p['price'];tol=atr*c['signals']['zone_atr']
    if p.get('available_ms',p.get('confirmed',last[0])+900000)>last[0]:return False
    gap=(last[0]-p['time'])/900000
    if not c['signals']['retest_min_gap']<=gap<=c['signals']['retest_max_gap']:return False
    middle=[x for x in b[:-1] if x[0]>p['time']]
    if not middle:return False
    excursion=max(x[2]-level for x in middle) if side==1 else max(level-x[3] for x in middle)
    settled=any((x[4]-level)*side < -tol for x in middle)
    return (excursion>=atr*c['signals']['retest_excursion_atr'] and not settled
            and abs((last[3] if side==1 else last[2])-level)<=atr*c['signals']['wick15']['sr_zone_atr']
            and (last[4]-level)*side>=0)

def decision(b15,higher,c,b5=None):
    if c['signals']['wick15'].get('scalp_enabled'):
        return scalp_decision(b5,b15,higher,c)
    w=c['signals']['wick15'];last=b15[-1];close_time=last[0]+900000
    frames={'15m':b15}
    for name,step in (('1H',3600000),('4H',14400000)):
        frames[name]=[b for b in higher.get(name,[]) if b[0]+step<=close_time]
    audit=dict(mode='wick15',signal_bar_ms=last[0],signal_close_ms=close_time,
               direction=None,entry_reference=last[4],stop=None,frames={},support_resistance=[],
               hold_condition='고정 1H MA와 진입 지지/저항 구간 유지, 구조 진행',exit_condition='보호 SL/위험 한도/고정 구간 붕괴/부분 익절 후 진행 실패')
    def wait(reason):
        audit['reason']=reason;return None,json.dumps(audit,ensure_ascii=False,separators=(',',':'))
    try:
        ms={k:metrics(v,c) for k,v in frames.items()};prior=metrics(b15[:-1],c)
    except (ValueError,IndexError):return wait('15m/1H/4H 확정 봉·MA200 이력 부족')
    for name,b in frames.items():
        m=ms[name];sh=shape(b[-1],metrics(b[:-1],c)['atr'],m,w)
        audit['frames'][name]=dict(trend=regime(m,c),structure=structure(b,c),ma=m['ma'],
            bb={k:m[k] for k in ('mid','upper','lower')},rsi=m['rsi'],shape=sh,
            volume_relative=m['relative_volume'],closed=True,last_bar_ms=b[-1][0],last_close=b[-1][4],
            last_confirmed_high=next((p['price'] for p in reversed(pivots(b,c)) if p['kind']=='resistance'),None),
            last_confirmed_low=next((p['price'] for p in reversed(pivots(b,c)) if p['kind']=='support'),None))
    sh=audit['frames']['15m']['shape'];direction=sh['direction']
    if not direction:return wait('15m 밴드 외부 긴 꼬리·종가 복귀·종가 위치 조건 미충족 또는 양꼬리 혼조')
    side=1 if direction=='LONG' else -1;kind='support' if side==1 else 'resistance';atr=prior['atr']
    audit['direction']=direction;test=last[3] if side==1 else last[2];tol=atr*w['sr_zone_atr']
    context=[]
    for name in ('1H','4H'):
        b=frames[name];m=ms[name]
        for p in zones(b,c):
            if p['kind']==kind:context.append(dict(p,frame=name,source='confirmed_pivot',available_ms=p['confirmed']+(3600000 if name=='1H' else 14400000)))
        for period,value in m['ma'].items():
            context.append(dict(price=value,kind=kind,frame=name,source='SMA'+str(period),time=0,confirmed=0))
    nearby=[p for p in context if abs(test-p['price'])<=tol and (last[4]-p['price'])*side>=0]
    audit['support_resistance']=nearby
    if not nearby:return wait('꼬리 위치에 겹치는 1H/4H 지지·저항·주요 이평선 근거 없음')
    # 15m prior extrema supplement a real upper-timeframe confluence for failed retests.
    prior_levels=zones(b15[:-1],c)
    failed=[p for p in nearby+prior_levels if p['kind']==kind and p.get('source','confirmed_pivot')=='confirmed_pivot' and retest(b15,p,side,atr,c)]
    opposite='downtrend' if side==1 else 'uptrend';opstructure='falling' if side==1 else 'rising'
    against=any(audit['frames'][name]['trend']==opposite or audit['frames'][name]['structure']==opstructure for name in ('1H','4H'))
    audit['countertrend']=against;audit['failed_retest']=failed
    if against and not failed:return wait('상위 추세 반대: 주요 구간 재시험 실패 확인 부족')
    strong=any(regime(ms[name],c)==opposite and abs(ms[name]['ma'][20]-ms[name]['ma'][50])/ms[name]['atr']>=c['signals']['strong_trend_gap_atr'] for name in ('1H','4H'))
    audit['strong_opposite']=strong
    if against and (strong or any(audit['frames'][name]['structure']==opstructure for name in ('1H','4H'))):
        opposite_kind='resistance' if side==1 else 'support'
        broken=any(p['kind']==opposite_kind and (last[4]-p['price'])*side>atr*c['signals']['breakout_atr']
                   and (b15[-2][4]-p['price'])*side<=atr*c['signals']['breakout_atr'] for p in prior_levels)
        hour_turn=ms['1H']['slopes'][20]*side>0 and ms['1H']['mid_slope']*side>0
        audit.update(structure_break=broken,hour_turn=hour_turn)
        if not broken and not hour_turn:return wait('강한 상위 추세/고저점 구조 유지: 확정 구조 변화 전 역추세 대기')
    stop=test-side*atr*c['risk']['stop_buffer_atr']
    primary=min(nearby,key=lambda p:abs(test-p['price']))
    target_candidates=[p['price'] for p in context+prior_levels if (p['price']-last[4])*side>atr*.5]
    # MA/pivot levels can be clustered. The band centre is an explicit mean-reversion objective.
    target_candidates += [v for v in (ms['15m']['mid'],ms['15m']['upper'] if side==1 else ms['15m']['lower']) if (v-last[4])*side>atr*.5]
    target=(min(target_candidates) if side==1 else max(target_candidates)) if target_candidates else last[4]+side*atr*3
    audit.update(stop=stop,reason='15m 볼밴 밖 긴 꼬리·종가 복귀 + 상위 구간 중첩'+('·재시험 실패' if failed else ''),
                 holding_ma=dict(frame=w['holding_frame'],period=w['holding_ma_period']),volume_strength=ms['15m']['relative_volume'])
    current=ms['15m'];gap=min(atr*w['max_entry_gap_atr'],last[4]*w['max_entry_gap_fraction'])
    holding=dict(frame=w['holding_frame'],ma_period=w['holding_ma_period'],zone=primary['price'],tolerance=tol,
                 armed=(last[4]-ms[w['holding_frame']]['ma'][w['holding_ma_period']])*side>=0,source=primary['source'])
    result=dict(action=direction,strategy='wick15_rejection',stop=stop,target=target,reason=audit['reason'],regime=regime(ms['1H'],c),
        level=primary['price'],ma={str(k):v for k,v in current['ma'].items()},
        bb={k:current[k] for k in ('mid','upper','lower','expansion','width_ratio','squeeze')},rsi=current['rsi'],
        relative_volume=current['relative_volume'],chart_context={'15m':current,**{k:ms[k] for k in ('1H','4H')},'recent_15m':b15[-8:]},
        retest=bool(failed),at_ms=last[0],atr=atr,wick_body_ratio=sh['lower_body' if side==1 else 'upper_body'],higher_confirmation=True,
        valid_from_ms=close_time,expires_ms=close_time+w['entry_window_seconds']*1000,entry_reference=last[4],entry_gap=gap,tail_low=last[3],tail_high=last[2],
        holding_rule=holding,decision_record=audit,signal_id=hashlib.sha256(f'wick15:{direction}:{last[0]}'.encode()).hexdigest()[:24])
    return result,''

def check_entry(found,now,price):
    if found.get("strategy")=="band_flow":
        if not found["valid_from_ms"]<=now<=found["expires_ms"]:raise BotError("실시간 신호 재확인 필요")
        return
    if found.get('strategy')!='wick15_rejection':return
    if not found['valid_from_ms']<=now<=found['expires_ms']:raise BotError('확정 신호: 다음 실행 봉 초반 진입 시간 초과')
    if abs(float(price)-found['entry_reference'])>found['entry_gap']:raise BotError('확정 신호: 허용 시가/진입 가격 이격 초과, 추격 취소')


def band_patterns(b,c):
    """One-bar rejection OR a two-bar outside/reclaim, using closed bars only."""
    w=c['signals']['wick15'];last=b[-1];prev=b[-2]
    current=metrics(b,c);previous=metrics(b[:-1],c)
    earlier=metrics(b[:-2],c);atr=previous['atr']
    sh=shape(last,atr,current,w);hits=[]
    if sh['direction']:
        hits.append(dict(direction=sh['direction'],pattern='single_wick',
                         low=last[3],high=last[2],anchor=last[0],shape=sh))
    for side in (1,-1):
        direction='LONG' if side==1 else 'SHORT'
        extreme=prev[3] if side==1 else prev[2]
        edge=previous['lower'] if side==1 else previous['upper']
        # Require the excursion and failed recovery to precede the recovery bar.
        outside=(extreme-edge)*side < -earlier['atr']*w['outside_atr']
        not_recovered=(prev[4]-edge)*side<=0
        recovered=(last[4]-(current['lower'] if side==1 else current['upper']))*side>0
        follow=(last[4]-prev[4])*side>=atr*c['signals']['follow_atr'] and (last[4]-last[1])*side>0
        if outside and not_recovered and recovered and follow and current['lower']<=last[4]<=current['upper']:
            hits.append(dict(direction=direction,pattern='two_bar_reclaim',low=min(prev[3],last[3]),
                             high=max(prev[2],last[2]),anchor=last[0],shape=sh))
    return hits


def scalp_decision(b5,b15,higher,c):
    """5m execution; 15m setups; higher frames describe context, never blanket-veto a bounce."""
    audit=dict(mode='wick15',execution_frame='5m',direction=None,frames={},candidates=[])
    def wait(reason):
        audit['reason']=reason
        return None,json.dumps(audit,ensure_ascii=False,separators=(',',':'))
    if not b5:return wait('5m 확정 봉 이력 필요')
    now=b5[-1][0]+300000
    one=(higher or {}).get('1m',[])
    if one:now=max(now,one[-1][0]+60000)
    frames={'5m':[b for b in b5 if b[0]+300000<=now],
            '15m':[b for b in b15 if b[0]+900000<=now]}
    for name,step in (('1m',60000),('1H',3600000),('4H',14400000)):
        frames[name]=[b for b in (higher or {}).get(name,[]) if b[0]+step<=now]
    try:
        m5=metrics(frames['5m'],c);m15=metrics(frames['15m'],c)
        previous=metrics(frames['5m'][:-1],c)
        if now-(frames['15m'][-1][0]+900000)>=900000:return wait('최신 15m 확정 봉 지연')
        for name,b in frames.items():
            try:
                m=metrics(b,c)
                audit['frames'][name]=dict(trend=regime(m,c),close=m['close'],ma=m['ma'],
                    bb={k:m[k] for k in ('mid','upper','lower')},volume_relative=m['relative_volume'],last_bar_ms=b[-1][0])
            except (ValueError,IndexError):
                if name in ('5m','15m'):raise
                from okx_support import context as short_context
                audit['frames'][name]=short_context(b,c)
        setups=[]
        for frame in ('5m','15m'):
            for hit in band_patterns(frames[frame],c):
                setups.append(dict(hit,frame=frame))
    except (ValueError,IndexError):return wait('5m/15m 확정 봉·지표 계산 이력 부족')
    prev,last=frames['5m'][-2:]
    atr=previous['atr'];w=c['signals']['wick15'];tol=atr*w['sr_zone_atr']
    adaptive=w.get('adaptive_enabled',False)
    if not adaptive and m5['relative_volume']<c['signals']['min_relative_volume']:
        return wait('5m 자체 거래량 보조 기준 미충족')
    # 15m averages known BEFORE the 5m test; no not-yet-closed higher candle.
    known15=[b for b in frames['15m'] if b[0]+900000<=prev[0]]
    if len(known15)>=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1:
        known=metrics(known15,c)
        for side in (1,-1):
            aligned=(known['ma'][15]-known['ma'][20])*side>0 and known['slopes'][20]*side>0
            if not aligned:continue
            for period in (5,10,15,20,50):
                level=sum(b[4] for b in known15[-period:])/period
                test=prev[3] if side==1 else prev[2]
                touched=abs(test-level)<=tol
                held=(prev[4]-level)*side>=0 and (last[4]-level)*side>0
                follow=(last[4]-prev[4])*side>=atr*c['signals']['follow_atr'] and (last[4]-last[1])*side>0
                if touched and held and follow:
                    setups.append(dict(direction='LONG' if side==1 else 'SHORT',pattern='ma_rejection',
                        frame='5m',low=min(prev[3],last[3]),high=max(prev[2],last[2]),
                        anchor=last[0],level=level,source='15m SMA'+str(period),shape={}))
                    break
    if adaptive:
        from okx_adaptive import setups as adaptive_setups
        setups.extend(adaptive_setups(frames['5m'],frames['15m'],c))
    from okx_trend_tail import setups as tail_setups,late_entry_reason
    setups.extend(tail_setups(frames['5m'],frames['15m'],c))
    from okx_support import setups as support_setups,flow_assessment
    setups.extend(support_setups(frames,c,now))
    from okx_context_entries import setups as context_setups
    setups.extend(context_setups(frames,c,now))
    from okx_fast_entries import setups as fast_setups
    setups.extend(fast_setups(frames,c,now))
    from okx_case_entries import setups as case_setups
    setups.extend(case_setups(frames,c,now))
    candidates=[]
    audit['rejected_candidates']=[]
    levels=zones(frames['15m'],c)
    for hit in setups:
        side=1 if hit['direction']=='LONG' else -1
        blocked=late_entry_reason(hit,last,m5,m15,c)
        if blocked:
            audit['rejected_candidates'].append(dict(pattern=hit['pattern'],reason=blocked));continue
        flow=flow_assessment(frames,side,c)
        if hit.get('independent_case'):
            flow=dict(flow,allowed=True,mode='independent_case_response',independent_confirmation={k:hit.get('evidence',{}).get(k) for k in ('route','completed_ms','reaction_confirmed','two_bar_price_response')})
        if hit.get('confirmed_turn') or (hit.get('fast_scalp') and hit.get('evidence',{}).get('range_confirmed')):
            # These independent routes already confirm a local turn/range; do not require the old trend too.
            flow=dict(flow,allowed=True,mode='confirmed_tail_turn' if hit.get('confirmed_turn') else 'confirmed_range_scalp',
                      independent_confirmation=hit.get('evidence',{}))
        if c['signals'].get('support_entries',{}).get('enabled') and not flow['allowed']:
            audit['rejected_candidates'].append(dict(pattern=hit['pattern'],reason='전체 흐름과 반대 / 반전 구조 미확인',flow=flow));continue
        hit=dict(hit,flow=flow)
        test=hit['low'] if side==1 else hit['high']
        # A 15m setup uses the latest completed 5m reaction, without waiting another 15m candle.
        if hit['frame']=='15m' and not hit.get('preferred_tail') and not hit.get('independent_support') and not ((last[4]-last[1])*side>0 and (last[4]-prev[4])*side>=atr*c['signals']['follow_atr']):continue
        if hit['frame']!='5m':
            frame_atr=metrics(frames[hit['frame']][:-1],c)['atr']
            confirm_tol=frame_atr*w['sr_zone_atr']
        else:
            frame_atr=atr;confirm_tol=tol
        kind='support' if side==1 else 'resistance'
        context=[dict(price=p['price'],source='15m pivot') for p in levels if p['kind']==kind]
        context += [dict(price=v,source='15m SMA'+str(k)) for k,v in m15['ma'].items()]
        context += [dict(price=m15['lower'] if side==1 else m15['upper'],source='15m band')]
        nearby=[p for p in context if abs(test-p['price'])<=confirm_tol and (last[4]-p['price'])*side>=0]
        if hit.get('adaptive') or hit['pattern']=='ma_rejection':
            primary=dict(price=hit['level'],source=hit['source'])
        elif hit['frame']=='15m':
            primary=dict(price=test,source='15m '+hit['pattern'])
        elif nearby:
            primary=min(nearby,key=lambda p:abs(test-p['price']))
        else:continue
        stop=test-side*frame_atr*c['risk']['stop_buffer_atr']
        entry_current=frames['1m'][-1][4] if hit['frame']=='1m' else last[4]
        noise_atr=frame_atr if hit['frame']=='1m' else atr
        if adaptive and not hit.get('fast_scalp') and not hit.get('independent_case'):
            # Keep actual structure, even when high leverage would reject it.
            stop=min(stop,entry_current-noise_atr*.8) if side==1 else max(stop,entry_current+noise_atr*.8)
        if (entry_current-stop)*side<=0:continue
        planned=dict(hit,stop=stop,primary=primary,side=side,frame_atr=frame_atr)
        from okx_entry_pipeline import enabled as pipeline_enabled,target_for,approximate_ratio
        if pipeline_enabled(c):
            target,source=target_for(planned,frames,m5,m15,levels,c,entry_current,frame_atr)
            if target is None:
                audit['rejected_candidates'].append(dict(pattern=hit['pattern'],reason=source));continue
            planned.update(target=target,_target_override=target,target_source=source)
            planned['estimated_reward_risk']=approximate_ratio(planned,entry_current,c)
        candidates.append(planned)
    if candidates and c.get('execution',{}).get('entry_pipeline',{}).get('enabled'):
        feasible=[h for h in candidates if h.get('estimated_reward_risk',-1)>=c['risk']['min_reward_risk']]
        if feasible:candidates=feasible

    audit['candidates']=[dict(pattern=h['pattern'],frame=h['frame'],direction=h['direction']) for h in candidates]
    if not candidates:return wait('전체 흐름 분석 후 독립 전략 미충족: 지지 회복·이평선 횡보·꼬리·돌파 후보 대기')
    if adaptive:
        candidates.sort(key=lambda h:h.get('evidence_score',3),reverse=True)
        opposite=[h for h in candidates if h['direction']!=candidates[0]['direction']]
        if opposite and candidates[0].get('evidence_score',3)-opposite[0].get('evidence_score',3)<c['signals'].get('direction_conflict_gap',2):
            return wait('롱·숏 근거 점수 차이 부족: 방향 충돌')
        contextual=[h for h in candidates if h.get('context_priority')]
        preferred=[h for h in candidates if h.get('preferred_tail')]
        fast=[h for h in candidates if h.get('fast_priority') and h.get('evidence_score',3)>=candidates[0].get('evidence_score',3)]
        hit=candidates[0] if any(h.get('case_priority') for h in candidates) else fast[0] if fast else contextual[0] if contextual else min(preferred,key=lambda h:0 if h['frame']=='15m' else 1) if preferred else candidates[0]
    else:
        if len({h['direction'] for h in candidates})>1:return wait('동일 시점 롱·숏 패턴 충돌')
        hit=min(candidates,key=lambda h:({'ma_rejection':0,'two_bar_reclaim':1,'single_wick':2}[h['pattern']],0 if h['frame']=='15m' else 1))
    side=hit['side'];stop=hit['stop']
    execution_frame='1m' if hit['frame']=='1m' else '5m'
    if execution_frame=='1m':
        last=frames['1m'][-1];atr=hit['frame_atr']
    price=last[4];now=last[0]+(60000 if execution_frame=='1m' else 300000)
    # Nearest real obstacle is retained; risk_plan still checks costs and minimum reward/risk.
    obstacles=[p['price'] for p in levels if (p['price']-price)*side>atr*.3]
    obstacles += [v for v in (m15['mid'],m15['upper'] if side==1 else m15['lower']) if (v-price)*side>atr*.3]
    target=(min(obstacles) if side==1 else max(obstacles)) if obstacles else price+side*atr*3
    if hit.get('target') is not None:
        known_targets=[p['price'] for p in levels if (p['price']-price)*side>0]
        known_targets += [v for v in (m15['mid'],m15['upper'] if side==1 else m15['lower']) if (v-price)*side>0]
        target=(min(known_targets+[hit['target']]) if side==1 else max(known_targets+[hit['target']]))
    if '_target_override' in hit:target=hit['_target_override']
    label={'case_single_wick_reversal_long':'확정 아랫꼬리 반전 롱','case_single_wick_reversal_short':'확정 윗꼬리 반전 숏','case_consolidation_long':'추세 횡보 후 상승 재개 롱','case_consolidation_short':'추세 횡보 후 하락 재개 숏','case_support_long':'이평/저점 지지 회복 롱','case_resistance_short':'이평/고점 저항 거부 숏','case_lower_rejection_long':'하단 가격 거부·반전 롱','case_upper_rejection_short':'상단 가격 거부·반전 숏','case_breakout_long':'상향 돌파·재지지 롱','case_breakdown_short':'하향 돌파·재저항 숏'}.get(hit['pattern'],hit['pattern'])
    reason=hit['frame']+' '+('추세 눌림 꼬리·지지/저항 회복' if hit.get('preferred_tail') else label)+' / '+hit['frame']+' 확정 신호 / '+hit['primary']['source']
    holding=dict(mode='scalp',execution_frame='5m',frame='15m',ma_period=20,
                 zone=hit['primary']['price'],tolerance=tol,armed=False,source=hit['primary']['source'])
    if hit.get('fast_scalp'):
        holding.update(fast_scalp=True,execution_frame='1m',ma_period=5,target=target,
            max_hold_seconds=c['signals']['fast_entries']['scalp_max_hold_seconds'])
    audit.update(strategy_logic='OR',market_flow=hit.get('flow',{}),execution_frame=execution_frame,evidence=hit.get('evidence',{}),evidence_score=hit.get('evidence_score'),target_source=hit.get('target_source'),estimated_reward_risk=hit.get('estimated_reward_risk'),adaptive=adaptive,
        direction=hit['direction'],pattern=hit['pattern'],setup_frame=hit['frame'],
        signal_bar_ms=last[0],signal_close_ms=now,entry_reference=price,stop=stop,reason=reason,
        support_resistance=hit['primary'],countertrend=regime(m15,c)==('downtrend' if side==1 else 'uptrend'))
    gap=min(atr*w['max_entry_gap_atr'],price*w['max_entry_gap_fraction'])
    result=dict(action=hit['direction'],strategy='wick15_rejection',pattern=hit['pattern'],setup_frame=hit['frame'],
        execution_frame=execution_frame,stop=stop,target=target,reason=reason,regime=regime(m15,c),level=hit['primary']['price'],
        ma={str(k):v for k,v in m5['ma'].items()},bb={k:m5[k] for k in ('mid','upper','lower','expansion','width_ratio','squeeze')},
        rsi=m5['rsi'],relative_volume=m5['relative_volume'],chart_context={'5m':m5,'15m':m15,'higher':audit['frames'],'recent_5m':frames['5m'][-8:]},
        retest=hit['pattern']=='ma_rejection',at_ms=last[0],atr=atr,wick_body_ratio=hit['shape'].get('lower_body' if side==1 else 'upper_body',0),
        adaptive=adaptive,higher_confirmation=True,valid_from_ms=now,expires_ms=now+hit.get('entry_window_seconds',w['entry_window_seconds'])*1000,
        entry_reference=price,entry_gap=gap,tail_low=hit['low'],tail_high=hit['high'],holding_rule=holding,decision_record=audit,
        signal_id=hashlib.sha256(f"scalp:{hit['direction']}:{'case_response' if hit.get('independent_case') else hit['pattern']}:{hit['frame']}:{hit['anchor']}".encode()).hexdigest()[:24])
    return result,''

def holding_check(frames,p,o,c):
    """The timeframe/period/zone is frozen at entry; only an arming latch may advance."""
    if o['holding_rule'].get('mode')=='scalp':
        return 'HOLD','5m 확정 구조·보호 손절로 추세 관리'
    rule=o['holding_rule'];side=1 if p['posSide']=='long' else -1;b=frames['15m'];last=b[-1]
    m=metrics(frames[rule['frame']],c);ma=m['ma'][rule['ma_period']]
    if (last[4]-rule['zone'])*side < -rule['tolerance']:
        return 'CLOSE','진입 시 고정한 지지/저항 구간 마감 붕괴'
    favourable=(last[4]-ma)*side>=0
    if favourable:rule['armed']=True
    adverse=all((x[4]-ma)*side<0 for x in b[-2:])
    progression=(last[3]-b[-2][3])*side if side==1 else (last[2]-b[-2][2])*side
    if rule.get('armed') and adverse and progression<0:return 'CLOSE','고정 보유 이평선 2봉 이탈과 고저점 구조 악화'
    return 'HOLD',f"고정 {rule['frame']} SMA{rule['ma_period']}={ma:.8g}, 구간 {rule['zone']:.8g} 유지 / 구조 진행 {progression:.8g}"

def holding_record(frames,p,o,c,action,reason):
    summary={}
    names=('1m','5m','15m','1H','4H') if o['holding_rule'].get('mode')=='scalp' else ('15m','1H','4H')
    for name in names:
        b=frames.get(name,[])
        try:
            m=metrics(b,c);previous=metrics(b[:-1],c)
        except (ValueError,IndexError):
            summary[name]=dict(trend='unknown',reason='확정 지표 이력 부족')
            continue
        summary[name]=dict(trend=regime(m,c),structure=structure(b,c),ma=m['ma'],
            bb={k:m[k] for k in ('mid','upper','lower')},
            shape=shape(b[-1],previous['atr'],m,c['signals']['wick15']),
            volume_relative=m['relative_volume'],closed=True,last_bar_ms=b[-1][0])
    return dict(mode='holding_wick15',direction=o['direction'],action=action,reason=reason,
        entry_price=p.get('avgPx'),mark_price=p.get('markPx'),roe=p.get('uplRatio'),stop=o['stop_px'],
        holding_rule=dict(o['holding_rule']),frames=summary,
        hold_condition=('스캘핑 목표·단기MA5·진행 부족·최대 시간' if o['holding_rule'].get('fast_scalp') else '5m 추세 유지·유리한 방향의 보호 손절' if o['holding_rule'].get('mode')=='scalp' else '진입 시 고정 이평선/가격 구간 유지'),
        exit_condition='보호 SL·계좌 한도·확정 추세 반전')

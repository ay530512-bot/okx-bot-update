@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "BOT_PY=.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=..\.venv\Scripts\python.exe"
if not exist "%BOT_PY%" (
 echo 기존 프로그램의 AI_FREE_5X 폴더에 덮어쓴 후 실행하세요.
 pause
 exit /b 1
)
"%BOT_PY%" setup_mobile.py
pause

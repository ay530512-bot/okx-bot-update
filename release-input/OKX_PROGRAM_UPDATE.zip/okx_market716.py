"""All live linear USDT perpetual quotes, independent of strategy candidate scanning."""
import math,threading,time

def market_rows(instruments,tickers,now):
    allowed={i['instId'] for i in instruments if i.get('instCategory')=='1' and i.get('groupId')!='6' and i.get('state')=='live' and i.get('settleCcy')=='USDT' and i.get('ctType','linear')=='linear' and i.get('instId','').endswith('-USDT-SWAP')}
    rows=[]
    for t in tickers:
        try:
            symbol=t['instId'];last=float(t['last']);opening=float(t['sodUtc0']);stamp=int(t['ts'])
            if stamp//86400000 != now//86400000:continue
            if symbol not in allowed or min(last,opening)<=0 or not all(math.isfinite(v) for v in (last,opening)) or not -5000<=now-stamp<=60000:continue
            rows.append(dict(symbol=symbol,last=last,change=last/opening-1,ts=stamp,ranking_start_ms=now//86400000*86400000))
        except (KeyError,TypeError,ValueError):continue
    return sorted(rows,key=lambda r:(-r['change'],r['symbol']))

class MarketFeed:
    def __init__(self,settings,events,factory=None):
        self.settings=settings;self.events=events;self.factory=factory;self.closed=threading.Event()
    def start(self):
        self.thread=threading.Thread(target=self.run,daemon=True,name='all-futures-quotes');self.thread.start()
    def stop(self):self.closed.set()
    def run(self):
        api=None;instruments=[];last_instruments=0
        try:
            while not self.closed.is_set():
                try:
                    if api is None:
                        from okx_core import OKX
                        api=(self.factory or OKX)(self.settings)
                    if not instruments or time.monotonic()-last_instruments>300:
                        instruments=api.public('/api/v5/public/instruments',instType='SWAP');last_instruments=time.monotonic()
                    quotes=api.public('/api/v5/market/tickers',instType='SWAP');now=api.now_ms()
                    rows=market_rows(instruments,quotes,now)
                    if not rows:raise ValueError('fresh quotes unavailable')
                    self.events.put(('futures_market',dict(rows=rows,observed_ms=now,basis='KST09시',basis_start_ms=now//86400000*86400000,stale=False)))
                except Exception:self.events.put(('futures_market_error','전체 선물 시세 갱신 지연 · 연결 확인'))
                self.closed.wait(10)
        finally:
            session=getattr(api,'session',None)
            if session:session.close()

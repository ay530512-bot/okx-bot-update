"""Observable trade diagnostics; flags are review hypotheses, not causal verdicts."""
import math
LABELS={'late_entry':'확인 종가보다 늦은 추격 진입','low_volume':'진입봉 거래량이 자체 평균 미만','tight_stop':'초기 SL 거리 0.5ATR 미만','near_obstacle':'다음 지지·저항까지 여유 0.5ATR 미만','continued_after_exit':'청산 후 같은 방향 1ATR 이상 진행','reversed_after_exit':'청산 후 반대 방향 1ATR 이상 진행'}
def context(frames,frame,entry,stop,direction):
 try:
  f=frames[frame];atr=float(f['atr']);price=float(entry);sl=float(stop);last=f['recent'][-1];side=1 if direction=='long' else -1
  if atr<=0 or not all(math.isfinite(x) for x in (atr,price,sl)):return {}
  h=f.get('chart_evidence',{});obstacle=h.get('prior_resistance' if side==1 else 'prior_support');gap=(price-float(last[4]))*side/atr;vol=float(f['relative_volume']) if f.get('relative_volume') is not None else None;distance=abs(price-sl)/atr
  if 'structural_levels' in f:
   candidates=[float(x['price']) for x in f['structural_levels'] if x.get('kind')==('high' if side==1 else 'low') and (float(x['price'])-price)*side>0]
   obstacle=(min(candidates) if side==1 else max(candidates)) if candidates else None
  tags=[]
  if gap>.5:tags.append('late_entry')
  if vol is not None and vol<1:tags.append('low_volume')
  if distance<.5:tags.append('tight_stop')
  room=(float(obstacle)-price)*side/atr if obstacle else None
  if room is not None and 0<room<.5:tags.append('near_obstacle')
  return dict(atr=atr,entry=price,initial_stop=sl,entry_gap_atr=gap,relative_volume=vol,stop_distance_atr=distance,obstacle_room_atr=room,tags=tags,frame=frame,direction=direction)
 except (KeyError,TypeError,ValueError,IndexError):return {}

def analysis(row,post_bars=None,now_ms=0):
 q=row.get('quality_context') or {};tags=list(q.get('tags',[]))
 if not q:return dict(tags=[],notes=['진입 당시 판단 자료 부족'],post_status='missing')
 notes=[LABELS[t]+' · 원인 확정 아님' for t in tags if t in LABELS]
 excursion=row.get('observed_excursion',{})
 if excursion.get('samples',0):notes.append('관측 유리/불리 움직임 '+str(round(excursion.get('favorable_atr',0),2))+'/'+str(round(excursion.get('adverse_atr',0),2))+'ATR · 틱 관측 범위')
 status='waiting'
 try:
  end=int(row['end_ms']);price=float(row.get('exit_price') or 0);side=1 if row['direction']=='long' else -1;atr=q['atr']
  step=900000 if (row.get('learning') or {}).get('key694') else 300000
  expected=((end+step-1)//step)*step
  bars=[b for b in (post_bars or []) if expected<=b[0] and b[0]+step<=now_ms][:3]
  if len(bars)==3 and [b[0] for b in bars]==[expected+i*step for i in range(3)] and price>0:
   move=(float(bars[-1][4])-price)*side/atr
   status='observed';notes.append('청산 후 완료 '+str(step//60000)+'분봉 3개 순이동 '+str(round(move,2))+'ATR · 대안 청산의 실제 수익 아님')
   if move>=1:tags.append('continued_after_exit')
   elif move<=-1:tags.append('reversed_after_exit')
  else:notes.append('청산 후 연속 5분봉 3개 또는 실제 청산가 부족 · 조기 청산 판정 보류')
 except (KeyError,ValueError,TypeError):status='missing';notes.append('청산 시점·가격 자료 부족')
 if not notes:notes=['추가 품질 경고 없음 · 좋은 진입으로 확정한 것은 아님']
 return dict(tags=tags,notes=notes,post_status=status)

def enrich(engine,rows):
 import json
 from pathlib import Path
 result,_=engine.universe.read() if hasattr(engine,'universe') else (None,None)
 candidates={r['symbol']:r for r in (result or {}).get('rows',[])}
 now=engine.api.now_ms() if hasattr(engine,'api') else 0
 path=Path(engine.root)/'trade_quality_assessments.json'
 try:cache=json.loads(path.read_text(encoding='utf-8'))
 except (OSError,ValueError):cache={}
 output=[];changed=False
 for r in rows:
  identity=str(r.get('source'))+':'+str(r.get('client_id'))
  prior=cache.get(identity,{})
  verdict=prior if prior.get('post_status')=='observed' else analysis(r,candidates.get(r.get('symbol'),{}).get('live_frames',{}).get('15m' if (r.get('learning') or {}).get('key694') else '5m',[]),now)
  if verdict!=prior:cache[identity]=verdict;changed=True
  output.append(dict(r,quality_analysis=verdict))
 if changed:
  try:
   tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(cache,ensure_ascii=False),encoding='utf-8');tmp.replace(path)
  except OSError:pass
 return output

def feedback(rows):
 groups={};seen=set()
 for row in rows:
  identity=(row.get('source'),row.get('client_id'))
  if identity in seen:continue
  seen.add(identity)
  for tag in row.get('quality_analysis',{}).get('tags',[]):
   name='|'.join(str(v) for v in (row.get('source'),(row.get('learning') or {}).get('setup'),(row.get('learning') or {}).get('frame'),tag))
   try:pnl=float(row['realizedPnl'])
   except (KeyError,ValueError,TypeError):continue
   if not math.isfinite(pnl):continue
   g=groups.setdefault(name,dict(flag=tag,label=LABELS.get(tag,tag),samples=0,profitable=0,losing=0))
   g['samples']+=1;g['profitable']+=int(pnl>0);g['losing']+=int(pnl<0)
 return groups

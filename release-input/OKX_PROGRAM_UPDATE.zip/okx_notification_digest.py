"""Bounded deterministic wait digest. No model/network calls; caller holds outbox lock."""
import re,time
WAIT_EVENTS=frozenset(('진입 거절','AI 진입 대기'))
INTERVAL=300

def add(data,event,text,now):
 b=data.setdefault('wait_digest',dict(started=now,count=0,symbols=[],reasons={}))
 b['count']+=1
 for s in re.findall(r'\b([A-Z0-9]+)(?:-USDT-SWAP|/USDT)',str(text)):
  if s not in b['symbols'] and len(b['symbols'])<5:b['symbols'].append(s)
 if any(k in text for k in ('최신 OHLCV','시세 준비','실시간 자료','자료 수신','누락·지연','미준비')):reason='시장 자료 수신 대기'
 elif any(k in text for k in ('유효 구조','패턴 미충족','구조 확인','재시험','꼬리·눌림')):reason='진입 패턴 확인 대기'
 elif any(k in text for k in ('예산','한도 초과')):reason='분석 예산·자료 한도 대기'
 elif any(k in text for k in ('추격','진입 구간')):reason='진입 가격 구간 대기'
 elif any(k in text for k in ('최소 수량','증거금','잔고')):reason='주문 수량·잔고 조건 대기'
 elif any(k in text for k in ('Error','오류','실패')):reason='프로그램·연결 오류 확인 필요'
 else:reason='추가 진입 근거 확인 대기'
 b['reasons'][reason]=b['reasons'].get(reason,0)+1

def flush(data,now):
 b=data.get('wait_digest')
 if not b or now-b['started']<INTERVAL:return None
 lines=['[진입 전 대기]','최근 대기·조건 미충족 알림 '+str(b['count'])+'건 요약']
 lines+=['· '+k+' '+str(v)+'건' for k,v in sorted(b['reasons'].items(),key=lambda v:-v[1])[:3]]
 if b['symbols']:lines.append('주요 종목: '+', '.join(b['symbols']))
 lines.append('진입·청산 알림은 별도 즉시 전달')
 data.pop('wait_digest',None)
 return '\n'.join(lines)

def migrate(data,now):
 keep=[];summaries=[]
 for item in data.get('pending',[]):
  if item.get('event') in WAIT_EVENTS:add(data,item['event'],item.get('text',''),now)
  elif item.get('event')=='진입 대기 요약':summaries.append(item)
  else:keep.append(item)
 # One old unsent summary maximum; never burst a backlog of summaries.
 data['pending']=keep+summaries[-1:]
 if data.get('wait_digest'):data['wait_digest']['started']=min(now,max(now-INTERVAL+1,data['wait_digest'].get('started',now)))

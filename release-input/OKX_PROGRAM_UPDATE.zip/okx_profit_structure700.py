"""Protect earned post-entry structure before target; no fixed ROE exit or profit claim."""
import math

def candidate(b,entry_ms,entry,stop,price,side,atr,cost_rate=0):
 from okx_structure694 import swings
 if min(entry,price,atr)<=0 or not all(math.isfinite(v) for v in (entry,stop,price,atr,cost_rate)):return None
 # Existing unverified history and bars containing the entry cannot create a pivot.
 post=[r for r in b if r[0]>=entry_ms]
 if len(post)<3:return None
 # cost_rate is an estimated roundtrip rate; account for fee on exit price too.
 fee=abs(cost_rate)/2
 if fee>=1:return None
 net_floor=entry*(1+fee)/(1-fee) if side==1 else entry*(1-fee)/(1+fee)
 kind='low' if side==1 else 'high'
 options=[]
 for j,t,level in swings(post):
  if t!=kind:continue
  test=post[j];confirm=post[j+1]
  response=(confirm[4]-confirm[1])*side>0 and (confirm[4]-test[4])*side>0
  if not response:continue
  proposed=float(level)-side*atr*.15
  # Never move a stop into the spread/current price, widen it, or call gross BE profit.
  if (proposed-net_floor)*side<=0 or (proposed-stop)*side<=0 or (price-proposed)*side<=0:continue
  # Reject a support/resistance already invalidated after its confirmation.
  if any((float(r[3 if side==1 else 2])-proposed)*side<=0 for r in post[j+2:]):continue
  options.append(dict(stop=proposed,pivot_ms=test[0],confirmed_ms=confirm[0]+900000,net_floor=net_floor,reason='목표 전·후 새 지지/저항 확인 · 비용 반영 수익 구간 구조 보호'))
 return max(options,key=lambda v:side*v['stop']) if options else None

def trace(e,o,p,action,reason,**extra):
 """Record an intent; only the exchange engine can acknowledge a fill/protection."""
 import json
 item=dict(ms=e.api.now_ms(),symbol=o.get('symbol'),action=action,reason=reason,mark=p.get('markPx'),entry=p.get('avgPx'),current_stop=o.get('stop_px'),execution_confirmed=False,**extra)
 o['last_structure_decision700']=item
 root=getattr(e,'root',None)
 if root is not None:
  try:
   with (root/'structure_management700.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(item,ensure_ascii=False)+'\n')
  except OSError:pass

"""Modern native dashboard. Trade policy lives in the unchanged engine modules."""
import queue
import socket
import sys
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox
from okx_dashboard import Dashboard

ROOT=Path(__file__).resolve().parent


def design_preview(app):
    """Explicit offline preview: no keys read, engine constructed, network or order callbacks."""
    callbacks={name:(lambda:None) for name in ('live','pause','preview','close','refresh','settings','history','positions','preflight','reconnect','telegram_test','update')}
    view=Dashboard(app,callbacks,demo=True)
    callbacks.update(settings=view.show_settings,history=view.show_history,positions=view.show_positions)
    view.receive('status',dict(equity='48.32',available='16.10',roi=.0067,api_spent=.034,live=False,mode='디자인 미리보기 · 실제 주문 없음',updated='15:28:17'))
    view.receive('dashboard',dict(day_profit='.32',market_connected=True,account_connected=True,telegram_configured=True,positions=[
        dict(key='demo-aave',symbol='AAVE-USDT-SWAP',direction='long',leverage=5,roe='.032',entry='147.21',mark='148.14',stop='147.40',quantity='.1',phase='active',protected=True,reason='지지 확인 · 보호 손절 상향'),
        dict(key='demo-sui',symbol='SUI-USDT-SWAP',direction='short',leverage=3,roe='-.0098',entry='2.144',mark='2.151',stop='2.175',quantity='15',phase='active',protected=True,reason='저항 재확인 대기')]))
    import math
    now=time.time()*1000;day=(now+32400000)//86400000*86400000-32400000
    view.receive('equity_history',[[day+(now-day)*j/119,47.7+j*.005+math.sin(j*.45)*.04] for j in range(120)])
    view.receive('timeframes',{'symbol':'AAVE-USDT-SWAP','frames':{k:{'trend':v} for k,v in [('1m','range'),('5m','uptrend'),('15m','range'),('1H','uptrend'),('4H','downtrend')]}})
    view.histories={'demo-aave':[147.3,147.4,147.35,147.55,147.8,147.75,147.9,148.14],
        'demo-sui':[2.16,2.15,2.152,2.148,2.147,2.154,2.149,2.151]}
    for title,text in (('지지·저항과 MA 교차 확인','지지·저항 구간과 이동평균선 교차 확인 중'),('밴드 내부 복귀 확인','주요 종목의 밴드 복귀 여부 확인'),('전체 시장 탐색 중','상승8·하락7 종목의 가격·거래량·변동성 확인')):
        view.receive('decision',dict(title=title,text=text))
    view.activities.clear()
    for stamp,text in (('15:20','상승8·하락7 후보 갱신'),('15:25','SUI 저항 구간 확인 중'),('15:28','AAVE 보호 SL 상향 · 147.21 → 147.40')):view.add_activity(stamp,text)
    view.state['chart_indicators']=dict(ma_periods=[50,100,120,150,200,240],bb_period=20,bb_multiplier=2)
    for frame,step in [('5m',300000),('15m',900000),('1H',3600000),('4H',14400000)]:
        end=int(now)//step*step;bars=[]
        for j in range(230):
            close=144+j*.017+math.sin(j*.35)*.42;opening=close-.12*math.cos(j*.6)
            bars.append([end-(229-j)*step,opening,max(opening,close)+.13,min(opening,close)-.16,close,100+40*abs(math.sin(j)),j<229])
        view.receive('position_chart',dict(symbol='AAVE-USDT-SWAP',frame=frame,bars=bars,observed_ms=int(now),stale=False))
    view.positions[0]['target']='150.00'
    view.schedule();return view


def main():
    app=tk.Tk();app.title('OKX 트레이딩 · 7.32-Q2U 다크 · 롱/숏 분석 · 고정 배율 · 시드1/4 · 공통 수익보호');app.configure(bg='#000000')
    width=min(1840,app.winfo_screenwidth()-60);height=min(1040,app.winfo_screenheight()-90)
    app.geometry(f'{max(width,1040)}x{max(height,640)}');app.minsize(1040,640)
    app.geometry(f'{min(2048,app.winfo_screenwidth()-20)}x{min(1178,app.winfo_screenheight()-60)}+0+0')
    if '--design-preview' in sys.argv:
        design_preview(app);app.mainloop();return
    # Same local singleton lock. This is not a network control server.
    instance_lock=socket.socket()
    try:
        if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):instance_lock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
        instance_lock.bind(('127.0.0.1',48736))
    except OSError:
        app.withdraw();messagebox.showerror('중복 실행 차단','이미 실행 중이거나 로컬 포트 48736을 사용 중입니다. 기존 창을 확인하세요.');app.destroy();return
    from dotenv import dotenv_values
    from okx_v5 import RuleEngine
    from okx_core import dec,BotError
    from okx_rules import load_config
    events=queue.Queue()
    try:
        settings=dotenv_values(ROOT/'.env' if (ROOT/'.env').exists() else ROOT.parent/'.env',encoding='utf-8-sig',interpolate=False)
        from okx_exchange_guard import require_okx
        require_okx(ROOT,settings)
        settings=dict(settings,_EXCHANGE_ROOT=str(ROOT))
        install_meta=ROOT/'installation_exchange.json'
        if install_meta.exists():
            import json
            settings['_SHARED_BUDGET_ROOT']=json.loads(install_meta.read_text(encoding='utf-8')).get('shared_budget_root')
        selected_exchange=str(settings.get('TRADING_EXCHANGE') or 'okx').upper()
        app.title(selected_exchange+' 트레이딩 · 7.32-Q2U 다크 · 롱/숏 분석 · 고정 배율 · 시드1/4 · 공통 수익보호')
        config=load_config(ROOT)
        if not config['execution'].get('rule_channel701') and (config['execution']['ai_confirmation'] or config['execution'].get('free_ai',{}).get('enabled')) and not settings.get('OPENAI_API_KEY'):raise ValueError('.env에 OPENAI_API_KEY가 없습니다.')
        engine=RuleEngine(ROOT,settings,events)
    except Exception as error:
        messagebox.showerror('실행 설정 확인',str(error) if isinstance(error,(ValueError,BotError)) else '설정 또는 기록 확인 오류: '+type(error).__name__)
        app.destroy();instance_lock.close();return
    latest={'equity':None,'owned':bool(engine.records()),'live':False,'preview':False};last_status=[0.]
    callbacks={name:(lambda:None) for name in ('live','pause','preview','close','refresh','settings','history','positions','preflight','reconnect','telegram_test','update')}
    view=Dashboard(app,callbacks)
    view.exchange_label=selected_exchange
    from okx_position_chart import ChartFeed
    chart_feed=ChartFeed(settings,events);chart_feed.start()
    from okx_market716 import MarketFeed
    market_feed=MarketFeed(settings,events);market_feed.start()
    callbacks['chart_feed_factory']=lambda queue:ChartFeed(settings,queue)
    view.state['chart_indicators']=dict(config['indicators'])
    from okx_mobile import start_mobile
    try:mobile=start_mobile(ROOT,settings)
    except Exception as mobile_error:
        mobile=None
        detail='모바일 서버를 시작하지 못했습니다. 이전 프로그램이 포트8766을 사용 중이거나 모바일 설정에 문제가 있습니다. 이전 실행창을 정상 종료한 뒤 다시 실행하세요. MOBILE_CHECK.bat에서 응답 버전을 확인할 수 있습니다.'
        view.add_activity('모바일 시작 실패',detail)
        messagebox.showerror('모바일 업데이트 미적용',detail)
    if mobile:
        view.add_activity('모바일 V7.32-Q2U 다크 · 15m 전용','새 모바일 서버 시작 완료 · 선물목록/직접진입/개별청산 지원 · Safari 상단 V7.32-Q2U 표시 확인 · +6%는 평가 목표이며 수익 보장 아님')
        (ROOT/'MOBILE_V721_ADDRESS.txt').write_text('https://'+mobile.config['https_host']+'/\n',encoding='utf-8')
    mobile_last=[0.]
    diagnostic_last=[0.]
    diagnostic_error=[False]
    def chart_select(symbol,frame):
        if symbol and symbol not in {p['symbol'] for p in view.positions} | {r['symbol'] for r in view.state.get('futures_market',{}).get('rows',[])}:return
        chart_feed.select(symbol,frame)
    callbacks['chart_select']=chart_select
    callbacks['funding_snapshot']=chart_feed.funding.snapshot
    def chart_older(symbol,frame):
        if symbol in {p['symbol'] for p in view.positions} | {r['symbol'] for r in view.state.get('futures_market',{}).get('rows',[])}:chart_feed.load_older(symbol,frame)
    callbacks['chart_older']=chart_older
    import uuid
    def click_entry(symbol,direction):
        engine.send('click_order',op='entry',symbol=symbol,direction=direction,request_id=uuid.uuid4().hex,issued_at=time.monotonic())
    def close_one(row):
        engine.send('click_order',op='close_one',key=row['close_key'],request_id=uuid.uuid4().hex,issued_at=time.monotonic())
    callbacks.update(click_entry=click_entry,close_one=close_one)
    view.state['profile_name']=engine.cfg['execution'].get('profile','')
    view.state["band_flow_profile"]=engine.cfg.get("signals",{}).get("band_flow",{}).get("enabled",False)
    def mobile_help():
        address=ROOT/'MOBILE_ADDRESS.txt'
        url=(address.read_text(encoding='utf-8').splitlines()[0].split('?')[0].rstrip('/')+'/') if address.exists() else '최초 설정 후 MOBILE_ADDRESS.txt에 주소가 저장됩니다.'
        messagebox.showinfo('휴대폰 시작·중지 및 조회',('조회 서버 실행 중' if mobile else '최초 설정 또는 PC 프로그램 재실행이 필요합니다.')+'\n\n1. PC와 iPhone에 Tailscale 설치, 같은 계정 로그인\n2. PC에서 SETUP_MOBILE.bat 실행, 별도 비밀번호 설정\n3. PC 프로그램 정상 종료 후 다시 실행\n4. 휴대폰 Tailscale 연결 후 Safari에서 주소 열기\n\n'+url+'\n\n상세 방법: MOBILE_BEGINNER_KO.txt / 시작은 모바일에서 확인 필요 · 롱/숏 직접진입 및 개별청산 지원 · 이체 없음')
    callbacks['mobile_view']=mobile_help
    from okx_mobile_update732 import MobileUpdater
    mobile_updater=MobileUpdater(ROOT,engine,mobile) if mobile else None
    update_window=[None]
    def program_update():
        from okx_update732 import UpdateWindow
        if update_window[0] and update_window[0].win.winfo_exists():
            update_window[0].win.lift();return
        update_window[0]=UpdateWindow(app,ROOT,engine)
    callbacks['update']=program_update
    from okx_update732 import UpdateNotice
    update_notice=UpdateNotice(ROOT,events);update_notice.start()
    def budget_value():
        try:
            amount=float(view.budget.get())
            if not .01<=amount<=6:raise ValueError()
            return amount
        except ValueError:messagebox.showerror('예산 확인','0.01~6달러 사이의 숫자를 입력하세요.');return None
    def preview():
        amount=budget_value()
        if amount is not None:engine.send('preview',budget=amount)
    def live():
        amount=budget_value()
        if amount is None:return
        duration=24 # Legacy parameter; continuous mode ignores expiry.
        if latest['equity'] is None or time.monotonic()-last_status[0]>30:
            messagebox.showinfo('잔고 조회 필요','현재 계정 조회가 끝날 때까지 기다려주세요. 설정에서 상태 새로고침을 실행할 수 있습니다.');return
        if dec(latest['equity'])<1:messagebox.showinfo('자금 이동 필요','거래 계정 USDT가 1 미만입니다. 자금 이동 후 다시 확인하세요.');return
        text=(f"현재 거래 계정 평가자산: {float(latest['equity']):.6f} USDT\n"
            '최초 자동 자금 ⅓ 고정(수동 거래 분리), 여러 종목·계좌 위험 한도 내, 자율3~10배(총노출 한도 우선) 시장가 자동주문.\n'
            '추가 비율 자동, 물타기/불타기 각 최대 1회, 공용 증거금 최대 ⅔.\n'
            '포지션 ROE −30% 최종 손절 / 일일 −21% 또는 +1000% 도달 시 보유 정리.\n'
            '급변·슬리피지로 손절 가격과 수익은 보장되지 않습니다.\n'
            f'신규 진입 시간 제한 없음 / 자동·채팅 AI 하루 공용 예산: ${amount:.2f}\n\n실제 주문을 활성화할까요?')
        if engine.cfg.get('signals',{}).get('band_flow',{}).get('enabled'):
            text=(f"현재 거래 계정 평가자산: {float(latest['equity']):.6f} USDT\n"
                'v6.43 전체 USDT 선물·주식 연동 포함 / 재상승/재하락 실패 OR 밴드 꼬리 OR 거래량 지지·저항 진입.\n'
                '자동 신규 전 종목10배 · 주식 제외 · 기존 포지션 배율 유지.\n'
                '최초 ⅓ · 직전 체결가에서 5% 역행마다 최대 ⅓씩 2회 추가.\n'
                '일일 손실 중단·최종 ROE -30% 해제 / 구조 보호 SL·청산가 접근 정리 유지.\n'
                '손익비1.1·실제 잔고·중복 방지·데이터 확인은 유지합니다.\n'
                '고배율은 5% 물타기 전에 강제청산될 수 있습니다.\n\n실제 주문을 활성화할까요?')
        text='6.87 FREE5\n'+('10월23일 네 전략 OR / BTC·ETH·SOL·주식 제외 / 최소 손익비1.1' if 'FREE5'=='OCT23' else 'AI가 진입·추가·청산 결정 / 자동 신규 전 종목10배·최초 최대1/3 / AI 호출 유료·기존 하루$6 공유')+'\n\n'+text
        profile=engine.cfg['execution'].get('profile')
        if profile in ('OCT23','FREE5'):
            text=f"현재 거래 계정 평가자산: {float(latest['equity']):.6f} USDT\n"
            if profile=='OCT23':text+='10월23일 조건 재구현: 추세 눌림 OR 돌파 재확인 OR 볼밴 꼬리 복귀 OR 고저점 재시험 실패.\nBTC·ETH·SOL·주식 연동 제외 / 손익비1.1 / 기타 기본4배.\n최초⅓·기존5% 간격 추가/보호관리 유지. 자동 진입 AI 호출 없음.\n'
            else:text+='별도 AI 자율형: 로컬 진입신호 필터 없음 / 자동 신규 전 종목10배·최초 최대1/3.\nAI가 진입·SL·목표·비중·추가·부분/전량 청산·추적SL을 판단.\n최초 증거금⅓ / 추가는 남은 자금에서 AI 판단 / 보호SL·중복방지 유지.\nAI 호출 유료 / 두 프로필 합산 하루 최대$6·자동$6·유료채팅 제거.\n'
            text+='일일 손실 중단 없음 / +1000% 중단·청산가 접근 정리 유지.\n수익이나 체결을 보장하지 않습니다.\n\n비정상 재시작·일시 오류는 계정/주문/SL 대조 후 자동 재개합니다.\n직접 중지·전체 청산·정상 종료를 누르면 자동 재개하지 않습니다.\n\n실거래를 활성화할까요?'
        if config['execution'].get('rule_channel701'):
            text=f"현재 평가자산 {float(latest['equity']):.6f} USDT\n"+'V7.32-Q2U · V7.32 기존15m OR 두꼬리 · 4H 추가 진입 삭제\n자동 진입 기타10배 · BTC20배 · ETH/SOL15배 / 버튼 진입 전 종목5배\n자동 운용 시드에서3 USDT 유보 후 1/4씩 · 최대4개 · 잔고 부족 시 소액 대체 없음\n최초2ATR SL · +20% 관측ROE 최초 절반익절 · 잔량 본전/추적보호 · 최대6시간\n청산 확인 후 기존 규칙의 새 신호 탐색 · 유료AI 호출 없음\n기존3배 포지션의 배율은 유지합니다. 기존4H 보유분에도 공통 수익보호와6시간 종료가 적용됩니다. 이미6시간이 지났다면 재개 후 종료될 수 있습니다.\n수동 보유분 관리 제외 · 실거래 순수익 개선은 아직 검증되지 않았습니다.\n\n비정상 재시작·일시 오류는 계정/주문/SL 대조 후 자동 재개합니다.\n직접 중지·전체 청산·정상 종료를 누르면 자동 재개하지 않습니다.\n\n실거래를 활성화할까요?' 
        if messagebox.askyesno('실거래 시작',text,default='no'):engine.send('live',equity=latest['equity'],budget=amount,hours=duration)
    def preflight():
        import subprocess
        flags=getattr(subprocess,'CREATE_NEW_CONSOLE',0)
        subprocess.Popen([sys.executable,str(ROOT/'check_live.py'),'--pause'],cwd=str(ROOT),creationflags=flags)
    def close_positions():
        if messagebox.askyesno('보유분 청산 후 중지','수동 보유를 포함한 모든 USDT 선물 포지션을 시장가로 청산하고 신규 진입을 중지할까요?',default='no'):engine.send('click_order',op='close_all',request_id=uuid.uuid4().hex,issued_at=time.monotonic())
    callbacks.update(live=live,preview=preview,pause=lambda:engine.send('pause'),close=close_positions,
        refresh=lambda:engine.send('refresh'),settings=view.show_settings,history=view.show_history,positions=view.show_positions,preflight=preflight,
        api_credit_refresh=lambda:engine.send('api_credit_refresh'),api_credit_sync=lambda **kw:engine.send('api_credit_sync',**kw),position_history_query=lambda **kw:engine.send('position_history',**kw),reconnect=lambda:engine.send('reconnect'),telegram_test=lambda:engine.send('telegram_test'),
        chat_selected=lambda **kw:engine.send('chat_selected',**kw),chat_cancel_selected=lambda:engine.send('chat_cancel_selected'))
    # Buttons keep a forwarding callback so replacing callbacks cannot leave a stale placeholder.
    view.start.command=lambda:callbacks['live']();view.pause.command=lambda:callbacks['pause']()
    view.preview.command=lambda:callbacks['preview']();view.close.command=lambda:callbacks['close']()
    def poll():
        for _ in range(150):
            try:kind,value=events.get_nowait()
            except queue.Empty:break
            if kind=='update_notice':
                view.update_notice=value;view.schedule()
                continue
            if kind=='mobile_update_status':
                if mobile_updater:mobile_updater.engine_result(value)
                continue
            if kind=='update_message':
                view.add_activity(time.strftime('%H:%M:%S'),value)
                if update_window[0] and update_window[0].win.winfo_exists():update_window[0].status.set(value)
                continue
            if kind=='status':latest.update(value);last_status[0]=time.monotonic()
            if kind=='click_result':
                view.add_activity(time.strftime('%H:%M:%S'),value['message']);view.receive('click_gate',value['entry_gate']);view.schedule();continue
            if kind=='mobile_control_result':
                if mobile:mobile.complete_control(value)
                continue
            if kind=='quit':
                chart_feed.stop();market_feed.stop()
                if mobile:mobile.stop()
                app.destroy();return
            view.receive(kind,value)
        if mobile_updater:mobile_updater.poll()
        if mobile:
            for _ in range(16):
                try:command=mobile.control_commands.get_nowait()
                except queue.Empty:break
                if command['op']=='update':
                    mobile_updater.request(command);continue
                if command['op']=='prepare':
                    try:command['budget']=float(view.budget.get())
                    except ValueError:command['budget']=0
                engine.send('mobile_control',**command)
        if mobile and time.monotonic()-mobile_last[0]>=.25:
            try:mobile.capture(view);mobile_last[0]=time.monotonic()
            except Exception:pass
        if time.monotonic()-diagnostic_last[0]>=5:
            diagnostic_last[0]=time.monotonic()
            try:
                from okx_live_readonly732 import atomic_json,runtime_snapshot
                atomic_json(ROOT/'runtime_diagnostic732.json',runtime_snapshot(view,mobile))
                diagnostic_error[0]=False
            except Exception:
                if not diagnostic_error[0]:
                    view.add_activity(time.strftime('%H:%M:%S'),'읽기 전용 점검 상태 저장 실패 · 실행 폴더 쓰기 권한 확인')
                diagnostic_error[0]=True
        app.after(100,poll)
    def close_window():
        if latest.get('owned') or engine.records():
            messagebox.showinfo('보호 관리 유지','기록된 주문/포지션이 있습니다. 청산 완료를 확인한 뒤 종료하세요.');return
        if messagebox.askyesno('프로그램 종료','신규 진입을 중지하고 프로그램을 닫을까요?',default='no'):
            engine.send('pause');engine.send('quit')
    app.protocol('WM_DELETE_WINDOW',close_window)
    # Health receipt occurs before engine threads can authorize any order.
    import os
    if os.environ.get('OKX_UPDATE_HEALTH_TOKEN'):
        from okx_update732 import write_json
        write_json(ROOT/'update_health.json',{'token':os.environ['OKX_UPDATE_HEALTH_TOKEN'],'pid':os.getpid()})
    engine.start();poll();app.mainloop();update_notice.stop();chart_feed.stop();market_feed.stop();instance_lock.close()

if __name__=='__main__':main()

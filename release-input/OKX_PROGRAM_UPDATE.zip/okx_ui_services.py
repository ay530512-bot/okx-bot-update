"""Display history and Telegram/report worker. Never submits OKX orders."""
import hashlib,json,queue,socket,threading,time
from pathlib import Path
from okx_core import BotError
from okx_daily_report import atomic_json,telegram,Reporter,ReadOnlyOKX,load_journal

class EquityHistory:
    def __init__(self,root):
        self.path=Path(root)/'asset_history.json'
        try:self.points=json.loads(self.path.read_text(encoding='utf-8'))['points']
        except (OSError,ValueError,KeyError):self.points=[]
        self.points=[p for p in self.points if isinstance(p,list) and len(p)==2 and all(type(v) in (int,float) for v in p)]
    def observe(self,ms,equity):
        value=float(equity)
        if not self.points or ms-self.points[-1][0]>=300000:
            self.points.append([ms,value]);self.points=self.points[-10000:]
            atomic_json(self.path,{'points':self.points})
        return self.points+([[ms,value]] if self.points[-1][0]!=ms else [])

class TelegramBridge:
    def __init__(self,root,settings,events):
        self.root=Path(root);self.settings=dict(settings);self.events=events
        self.token=settings.get('TELEGRAM_BOT_TOKEN');self.chat=settings.get('TELEGRAM_CHAT_ID')
        self.stop_event=threading.Event();self.tests=queue.Queue(maxsize=1);self.thread=None
        self.status_lock=threading.Lock();self.last_delivery=0;self.reporter=None;self.report_lock=None
        self.report_next=0;self.test_next=0;self.test_lock=threading.Lock();self.api=None;self.session=None
        self.report_identity=None;self.report_bot_id=None
        self.update('unverified' if self.token and self.chat else 'missing')
    def update(self,status,detail=''):
        with self.status_lock:
            if status=='verified':self.last_delivery=int(time.time()*1000)
            payload=dict(status=status,detail=detail,last_success_ms=self.last_delivery)
        self.events.put(('telegram',payload))
    def delivered(self):self.update('verified','메시지 전송 응답 확인')
    def failed(self):self.update('failed','전송 결과 미확인 / 설정·네트워크 확인')
    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self.run,daemon=True,name='telegram-and-daily-report');self.thread.start()
    def request_test(self):
        if not self.token or not self.chat:
            self.update('missing','저장된 .env의 TELEGRAM_BOT_TOKEN·TELEGRAM_CHAT_ID를 확인하고 재시작하세요.');return False
        if time.monotonic()<self.test_next:return False
        if not self.test_lock.acquire(blocking=False):return False
        self.test_next=time.monotonic()+10;self.update('checking','연결·테스트 메시지 확인 중')
        def task():
            import requests
            session=requests.Session()
            try:self.test_once(session)
            except Exception:self.failed()
            finally:session.close();self.test_lock.release()
        threading.Thread(target=task,daemon=True,name='telegram-manual-test').start()
        return True
    def check_target(self,session=None):
        session=session or self.session
        bot=telegram(session,self.token,'getMe')
        target=telegram(session,self.token,'getChat',chat_id=self.chat)
        if target.get('type')!='private' or str(target.get('id'))!=str(self.chat):raise BotError('기존 개인 수신 대상 불일치')
        return bot
    def send(self,text,session=None):
        telegram(session or self.session,self.token,'sendMessage',chat_id=self.chat,text=text)
        self.delivered()
    def test_once(self,session=None):
        self.check_target(session);self.send('['+str(self.settings.get('TRADING_EXCHANGE') or 'okx').upper()+'] 텔레그램 연결 테스트 성공\n프로그램에서 전송했습니다. 매매 주문은 실행하지 않았습니다.',session)
    def report_once(self):
        if not self.report_lock:
            lock=socket.socket()
            if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):lock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
            try:lock.bind(('127.0.0.1',48737))
            except OSError:
                lock.close();self.events.put(('report_state',dict(status='external',detail='기존 별도 보고서 창 사용 중 · 중복 실행 방지')));return
            self.report_lock=lock
        if not self.api:self.api=ReadOnlyOKX(self.settings)
        snapshot=self.api.snapshot()
        uid=snapshot['config'].get('uid')
        if not uid:raise BotError('보고서 계정 식별 확인 실패')
        if not self.reporter:
            bot=self.check_target();self.report_bot_id=str(bot['id'])
            identity=hashlib.sha256((str(uid)+':'+self.report_bot_id+':'+str(self.chat)).encode()).hexdigest()
            self.reporter=Reporter(self.root,self.api,self.send,identity);self.report_identity=identity
        identity=hashlib.sha256((str(uid)+':'+self.report_bot_id+':'+str(self.chat)).encode()).hexdigest()
        if identity!=self.report_identity:raise BotError('보고서 계정 변경 감지')
        self.reporter.observe(snapshot,load_journal(self.root));self.reporter.due(snapshot['ms'])
        self.events.put(('report_state',dict(status='running',detail='일일 보고 00:10 KST · 프로그램을 켜 두세요')))
    def run(self):
        import requests
        self.session=requests.Session()
        try:
            while not self.stop_event.is_set():
                if self.token and self.chat and time.monotonic()>=self.report_next:
                    self.report_next=time.monotonic()+30
                    try:self.report_once()
                    except Exception:
                        self.events.put(('report_state',dict(status='error',detail='일일 보고 조회 보류 · 설정/연결 확인, 30초 후 재시도')))
                self.stop_event.wait(.2)
        finally:
            self.session.close()
            if self.api:self.api.session.close()
            if self.report_lock:self.report_lock.close()
    def stop(self):self.stop_event.set()

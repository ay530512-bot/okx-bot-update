"""Validate installation/account routing before constructing any execution transport."""
import json
from pathlib import Path

def require_okx(root,settings):
    # Retain name for updater compatibility; now validates all supported exchanges.
    e=str(settings.get('TRADING_EXCHANGE') or 'okx').lower()
    if e not in ('okx','binance','bitget'):raise ValueError('지원하지 않는 거래소 설정입니다.')
    p=Path(root)/'installation_exchange.json'
    if p.exists():
        try:meta=json.loads(p.read_text(encoding='utf-8'))
        except Exception:raise ValueError('설치 거래소 기록 확인 필요') from None
        if meta.get('exchange')!=e:raise ValueError('설치 폴더와 API 거래소 불일치. 신규 주문 없음.')
    elif e!='okx':raise ValueError('선택 거래소 전용 설치 폴더에서 실행하세요.')

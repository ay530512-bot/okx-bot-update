"""Read-only manual entry snapshots; no exchange requests or position control."""
import json,math,time
from okx_core import BotError
from pathlib import Path

def save(path,data):
 tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');tmp.replace(path)

def update(e):
 if time.monotonic()-getattr(e,'_manual_learning_poll',-1e9)<30:return
 e._manual_learning_poll=time.monotonic()
 path=Path(e.root)/'manual_learning_entries.json'
 try:entries=json.loads(path.read_text(encoding='utf-8'))
 except (OSError,ValueError):entries={}
 universe,_=e.universe.read();rows={r['symbol']:r for r in (universe or {}).get('rows',[])}
 owned={(r['symbol'],r['direction']) for r in e.records()}
 from okx_position_history import key
 from okx_volume_entry import evidence
 from okx_free_ai import packet
 changed=False
 for p in (e.raw_snapshot or {}).get('positions',[]):
  symbol=p.get('instId');direction=p.get('posSide');identity=key(p)
  if (symbol,direction) in owned or direction not in ('long','short') or not p.get('posId'):continue
  try:
   qty=abs(float(p.get('pos') or 0));price=float(p.get('avgPx') or 0);entry=int(p['cTime'])
   if qty<=0 or price<=0:continue
   if identity in entries:
    old=entries[identity]
    if old.get('quantity')!=qty or old.get('entry_price')!=price:
     old['changed_exposure']=True;changed=True
    q=old.get('quality_context',{})
    if q.get('atr') and float(p.get('markPx') or 0)>0:
     move=(float(p['markPx'])-q['entry'])*(1 if direction=='long' else -1)/q['atr'];ex=old.setdefault('observed_excursion',dict(samples=0,favorable_atr=0.,adverse_atr=0.));ex.update(samples=ex['samples']+1,favorable_atr=max(ex['favorable_atr'],move),adverse_atr=max(ex['adverse_atr'],-move));changed=True
    continue
   if abs(int((e.raw_snapshot or {}).get('ms',0))-entry)>60000:continue
   row=rows.get(symbol)
   if not row:continue
   # packet filters every OHLCV bar at entry time; later candles cannot label the entry.
   data=packet(row,e.cfg,entry,{'last':price})
   if e.cfg['execution'].get('structure694'):
    frame='15m';proof=next((v for v in data['entry_setups'] if v['action']==('LONG' if direction=='long' else 'SHORT')),None)
    if proof:
     ct=float(row['instrument']['ctVal']);risk=abs(price-proof['structural_stop'])*qty*ct;quality=__import__('okx_trade_quality').context(data['frames'],frame,price,proof['structural_stop'],direction);quality['regime']=proof['market_regime'];meta=dict(setup=proof['setup'],frame=frame,key694=proof['learning_key'])
    else:risk=0;quality={};meta=dict(setup='manual_unclassified',frame=frame,key694=None)
    entries[identity]=dict(symbol=symbol,direction=direction,entry_ms=entry,entry_price=price,quantity=qty,learning=meta,estimated_loss=risk,quality_context=quality,changed_exposure=False,observations=data['frames'],risk_basis='Manual reference only: hypothetical structure stop, not observed actual SL; unclassified has no R denominator')
    changed=True
   else:
    for frame,observations in data['frames'].items():
     try:proof=evidence(observations,'LONG' if direction=='long' else 'SHORT',price)
     except Exception:continue
     ct=float(row['instrument']['ctVal']);risk=abs(price-proof['structural_stop'])*qty*ct
     if not math.isfinite(risk) or risk<=0:continue
     entries[identity]=dict(symbol=symbol,direction=direction,entry_ms=entry,entry_price=price,quantity=qty,learning=dict(setup=proof['setup'],frame=frame),estimated_loss=risk,quality_context=__import__('okx_trade_quality').context(data['frames'],frame,price,proof['structural_stop'],direction),changed_exposure=False,observations=data['frames'],risk_basis='Hypothetical structural invalidation, not actual SL');changed=True;break
  except (KeyError,ValueError,TypeError,BotError):continue
 if changed:save(path,entries)
 # Only finalized, uniquely classified external manual positions become outcome samples.
 with e.position_history.lock:
  history=list(e.position_history.rows.values());sources=dict(e.position_history.sources)
 output=[]
 for row in history:
  identity=key(row);item=entries.get(identity)
  if not item or item.get('changed_exposure') or sources.get(identity,{}).get('source')!='manual' or row.get('type') not in ('2','3','6'):continue
  try:
   pnl=float(row['realizedPnl'])
   if not math.isfinite(pnl):continue
  except (KeyError,ValueError,TypeError,BotError):continue
  output.append(dict(symbol=item['symbol'],client_id='manual:'+identity,source='manual',direction=item['direction'],learning=item['learning'],estimated_loss=item['estimated_loss'],realizedPnl=pnl,
   learning_risk_usdt=item['estimated_loss'] if item['learning'].get('key694') else None,observed_excursion=item.get('observed_excursion',{}),end_ms=row.get('uTime'),exit_price=row.get('closeAvgPx'),quality_context=item.get('quality_context',{}),risk_basis=item['risk_basis']))
 save(Path(e.root)/'manual_learning_results.json',output)
 from okx_online_learning import refresh
 refresh(e)
 if getattr(e,'_manual_sample_count',None)!=len(output):
  e._manual_sample_count=len(output);e.log('수동학습 / 확정 표본 '+str(len(output))+'건 / 진입 직후 자료확보 거래만 반영·수동 포지션 제어 없음')

"""Binance USD-M / Bitget Classic execution behind the existing engine contract.

The /api/v5 strings are INTERNAL compatibility operations, never external URLs.
CCXT maps them to the selected exchange. No network operation runs on import.
"""
import hashlib,json,threading,time
from pathlib import Path
from decimal import Decimal,ROUND_DOWN
from okx_core import BotError,Rejected,UnknownOutcome,dec,fmt

_LOCK=threading.RLock();_STORES={};_MARKET_CACHE={}
FRAMES={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000,'1Dutc':86400000}
EXCLUDED={'AAPL','TSLA','NVDA','MSFT','AMZN','GOOG','GOOGL','META','COIN','MSTR','SPY','QQQ','XAU','XAG','XAUT','PAXG','CL','BZ','XCU','USO','SPX','NDX','DJI','SILVER','GOLD'}

def exchange_id(settings):
 value=str(settings.get('TRADING_EXCHANGE') or 'okx').lower()
 if value not in ('okx','binance','bitget'):raise BotError('지원하지 않는 거래소')
 return value

def make_client(settings):
 import ccxt
 e=exchange_id(settings);prefix=e.upper()
 options={'defaultType':'future' if e=='binance' else 'swap','defaultSubType':'linear','adjustForTimeDifference':True,'maxRetriesOnFailure':0,'fetchCurrencies':False,'warnOnFetchOpenOrdersWithoutSymbol':False,'fetchOpenOrders':{'warnWithoutSymbol':False}}
 cfg=dict(apiKey=settings.get(prefix+'_API_KEY'),secret=settings.get(prefix+'_SECRET_KEY'),password=settings.get(prefix+'_PASSPHRASE'),enableRateLimit=True,timeout=10000,options=options)
 if not cfg['apiKey'] or not cfg['secret'] or (e=='bitget' and not cfg['password']):raise BotError(e+' API 필수 정보 누락')
 client=(ccxt.binanceusdm if e=='binance' else ccxt.bitget)(cfg)
 if str(settings.get('EXCHANGE_DEMO','0'))=='1':client.set_sandbox_mode(True)
 return client

class Store:
 def __init__(self,root,identity):
  self.root=Path(root);self.path=self.root/'exchange_transport.json';self.lock=threading.RLock()
  self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else dict(identity=identity,orders={},stops={},cycles={},positions={})
  if self.data.get('identity')!=identity:raise BotError('다른 거래소/API 키의 운용 기록입니다. 새 계정 폴더를 사용하세요.')
 def save(self):
  from okx_daily_report import atomic_json
  self.root.mkdir(parents=True,exist_ok=True);atomic_json(self.path,self.data)
def store_for(root,identity):
 with _LOCK:
  key=(str(Path(root).resolve()),identity)
  if key not in _STORES:_STORES[key]=Store(root,identity)
  return _STORES[key]

class FuturesAdapter:
 def __init__(self,settings,client=None,execution=False):
  self.settings=dict(settings);self.exchange=exchange_id(settings)
  if self.exchange=='okx':raise BotError('OKX는 기존 네이티브 연결을 사용합니다.')
  self.client=client or make_client(settings);self.session=self.client.session
  self.execution=execution;self.synced=0;self.server_ms=0;self.anchor=0;self.read_efficiency=False
  identity=self.exchange+':'+hashlib.sha256(str(settings.get(self.exchange.upper()+'_API_KEY','')).encode()).hexdigest()
  self.identity=identity;self.candle_cache_namespace=identity;self.instruments={};self.markets={};self.last_markets=0;self.opening={};self.mode_cache={};self.ledger_cache=None
  root=settings.get('_EXCHANGE_ROOT')
  if execution and not root:raise BotError('주문 복구 기록 폴더 누락')
  self.store=store_for(root,identity) if root else None
 def _call(self,name,*args,write=False,**kw):
  if write and not self.execution:raise BotError('읽기 전용 연결에서 주문/설정 변경 차단')
  try:return getattr(self.client,name)(*args,**kw)
  except Exception as e:
   import ccxt
   # Treat transient exchange replies and malformed write replies as UNKNOWN.
   if write and not isinstance(e,(ccxt.InvalidOrder,ccxt.InsufficientFunds,ccxt.AuthenticationError,ccxt.PermissionDenied,ccxt.BadSymbol,ccxt.ArgumentsRequired)):
    raise UnknownOutcome(self.exchange+' 쓰기 응답 미확인. client ID 조회로 확인하며 재전송하지 않습니다.') from None
   kind=Rejected if write or isinstance(e,ccxt.OrderNotFound) else BotError
   raise kind(self.exchange+' '+type(e).__name__+' · 키/권한/주문 상태를 확인하세요.') from None
 def sync(self):
  value=self._call('fetch_time')
  if not value:raise BotError('거래소 시간 누락')
  self.server_ms=int(value);self.anchor=self.synced=time.monotonic()
 def now_ms(self):
  if not self.server_ms or time.monotonic()-self.synced>300:self.sync()
  return self.server_ms+int((time.monotonic()-self.anchor)*1000)
 def safe(self,message):
  text=str(message)
  for k,v in self.settings.items():
   if v and any(t in k for t in ('KEY','TOKEN','PASSPHRASE')):text=text.replace(str(v),'[숨김]')
  return text[:300]
 def _load(self):
  if self.markets and time.monotonic()-self.last_markets<600:return
  cachekey=(self.exchange,type(self.client).__module__,str(self.settings.get('EXCHANGE_DEMO','0')))
  with _LOCK:
   cached=_MARKET_CACHE.get(cachekey)
   if cached and time.monotonic()-cached[0]<600:
    allmarkets=cached[1]
    if hasattr(self.client,'set_markets'):self.client.set_markets(list(allmarkets.values()))
    self.spot_bases=cached[2]
   else:
    allmarkets=self._call('load_markets')
    try:
     if self.exchange=='binance':
      spot=self._call('publicGetExchangeInfo').get('symbols',[])
      bases={r['baseAsset'] for r in spot if r.get('quoteAsset')=='USDT' and r.get('status')=='TRADING'}
     else:
      spot=self._call('publicSpotGetV2SpotPublicSymbols').get('data',[])
      bases={r['baseCoin'] for r in spot if r.get('quoteCoin')=='USDT' and r.get('status')=='online' and r.get('symbolType','crypto')=='crypto'}
     self.spot_bases=bases
     _MARKET_CACHE[cachekey]=(time.monotonic(),allmarkets,bases)
    except BotError:self.spot_bases=set() # Management remains possible; unknown assets cannot be entries.
  self.markets={};self.instruments={}
  for m in allmarkets.values():
   if not (m.get('swap') and m.get('linear') and m.get('settle')=='USDT' and m.get('quote')=='USDT'):continue
   s=m['base']+'-USDT-SWAP';self.markets[s]=m
   precision=m.get('precision',{});limits=m.get('limits',{});native=m.get('info',{})
   # TICK_SIZE precision is required. Never infer decimal places from an integer.
   import ccxt
   if self.client.precisionMode!=ccxt.TICK_SIZE:raise BotError('지원하지 않는 거래소 정밀도 모드')
   tick=precision.get('price');lot=precision.get('amount');minimum=limits.get('amount',{}).get('min')
   if not tick or not lot or not minimum:continue
   category=str(native.get('underlyingType','COIN')).upper()
   flags=' '.join(str(native.get(k,'')) for k in ('underlyingSubType','category','assetType','symbolType','businessType')).upper()
   stock=bool(m.get('stock')) or category not in ('COIN','CRYPTO') or any(t in flags for t in ('STOCK','INDEX','EQUITY','COMMODITY','TRADFI','ETF')) or m['base'].upper() in EXCLUDED or m['base'].upper().endswith(('STOCK','XSTOCK')) or m['base'] not in self.spot_bases
   # Classification is a conservative transport policy, not a fabricated exchange category.
   self.instruments[s]=dict(instId=s,instFamily=m['base']+'-USDT',instType='SWAP',settleCcy='USDT',ctType='linear',ctVal=fmt(m.get('contractSize') or 1),ctValCcy=m['base'],tickSz=fmt(tick),lotSz=fmt(lot),minSz=fmt(minimum),maxMktSz=fmt(limits.get('amount',{}).get('max') or '1000000000'),lever=fmt(limits.get('leverage',{}).get('max') or 5),state='live' if m.get('active') is True else 'suspend',instCategory='0' if stock else '1',groupId='4',listTime=str(native.get('onboardDate') or native.get('launchTime') or native.get('symbolStatusTime') or 0),asset_classification='excluded or crypto classification unverified' if stock else 'native futures and actual same-exchange spot listing; exclusions applied',transport_exchange=self.exchange,minNotional=fmt(limits.get('cost',{}).get('min') or 0))
  self.last_markets=time.monotonic()
 def market(self,s):
  self._load()
  if s not in self.markets:raise BotError('선택 거래소에 없는 USDT 무기한 종목: '+str(s))
  return self.markets[s]
 def canonical(self,symbol):
  self._load()
  for s,m in self.markets.items():
   if symbol in (m['symbol'],m['id']):return s
  raise BotError('선물 종목 식별 불가')
 def mode(self,s=None):
  if self.exchange=='binance':return bool(self._call('fetch_position_mode').get('hedged'))
  m=self.market(s or next(iter(self.instruments)))
  r=self._call('privateMixGetV2MixAccountAccount',dict(symbol=m['id'],productType='USDT-FUTURES',marginCoin='USDT'))
  mode=r.get('data',{}).get('posMode')
  if mode not in ('one_way_mode','hedge_mode'):raise BotError('비트겟 포지션 모드 확인 불가')
  return mode=='hedge_mode'
 def _positions(self):
  rows=self._call('fetch_positions',None,{'type':'future' if self.exchange=='binance' else 'swap','subType':'linear','productType':'USDT-FUTURES'})
  out=[]
  for p in rows:
   if not p.get('contracts'):continue
   s=self.canonical(p['symbol']);m=self.market(s);info=p.get('info',{});direction=p.get('side')
   if direction not in ('long','short'):raise BotError('포지션 방향 확인 불가')
   margin=p.get('initialMargin');lev=p.get('leverage')
   if lev is None:
    lv=self.leverage(s);lev=lv.get(direction)
   if not lev or not p.get('entryPrice') or not p.get('markPrice'):raise BotError('포지션 진입가/마크/배율 누락')
   if margin is None:margin=abs(dec(p['notional']))/dec(lev)
   pnl=dec(p.get('unrealizedPnl') or 0);roe=pnl/dec(margin) if dec(margin)>0 else dec(0)
   key=s+':'+direction;posid=str(info.get('positionId') or '')
   created=info.get('cTime') or p.get('timestamp')
   if self.store:
    with self.store.lock:
     previous=self.store.data['positions'].get(key)
     if not previous or not previous.get('active'):
      cycle=next((x for x in self.store.data['cycles'].values() if x['symbol']==s and x['direction']==direction and not x.get('closed_ms')),None)
      born=int(created or (cycle or {}).get('entry_ms') or self.now_ms())
      if cycle is None:
       manual_id='manual-'+hashlib.sha256((key+str(born)).encode()).hexdigest()[:24]
       self.store.data['cycles'][manual_id]=dict(id=manual_id,symbol=s,direction=direction,entry_ms=born,had_fill=True,orders=[],source='manual')
       cycle=self.store.data['cycles'][manual_id]
      previous=dict(posid=posid or (cycle or {}).get('id') or hashlib.sha256((key+str(born)).encode()).hexdigest()[:24],created=born,active=True)
      self.store.data['positions'][key]=previous;self.store.save()
     posid=previous['posid'];created=previous['created']
   else:posid=posid or key;created=created or 0
   out.append(dict(instType='SWAP',instId=s,posSide=direction,pos=fmt(abs(dec(p['contracts']))),mgnMode=p.get('marginMode') or info.get('marginMode'),lever=fmt(lev),avgPx=fmt(p['entryPrice']),markPx=fmt(p['markPrice']),upl=fmt(pnl),uplRatio=fmt(roe),imr=fmt(margin),margin=fmt(margin),notionalUsd=fmt(abs(dec(p.get('notional') or dec(p['contracts'])*dec(m['contractSize'])*dec(p['markPrice'])))),liqPx=fmt(p.get('liquidationPrice') or 0),posId=posid,cTime=str(created),uTime=str(info.get('updateTime') or info.get('uTime') or self.now_ms())))
  if self.store:
   active={p['instId']+':'+p['posSide'] for p in out}
   with self.store.lock:
    change=False
    for key,p in self.store.data['positions'].items():
     if p.get('active') and key not in active:p['active']=False;change=True
    for cycle in self.store.data['cycles'].values():
     key=cycle['symbol']+':'+cycle['direction']
     if key in active:
      cycle['seen_position']=True;cycle['had_fill']=True;cycle['flat_checks']=0
      if any(p['instId']==cycle['symbol'] and p['posSide']!=cycle['direction'] for p in out):cycle['opposite_overlap']=True
      cycle['posid']=self.store.data['positions'][key]['posid'];change=True
     elif cycle.get('had_fill') and not cycle.get('closed_ms') and self.now_ms()-cycle['entry_ms']>15000:
      cycle['flat_checks']=cycle.get('flat_checks',0)+1;change=True
      if cycle['flat_checks']>=2:cycle['closed_ms']=self.now_ms()
    if change:self.store.save()
  return out
 def leverage(self,s):
  m=self.market(s)
  if self.exchange=='binance':r=self._call('fetch_leverages',[m['symbol']])[m['symbol']]
  else:r=self._call('fetch_leverage',m['symbol'])
  return dict(long=r.get('longLeverage'),short=r.get('shortLeverage'),marginMode=r.get('marginMode'))
 def snapshot(self):
  self._load();b=self._call('fetch_balance',{'type':'future' if self.exchange=='binance' else 'swap','productType':'USDT-FUTURES'})
  u=b.get('USDT')
  if not isinstance(u,dict) or u.get('total') is None or u.get('free') is None:raise BotError('USDT 선물 잔고 확인 불가')
  # Binance CCXT total is wallet balance; add the verified USDT unrealized PnL.
  equity=dec(u['total']);info=b.get('info',{})
  if self.exchange=='binance':
   asset=next((r for r in info.get('assets',[]) if r.get('asset')=='USDT'),None)
   if not asset or asset.get('marginBalance') is None:raise BotError('바이낸스 USDT 평가자산 확인 불가')
   equity=dec(asset['marginBalance'])
  elif isinstance(info,list) or isinstance(info,dict) and isinstance(info.get('data'),list):
   accounts=info if isinstance(info,list) else info['data']
   asset=next((r for r in accounts if r.get('marginCoin')=='USDT'),None)
   if not asset or asset.get('accountEquity') is None:raise BotError('비트겟 USDT 평가자산 확인 불가')
   equity=dec(asset['accountEquity'])
   if asset.get('available') is None:raise BotError('비트겟 실제 가용잔고 누락')
   u=dict(u,free=asset['available'])
  else:raise BotError('비트겟 Classic 선물 계정 응답 확인 필요 (UTA 별도)')
  pos=self._positions();orders=self._call('fetch_open_orders',None,None,None,{})
  if len(orders)>=100:raise BotError('미체결 주문 전체 확인 한도 초과')
  return dict(config=dict(acctLv='2',posMode='long_short_mode',uid=self.identity,native_hedged=self.mode(),exchange=self.exchange),equity=equity,available=dec(u['free']),positions=pos,orders=[self.order_row(o) for o in orders],ms=self.now_ms())
 def order_row(self,o):
  info=o.get('info',{});cid=o.get('clientOrderId') or info.get('clientOid') or info.get('clientAlgoId') or info.get('origClientOrderId') or ''
  return dict(instId=self.canonical(o['symbol']),clOrdId=cid,ordId=str(o.get('id') or ''),state={'closed':'filled','canceled':'canceled','cancelled':'canceled','expired':'canceled','rejected':'canceled','open':'partially_filled' if o.get('filled') else 'live'}.get(o.get('status'),'unknown'),accFillSz=fmt(o.get('filled') or 0),avgPx=fmt(o.get('average') or info.get('avgPrice') or info.get('priceAvg') or 0),sz=fmt(o.get('amount') or 0),posSide=info.get('positionSide',info.get('holdSide','')).lower(),side=o.get('side'),cTime=str(o.get('timestamp') or 0))
 def _fetch_order(self,s,cid,trigger=False,oid=None):
  m=self.market(s);params={'trigger':True} if trigger else {}
  if not oid:params['clientOrderId']=cid
  return self._call('fetch_order',oid or '',m['symbol'],params)
 def _stop_rows(self):
  if self.exchange=='binance':orders=self._call('fetch_open_orders',None,None,None,{'trigger':True})
  else:
   orders=[]
   for kind in ('normal_plan','profit_loss','track_plan'):orders+=self._call('fetch_open_orders',None,None,100,{'trigger':True,'planType':kind,'productType':'USDT-FUTURES'})
  if len(orders)>=100:raise BotError('조건주문 전체 조회 한도 초과')
  return orders
 def _normalize_stop(self,o):
  info=o.get('info',{});physical=o.get('clientOrderId') or info.get('clientAlgoId') or info.get('clientOid') or ''
  s=self.canonical(o['symbol']);side=info.get('positionSide',info.get('holdSide','')).lower()
  if side in ('both','','buy','sell'):side='long' if o.get('side')=='sell' else 'short'
  logical=physical;trigger=o.get('stopLossPrice') or o.get('triggerPrice') or info.get('triggerPrice') or info.get('stopPrice')
  working=info.get('workingType') or info.get('triggerType');mark=working in ('MARK_PRICE','mark_price')
  if self.store:
   for cid,v in self.store.data['stops'].items():
    if physical in (cid,v.get('physical'),v.get('old_physical')):
     logical=cid
     if info.get('positionSide',info.get('holdSide','')).lower() in ('both','','buy','sell'):side=v['body']['posSide']
     break
  return dict(instId=s,posSide=side,algoClOrdId=logical,algoId=str(o.get('id') or info.get('algoId') or ''),physical_client_id=physical,ordType='conditional',state='live' if o.get('status')=='open' else 'unknown',sz=fmt(o.get('amount') or info.get('quantity') or info.get('size') or 0),slTriggerPx=fmt(trigger) if trigger is not None else '',slTriggerPxType='mark' if mark else 'last',slOrdPx='-1',side=o.get('side'))
 def pending_algos(self,full=False):
  raw=self._stop_rows()
  if self.execution and self.store and any(v.get('old_physical') for v in self.store.data['stops'].values()):
   self._recover_amendments(raw);raw=self._stop_rows()
  return [self._normalize_stop(o) for o in raw]
 def taker_fee(self,i):
  r=self._call('fetch_trading_fee',self.market(i['instId'])['symbol']);v=r.get('taker')
  if v is None:raise BotError('실제 선물 수수료 확인 불가')
  return abs(dec(v))
 def _quantity(self,s,q):
  m=self.market(s);value=self.client.amount_to_precision(m['symbol'],str(q))
  if dec(value)!=dec(q):raise Rejected('거래소 수량 단위 불일치: 상향 반올림 금지')
  if dec(q)<=0:raise Rejected('수량은 양수여야 합니다.')
  return value
 def _build_order(self,body,stop=False,physical=None):
  s=body['instId'];m=self.market(s);direction=body['posSide'];side=body['side'];qty=self._quantity(s,body['sz']);hedged=self.mode(s)
  closing=side!=('buy' if direction=='long' else 'sell')
  if stop and not closing:raise Rejected('손절은 포지션 축소 방향이어야 합니다.')
  # A one-way opposite position must never be adopted or netted by an entry.
  if not closing:
   for p in self._positions():
    if p['instId']==s and (p['posSide']!=direction or p['mgnMode']!='isolated'):raise Rejected('다른 방향/교차 포지션과 합산 진입 차단')
  params=dict(clientOrderId=physical or body.get('algoClOrdId') or body.get('clOrdId'),marginMode='isolated')
  if self.exchange=='binance':
   params['positionSide']=direction.upper() if hedged else 'BOTH'
   if closing and not hedged:params['reduceOnly']=True
   if stop:params.update(stopLossPrice=body['slTriggerPx'],workingType='MARK_PRICE')
  else:
   params['hedged']=hedged
   if closing:params['reduceOnly']=True
   # A sized normal-plan reducing trigger, not pos_loss (which is whole-position).
   if stop:params.update(triggerPrice=body['slTriggerPx'],triggerType='mark_price')
  if not closing:
   last=self.public('/api/v5/market/ticker',instId=s)[0]['last'];mincost=dec(self.instruments[s]['minNotional'])
   if dec(qty)*dec(m.get('contractSize') or 1)*dec(last)<mincost:raise Rejected('거래소 최소 명목 주문금액 미달')
  return m['symbol'],'market',side,qty,None,params
 def _create(self,body,stop=False,physical=None):
  try:args=self._build_order(body,stop,physical)
  except (BotError,ValueError,KeyError,TypeError) as e:
   raise Rejected('거래소 주문 전 검증 실패: '+self.safe(e)) from None
  return self._call('create_order',*args,write=True)
 def _save_order(self,body):
  cid=body['clOrdId']
  with self.store.lock:
   if cid in self.store.data['orders']:raise UnknownOutcome('이미 기록된 client ID: 재전송 차단')
   self.store.data['orders'][cid]=dict(body=body,phase='sending',ms=self.now_ms())
   if body['side']==('buy' if body['posSide']=='long' else 'sell'):
    active=next((c for c in self.store.data['cycles'].values() if c['symbol']==body['instId'] and c['direction']==body['posSide'] and not c.get('closed_ms')),None)
    if not active:self.store.data['cycles'][cid]=dict(id=cid,symbol=body['instId'],direction=body['posSide'],entry_ms=self.now_ms(),had_fill=False,orders=[cid])
   self.store.save()
  return cid
 def _ensure_stop(self,cid,order):
  item=self.store.data['orders'].get(cid,{})
  body=item.get('body',{});attached=body.get('attachAlgoOrds') or []
  if not attached or dec(order.get('filled') or 0)<=0:return
  a=attached[0];key=a['attachAlgoClOrdId']
  if key in self.store.data['stops']:return
  # Don't reopen protection after a very fast flat exit; never resubmit an attempted stop.
  p=next((p for p in self._positions() if p['instId']==body['instId'] and p['posSide']==body['posSide']),None)
  if not p:return
  protect=dict(instId=body['instId'],posSide=body['posSide'],side='sell' if body['posSide']=='long' else 'buy',sz=fmt(min(dec(order['filled']),dec(p['pos']))),algoClOrdId=key,slTriggerPx=a['slTriggerPx'])
  try:self._submit_stop(protect)
  except Exception:raise UnknownOutcome('진입 체결 후 손절 응답 확인 필요: 진입 기록을 보존하고 보호 상태를 재조회합니다.') from None
 def _submit_stop(self,b):
  cid=b['algoClOrdId']
  with self.store.lock:
   if cid in self.store.data['stops']:raise UnknownOutcome('손절 client ID 재전송 차단')
   self.store.data['stops'][cid]=dict(body=b,physical=cid,phase='sending',ms=self.now_ms());self.store.save()
  o=self._create(b,True);item=self.store.data['stops'][cid];item.update(phase='sent',oid=str(o.get('id') or ''));self.store.save()
  return [dict(algoId=str(o.get('id') or ''),algoClOrdId=cid,sCode='0')]
 def _recover_amendments(self,raw):
  if not self.store:return
  for cid,v in list(self.store.data['stops'].items()):
   if not v.get('old_physical'):continue
   new=next((o for o in raw if (o.get('clientOrderId') or o.get('info',{}).get('clientAlgoId') or o.get('info',{}).get('clientOid'))==v['physical']),None)
   if not new:continue
   normalized=self._normalize_stop(new)
   if normalized['slTriggerPxType']!='mark' or normalized['slTriggerPx']!=v['body']['slTriggerPx'] or dec(normalized['sz'])!=dec(v['body']['sz']):raise BotError('새 손절의 실제 가격/수량 검증 실패')
   old=next((o for o in raw if str(o.get('id'))==str(v.get('old_oid'))),None)
   if old:self._call('cancel_order',str(old['id']),self.market(v['body']['instId'])['symbol'],{'trigger':True},write=True)
   # The next query must independently show old order absent before verification can pass.
   else:v.pop('old_physical');v.pop('old_oid',None);v['phase']='sent';self.store.save()
 def post(self,path,body):
  if not self.execution:raise BotError('조회 연결의 쓰기 차단')
  from okx_read_control import invalidate
  invalidate(self)
  if path=='/api/v5/account/set-leverage':
   m=self.market(body['instId']);hedged=self.mode(body['instId'])
   try:self._call('set_margin_mode','isolated',m['symbol'],write=True)
   except (Rejected,UnknownOutcome) as e:
    import ccxt
    # Query actual mode; don't assume an "already isolated" reply succeeded.
    if self.leverage(body['instId']).get('marginMode')!='isolated':raise e
   self._call('set_leverage',int(body['lever']),m['symbol'],{'marginMode':'isolated',**({'holdSide':body['posSide']} if self.exchange=='bitget' and hedged else {})},write=True)
   return [dict(lever=body['lever'],posSide=body['posSide'])]
  if path=='/api/v5/trade/order':
   opening=body['side']==('buy' if body['posSide']=='long' else 'sell')
   if opening and not body.get('attachAlgoOrds'):raise Rejected('진입에는 보호 손절 계획이 필요합니다.')
   cid=self._save_order(body)
   try:o=self._create(body)
   except Rejected:
    self.store.data['orders'][cid]['phase']='rejected'
    if cid in self.store.data['cycles'] and not self.store.data['cycles'][cid]['had_fill']:self.store.data['cycles'][cid]['closed_ms']=self.now_ms()
    self.store.save();raise
   self.store.data['orders'][cid].update(phase='sent',oid=str(o.get('id') or ''));self.store.save()
   opening=body['side']==('buy' if body['posSide']=='long' else 'sell')
   if opening:
    cycle=next((c for c in self.store.data['cycles'].values() if c['symbol']==body['instId'] and c['direction']==body['posSide'] and not c.get('closed_ms')),None)
    if not cycle:self.store.data['cycles'][cid]=dict(id=cid,symbol=body['instId'],direction=body['posSide'],entry_ms=self.now_ms(),had_fill=False,orders=[]);cycle=self.store.data['cycles'][cid]
    if cid not in cycle['orders']:cycle['orders'].append(cid)
    self.store.save()
   if o.get('filled'):self._mark_fill(cid,o);self._ensure_stop(cid,o)
   return [dict(ordId=str(o.get('id') or ''),clOrdId=cid,sCode='0')]
  if path=='/api/v5/trade/order-algo':return self._submit_stop(body)
  if path=='/api/v5/trade/cancel-order':
   o=self._fetch_order(body['instId'],body['clOrdId']);self._call('cancel_order',o['id'],self.market(body['instId'])['symbol'],{},write=True);return [dict(sCode='0')]
  if path=='/api/v5/trade/cancel-algos':
   for b in body:self._call('cancel_order',b['algoId'],self.market(b['instId'])['symbol'],{'trigger':True},write=True)
   return [dict(sCode='0')]
  if path=='/api/v5/trade/amend-algos':
   rows=self.pending_algos();old=next((r for r in rows if r['algoId']==body['algoId']),None)
   if not old:raise BotError('수정할 보호 주문 식별 불가')
   cid=old['algoClOrdId'];v=self.store.data['stops'].get(cid)
   if not v:raise BotError('소유 손절 기록 없음')
   if v.get('old_physical'):raise UnknownOutcome('손절 교체 확인 진행 중')
   before=dec(old['slTriggerPx']);after=dec(body['newSlTriggerPx'])
   if (old['posSide']=='long' and after<=before) or (old['posSide']=='short' and after>=before):raise Rejected('손절 불리한 확대 차단')
   physical='OS'+hashlib.sha256(body['reqId'].encode()).hexdigest()[:28]
   v.setdefault('physical_history',[]).append(dict(client=v['physical'],oid=v.get('oid')))
   v.update(old_physical=v['physical'],old_oid=old['algoId'],physical=physical,phase='replacing');v['body']=dict(v['body'],slTriggerPx=body['newSlTriggerPx']);self.store.save()
   new=self._create(v['body'],True,physical=physical);v['oid']=str(new.get('id') or '');self.store.save();self._recover_amendments(self._stop_rows());return [dict(sCode='0')]
  raise BotError('지원하지 않는 쓰기 연산: '+path)
 def _mark_fill(self,cid,o):
  if not self.store:return
  b=self.store.data['orders'][cid]['body']
  opening=b['side']==('buy' if b['posSide']=='long' else 'sell')
  if opening:
   cycle=next((c for c in self.store.data['cycles'].values() if c['symbol']==b['instId'] and c['direction']==b['posSide'] and not c.get('closed_ms')),None)
   if not cycle:
    self.store.data['cycles'][cid]=dict(id=cid,symbol=b['instId'],direction=b['posSide'],entry_ms=int(o.get('timestamp') or self.store.data['orders'][cid]['ms']),orders=[cid],had_fill=True)
   else:cycle['had_fill']=True
  self.store.data['orders'][cid]['last']=self.order_row(o)
  if o.get('id'):self.store.data['orders'][cid]['oid']=str(o['id'])
  self.store.save()
 def get(self,path,**p):
  from okx_read_control import get
  return get(self,path,p)
 def public(self,path,**p):return self.request('GET',path,params=p,private=False)
 def request(self,method,path,params=None,body=None,private=True):
  if method!='GET':return self.post(path,body)
  p=params or {};s=p.get('instId')
  if not private:return self.public_operation(path,p)
  if path=='/api/v5/account/config':return [self.snapshot()['config']]
  if path=='/api/v5/account/positions':return self._positions()
  if path=='/api/v5/account/balance':
   snap=self.snapshot();return [dict(details=[dict(ccy='USDT',eq=fmt(snap['equity']),availBal=fmt(snap['available']))])]
  if path=='/api/v5/trade/order':
   o=self._fetch_order(s,p['clOrdId'])
   if self.execution and self.store and p['clOrdId'] in self.store.data['orders']:
    self._mark_fill(p['clOrdId'],o) if o.get('filled') else None
    self._ensure_stop(p['clOrdId'],o)
   return [self.order_row(o)]
  if path=='/api/v5/trade/orders-pending':return [self.order_row(o) for o in self._call('fetch_open_orders',None,None,None,{})]
  if path=='/api/v5/trade/orders-algo-pending':return self.pending_algos()
  if path=='/api/v5/account/trade-fee':return [dict(takerU=fmt(self.taker_fee(self.instruments[s])))]
  if path=='/api/v5/account/leverage-info':
   r=self.leverage(s)
   return [dict(posSide=d,lever=fmt(r[d]),mgnMode=r.get('marginMode')) for d in ('long','short') if r.get(d) is not None]
  if path=='/api/v5/account/max-size':
   m=self.market(s);snap=self.snapshot();t=self.public('/api/v5/market/ticker',instId=s)[0];lot=dec(self.instruments[s]['lotSz'])
   qty=(snap['available']*dec(p['leverage'])/dec(t['askPx'])/dec(m.get('contractSize') or 1)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
   maximum=min(qty,dec(self.instruments[s]['maxMktSz']));return [dict(maxBuy=fmt(maximum),maxSell=fmt(maximum))]
  if path=='/api/v5/account/bills':return self.bills(p)
  if path=='/api/v5/account/positions-history':return self.history(p)
  raise BotError('지원하지 않는 조회 연산: '+path)
 def public_operation(self,path,p):
  self._load();s=p.get('instId')
  if path=='/api/v5/public/time':return [dict(ts=str(self.now_ms()))]
  if path=='/api/v5/public/instruments':
   if p.get('instType')=='SPOT':return [dict(baseCcy=b,quoteCcy='USDT',state='live',instCategory='1') for b in self.spot_bases]
   if s:
    if s not in self.instruments:raise BotError('종목 명세 미확인')
    return [self.instruments[s]]
   return list(self.instruments.values())
  if path in ('/api/v5/market/candles','/api/v5/market/history-candles'):
   frame=p.get('bar','5m');step=FRAMES[frame];limit=min(1000,int(p.get('limit',300)));since=int(p['after'])-step*limit if p.get('after') else None
   rows=self._call('fetch_ohlcv',self.market(s)['symbol'],{'1H':'1h','4H':'4h','1Dutc':'1d'}.get(frame,frame),since,limit,{})
   now=self.now_ms();ct=dec(self.market(s).get('contractSize') or 1);out=[]
   for r in rows:
    if p.get('after') and int(r[0])>=int(p['after']):continue
    # Unified volume is base for these linear markets; compatibility quantity is contracts.
    base=dec(r[5]);qty=base/ct;quote=base*dec(r[4])
    out.append([str(r[0]),*[fmt(v) for v in r[1:5]],fmt(qty),fmt(base),fmt(quote),'1' if int(r[0])+step<=now else '0'])
   return list(reversed(out))
  if path in ('/api/v5/market/ticker','/api/v5/market/tickers'):
   if s:return [self._ticker(s,self._call('fetch_ticker',self.market(s)['symbol']),opening_needed=False)]
   data=self._call('fetch_tickers',None,{'type':'future' if self.exchange=='binance' else 'swap','productType':'USDT-FUTURES'})
   out=[]
   if any(t.get('bid') is None or t.get('ask') is None for t in data.values()):
    quotes=self._call('fetch_bids_asks',None,{})
    data={k:dict(t,bid=(quotes.get(k) or {}).get('bid',t.get('bid')),ask=(quotes.get(k) or {}).get('ask',t.get('ask'))) for k,t in data.items()}
   for key,t in data.items():
    try:symbol=self.canonical(key);out.append(self._ticker(symbol,t))
    except BotError:continue
   return out
  if path=='/api/v5/market/books':
   depth=int(p.get('sz',400));depth=next((n for n in (5,10,20,50,100,500,1000) if n>=depth),1000) if self.exchange=='binance' else min(100,depth)
   book=self._call('fetch_order_book',self.market(s)['symbol'],depth)
   # Binance's REST depth has no timestamp: pair it with server time from this request,
   # and label its source; do not reuse an old order book with a fresh timestamp.
   return [dict(asks=[[fmt(x[0]),fmt(dec(x[1])/dec(self.market(s).get('contractSize') or 1)),'0','1'] for x in book['asks']],bids=[[fmt(x[0]),fmt(dec(x[1])/dec(self.market(s).get('contractSize') or 1)),'0','1'] for x in book['bids']],ts=str(book.get('timestamp') or self.now_ms()),source='REST response')]
  if path=='/api/v5/public/funding-rate':
   r=self._call('fetch_funding_rate',self.market(s)['symbol']);return [dict(fundingRate=fmt(r['fundingRate']),fundingTime=str(r.get('fundingTimestamp') or r.get('nextFundingTimestamp') or 0),ts=str(r.get('timestamp') or self.now_ms()))]
  raise BotError('지원하지 않는 공개 조회: '+path)
 def _ticker(self,s,t,opening_needed=True):
  info=t.get('info',{});opening=info.get('openUtc') or info.get('openUtc0')
  if t.get('bid') is None or t.get('ask') is None:
   q=self._call('fetch_bids_asks',[self.market(s)['symbol']],{}).get(self.market(s)['symbol'],{})
   t=dict(t,bid=q.get('bid'),ask=q.get('ask'))
  # Native 24h opening is never substituted for UTC00. UI rankings use a separately
  # cached current-day candle opening, loaded lazily once per symbol/day.
  day=self.now_ms()//86400000*86400000;cached=self.opening.get(s)
  if opening is None and cached and cached[0]==day:opening=cached[1]
  if opening_needed and opening is None and self.markets[s]['base'] not in EXCLUDED:
   r=self._call('fetch_ohlcv',self.market(s)['symbol'],'1d',day,1,{})
   if r and int(r[0][0])==day:opening=fmt(r[0][1]);self.opening[s]=(day,opening)
  return dict(instId=s,last=fmt(t['last']),bidPx=fmt(t['bid']),askPx=fmt(t['ask']),volCcy24h=fmt(t.get('baseVolume') or 0),vol24h=fmt(dec(t.get('baseVolume') or 0)/dec(self.market(s).get('contractSize') or 1)),sodUtc0=str(opening or ''),open24h=fmt(t.get('open') or t['last']),ts=str(t.get('timestamp') or self.now_ms()))
 def ledger(self,start,end):
  """Bounded complete native ledger. Fail instead of treating truncation as zero."""
  result=[];seen=set();window=7*86400000;cursor_start=int(start)
  while cursor_start<=end:
   until=min(int(end),cursor_start+window-1);page=1;cursor=None
   for _ in range(50):
    if self.exchange=='binance':
     raw=self._call('fapiPrivateGetIncome',dict(startTime=cursor_start,endTime=until,limit=1000,page=page));rows=raw;limit=1000
    else:
     args=dict(productType='USDT-FUTURES',startTime=str(cursor_start),endTime=str(until),limit='100')
     if cursor:args['idLessThan']=cursor
     raw=self._call('privateMixGetV2MixAccountBill',args);rows=raw.get('data',{}).get('bills');limit=100
    if not isinstance(rows,list):raise BotError('거래 장부 응답 누락')
    for r in rows:
     ident=str(r.get('tranId') or r.get('billId') or '')+':'+str(r.get('incomeType') or r.get('businessType'))
     if not ident or ident in seen:continue
     seen.add(ident);result.append(r)
    if len(rows)<limit:break
    if self.exchange=='binance':page+=1
    else:
     nxt=str(raw.get('data',{}).get('endId') or rows[-1].get('billId') or '')
     if not nxt or nxt==cursor:raise BotError('장부 페이지 반복')
     cursor=nxt
   else:raise BotError('장부 조회 한도 초과: 확정 손익 보류')
   cursor_start=until+1
  return result
 def bills(self,p):
  start=int(p.get('begin') or self.now_ms()//86400000*86400000);end=int(p.get('end') or self.now_ms());now=time.monotonic()
  key=(start,end//60000)
  if self.ledger_cache and self.ledger_cache[0]==key and now-self.ledger_cache[1]<20:rows=self.ledger_cache[2]
  else:rows=self.ledger(start,end);self.ledger_cache=(key,now,rows)
  out=[]
  for r in rows:
   if (r.get('asset') or r.get('coin'))!='USDT':continue
   native=r.get('symbol');s=self.canonical(native) if native else ''
   kind=r.get('incomeType') or r.get('businessType');change=dec(r.get('income') if self.exchange=='binance' else r.get('amount'))
   transfer=kind in ('TRANSFER','INTERNAL_TRANSFER','trans_to_exchange','trans_from_exchange','trans_to_cross','trans_from_cross','trans_to_isolated','trans_from_isolated','transfer_in','transfer_out')
   funding=kind in ('FUNDING_FEE','contract_settle_fee','settle_fee')
   commission=kind=='COMMISSION';stamp=int(r.get('time') or r.get('cTime') or 0)
   fee=change if commission else dec(r.get('fee') or 0) if self.exchange=='bitget' else dec(0)
   pnl=change if kind=='REALIZED_PNL' or self.exchange=='bitget' and not transfer and not funding else dec(0)
   net=change+fee if self.exchange=='bitget' and not transfer else change
   out.append(dict(billId=str(r.get('tranId') or r.get('billId'))+':'+str(kind),ccy='USDT',type='1' if transfer else '8' if funding else '2',instType='SWAP' if s else '',instId=s,ts=str(stamp),balChg=fmt(net),pnl=fmt(pnl),fee=fmt(fee),tradeId=str(r.get('tradeId') or ''),native_type=kind))
  # Internal callers paginate by bill id. Serve a stable local sequence from complete data.
  out.sort(key=lambda r:(int(r['ts']),r['billId']),reverse=True)
  if p.get('after'):
   idx=next((j+1 for j,r in enumerate(out) if r['billId']==p['after']),None)
   if idx is None:raise BotError('장부 페이지 기준 미확인')
   out=out[idx:]
  return out[:int(p.get('limit',100))]
 def history(self,p):
  """Exchange-native Bitget history; Binance verified closed-cycle fills and funding."""
  s=p.get('instId');start=int(p.get('before') or self.now_ms()-90*86400000);end=int(p.get('after') or self.now_ms())
  if self.exchange=='bitget':
   symbols=[self.market(s)['symbol']] if s else None
   rows=self._call('fetch_positions_history',symbols,start,100,{'until':end,'productType':'USDT-FUTURES'})
   result=[]
   for row in rows:
    info=row.get('info',{});symbol=self.canonical(row['symbol']);direction=row.get('side') or info.get('holdSide');born=int(info.get('ctime') or info.get('cTime') or row.get('timestamp') or 0);closed=int(info.get('utime') or info.get('uTime') or row.get('lastUpdateTimestamp') or 0)
    if not born or not closed or info.get('netProfit') is None:continue
    # Map to the same locally observed ID only within matching symbol/side/time.
    posid=str(info.get('positionId') or '')
    if self.store:
     matches=[v for k,v in self.store.data['positions'].items() if k==symbol+':'+direction and abs(v['created']-born)<120000]
     if len(matches)==1:posid=matches[0]['posid']
    result.append(dict(instId=symbol,posId=posid,posSide=direction,direction=direction,mgnMode=info.get('marginMode'),ccy='USDT',cTime=str(born),uTime=str(closed),type='2',openAvgPx=str(info.get('openAvgPrice') or row.get('entryPrice') or ''),closeAvgPx=str(info.get('closeAvgPrice') or ''),realizedPnl=str(info['netProfit']),fee=fmt(dec(info.get('openFee') or 0)+dec(info.get('closeFee') or 0)),fundingFee=str(info.get('totalFunding') or '0')))
   return result[:int(p.get('limit',100))]
  if not self.store:return []
  self._positions();out=[]
  if not p.get('after'):end=self.now_ms()+1
  for cycle in list(self.store.data['cycles'].values()):
   if s and cycle['symbol']!=s:continue
   if not cycle.get('closed_ms') or not start<=cycle['closed_ms']<end:continue
   if cycle.get('settled'):out.append(cycle['settled']);continue
   symbol=cycle['symbol'];m=self.market(symbol);since=cycle['entry_ms']-2000;until=cycle['closed_ms'];fills=[];fromid=None
   for _ in range(30):
    args={'endTime':until}
    if fromid is not None:args['fromId']=fromid
    rows=self._call('fetch_my_trades',m['symbol'],None if fromid is not None else since,1000,args)
    fills.extend(t for t in rows if since<=int(t.get('timestamp') or 0)<=until and t.get('info',{}).get('positionSide') in (cycle['direction'].upper(),'BOTH'))
    if len(rows)<1000:break
    nxt=int(rows[-1]['id'])+1
    if fromid is not None and nxt<=fromid:raise BotError('체결 내역 페이지 반복')
    fromid=nxt
   else:raise BotError('체결 내역 한도: 확정 손익 보류')
   if not fills:continue
   if cycle.get('opposite_overlap'):continue
   if cycle.get('source')!='manual':
    allowed=set()
    for cid,item in list(self.store.data['orders'].items()):
     b=item['body']
     if b['instId']!=symbol or b['posSide']!=cycle['direction'] or not since<=item['ms']<=until or item.get('phase')=='rejected':continue
     detail=self._fetch_order(symbol,cid);allowed.add(str(detail['id']))
    for stop in self.store.data['stops'].values():
     if stop['body']['instId']!=symbol or stop['body']['posSide']!=cycle['direction'] or not since<=stop['ms']<=until:continue
     versions=stop.get('physical_history',[])+[dict(client=stop['physical'],oid=stop.get('oid'))]
     for v in versions:
      try:detail=self._fetch_order(symbol,v['client'],trigger=True,oid=v.get('oid'))
      except Rejected:continue # No guessed attribution if old algo history has expired.
      native=detail.get('info',{});actual=native.get('actualOrderId') or native.get('triggeredOrderId')
      if actual and str(actual)!='0':allowed.add(str(actual))
    if any(str(t.get('order')) not in allowed for t in fills):continue
   opening='buy' if cycle['direction']=='long' else 'sell';entry=[t for t in fills if t['side']==opening];exits=[t for t in fills if t['side']!=opening]
   if not entry or not exits:continue
   eq=sum((dec(t['amount']) for t in entry),dec(0));xq=sum((dec(t['amount']) for t in exits),dec(0))
   if eq!=xq:continue  # No guess for a mixed or incompletely attributed cycle.
   fees=dec(0);real=dec(0)
   for t in fills:
    if t.get('info',{}).get('realizedPnl') is None:raise BotError('바이낸스 실현손익 필드 누락')
    real+=dec(t['info']['realizedPnl']);fee=t.get('fee') or {}
    if fee.get('currency')!='USDT' or fee.get('cost') is None:raise BotError('USDT 외 수수료/수수료 누락: 확정 순손익 보류')
    fees-=abs(dec(fee['cost']))
   ledger=self.ledger(since,until);funding=sum((dec(r['income']) for r in ledger if r.get('symbol')==m['id'] and r.get('incomeType')=='FUNDING_FEE'),dec(0))
   # Funding ledger is symbol-level. Opposite-direction overlap makes attribution ambiguous.
   if any(c['id']!=cycle['id'] and c['symbol']==symbol and c['direction']!=cycle['direction'] and c['entry_ms']<=until and c.get('closed_ms',until)>=since for c in self.store.data['cycles'].values()):continue
   avg=lambda ts:fmt(sum((dec(t['price'])*dec(t['amount']) for t in ts),dec(0))/sum((dec(t['amount']) for t in ts),dec(0)))
   row=dict(instId=symbol,posId=cycle.get('posid') or cycle['id'],posSide=cycle['direction'],direction=cycle['direction'],mgnMode='isolated',ccy='USDT',cTime=str(min(int(t['timestamp']) for t in entry)),uTime=str(max(int(t['timestamp']) for t in exits)),type='2',openAvgPx=avg(entry),closeAvgPx=avg(exits),realizedPnl=fmt(real+fees+funding),fee=fmt(fees),fundingFee=fmt(funding))
   cycle['settled']=row;self.store.save();out.append(row)
  return sorted(out,key=lambda r:int(r['uTime']),reverse=True)[:int(p.get('limit',100))]

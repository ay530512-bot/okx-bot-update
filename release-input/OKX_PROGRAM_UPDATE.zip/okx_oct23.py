"""Reimplementation of the four documented Oct23 entry families, not old binary recovery."""
import math,statistics,hashlib
from okx_core import BotError

DEFAULTS=dict(enabled=True,turnover_top_n=30,volume_history=60,volume_percentile=80.,
 relative_volume=1.5,volume_growth=1.1,zone_atr=.5,reaction_atr=.1,
 stop_buffer_atr=.35,wick_body=2.,wick_fraction=.5,wick_atr=.5,
 retest_min_gap=3,retest_max_gap=36,middle_atr=.5,range_bars=20)
def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('oct23_entry',{}))
def enabled(c):return c.get('signals',{}).get('oct23_entry',{}).get('enabled',False)
def validate(p):
 return (type(p['enabled']) is bool and type(p['turnover_top_n']) is int and 5<=p['turnover_top_n']<=100
  and type(p['volume_history']) is int and 30<=p['volume_history']<=200
  and 0<=p['volume_percentile']<=100 and 1<=p['relative_volume']<=5 and 1<=p['volume_growth']<=5
  and .1<=p['zone_atr']<=2 and .01<=p['reaction_atr']<=1 and .1<=p['stop_buffer_atr']<=2
  and 1<=p['wick_body']<=5 and .3<=p['wick_fraction']<=.8 and .1<=p['wick_atr']<=2
  and type(p['retest_min_gap']) is int and type(p['retest_max_gap']) is int
  and 3<=p['retest_min_gap']<p['retest_max_gap']<=60 and .2<=p['middle_atr']<=3
  and type(p['range_bars']) is int and 10<=p['range_bars']<=60)
def allowed(i,c):
 from okx_band_flow import allowed as generic
 return generic(i) and i.get('instCategory')=='1' and i.get('groupId')!='6' and i['instId'].split('-')[0] not in ('BTC','ETH','SOL') and i['instId'] not in c['selection'].get('stock_linked_symbols',[])
def turnover_ranks(instruments,quotes,c):
 values=[]
 for i in instruments:
  t=quotes.get(i['instId'],{})
  try:
   amount=float(t['volCcy24h'])*float(t['last'])
   if not math.isfinite(amount) or amount<=0:continue
   values.append((amount,i['instId']))
  except (KeyError,TypeError,ValueError):continue
 return {symbol:dict(turnover_rank=n,turnover_usdt_estimate=amount) for n,(amount,symbol) in enumerate(sorted(values,key=lambda x:(-x[0],x[1])),1)}
def activity(b,c):
 p=settings(c);n=p['volume_history'];history=[r[5] for r in b[-n-1:-1]]
 if len(history)<n or not history:return dict(active=False,reason='거래량 이력 부족')
 value=b[-1][5];mean=sum(history)/n;relative=value/mean if mean>0 else 0
 growth=value/b[-2][5] if b[-2][5]>0 else 0;percentile=100*sum(v<=value for v in history)/n
 return dict(active=relative>=p['relative_volume'] and growth>=p['volume_growth'] and percentile>=p['volume_percentile'],relative=relative,growth=growth,percentile=percentile)
def eligible(row,c,now):
 b=[r for r in row.get('live_frames',{}).get('5m',[]) if r[0]+300000<=now]
 a=activity(b,c);rank=row.get('turnover_rank')
 return (rank is not None and rank<=settings(c)['turnover_top_n']) or a['active'],a
def pivots(b):
 return [(j,'low',r[3]) for j,r in enumerate(b[1:-1],1) if r[3]<b[j-1][3] and r[3]<=b[j+1][3]]+[(j,'high',r[2]) for j,r in enumerate(b[1:-1],1) if r[2]>b[j-1][2] and r[2]>=b[j+1][2]]
def setups(frames,c):
 from okx_band_flow import atr,view,ma
 p=settings(c);b=frames.get('5m',[]);h=frames.get('15m',[])
 if len(b)<max(60,p['range_bars']+10) or len(h)<60:return [],'5분/15분 완료봉 이력 부족'
 a=atr(b[:-1]);last=b[-1];prev=b[-2]
 if a<=0:return [],'ATR 계산 불가'
 m=view(b,c);hm=view(h,c);hm50=ma(h,50);slope=ma(h,20)-ma(h[:-3],20)
 direction=1 if h[-1][4]>hm['mid']>hm50 and slope>0 else -1 if h[-1][4]<hm['mid']<hm50 and slope<0 else 0
 strong=abs(hm['mid']-hm50)>hm['atr']
 hits=[];known=pivots(b[:-2]);higher=pivots(h);zones=[v for j,k,v in known[-60:]]+[v for j,k,v in higher[-30:]]
 def add(kind,side,level,extreme,target,anchor,why):
  stop=extreme-side*a*p['stop_buffer_atr']
  if min(stop,target)<=0 or (last[4]-stop)*side<=0 or (target-last[4])*side<=0:return
  hits.append(dict(kind=kind,side=side,level=level,stop=stop,target=target,anchor_ms=anchor,
   atr=a,reason=why,ma=m['ma'],bb={k:m[k] for k in ('mid','upper','lower')},trend15=direction))
 for side in (1,-1):
  reaction=(last[4]-last[1])*side>0 or (last[4]-prev[4])*side>0
  # Trend pullback with historical MA at the touch, not a future MA projected back.
  if direction==side and reaction:
   for j in range(len(b)-3,len(b)):
    for n in (15,20,50):
     level=ma(b[:j],n)
     if b[j][3]<=level+a*p['zone_atr'] and b[j][2]>=level-a*p['zone_atr'] and (last[4]-level)*side>=a*p['reaction_atr']:
      segment=b[j:];extreme=min(r[3] for r in segment) if side==1 else max(r[2] for r in segment)
      target=max(r[2] for r in b[j-20:j]) if side==1 else min(r[3] for r in b[j-20:j])
      add('trend_pullback',side,level,extreme,target,b[j][0],f'15분 추세 방향·5분 SMA{n} 지지/저항 후 회복')
  # Failed retest: first pivot already confirmed before the second touch.
  retest=False
  for j,kind,level in reversed(sorted(known)):
   gap=len(b)-2-j
   if kind!=('low' if side==1 else 'high') or not p['retest_min_gap']<=gap<=p['retest_max_gap']:continue
   test=prev;price=test[3 if side==1 else 2];middle=b[j+1:-2]
   if not middle or abs(price-level)>a*p['zone_atr']:continue
   excursion=max(r[2]-level for r in middle) if side==1 else max(level-r[3] for r in middle)
   settled=any((r[4]-level)*side < -a*p['zone_atr'] for r in middle)
   if settled or excursion<a*p['middle_atr'] or (test[4]-level)*side<0 or not reaction or (last[4]-test[4])*side<a*p['reaction_atr']:continue
   retest=True;extreme=min(level,test[3]) if side==1 else max(level,test[2]);target=max(r[2] for r in middle) if side==1 else min(r[3] for r in middle)
   add('failed_retest',side,level,extreme,target,b[j][0],'기존 저점/고점 구간 재시험·종가 돌파 실패·후속 반전');break
  # BB rejection needs band return and a completed following reaction, plus known SR.
  pm=view(b[:-1],c);span=prev[2]-prev[3];body=abs(prev[4]-prev[1]);wick=min(prev[1],prev[4])-prev[3] if side==1 else prev[2]-max(prev[1],prev[4]);extreme=prev[3 if side==1 else 2]
  outside=extreme<pm['lower'] if side==1 else extreme>pm['upper']
  sr=any(abs(extreme-z)<=a*.75 for z in zones)
  if span>0 and outside and pm['lower']<=prev[4]<=pm['upper'] and wick>=max(body*p['wick_body'],span*p['wick_fraction'],a*p['wick_atr']) and sr and reaction and (last[4]-prev[4])*side>=a*p['reaction_atr']:
   if not (strong and direction==-side) or retest:
    target=max(r[2] for r in b[-22:-2]) if side==1 else min(r[3] for r in b[-22:-2])
    add('band_rejection',side,extreme,extreme,target,prev[0],'볼밴 외부 긴 꼬리·밴드 복귀·지지저항·후속 완료봉 반전')
  # Breakout -> a distinct later retest of the pre-break box.
  if direction==side and reaction:
   start=len(b)-5;base=b[start-p['range_bars']:start];level=max(r[2] for r in base) if side==1 else min(r[3] for r in base)
   for j in range(start,len(b)-1):
    if (b[j][4]-level)*side<a*p['reaction_atr']:continue
    if last[3]<=level+a*p['zone_atr'] and last[2]>=level-a*p['zone_atr'] and (last[4]-level)*side>=a*p['reaction_atr']:
     extreme=min(r[3] for r in b[j+1:]) if side==1 else max(r[2] for r in b[j+1:]);height=max(r[2] for r in base)-min(r[3] for r in base)
     add('breakout_retest',side,level,extreme,level+side*height,b[j][0],'15분 추세·20봉 박스 돌파 후 별도 봉 재확인 / 목표는 박스 높이 추정');break
 return hits,''
def signal(frames,c,now,symbol,instrument,selection=None):
 from okx_band_flow import view,leverage
 completed={}
 for f,step in (('5m',300000),('15m',900000)):
  b=[r for r in frames.get(f,[]) if r[0]+step<=now]
  if not b or not 0<=now-(b[-1][0]+step)<step:return None,f+' 최신 완료봉 대기'
  if any(b[j][0]-b[j-1][0]!=step for j in range(max(1,len(b)-25),len(b))):return None,'봉 간격 오류'
  completed[f]=b
 hits,why=setups(completed,c)
 if not hits:return None,why or '네 진입 전략 미충족'
 sides={h['side'] for h in hits}
 if len(sides)!=1:return None,'롱·숏 전략 충돌'
 priority={k:j for j,k in enumerate(c['signals']['priority'])};hit=min(hits,key=lambda x:priority[x['kind']]);side=hit['side'];last=completed['5m'][-1];m=view(completed['5m'],c)
 lev=leverage(instrument,c)
 if abs(last[4]-hit['stop'])/last[4]>=.85/lev:return None,'구조 손절과 청산 위험 충돌'
 action='LONG' if side==1 else 'SHORT';end=last[0]+300000
 identity=hashlib.sha256(f"oct23:{symbol}:{action}:{hit['kind']}:{hit['anchor_ms']}:{last[0]}".encode()).hexdigest()[:24]
 return dict(symbol=symbol,action=action,strategy='band_flow',pattern='oct23_'+hit['kind'],signal_id=identity,
  leverage=lev,stop=hit['stop'],target=hit['target'],level=hit['level'],atr=hit['atr'],reason=hit['reason'],
  setup_frame='5m',execution_frame='5m',at_ms=last[0],valid_from_ms=end,expires_ms=end+300000,
  entry_reference=last[4],entry_gap=last[4],adaptive=True,regime='uptrend' if hit['trend15']==1 else 'downtrend' if hit['trend15']==-1 else 'range',
  ma=m['ma'],bb=hit['bb'],rsi={n:__import__('okx_market').rsi([r[4] for r in completed['5m']],n) for n in (6,14,24)},retest='retest' in hit['kind'],selection=selection or dict(activity={}),
  holding_rule=dict(band_flow=True,long_hold=True,frame='5m',zone=hit['level'],target=hit['target']),
  decision_record=dict(source='OCT23_REIMPLEMENTATION',reason=hit['reason'],confirmed=True,independent_hits=[h['kind'] for h in hits])),''

"""Persist partial-close intent, reconcile fills, replace protection without a gap."""
import uuid
from decimal import ROUND_DOWN, ROUND_UP
from okx_core import BotError, Rejected, dec, fmt, owned_position
from okx_scale import legs_for


class PartialExits:
    def partial_close(self,snapshot,reason,profit_sequence=None,fraction=None):
        o=self.journal.data['owned']; p=owned_position(o,snapshot['positions'])
        if not o or not p or o['phase']!='active' or (o.get('partial_used') and (o.get('v4_signal',{}).get('rule_channel701') or not o.get('v4_signal',{}).get('free_ai'))): return
        i=self.api.public('/api/v5/public/instruments',instType='SWAP',instId=o['symbol'])[0]
        lot=dec(i['lotSz']); qty=dec(p['pos'])
        part=(qty*dec(self.cfg['risk']['partial_fraction'] if fraction is None else fraction)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
        if min(part,qty-part)<dec(i['minSz']):
            o['partial_unsplittable']=True; self.journal.save()
            self.notify('부분 청산 불가',o['symbol']+' / 최소 주문 단위 미달: 분할 주문 생략')
            return
        o['partial']={'client_id':'OP'+uuid.uuid4().hex[:28],'quantity':fmt(part),'before':fmt(qty),
                      'started_ms':self.api.now_ms(),'reason':reason,'tick_size':i['tickSz']}
        if profit_sequence is not None:o['profit_sequence']=dict(profit_sequence)
        o['phase']='partial_closing'; self.journal.save(); self.invalidate()
        self.notify('부분 청산 요청',o['symbol']+' / '+reason+' / '+fmt(part)+'계약')
        try:
            self.api.post('/api/v5/trade/order',{'instId':o['symbol'],'tdMode':'isolated','posSide':o['direction'],
                'side':'sell' if o['direction']=='long' else 'buy','ordType':'market','sz':fmt(part),'clOrdId':o['partial']['client_id']})
        except Rejected:
            o.pop('partial'); o['phase']='active'; self.journal.save(); raise

    def reconcile_partial(self,snapshot):
        o=self.journal.data['owned']; state=o['partial']; p=owned_position(o,snapshot['positions'])
        if not p: self.finish_position(); return None
        order=self.api.get('/api/v5/trade/order',instId=o['symbol'],clOrdId=state['client_id'])[0]
        if order['state'] not in ('filled','canceled'):
            if self.api.now_ms()-state['started_ms']>15000: raise BotError('부분 청산 결과 미확인: 중복 청산 금지')
            return p
        filled=dec(order.get('accFillSz') or 0); remaining=dec(state['before'])-filled
        if filled==0:
            if dec(p['pos'])!=dec(state['before']): raise BotError('부분 청산 취소 후 수량 불일치')
            o.pop('partial'); o['phase']='active'; self.journal.save(); return p
        if dec(p['pos'])!=remaining:
            # A protective stop may race the close; flat handled above, unknown residual never guessed.
            raise BotError('부분 체결 후 잔여 수량 불일치')
        state['filled']=fmt(filled); state['avg_px']=order.get('avgPx') or '미확인'
        o['cleanup_legs']=legs_for(o)
        o['quantity']=fmt(remaining); o['committed_margin']=fmt(dec(o['committed_margin'])*remaining/dec(state['before']))
        target=o['stop_px']
        from okx_profit_guard714 import enabled,effective_stop
        if enabled(self.cfg):
            proposed=dec(effective_stop(o));mark=dec(p['markPx']);side=1 if o['direction']=='long' else -1
            tick=dec(state.get('tick_size') or self.api.public('/api/v5/public/instruments',instType='SWAP',instId=o['symbol'])[0]['tickSz'])
            proposed=(proposed/tick).to_integral_value(rounding=ROUND_DOWN if side==1 else ROUND_UP)*tick
            if (mark-proposed)*side<=0:
                o['close_requested']='부분 체결 확인 중 수익 보호선 이탈'
            elif (proposed-dec(target))*side>0:
                target=fmt(proposed)
        leg={'algo_client_id':'OS'+uuid.uuid4().hex[:28],'quantity':fmt(remaining),'stop_px':target}
        o['legs']=[leg]; o['phase']='resizing'; o['protection_verified']=False
        o['resize_started_ms']=self.api.now_ms(); o['partial_used']=True
        self.journal.save()
        # Persist BEFORE write. Old stops stay live until new protective size is independently verified.
        try:
            self.api.post('/api/v5/trade/order-algo',{'instId':o['symbol'],'tdMode':'isolated','posSide':o['direction'],
                'side':'sell' if o['direction']=='long' else 'buy','ordType':'conditional','sz':fmt(remaining),
                'algoClOrdId':leg['algo_client_id'],'slTriggerPx':leg['stop_px'],'slTriggerPxType':'mark','slOrdPx':'-1'})
        except Rejected:
            o['phase']='active'; self.journal.save(); self.pause('잔여 수량 보호 등록 거절'); self.close(snapshot,'부분 청산 후 보호 실패')
        return p

    def reconcile_resize(self,snapshot):
        o=self.journal.data['owned']; p=owned_position(o,snapshot['positions'])
        if not p: self.finish_position(); return None
        mine,other=self.algos(); leg=o['legs'][0]
        matched=[a for a in mine if a.get('algoClOrdId')==leg['algo_client_id']]
        good=len(matched)==1 and self.valid_stop(matched[0],leg)
        if good:
            old_ids={l['algo_client_id'] for l in o['cleanup_legs']}
            old=[a for a in mine if a.get('algoClOrdId') in old_ids]
            for a in old: self.api.post('/api/v5/trade/cancel-algos',[{'instId':o['symbol'],'algoId':a['algoId']}])
            # Crash while cancelling: query on restart, only remaining live old IDs are cancelled.
            if not old:
                partial=dict(o['partial'])
                o.pop('cleanup_legs'); o.pop('partial'); o['stop_px']=leg['stop_px']; o['phase']='active'; o['protection_verified']=True
                self.journal.save(); self.notify('부분 청산 확인',o['symbol']+' / 부분 청산 체결 '+partial.get('filled',partial['quantity'])+'계약 / 체결가 '+partial.get('avg_px','미확인')+' / 잔여 '+o['quantity']+'계약 보호 확인',state='partial:'+o['client_id']+':'+partial['client_id'])
        elif self.api.now_ms()-o['resize_started_ms']>15000:
            o['phase']='active'; self.journal.save(); self.pause('잔여 보호 등록 미확인'); self.close(snapshot,'부분 청산 후 보호 등록 미확인')
        return p

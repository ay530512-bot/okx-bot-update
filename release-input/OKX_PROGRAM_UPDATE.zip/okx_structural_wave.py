"""Causal swing targets and confirmed double-extreme neckline retests.
All input bars must be completed. No account writes or model calls.
"""
import math
from okx_core import BotError

def levels(bars,atr):
 b=bars[-80:];out=[]
 if atr<=0:return out
 for i in range(3,len(b)-3):
  for side,field,kind in ((1,2,'high'),(-1,3,'low')):
   v=float(b[i][field]);near=b[i-3:i]+b[i+1:i+4]
   if any((float(r[field])-v)*side>0 for r in near):continue
   # A local wiggle is not a major price obstacle: require a >=1 ATR reaction.
   reaction=min(v-min(float(r[4]) for r in b[i-3:i]),v-min(float(r[4]) for r in b[i+1:i+4])) if side==1 else min(max(float(r[4]) for r in b[i-3:i])-v,max(float(r[4]) for r in b[i+1:i+4])-v)
   if reaction<atr:continue
   # A completed close through the zone invalidates the old obstacle.
   if any((float(r[4])-v)*side>.15*atr for r in b[i+1:]):continue
   out.append(dict(kind=kind,price=v,ms=b[i][0],prominence_atr=reaction/atr))
 unique=[]
 for item in sorted(out,key=lambda x:x['ms'],reverse=True):
  if not any(x['kind']==item['kind'] and abs(x['price']-item['price'])<=.2*atr for x in unique):unique.append(item)
 return sorted(unique,key=lambda x:abs(x['price']-float(b[-1][4])))[:8]

def setups(bars,atr):
 b=bars[-80:];out={}
 if len(b)<18 or not math.isfinite(atr) or atr<=0:return out
 for action,side,field in (('LONG',1,3),('SHORT',-1,2)):
  for j in range(len(b)-4,max(7,len(b)-18),-1):
   second=float(b[j][field])
   if any((float(b[k][field])-second)*side<0 for k in (j-1,j+1)):continue
   for i in range(j-4,max(4,j-32),-1):
    first=float(b[i][field])
    if any((float(b[k][field])-first)*side<0 for k in (i-1,i+1)):continue
    if abs(second-first)>.6*atr:continue
    # Prior directional leg and an intervening rebound/drop are required.
    before=b[max(0,i-8):i]
    origin=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in before)
    if (origin-first)*side<1.5*atr:continue
    middle=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in b[i+1:j])
    height=(middle-(min(first,second) if side==1 else max(first,second)))*side
    if height<atr:continue
    extreme=min(first,second) if side==1 else max(first,second)
    if any((float(r[4])-extreme)*side<-.15*atr for r in b[i+1:]):continue
    crosses=[k for k in range(j+1,len(b)-2) if (float(b[k][4])-middle)*side>.1*atr]
    if not crosses:continue
    cross=crosses[0];tail=b[-3:]
    # Retest happens AFTER the breakout; latest close must recover the neckline.
    retests=[r for r in b[max(cross+1,len(b)-3):-1] if abs(float(r[field])-middle)<=.5*atr and (float(r[4])-middle)*side>=-.15*atr]
    last=b[-1]
    if not retests or (float(last[4])-middle)*side<=.1*atr:continue
    if (float(last[4])-float(last[1]))*side<=0 or (float(last[4])-float(b[-2][4]))*side<=0:continue
    if any((float(r[4])-middle)*side<-.25*atr for r in b[cross+1:]):continue
    def volume_ratio(k):
     sample=b[max(0,k-20):k];mean=sum(float(r[5]) for r in sample)/len(sample) if len(sample)>=10 else 0
     return float(b[k][5])/mean if mean>0 else 0
    participation=max(volume_ratio(cross),volume_ratio(len(b)-1))
    if participation<1.2:continue
    retest_extreme=(min if side==1 else max)(float(r[field]) for r in tail)
    out[action]=dict(setup='double_bottom_neckline_retest' if side==1 else 'double_top_neckline_retest',signal_ms=last[0],first_ms=b[i][0],second_ms=b[j][0],first=first,second=second,neckline=middle,break_ms=b[cross][0],frame_close=float(last[4]),confirmation_relative_volume=participation,pattern_extreme=extreme,structural_stop=retest_extreme-side*.25*atr,measured_target=middle+side*height,pattern_height=height)
    break
   if action in out:break
 return out

def evidence(frame,action,price):
 proof=frame.get('double_wave_setups',{}).get(action)
 if not proof:raise BotError('쌍바닥/쌍고점 넥라인 돌파 후 지지·저항 재시험 대기')
 side=1 if action=='LONG' else -1;atr=float(frame['atr'])
 if proof['signal_ms']!=frame['recent'][-1][0]:raise BotError('쌍바닥/쌍고점 확인봉 만료')
 if not -.15*atr<=(price-proof['frame_close'])*side<=.5*atr:raise BotError('쌍바닥/쌍고점 확인 가격 이탈 또는 추격 구간')
 if (price-proof['neckline'])*side<=0 or (price-proof['structural_stop'])*side<=0:raise BotError('쌍바닥/쌍고점 지지·저항 무효화')
 return dict(proof)

def plan(packet,action,frame_name,proof,proposed_stop,proposed_target):
 side=1 if action=='LONG' else -1;price=float(packet['price']);frame=packet['frames'][frame_name]
 stop=min(proposed_stop,proof['structural_stop']) if side==1 else max(proposed_stop,proof['structural_stop'])
 target=float(proof.get('measured_target') or proposed_target)
 candidates=[float(r['price']) for r in frame.get('structural_levels',[]) if r['kind']==('high' if side==1 else 'low') and (float(r['price'])-price)*side>0]
 if candidates:target=min(target,min(candidates)) if side==1 else max(target,max(candidates))
 risk=(price-stop)*side;reward=(target-price)*side
 try:cost=float(packet['execution']['round_trip_cost_fraction_estimate'])*price
 except (KeyError,TypeError,ValueError):raise BotError('왕복비용 자료 미확인 · 구조 목표 수익성 계산 대기') from None
 if not all(math.isfinite(x) for x in (price,stop,target,cost,risk,reward)) or cost<0 or risk<=0 or stop<=0:raise BotError('구조 손절/목표 또는 비용 수치 오류')
 net=reward-cost;ratio=net/(risk+cost)
 detail=f'{frame_name} 진입 {price:g} / SL {stop:g} / 파동 재평가 {target:g} / 여유 {reward/price*100:.2f}% / 비용 {cost/price*100:.2f}% / 비용 반영 손익비 {ratio:.2f}'
 if net<=0:raise BotError('파동 목표까지 비용 제외 여유 부족 · '+detail)
 if ratio<1:raise BotError('구조 손절 대비 순수익 여유 1배 미만 · '+detail)
 return dict(stop=stop,target=target,net_reward_risk=ratio,round_trip_cost_fraction=cost/price,summary=detail,basis='confirmed pattern height capped at significant swing obstacle' if proof.get('measured_target') else 'AI structural target capped at significant swing obstacle')

"""Nearest execution-frame obstacle; remote targets cannot bypass nearby levels."""
import math
from okx_core import BotError

def observe(packet,action,frame_name=None):
 side=1 if action=='LONG' else -1;price=float(packet['price'])
 frame_name=frame_name or '5m';frame=packet.get('frames',{}).get(frame_name,{});h=frame.get('chart_evidence',{})
 bars=frame.get('recent',[]);levels=[]
 label='저항' if side==1 else '지지'
 def add(value,source):
  try:v=float(value)
  except (ValueError,TypeError):return
  if math.isfinite(v) and v>0 and (v-price)*side>0:levels.append((v,source))
 if 'structural_levels' in frame:
  for pivot in frame['structural_levels']:
   if pivot.get('kind')==('high' if side==1 else 'low'):add(pivot.get('price'),frame_name+' 주요 확정 스윙 '+label)
 else:
  # Old saved decisions retain their original evidence; new packets use significant swings.
  add(h.get('prior_resistance' if side==1 else 'prior_support'),frame_name+' 직전 '+label)
  for pivot in h.get('confirmed_pivots',[]):
   if pivot.get('kind')==('high' if side==1 else 'low'):add(pivot.get('price'),frame_name+' 확정 피벗 '+label)
 try:cost=float(packet.get('execution',{}).get('round_trip_cost_fraction_estimate'))
 except (TypeError,ValueError):cost=None
 if cost is not None and (not math.isfinite(cost) or cost<0):cost=None
 nearest=min(levels,key=lambda x:abs(x[0]-price)) if levels else None
 room=abs(nearest[0]-price)/price if nearest and price>0 else None
 blocked=bool(room is not None and cost is not None and room<=cost)
 return dict(direction=action,frame=frame_name,nearest_level=nearest[0] if nearest else None,level_source=nearest[1] if nearest else None,room_fraction=room,modeled_round_trip_cost_fraction=cost,blocked=blocked,
  reason=(frame_name+' 주요 '+label+' '+str(nearest[0])+'까지 '+f'{room*100:.2f}'+'% / 왕복비용 '+f'{cost*100:.2f}'+'% · 돌파 후 재시험 대기') if blocked else '근접 장애물 비용 기준 통과 또는 자료 부족 · 진입 승인 의미 아님')

def validate(packet,action,frame_name=None):
 obs=observe(packet,action,frame_name)
 if obs['blocked']:raise BotError(obs['reason'])
 return obs

def eligible(packet):
 from okx_volume_entry import evidence
 checks={}
 for action in ('LONG','SHORT'):
  reasons=[]
  for name,frame in packet.get('frames',{}).items():
   obs=observe(packet,action,name);reasons.append(obs['reason'])
   if obs['blocked']:continue
   try:
    proof=evidence(frame,action,packet['price'])
    if 'structural_levels' in frame:
     target=proof.get('measured_target')
     # Other setup families retain model-selected targets. Known major room must
     # still support structural risk; with no observed target AI may inspect it.
     if target is None and obs['nearest_level'] is not None:target=obs['nearest_level']
     if target is not None:
      from okx_structural_wave import plan
      plan(packet,action,name,proof,proof['structural_stop'],target)
    checks[action]=obs
    return True,checks
   except (BotError,ValueError,TypeError,KeyError) as err:reasons.append(str(err))
  checks[action]=dict(blocked=True,reason=action+' · '+' / '.join(dict.fromkeys(reasons))[:500])
 return False,checks

def reassessment(packet,direction):
 """Opposing completed-bar observations; neither a forced exit nor a stop edit."""
 f=packet.get('frames',{}).get('5m',{});b=f.get('recent',[]);ma=f.get('ma',{});side=1 if direction=='long' else -1
 if len(b)<3:return dict(available=False)
 closes=[float(r[4]) for r in b[-3:]];extreme=3 if side==-1 else 2
 # Against a short: held higher low + rising close; against a long: lower high + falling close.
 held=(float(b[-1][extreme])-float(b[-3][extreme]))*(-side)>0
 improving=(closes[-1]-closes[-2])*(-side)>0
 try:reclaimed=(closes[-1]-float(ma.get('15')))*(-side)>0
 except (TypeError,ValueError):reclaimed=False
 return dict(available=True,completed_ms=f.get('completed_ms'),opposing_held_swing=held,opposing_close_progress=improving,opposing_ma15_reclaim=reclaimed,needs_fresh_thesis=bool(held and improving and reclaimed),
  guidance='Repeated original resistance/support not yet broken is not affirmative evidence of a valid thesis. Compare new opposing held structure with original evidence. HOLD requires current directional evidence; consider PARTIAL/CLOSE for meaningful deterioration. A single bounce alone does not mandate exit. Existing server SL is never widened or delayed.')

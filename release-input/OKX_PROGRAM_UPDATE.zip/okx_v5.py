from okx_daily_goal728 import cost_for_day
"""v5 rules + AI veto, two durable positions, prioritized protection/recovery.

Real account access is supplied at runtime by the user. Importing this module
neither connects to a service nor starts a strategy.
"""
import json
import queue
import threading
import time
import uuid
from decimal import ROUND_DOWN, ROUND_UP
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from okx_core import BotError, Rejected, UnknownOutcome, OKX, dec, fmt, owned_position, size_plan, day_key, KST
from okx_portfolio import PortfolioEngine
from okx_partial import PartialExits
from okx_rules import load_config, signal, manage, metrics, allowed_instrument, select_leverage, scale_confirmation, protective_target, dynamic_add_fraction, sync_profit_threshold
from okx_liquidity import book_check, risk_plan, fit_book_quantity
from okx_universe import Universe, activity
from okx_stream import MarketStream, AccountStream
from okx_notify import Notifier
from okx_scale import legs_for
from okx_market import closed_candles
from okx_wick import check_entry,holding_check,holding_record
from okx_execution_status import ExecutionStatus,check_permissions,read_frames


def decision_summary(title,text):
    """Raw analysis belongs in decision_records, not dashboard widgets."""
    value=str(text)
    try:
        row=json.loads(value)
    except (ValueError,TypeError):row=None
    if isinstance(row,dict):
        reason=row.get('reason')
        if reason:
            value=str(reason)
        else:
            direction={'LONG':'롱','SHORT':'숏','long':'롱','short':'숏'}.get(row.get('action') or row.get('direction'),'대기')
            value=direction+' / 차트 조건 확인 중'
    return value.replace('\n',' ')[:240]


from okx_autonomous import AutonomousMixin

class RuleEngine(AutonomousMixin, PartialExits, PortfolioEngine):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.cfg=load_config(self.root)
        if self.cfg['execution'].get('budget_pacing',{}).get('enabled'):self.budget=6.
        from okx_position_history import PositionHistory
        self.position_history=PositionHistory(self.root,self.settings,self.events)
        self.execution_status=ExecutionStatus();self.last_pipeline_log=0.;self.traced_signals=set()
        for record in self.records():sync_profit_threshold(record,self.cfg['risk']['profit_review_roe'])
        if str(self.settings.get('TRADING_EXCHANGE') or 'okx')=='okx':
            self.stream=MarketStream(); self.account_stream=AccountStream(self.settings,self.account_event)
        else:
            from okx_exchange_stream import FuturesMarketStream,FuturesAccountStream
            self.stream=FuturesMarketStream(self.settings);self.account_stream=FuturesAccountStream(self.settings,self.account_event)
            self.log('선택 거래소 공개 WebSocket / 계정은 3초 REST 대조로 운용합니다.')
        self.universe=Universe(self.settings,self.cfg); self.notifier=Notifier(self.root,self.settings,self.cfg)
        from okx_ui_services import TelegramBridge,EquityHistory
        self.telegram_ui=TelegramBridge(self.root,self.settings,self.events)
        self.equity_history=EquityHistory(self.root)
        self.notifier.on_success=self.telegram_ui.delivered;self.notifier.on_failure=self.telegram_ui.failed
        self.chart_jobs={}; self.charts={}; self.next_charts={}
        self.chart_pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix='v5-chart')
        self.approval_pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='v5-ai-veto')
        self.approval=None; self.approval_signal=None; self.approval_result=None
        self.ai_reviewed={}; self.executing_signal=None
        from okx_chat import ChatService
        self.chat=ChatService(self)
        self.approval_epoch=None; self.good_snapshots=0; self.connection_key=None
        self.recovering=True; self.user_paused=True; self.guard_rows=(); self.risk_queue=queue.Queue()
        from okx_profit_guard714 import init_buffer
        init_buffer(self)
        self.queued_risks=set(); self.risk_lock=threading.Lock();self.protection_wake=threading.Event()
        self.guard_amend_seconds=2.0;self.last_profit_wake=0.
        self.stream.on_mark=self.mark_event
        self.loss_context=None; self.prepared_signal=None
        self.journal.data.setdefault('seen_signals',{}); self.journal.data.setdefault('settlements',[])
        self.journal.data['strategy_version']=5.1; self.previous_strategy=5.1; self.journal.save()
        if self.cfg['execution'].get('rule_channel701'):
            self.log('V7.32-Q2: 15분봉 기존 규칙만 · 4H 추가 진입 삭제 · 기타10배/BTC20배/ETH·SOL15배 · 증거금(시드−3)/4 · 최대4개')
        if self.cfg['execution'].get('rule_channel701'):
            self.log(self.cfg['version']+' / V723 추세 눌림·이평 재확인 연구판 / 수익성 검증 미통과 / 종목별 배율 · 최대4개 · 3USDT 제외 · 목표 증거금(시드−3)/4 · 소액 대체 없음 · 24시간 연속 / 신규 AI 호출 없음')
            self.log('최초2ATR / +20% ROE 최초 절반청산 / 청산 확인 후 신규 신호 재탐색 / 완료봉 돌파실패 정리 / 최대6시간')
        else:
            self.log(str(self.cfg.get('version','legacy'))+' / 기존 프로필 운용')
        if not self.notifier.enabled: self.log('텔레그램 거래 알림 비활성: 토큰·수신 대상 설정을 확인하세요.')
        from okx_continuity732 import initialize
        initialize(self)

    def notify(self,title,text,state=None):
        summary=decision_summary(title,text)
        # Keep rejection reasons locally even though Telegram status messages are disabled.
        if str(title).startswith('대기'):
            message=str(text)
            try:
                audit=json.loads(message)
                if isinstance(audit,dict):message=str(audit.get('reason',message))
            except (ValueError,TypeError):pass
            if not hasattr(self,'wait_log_times'):self.wait_log_times={}
            key=(str(title),message[:300]);now=time.monotonic()
            if now-self.wait_log_times.get(key,-1e9)>=60:
                self.wait_log_times[key]=now
                self.log(str(title)+' / '+message[:500])
            if len(self.wait_log_times)>500:
                self.wait_log_times={k:v for k,v in self.wait_log_times.items() if now-v<300}
        status=str(title).startswith(('대기','보유')) or title in ('미리보기','연결 대기','복구 대기')
        if status:
            if not hasattr(self,'status_ui_times'):self.status_ui_times={}
            now=time.monotonic();key=(str(title),summary)
            if now-self.status_ui_times.get(key,-1e9)<30:return
            self.status_ui_times[key]=now
            if len(self.status_ui_times)>500:
                self.status_ui_times={k:v for k,v in self.status_ui_times.items() if now-v<300}
        self.events.put(('decision',{'title':str(title),'text':summary}))
        self.notifier.emit(title,'['+str(self.settings.get('TRADING_EXCHANGE') or 'okx').upper()+' '+str(self.cfg.get('version','v6.36'))+'] '+title+'\n'+str(text),state)

    def start(self):
        self.stream.watch(['AAVE-USDT-SWAP'])  # Public connectivity probe only; never an entry candidate by itself.
        self.stream.start(); self.account_stream.start(); self.universe.start(); self.notifier.start();self.telegram_ui.start();self.position_history.start()
        threading.Thread(target=self.guard_loop,daemon=True,name='risk-watch').start()
        super().start()

    def pipeline(self,phase,reason='',count=None):
        if not hasattr(self,'execution_status'):self.execution_status=ExecutionStatus()
        changed=self.execution_status.set(phase,decision_summary('',reason),count)
        value=self.execution_status.snapshot()
        if phase in ('ai_rejected','preflight_rejected','error'):self.last_entry_blocker=value['reason']
        value['last_blocker']=getattr(self,'last_entry_blocker','')
        if changed and phase in ('ai_rejected','preflight_rejected','error'):
            reason_text=str(reason)
            times=getattr(self,'telegram_block_times',{});stamp=time.monotonic()
            if stamp-times.get(reason_text,-1e9)>=600:
                self.notifier.emit('진입 거절',reason_text)
                times[reason_text]=stamp
            self.telegram_block_times={k:v for k,v in times.items() if stamp-v<600}
        if changed or count:
            self.events.put(('pipeline',value))
            if phase in ('ai_pending','approved','submitted','filled','ai_rejected','preflight_rejected','error') or time.monotonic()-getattr(self,'last_pipeline_log',0)>30:
                self.log('[진입 단계] '+value['label']+' / '+value['reason']);self.last_pipeline_log=time.monotonic()

    def account_event(self,kind,row):
        if kind=="position":
            self.events.put(("position_live",dict(row=row,received_ms=int(time.time()*1000))))
        # Private position updates reduce detection latency; REST still verifies actual quantity before writes.
        if kind=='equity' and self.loss_context:
            d=self.loss_context['day']; denominator=float(d.get('start_equity',d['base']))
            roi=(float(row['equity'])-float(d['base']))/denominator if denominator>0 else 0
            if (self.cfg['risk'].get('daily_loss_enabled',True) and roi<=self.cfg['risk']['daily_stop']) or (self.cfg['risk'].get('daily_profit_cap_enabled',True) and roi>=self.cfg['risk']['daily_cap']):
                self.entry_cancel.set()  # Worker corrects transfers before deciding to flatten.
        if kind=='position' and row.get('uplRatio') not in (None,''):
            for o in self.guard_rows:
                if self.cfg['risk'].get('final_roe_enabled',True) and (o['symbol'],o['direction'])==(row.get('instId'),row.get('posSide')) and not o.get('band_flow') and float(row['uplRatio'])<=self.cfg['risk']['final_stop_roe']:
                    self.queue_risk(o['client_id'],'실시간 포지션 ROE 최종 손절')

    def mark_event(self,row):
        # Receive every mark before later quotes replace it; never place orders on WS threads.
        from okx_profit_guard714 import buffer_mark
        for o in self.guard_rows:
            if o['symbol']==row.get('instId'):
                buffer_mark(self,o,row)
                self.evaluate_guard(o,row)
        self.protection_wake.set()

    def queue_risk(self,identity,reason):
        with self.risk_lock:
            if identity not in self.queued_risks:
                self.queued_risks.add(identity); self.entry_cancel.set(); self.risk_queue.put((identity,reason))
        self.command_wake.set()

    def guard_once(self):
        for o in self.guard_rows:
            row=self.stream.read(o['symbol'],'mark-price',15)
            if not row:continue
            from okx_profit_guard714 import buffer_mark
            buffer_mark(self,o,row)
            self.evaluate_guard(o,row)

    def evaluate_guard(self,o,row):
        if not 0<=self.api.now_ms()-int(row['ts'])<=15000:return
        mark=float(row['markPx']);stop=float(o['stop_px']);long=o['direction']=='long'
        roe=(mark/float(o['avg_px'])-1)*o['leverage']*(1 if long else -1)
        liq=float(o.get('liq_px',0));proximity=liq>0 and (mark<=liq*(1+self.cfg['risk']['liquidation_buffer']) if long else mark>=liq*(1-self.cfg['risk']['liquidation_buffer']))
        final=self.cfg['risk'].get('final_roe_enabled',True) and not o.get('band_flow') and roe<=self.cfg['risk']['final_stop_roe']
        if proximity or (long and mark<=stop) or (not long and mark>=stop) or final:
            self.queue_risk(o['client_id'],'실시간 마크가격 보호 손절')
        # Wake the existing worker at most once/sec for profit handling; API pacing is unchanged.
        now=time.monotonic()
        if roe>=self.cfg['risk'].get('profit_review_roe',.2) and now-self.last_profit_wake>=1:
            self.last_profit_wake=now;self.command_wake.set()
    def guard_loop(self):
        last_error=0.
        while not self.stop_event.is_set():
            self.protection_wake.clear()
            try:self.guard_once()
            except Exception as error:
                now=time.monotonic()
                if now-last_error>=30:
                    self.log('보호 감시 자료 확인 필요: '+type(error).__name__);last_error=now
                self.command_wake.set()
            self.protection_wake.wait(.05)

    def activate(self,*args,**kwargs):
        # Existing positions must remain manageable even if no new candidate passes these checks.
        starting=self.snapshot();check_permissions(starting['config']);self.refresh_day(starting)
        d=self.journal.data['day']
        if not self.cfg['risk'].get('daily_loss_enabled',True) and d and d.get('ended') and d.get('end_reason')=='일일 -21% 손실 한도':
            d['ended']=False;d.pop('end_reason',None);self.journal.save();self.log('사용자 설정: 이전 일일 손실 중단 해제·계정 대조 후 재개')
        if d and d['ended'] and d.get('end_reason')=='일일 +200% 상한':
            roi=self.strategy_roi(self.last_snapshot['equity'])
            if roi is not None and dec(self.cfg['risk']['daily_stop'])<roi<dec(self.cfg['risk']['daily_cap']):
                d['ended']=False;d.pop('end_reason',None);self.journal.save()
                self.log('이전 +200% 중단 해제: 새 +1000% 상한 적용')
        if d and d['ended']:
            from okx_day_status import daily_status,lines
            raise BotError(' / '.join(lines(daily_status(d,starting['equity'],starting['ms'],self.cfg,cost_for_day(self.journal.data,d.get('date'))))))
        if not self.account_stream.fresh(): raise BotError('계정 WebSocket 연결/최초 스냅샷을 기다려주세요.')
        super().activate(*args,**kwargs)
        self.journal.data['strategy_version']=5.1; self.previous_strategy=5.1; self.journal.save()
        self.user_paused=False; self.mobile_entry_pause=False; self.recovering=True; self.good_snapshots=0; self.entry_cancel.set()
        self.preview=False
        from okx_continuity732 import started
        started(self)
        self.pipeline('recovery','실거래 활성화 완료. 계정·미체결·보호 주문 대조 후 신호에 따라 자동 주문합니다.')
        self.notify('실거래 시작','실제 계정 대조 및 데이터 확인 후 신규 진입 허용 / +6%는 목표, 수익 보장 없음')

    def handle(self,action,kwargs):
        if action=='update_restart':
            from okx_update732 import flat_checkpoint,verify_staged,launch_worker
            from pathlib import Path
            def update_status(status,message):
                self.events.put(('update_message',message))
                if kwargs.get('mobile_update'):
                    self.events.put(('mobile_update_status',dict(status=status,message=message)))
            try:
                folder=Path(kwargs['folder']).resolve()
                if folder.parent != (self.root/'updates').resolve():
                    raise BotError('업데이트 저장 경로 확인 실패')
                verify_staged(folder)
                ok,reason=flat_checkpoint(self)
                if not ok:
                    update_status('blocked',reason);return
                self.journal.save()
                launch_worker(self.root,folder)
            except Exception as exc:
                update_status('failed','설치 준비 실패 · 기존 프로그램 유지: '+str(exc)[:200]);return
            update_status('installing','설치·PC 프로그램 재시작 중 · 잠시 후 같은 주소로 다시 접속하세요.')
            self.entry_cancel.set();self.enabled=False;self.stop_event.set()
            self.events.put(('quit',None));return
        if action=='click_order':
            from okx_click716 import accept,result
            try:accept(self,kwargs)
            except Exception as ex:
                result(self,kwargs,'failed',('주문 결과 미확인 · 재클릭 금지·계정 확인' if isinstance(ex,UnknownOutcome) else str(ex) if isinstance(ex,BotError) else '개별 주문 처리 오류 · 계정 확인'))
                if isinstance(ex,UnknownOutcome):raise
            return
        if self.cfg.get('execution',{}).get('subscription_chat_only') and action in ('chat','chat_result','chat_confirm','chat_reprepare'):
            self.events.put(('log','유료 API 대화는 제거되었습니다. ChatGPT 웹에서 대화해 주세요.'));return
        if action=='mobile_control':
            from okx_mobile_control import handle
            handle(self,kwargs);return
        if action=='api_credit_refresh':
            from okx_api_credit import estimate
            self.events.put(('api_credit',estimate(self)))
            return
        if action=='api_credit_sync':
            from okx_api_credit import calibrate
            try:self.events.put(('api_credit',calibrate(self,kwargs.get('balance',''))))
            except BotError as error:self.events.put(('api_credit_error',str(error)))
            return
        if action=='position_history':
            try:self.position_history.request(kwargs.get('date',''))
            except ValueError:self.events.put(('log','날짜 형식을 확인하세요: YYYY-MM-DD'))
            return
        if action in ('chat','chat_result','chat_confirm','chat_reprepare','chat_selected','chat_selected_result','chat_selected_error','chat_cancel_selected'):
            try:
                if action=='chat':self.chat.message(kwargs.get('text',''),kwargs.get('symbol',''))
                elif action=='chat_cancel_selected':self.chat.cancel_selected()
                elif action=='chat_selected':self.chat.start_selected(kwargs.get('symbol',''))
                elif action=='chat_selected_result':self.chat.finish_selected(kwargs['identity'],reply=kwargs['reply'])
                elif action=='chat_selected_error':self.chat.finish_selected(kwargs['identity'],error=kwargs['error'])
                elif action=='chat_result':self.chat.result(kwargs['reply'])
                elif action=='chat_reprepare':
                    if self.chat.last_intent:self.chat.prepare(self.chat.last_intent)
                    else:raise BotError('재조회할 주문 의도가 없습니다. 채팅으로 주문을 요청하세요.')
                else:self.chat.confirm(kwargs['token'])
            except Exception as error:
                self.events.put(('chat_reply',dict(role='assistant',text='진행 보류: '+(str(error) if isinstance(error,BotError) else type(error).__name__),done=True)))
            return
        if action=='telegram_test':
            self.telegram_ui.request_test();return
        if action=='reconnect':
            self.manual_reconnect();return
        if action in ('pause','close','quit'):
            # A rejected quit must not silently turn an active session into a pause.
            if action=='quit' and self.records():
                if self.enabled and not self.user_paused:
                    self.recovering=True;self.good_snapshots=0
                raise BotError('보유 포지션 기록이 있습니다. 관리 창을 유지하세요.')
            from okx_continuity732 import stopped
            stopped(self,{'pause':'사용자가 신규 진입 중지','close':'사용자가 전체 청산 후 중지','quit':'사용자가 프로그램 종료'}[action])
        if action=='preview':
            if self.records():raise BotError('보유분이 있어 미리보기 전환 불가')
            from okx_continuity732 import stopped
            stopped(self,'사용자가 미리보기로 전환')
            self.enabled=False;self.preview=True;self.invalidate()
            self.log('규칙 미리보기: 주문·AI 호출 없음 / 60초 목표 갱신')
            self.pipeline('preview','신호 탐색만 수행하며 주문과 AI 호출은 없습니다.')
            return
        return super().handle(action,kwargs)

    def manual_reconnect(self):
        if time.monotonic()-getattr(self,'last_manual_reconnect',-1e9)<5:return
        self.last_manual_reconnect=time.monotonic()
        self.entry_cancel.set();self.invalidate();self.approval_result=None
        self.recovering=True;self.good_snapshots=0;self.connection_key=None
        self.api.synced=0
        from okx_entry_pipeline import clear_candles
        clear_candles(self.api)
        self.stream.reconnect();self.account_stream.reconnect()
        self.events.put(('connection_reset',{}))
        self.pipeline('recovery','수동 재연결 요청: 시세·계정 수신 후 포지션·미체결·보호 주문 대조')
        self.log('OKX 재연결 요청 / 기존 운용 상태 유지 / 대조 완료 전 신규 진입 대기')

    def strategy_roi(self,equity):
        return self.journal.daily_return(equity)  # Account PnL already includes fees/funding/unrealized; AI separately reported.

    def refresh_day(self,snapshot):
        # First day/long outage cannot reconstruct exact midnight equity. Mark this, never invent a 48 USDT baseline.
        rolled=self.journal.roll_day(snapshot['ms'],snapshot['equity'],initialize=self.enabled)
        if rolled:
            self.notify('거래일 기준','KST '+day_key(snapshot['ms'])+' / 첫 관측 총자산 '+fmt(snapshot['equity'])+' USDT; 자정 정확값과 차이가 있을 수 있음')
        d=self.journal.data['day']
        if not d: return
        from okx_cashflows import fetch_transfers,correct_transfer_latch,reconcile_legacy_transfer_stop
        try:
            rows=fetch_transfers(self.api,d['started_ms'],snapshot['ms'])
            known=set(d.get('flow_ids',[]));new_rows=[r for r in rows if r['billId'] not in known]
            self.journal.apply_transfers(rows)
            d['flow_status']='이체 장부 조회 성공 / 지연 내역은 추후 재대조';d['flow_checked_ms']=snapshot['ms']
            d['recent_transfers']=[dict(ms=int(r['ts']),amount=r['balChg'],direction='입금/전입' if dec(r['balChg'])>0 else '출금/전출') for r in sorted(rows,key=lambda x:int(x['ts']))[-5:]]
            repaired=correct_transfer_latch(d,new_rows,self.cfg['risk'])
            if not repaired:repaired=reconcile_legacy_transfer_stop(d,rows,snapshot['equity'],self.cfg['risk'],self.cfg['execution'].get('legacy_transfer_recheck_authorized',False),snapshot['ms'])
            if repaired:self.log(d['transfer_latch_note'])
            self.journal.save()
        except Exception:
            d['flow_status']='이체 내역 확인 대기: 손실·이체 구분 미확정'
            self.journal.save()
            from okx_day_status import daily_status
            self.events.put(('daily_risk',daily_status(d,snapshot['equity'],snapshot['ms'],self.cfg,cost_for_day(self.journal.data,d.get('date')))))
            raise
        if 'start_equity' not in d:
            if d['flow_ids']: raise BotError('이전 버전 일일 원금 복원 필요: 입출금이 있는 날은 신규 진입 보류')
            d['start_equity']=d['base']; self.journal.save()
        from okx_risk732 import clear_daily_halt
        clear_daily_halt(self)
        self.loss_context=dict(equity=snapshot['equity'],day=d)

    def day_room(self,snapshot):
        d=self.journal.data['day']
        if not d: raise BotError('일일 기준 자산 없음')
        if not self.cfg['risk'].get('daily_loss_enabled',True):return snapshot['equity']
        # Conservative remaining loss room from current equity to day's permitted loss floor.
        return max(dec(0),snapshot['equity']-(dec(d['base'])+dec(d['start_equity'])*dec(self.cfg['risk']['daily_stop'])))

    def latch_day(self,snapshot):
        d=self.journal.data['day']; roi=self.strategy_roi(snapshot['equity'])
        if not d or roi is None: return False
        if (self.cfg['risk'].get('daily_loss_enabled',True) and roi<=dec(self.cfg['risk']['daily_stop'])) or (self.cfg['risk'].get('daily_profit_cap_enabled',True) and roi>=dec(self.cfg['risk']['daily_cap'])):
            if not d['ended']:
                d.update(ended=True,end_reason='일일 -21% 손실 한도' if roi<0 else '일일 +1000% 상한',stop_observed_roi=float(roi),stop_observed_equity=fmt(snapshot['equity']),stop_observed_ms=snapshot['ms'],stop_observed_base=d['base'],stop_observed_start=d.get('start_equity',d['base']))
                self.journal.save(); self.invalidate(); self.entry_cancel.set()
                self.notify('당일 중단',d['end_reason']+f' / 관측 수익률 {float(roi)*100:+.3f}% / 미체결 진입 취소·보유 정리')
        return bool(d['ended'])

    def cancel_entries(self,snapshot):
        by_id={}
        for r in self.records():
            if r['phase']=='submitted': by_id[(r['symbol'],r['client_id'])]=r
            if r.get('pending_add'): by_id[(r['symbol'],r['pending_add']['client_id'])]=r
        for r in self.records(): r['close_requested']=self.journal.data['day'].get('end_reason','당일 중단')
        self.journal.save()
        for order in (self.raw_snapshot or snapshot)['orders']:
            if (order.get('instId'),order.get('clOrdId')) in by_id:
                # Cancellation is reconciled by subsequent order GET; it never causes an opening resend.
                self.api.post('/api/v5/trade/cancel-order',{'instId':order['instId'],'clOrdId':order['clOrdId']})
        for r in self.records(): r['close_requested']=self.journal.data['day'].get('end_reason','당일 중단')
        self.journal.save()

    def margin_room(self,snapshot):
        from okx_risk732 import enabled as quarter_enabled
        if quarter_enabled(self.cfg):
            used=sum((dec(r.get("committed_margin") or 0)+dec(r.get("pending_add",{}).get("margin",0)) for r in self.records()),dec(0))
            return max(dec(0),self.allocation_seed(snapshot)-used)
        from okx_band_flow import enabled as band_enabled
        base=self.allocation_seed(snapshot) if band_enabled(self.cfg) else super().margin_room(snapshot)
        # Preserve stricter allocation if config reduced the previous 2/3 default.
        used=sum((dec(r.get('committed_margin') or 0)+dec(r.get('pending_add',{}).get('margin',0)) for r in self.records()),dec(0))
        return max(dec(0),min(base,self.allocation_seed(snapshot)*dec(self.cfg['risk']['max_total_margin_fraction'])-used))

    def open_risk(self,snapshot):
        total=dec(0)
        positions=(self.raw_snapshot or snapshot)['positions']
        for r in self.records():
            p=next((p for p in positions if (p['instId'],p['posSide'])==(r['symbol'],r['direction'])),None)
            if not p:
                total+=dec(r.get('estimated_loss',r.get('committed_margin',0)) or 0); continue
            ct=dec(r.get('ct_val') or self.api.public('/api/v5/public/instruments',instType='SWAP',instId=r['symbol'])[0]['ctVal'])
            mark=dec(p['markPx']); stop=dec(r['stop_px']); sign=1 if r['direction']=='long' else -1
            total+=dec(p['pos'])*ct*(max(dec(0),(mark-stop)*sign)+mark*dec(r.get('cost_rate',.005)))
        return total

    def risk_snapshot(self,snapshot):
        self.refresh_day(snapshot)
        if self.latch_day(snapshot) or self.entry_cancel.is_set() or not self.enabled or self.recovering: raise BotError('입출금 보정 후 일일/연결/운용 위험 한도 차단')
        notional=self.exposure(snapshot)
        if notional>=self.allocation_seed(snapshot)*dec(self.cfg['risk']['max_total_notional_fraction']): raise BotError('총노출 한도 도달')
        return notional

    def fresh_bars(self,symbol):
        result,opens=read_frames(self.api,symbol,self.cfg)
        self.next_15m_open=opens.get('15m',{});self.next_5m_open=opens.get('5m',{});self.next_1m_open=opens.get('1m',{})
        return result

    def entry_context(self,symbol,action):
        if self.executing_signal and self.executing_signal.get('free_ai'):
            from okx_free_ai import context
            return context(self,symbol,action)
        if self.executing_signal and self.executing_signal.get('strategy')=='band_flow':
            from okx_band_flow import context
            return context(self,symbol,action)
        if self.executing_signal and self.executing_signal.get('strategy')=='research_momentum':
            from okx_research_entry import context
            return context(self,symbol,action)
        from okx_autonomous import enabled
        frozen=self.executing_signal or getattr(self,'auto_frozen',None)
        if frozen and frozen.get('autonomous') and (enabled(self.cfg) or frozen.get('selected_ai_order') or frozen.get('user_chat_order')):return self._autonomous_context(symbol,action)
        if symbol in self.blocked_manual_symbols():raise BotError('수동 포지션/주문 종목 제외: '+symbol)
        self.signal_prepared_monotonic=time.monotonic()
        bars=self.fresh_bars(symbol)
        expected=self.api.now_ms()//300000*300000-300000
        if bars['5m'][-1][0]!=expected:raise BotError('최신 5분 마감 데이터 대기')
        if self.cfg['selection'].get('mode')=='hourly_volume':
            hourly=bars['1H'];expected_hour=self.api.now_ms()//3600000*3600000-3600000
            if not hourly or hourly[-1][0]!=expected_hour or not activity(hourly,self.cfg)['active']:
                raise BotError('진입 재확인: 최신 1시간봉 거래량 급증 조건 미충족')
        if self.cfg['selection'].get('mode')=='scalp_volume' and not activity(bars['5m'],self.cfg)['active']:
            raise BotError('진입 재확인: 5분 거래량 활성 조건 미충족')
        found,reason=signal(bars['5m'],bars['15m'],self.cfg,{k:v for k,v in bars.items() if k in ('1m','1H','4H')})
        if not found or found['action']!=action:
            try:reason=json.loads(reason).get('reason',reason)
            except (ValueError,TypeError):pass
            raise BotError('진입 재확인: '+str(reason))
        check_entry(found,self.api.now_ms(),found.get('entry_reference',0))
        if found.get('strategy')=='wick15_rejection':
            opening_map={'1m':'next_1m_open','5m':'next_5m_open'}.get(found.get('execution_frame'),'next_15m_open')
            opening=getattr(self,opening_map,{}).get(found['valid_from_ms'])
            if opening is None:raise BotError('다음 실행 봉 실제 시가 확인 대기')
            check_entry(found,self.api.now_ms(),opening)
            found['next_open']=opening
        if self.executing_signal and found['signal_id']!=self.executing_signal['signal_id']: raise BotError('AI 확인 후 마감 신호 변경: 다시 확인 필요')
        key=symbol+':'+found['signal_id']
        if key in self.journal.data['seen_signals']: raise BotError('동일 확정 신호 중복 주문 차단')
        self.prepared_signal=found
        # Compatibility with the underlying order machine's structural stop calculation.
        from okx_market import summarize
        frames={bar:summarize(b) if len(b)>=60 else None for bar,b in bars.items()}
        frames['_v4']=found; return frames

    def prepare_entry_plan(self,plan,i,ticker,frames,direction,snapshot,fee):
        from okx_pattern15 import enabled,prepare_plan
        if enabled(self.cfg):return prepare_plan(self,plan,i,ticker,frames,direction,snapshot,fee)
        if frames['_v4'].get('free_ai'):
            reference=dec(ticker['askPx' if direction=='long' else 'bidPx'])
            if abs(reference-dec(frames['_v4']['stop']))/reference>=dec('.85')/5:raise BotError('AI 계획이 현재 시세에서 청산 위험 범위를 벗어남')
        from okx_band_flow import enabled as band_enabled,stock as band_stock
        if band_enabled(self.cfg):
            base=i['instId'].split('-')[0]
            exact=5 if self.cfg['execution'].get('free_ai',{}).get('enabled') or band_stock(i,self.cfg) else {'BTC':30,'ETH':20,'SOL':20}.get(base)
            if (exact is not None and self.entry_leverage!=exact) or (exact is None and not 4<=self.entry_leverage<=10):raise BotError('실제 종목 분류와 요청 배율 불일치: BTC30 / ETH·SOL20 / 주식5 / 기타4~10')
        if frames['_v4'].get('strategy')=='research_momentum':
            reference=dec(ticker['askPx' if direction=='long' else 'bidPx'])
            if abs(reference-dec(frames['_v4']['stop']))/reference*self.entry_leverage>abs(dec(self.cfg['risk']['final_stop_roe'])):raise BotError('구조 손절과 최종 ROE 한도 충돌')
        check_permissions(snapshot['config'])
        notional=self.risk_snapshot(snapshot); found=frames['_v4']
        if not self.stream.ready(i['instId'],self.cfg,self.api.now_ms()): raise BotError('가격·체결·호가 WebSocket 데이터 지연')
        from okx_entry_pipeline import funding_rate
        funding=funding_rate(self.api,i['instId'],self.cfg)
        local_cfg=dict(self.cfg,risk=dict(self.cfg['risk'],leverage=self.entry_leverage))
        prebook=None
        from okx_entry_pipeline import enabled as pipeline_enabled
        if pipeline_enabled(self.cfg):
            # The old size estimate included 10bp and could reject reward/risk before
            # the actual book's configured 5bp entry estimate was ever examined.
            prebook=self.api.public('/api/v5/market/books',instId=i['instId'],sz='400')[0]
            if plan.get('fixed_initial'):
                estimate=book_check(prebook,i,plan['quantity'],direction,self.api.now_ms(),self.cfg)
            else:
                fitted,estimate=fit_book_quantity(prebook,i,plan['quantity'],direction,self.api.now_ms(),self.cfg)
                plan=dict(plan,quantity=fitted)
            plan[direction=='long' and 'buy' or 'sell']=estimate['limit_px']
        if found.get('strategy')=='band_flow' and prebook is not None:
            local_cfg=dict(local_cfg,liquidity=dict(self.cfg['liquidity'],max_slippage=max(self.cfg['liquidity'].get('max_slippage',0),estimate['slippage'])))
        plan=risk_plan(plan,i,found,direction,self.allocation_seed(snapshot),snapshot['available'],fee,funding['fundingRate'],local_cfg,self.open_risk(snapshot),self.day_room(snapshot))
        plan['_allocation_seed']=fmt(self.allocation_seed(snapshot))
        plan['_account_equity']=fmt(snapshot['equity'])
        plan['_initial_risk_budget']=fmt(self.allocation_seed(snapshot)*dec(self.cfg['risk']['max_position_loss_fraction']))
        remaining=self.allocation_seed(snapshot)*dec(self.cfg['risk']['max_total_notional_fraction'])-notional
        lot=dec(i['lotSz']); ct=dec(i['ctVal']); price=dec(plan['buy' if direction=='long' else 'sell'])
        cap=(remaining/(ct*price)/lot).to_integral_value(rounding=ROUND_DOWN)*lot
        if cap<dec(i['minSz']): raise BotError('총노출 한도로 최소 주문 미달')
        if cap<dec(plan['quantity']):
            if plan.get('fixed_initial'):raise BotError('설정 비율 고정 진입 불가: 전체 명목 노출 한도 부족')
            factor=cap/dec(plan['quantity']); plan['quantity']=fmt(cap)
            plan['estimated_loss']=fmt(dec(plan['estimated_loss'])*factor); plan['margin_bound']=fmt(dec(plan['margin_bound'])*factor)
        book=prebook if prebook and 0<=self.api.now_ms()-int(prebook['ts'])<=self.cfg['liquidity']['max_book_age_ms'] else self.api.public('/api/v5/market/books',instId=i['instId'],sz='400')[0]
        original_quantity=dec(plan['quantity'])
        if plan.get('fixed_initial'):
            try:check=book_check(book,i,plan['quantity'],direction,self.api.now_ms(),self.cfg)
            except BotError as error:raise BotError('설정 비율 고정 진입 불가: '+str(error)) from None
            fitted=plan['quantity']
        else:fitted,check=fit_book_quantity(book,i,plan['quantity'],direction,self.api.now_ms(),self.cfg)
        if dec(fitted)<original_quantity:
            factor=dec(fitted)/original_quantity;plan['quantity']=fitted
            plan['margin_bound']=fmt(dec(plan['margin_bound'])*factor);plan['estimated_loss']=fmt(dec(plan['estimated_loss'])*factor)
            plan['_liquidity_resize']=dict(before=fmt(original_quantity),after=fitted)
        plan['buy' if direction=='long' else 'sell']=check['limit_px']
        # Recompute loss, quantity and reward/risk using the latest book estimate.
        if found.get('strategy')=='band_flow':
            local_cfg=dict(local_cfg,liquidity=dict(self.cfg['liquidity'],max_slippage=max(self.cfg['liquidity'].get('max_slippage',0),check['slippage'])))
        plan=risk_plan(plan,i,found,direction,self.allocation_seed(snapshot),snapshot['available'],fee,
            funding['fundingRate'],local_cfg,self.open_risk(snapshot),self.day_room(snapshot))
        plan['_liquidity']=check; plan['_ct']=i['ctVal']; plan['_fee']=fmt(fee); plan['_funding']=funding['fundingRate']
        plan['_selection']=self.selection_row(i['instId'])
        check_entry(found,self.api.now_ms(),plan['buy' if direction=='long' else 'sell'])
        self.risk_snapshot(self.snapshot())  # Final refreshed balance, transfers and daily threshold before writing.
        return plan

    def selection_row(self,symbol):
        frozen=getattr(self,'executing_signal',None) or getattr(self,'auto_frozen',None) or {}
        if not isinstance(frozen,dict):frozen={}
        if frozen.get('strategy')=='band_flow' and frozen.get('symbol')==symbol:
            if symbol in self.blocked_manual_symbols():raise BotError('수동 포지션/주문 종목 제외: '+symbol)
            return dict(frozen['selection'])
        manual_request=frozen.get('selected_ai_order') or frozen.get('user_chat_order') or not frozen.get('autonomous')
        if manual_request and hasattr(self,'chat') and self.chat.allowed_row(symbol):return self.chat.allowed_row(symbol)
        if symbol in self.blocked_manual_symbols():raise BotError('수동 포지션/주문 종목 제외: '+symbol)
        result,_=self.universe.read()
        if not result or time.monotonic()-result['completed']>self.cfg['execution']['scan_max_age_seconds']: raise BotError('전체 후보 갱신 지연')
        from okx_kst_turnover import check_scope
        check_scope(result,symbol,self.api.now_ms(),self.cfg)
        row=next((r for r in result['rows'] if r['symbol']==symbol),None)
        if not row:
            from okx_entry_admission import retained_selection
            row=retained_selection(self,symbol)
        if not row: raise BotError('최신 감시 후보 및 유효한 사전검사 후보에 없는 종목')
        if self.cfg['selection'].get('mode')=='kst09_movers' and row.get('ranking_start_ms')!=self.api.now_ms()//86400000*86400000:
            raise BotError('09시 등락률 기준 변경: 새 후보 갱신 대기')
        return {k:row[k] for k in ('rank','turnover','activity','change','ranking_start_ms','mover_group','mover_rank','turnover_rank','kst_turnover_usdt','turnover_start_ms','turnover_observed_ms') if k in row}

    def entry_metadata(self,plan,frames):
        s=frames['_v4']; key=self.prepared_symbol+':'+s['signal_id']
        self.journal.data['seen_signals'][key]=self.api.now_ms()
        # Keep 7 days of durable deduplication; signal timestamps make old entries unusable anyway.
        self.journal.data['seen_signals']={k:v for k,v in self.journal.data['seen_signals'].items() if self.api.now_ms()-v<7*86400000}
        return dict(initial_risk_px=abs(float(s['entry_reference'])-float(s['stop'])),v4_signal=s,holding_rule=s.get('holding_rule'),invalidation_px=plan['long_stop' if s['action']=='LONG' else 'short_stop'],risk732=plan.get('risk732'),
                    estimated_loss=plan['estimated_loss'],cost_rate=plan['cost_rate'],ct_val=plan['_ct'],
                    entry_liquidity=plan['_liquidity'],selection=plan['_selection'],funding_reserve_rate=plan['_funding'],
                    entry_seed=plan.get('_allocation_seed',plan.get('_account_equity')),account_equity_at_entry=plan.get('_account_equity'),initial_size_mode=plan.get('initial_size_mode') or ('fixed_third' if plan.get('fixed_initial') else 'up_to_third'),initial_margin_target=plan.get('initial_margin_target'),market_fill_check_pending=True,partial_used=False,profit_review_armed=False,profit_review_threshold=self.cfg['risk']['profit_review_roe'],original_risk_budget=plan['_initial_risk_budget'])

    def entry(self,result,instruments=None,analysis_cost=0):
        previous_ids={r['client_id'] for r in self.records()}
        self.pipeline('preflight',result['symbol']+' / 잔고·신호·호가·수량·손절·거래소 허용량 점검')
        self.prepared_symbol=result['symbol']; self.entry_leverage=result['leverage']
        override=self.cfg['signals'].get('support_entries',{}).get('major_leverages',{}).get(self.prepared_symbol.split('-')[0])
        from okx_autonomous import valid_leverage
        if not valid_leverage(result,self.cfg):raise BotError('설정된 종목별 배율 범위 밖')
        try:super().entry(result,instruments,analysis_cost)
        except UnknownOutcome:
            o=self.journal.data['owned']
            if o and o['client_id'] not in previous_ids:self.pipeline('submitted',o['symbol']+' / 응답 미확인: 재전송 없이 주문·체결 조회',count='orders')
            raise
        o=self.journal.data['owned']
        if o and o['phase']=='submitted' and o['client_id'] not in previous_ids:
            self.pipeline('submitted',o['symbol']+' / 주문 전송 후 실제 체결·보호 주문 확인 중',count='orders')
            s=o['v4_signal']; sel=o['selection']; liq=o['entry_liquidity']
            self.notify('진입 요청',f"{o['symbol']} {o['direction']} / {s['strategy']}\n{s['reason']}\n시장: {s['regime']} / {'24h 환산 거래대금 추정 순위' if 'turnover_usdt_estimate' in sel else 'KST09 거래대금 순위'} {sel.get('turnover_rank','미사용')} / 금액 {sel.get('turnover_usdt_estimate',sel.get('kst_turnover_usdt','미사용'))} USDT / 후보 분류 {sel.get('mover_group','기존')} {sel.get('mover_rank','')} / KST09 등락률 {sel.get('change',0)*100:+.2f}% / 시간봉 자체 거래량 {json.dumps(sel['activity'],ensure_ascii=False)}\nMA {s['ma']}\nBOLL {s['bb']} / 재확인 {s['retest']} / 지지저항 {s['level']:.8g} / RSI 보조 {s['rsi']}\n스프레드 {liq['spread']*100:.4f}% / 예상 슬리피지 {liq['slippage']*100:.4f}%\n{o['leverage']}배 / 최초 목표 증거금 {o.get('initial_margin_target') or o['committed_margin']} / 주문 추정 증거금 {o['committed_margin']} / 명목 {liq['notional']} USDT\n손절가 {o['stop_px']} / 비용·급변 여유 반영 예상손실 {o['estimated_loss']} USDT (실제 초과 가능)")
        elif o:self.pipeline('recovery',o['symbol']+' / 기존 포지션·주문 기록 확인 중, 중복 주문 없음')
        else:self.pipeline('preflight_rejected','주문 전 상태/시세가 변경되어 진입 생략. 활동 기록의 상세 이유를 확인하세요.')

    def reconcile(self,snapshot):
        o=self.journal.data['owned']; phase=o['phase'] if o else None
        if phase in ('active','protecting','resizing','partial_closing') and not owned_position(o,snapshot['positions']):
            # No new entry on a single flat observation; retain SL until flat is confirmed.
            ts=int(snapshot['ms']);first=o.get('flat_seen708')
            if first is None or ts<first:
                o['flat_seen708']=ts;self.journal.save();return None
            if ts-first<1000:return None
            self.log(o['symbol']+' / 거래소 잔량 0 재확인 · 보호 주문 정리 후 재탐색')
            self.finish_position();return None
        if o and 'flat_seen708' in o:
            o.pop('flat_seen708');self.journal.save()
        if phase=='partial_closing': return self.reconcile_partial(snapshot)
        if phase=='resizing': return self.reconcile_resize(snapshot)
        if phase=='submitted':
            order=self.api.get('/api/v5/trade/order',instId=o['symbol'],clOrdId=o['client_id'])[0]
            filled=dec(order.get('accFillSz') or 0)
            if filled>0:o['has_fill']=True;self.journal.save()
            if o.get('entry_order_type')=='market' and order.get('state') in ('live','partially_filled') and self.api.now_ms()-o['entry_ms']>5000:
                if not o.get('market_cancel_requested'):
                    o['market_cancel_requested']=True;self.journal.save()
                    self.api.post('/api/v5/trade/cancel-order',dict(instId=o['symbol'],clOrdId=o['client_id']))
                    self.log('시장가 진입 잔량 취소 요청: 결과 확인 후 체결분 대조')
                elif self.api.now_ms()-o['entry_ms']>15000:
                    raise BotError('시장가 잔량 취소 결과 미확인: 신규 주문 차단·계정 확인 필요')
                return owned_position(o,snapshot['positions'])
            if order.get('state') in ('filled','canceled') and 0<filled<dec(o['quantity']):
                p=owned_position(o,snapshot['positions'])
                if not p: self.finish_position(); return None
                if dec(p['pos'])!=filled: raise BotError('진입 일부 체결/실제 수량 불일치')
                ratio=filled/dec(o['quantity']); o['quantity']=fmt(filled)
                o['committed_margin']=fmt(dec(o['committed_margin'])*ratio)
                o['legs']=[dict(legs_for(o)[0],quantity=fmt(filled))]
                o['posId']=p['posId']; o['phase']='active'; self.journal.save()
                self.pause('진입 일부 체결: 실제 체결분만 정리')
                self.close(snapshot,'진입 일부 체결 안전 정리'); return p
        p=super().reconcile(snapshot)
        o=self.journal.data['owned']
        if o and phase=='submitted' and o['phase']=='active':
            self.journal.data['auto_last_entry_fill_ms']=self.api.now_ms();self.journal.save()
            self.pipeline('filled',o['symbol']+' / 실제 체결 확인, 잔여 수량과 거래소 보호 손절 대조',count='fills')
            self.notify('진입 체결',o['symbol']+' / '+o['direction']+' / 실제 체결 '+o['quantity']+'계약 / '+str(o['leverage'])+'배 / 체결가 '+str(o.get('fill_px') or p.get('avgPx') or '확인 중')+' / 손절가 '+str(o.get('stop_px','확인 중'))+' / 보호 등록 확인 중',state=o['client_id'])
        if o and p and o['phase']=='active' and o.get('market_fill_check_pending'):
            from okx_market_orders import fill_assessment
            stats,reason=fill_assessment(p,o,self.cfg)
            # Capture the initial filled structural risk once; the account risk budget is not R.
            if o.get('v4_signal',{}).get('free_ai') and not o.get('learning_risk_usdt'):
                risk=abs(dec(p['avgPx'])-dec(o['v4_signal']['stop']))*abs(dec(p['pos']))*dec(o['ct_val'])
                if risk>0:
                    o['learning_risk_usdt']=fmt(risk)
                    o['learning_risk_basis']='Initial actual filled quantity x contract value x distance from fill to original structural SL; account budget excluded'
            o.update(market_fill_check_pending=False,market_fill_stats=stats,
                committed_margin=stats['margin_usdt'],estimated_loss=stats['estimated_stop_loss'])
            self.journal.save()
            self.log(o['symbol']+' / 시장가 실제 체결 대조: '+json.dumps(stats,ensure_ascii=False))
            if reason:
                self.pause(reason);self.close(snapshot,reason)
        if o and p and o.get('v4_signal',{}).get('strategy')=='research_momentum' and not o.get('initial_risk_px'):
            o['initial_risk_px']=abs(float(p['avgPx'])-float(o['stop_px']));self.journal.save()
        return p

    @staticmethod
    def valid_stop(row,leg):
        try:
            return (row.get('state')=='live' and dec(row['slTriggerPx'])==dec(leg['stop_px'])
                and row.get('slTriggerPxType')=='mark' and row.get('slOrdPx')=='-1'
                and (row.get('closeFraction')=='1' or dec(row.get('sz') or 0)==dec(leg['quantity'])))
        except Exception: return False

    def verify_protection(self,snapshot,p,o):
        mine,other=self.algos()
        if other: raise BotError('기록 외 보호 주문 발견')
        legs=legs_for(o)
        good=sum((dec(l['quantity']) for l in legs),dec(0))==dec(p['pos'])
        for leg in legs:
            rows=[r for r in mine if r.get('algoClOrdId')==leg['algo_client_id']]
            good=good and len(rows)==1 and self.valid_stop(rows[0],leg)
            if good and len(legs)>1:good=dec(rows[0].get('sz') or 0)==dec(leg['quantity'])
        if not good and self.api.now_ms()-o.get('entry_ms',0)>15000:
            # Record the mismatch for diagnosis; never suppress the protective close.
            o['protection_failure_context']=dict(ms=self.api.now_ms(),position_quantity=p.get('pos'),legs=[{k:l.get(k) for k in ('quantity','stop_px','algo_client_id')} for l in legs],observed=[{k:r.get(k) for k in ('algoClOrdId','state','slTriggerPx','slTriggerPxType','slOrdPx','sz','closeFraction')} for r in mine])
            self.journal.save();self.log(o['symbol']+' / 보호 대조 불일치 / '+json.dumps(o['protection_failure_context'],ensure_ascii=False))
            self.pause('보호 주문 확인 실패'); self.close(snapshot,'보호 실패: 잔여 포지션 정리')
        elif good and not o.get('protection_verified'):
            o['protection_verified']=True; self.journal.save(); self.notify('보호 등록 확인',o['symbol']+' / '+o['quantity']+'계약 / 손절가 '+o['stop_px'])
            self.pipeline('holding',o['symbol']+' / 실제 수량과 거래소 보호 손절 확인 완료',count='protected')
        return good

    def trail(self,snapshot,p,o,target):
        tick=dec(self.api.public('/api/v5/public/instruments',instType='SWAP',instId=o['symbol'])[0]['tickSz'])
        long=o['direction']=='long'
        rounding=(ROUND_DOWN if long else ROUND_UP) if self.cfg['execution'].get('rule_channel701') else (ROUND_UP if long else ROUND_DOWN)
        value=(dec(target)/tick).to_integral_value(rounding=rounding)*tick
        old=dec(o['stop_px']); mark=dec(p['markPx'])
        if (long and value<=old) or (not long and value>=old): return
        if (long and value>=mark) or (not long and value<=mark): self.close(snapshot,'추적 손절 가격 도달'); return
        o.update(phase='protecting',target_stop_px=fmt(value),protection_started_ms=self.api.now_ms(),protection_verified=False)
        self.journal.save()
        if self.cfg['execution'].get('rule_channel701'):
            self.log(o['symbol']+' / 보호 SL 변경 요청: '+fmt(old)+' → '+fmt(value)+' / 거래소 확인 대기')
        else:
            self.notify('보호 SL 변경 요청',o['symbol']+' / 기존 '+fmt(old)+' → '+fmt(value)+' / 거래소 확인 대기',state=fmt(value))

    def addition_frames(self,symbol): return self.fresh_bars(symbol)

    def addition_allowed(self,o,p,market):
        from okx_free_ai import owned as free_owned,addition as free_addition
        if free_owned(o):
            if not free_addition(o,p,self.cfg,self.api.now_ms()):return []
            decision=o['free_add_decision'];signal_id='freeadd-'+decision['id']
            if o['symbol']+':'+signal_id in self.journal.data['seen_signals']:return []
            target=decision['target'] if decision['target']>0 else o['v4_signal']['target']
            market['_v4']=dict(o['v4_signal'],stop=float(o['stop_px']),target=target,signal_id=signal_id,at_ms=decision['issued_ms'],reason=decision['reason'])
            return ['ADD_AVERAGE']
        from okx_band_flow import is_owned,add_allowed
        if is_owned(o):
            if not add_allowed(o,p,self.cfg,self.api.now_ms()):return []
            market['_v4']=dict(o['v4_signal'],stop=float(o['stop_px']),signal_id=o['v4_signal']['signal_id']+'A'+str(o.get('band_add_count',0)+1),at_ms=self.api.now_ms(),reason='직전 실제 체결가 대비 가격 5% 역행·기존 SL 유지')
            return ['ADD_AVERAGE']
        if o.get('symbol') in self.blocked_manual_symbols():return []
        from okx_fast_manage import is_fast
        if is_fast(o):return []  # Dedicated short-horizon scalps never average into a losing or aging trade.
        if float(p['uplRatio'])<=self.cfg['risk']['final_stop_roe']: return []
        if o.get('partial_used') or o.get('partial_unsplittable') or o.get('profit_review_armed'):return []
        b=market['frames']
        if o.get('holding_rule') and o['holding_rule'].get('mode')!='scalp':b={**b,'5m':b['15m'],'15m':b['1H']}
        s=scale_confirmation(b,o['direction'],self.cfg)
        if not s or s['action']!=('LONG' if o['direction']=='long' else 'SHORT'): return []
        if s['at_ms'] <= max(o.get('last_scale_bar_ms',o.get('v4_signal',{}).get('at_ms',0)),o.get('profit_sequence',{}).get('signal_bar_ms',0)):return []
        if o['symbol']+':'+s['signal_id'] in self.journal.data['seen_signals']: return []
        sign=1 if o['direction']=='long' else -1
        if (float(p['markPx'])-float(o['stop_px']))*sign<=0: return []
        r=self.cfg['risk']; roe=float(p['uplRatio']); result=[]
        if not o.get('average_used') and not o.get('pyramid_used') and roe<0: result.append('ADD_AVERAGE')
        if not o.get('pyramid_used') and roe>=0: result.append('ADD_PYRAMID')
        market['_v4']=s
        return result

    def prepare_add_plan(self,plan,i,ticker,market,snapshot,p,fee):
        o=self.journal.data['owned']; direction=o['direction']; sign=1 if direction=='long' else -1
        from okx_band_flow import is_owned
        if is_owned(o):
            return self.prepare_band_add(plan,i,ticker,market,snapshot,p,fee)
        found=market['_v4']; found=dict(found,stop=float(o['stop_px']))
        # Do not reset original stop or original position loss budget after averaging.
        local_cfg=dict(self.cfg,risk=dict(self.cfg['risk'],leverage=o['leverage'],initial_margin_fraction=1.0))
        if found.get('strategy')=='band_flow' and prebook is not None:
            local_cfg=dict(local_cfg,liquidity=dict(self.cfg['liquidity'],max_slippage=max(self.cfg['liquidity'].get('max_slippage',0),estimate['slippage'])))
        plan=risk_plan(plan,i,found,direction,self.allocation_seed(snapshot),snapshot['available'],fee,
            self.api.public('/api/v5/public/funding-rate',instId=i['instId'])[0]['fundingRate'],local_cfg,
            self.open_risk(snapshot),self.day_room(snapshot))
        price=dec(plan['buy' if sign==1 else 'sell']); stop=dec(o['stop_px']); ct=dec(i['ctVal']); lot=dec(i['lotSz'])
        oldloss=dec(p['pos'])*ct*(max(dec(0),(dec(p['avgPx'])-stop)*sign)+dec(p['avgPx'])*dec(o.get('cost_rate',.005)))
        realized=dec(p['realizedPnl']) if p.get('realizedPnl') not in (None,'') else sum((dec(p.get(k) or 0) for k in ('pnl','fee','fundingFee')),dec(0))
        budget=dec(o.get('original_risk_budget',o.get('estimated_loss',0)))-oldloss-max(dec(0),-realized)
        unit=ct*(max(dec(0),(price-stop)*sign)+price*dec(plan['cost_rate']))
        if budget<=0 or unit<=0: raise BotError('추가 진입: 최초 손실 예산/고정 손절로 추가 여유 없음')
        notional=self.risk_snapshot(snapshot)
        exposure_room=self.allocation_seed(snapshot)*dec(self.cfg['risk']['max_total_notional_fraction'])-notional
        margin_room=self.addition_margin_cap(snapshot,market,fee)
        qty=min(dec(plan['quantity']), (budget/unit/lot).to_integral_value(rounding=ROUND_DOWN)*lot,
            (exposure_room/(ct*price)/lot).to_integral_value(rounding=ROUND_DOWN)*lot,
            (margin_room*o['leverage']/(ct*price)/lot).to_integral_value(rounding=ROUND_DOWN)*lot)
        if qty<dec(i['minSz']): raise BotError('추가 진입: 위험/노출/증거금 한도로 최소 주문 미달')
        plan.update(quantity=fmt(qty),margin_bound=fmt(qty*ct*price/o['leverage']))
        if not self.stream.ready(i['instId'],self.cfg,self.api.now_ms()): raise BotError('추가 진입 WS 지연')
        check=book_check(self.api.public('/api/v5/market/books',instId=i['instId'],sz='400')[0],i,qty,direction,self.api.now_ms(),self.cfg)
        plan['buy' if sign==1 else 'sell']=check['limit_px']; return plan

    def prepare_band_add(self,plan,i,ticker,market,snapshot,p,fee):
        if self.cfg['execution'].get('structure694'):raise BotError('694 구조 위험 예산 유지: 자동 추가 진입 비활성')
        from okx_entry_pipeline import funding_rate
        o=self.journal.data['owned'];direction=o['direction'];sign=1 if direction=='long' else -1
        self.risk_snapshot(snapshot)
        if not self.stream.ready(i['instId'],self.cfg,self.api.now_ms()):raise BotError('추가 진입 실시간 시세 지연')
        book=self.api.public('/api/v5/market/books',instId=i['instId'],sz='400')[0]
        check=book_check(book,i,plan['quantity'],direction,self.api.now_ms(),self.cfg)
        plan['buy' if sign==1 else 'sell']=check['limit_px']
        cfg=dict(self.cfg,risk=dict(self.cfg['risk'],leverage=o['leverage'],initial_margin_fraction=1.),
                 liquidity=dict(self.cfg['liquidity'],max_slippage=max(check['slippage'],self.cfg['liquidity'].get('max_slippage',0))))
        found=dict(market['_v4'],stop=float(o['stop_px']))
        plan=risk_plan(plan,i,found,direction,dec(o['entry_seed']),snapshot['available'],fee,
            funding_rate(self.api,i['instId'],self.cfg)['fundingRate'],cfg,self.open_risk(snapshot),self.day_room(snapshot))
        cap=self.addition_margin_cap(snapshot,market,fee)
        if dec(plan['margin_bound'])>cap:raise BotError('추가 진입 가용 증거금 부족')
        if self.exposure(snapshot)+dec(plan['quantity'])*dec(i['ctVal'])*dec(plan['buy' if sign==1 else 'sell'])>self.allocation_seed(snapshot)*dec(self.cfg['risk']['max_total_notional_fraction']):raise BotError('추가 진입 총 명목 노출 한도 초과')
        return plan

    def final_add_check(self,snapshot,plan,market):
        self.risk_snapshot(snapshot)
        key=self.journal.data['owned']['symbol']+':'+market['_v4']['signal_id']
        self.journal.data['seen_signals'][key]=self.api.now_ms()
        self.journal.data['owned']['last_scale_bar_ms']=market['_v4']['at_ms']; self.journal.save()
        if not self.within_session(): raise BotError('추가 진입 시간 종료')
        self.notify('추가 진입 요청',self.journal.data['owned']['symbol']+' / '+market['_v4']['reason']+' / '+plan['quantity']+'계약 / 최초 손실 예산·기존 손절 유지')

    def close(self,snapshot,reason,end_day=False):
        o=self.journal.data['owned']
        if o and o['phase'] in ('partial_closing','resizing'):
            o['close_requested']=reason; self.journal.save(); return
        if o and o['phase']!='closing':
            o['exit_reason']=reason; self.notify('전량 청산 요청',o['symbol']+' / '+reason)
        return super().close(snapshot,reason,end_day)

    def finish_position(self):
        o=self.journal.data['owned']
        if o:
            self.queued_risks.discard(o['client_id'])
            if (o.get('posId') or o.get('has_fill')) and not any(r['client_id']==o['client_id'] for r in self.journal.data['settlements']):
                self.journal.data['settlements'].append(dict(symbol=o['symbol'],posId=o.get('posId'),direction=o['direction'],entry_ms=o['entry_ms'],end_ms=self.api.now_ms(),
                    risk732=o.get('risk732'),market_fill_stats=o.get('market_fill_stats'),protection_failure_context=o.get('protection_failure_context'),learning_risk_usdt=o.get('learning_risk_usdt'),learning_risk_basis=o.get('learning_risk_basis'),quality_context=o.get('quality_context',{}),observed_excursion=o.get('observed_excursion',{}),exit_price=o.get('last_quality_mark'),learning=dict(setup=o.get('v4_signal',{}).get('decision_record',{}).get('volume_wick_proof',{}).get('setup'),frame=o.get('v4_signal',{}).get('setup_frame'),key694=o.get('v4_signal',{}).get('decision_record',{}).get('volume_wick_proof',{}).get('learning_key')),source='manual' if o.get('v4_signal',{}).get('user_chat_order') else 'auto',estimated_loss=o.get('original_risk_budget',o.get('estimated_loss','0')),client_id=o['client_id'],reason=o.get('exit_reason','거래소 손절 또는 포지션 종료'),next_check=0))
                self.journal.save()
            self.notify('청산 확인',o['symbol']+' / '+o.get('exit_reason','거래소 손절 또는 포지션 종료')+' / 수수료·펀딩 포함 최종 손익 조회 대기')
        super().finish_position()
        self._search_resume_requested=True
        self.channel_pending={}
        self.band_focus=None

    def settle(self,snapshot):
        for item in list(self.journal.data['settlements']):
            if time.time()<item.get('next_check',0): continue
            item['next_check']=time.time()+60; self.journal.save()
            rows=self.api.get('/api/v5/account/positions-history',instType='SWAP',instId=item['symbol'],limit='100')
            if item.get('posId'):
                found=[r for r in rows if r.get('posId')==item['posId'] and int(r.get('uTime') or 0)>=item['entry_ms']]
            else:
                found=[r for r in rows if r.get('posSide')==item.get('direction') and item['entry_ms']-2000<=int(r.get('cTime') or 0)<=item.get('end_ms',0)+2000 and item['entry_ms']<=int(r.get('uTime') or 0)<=item.get('end_ms',0)+2000]
                if len(found)!=1:continue  # Never invent a symbol attribution when ambiguous.
            if not found: continue
            row=max(found,key=lambda r:int(r.get('uTime') or 0))
            if row.get('realizedPnl') in (None,''): continue
            roi=self.strategy_roi(snapshot['equity']); d=self.journal.data['day']
            pnl=dec(snapshot['equity'])-dec(d['base']) if d else None
            self.notify('청산 손익',f"{item['symbol']} / {item['reason']}\n수수료·펀딩 포함 실현손익 {row['realizedPnl']} USDT\n수수료 {row.get('fee','미확인')} / 펀딩 {row.get('fundingFee','미확인')}\n당일 손익 {fmt(pnl) if pnl is not None else '미확인'} USDT / 수익률 {float(roi)*100 if roi is not None else 0:+.3f}%\n총자산 {fmt(snapshot['equity'])} USDT",state=item['client_id'])
            item['exit_price']=row.get('closeAvgPx')
            actual=dec(row['realizedPnl']); budget=dec(item.get('estimated_loss') or 0)
            if actual<0 and budget>0 and -actual>budget:
                self.notify('예상손실 초과',item['symbol']+' / 예상 '+fmt(budget)+' / 실제 순손실 '+fmt(-actual)+' / 차이 '+fmt(-actual-budget)+' USDT')
            with (self.root/'position_results.jsonl').open('a',encoding='utf-8') as out:
                out.write(json.dumps(dict(item,realizedPnl=row['realizedPnl'],fee=row.get('fee'),fundingFee=row.get('fundingFee')),ensure_ascii=False)+'\n')
            self.journal.data['settlements'].remove(item); self.journal.save()
            try:
                from okx_online_learning import refresh
                learned=refresh(self)
                self.log('자동학습 갱신 / 확정 자동거래 '+str(learned['accepted_trades'])+'건 / 구조별20건부터 후보 우선순위 반영')
            except Exception as error:self.log('자동학습 갱신 실패 / '+type(error).__name__+' / 기존 매매·보호 계속')

    def chart_job(self,symbol):
        existing=self.chart_jobs.get(symbol)
        if existing and existing.done():
            self.chart_jobs.pop(symbol)
            try: self.charts[symbol]=existing.result()
            except Exception: self.charts.pop(symbol,None)
        if symbol not in self.chart_jobs and time.monotonic()>=self.next_charts.get(symbol,0):
            self.next_charts[symbol]=time.monotonic()+self.cfg['execution']['chart_refresh_seconds']
            def read():
                api=OKX(self.settings)
                try:
                    bars,_=read_frames(api,symbol,self.cfg)
                    return bars,time.monotonic()
                finally: api.session.close()
            self.chart_jobs[symbol]=self.chart_pool.submit(read)
        value=self.charts.get(symbol)
        return value[0] if value and time.monotonic()-value[1]<30 else None

    def ai_veto(self,s,epoch):
        if not s.get('_ai_precheck'):raise BotError('AI 호출 전 주문 가능 점검 기록 없음')
        from openai import OpenAI
        from okx_ai_cost import compact,limits,INSTRUCTIONS
        text=compact(s,s.get('_ai_precheck',{}),self.cfg);output_limit=limits(self.cfg)['max_output_tokens']
        from okx_model_runtime import enabled as model_enabled,request as model_request
        if model_enabled(self.cfg):
            schema={'type':'object','properties':{'approve':{'type':'boolean'},'reason':{'type':'string'}},'required':['approve','reason'],'additionalProperties':False}
            return model_request(self,json.loads(text),INSTRUCTIONS,schema,'auto_entry',epoch)
        reserved=(len(text.encode())+len(INSTRUCTIONS.encode())+4096)*.4/1e6+output_limit*1.6/1e6
        billing=self.reserve_api(reserved,epoch)
        if self.cfg["execution"].get("rule_channel701"):raise BotError("규칙 전용 모드: 유료 AI 호출 차단")
        client=OpenAI(api_key=self.settings.get('OPENAI_API_KEY'),max_retries=0,timeout=15)
        response=client.responses.create(model='gpt-4.1-mini',max_output_tokens=output_limit,
            instructions=INSTRUCTIONS,input=text,text={'format':{'type':'json_schema','name':'veto','strict':True,'schema':{'type':'object','properties':{'approve':{'type':'boolean'},'reason':{'type':'string'}},'required':['approve','reason'],'additionalProperties':False}}})
        result=json.loads(response.output_text)
        if set(result)!={'approve','reason'} or type(result['approve']) is not bool or not isinstance(result['reason'],str) or not result['reason'].strip():raise BotError('AI 보조 확인 형식 오류')
        result.update(cost=response.usage.input_tokens*.4/1e6+response.usage.output_tokens*1.6/1e6,
                      reserved=reserved,billing_day=billing,completed=time.monotonic())
        return result

    def schedule_ai(self,s):
        from okx_autonomous import enabled
        if enabled(self.cfg) and s.get('strategy')=='ai_wave_review':return self._autonomous_schedule(s)
        from okx_ai_cost import precheck,compact,wait_reason,mark_call,limits,key
        reason=wait_reason(self,s)
        if reason:self.pipeline('preflight_rejected',s['symbol']+' / '+reason);return False
        try:
            receipt=precheck(self,s)
            fresh=receipt.pop('_fresh_signal',s)
            compact(fresh,receipt,self.cfg) # Bound the payload before any paid request.
        except Exception as error:
            self.pre_ai_retry=getattr(self,'pre_ai_retry',{})
            self.pre_ai_retry[key(s)]=self.api.now_ms()+limits(self.cfg)['precheck_retry_seconds']*1000
            reason=str(error) if isinstance(error,BotError) else '주문 가능 조회 실패: '+type(error).__name__+' / '+str(error)[:160]
            self.pipeline('preflight_rejected',s['symbol']+' / AI 호출 없음 / '+reason,count='pre_ai_blocked')
            return False
        reviewed=dict(fresh,_ai_precheck=receipt)
        mark_call(self,fresh)
        self.approval_signal=reviewed;self.approval_epoch=self.epoch
        self.approval=self.approval_pool.submit(self.ai_veto,reviewed,self.epoch)
        self.pipeline('ai_pending',s['symbol']+' / 주문 가능 점검 통과 후 요약 검토',count='ai_requests')
        return True

    def candidate_decision(self):
        from okx_free_ai import enabled as free_enabled,candidate as free_candidate
        if free_enabled(self.cfg):return free_candidate(self)
        from okx_band_flow import enabled as band_enabled,candidate as band_candidate
        if band_enabled(self.cfg):return band_candidate(self)
        from okx_research_entry import enabled as research_enabled,candidate as research_candidate
        if research_enabled(self.cfg):return research_candidate(self)
        from okx_autonomous import enabled
        if enabled(self.cfg):return self._autonomous_candidate()
        rows,error=self.universe.read()
        if not rows or time.monotonic()-rows['completed']>self.cfg['execution']['scan_max_age_seconds']:
            self.pipeline('scan','전체 후보 조회 중 또는 지연 / '+str(error or '첫 스캔 대기'))
            self.notify('대기','전체 후보 갱신 지연 / '+str(error),state='universe'); return None
        if getattr(self,'last_scan_logged',None)!=rows['completed']:
            self.last_scan_logged=rows['completed']
            stats=rows.get('filter_counts',{})
            if self.cfg['selection'].get('mode')=='kst09_movers':
                rising=sum(r.get('mover_group')=='gainer' for r in rows['rows'])
                falling=sum(r.get('mover_group')=='loser' for r in rows['rows'])
                self.log(f"09시 등락률 스캔: 대상 {rows.get('universe',0)}개 / 순위 선정 {rows.get('selected_count',0)}개 / 감시 상승 {rising}·하락 {falling}개 / {rows.get('scan_seconds',0)}초 / 제외 {stats}")
                for r in rows['rows']:
                    self.log(f"후보 {r['symbol']} / {r.get('mover_group')} {r.get('mover_rank')}위 / KST09 대비 {r.get('change',0)*100:+.2f}%")
            else:self.log(f"종목 스캔: 대상 {rows.get('universe',0)}개 / 거래량 통과 {rows.get('all_candidates',0)}개 / 감시 {len(rows['rows'])}개 / {rows.get('scan_seconds',0)}초 / 거래량 제외 {stats.get('volume_filter',0)}개 / 급변 제외 {stats.get('abnormal_volatility',0)}개")
        if getattr(self,'signal_cache_scan',None)!=rows['completed']:
            self.signal_cache_scan=rows['completed'];self.signal_scan_cache={}
        self.stream.watch([r['symbol'] for r in rows['rows']]+[r['symbol'] for r in self.records()] or ['AAVE-USDT-SWAP'])
        if not rows['rows']:
            self.pipeline('signal_wait','선정·데이터 기준을 통과한 후보 없음 / '+str(rows.get('filter_counts',{})))
            self.notify('대기','종목 선정·데이터 이력·급변 제외 기준을 통과한 후보 없음',state='no_candidates')
            return None
        waits={'수동 거래 종목 제외':0,'패턴 미충족':0,'이미 검토한 신호':0,'실시간 데이터 대기':0,'AI 재호출 제한':0}
        for row in rows['rows']:
            if row['symbol'] in self.blocked_manual_symbols():
                waits['수동 거래 종목 제외']+=1;continue
            if any(o['symbol']==row['symbol'] for o in self.records()): continue
            if self.api.now_ms()-row.get('observed_ms',self.api.now_ms())>self.cfg['execution']['scan_max_age_seconds']*1000:continue
            if row['symbol'] not in self.signal_scan_cache:
                self.signal_scan_cache[row['symbol']]=signal(row['bars5'],row['bars15'],self.cfg,row.get('higher'))
            cached,reason=self.signal_scan_cache[row['symbol']]
            s=dict(cached) if cached else None
            if s and s.get('strategy')=='wick15_rejection':
                try:check_entry(s,self.api.now_ms(),s['entry_reference'])
                except BotError as error:
                    audit=dict(s['decision_record'],reason=str(error));s=None;reason=json.dumps(audit,ensure_ascii=False)
            if self.cfg['signals'].get('entry_mode')=='wick15':
                audit=s['decision_record'] if s else json.loads(reason)
                self.record_wick_decision(row['symbol'],audit)
            if not s:
                waits['패턴 미충족']+=1
                self.notify('대기 '+row['symbol'],reason,state=reason); continue
            s=dict(s,symbol=row['symbol'],selection={k:row[k] for k in ('rank','turnover','activity','change','ranking_start_ms','mover_group','mover_rank','turnover_rank','kst_turnover_usdt','turnover_start_ms','turnover_observed_ms') if k in row})
            cap=int(float(row['instrument']['lever']))
            if cap<self.cfg['risk']['min_leverage']:continue
            chosen=select_leverage(s,self.cfg)
            if self.cfg['risk']['leverage_mode']=='fixed' and chosen>cap:continue
            override=self.cfg['signals'].get('support_entries',{}).get('major_leverages',{}).get(row['symbol'].split('-')[0])
            if override is not None and chosen>cap:
                self.pipeline('preflight_rejected',row['symbol']+' / 거래소 허용 배율이 요청 배율 미만');continue
            s['leverage']=chosen if override is not None else min(chosen,cap)
            from okx_ai_cost import wait_reason
            if not self.preview and self.cfg['execution']['ai_confirmation'] and wait_reason(self,s):
                waits['AI 재호출 제한']+=1;continue
            signal_key=s['symbol']+':'+s['signal_id']
            if signal_key in self.journal.data['seen_signals'] or signal_key in self.ai_reviewed:
                waits['이미 검토한 신호']+=1;continue
            if not self.stream.ready(s['symbol'],self.cfg,self.api.now_ms()):
                waits['실시간 데이터 대기']+=1
                missing=self.stream.missing(s['symbol'],self.cfg,self.api.now_ms())
                self.notify('대기 '+s['symbol'],'실시간 데이터 미준비: '+','.join(missing),state='ws'); continue
            if signal_key not in self.traced_signals:
                self.traced_signals.add(signal_key)
                if len(self.traced_signals)>2000:self.traced_signals={signal_key}
                self.pipeline('preview' if self.preview else 'scan',s['symbol']+' / 확정 신호 발견 '+s['action'],count='signals')
            return s
        self.pipeline('preview' if self.preview else 'signal_wait',' / '.join(k+' '+str(v)+'개' for k,v in waits.items()))
        return None

    def record_wick_decision(self,symbol,audit):
        """Deduplicate identical observations; persist the complete causal explanation locally."""
        import hashlib
        data=json.dumps(audit,ensure_ascii=False,sort_keys=True,separators=(',',':'))
        digest=hashlib.sha256(data.encode()).hexdigest()
        if not hasattr(self,'wick_audits'):self.wick_audits={}
        if self.wick_audits.get(symbol)==digest:return
        path=self.root/'decision_records';path.mkdir(exist_ok=True)
        with (path/(day_key(self.api.now_ms())+'.jsonl')).open('a',encoding='utf-8') as out:
            out.write(json.dumps(dict(symbol=symbol,observed_ms=self.api.now_ms(),**audit),ensure_ascii=False)+'\n')
        self.wick_audits[symbol]=digest
        self.events.put(('timeframes',{'symbol':symbol,'frames':audit.get('frames',{})}))
        frames=audit.get('frames',{})
        summary=' / '.join(k+':'+str(frames.get(k,{}).get('trend','unknown')) for k in ('1m','5m','15m','1H','4H'))
        if not hasattr(self,'frame_summaries'):self.frame_summaries={}
        if self.frame_summaries.get(symbol)!=summary:
            self.log(symbol+' 시간봉 분석 '+summary);self.frame_summaries[symbol]=summary

    def process_approval(self):
        if self.approval_signal and self.approval_signal.get('strategy')=='ai_wave_review':return self._autonomous_process()
        if not self.approval or not self.approval.done(): return
        future=self.approval; s=self.approval_signal; epoch=self.approval_epoch
        self.approval=None; self.approval_signal=None
        self.ai_reviewed[s['symbol']+':'+s['signal_id']]=True
        try: result=future.result()
        except Exception as error:
            self.pipeline('ai_rejected','AI 호출 실패: '+(str(error) if isinstance(error,BotError) else type(error).__name__),count='ai_errors')
            self.notify('대기','AI 보조 확인 실패 / '+type(error).__name__,state='ai-fail'); return
        adjustment=0 if result.get('accounted') else result['cost']-result['reserved']; self.journal.data['api_total_spent']+=adjustment
        if result['billing_day']==self.journal.data['api_day']: self.journal.data['api_spent']+=adjustment
        self.journal.save()
        if epoch!=self.epoch or time.monotonic()-result['completed']>self.cfg['execution']['signal_max_age_seconds']:
            self.pipeline('preflight_rejected','AI 확인 중 운용 상태 또는 신호 유효시간 변경');return
        if not result['approve']:
            self.pipeline('ai_rejected',s['symbol']+' / '+result['reason'],count='ai_rejected')
            self.notify('대기 '+s['symbol'],'AI 보조 거부: '+result['reason'],state='ai-veto-'+s['signal_id']); self.approval_result=None; return
        self.approval_result=s
        self.notify('AI 승인',s['symbol']+' / '+s['action']+' / '+str(s['leverage'])+'배 / '+result['reason']+'\n주문 전 재검증 대기입니다. 실제 체결 알림과 구분하세요.',state=s['symbol']+':'+s['signal_id'])
        self.pipeline('approved',s['symbol']+' / AI 승인, 주문 전 조건 재검증',count='ai_approved')

    def tick(self):
        snapshot=self.snapshot(); day_error=None
        from okx_search_capacity import sync as sync_capacity
        sync_capacity(self)
        try:
            self.refresh_day(snapshot); ended=self.latch_day(snapshot)
        except Exception as error:
            day_error=error;self.entry_cancel.set();self.recovering=True
            ended=bool(self.journal.data['day'] and self.journal.data['day']['ended'])
        if ended:
            try:self.cancel_entries(snapshot)
            except Exception as error:day_error=error
        session=self.journal.data.get('session')
        if session and not session.get('ended') and not session.get('continuous') and self.run_requested and self.cfg['execution'].get('continuous_trading'):
            session['continuous']=True;self.journal.save()
            self.log('연속 운용 시작 기록에 따라 이전 세션의 시간 제한 해제')
        if session and not session.get('continuous') and not session['ended'] and snapshot['ms']>=session['end_ms'] and not self.cfg['execution'].get('continuous_trading'):
            session['ended']=True; self.journal.save(); self.enabled=False; self.user_paused=True; self.entry_cancel.set()
            from okx_continuity732 import stopped
            stopped(self,'설정한 신규 진입 운용시간 만료')
            self.notify('신규 진입 종료','운용시간 만료 / 기존 보유분 보호·차트 관리는 계속')
        result,_=self.universe.read()
        watched=([r['symbol'] for r in result['rows']] if result else [])+[r['symbol'] for r in self.records()]+[k for k,v in getattr(self,'entry_candidate_leases',{}).items() if 0<=self.api.now_ms()-v['ms']<=60000]
        if getattr(self,'_search_capacity_full',False):watched=[r['symbol'] for r in self.records()]+[p['instId'] for p in (self.raw_snapshot or {}).get('positions',[]) if p.get('pos') not in ('0',0,None,'')]
        from okx_band_flow import enabled as band_enabled
        if band_enabled(self.cfg):watched=([self.band_focus] if getattr(self,'band_focus',None) else [])+[r['symbol'] for r in self.records()]
        from okx_free_ai import execution_watch_symbols
        self.stream.watch(execution_watch_symbols(self,watched+self.chat.watch()) or ['AAVE-USDT-SWAP'])
        key=(self.stream.generation,self.account_stream.generation)
        healthy=self.account_stream.fresh() and self.stream.connected
        if not healthy or key!=self.connection_key:
            self.pipeline('recovery','공개 WS: '+str(self.stream.error or ('연결' if self.stream.connected else '미연결'))+' / 계정 WS: '+str(self.account_stream.error or ('수신 확인' if self.account_stream.fresh() else '스냅샷 지연')))
            self.connection_key=key; self.good_snapshots=0; self.recovering=True; self.entry_cancel.set()
            self.notify('연결 대기','연결 끊김/재연결: 신규 진입 차단, 실제 포지션·일반 주문·보호 주문 대조 중',state='recover')
        risks={}
        while not self.risk_queue.empty():
            identity,reason=self.risk_queue.get_nowait(); risks[identity]=reason
        guards=[]; errors=[]
        for slot in range(self.slot_count()):
            with self.selected(slot):
                try:
                    snap=self.snapshot(); o=self.journal.data['owned']
                    from okx_profit_guard714 import enabled as guard_enabled,observe_snapshot,effective_stop,take_profit_due
                    if o and guard_enabled(self.cfg):
                        snap,observed=observe_snapshot(self,snap,o)
                        if observed and o['phase'] in ('active','protecting'):
                            sign=1 if o['direction']=='long' else -1
                            if (float(observed['markPx'])-effective_stop(o))*sign<=0:
                                self.close(snap,'관측 마크가격 보호선 도달');continue
                    p=self.reconcile(snap) if o else None; o=self.journal.data['owned']
                    if not o: continue
                    from okx_profit_guard714 import enabled as guard_enabled,observe as guard_observe,effective_stop
                    if p and p.get('avgPx') and guard_enabled(self.cfg):
                        p=guard_observe(self,snap,p,o)
                    if p and p.get('avgPx'): guards.append(dict(symbol=o['symbol'],direction=o['direction'],client_id=o['client_id'],stop_px=effective_stop(o) if guard_enabled(self.cfg) else o['stop_px'],leverage=o['leverage'],avg_px=p['avgPx'],liq_px=p.get('liqPx') or '0',band_flow=o.get('v4_signal',{}).get('strategy')=='band_flow'))
                    reason=risks.get(o['client_id']) or o.get('close_requested')
                    if ended: reason=self.journal.data['day'].get('end_reason','당日 중단')
                    if self.cfg['risk'].get('final_roe_enabled',True) and p and o.get('v4_signal',{}).get('strategy')!='band_flow' and float(p['uplRatio'])<=self.cfg['risk']['final_stop_roe']: reason='포지션 ROE -30% 최종 손절'
                    if reason:
                        self.close(snap,reason); continue
                    if not p or o['phase']!='active': continue
                    if not self.verify_protection(snap,p,o): continue
                    if not self.cfg['execution'].get('structure694') and float(p['uplRatio'])>=self.cfg['risk']['profit_review_roe'] and not o.get('profit_review_armed'):
                        o['profit_review_armed']=True; self.journal.save()
                    liq=dec(p.get('liqPx') or 0); mark=dec(p['markPx']); buffer=dec(self.cfg['risk']['liquidation_buffer'])
                    if not self.cfg['execution'].get('pattern15_only') and liq>0 and ((o['direction']=='long' and mark<=liq*(1+buffer)) or (o['direction']=='short' and mark>=liq*(1-buffer))):
                        self.close(snap,'청산가 접근: 선제 정리'); continue
                    if self.cfg["execution"].get("rule_channel701"):
                        from okx_channel701 import management as channel_management
                        channel_management(self,snap,p,o);continue
                    from okx_free_ai import owned as free_owned,manage as free_manage
                    if free_owned(o):
                        free_manage(self,snap,p,o);continue
                    from okx_band_flow import is_owned as is_band_owned,evaluate as band_evaluate
                    if is_band_owned(o):
                        bars=self.chart_job(o['symbol']) or {}
                        verdict=band_evaluate(bars,p,o,self.cfg,self.api.now_ms())
                        if verdict['action']=='CLOSE':self.close(snap,verdict['reason']);continue
                        if verdict.get('trail') is not None:self.trail(snap,p,o,verdict['trail'])
                        if o['phase']=='active' and self.enabled and not self.recovering and not ended:
                            market={'frames':bars}
                            if self.addition_allowed(o,p,market):self.scale('ADD_AVERAGE')
                        continue
                    from okx_dynamic_exit import enabled as dynamic_enabled,evaluate as dynamic_evaluate
                    if dynamic_enabled(self.cfg):
                        if 'initial_risk_px' not in o:
                            o['initial_risk_px']=abs(float(o.get('fill_px') or p['avgPx'])-float(o['stop_px']));self.journal.save()
                        dynamic_bars=self.chart_job(o['symbol']) or {}
                        verdict=dynamic_evaluate(dynamic_bars,p,o,self.cfg,self.api.now_ms())
                        if verdict['action']=='CLOSE':self.close(snap,verdict['reason']);continue
                        if verdict['action']=='PARTIAL':
                            self.partial_close(snap,verdict['reason'],fraction=self.cfg['risk']['dynamic_exit']['partial_fraction']);continue
                        if verdict.get('trail') is not None:
                            self.trail(snap,p,o,verdict['trail'])
                            if o['phase']!='active':continue
                        state=(verdict['action'],verdict['bar_ms'],verdict['reason'])
                        if getattr(self,'dynamic_review_states',{}).get(o['client_id'])!=state:
                            if not hasattr(self,'dynamic_review_states'):self.dynamic_review_states={}
                            self.dynamic_review_states[o['client_id']]=state
                            self.log(o['symbol']+' / '+verdict['reason'])
                        self.autonomous_manage(snap,p,o)
                        continue
                    # Profitable confirmed reversal takes priority over +10% and scalp exits.
                    if self.cfg['risk'].get('reversal_profit',{}).get('enabled') and float(p['uplRatio'])>0 and not o.get('partial_used'):
                        reversal_bars=self.chart_job(o['symbol'])
                        if reversal_bars:
                            from okx_reversal_profit import reason as reversal_reason
                            reversal=reversal_reason(reversal_bars,p,o,self.cfg,self.api.now_ms())
                            if reversal:
                                self.log(o['symbol']+' / '+reversal+' / ROE '+str(float(p['uplRatio'])*100)+'% / 60% 부분 청산')
                                self.partial_close(snap,reversal,fraction=self.cfg['risk']['reversal_profit']['partial_fraction'])
                                if o['phase']!='active':continue
                    if self.autonomous_manage(snap,p,o):continue
                    from okx_swing_context import is_structural,manage as swing_manage
                    if is_structural(o):
                        bars=self.chart_job(o['symbol']) or {}
                        action,why,target=swing_manage(bars,p,o,self.cfg,self.api.now_ms())
                        if action=='CLOSE':self.close(snap,why)
                        elif action=='PARTIAL':self.partial_close(snap,why,fraction=.6)
                        elif action=='TRAIL':self.trail(snap,p,o,target)
                        continue
                    from okx_fast_manage import is_fast, realtime_reason as fast_realtime_reason, manage as fast_manage
                    if is_fast(o):
                        fast_exit=fast_realtime_reason(p,o,self.cfg,self.api.now_ms())
                        if fast_exit:
                            self.close(snap,fast_exit);continue
                        fast_bars=self.chart_job(o['symbol'])
                        if fast_bars:
                            action,why,target=fast_manage(fast_bars,p,o,self.cfg,self.api.now_ms())
                            self.record_wick_decision(o['symbol'],holding_record(fast_bars,p,o,self.cfg,action,why))
                            if action=='CLOSE':self.close(snap,why)
                            elif action=='TRAIL':self.trail(snap,p,o,target)
                        continue
                    # First take-profit uses the current position ROE, independent of chart-job delay.
                    if (self.cfg['risk'].get('runner_trend_exit') and not o.get('partial_used')
                        and not o.get('partial_unsplittable') and float(p['uplRatio'])>=self.cfg['risk']['profit_review_roe']):
                        self.partial_close(snap,f"ROE +{self.cfg['risk']['profit_review_roe']*100:g}% 이상: 보유 수량 {self.cfg['risk']['partial_fraction']*100:g}% 1차 익절")
                        if o['phase']!='active':continue
                    bars=self.chart_job(o['symbol'])
                    if not bars: continue
                    from okx_short_exit import reason as short_support_exit
                    support_exit=short_support_exit(bars,p,o,self.cfg)
                    if support_exit:
                        self.log(o['symbol']+' / '+support_exit);self.close(snap,support_exit);continue
                    new_wick=bool(o.get('holding_rule'))
                    scalp=bool(new_wick and o['holding_rule'].get('mode')=='scalp')
                    execution_bars=bars['15m'] if new_wick and not scalp else bars['5m']
                    context_bars=bars['1H'] if new_wick and not scalp else bars['15m']
                    structural=protective_target(execution_bars,context_bars,p,o,self.cfg)
                    if structural is not None:
                        self.trail(snap,p,o,structural)
                        if o['phase']!='active':continue
                    if new_wick:
                        before=o['holding_rule'].get('armed');hold_action,hold_reason=holding_check(bars,p,o,self.cfg)
                        if o['holding_rule'].get('armed')!=before:self.journal.save()
                        if hold_action=='CLOSE':
                            self.record_wick_decision(o['symbol'],holding_record(bars,p,o,self.cfg,'CLOSE',hold_reason))
                            self.close(snap,hold_reason);continue
                    action,why,target=manage(execution_bars,context_bars,p,o,self.cfg)
                    if new_wick:why=hold_reason+' / '+why
                    if new_wick:self.record_wick_decision(o['symbol'],holding_record(bars,p,o,self.cfg,action,why))
                    self.notify('보유 '+o['symbol'],action+' / '+why,state=action+':'+why)
                    if action=='CLOSE': self.close(snap,why)
                    elif action=='PARTIAL': self.partial_close(snap,why,{'target':target,'signal_bar_ms':execution_bars[-1][0]})
                    elif action=='TRAIL': self.trail(snap,p,o,target)
                    if o['phase']=='active' and self.enabled and not ended and not self.recovering and self.within_session():
                        market={'frames':bars}; adds=self.addition_allowed(o,p,market)
                        if adds: self.scale(adds[0])
                except Exception as error: errors.append(error)
        self.guard_rows=tuple(guards)
        sync_capacity(self)  # Re-evaluate after closed slot records have been reconciled.
        if errors: raise errors[0]
        if healthy and day_error is None:
            # Also verify conditional ownership globally after reconnect, including when flat.
            with self.selected(0):
                _,other=self.algos(full=self.recovering)
                if other: raise BotError('복구 대조: 기록 외 조건주문 발견')
            self.good_snapshots+=1
            if self.good_snapshots>=self.cfg['execution']['recovery_snapshots']:
                self.recovering=False
                if self.enabled and not self.user_paused and not ended and not self.queued_risks: self.entry_cancel.clear()
        if day_error is not None:raise day_error
        from okx_click716 import poll as click_poll
        click_busy=click_poll(self)
        from okx_continuity732 import resume_if_ready
        resume_if_ready(self)
        self.chat.poll_selected()
        self.process_approval()
        if ended:self.pipeline('day_stop',self.journal.data['day'].get('end_reason','당일 중단'))
        elif not self.enabled and not self.preview:self.pipeline('recovery' if self.resume_pending else 'paused',self.resume_reason or '실거래 시작 전 또는 사용자 중지')
        elif not self.can_open_position():self.pipeline('holding','설정된 포지션 수 한도 / 보호 손절 감시')
        elif self.enabled and not self.recovering and self.margin_room(snapshot)<=0:self.pipeline('preflight_rejected','전체 증거금 한도로 신규 진입 대기')
        elif self.approval and not self.approval.done():
            from okx_review_ui import review_names
            self.pipeline('ai_pending',review_names(self.approval_signal)+' / AI 승인 응답 대기 중')
        if not click_busy and (self.preview or (self.enabled and not self.recovering and not ended and self.within_session() and not self.entry_cancel.is_set())):
            if self.can_open_position() and self.margin_room(snapshot)>0:
                s=self.approval_result or self.candidate_decision()
                if s:
                    if self.preview:
                        self.notify('미리보기',json.dumps(s,ensure_ascii=False),state=s['symbol']+s['signal_id'])
                        self.log('미리보기 규칙 신호: '+s['symbol']+' '+s['strategy']+' '+s['action'])
                    elif self.cfg['execution']['ai_confirmation'] and not self.approval_result:
                        if not self.approval:
                            self.schedule_ai(s)
                    else:
                        self.approval_result=None
                        slot=self.empty_slot()
                        with self.selected(slot):
                            try:
                                self.executing_signal=s
                                self.entry(s)
                            except BotError as error:
                                # An explicit preflight rejection is a WAIT. Unknown writes still escalate recovery.
                                if isinstance(error,UnknownOutcome): raise
                                self.pipeline('preflight_rejected',s['symbol']+' / '+str(error),count='preflight_rejected')
                                self.notify('대기 '+s['symbol'],str(error),state=str(error)); self.log(str(error))
                            finally: self.executing_signal=None
        self.settle(snapshot); self.publish_portfolio()

    def run(self):
        try:
            while not self.stop_event.is_set():
                self.command_wake.clear()
                try:
                    with self.lock:
                        while not self.commands.empty():
                            action,kwargs=self.commands.get_nowait()
                            try: self.handle(action,kwargs)
                            except Exception as error:
                                self.events.put(('error',str(error) if isinstance(error,BotError) else type(error).__name__))
                                self.pipeline('preflight_rejected',str(error) if isinstance(error,BotError) else type(error).__name__)
                        if not self.stop_event.is_set(): self.tick()
                        self.last_error=None
                except Exception as error:
                    message=str(error) if isinstance(error,BotError) else type(error).__name__+' / '+str(error)[:180]
                    self.recovering=True; self.good_snapshots=0; self.entry_cancel.set()
                    if message!=self.last_error:
                        self.log('복구 대조 대기: '+message); self.notify('복구 대기',message,state=message)
                    self.last_error=message; self.events.put(('error',message))
                    self.pipeline('error',message)
                from okx_entry_gate720 import gate
                self.events.put(('click_gate',gate(self)))
                from okx_continuity732 import publish
                publish(self)
                self.command_wake.wait(.5 if self.guard_rows else 1.5)
        finally:
            self.chat.stop();self.position_history.stop()
            self.telegram_ui.stop();self.stream.stop(); self.account_stream.stop(); self.universe.stop_event.set(); self.notifier.stop_event.set()
            for pool in (self.executor,self.chart_executor,self.chart_pool,self.approval_pool): pool.shutdown(wait=False,cancel_futures=True)

    def publish_portfolio(self):
        super().publish_portfolio()
        from okx_continuity732 import publish
        publish(self)
        from okx_entry_gate720 import gate
        self.events.put(('click_gate',gate(self)))
        if time.monotonic()-getattr(self,'last_entry_diagnostic',-1e9)>=60:
            self.last_entry_diagnostic=time.monotonic()
            state=self.execution_status.snapshot()
            msg='규칙 상태 · '+state['label']+' / '+state['reason']
            scan=getattr(self,'last_channel_scan',None)
            if scan:
                ts,rows,checked,signals,pending=scan
                msg+=' / 마지막 검사 '+datetime.fromtimestamp(ts/1000,KST).strftime('%H:%M:%S')+f' · 후보 {rows} · 완료봉 확인 {checked} · 돌파 {signals} · 주문 준비 {pending}'
            else:msg+=' / 이번 실행에서 아직 완료된 종목 검사 없음'
            self.log(msg)
        d=self.journal.data['day']
        from okx_day_status import daily_status
        equity=self.raw_snapshot['equity'] if self.raw_snapshot else None
        self.events.put(('daily_risk',daily_status(d,equity,self.api.now_ms(),self.cfg,cost_for_day(self.journal.data,(d or {}).get('date')))))
        from okx_autonomous import cadence_status
        self.events.put(('entry_cadence',cadence_status(self)))
        from okx_dashboard_data import dashboard_snapshot
        if self.raw_snapshot:
            try:
                self.position_history.observe(self.raw_snapshot,self.records());self.position_history.tick(self.raw_snapshot['ms'])
                from okx_manual_learning import update as update_manual_learning
                update_manual_learning(self)
            except Exception:pass
            self.events.put(('dashboard',dashboard_snapshot(self.raw_snapshot,self.records(),d,self.stream.connected,self.account_stream.fresh(),self.notifier.enabled)))
        session=self.journal.data.get('session') or {}
        self.events.put(('session_ui',dict(start_ms=session.get('start_ms'),end_ms=None if session.get('continuous') else session.get('end_ms'),continuous=bool(session.get('continuous')),live=self.enabled,user_paused=self.user_paused)))
        from okx_model_runtime import summary as model_summary
        self.events.put(('model_usage',model_summary(self)))
        from okx_api_credit import estimate as credit_estimate
        self.events.put(('api_credit',credit_estimate(self)))
        from okx_budget_pacing import snapshot as pace_snapshot
        self.events.put(('budget_pacing',pace_snapshot(self)))
        from okx_full_market import market_view
        market=market_view(self)
        self.events.put(('market_table',market))
        self.events.put(('chat_symbols',[r['symbol'] for r in market.get('rows',[])] or [r['symbol'] for r in (self.universe.read()[0] or {}).get('rows',[])]))
        if self.raw_snapshot:
            try:self.events.put(('equity_history',self.equity_history.observe(self.raw_snapshot['ms'],self.raw_snapshot['equity'])))
            except Exception:pass
        self.events.put(('v5mode', {'recovering':self.recovering,'ended':bool(d and d['ended']),
            'reason':d.get('end_reason','당일 거래 중단') if d else '',
            'focus':len((self.universe.read()[0] or {}).get('rows',[]))}))
        value=self.execution_status.snapshot();value['last_blocker']=getattr(self,'last_entry_blocker','')
        self.events.put(('pipeline',value))

    def is_allowed_instrument(self,i):
        from okx_free_ai import enabled as free_enabled,allowed as free_allowed
        if free_enabled(self.cfg):return free_allowed(i,self.cfg)
        from okx_oct23 import enabled as oct_enabled,allowed as oct_allowed
        if oct_enabled(self.cfg):return oct_allowed(i,self.cfg)
        from okx_band_flow import enabled as band_enabled,allowed as band_allowed
        if band_enabled(self.cfg):return band_allowed(i)
        if not allowed_instrument(i,self.cfg): return False
        return bool(i.get('listTime') and self.api.now_ms()-int(i['listTime'])>=self.cfg['selection']['min_listing_days']*86400000)

    def reconcile_addition(self,snapshot):
        o=self.journal.data['owned']; pending=o['pending_add']
        row=self.api.get('/api/v5/trade/order',instId=o['symbol'],clOrdId=pending['client_id'])[0]
        if pending.get('entry_order_type')=='market' and row.get('state') in ('live','partially_filled') and self.api.now_ms()-pending['started_ms']>5000:
            if not pending.get('market_cancel_requested'):
                pending['market_cancel_requested']=True;self.journal.save()
                self.api.post('/api/v5/trade/cancel-order',dict(instId=o['symbol'],clOrdId=pending['client_id']))
            elif self.api.now_ms()-pending['started_ms']>15000:
                raise BotError('추가 시장가 잔량 취소 결과 미확인: 신규 주문 차단·계정 확인 필요')
            return owned_position(o,snapshot['positions'])
        filled=dec(row.get('accFillSz') or 0)
        if row.get('state') in ('filled','canceled') and 0<filled<dec(pending['quantity']):
            p=owned_position(o,snapshot['positions'])
            if not p: self.finish_position(); return None
            actual=dec(p['pos'])
            if actual not in (dec(o['quantity'])+filled,filled): raise BotError('추가 진입 일부 체결 수량 불일치')
            old=legs_for(o); leg=dict(algo_client_id=pending['algo_client_id'],quantity=fmt(filled),stop_px=o['stop_px'])
            o['legs']=(old+[leg]) if actual>filled else [leg]
            if actual==filled: o['cleanup_legs']=old
            o['quantity']=fmt(actual); o['posId']=p['posId']; o['phase']='active'
            o['committed_margin']=fmt(dec(o['committed_margin'])+dec(pending['margin'])*filled/dec(pending['quantity']))
            o.pop('pending_add'); self.journal.save()
            self.pause('추가 진입 일부 체결'); self.close(snapshot,'추가 진입 일부 체결 실제 잔여분 정리'); return p
        p=super().reconcile_addition(snapshot)
        if p and o.get('v4_signal',{}).get('strategy')=='band_flow' and o.get('phase')=='protecting':
            o['market_fill_check_pending']=True;self.journal.save()
        if p and o.get('phase')=='active' and pending.get('entry_order_type')=='market':
            prior=dec(pending.get('prior_quantity') or 0);added=dec(pending['quantity'])
            if pending.get('planned_entry_px') and pending.get('prior_average_px'):
                o['planned_entry_px']=fmt((prior*dec(pending['prior_average_px'])+added*dec(pending['planned_entry_px']))/(prior+added))
            o['market_fill_check_pending']=True;self.journal.save()
        return p

    def pre_submit_check(self,plan,instrument,direction):
        from okx_pattern15 import enabled,submit_check
        if enabled(self.cfg):return submit_check(self,plan,instrument,direction)
        from okx_kst_turnover import enabled as turnover_enabled,check_scope
        frozen=getattr(self,'executing_signal',None) or getattr(self,'auto_frozen',None) or {}
        if not isinstance(frozen,dict):frozen={}
        if turnover_enabled(self.cfg) and not (frozen.get('selected_ai_order') or frozen.get('user_chat_order')):
            current,_=self.universe.read()
            if not current:raise BotError('한국시간 거래대금 순위 준비 중')
            check_scope(current,instrument['instId'],self.api.now_ms(),self.cfg)
        if time.monotonic()-getattr(self,'signal_prepared_monotonic',time.monotonic())>self.cfg['execution']['signal_max_age_seconds']:raise BotError('진입 전 차트 확인 유효시간 초과')
        snapshot=self.snapshot(); self.risk_snapshot(snapshot)
        if self.prepared_signal and self.prepared_signal.get('strategy')=='research_momentum':
            from okx_research_entry import check
            quote=self.stream.read(instrument['instId'],'tickers',3,self.api.now_ms())
            if not quote:raise BotError('새 규칙 주문 직전 시세 지연')
            check(self.prepared_signal,self.api.now_ms(),quote['last'])
        if instrument['instId'] in self.blocked_manual_symbols():raise BotError('수동 포지션/주문 종목 제외: '+instrument['instId'])
        if not self.stream.ready(instrument['instId'],self.cfg,self.api.now_ms()): raise BotError('주문 직전 WS 지연')
        if plan.get('fixed_initial'):
            target=dec(plan['initial_margin_target'])
            if dec(plan['quantity'])!=dec(plan['initial_quantity']):raise BotError('설정 비율 고정 수량 변경 감지: 주문 차단')
            fees=target*abs(dec(plan.get('_fee') or 0))*self.entry_leverage*2
            if snapshot['available']<target+fees or self.margin_room(snapshot)<target:
                raise BotError('설정 비율 고정 진입 불가: 주문 직전 가용잔고/전체 증거금 한도 부족')
            tolerance=max(dec(instrument['lotSz'])*dec(instrument['ctVal'])*dec(plan['buy'])/self.entry_leverage,
                target*dec(self.cfg['risk'].get('fixed_initial_max_rounding_fraction',.03)))
            if abs(self.allocation_seed(snapshot)*dec(self.cfg['risk']['initial_margin_fraction'])-target)>tolerance:
                raise BotError('설정 비율 고정 진입: 총자산 변경으로 목표 수량 재분석 필요')
        elif dec(plan['margin_bound'])>min(snapshot['equity'],snapshot['available'])*dec(self.cfg['risk']['initial_margin_fraction']):
            raise BotError('주문 직전 가용잔고 감소: 수량 재분석 필요')
        book=self.api.public('/api/v5/market/books',instId=instrument['instId'],sz='400')[0]
        check=book_check(book,instrument,plan['quantity'],direction,self.api.now_ms(),self.cfg)
        key='buy' if direction=='long' else 'sell'
        old=dec(plan[key]); new=dec(check['limit_px'])
        plan[key]=fmt(min(old,new) if direction=='long' else max(old,new))
        if self.prepared_signal and self.prepared_signal.get('strategy')=='band_flow':
            plan[key]=fmt(new)
            cfg=dict(self.cfg,risk=dict(self.cfg['risk'],leverage=self.entry_leverage),
                     liquidity=dict(self.cfg['liquidity'],max_slippage=max(check['slippage'],self.cfg['liquidity'].get('max_slippage',0))))
            updated=risk_plan(plan,instrument,self.prepared_signal,direction,self.allocation_seed(snapshot),snapshot['available'],
                plan['_fee'],plan['_funding'],cfg,self.open_risk(snapshot),self.day_room(snapshot))
            plan.update(updated)
        if self.prepared_signal:check_entry(self.prepared_signal,self.api.now_ms(),plan[key])
        if (direction=='long' and dec(plan[key])<dec(book['asks'][0][0])) or (direction=='short' and dec(plan[key])>dec(book['bids'][0][0])):
            raise BotError('주문 직전 가격 이동: 기존 허용 범위 밖')
        stop=dec(plan[direction+'_stop'])
        if (direction=='long' and stop>=dec(book['bids'][0][0])) or (direction=='short' and stop<=dec(book['asks'][0][0])):
            raise BotError('주문 직전 손절 가격 도달')
        plan['_liquidity']=check

    def exposure(self,snapshot):
        total=dec(0)
        for pos in (self.raw_snapshot or snapshot)['positions']:
            if dec(pos.get('pos') or 0)==0:continue
            record=next((r for r in self.records() if (r['symbol'],r['direction'])==(pos['instId'],pos['posSide'])),None)
            if not record and self.manual_coexist():continue
            if pos.get('notionalUsd') not in (None,''):total+=abs(dec(pos['notionalUsd']));continue
            if not record:raise BotError('명목 노출을 확인할 수 없는 포지션')
            ct=record.get('ct_val')
            if not ct:ct=self.api.public('/api/v5/public/instruments',instType='SWAP',instId=record['symbol'])[0]['ctVal']
            total+=abs(dec(pos['pos'])*dec(ct)*dec(pos['markPx']))
        return total

    def initial_margin_cap(self,snapshot):
        from okx_free_ai import enabled as free_enabled
        if free_enabled(self.cfg):
            return min(self.margin_room(snapshot),self.allocation_seed(snapshot)*dec(self.cfg['risk']['initial_margin_fraction']))
        from okx_band_flow import enabled as band_enabled
        if band_enabled(self.cfg):
            used=sum((dec(o.get('initial_margin_target') or o.get('committed_margin') or 0) for o in self.records()),dec(0))
            return max(dec(0),min(self.margin_room(snapshot),self.allocation_seed(snapshot)/3-used))
        if self.cfg['risk'].get('initial_size_mode')=='fixed_third':
            return min(self.margin_room(snapshot),self.allocation_seed(snapshot)*dec(self.cfg['risk']['initial_margin_fraction']))
        return min(self.margin_room(snapshot),min(snapshot['equity'],snapshot['available'])*dec(self.cfg['risk']['initial_margin_fraction']))

    def pause(self,reason):
        self.mobile_entry_pause=False
        super().pause(reason)
        from okx_continuity732 import suspended
        suspended(self,reason)
        if hasattr(self,'notifier') and '보호' in str(reason) and any(w in str(reason) for w in ('실패','미확인','불일치','거절')):
            o=self.journal.data.get('owned') or {}
            self.notifier.emit('보호 오류',str(o.get('symbol',''))+' / '+str(reason),state=str(o.get('client_id',''))+':'+str(reason))

    def addition_margin_cap(self,snapshot,market,fee):
        from okx_free_ai import owned as free_owned
        o=self.journal.data['owned']
        if free_owned(o):
            remaining=max(dec(0),min(dec(o['entry_seed'])-dec(o['committed_margin']),self.margin_room(snapshot),snapshot['available']/(1+abs(dec(fee))*o['leverage']*2)))
            return remaining*dec(o['free_add_decision']['margin_fraction'])
        from okx_band_flow import is_owned
        o=self.journal.data['owned']
        if is_owned(o):return min(dec(o['entry_seed'])/3,self.margin_room(snapshot),snapshot['available']/(1+abs(dec(fee))*o['leverage']*2))
        o=self.journal.data['owned'];r=self.cfg['risk']
        room=max(dec(0),min(self.margin_room(snapshot),
            dec(o['entry_seed'])*dec(r['max_position_margin_fraction'])-dec(o['committed_margin']),
            snapshot['available']/(1+abs(dec(fee))*o['leverage']*2)))
        return room*dec(dynamic_add_fraction(market['_v4'],self.cfg))

@echo off
setlocal
cd /d "%~dp0"
set "BOT_PY=.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=..\.venv\Scripts\python.exe"
if not exist "%BOT_PY%" set "BOT_PY=python"
"%BOT_PY%" okx_live_readonly732.py
if errorlevel 1 (
 echo Check failed. Keep the error output.
 pause
 exit /b 1
)
echo Report: LIVE_CHECK_RESULT.txt and LIVE_CHECK_RESULT.json
 echo Read-only inspection. No new live orders, closures, or leverage changes.
pause

"""Read-only chart worker and Canvas renderer. No AI calls or exchange writes."""
import math,statistics,threading,time
from datetime import datetime,timedelta,timezone
STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000,'1D':86400000,'1W':604800000}
NAMES={'1m':'1분봉','5m':'5분봉','15m':'15분봉','1H':'1시간봉','4H':'4시간봉','1D':'1일봉 (UTC)','1W':'1주봉 (UTC)'}
API_FRAMES={'1D':'1Dutc','1W':'1Wutc'}
OFFSETS={'1W':345600000} # Monday 1970-01-05 UTC
KST=timezone(timedelta(hours=9))
def parse(rows,frame,now):
 out={}
 for r in rows:
  if len(r)<9:continue
  try:
   t=int(r[0]);o,h,l,c,v=map(float,r[1:6])
   if t>now or (t-OFFSETS.get(frame,0))%STEPS[frame] or not all(math.isfinite(x) for x in (o,h,l,c,v)) or min(o,h,l,c)<=0 or v<0 or not l<=min(o,c)<=max(o,c)<=h:continue
   extra=[]
   for value in r[6:8]:
    try:
     value=float(value);extra.append(value if math.isfinite(value) and value>=0 else None)
    except (ValueError,TypeError):extra.append(None)
   out[t]=[t,o,h,l,c,v,r[8]=='1',*extra]
  except (ValueError,TypeError):continue
 return [out[k] for k in sorted(out)]
class ChartFeed:
 def __init__(self,settings,events,api_factory=None):
  from okx_funding732 import FundingFeed
  self.funding=FundingFeed(settings,api_factory)
  self.settings=dict(settings);self.events=events;self.factory=api_factory;self.condition=threading.Condition();self.selection=None;self.revision=0;self.closed=False;self.thread=None;self.cache={};self.older=False;self.exhausted=set();self.last_older=0;self.analysis_cache={};self.direction_cache={}
 def start(self):
  if not self.thread:self.thread=threading.Thread(target=self.run,daemon=True,name='readonly-position-chart');self.thread.start()
 def select(self,symbol,frame):
  if frame not in STEPS:raise ValueError('차트 시간봉 오류')
  self.funding.select(symbol)
  with self.condition:
   value=(symbol,frame) if symbol else None
   if value!=self.selection:self.selection=value;self.older=False;self.revision+=1;self.condition.notify_all()
 def load_older(self,symbol,frame):
  with self.condition:
   key=(symbol,frame)
   if self.selection==key and key not in self.exhausted and self.cache.get(key):self.older=True;self.condition.notify_all()
 def stop(self):
  self.funding.stop()
  with self.condition:self.closed=True;self.condition.notify_all()
 def run(self):
  api=None;last=0;observed=-1
  try:
   while True:
    with self.condition:
     if self.closed:return
     if not self.selection:self.condition.wait(1);continue
     if not self.older and observed==self.revision and time.monotonic()-last<1:self.condition.wait(min(.25,1-(time.monotonic()-last)));continue
     symbol,frame=self.selection;rev=self.revision;observed=rev;last=time.monotonic()
     key=(symbol,frame);older=self.older and bool(self.cache.get(key));self.older=False
     if older and last-self.last_older<1:
      self.older=True;self.condition.wait(1-(last-self.last_older));continue
     if older:self.last_older=last
    try:
     if api is None:
      from okx_core import OKX
      api=(self.factory or OKX)(self.settings)
     if older:
      before=self.cache[key][0][0]
      rows=api.public('/api/v5/market/history-candles',instId=symbol,bar=API_FRAMES.get(frame,frame),after=str(before),limit='100')
     else:rows=api.public('/api/v5/market/candles',instId=symbol,bar=API_FRAMES.get(frame,frame),limit='300')
     now=api.now_ms();received=parse(rows,frame,now)
     if older and not any(b[0]<before for b in received):self.exhausted.add(key)
     joined={b[0]:b for b in self.cache.get(key,[])};joined.update({b[0]:b for b in received})
     bars=[joined[t] for t in sorted(joined)]
     if not bars:raise ValueError('차트 봉 데이터 없음')
     self.cache[key]=bars
     if len(self.cache)>8:
      first=next(k for k in self.cache if k!=key);self.cache.pop(first);self.exhausted.discard(first)
     early=dict(analysis=self.direction_cache.get(symbol),symbol=symbol,frame=frame,bars=bars,observed_ms=now,stale=now-bars[-1][0]>=STEPS[frame]*2,error=None,history_end=key in self.exhausted,operation='older' if older else 'latest')
     with self.condition:
      if not self.closed and rev==self.revision:self.events.put(('position_chart',early))
     if not older:
      from okx_pattern15 import STEPS as ANALYSIS_STEPS,summary
      reports={};analysis_frames={}
      for af,step in ANALYSIS_STEPS.items():
       cached=self.analysis_cache.get((symbol,af))
       if not cached or time.monotonic()-cached[0]>=60 or cached[1].get('completed_ms')!=now//step*step:
        try:
         ab=bars if af==frame else parse(api.public('/api/v5/market/candles',instId=symbol,bar=af,limit='300'),af,now)
         closed=[r for r in ab if r[0]+step<=now and r[6]]
         info=summary(closed);info.update(observed_ms=now,completed_ms=closed[-1][0]+step if closed else 0);self.analysis_cache[(symbol,af)]=(time.monotonic(),info,ab)
        except Exception:self.analysis_cache[(symbol,af)]=(time.monotonic(),dict(trend='unknown',reason='분석 조회 실패 · 재시도 대기'))
       reports[af]=self.analysis_cache[(symbol,af)][1]
       cached=self.analysis_cache[(symbol,af)]
       if len(cached)>2:analysis_frames[af]=cached[2]
      self.events.put(('timeframes',dict(symbol=symbol,frames=reports)))
      from okx_direction732 import analyze
      try:
       quote=api.public('/api/v5/market/ticker',instId=symbol)[0]
       self.direction_cache[symbol]=analyze(symbol,analysis_frames,quote,api.now_ms())
      except Exception:self.direction_cache[symbol]=dict(ready=False,symbol=symbol,reason='분석 시세 조회 실패')
      # Bounded cache; historical bars never change the latest-entry analysis.
      if len(self.direction_cache)>8:self.direction_cache.pop(next(iter(self.direction_cache)))
      if len(self.analysis_cache)>32:self.analysis_cache={k:v for k,v in self.analysis_cache.items() if k[0]==symbol}
     result=dict(analysis=self.direction_cache.get(symbol),symbol=symbol,frame=frame,bars=bars,observed_ms=now,stale=now-bars[-1][0]>=STEPS[frame]*2,error=None,history_end=key in self.exhausted,operation='older' if older else 'latest')
    except Exception as exc:
     result=dict(symbol=symbol,frame=frame,bars=[],observed_ms=int(time.time()*1000),stale=True,error='차트 조회 보류 · '+type(exc).__name__+' · 자동 재시도')
    with self.condition:
     if not self.closed and rev==self.revision:self.events.put(('position_chart',result))
  finally:
   if api:api.session.close()

def window_bounds(bars,anchor,count):
 from bisect import bisect_right
 end=len(bars) if anchor is None else bisect_right([b[0] for b in bars],anchor)
 end=max(1,min(len(bars),end));return max(0,end-count),end

def price_bounds(low,high,zoom):
 center=(low+high)/2;half=max(high-low,abs(high)*.002)*.57/max(.5,min(4.0,zoom))
 return center-half,center+half

def draw(view,c,x,y,w,h,position,data,frame):
 from okx_ui_theme import INNER,BORDER,MUTED,GREEN,RED,AMBER,TEXT
 c.create_rectangle(x,y,x+w,y+h,fill=INNER,outline=BORDER)
 view.text(c,x+10,y+5,NAMES.get(frame,frame)+' · 현재 표시 시간봉',11,TEXT,True)
 view._candle_geometry=None
 bars=data.get('bars',[]) if data else []
 if not bars:
  view.text(c,x+w/2,y+h/2,(data or {}).get('error') or ('보유 포지션을 선택하세요' if not position else '차트 데이터 조회 중'),14,MUTED,anchor='center');return
 start,end=window_bounds(bars,view.chart_anchor,view.chart_count)
 displayed=bars[start:end];allclose=[r[4] for r in bars[:end]];offset=start
 periods=view.state.get('chart_indicators',{}).get('ma_periods',[15,20,50,100,120,200]);bbn=view.state.get('chart_indicators',{}).get('bb_period',20);bbk=view.state.get('chart_indicators',{}).get('bb_multiplier',2)
 series=[];colors=['#e5bd72','#63c8da','#b293ed','#ed9dad','#80c6a2','#a4b4cf']
 for n,col in zip(periods,colors):
  values=[sum(allclose[j-n+1:j+1])/n if j+1>=n else None for j in range(offset,end)];series.append(('MA'+str(n),col,values))
 mids=[];uppers=[];lowers=[]
 for j in range(offset,end):
  chunk=allclose[max(0,j-bbn+1):j+1]
  if len(chunk)<bbn:mids.append(None);uppers.append(None);lowers.append(None);continue
  mid=sum(chunk)/bbn;sd=statistics.pstdev(chunk);mids.append(mid);uppers.append(mid+bbk*sd);lowers.append(mid-bbk*sd)
 values=[v for r in displayed for v in r[2:4]]+[v for a in (mids,uppers,lowers) for v in a if v is not None]
 # Price scale includes trade levels, but distant MA200 is clipped rather than flattening candles.
 levels=[]
 for key,label,col in [('entry','진입', GREEN),('mark','현재',GREEN),('stop','SL',RED),('target','목표',AMBER),('partial_price','1차 +20% ROE',AMBER)]:
  try:value=float((position or {}).get(key) or 0)
  except (ValueError,TypeError):continue
  if value>0 and math.isfinite(value):levels.append((value,label,col));values.append(value)
 low,high=price_bounds(min(values),max(values),view.chart_price_zoom)
 shift=getattr(view,'chart_price_shift',0.)*(high-low);low+=shift;high+=shift
 left=x+10;right=x+w-88;top=y+68;bottom=y+h-80;voltop=bottom+12;volbottom=y+h-23
 slots=len(displayed)+max(0,getattr(view,'chart_right_bars',0))
 view._candle_geometry=dict(bars=displayed,left=left,right=right,top=top,bottom=volbottom,slots=slots,x=x,y=y,w=w,h=h)
 def px(j):return left+(j+.5)*(right-left)/slots
 def py(v):return max(top,min(bottom,top+(high-v)/(high-low)*(bottom-top)))
 for j in range(5):
  v=low+(high-low)*j/4;yy=py(v);c.create_line(left,yy,right,yy,fill=BORDER);view.text(c,right+7,yy,format(v,'.6g'),10,MUTED,anchor='w')
 for label,col,line in [('BOLL',AMBER,mids),('UB',AMBER,uppers),('LB',AMBER,lowers)]+series:
  points=[]
  for j,v in enumerate(line):
   if v is not None and low<=v<=high:points.extend((px(j),py(v)))
   else:
    if len(points)>=4:c.create_line(*points,fill=col,width=1)
    points=[]
  if len(points)>=4:c.create_line(*points,fill=col,width=1)
 bw=max(2,(right-left)/slots*.62);maxvol=max(r[5] for r in displayed) or 1
 for j,r in enumerate(displayed):
  col=GREEN if r[4]>=r[1] else RED;xx=px(j)
  if r[2]>=low and r[3]<=high:c.create_line(xx,py(r[2]),xx,py(r[3]),fill=col)
  if max(r[1],r[4])>=low and min(r[1],r[4])<=high:c.create_rectangle(xx-bw/2,min(py(r[1]),py(r[4])),xx+bw/2,max(min(py(r[1]),py(r[4]))+1,max(py(r[1]),py(r[4]))),fill=col,outline=col)
  c.create_rectangle(xx-bw/2,volbottom-(volbottom-voltop)*r[5]/maxvol,xx+bw/2,volbottom,fill=col,outline='')
 label_y=top-22
 for v,label,col in sorted(levels,key=lambda a:py(a[0])):
  if not low<=v<=high:continue
  yy=py(v);c.create_line(left,yy,right,yy,fill=col,dash=(5,4))
  if label=='목표':label+='(고정)' if (position or {}).get('target_mode')=='fixed' else '(검토)'
  if label=='SL' and not (position or {}).get('protected'):label+=' 확인중'
  note=(position or {}).get('stop_note','') if label.startswith('SL') else (position or {}).get('partial_note','') if label.startswith('1차') else ''
  label_y=max(label_y+20,yy-18);view.text(c,left+4,label_y,label+' '+format(v,'.7g')+(' · '+note if note else ''),10,col,True)
 for j in (0,len(displayed)//2,len(displayed)-1):view.text(c,px(j),volbottom+4,datetime.fromtimestamp(displayed[j][0]/1000,KST).strftime('%m/%d %H:%M'),10,MUTED,anchor='n')
 legend='BOLL('+str(bbn)+','+str(bbk)+') · MA '+','.join(map(str,periods))+' · 거래량'
 view.text(c,left,y+25,(((position or {}).get('exit_estimate_note') or legend)+(' · '+str((position or {}).get('partial_note')) if (position or {}).get('partial_note') and not (position or {}).get('partial_price') else '')),9,MUTED)
 last=displayed[-1];stamp=datetime.fromtimestamp(data['observed_ms']/1000,KST).strftime('%H:%M:%S')
 view.text(c,left,y+45,('예시 · ' if view.demo else '')+('지연 · ' if data.get('stale') else '')+stamp+' KST · '+('과거 구간' if view.chart_anchor is not None else ('마감봉' if last[6] else '진행봉')),10,AMBER if data.get('stale') else MUTED)

def hover_candle(view,c,event=None):
 c.delete('candle_tip')
 g=getattr(view,'_candle_geometry',None)
 if event is None or not g:return
 xx=c.canvasx(event.x);yy=c.canvasy(event.y);step=(g['right']-g['left'])/g['slots']
 i=int((xx-g['left'])/step)
 if xx<g['left'] or not g['top']<=yy<=g['bottom'] or not 0<=i<len(g['bars']):return
 b=g['bars'][i];cx=g['left']+(i+.5)*step
 c.create_line(cx,g['top'],cx,g['bottom'],fill='#ffab54',dash=(4,4),tags='candle_tip')
 stamp=datetime.fromtimestamp(b[0]/1000,KST).strftime('%m/%d %H:%M')
 lines=[stamp+' KST · '+('확정봉' if b[6] else '진행봉'),
        '시가  '+format(b[1],'.8g'),'고가  '+format(b[2],'.8g'),
        '저가  '+format(b[3],'.8g'),'종가  '+format(b[4],'.8g'),
        '등락률  '+format((b[4]/b[1]-1)*100,'+.2f')+'%',
        '진폭  '+format((b[2]-b[3])/b[1]*100,'.2f')+'%',
        '거래량 (계약)  '+format(b[5],',.2f')]
 if len(b)>7 and b[7] is not None:lines.append('거래량 (코인)  '+format(b[7],',.2f'))
 if len(b)>8 and b[8] is not None:lines.append('거래대금 (USDT)  '+format(b[8],',.2f'))
 text=c.create_text(0,0,text='\n'.join(lines),anchor='nw',fill='#eee',font=('TkDefaultFont',10),tags='candle_tip')
 box=c.bbox(text);tw=box[2]-box[0]+20;th=box[3]-box[1]+20
 tx=max(g['x']+4,min(g['x']+g['w']-tw-4,cx+14 if cx<g['x']+g['w']/2 else cx-tw-14))
 ty=max(g['y']+4,min(g['y']+g['h']-th-4,yy-th/2))
 rect=c.create_rectangle(tx,ty,tx+tw,ty+th,fill='#171717',outline='#ffab54',tags='candle_tip')
 c.coords(text,tx+10,ty+10);c.tag_raise(text,rect)

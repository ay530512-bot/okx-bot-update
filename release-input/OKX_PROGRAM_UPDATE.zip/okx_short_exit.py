"""Confirmed MA support against a held short; never widens protection or opens orders."""
from okx_rules import metrics
from okx_context_entries import background

DEFAULTS=dict(enabled=True,fast_periods=[5,10,15,20],hour_periods=[15,20,50,100,120,200],
    touch_atr=.25,reaction_atr=.05)


def validate(p):
    return (type(p['enabled']) is bool and p['fast_periods'] and p['hour_periods']
        and all(type(n) is int and n in (5,10,15,20,50,100,120,200) for n in p['fast_periods']+p['hour_periods'])
        and 0<p['touch_atr']<=1 and 0<p['reaction_atr']<=.5)


def reason(frames,position,owned,c):
    p=c['signals'].get('short_support_exit',{})
    if not p.get('enabled') or position.get('posSide')!='short':return None
    signal=owned.get('v4_signal',{});context=signal.get('decision_record',{}).get('evidence',{}).get('context_frame')
    hourly=context in ('1H','4H') and signal.get('pattern','').startswith('context_')
    frame='5m' if hourly else '1m' if frames.get('1m') else '5m'
    b=frames.get(frame,[]);need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1
    if len(b)<need+1:return None
    step=60000 if frame=='1m' else 300000;last,prev=b[-1],b[-2]
    if prev[0]+step<=owned.get('entry_ms',0):return None
    m=metrics(b[:-1],c);atr=m['atr']
    # Two completed candles: no fresh low, directional close recovery, not a mere intrabar touch.
    bounce=(last[3]>=prev[3]-atr*.05 and last[4]>prev[4]+atr*p['reaction_atr'] and last[4]>last[1])
    if not bounce:return None
    if hourly:
        known=[r for r in frames.get(context,[]) if r[0]+(3600000 if context=='1H' else 14400000)<=prev[0]]
        cfg=dict(c,signals=dict(c['signals'],context_entries=dict(c['signals'].get('context_entries',{}),reference_periods=p['hour_periods'])))
        upper=background(known,cfg)
        if not upper:return None
        references=upper['ma'];tol=upper['atr']*p['touch_atr']
    else:
        references={n:sum(r[4] for r in b[:-1][-n:])/n for n in p['fast_periods']};tol=atr*p['touch_atr']
    for period,level in references.items():
        touched=min(abs(prev[3]-level),abs(last[3]-level))<=tol
        recovered=prev[4]>=level-atr*.1 and last[4]>level+atr*p['reaction_atr']
        if touched and recovered:
            if hourly and not (prev[4]>level and last[4]>level):continue
            return ('숏 청산: '+context+' SMA'+str(period)+' 지지·5m 2봉 회복') if hourly else ('숏 신속 청산: '+frame+' SMA'+str(period)+' 지지 회복·저점 보존 2봉')
    return None

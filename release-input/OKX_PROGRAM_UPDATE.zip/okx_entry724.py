"""Causal V724 rule candidates. Research hypotheses, not guaranteed returns.

All variants are recorded in the research plan before independent evaluation.
Each proof is consumed unchanged by the existing order/SL state machine.
"""
from math import isfinite, sqrt
from okx_band_flow import atr
from okx_market import rsi
from okx_entry721 import PERIODS, LOOKBACKS
from okx_entry722 import direction, hourly_from_15m
from okx_entry723 import analyze as previous

DEFAULT_VARIANT = 'regime724'  # frozen development-only selection
VARIANTS = ('baseline723', 'smooth724', 'progress724', 'smooth_progress724',
            'hour_break724', 'exhaustion724', 'range724', 'squeeze724',
            'failed_retest724', 'regime724', 'slow_pullback724',
            'ema_reclaim724', 'vwap_reclaim724', 'failed_break724',
            'rsi_recovery724', 'double_turn724')


def efficiency(closes, n=20):
    if len(closes) < n + 1:
        return 0.
    c = [float(x) for x in closes[-n-1:]]
    distance = sum(abs(y-x) for x, y in zip(c, c[1:]))
    return abs(c[-1]-c[0])/distance if distance > 0 else 0.


def ema(closes, n=20):
    value=float(closes[0]);alpha=2/(n+1)
    for c in closes[1:]:value+=alpha*(float(c)-value)
    return value


def slow_direction(h):
    if len(h)<55 or any(y[0]-x[0]!=3600000 for x,y in zip(h[-55:],h[-54:])):
        return 0
    c=[r[4] for r in h];m=sum(c[-50:])/50;old=sum(c[-55:-5])/50
    return 1 if c[-1]>m>old else -1 if c[-1]<m<old else 0


def _frames(b, hourly):
    if len(b) < 241:
        return None, '완료15분봉241개 대기'
    try:
        if any(len(r) < 6 or not all(isfinite(float(x)) for x in r[:6]) or
               min(r[1:5]) <= 0 or r[5] < 0 or
               not r[3] <= min(r[1], r[4]) <= max(r[1], r[4]) <= r[2] for r in b):
            return None, '봉 데이터 오류'
        if any(y[0]-x[0] != 900000 for x, y in zip(b, b[1:])):
            return None, '15분봉 누락'
        end = b[-1][0] + 900000
        h = hourly_from_15m(b) if hourly is None else [r for r in hourly if r[0]+3600000 <= end]
        if len(h) < 25 or h[-1][0]+3600000 != end//3600000*3600000:
            return None, '최신 완료1시간봉 대기'
        if any(y[0]-x[0] != 3600000 for x, y in zip(h[-25:], h[-24:])):
            return None, '1시간봉 누락'
        if any(len(r) < 6 or not all(isfinite(float(x)) for x in r[:6]) or
               min(r[1:5]) <= 0 or r[5] < 0 or
               not r[3] <= min(r[1], r[4]) <= max(r[1], r[4]) <= r[2] for r in h[-100:]):
            return None, '1시간봉 데이터 오류'
    except (TypeError, ValueError, IndexError):
        return None, '봉 데이터 오류'
    return h, ''


def analyze(b, hourly=None, variant=None, relaxed=False):
    variant = variant or DEFAULT_VARIANT
    if variant not in VARIANTS:
        raise ValueError('Unknown V724 variant: '+variant)
    h, error = _frames(b, hourly)
    if h is None:
        return dict(setups=[], reason=error)
    er = efficiency([r[4] for r in h])
    if variant == 'regime724':
        # Two economic regimes, not a per-symbol winner lookup.
        branch = 'smooth_progress724' if er >= .30 else 'exhaustion724'
        result = analyze(b, h, branch, relaxed=relaxed)
        return dict(setups=[dict(v, variant724=variant, regime_branch724=branch)
                           for v in result['setups']], reason=result['reason'])
    if variant in VARIANTS[:4] or variant == 'slow_pullback724':
        result = previous(b, h, relaxed=relaxed)
        values = []
        for value in result['setups']:
            side = 1 if value['action'] == 'LONG' else -1
            if variant in ('smooth724', 'smooth_progress724') and (
                    er < .30 or (h[-1][4]-h[-21][4])*side <= 0):
                continue
            if variant == 'slow_pullback724' and slow_direction(h) != side:
                continue
            values.append(dict(value, policy_version=724, variant724=variant,
                               hourly_efficiency724=er,
                               progress_exit724=variant in ('progress724', 'smooth_progress724', 'slow_pullback724')))
        return dict(setups=values, reason='눌림 확인' if values else '눌림/시간봉 추세 지속성 확인 대기')
    cs = [float(r[4]) for r in b]
    last = b[-1]; op, hi, lo, c, vol = map(float, last[1:6])
    a = atr(b[:-1]); span = hi-lo
    minimum_atr=.002 if variant in ('ema_reclaim724','vwap_reclaim724','failed_break724',
                                   'rsi_recovery724','double_turn724') else .004
    if a <= 0 or span <= 0 or a/c < minimum_atr:
        return dict(setups=[], reason='변동폭/가격 범위 대기')
    rs = rsi(cs, 14); oldrs = rsi(cs[:-1], 14)
    ma = {n: sum(cs[-n:])/n for n in PERIODS}
    slopes = {n: ma[n]-sum(cs[-n-1:-1])/n for n in PERIODS}
    hd = direction(h); candidates = []
    for side in (1, -1):
        strength = (c-lo if side == 1 else hi-c)/span
        wick = (min(op,c)-lo if side == 1 else hi-max(op,c))/span
        votes = sum((c-ma[n])*side > 0 and slopes[n]*side > 0 for n in PERIODS)
        if (c-op)*side <= 0 or strength < (.55 if relaxed else .6) or span > 2.5*a:
            continue
        for n in LOOKBACKS:
            p = b[-n-1:-1]; mean = sum(r[5] for r in p)/n
            if mean <= 0 or vol < mean * (.9 if relaxed else 1.):
                continue
            ch = max(r[2] for r in p); cl = min(r[3] for r in p)
            level = None
            if variant == 'hour_break724':
                edge = max(r[2] for r in h[-20:]) if side == 1 else min(r[3] for r in h[-20:])
                if (hd == side and er >= .30 and votes >= 3 and vol >= 1.2*mean
                        and (50 <= rs <= 75 if side == 1 else 25 <= rs <= 50)
                        and (cs[-2]-edge)*side <= 0 and .05*a < (c-edge)*side <= a):
                    level = edge
            elif variant == 'exhaustion724':
                # A completed expansion is followed by a failed extension and reversal.
                prev = b[-2]; pa = atr(b[:-2]); vm = sum(r[5] for r in b[-22:-2])/20
                mid = sum(cs[-21:-1])/20
                if pa <= 0 or vm <= 0:
                    continue
                extreme = prev[3] if side == 1 else prev[2]
                near = lo if side == 1 else hi
                if (prev[2]-prev[3] >= 2*pa and (prev[4]-prev[1])*side <= -pa
                        and prev[5] >= (1.35 if relaxed else 1.5)*vm and (prev[4]-mid)*side <= -pa
                        and (oldrs < 35 and rs > oldrs if side == 1 else oldrs > 65 and rs < oldrs)
                        and wick >= (.20 if relaxed else .25) and -.25*a <= (near-extreme)*side <= .5*a
                        and (c-prev[4])*side > 0):
                    level = min(lo,prev[3]) if side == 1 else max(hi,prev[2])
            elif variant == 'range724':
                mid = sum(cs[-21:-1])/20
                sd = sqrt(sum((x-mid)**2 for x in cs[-21:-1])/20)
                edge = mid-side*2*sd
                near = lo if side == 1 else hi
                if (er <= .30 and wick >= .25
                        and (oldrs < 35 and rs > oldrs if side == 1 else oldrs > 65 and rs < oldrs)
                        and (near-edge)*side < 0 and (c-edge)*side > 0):
                    level = lo if side == 1 else hi
            elif variant == 'squeeze724':
                edge = ch if side == 1 else cl
                if (hd == side and votes >= 3 and ch-cl <= 4*a
                        and vol >= 1.5*mean and (50 <= rs <= 75 if side == 1 else 25 <= rs <= 50)
                        and (cs[-2]-edge)*side <= 0 and .05*a < (c-edge)*side <= a):
                    level = edge
            elif variant == 'failed_retest724':
                if wick < .15 or (rs-rsi(cs[:-1],14))*side <= 0:
                    continue
                # Do not reverse because a trade lost money. Require a new completed
                # price break through the failed support/resistance of a prior setup.
                for age in range(1,5):
                    prior = previous(b[:-age], hourly)['setups']
                    prior = [v for v in prior if v['action'] != ('LONG' if side == 1 else 'SHORT')]
                    if not prior:
                        continue
                    edge = prior[0]['failure_level722']
                    if ((cs[-2]-edge)*side <= .1*a and .1*a < (c-edge)*side <= a
                            and all((r[4]-edge)*side <= .1*a for r in b[-age:-1])):
                        level = hi if side == -1 else lo
                        break
            elif variant == 'ema_reclaim724':
                e=ema(cs);old_e=ema(cs[:-1]);prev=b[-2]
                near=prev[3] if side==1 else prev[2]
                edge=prev[2] if side==1 else prev[3]
                if (slow_direction(h)==side and (e-ma[50])*side>0
                        and slopes[50]*side>0 and (50<=rs<=70 if side==1 else 30<=rs<=50)
                        and -.5*a<=(near-old_e)*side<=.25*a
                        and (prev[4]-prev[1])*side<0 and (c-edge)*side>0
                        and 0<(c-e)*side<=a):
                    level=min(lo,prev[3]) if side==1 else max(hi,prev[2])
            elif variant == 'vwap_reclaim724':
                session=[r for r in b if r[0]//86400000==last[0]//86400000]
                if len(session)<8 or sum(r[5] for r in session[:-1])<=0:continue
                def vw(rows):return sum((r[2]+r[3]+r[4])/3*r[5] for r in rows)/sum(r[5] for r in rows)
                vwap=vw(session);old_vwap=vw(session[:-1]);near=lo if side==1 else hi
                if (slow_direction(h)==side and slopes[50]*side>0
                        and (50<=rs<=70 if side==1 else 30<=rs<=50)
                        and (cs[-2]-old_vwap)*side<=0
                        and .05*a<(c-vwap)*side<=a and (near-vwap)*side>=-.75*a):
                    level=lo if side==1 else hi
            elif variant == 'failed_break724':
                edge=cl if side==1 else ch;near=lo if side==1 else hi
                if (er<=.6 and wick>=.35 and vol>=1.2*mean and abs(c-ma[50])<=3*a
                        and (oldrs<40 and rs>oldrs if side==1 else oldrs>60 and rs<oldrs)
                        and (near-edge)*side<-.15*a and .05*a<(c-edge)*side<=a):
                    level=lo if side==1 else hi
            elif variant == 'rsi_recovery724':
                short_rs=rsi(cs,2);prior_rs=rsi(cs[:-1],2)
                recovered=(prior_rs<10 and short_rs>20) if side==1 else (prior_rs>90 and short_rs<80)
                if (slow_direction(h)==side and slopes[50]*side>0
                        and recovered and (c-cs[-2])*side>0
                        and abs(c-ma[50])<=2*a):
                    level=min(lo,b[-2][3]) if side==1 else max(hi,b[-2][2])
            elif variant == 'double_turn724':
                # A pivot is known only after its two right-hand candles close.
                # Exclude the signal candle from pivot confirmation: both pivots
                # and the neckline must already exist before this fresh break.
                ix=3 if side==1 else 2
                pivots=[i for i in range(len(b)-n-1,len(b)-3)
                        if all((b[i][ix]-b[j][ix])*side<0
                               for j in (i-2,i-1,i+1,i+2))]
                if len(pivots)>=2 and vol>=1.2*mean:
                    i,j=pivots[-2:]
                    r1=rsi(cs[:i+1],14);r2=rsi(cs[:j+1],14)
                    edge=max(r[2] for r in b[i+1:j]) if side==1 else min(r[3] for r in b[i+1:j])
                    if (j-i>=3 and abs(b[j][ix]-b[i][ix])<=.5*a
                            and (r1<40 if side==1 else r1>60) and (r2-r1)*side>=5
                            and (edge-b[j][ix])*side>=.75*a
                            and (cs[-2]-edge)*side<=0 and 0<(c-edge)*side<=a):
                        level=min(b[i][3],b[j][3]) if side==1 else max(b[i][2],b[j][2])
            if level is None:
                continue
            stop = c-side*2*a
            if stop <= 0:
                continue
            candidates.append(dict(setup='channel20_10', policy_version=724, variant724=variant,
                action='LONG' if side == 1 else 'SHORT', priority=0, route721=variant,
                lookback721=n, ma_touched721=[], signal_ms=last[0], confirmation_ms=last[0],
                test_ms=last[0], structural_stop=stop, target=None, atr=a, reference=c,
                channel_high=ch, channel_low=cl, failure_level722=level,
                failure_kind722='V724 진입 구조 실패', hourly_direction=hd,
                hourly_efficiency724=er, progress_exit724=variant in ('ema_reclaim724','vwap_reclaim724','rsi_recovery724'),
                learning_key='rule724|'+variant+'|'+str(n)+'|'+str(side),
                confirmation721=dict(volume_ratio=vol/mean, rsi14=rs, ma=ma,
                    ma_slopes=slopes, ma_votes=votes, close_strength=strength, wick_fraction=wick)))
    if len({v['action'] for v in candidates}) > 1:
        return dict(setups=[], reason='방향 충돌 대기')
    return dict(setups=candidates, reason='완료봉 진입 확인' if candidates else '완료봉 패턴 확인 대기')


def setup(b, hourly=None, variant=None):
    values = analyze(b, hourly, variant)['setups']
    return max(values, key=lambda v: v['lookback721']) if values else None

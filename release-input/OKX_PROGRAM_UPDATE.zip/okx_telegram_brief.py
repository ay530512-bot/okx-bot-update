"""Local deterministic summaries; no extra model requests."""
import re
from decimal import Decimal,InvalidOperation

def short(text,limit=150):
 text=re.sub(r'\s+',' ',str(text)).strip()
 # Shorten decimal output without changing small coin price precision.
 def rounded(m):
  try:
   n=Decimal(m.group());return format(n.quantize(Decimal('.01')),'f') if abs(n)>=1 else m.group()
  except InvalidOperation:return m.group()
 text=re.sub(r'(?<![\w.])-?\d+\.\d{5,}(?= USDT)',rounded,text)
 if len(text)<=limit:return text
 sentences=re.split(r'(?<=[다요.!?])\s+',text)
 complete=[x for x in sentences if len(x)<=limit and x.endswith(('다.','요.','.','!','?'))]
 return complete[-1] if complete else reason_summary(text)

def reason_summary(text):
 """Choose explicit decision blockers, never infer new trade evidence."""
 text=re.sub(r'\s+',' ',str(text)).strip()
 if len(text)<=160:return text
 # Prefer an explicit short conclusion over the chronological candle narrative.
 sentences=re.split(r'(?<=[.!?])\s+(?!\d)',text)
 conclusions=[x for x in sentences if len(x)<=55 and any(k in x for k in ('따라서','때문','부족','미확인','보류','기다','추격','불리'))]
 if conclusions:return conclusions[-1]
 reasons=[]
 rules=[
  (r'(?:MA\d+|이평선).{0,35}(?:아래입니다|아래에|하회|이탈)', '이평선 아래로 밀려 회복 확인 대기'),
  (r'(?:저항.{0,35}(?:가까|근접|맞닿|추격)|추격.{0,20}(?:위치|위험|불리))', '저항에 가까워 추격 진입 보류'),
  (r'(?:거래량.{0,25}(?:부족|감소|줄었|약해)|거래.{0,15}비활성)', '거래량·매매 강도 확인 대기'),
  (r'(?:반전|회복|거절|지지).{0,18}(?:미확인|부족|확인되지|아직 없)', '반전·지지 확인 근거 부족'),
  (r'(?:수수료|비용).{0,35}(?:초과|부족|불리|잠식|작아|넘지)', '예상 수익 대비 거래 비용 불리'),
  (r'(?:호가|체결|데이터|자료).{0,20}(?:누락|지연|대기|미준비)', '최신 시장 자료 수신 대기'),
 ]
 for pattern,label in rules:
  if any(re.search(pattern,clause) and not re.search(r'(?:아닙|않습|없지 않)',clause) for clause in sentences) and label not in reasons:reasons.append(label)
 if reasons:return ' / '.join(reasons[:2])+'입니다.'
 # An honest fallback is preferable to cutting off a sentence or inventing why.
 # Preserve a complete actual conclusion even for unknown terminology.
 relevant=[x for x in sentences if any(k in x for k in ('따라서','때문','보류','기다','필요','위험','확인','부족','불리'))]
 return (relevant[-1] if relevant else sentences[-1])

def symbol_reason(text):
 match=re.search(r'([A-Z0-9]+)-USDT-SWAP',text)
 symbol=match.group(1)+'/USDT' if match else '종목 판단'
 reason=text.split(' / ',1)[-1]
 direction=' · 숏 후보' if '숏 후보' in reason else (' · 롱 후보' if '롱 후보' in reason else '')
 return symbol+direction+'\n사유: '+reason_summary(reason)

def brief(event,text):
 text=re.sub(r'^\[OKX[^\n]*?\]\s*[^\n]*\n','',str(text))
 category={'진입 체결':'진입','청산 손익':'청산','부분 청산 확인':'청산','진입 거절':'거절','AI 진입 대기':'진입 전 대기'}.get(event,'대기')
 lines=text.splitlines();head=lines[0] if lines else ''
 if event=='보호 오류':return '[거절]\n보호 주문 오류 · 확인 필요\n'+short(text,180)
 if event in ('AI 진입 대기','진입 거절'):return '['+category+']\n'+symbol_reason(text)
 if event=='실거래 시작':return '[진입 전 대기]\n자동매매 시작 · 계정·자료 확인 후 진입'
 if event=='AI 승인':return '[진입 전 대기]\n'+short(head,150)+'\nAI 진입 판단 · 주문 점검 중, 미체결'
 if event=='청산 손익':
  symbol=head.split(' / ')[0]
  reason=head.split(' / ',1)[1] if ' / ' in head else ''
  money=[short(x,110) for x in lines[1:] if any(k in x for k in ('실현손익','당일 손익','총자산'))]
  return '[청산]\n'+symbol+'\n사유: '+reason_summary(reason)+'\n'+'\n'.join(money)
 if event=='AI 보유 판단':
  # Retain actual action, one reason, ROE and current protection; label as judgment only.
  keep=[short(head,80)]
  if len(lines)>1:keep.append(reason_summary(lines[1]))
  keep += [short(x,95) for x in lines[2:] if x.startswith(('현재가','현재 보호 SL'))]
  return '[보유중]\n'+'\n'.join(keep)+'\n판단 알림 · 실행 확정 아님'
 return '['+category+']\n'+short(head,160)+ ('\n'+reason_summary(lines[1]) if len(lines)>1 else '')

def daily(text):
 keys=('시작 시드:','종료 관측 자산:','순입출금:','계정 손익:','AI 비용 추정:','AI 비용 차감 손익 추정:','수익률:','+6% 목표 수익:','+6% 목표 총액:','주의:','시작·종료 시드 기록 부족:','AI 비용 관측 추정:')
 lines=str(text).splitlines();date=re.search(r'\d{4}-\d{2}-\d{2}',str(text))
 out=['[대기]','일일 보고 · '+(date.group() if date else '날짜 미확인')+' KST']
 out.extend(short(x,170) for x in lines if x.startswith(keys))
 out.append('입출금은 손익 제외 · AI 비용은 추정')
 return '\n'.join(out)


def migrate_pending_label(item):
 """Relabel unsent old messages without altering body, ids or dedup state."""
 text=item.get('text','');event=item.get('event')
 if text.startswith('[대기]\n'):
  label='보유중' if event=='AI 보유 판단' else '진입 전 대기' if event in ('AI 진입 대기','AI 승인','실거래 시작') else None
  if label:item['text']='['+label+']'+text[len('[대기]'):]
 return item

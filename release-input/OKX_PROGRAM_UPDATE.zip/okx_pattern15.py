"""User specification 6.93: only three closed-15m setup families.
No cost/RR, RSI, extension or common candle-colour entry veto.
"""
import math,statistics,time,uuid,hashlib
from decimal import ROUND_DOWN,ROUND_UP
from okx_core import BotError,dec,fmt
STEPS={'15m':900000,'1H':3600000,'4H':14400000}
NAMES={'15m':'15분봉','1H':'1시간봉','4H':'4시간봉','5m':'5분봉'}
LABELS={'band_double':'볼밴 꼬리 쌍바닥·쌍고점','ma_retest':'50/100/120/200 이평 재시험','impulse_retest':'거래량 장대봉 내부 재시험'}
def enabled(c):return c.get('execution',{}).get('pattern15_only',False)
def leverage(symbol):return {"BTC":20,"ETH":15,"SOL":15}.get(symbol.split("-")[0].split("/")[0],10)  # New automatic entries only; existing owned leverage is persisted.
def allowed(i,c):
 from okx_band_flow import allowed as generic,stock
 return generic(i) and i.get('instCategory')=='1' and not stock(i,c)
def avg(b,n,end=None):
 a=b if end is None else b[:end+1]
 return sum(float(r[4]) for r in a[-n:])/n if len(a)>=n else None
def band(b,j):
 a=[float(r[4]) for r in b[j-19:j+1]]
 if len(a)!=20:return None
 m=sum(a)/20;s=statistics.pstdev(a);return m-2*s,m,m+2*s

def shape(r,side):
 o,h,l,c=map(float,r[1:5]);body=abs(c-o);span=h-l
 tail=min(o,c)-l if side==1 else h-max(o,c)
 return span>0 and tail>body and (c-l if side==1 else h-c)>span/2

def vol(b,j):
 a=b[max(0,j-20):j];m=sum(float(r[5]) for r in a)/len(a) if a else 0
 return float(b[j][5])/m if m>0 else None

def summary(b):
 if len(b)<21:return dict(trend='unknown',reason='완료봉 자료 부족')
 m={str(n):avg(b,n) for n in (15,20,50,100,120,200)};close=float(b[-1][4]);slope=(avg(b,20)-avg(b[:-1],20))
 trend='uptrend' if close>m['20'] and slope>0 else 'downtrend' if close<m['20'] and slope<0 else 'range'
 from okx_market import rsi
 return dict(trend=trend,ma=m,close=close,relative_volume=vol(b,len(b)-1),rsi14=rsi([float(r[4]) for r in b],14),completed_ms=b[-1][0],reason='확정봉 SMA20 위치·기울기 / RSI·거래량 보조')

def legacy_setups(b,atr,tick=0):
 out=[]
 if len(b)<24 or atr<=0:return out
 last=len(b)-1;pad=max(float(tick),atr*.05) # explicit small structural stop buffer
 for action,side,field in (('LONG',1,3),('SHORT',-1,2)):
  current=b[-1]
  # Second test may itself be red/green: recovery wick, not colour, controls.
  for j in (last,last-1):
   if not shape(b[j],side):continue
   second=float(b[j][field])
   for i in range(j-2,max(19,j-80),-1):
    bb=band(b,i);first=b[i];extreme=float(first[field]);vr=vol(b,i)
    if not bb or vr is None or vr<=1 or not shape(first,side):continue
    if (float(first[4])-float(first[1]))*side>=0:continue
    # User example explicitly permits a rolled-up bearish first candle for LONG.
    if side==1 and not (float(first[3])<bb[0] and float(first[4])>=bb[0]):continue
    if side==-1 and not (float(first[2])>bb[2] and float(first[4])<=bb[2]):continue
    if (second-extreme)*side<0:continue
    between=b[i+1:j]
    if not between:continue
    if side==1 and (max(float(r[2]) for r in between)<=second or any(float(r[3])<extreme for r in b[i+1:])):continue
    if side==-1 and (min(float(r[3]) for r in between)>=second or any(float(r[2])>extreme for r in b[i+1:])):continue
    target=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in between)
    out.append(dict(setup='band_double',priority=0,action=action,first_ms=first[0],first_extreme=extreme,retest_extreme=second,signal_ms=current[0],structural_stop=extreme-side*pad,target=target,relative_volume=vr,reference=b[j][4]));break
   if any(p['action']==action and p['setup']=='band_double' for p in out):break
  # Ordered MA stack; cross 200, then pullback into 120 with rejection/recovery.
  if len(b)>=204:
   m=[avg(b,n) for n in (50,100,120,200)]
   ordered=all((m[k]-m[k+1])*side>0 for k in range(3))
   crosses=[k for k in range(max(200,last-40),last) if (float(b[k-1][4])-avg(b,200,k-1))*side<=0 and (float(b[k][4])-avg(b,200,k))*side>0]
   zone=m[2]
   if ordered and crosses and shape(current,side) and float(current[3])<=zone<=float(current[2]) and (float(current[4])-zone)*side>0:
    extreme=float(current[field]);target=(max if side==1 else min)(float(r[2 if side==1 else 3]) for r in b[crosses[-1]:last])
    out.append(dict(setup='ma_retest',priority=1,action=action,signal_ms=current[0],structural_stop=extreme-side*pad,retest_extreme=extreme,target=target,zone=zone,reference=current[4]))
  # Large-body volume candle, subsequent internal pullback with retained extreme.
  if shape(current,side):
   for i in range(last-2,max(20,last-30),-1):
    impulse=b[i];vr=vol(b,i);baseline=b[i-20:i]
    mean_body=sum(abs(float(r[4])-float(r[1])) for r in baseline)/20
    if vr is None or vr<=1 or abs(float(impulse[4])-float(impulse[1]))<=mean_body:continue
    low,high=float(impulse[3]),float(impulse[2]);test=float(current[field])
    if not low<test<high:continue
    if side==1 and any(float(r[3])<low for r in b[i+1:]):continue
    if side==-1 and any(float(r[2])>high for r in b[i+1:]):continue
    # Observable opposite leg after impulse, then current wick recovery/rejection.
    after=b[i+1:]
    if not any((float(r[4])-float(impulse[4]))*side<0 for r in after[:-1]):continue
    extreme=low if side==1 else high
    out.append(dict(setup='impulse_retest',priority=2,action=action,signal_ms=current[0],impulse_ms=impulse[0],structural_stop=extreme-side*pad,retest_extreme=test,target=high if side==1 else low,relative_volume=vr,reference=current[4]));break
 return sorted(out,key=lambda p:p['priority'])

def setups(b,atr,tick=0,c=None):
 from okx_structure694 import setups as selected
 return selected(b,atr,tick,c)

def major_direction(frames,action):
 side=1 if action=='LONG' else -1
 for f in STEPS:
  m=frames.get(f,{}).get('analysis',{}).get('ma',{})
  if not all(m.get(str(n)) is not None for n in (50,100,120,200)):return False
  if not all((m[str(a)]-m[str(b)])*side>0 for a,b in ((50,100),(100,120),(120,200))):return False
  if frames[f]['analysis'].get('trend')!=('uptrend' if side==1 else 'downtrend'):return False
 return True

def packet(row,c,now,quote=None,swing_frame=None):
 from okx_channel701 import enabled,packet as rules_packet
 if enabled(c):return rules_packet(row,c,now,quote,swing_frame)
 from okx_band_flow import view
 frames={}
 for f,step in STEPS.items():
  b=[r for r in row.get('live_frames',{}).get(f,[]) if r[0]+step<=now]
  if len(b)<24 or now-b[-1][0]-step>=step:raise BotError(f+' 최신 확정봉 대기')
  if any(b[j][0]-b[j-1][0]!=step for j in range(max(1,len(b)-25),len(b))):raise BotError(f+' 봉 연속성 확인 대기')
  metrics=view(b,c);frames[f]=dict(analysis=summary(b),ma=metrics['ma'],bollinger={k:metrics[k] for k in ('mid','upper','lower')},atr=metrics['atr'],recent=b[-24:],completed_ms=b[-1][0]+step,relative_volume=vol(b,len(b)-1))
  if f=='15m':frames[f]['entry_setups']=setups(b,metrics['atr'],float(row.get('instrument',{}).get('tickSz') or 0),c)
  if f=='15m':
   from okx_flexible697 import diagnose
   frames[f]['entry_diagnostic']=diagnose(b,metrics['atr'],c)
 from okx_structure694 import select_regime
 closed_row=dict(row,live_frames={f:[r for r in row.get('live_frames',{}).get(f,[]) if r[0]+step<=now] for f,step in STEPS.items()})
 routed=select_regime(dict(entry_setups=frames['15m']['entry_setups']),closed_row)
 candidates=routed['entry_setups'];symbol=row['symbol']
 if symbol.split('-')[0] in ('BTC','ETH','SOL'):candidates[:]=[p for p in candidates if major_direction(frames,p['action'])]
 price=float((quote or {}).get('last') or frames['15m']['recent'][-1][4])
 return dict(symbol=symbol,price=price,asset_category=row.get('instrument',{}).get('instCategory','1'),required_leverage=leverage(symbol),frames=frames,market_regime=routed['market_regime'],entry_setups=candidates,selection='15분봉 세 경로만 · 쌍바닥/쌍고점 우선 · 등락폭 우선',policy='RSI/1H/4H/volume context; no cost/RR/common extension gate')

def proof(p,action):
 for v in p.get('entry_setups',[]):
  if v['action']==action:return v
 raise BotError('15분봉 새 세 경로 중 해당 방향 확인 없음')

def make_signal(out,p,c,now):
 from okx_channel701 import enabled,make_signal as rules_signal
 if enabled(c):return rules_signal(out,p,c,now)
 v=proof(p,out['action']);side=1 if out['action']=='LONG' else -1;price=p['price'];stop=v['structural_stop'];target=v['target']
 if stop<=0 or (price-stop)*side<=0:raise BotError('현재가가 구조 손절을 이미 이탈')
 from okx_structure694 import entry_window
 if not entry_window(v,price):raise BotError('확인 진입 구간 이탈 · 추격 금지·재시험 대기')
 return dict(symbol=p['symbol'],action=out['action'],leverage=leverage(p['symbol']),strategy='band_flow',pattern=v['setup'],free_ai=True,pattern15=True,stop=stop,target=target,margin_fraction=1/3,signal_id='p694-'+hashlib.sha256((p['symbol']+'|'+out['action']+'|'+v['setup']+'|'+str(v['confirmation_ms'])+'|'+str(v.get('first_ms') or v.get('impulse_ms') or v.get('cross_ms'))).encode()).hexdigest()[:24],atr=p['frames']['15m']['atr'],level=stop,reason=out['reason'][:300],regime='15분봉 패턴·추세',ma=p['frames']['15m']['ma'],bb=p['frames']['15m']['bollinger'],rsi={f:p['frames'][f]['analysis']['rsi14'] for f in STEPS},retest=True,adaptive=True,setup_frame='15m',execution_frame='15m',at_ms=now,valid_from_ms=now,expires_ms=now+90000,entry_reference=price,entry_gap=price,selection=dict(activity={},asset_category=p['asset_category']),holding_rule=dict(band_flow=True,free_ai=True,pattern15=True,frame='15m',zone=stop,target=target,target_mode='review'),decision_record=dict(source='STRUCTURE694',frames=p['frames'],volume_wick_proof=v))

def fresh(e,symbol):
 from okx_band_flow import rows
 return {f:rows(e.api.public('/api/v5/market/candles',instId=symbol,bar=f,limit='300'),f,e.api.now_ms()) for f in STEPS}

def check_entry(e,s,price):
 if s.get('click716'):
  from okx_click716 import check
  return check(e,s,price)
 from okx_channel701 import enabled,check_entry as rules_check
 if enabled(e.cfg):return rules_check(e,s,price)
 row=dict(symbol=s['symbol'],instrument={'instCategory':'1'},live_frames=fresh(e,s['symbol']))
 p=packet(row,e.cfg,e.api.now_ms(),{'last':price});v=proof(p,s['action'])
 if v['setup']!=s['pattern']:raise BotError('주문 전 15분봉 패턴 변경 · 재검토')
 original=s.get('decision_record',{}).get('volume_wick_proof',{})
 for key in ('first_ms','impulse_ms','test_ms','confirmation_ms'):
  if key in original and v.get(key)!=original[key]:raise BotError('주문 전 원래 패턴 기준봉 변경 · 재검토')
 from okx_structure694 import entry_window
 if not entry_window(original or v,float(price)):raise BotError('주문 직전 확인 진입 구간 이탈 · 추격 금지')
 side=1 if s['action']=='LONG' else -1
 if (float(price)-float(s['stop']))*side<=0:raise BotError('주문 전 구조 손절 이탈')
 e.events.put(('timeframes',dict(symbol=s['symbol'],frames={f:p['frames'][f]['analysis'] for f in STEPS})))
 return p

from okx_structure694 import INSTRUCTIONS

def book(book,instrument,quantity,direction,now,c):
 if not -500<=now-int(book['ts'])<=c['liquidity']['max_book_age_ms']:raise BotError('주문 호가 자료 지연')
 ct=dec(instrument['ctVal']);q=dec(quantity)
 if min(ct,q)<=0:raise BotError('계약 수량 오류')
 for name in ('bids','asks'):
  a=[(dec(r[0]),dec(r[1])) for r in book[name]]
  if not a or any(p<=0 or n<0 for p,n in a) or a!=sorted(a,reverse=name=='bids'):raise BotError('주문 호가 자료 오류')
 bid=dec(book['bids'][0][0]);ask=dec(book['asks'][0][0])
 if ask<bid:raise BotError('호가 역전')
 left=q;total=dec(0);worst=None
 for r in book['asks' if direction=='long' else 'bids']:
  used=min(left,dec(r[1]));left-=used;total+=used*ct*dec(r[0])
  if used:worst=dec(r[0])
  if left==0:break
 if left>0:raise BotError('주문 수량 체결 가능 호가 부족')
 touch=ask if direction=='long' else bid
 return dict(limit_px=fmt(worst),spread=float((ask-bid)/((ask+bid)/2)),slippage=float(abs(total/(q*ct)/touch-1)),notional=fmt(q*ct*worst),mid=fmt((ask+bid)/2),bid_depth_usdt=fmt(sum(dec(r[0])*dec(r[1])*ct for r in book['bids'])),ask_depth_usdt=fmt(sum(dec(r[0])*dec(r[1])*ct for r in book['asks'])))

def risk(plan,i,s,direction,equity,available,fee,funding,c,*unused):
 side=1 if direction=='long' else -1;price=dec(plan['buy' if side==1 else 'sell']);tick=dec(i['tickSz']);q=dec(plan['quantity']);ct=dec(i['ctVal']);lev=dec(s.get('leverage') or c['risk']['leverage'])
 stop=(dec(s['stop'])/tick).to_integral_value(rounding=ROUND_DOWN if side==1 else ROUND_UP)*tick
 if stop<=0 or (price-stop)*side<=0:raise BotError('구조 손절가 현재가 이탈')
 margin=q*ct*price/lev
 if margin+q*ct*price*abs(dec(fee))>dec(available):raise BotError('실제 증거금/수수료 잔고 부족')
 result=dict(plan,margin_bound=fmt(margin),estimated_loss=fmt(q*ct*(abs(price-stop)+price*2*abs(dec(fee)))),cost_rate=fmt(2*abs(dec(fee))),reward_risk=None)
 result[direction+'_stop']=fmt(stop);return result

def prepare_plan(e,plan,i,ticker,frames,direction,snapshot,fee):
 from okx_risk732 import enabled as risk_enabled,prepare_plan as risk_prepare
 if risk_enabled(e.cfg):return risk_prepare(e,plan,i,ticker,frames,direction,snapshot,fee)
 from okx_channel4h730 import is_signal,prepare_plan as four_prepare
 if is_signal(frames['_v4']):return four_prepare(e,plan,i,ticker,frames,direction,snapshot,fee)
 from okx_execution_status import check_permissions
 check_permissions(snapshot['config']);e.risk_snapshot(snapshot)
 if not frames['_v4'].get('click716') and not e.stream.ready(i['instId'],e.cfg,e.api.now_ms()):raise BotError('실시간 시세 준비 대기')
 s=frames['_v4'];plan=dict(plan)
 if not allowed(i,e.cfg) or int(s['leverage'])!=(5 if s.get('click716') else leverage(i['instId'])) or dec(i.get('lever') or 0)<dec(s['leverage']):raise BotError('코인 선물/종목별 배율 조건 불일치')
 from okx_structure694 import cap_quantity,params,total_risk,entry_window
 plan['buy' if direction=='long' else 'sell']=ticker['askPx' if direction=='long' else 'bidPx']
 plan=cap_quantity(plan,i,s,direction,e.allocation_seed(snapshot),snapshot['available'],fee,e.cfg)
 raw=e.api.public('/api/v5/market/books',instId=i['instId'],sz='400')[0]
 check=book(raw,i,plan['quantity'],direction,e.api.now_ms(),e.cfg)
 plan['buy' if direction=='long' else 'sell']=check['limit_px']
 original=s['decision_record']['volume_wick_proof']
 if not entry_window(original,float(check['limit_px'])):raise BotError('실행 호가가 확인 진입 구간 밖 · 추격 금지')
 plan=cap_quantity(plan,i,s,direction,e.allocation_seed(snapshot),snapshot['available'],fee,e.cfg)
 check=book(raw,i,plan['quantity'],direction,e.api.now_ms(),e.cfg)
 plan['buy' if direction=='long' else 'sell']=check['limit_px']
 plan=risk(plan,i,s,direction,e.allocation_seed(snapshot),snapshot['available'],fee,0,e.cfg)
 plan.update(_liquidity=check,_ct=i['ctVal'],_fee=fmt(fee),_funding='0',_allocation_seed=fmt(e.allocation_seed(snapshot)),_account_equity=fmt(snapshot['equity']),_initial_risk_budget=plan['estimated_loss'],_selection=e.selection_row(i['instId']))
 return plan

def submit_check(e,plan,i,direction):
 from okx_risk732 import enabled as risk_enabled,submit_check as risk_submit
 if risk_enabled(e.cfg):return risk_submit(e,plan,i,direction)
 from okx_channel4h730 import is_signal,submit_check as four_submit
 if is_signal(e.prepared_signal):return four_submit(e,plan,i,direction)
 snapshot=e.snapshot();e.risk_snapshot(snapshot)
 if i['instId'] in e.blocked_manual_symbols():raise BotError('수동 동일 종목 진입 금지')
 if not e.prepared_signal.get('click716') and not e.stream.ready(i['instId'],e.cfg,e.api.now_ms()):raise BotError('주문 직전 시세 지연')
 check=book(e.api.public('/api/v5/market/books',instId=i['instId'],sz='400')[0],i,plan['quantity'],direction,e.api.now_ms(),e.cfg)
 price=check['limit_px'];s=e.prepared_signal
 check_entry(e,s,float(price)) # re-evaluate actual latest15m/1H/4H, not cached AI candles
 if dec(plan['margin_bound'])>e.margin_room(snapshot):raise BotError('주문 직전 증거금 부족')
 plan['buy' if direction=='long' else 'sell']=price
 updated=risk(plan,i,s,direction,e.allocation_seed(snapshot),snapshot['available'],plan['_fee'],0,e.cfg)
 from okx_structure694 import params,total_risk,cap_quantity
 capped=cap_quantity(plan,i,s,direction,e.allocation_seed(snapshot),snapshot['available'],plan['_fee'],e.cfg)
 target=dec(capped['initial_margin_target']);margin=dec(updated['margin_bound'])
 tolerance=max(dec(i['lotSz'])*dec(i['ctVal'])*dec(price)/dec(s['leverage']),target*dec(e.cfg['risk'].get('fixed_initial_max_rounding_fraction',.03)))
 if abs(margin-target)>tolerance:raise BotError('주문 직전 시드 1/4 증거금 변경 · 재산정 대기')
 if margin>e.margin_room(snapshot):raise BotError('주문 직전 전체 증거금 한도 부족')
 plan.update(updated);plan['_liquidity']=check


def legacy_management(e,snap,p,o):
 """Local structural close/half/rejection/runner checks, independent of paid cadence."""
 now=e.api.now_ms()
 if now-o.get('pattern15_check_ms',0)<10000:return False
 o['pattern15_check_ms']=now
 bars=e.chart_job(o['symbol']) or {}
 if not bars.get('15m'):return False
 side=1 if o['direction']=='long' else -1;price=float(p['markPx']);entry=float(p['avgPx']);stop=float(o['stop_px'])
 b=[r for r in bars['15m'] if r[0]+900000<=now]
 if len(b)<22:return False
 last=b[-1];prior=b[-21:-1]
 # Prefer original entry pattern's observed previous extreme before live rolling levels.
 original=o.get('v4_signal',{}).get('decision_record',{}).get('volume_wick_proof',{})
 target=float(o.get('holding_rule',{}).get('target') or original.get('target') or ((max if side==1 else min)(float(r[2 if side==1 else 3]) for r in prior)))
 e.events.put(('timeframes',dict(symbol=o['symbol'],frames={f:summary([r for r in bars.get(f,[]) if r[0]+step<=now]) for f,step in STEPS.items()})))
 if (price-stop)*side<=0:e.close(snap,'15분봉 구조 손절 이탈');return True
 # Immediate observed level test and directional rejection; not merely touching it.
 bucket=now//900000*900000;tracking=o.get('pattern15_live')
 if not tracking or tracking['ms']!=bucket:tracking=dict(ms=bucket,open=price,high=price,low=price)
 tracking['high']=max(tracking['high'],price);tracking['low']=min(tracking['low'],price);o['pattern15_live']=tracking
 edge=tracking['high'] if side==1 else tracking['low']
 tested=(edge-target)*side>=0
 rejected=(price-target)*side<0 and (edge-price)*side>abs(price-tracking['open'])
 # A completed post-entry bar may also establish rejection, never a pre-entry bar.
 if int(last[0])>=int(o.get('entry_ms',now)):
  tested=tested or (float(last[2 if side==1 else 3])-target)*side>=0
  rejected=rejected or ((float(last[4])-target)*side<0 and shape(last,-side))
 e.journal.save()
 if tested and rejected:e.close(snap,'직전 고점 돌파 실패·거절 청산' if side==1 else '직전 저점 이탈 실패·회복 청산');return True
 roe=float(p.get('uplRatio') or 0)
 if roe>=.10 and not o.get('partial_used') and (price-target)*side>=0:
  e.partial_close(snap,'ROE 10% 이상·직전 극점 확인 절반 청산',fraction=.5);return True
 if o.get('partial_used'):
  if (float(last[4])-target)*side>0:
   proposed=target
   if (proposed-stop)*side>0 and (price-proposed)*side>0:
    e.trail(snap,p,o,proposed);return True
  # Subsequent confirmed swing trail only in favorable direction.
  for j in range(len(b)-2,max(1,len(b)-12),-1):
   field=3 if side==1 else 2;v=float(b[j][field])
   if (v-float(b[j-1][field]))*side<=0 and (v-float(b[j+1][field]))*side<=0:
    if (v-stop)*side>0 and (price-v)*side>0:e.trail(snap,p,o,v);return True
 return False

def management(e,snap,p,o):
 from okx_channel701 import enabled,management as rules_manage
 if enabled(e.cfg):return rules_manage(e,snap,p,o)
 from okx_structure694 import management as selected
 return selected(e,snap,p,o)

def configure(c):
 c['version']='7.00-structure-profit-protection';c['execution']['pattern15_only']=True
 c['execution']['free_ai'].update(enabled=True,entry_seconds=300,manage_seconds=300,min_active_bar_fraction=0)
 c['indicators']['frames']=['15m','1H','4H']
 c['risk'].update(daily_loss_enabled=False,final_roe_enabled=False,partial_fraction=.5,profit_review_roe=.10)
 for key in ('max_spread','depth_multiple','max_slippage'):c['liquidity'].pop(key,None)
 c['risk'].pop('min_reward_risk',None)
 from okx_structure694 import DEFAULTS
 c['execution']['structure694']=dict(DEFAULTS,**c['execution'].get('structure694',{}))
 c['risk'].update(initial_size_mode='fixed_third',initial_margin_fraction=1/3)
 c['risk'].update(leverage=10,leverage_mode='fixed',min_leverage=10,max_leverage=10)
 for key,val in c['signals'].items():
  if isinstance(val,dict) and 'enabled' in val and key!='band_flow':val['enabled']=False
 # band_flow is transport compatibility only; free_ai selects only pattern15.
 c['signals']['band_flow']['enabled']=True
 from okx_channel701 import configure as rules_configure
 return rules_configure(c)

def validate_config(c):
 from okx_channel701 import enabled,validate
 if enabled(c):return validate(c)
 from okx_structure694 import params
 k=params(c)
 if not 0<k['risk_fraction']<=.01 or not k['risk_fraction']<=k['max_total_risk_fraction']<=.02:raise BotError('구조 위험 예산 오류')
 if not 0<k['wick_fraction']<1 or not 0<k['volume_percentile']<=1 or not 0<k['fill_reserve_fraction']<.5 or not 2<=k['min_separation']<k['max_separation']<=80:raise BotError('구조 파라미터 범위 오류')
 if any(not math.isfinite(float(v)) or float(v)<=0 for v in k.values()):raise BotError('구조 파라미터 수치 오류')
 if c['indicators']['frames']!=list(STEPS):raise BotError('15분/1시간/4시간 설정 필요')
 if not c['execution']['free_ai']['enabled'] or c['risk']['max_positions']!=2:raise BotError('신규 3패턴 운용 설정 오류')
 if c['risk']['daily_loss_enabled'] or c['risk']['final_roe_enabled']:raise BotError('퍼센트 손실 강제 종료 해제 필요')
 if any(k in c['liquidity'] for k in ('max_spread','depth_multiple','max_slippage')) or 'min_reward_risk' in c['risk']:raise BotError('구형 비용/손익비 차단 설정 잔존')

"""Dedicated minute-scalp exits. Returns actions; existing order machine executes them."""
from okx_rules import metrics,protective_target


def is_fast(owned):return bool((owned.get('holding_rule') or {}).get('fast_scalp'))


def realtime_reason(position,owned,c,now):
    if not is_fast(owned):return None
    rule=owned['holding_rule'];side=1 if owned['direction']=='long' else -1
    target=rule.get('target');mark=float(position['markPx'])
    if target is not None and (mark-float(target))*side>=0:return '스캘핑 목표가 도달: 전량 정리'
    if now-owned.get('entry_ms',now)>=rule['max_hold_seconds']*1000:
        return '스캘핑 최대 보유 시간 도달: 전량 정리'
    return None


def manage(frames,position,owned,c,now):
    p=c['signals']['fast_entries'];side=1 if owned['direction']=='long' else -1
    b=[r for r in frames.get('1m',[]) if r[0]+60000<=now]
    need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1
    if len(b)<need+1:return 'HOLD','스캘핑: 최신1분봉 대기·거래소 보호 손절 유지',None
    prev,last=b[-2:]
    if last[0]+60000<now-60000:return 'HOLD','스캘핑: 차트 지연·보호 손절/시간 제한 유지',None
    if prev[0]+60000<=owned.get('entry_ms',0):return 'HOLD','스캘핑: 진입 이후 반응 확인 중',None
    m=metrics(b[:-1],c);atr=m['atr'];ma5=sum(r[4] for r in b[:-2][-5:])/5
    adverse=(prev[4]-ma5)*side<0 and (last[4]-ma5)*side<0
    opposite=(last[4]-prev[4])*side<-atr*p['confirmation_atr'] and (last[4]-last[1])*side<0
    if adverse and opposite:return 'CLOSE','스캘핑 단기MA5 2봉 이탈·반대 가격 진행: 전량 정리',None
    entry=float(position['avgPx']);stop=float(owned.get('invalidation_px',owned['stop_px']));risk=abs(entry-stop)
    after=[r for r in b if r[0]>=owned.get('entry_ms',now)]
    if risk>0 and len(after)>=p['scalp_stagnation_bars']:
        progress=max((r[4]-entry)*side for r in after)
        if progress<risk*p['scalp_min_progress_r']:
            return 'CLOSE',f"스캘핑 진입 후{p['scalp_stagnation_bars']}봉 이상 진행 부족: 전량 정리",None
    if risk>0 and (float(position['markPx'])-entry)*side>=risk*p['scalp_breakeven_r']:
        # The shared cost-aware protection function includes entry/exit fees, funding and slippage reserves.
        surrogate=dict(owned,profit_review_armed=True)
        target=protective_target(b,frames.get('5m',b),position,surrogate,c)
        if target is not None:return 'TRAIL','스캘핑 유리한 진행: 비용 반영 보호 손절 상향/하향',target
    return 'HOLD','스캘핑 목표·MA5 반전·진행 부족·최대 시간 감시',None

"""Local window/pane persistence; no trading or network operations."""
import json
import math
import re
from pathlib import Path


def load_layout(path):
    defaults=dict(maximized=True,geometry='',right=.34,chart=.56)
    try:
        data=json.loads(Path(path).read_text(encoding='utf-8'))
        if not isinstance(data,dict):return defaults
        if isinstance(data.get('maximized'),bool):defaults['maximized']=data['maximized']
        geometry=data.get('geometry','')
        if isinstance(geometry,str) and re.fullmatch(r'\d+x\d+[+-]\d+[+-]\d+',geometry):defaults['geometry']=geometry
        for key,low,high in [('right',.15,.5),('chart',.25,.8)]:
            value=data.get(key)
            if isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value):defaults[key]=max(low,min(high,value))
    except (OSError,ValueError,TypeError):pass
    return defaults


def write_layout(path,data):
    path=Path(path);temporary=path.with_suffix('.tmp')
    try:
        temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        temporary.replace(path)
    except OSError:pass


class LayoutController:
    def __init__(self,root,horizontal,vertical,path):
        self.root=root;self.horizontal=horizontal;self.vertical=vertical;self.path=path
        self.data=load_layout(path);self.ready=False;self.closed=False;self.jobs={};self.last=None;self.stable=0
        sw=root.winfo_screenwidth();sh=root.winfo_screenheight()
        width=min(1840,sw-20);height=min(1040,sh-80);x=y=0
        match=re.fullmatch(r'(\d+)x(\d+)([+-]\d+)([+-]\d+)',self.data['geometry'])
        if match:width,height,x,y=map(int,match.groups())
        width=max(min(1040,sw),min(width,sw));height=max(min(640,sh),min(height,sh-40))
        x=max(0,min(x,sw-width));y=max(0,min(y,sh-height-30))
        self.data['geometry']=f'{width}x{height}+{x}+{y}'
        root.geometry(self.data['geometry'])
        self.binding=root.bind('<Configure>',self.configure,add='+')
        horizontal.bind('<ButtonRelease-1>',self.capture_panes,add='+')
        vertical.bind('<ButtonRelease-1>',self.capture_panes,add='+')
        self.later('start',0,self.start)
    def later(self,key,ms,callback):
        if self.closed:return
        if key in self.jobs:
            self.root.after_cancel(self.jobs.pop(key))
        def run():
            self.jobs.pop(key,None)
            if not self.closed:callback()
        self.jobs[key]=self.root.after(ms,run)
    def start(self):
        if not self.root.winfo_ismapped():self.later('start',100,self.start);return
        if self.data['maximized']:
            try:self.root.state('zoomed')
            except Exception:
                try:self.root.attributes('-zoomed',True)
                except Exception:pass
        self.later('settle',100,self.settle)
    def settle(self):
        dimensions=(self.horizontal.winfo_width(),self.vertical.winfo_height())
        if min(dimensions)<100:self.later('settle',100,self.settle);return
        self.stable=self.stable+1 if dimensions==self.last else 0;self.last=dimensions
        self.apply()
        if self.stable<3:self.later('settle',100,self.settle);return
        self.ready=True
    def apply(self):
        width=self.horizontal.winfo_width();height=self.vertical.winfo_height()
        right=max(360,min(width-300,int(width*self.data['right'])))
        self.horizontal.sash_place(0,width-right,0)
        self.vertical.sash_place(0,0,max(240,min(height-300,int(height*self.data['chart']))))
    def configure(self,event):
        if event.widget is not self.root or not self.ready:return
        if self.root.state() in ('iconic','withdrawn'):return
        self.later('resize',150,self.apply)
        self.later('save',500,self.save)
    def capture_panes(self,event=None):
        if not self.ready:return
        # Cancel a pending root resize so it cannot undo a user's sash drag.
        if 'resize' in self.jobs:self.root.after_cancel(self.jobs.pop('resize'))
        width=self.horizontal.winfo_width();height=self.vertical.winfo_height()
        self.data['right']=(width-self.horizontal.sash_coord(0)[0])/width
        self.data['chart']=self.vertical.sash_coord(0)[1]/height
        self.save()
    def save(self):
        if not self.ready:return
        state=self.root.state()
        if state in ('iconic','withdrawn'):return
        self.data['maximized']=state=='zoomed'
        if state=='normal':self.data['geometry']=self.root.geometry()
        write_layout(self.path,self.data)
    def close(self):
        self.save();self.closed=True
        for job in self.jobs.values():self.root.after_cancel(job)
        self.jobs.clear();self.root.unbind('<Configure>',self.binding)

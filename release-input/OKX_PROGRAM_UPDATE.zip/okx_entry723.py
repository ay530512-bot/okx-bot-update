"""V723 research candidates. All information must be closed before the order.
Thresholds are fixed hypotheses, not fitted profit guarantees.
"""
from math import isfinite, sqrt
from okx_band_flow import atr
from okx_market import rsi
from okx_entry721 import PERIODS, LOOKBACKS
from okx_entry722 import direction, hourly_from_15m

def analyze(b,hourly=None,variant='pullback_v723',relaxed=False):
    volatility_policy=variant=='pullback_v723'
    if volatility_policy:variant='pullback723'
    if len(b)<241:return dict(setups=[],reason='완료15분봉241개 대기')
    if any(len(r)<6 or not all(isfinite(float(x)) for x in r[:6]) or min(r[1:5])<=0 or r[5]<0 or not r[3]<=min(r[1],r[4])<=max(r[1],r[4])<=r[2] for r in b):
        return dict(setups=[],reason='봉 데이터 오류')
    if any(y[0]-x[0]!=900000 for x,y in zip(b,b[1:])):return dict(setups=[],reason='15분봉 누락')
    end=b[-1][0]+900000;h=hourly_from_15m(b) if hourly is None else [r for r in hourly if r[0]+3600000<=end]
    if len(h)<25 or h[-1][0]+3600000!=end//3600000*3600000 or any(y[0]-x[0]!=3600000 for x,y in zip(h[-25:],h[-24:])):
        return dict(setups=[],reason='최신 연속 완료1시간봉 대기')
    last=b[-1];op,hi,lo,c,vol=map(float,last[1:6]);a=atr(b[:-1]);span=hi-lo
    if a<=0 or span<=0:return dict(setups=[],reason='ATR/가격 범위 오류')
    if volatility_policy and a/c<.004:return dict(setups=[],reason='변동폭 대비 비용 비중 큼 · ATR 0.4% 이상 대기')
    cs=[float(r[4]) for r in b];rs=rsi(cs,14);oldrs=rsi(cs[:-1],14)
    ma={n:sum(cs[-n:])/n for n in PERIODS};slope={n:ma[n]-sum(cs[-n-1:-1])/n for n in PERIODS}
    hd=direction(h);candidates=[]
    for side in (1,-1):
        strength=(c-lo if side==1 else hi-c)/span
        wick=(min(op,c)-lo if side==1 else hi-max(op,c))/span
        votes=sum((c-ma[n])*side>0 and slope[n]*side>0 for n in PERIODS)
        if (c-op)*side<=0 or strength<(.55 if relaxed else .6) or span>2.5*a:continue
        if variant!='range723' and (hd!=side or votes<3 or not (45<=rs<=70 if side==1 else 30<=rs<=55)):continue
        for n in LOOKBACKS:
            p=b[-n-1:-1];ch=max(r[2] for r in p);cl=min(r[3] for r in p);mean=sum(r[5] for r in p)/n
            if mean<=0 or vol<mean*(.9 if relaxed else 1.):continue
            level=None;test_ms=None;touched=[]
            if variant=='retest723':
                # A prior close broke a pre-existing channel. Wait 1..6 bars for a retest.
                # No future extrema and no repeated rolling high counted as a new event.
                for age in range(1,7):
                    j=len(b)-1-age;prev=b[j-n:j];edge=max(r[2] for r in prev) if side==1 else min(r[3] for r in prev)
                    bc=b[j][4];ba=atr(b[:j])
                    if ba<=0 or not .1*ba<(bc-edge)*side<=ba:continue
                    if (b[j-1][4]-edge)*side>0:continue
                    if any((r[4]-edge)*side<-.5*ba for r in b[j+1:-1]):continue
                    near=lo if side==1 else hi
                    if -.35*a<=(near-edge)*side<=.35*a and .05*a<(c-edge)*side<=a:
                        level=edge;test_ms=b[j][0];break
            elif variant=='pullback723':
                if abs(c-ma[50])>2*a or wick<(.20 if relaxed else .25):continue
                for period in PERIODS:
                    m=ma[period];near=lo if side==1 else hi
                    if slope[period]*side<=0 or not (-.6 if relaxed else -.5)*a<=(near-m)*side<=(.35 if relaxed else .25)*a or (c-m)*side<=0:continue
                    if sum((r[4]-m)*side>0 for r in b[-5:-2])<2:continue
                    if (b[-2][4]-b[-3][4])*side>=0:continue
                    if (c-b[-2][4])*side<=0:continue
                    touched.append(period)
                if touched:level=lo if side==1 else hi;test_ms=last[0]
            elif variant=='range723':
                mid=sum(cs[-21:-1])/20;sd=sqrt(sum((x-mid)**2 for x in cs[-21:-1])/20)
                upper=mid+2*sd;lower=mid-2*sd
                old50=sum(cs[-55:-5])/50
                if abs(ma[50]-old50)>.5*a or hd!=0:continue
                if wick<.3 or not (rs>oldrs and oldrs<40 if side==1 else rs<oldrs and oldrs>60):continue
                edge=cl if side==1 else ch
                if (lo<min(edge,lower) and c>lower) if side==1 else (hi>max(edge,upper) and c<upper):
                    level=lo if side==1 else hi;test_ms=last[0]
            else:raise ValueError('Unknown research variant: '+variant)
            if level is None:continue
            stop=c-side*2*a
            if stop<=0:continue
            route={'retest723':'breakout_retest','pullback723':'trend_pullback','range723':'range_reclaim'}[variant]
            candidates.append(dict(setup='channel20_10',policy_version=723,volatility_cost723=volatility_policy,action='LONG' if side==1 else 'SHORT',priority=0,
                route721=route,lookback721=n,ma_touched721=touched,confirmation_ms=last[0],signal_ms=last[0],test_ms=test_ms,
                structural_stop=stop,target=None,atr=a,reference=c,channel_high=ch,channel_low=cl,
                failure_level722=level,failure_kind722='진입 지지·저항 재확인 실패',hourly_direction=hd,
                learning_key='rule723|'+route+'|'+str(n)+'|'+str(side),
                confirmation721=dict(volume_ratio=vol/mean,rsi14=rs,ma=ma,ma_slopes=slope,ma_votes=votes,close_strength=strength,wick_fraction=wick)))
    if len({x['action'] for x in candidates})>1:return dict(setups=[],reason='방향 충돌 대기')
    return dict(setups=candidates,reason='재확인 신호' if candidates else '완료봉 지지·저항/거래량/RSI/이평 재확인 대기')

def setup(b,hourly=None,variant='pullback_v723'):
    values=analyze(b,hourly,variant)['setups']
    return max(values,key=lambda x:x['lookback721']) if values else None

"""Read-only, causal decision context. No signals, orders, or new API requests."""
import math

def number(value):
 try:
  n=float(value);return n if math.isfinite(n) else None
 except (TypeError,ValueError):return None

def location(price,frames):
 price=number(price);out={}
 if price is None or price<=0:return out
 for frame,data in frames.items():
  atr=number(data.get('atr'));recent=data.get('recent',[])
  if atr is None or atr<=0 or not recent:continue
  last=recent[-1];evidence=data.get('chart_evidence',{});averages=[]
  for period,value in data.get('ma',{}).items():
   v=number(value)
   if v is not None and v>0:averages.append(dict(period=str(period),price=v,signed_distance_atr=(price-v)/atr))
  averages.sort(key=lambda item:abs(item['signed_distance_atr']))
  support=number(evidence.get('prior_support'));resistance=number(evidence.get('prior_resistance'))
  lo=min(r[3] for r in recent);hi=max(r[2] for r in recent)
  out[frame]=dict(completed_ms=data.get('completed_ms'),price_vs_last_closed_atr=(price-last[4])/atr,nearest_averages=averages[:3],recent_low=lo,recent_high=hi,above_recent_low_atr=(price-lo)/atr,below_recent_high_atr=(hi-price)/atr,prior_support=support,prior_resistance=resistance,position_in_recent_range=(price-lo)/(hi-lo) if hi>lo else None,
   note='Distances use live quote versus completed bars, not a new confirmed candle. No mandatory threshold or direction.')
 return out

def position_context(p,o):
 signal=o.get('v4_signal',{});rule=o.get('holding_rule',{})
 thesis=dict(reason=signal.get('reason'),signal_frame=signal.get('setup_frame') or rule.get('frame'),original_invalidation=o.get('invalidation_px'),current_stop=o.get('stop_px'),entry_reference=signal.get('entry_reference'),original_ma=signal.get('ma'),original_zone=signal.get('level'),source='Persisted entry decision, not a replacement thesis')
 qty=number(p.get('pos'));ct=number(o.get('ct_val'));entry=number(p.get('avgPx'));mark=number(p.get('markPx'));rate=number(o.get('cost_rate'))
 estimate=None
 if all(v is not None and v>0 for v in (ct,entry,mark)) and qty is not None and rate is not None and rate>=0:
  units=abs(qty)*ct;side=1 if o['direction']=='long' else -1;gross=(mark-entry)*units*side;buffer=units*max(entry,mark)*rate
  estimate=dict(remaining_contracts=abs(qty),gross_remaining_leg_usdt=gross,modeled_cost_buffer_usdt=buffer,gross_less_modeled_buffer_usdt=gross-buffer,buffer_rate=rate,
   basis='Remaining leg from current average entry/mark; entry-time round-trip fee/slippage/funding reserve is a conservative buffer, not an actual current exit quote. Does not add already realized partial PnL; not final whole-trade realized PnL. Future execution may differ.')
 return dict(entry_thesis=thesis,remaining_leg_cost_estimate=estimate,account_reported_unrealized=p.get('upl'),account_reported_realized=p.get('realizedPnl'),policy='Reassess original thesis using current structure; never change its invalidation merely to avoid a loss. No automatic exit caused by this estimate.')

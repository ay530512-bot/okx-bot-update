"""Read-only review activity metadata; never creates a model request or order."""
PATTERNS={'double_top':'쌍고점','double_bottom':'쌍저점','trend_support':'추세 지지','trend_resistance':'추세 저항'}

def review_items(review):
 if not isinstance(review,dict):return []
 packets=review.get('_packets') or ([review] if review.get('symbol') else [])
 out=[]
 for p in packets:
  symbol=str(p.get('symbol') or '')
  if not symbol:continue
  plans=[]
  selected=p.get('selection',{})
  if selected.get('turnover_rank') is not None:
   plans.append(('24h 환산 거래대금 추정 ' if 'turnover_usdt_estimate' in selected else 'KST09 거래대금 ')+str(selected['turnover_rank'])+'위 / '+str(selected.get('turnover_usdt_estimate',selected.get('kst_turnover_usdt',0)))+' USDT')
  for side,d in p.get('directions',{}).items():
   for plan in d.get('stop_plans',[]):
    kind=plan.get('structure',{}).get('pattern',plan.get('source','파동'))
    label=plan.get('frame','')+' '+('롱' if side=='LONG' else '숏')+' '+PATTERNS.get(kind,kind)
    if label not in plans:plans.append(label)
  out.append(dict(symbol=symbol,plans=plans))
 return out

def review_names(review):
 items=review_items(review)
 return ', '.join(r['symbol'] for r in items) or '검토 종목 미확인'

def emit_review(engine,stage,review,reason=''):
 rows=review_items(review);value=dict(stage=stage,items=rows,reason=str(reason),ms=engine.api.now_ms())
 fingerprint=(stage,tuple((r['symbol'],tuple(r['plans'])) for r in rows),str(reason))
 if getattr(engine,'last_review_ui_key',None)==fingerprint:return
 engine.last_review_ui_key=fingerprint
 engine.events.put(('review_activity',value))
 # Reuse the exact already-computed summary; this is not a fresh market/AI request.
 p=next(iter((review or {}).get('_packets',[])),None)
 if p and p.get('frames'):engine.events.put(('timeframes',dict(symbol=p['symbol'],frames=p['frames'])))

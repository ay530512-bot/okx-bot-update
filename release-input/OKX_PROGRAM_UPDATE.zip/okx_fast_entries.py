"""Causal tail-turn and minute scalps. Closed OHLCV only; no orders/network."""
from okx_rules import metrics,zones

STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}
DEFAULTS=dict(turn_enabled=True,turn_frames=['5m','15m'],scalp_enabled=True,
    trend_lookback=8,trend_move_atr=.6,tail_body_ratio=1.5,tail_range_fraction=.4,
    tail_atr_fraction=.35,tail_close_fraction=.6,max_opposite_fraction=.25,
    zone_atr=.4,confirmation_atr=.05,min_relative_volume=.8,
    scalp_pullback_zone_atr=.3,scalp_max_extension_atr=1.5,
    range_slope_atr=.15,range_ma_distance_atr=.7,scalp_entry_window_seconds=90,
    scalp_max_hold_seconds=600,scalp_stagnation_bars=4,scalp_min_progress_r=.25,
    scalp_breakeven_r=.8)


def validate(p):
    return (type(p['turn_enabled']) is bool and type(p['scalp_enabled']) is bool
        and p['turn_frames'] and all(f in ('5m','15m') for f in p['turn_frames'])
        and type(p['trend_lookback']) is int and 4<=p['trend_lookback']<=30
        and 0<p['trend_move_atr']<=3 and 1<=p['tail_body_ratio']<=5
        and .2<=p['tail_range_fraction']<=.8 and 0<p['tail_atr_fraction']<=2
        and .5<p['tail_close_fraction']<1 and 0<p['max_opposite_fraction']<.5
        and 0<p['zone_atr']<=1 and 0<p['confirmation_atr']<=.5
        and 0<p['min_relative_volume']<=3 and 0<p['scalp_pullback_zone_atr']<=1
        and 0<p['scalp_max_extension_atr']<=3 and 0<p['range_slope_atr']<=1
        and 0<p['range_ma_distance_atr']<=2 and 45<=p['scalp_entry_window_seconds']<=120
        and 120<=p['scalp_max_hold_seconds']<=1800
        and type(p['scalp_stagnation_bars']) is int and 2<=p['scalp_stagnation_bars']<=10
        and 0<p['scalp_min_progress_r']<=1 and .3<=p['scalp_breakeven_r']<=2)


def sma(b,n):return sum(r[4] for r in b[-n:])/n


def tail_shape(b,atr,side,p):
    _,o,h,l,cl,_=b;span=h-l
    if span<=0:return None
    body=abs(cl-o);wick=min(o,cl)-l if side==1 else h-max(o,cl)
    other=h-max(o,cl) if side==1 else min(o,cl)-l
    location=(cl-l)/span if side==1 else (h-cl)/span
    if (wick<max(body*p['tail_body_ratio'],span*p['tail_range_fraction'],atr*p['tail_atr_fraction'])
            or location<p['tail_close_fraction'] or other/span>=p['max_opposite_fraction']):return None
    return dict(tail_body=wick/max(body,atr*.000001),tail_range=wick/span,tail_atr=wick/atr,
                close_location=location,opposite_range=other/span)


def target_at(price,side,refs):
    # Never stretch the target to satisfy reward/risk. The closest known obstacle wins.
    candidates=[x for x in refs if (x-price)*side>0]
    return (min(candidates) if side==1 else max(candidates)) if candidates else None


def setups(frames,c,now):
    p=c['signals'].get('fast_entries',{})
    if not p:return []
    need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1;hits=[]
    def emit(frame,b,side,pattern,level,source,shape,evidence,score,scalp=False,target=None):
        tail,last=b[-2:];end=last[0]+STEPS[frame]
        window=p['scalp_entry_window_seconds'] if scalp else c['signals']['wick15']['entry_window_seconds']
        if not end<=now<end+window*1000:return
        hits.append(dict(frame=frame,direction='LONG' if side==1 else 'SHORT',pattern=pattern,
            low=min(tail[3],last[3]),high=max(tail[2],last[2]),anchor=last[0],level=level,source=source,
            shape=shape,adaptive=True,independent_support=True,evidence=evidence,evidence_score=score,
            confirmed_turn=not scalp,fast_scalp=scalp,fast_priority=True,entry_window_seconds=window,
            target=target))
    if p['turn_enabled']:
        for frame in p['turn_frames']:
            b=[r for r in frames.get(frame,[]) if r[0]+STEPS[frame]<=now]
            if len(b)<need+2:continue
            prior=b[:-2];tail,last=b[-2:];m=metrics(prior,c);atr=m['atr'];ma5=sma(prior,5)
            for side in (1,-1):
                before=-side
                trend=((m['ma'][15]-m['ma'][20])*before>0 and m['slopes'][20]*before>0
                    and (prior[-1][4]-prior[-p['trend_lookback']][4])*before>=atr*p['trend_move_atr'])
                shape=tail_shape(tail,atr,side,p)
                if not trend or not shape:continue
                extreme=tail[3] if side==1 else tail[2]
                edge=m['lower'] if side==1 else m['upper']
                old_extreme=min(r[3] for r in prior[-20:]) if side==1 else max(r[2] for r in prior[-20:])
                located=(abs(extreme-edge)<=atr*p['zone_atr'] or (edge-extreme)*side>0
                    or abs(extreme-old_extreme)<=atr*p['zone_atr'])
                if not located:continue
                body_mid=(tail[1]+tail[4])/2
                preserved=(last[3]>=tail[3]-atr*.05) if side==1 else (last[2]<=tail[2]+atr*.05)
                turn=(preserved and (last[4]-last[1])*side>0
                    and (last[4]-tail[4])*side>=atr*p['confirmation_atr']
                    and (last[4]-body_mid)*side>=atr*p['confirmation_atr']
                    and (last[4]-ma5)*side>0)
                if not turn:continue
                baseline=sum(r[5] for r in prior[-20:])/20
                relative=max(tail[5],last[5])/baseline if baseline>0 else 0
                if relative<p['min_relative_volume']:continue
                break_level=max(r[2] for r in prior[-3:]) if side==1 else min(r[3] for r in prior[-3:])
                broken=(last[4]-break_level)*side>atr*p['confirmation_atr']
                # Counter both higher trends only after local swing structure actually breaks.
                higher={}
                for f in ('1H','4H'):
                    known=[r for r in frames.get(f,[]) if r[0]+STEPS[f]<=tail[0]]
                    if len(known)>=need:
                        hm=metrics(known,c)
                        higher[f]=((hm['ma'][15]-hm['ma'][20])*side<0 and hm['slopes'][20]*side<0)
                if sum(higher.values())>=2 and not broken:continue
                refs=[m['mid'],m['lower'] if side==-1 else m['upper']]
                refs += [z['price'] for z in zones(prior,c) if z['kind']==('resistance' if side==1 else 'support')]
                target=target_at(last[4],side,refs)
                if target is None:continue
                emit(frame,b,side,'tail_turn_long' if side==1 else 'tail_turn_short',edge,
                    frame+' 꼬리 이후 MA5·몸통 회복/이탈',shape,
                    dict(prior_trend='down' if side==1 else 'up',confirmed_turn=True,
                         tail_ms=tail[0],confirmation_ms=last[0],relative_volume=relative,
                         local_structure_break=broken,break_level=break_level,higher_opposed=higher,
                         band_return=m['lower']<=tail[4]<=m['upper'],**shape),16,target=target)
    if not p['scalp_enabled']:return hits
    b=[r for r in frames.get('1m',[]) if r[0]+60000<=now]
    if len(b)<need+2:return hits
    tail,last=b[-2:];prior=b[:-2];m=metrics(prior,c);atr=m['atr']
    known5=[r for r in frames.get('5m',[]) if r[0]+300000<=tail[0]]
    if len(known5)<need:return hits
    m5=metrics(known5,c)
    volume=sum(r[5] for r in prior[-20:])/20
    relative=max(tail[5],last[5])/volume if volume>0 else 0
    if relative<p['min_relative_volume']:return hits
    for side in (1,-1):
        reaction=(last[4]-last[1])*side>0 and (last[4]-tail[4])*side>=atr*p['confirmation_atr']
        extreme=min(tail[3],last[3]) if side==1 else max(tail[2],last[2])
        older_extreme=min(r[3] for r in prior[-8:]) if side==1 else max(r[2] for r in prior[-8:])
        preserved=(extreme-older_extreme)*side>=-atr*.1
        if not reaction:continue
        refs=[m['upper'] if side==1 else m['lower'],m5['upper'] if side==1 else m5['lower']]
        refs += [z['price'] for z in zones(prior,c) if z['kind']==('resistance' if side==1 else 'support')]
        refs += [max(r[2] for r in prior[-20:]) if side==1 else min(r[3] for r in prior[-20:])]
        target=target_at(last[4],side,refs)
        if target is None:continue
        trend=(m5['ma'][15]-m5['ma'][20])*side>0 and m5['slopes'][20]*side>0
        if trend and preserved and (last[4]-m['ma'][20])*side<=atr*p['scalp_max_extension_atr']:
            for n in (5,20):
                level=sma(prior,n);tol=atr*p['scalp_pullback_zone_atr']
                touch=tail[3]-tol<=level<=tail[2]+tol
                reclaim=(tail[4]-level)*side>=-tol and (last[4]-level)*side>atr*p['confirmation_atr']
                if touch and reclaim:
                    emit('1m',b,side,'scalp_ma_long' if side==1 else 'scalp_ma_short',level,
                        '5m 추세·1m SMA'+str(n)+' 지지/저항 회복',{},
                        dict(context_frame='5m',context_closed_ms=known5[-1][0]+300000,
                            period=n,relative_volume=relative,structure_preserved=True),12,True,target)
                    break
        ranging=abs(m5['slopes'][20])<=p['range_slope_atr'] and abs(m5['ma'][15]-m5['ma'][50])<=m5['atr']*p['range_ma_distance_atr']
        shape=tail_shape(tail,atr,side,p)
        edge=m['lower'] if side==1 else m['upper']
        excursion=(edge-(tail[3] if side==1 else tail[2]))*side>atr*.05
        restored=m['lower']<tail[4]<m['upper'] and m['lower']<last[4]<m['upper']
        if ranging and shape and excursion and restored:
            target=target_at(last[4],side,[m['mid'],m5['mid']])
            if target is not None:
                emit('1m',b,side,'scalp_range_long' if side==1 else 'scalp_range_short',edge,
                    '5m 횡보·1m 밴드 밖 꼬리 후 내부 복귀',shape,
                    dict(context_frame='5m',context_closed_ms=known5[-1][0]+300000,
                        relative_volume=relative,band_return=True,range_confirmed=True,**shape),12,True,target)
    return hits

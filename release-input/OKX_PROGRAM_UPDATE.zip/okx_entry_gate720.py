"""One authoritative entry-readiness state for buttons and serialized orders."""
def gate(e):
    code='READY';reason='직접 진입 가능'
    day=e.journal.data.get('day') or {}
    if not e.enabled:
        if getattr(e,'resume_pending',False):code,reason='AUTO_RESUME_WAIT','자동 재개 대기: '+str(getattr(e,'resume_reason','계정·주문·SL 대조 중'))
        else:code,reason='LIVE_OFF',str(getattr(e,'resume_reason','') or '실거래가 꺼져 있습니다. 실거래 시작 후 확인을 완료하세요.')
    elif e.preview:code,reason='PREVIEW','미리보기 상태입니다. 실거래 시작으로 전환하세요.'
    elif e.user_paused or getattr(e,'mobile_entry_pause',False):code,reason='USER_PAUSED','신규 진입이 일시정지됐습니다. 실거래 시작으로 재개하세요.'
    elif day.get('ended'):code,reason='DAY_ENDED','당일 운용 중단: '+str(day.get('end_reason') or '중단 기록 확인 필요')
    elif not e.account_stream.fresh():code,reason='ACCOUNT_STALE','계정 실시간 연결이 지연됐습니다. PC의 OKX 재연결 후 계정 대조를 기다리세요.'
    elif not e.stream.connected:code,reason='MARKET_DISCONNECTED','공개 시세 연결이 끊겼습니다. PC의 OKX 재연결을 확인하세요.'
    elif e.recovering:code,reason='RECOVERING','재연결 후 포지션·주문·보호SL 대조 중입니다. 대조 완료 후 자동으로 진입을 허용합니다.'
    elif getattr(e,'queued_risks',None):code,reason='RISK_PENDING','기존 포지션 위험 처리를 확인 중입니다. 보호 주문 및 청산 결과를 먼저 확인하세요.'
    elif e.entry_cancel.is_set():code,reason='ENTRY_LOCK','신규 주문 차단이 남아 있습니다. PC 최근 활동의 마지막 오류와 보호 주문 상태를 확인하세요.'
    elif not e.within_session():code,reason='SESSION_ENDED','신규 진입 운용시간이 끝났습니다. 실거래 시작으로 재개하세요.'
    result=dict(allowed=code=='READY',code=code,reason=reason)
    try:
        raw=e.raw_snapshot
        result['preview_margin']=float(min(float(raw['equity']),float(e.allocation_seed(raw)))/4)
    except (AttributeError,KeyError,TypeError,ValueError):result['preview_margin']=None
    return result

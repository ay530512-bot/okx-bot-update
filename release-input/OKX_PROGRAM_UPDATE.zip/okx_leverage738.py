"""Validate the exact contract/side/margin leverage acknowledgement."""
from okx_core import dec
def confirmed_leverage(rows, symbol, side, leverage):
    if not isinstance(rows, list):
        return False
    matched = [r for r in rows if isinstance(r, dict) and r.get('instId') == symbol
               and r.get('posSide') == side and r.get('mgnMode') == 'isolated']
    try:
        return bool(matched) and all(dec(r.get('lever')) == dec(leverage) for r in matched)
    except Exception:
        return False

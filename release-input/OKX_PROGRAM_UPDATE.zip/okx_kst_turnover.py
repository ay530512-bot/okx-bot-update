"""KST09 session quote-currency turnover; never substitute rolling24h volume."""
import math,threading
from concurrent.futures import ThreadPoolExecutor,as_completed
from okx_core import OKX,BotError

DEFAULTS=dict(enabled=True,top_n=30,max_age_seconds=300)
def settings(c):return dict(DEFAULTS,**c.get('selection',{}).get('kst_turnover',{}))
def enabled(c):return c.get('selection',{}).get('kst_turnover',{}).get('enabled',False)
def validate(p):return type(p['enabled']) is bool and type(p['top_n']) is int and 5<=p['top_n']<=100 and 60<=p['max_age_seconds']<=600
def session_start(now):return now//86400000*86400000 # UTC00 = KST09

def daily_turnover(rows,now):
 start=session_start(now)
 row=next((r for r in rows if len(r)>=9 and int(r[0])==start and str(r[8])=='0'),None)
 if row is None:raise BotError('한국시간09시 진행 일봉 데이터 미확인')
 value=float(row[7])
 if not math.isfinite(value) or value<0:raise BotError('USDT 환산 거래대금 오류')
 return value

def order_rows(rows,top_n):
 ordered=sorted(rows,key=lambda r:(-r['kst_turnover_usdt'],r['symbol']))
 return [dict(r,turnover_rank=n) for n,r in enumerate(ordered,1) if r['kst_turnover_usdt']>0][:top_n]

def collect(market,instruments):
 owner=market.owner;local=threading.local();apis=[];lock=threading.Lock();rows=[];errors=[]
 def one(i):
  if owner.stop_event.is_set():raise BotError('거래대금 순위 조회 중지')
  if not hasattr(local,'api'):
   local.api=OKX(owner.settings)
   with lock:apis.append(local.api)
  owner.throttle();now=local.api.now_ms()
  data=local.api.public('/api/v5/market/candles',instId=i['instId'],bar='1Dutc',limit='2')
  observed=local.api.now_ms()
  return dict(symbol=i['instId'],kst_turnover_usdt=daily_turnover(data,observed),
   turnover_start_ms=session_start(observed),turnover_observed_ms=observed)
 try:
  with ThreadPoolExecutor(max_workers=6) as pool:
   futures={pool.submit(one,i):i['instId'] for i in instruments}
   for f in as_completed(futures):
    try:rows.append(f.result())
    except Exception:errors.append(futures[f])
  if errors or not rows:raise BotError('한국시간 거래대금 전체 순위 미완료: 누락 '+str(len(errors))+'종목')
  now=apis[0].now_ms();p=settings(owner.cfg);start=session_start(now)
  if any(r['turnover_start_ms']!=start or not 0<=now-r['turnover_observed_ms']<=p['max_age_seconds']*1000 for r in rows):
   raise BotError('한국시간 거래대금 기준일 변경 또는 순위 데이터 지연')
  return dict(rows=order_rows(rows,p['top_n']),start_ms=start,
   observed_ms=min(r['turnover_observed_ms'] for r in rows),universe=len(rows))
 finally:
  for api in apis:api.session.close()

def check_scope(result,symbol,now,c):
 if not result.get('turnover_scope'):return
 if not result.get('turnover_ready') or result.get('turnover_start_ms')!=session_start(now):raise BotError('한국시간 거래대금 순위 갱신 대기')
 if not 0<=now-result['turnover_observed_ms']<=settings(c)['max_age_seconds']*1000:raise BotError('한국시간 거래대금 순위 지연')
 if symbol not in result.get('ranked_symbols',[]):raise BotError('한국시간 거래대금 상위권 밖: 자동 신규 진입 제외')

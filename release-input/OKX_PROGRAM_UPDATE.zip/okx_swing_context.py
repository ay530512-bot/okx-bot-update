"""Confirmed lower highs / higher lows with intervening waves; no future bars."""
DEFAULTS=dict(enabled=True,lookback=80,pivot_wing=2,min_gap=4,max_gap=40,
              zone_atr=.25,minimum_swing_atr=.5,progress_atr=.15,max_age_bars=6,
              hold_seconds={'1m':600,'5m':1800,'15m':3600,'1H':14400,'4H':28800})
STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}

def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('swing_context',{}))
def validate(p):
 return (type(p['enabled']) is bool and 30<=p['lookback']<=200 and type(p['pivot_wing']) is int and 1<=p['pivot_wing']<=5
  and 2*p['pivot_wing']<=p['min_gap']<p['max_gap']<=p['lookback'] and 0<p['zone_atr']<=1
  and .1<=p['minimum_swing_atr']<=3 and 0<p['progress_atr']<=1 and 1<=p['max_age_bars']<=12
  and set(p['hold_seconds'])==set(STEPS) and all(type(v) is int and 120<=v<=86400 for v in p['hold_seconds'].values()))

def evidence(bars,frame,atr,c):
 p=settings(c)
 if not p['enabled'] or atr<=0:return {}
 b=bars[-p['lookback']:];w=p['pivot_wing'];out={}
 if len(b)<p['min_gap']+2*w+1:return out
 for side,field,action in ((-1,2,'SHORT'),(1,3,'LONG')):
  pivots=[]
  for i in range(w,len(b)-w):
   v=b[i][field];left=[r[field] for r in b[i-w:i]];right=[r[field] for r in b[i+1:i+w+1]]
   if (v>max(left) and v>=max(right)) if side==-1 else (v<min(left) and v<=min(right)):pivots.append(i)
  if len(pivots)<2:continue
  i,j=pivots[-2:];first=b[i][field];second=b[j][field]
  if not p['min_gap']<=j-i<=p['max_gap'] or len(b)-1-(j+w)>p['max_age_bars']:continue
  middle=min(r[3] for r in b[i+1:j]) if side==-1 else max(r[2] for r in b[i+1:j])
  retrace=(first-middle)*(-side)
  if retrace<atr*p['minimum_swing_atr']:continue
  favorable=(second-first)*side
  double=abs(second-first)<=atr*p['zone_atr']
  improved=favorable>=atr*p['progress_atr']
  if not (double or improved):continue
  # Price must reject the second extreme; being merely below/above the first is insufficient.
  reaction=(b[-1][4]-second)*side>=atr*p['progress_atr']
  progressing=(b[-1][4]-b[-2][4])*side>0 or (b[-1][4]-b[-3][4])*side>0
  reclaimed=(b[-1][4]-first)*side>0
  if not reaction or not progressing or not reclaimed:continue
  pattern=('double_top' if side==-1 else 'double_bottom') if double else ('lower_high' if side==-1 else 'higher_low')
  out[action]=dict(pattern=pattern,frame=frame,first=first,second=second,middle=middle,
    first_ms=b[i][0],second_ms=b[j][0],confirmed_ms=b[j+w][0]+STEPS[frame],
    gap_bars=j-i,retracement_atr=retrace/atr,zone_atr=p['zone_atr'],reaction_confirmed=True,
    stop=second-side*atr*c['risk']['stop_buffer_atr'],max_hold_seconds=p['hold_seconds'][frame])
 return out

def is_structural(owned):return bool((owned.get('holding_rule') or {}).get('swing_structure'))

def manage(frames,position,owned,c,now):
 rule=owned['holding_rule'];side=1 if owned['direction']=='long' else -1;frame=rule['frame'];step=STEPS[frame]
 if not rule.get('no_time_exit') and now-owned.get('entry_ms',now)>=rule['max_hold_seconds']*1000:return 'CLOSE','진입 시간봉별 최대 보유 시간 도달',None
 from okx_wave_mode import net_profitable
 if not owned.get('partial_used') and not owned.get('partial_unsplittable') and float(position['uplRatio'])>0 and (not rule.get('wave') or net_profitable(position,owned)) and (float(position['markPx'])-rule['target'])*side>=0:
  return 'PARTIAL','시간봉 파동 목표 도달: 60% 청산 후 구조 추적',None
 b=[r for r in frames.get(frame,[]) if r[0]+step<=now]
 if len(b)<24 or now-(b[-1][0]+step)>=step:return 'HOLD','진입 기준 시간봉 갱신 대기·거래소 보호 손절 유지',None
 before_entry=(b[-1][0]+step<=owned.get('entry_ms',now)) if rule.get('wave') else (b[-1][0]<owned.get('entry_ms',now))
 if before_entry:return 'HOLD','진입 후 기준 시간봉 완료 대기·보호 손절 유지',None
 if (b[-1][4]-rule['zone'])*side < -rule['tolerance']:return 'CLOSE','기준 시간봉 지지/저항 구조 종가 이탈',None
 # Only a completed, confirmed post-entry swing can tighten the existing exchange stop.
 from okx_rules import metrics
 atr=metrics(b,c)['atr'];hits=evidence(b,frame,atr,c);hit=hits.get('LONG' if side==1 else 'SHORT')
 if hit and hit['second_ms']>=owned.get('entry_ms',now):
  target=hit['stop']
  if rule.get('wave'):
   from okx_wave_mode import settings as wave_settings
   target=(min(hit['first'],hit['second']) if side==1 else max(hit['first'],hit['second']))-side*atr*wave_settings(c)['stop_buffer_atr']
  old=float(owned['stop_px']);mark=float(position['markPx'])
  if (target-old)*side>0 and (mark-target)*side>0:return 'TRAIL','기준 시간봉의 새 저점 상승/고점 하락: 보호 손절 유리하게 조정',target
 return 'HOLD','진입 기준 시간봉 구조 유지·분봉 흔들림과 구분',None

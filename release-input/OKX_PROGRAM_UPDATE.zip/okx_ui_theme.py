"""Shared presentation palette and native-widget styling. No trading dependencies."""
import tkinter as tk
from tkinter import ttk
BG='#000000';PANEL='#1c1c1c';INNER='#242424';BORDER='#303030'
TEXT='#f4f4f4';MUTED='#a3a3a3';GREEN='#50a65a';RED='#ba4667';AMBER='#ff9f43'

ACCENT='#c7ff54';PRIMARY_BG='#c7ff54';HOVER='#303030';SELECTED='#25301b'
LONG_BG='#50a65a';SHORT_BG='#ba4667'

def apply_theme(master,family):
 style=ttk.Style(master)
 if style.theme_use()!='clam':style.theme_use('clam')
 style.configure('.',background=PANEL,foreground=TEXT,bordercolor=BORDER,lightcolor=BORDER,darkcolor=BORDER)
 style.configure('TCombobox',fieldbackground=INNER,background=PANEL,foreground=TEXT,arrowcolor=MUTED)
 style.map('TCombobox',fieldbackground=[('readonly',INNER)],foreground=[('readonly',TEXT)],selectbackground=[('readonly',INNER)],selectforeground=[('readonly',TEXT)])
 style.configure('TEntry',fieldbackground=INNER,foreground=TEXT,insertcolor=TEXT)
 style.configure('TButton',background=INNER,foreground=TEXT)
 style.map('TButton',background=[('active',HOVER)],foreground=[('disabled',MUTED),('active',TEXT)])
 for widget in ('Button','Entry','Text','Listbox'):
  master.option_add('*'+widget+'.background',INNER)
  master.option_add('*'+widget+'.foreground',TEXT)
  master.option_add('*'+widget+'.selectBackground',SELECTED)
  master.option_add('*'+widget+'.selectForeground',TEXT)
 master.option_add('*Button.activeBackground',HOVER)
 master.option_add('*Button.activeForeground',TEXT)
 master.option_add('*Button.disabledForeground',MUTED)
 master.option_add('*Entry.insertBackground',TEXT)
 master.option_add('*Text.insertBackground',TEXT)
 style.configure('TScrollbar',background='#484848',troughcolor=BG,bordercolor=BG,arrowcolor=MUTED,lightcolor=BG,darkcolor=BG,arrowsize=11)
 style.map('TScrollbar',background=[('active','#626262')])
 style.configure('Market.TCombobox',fieldbackground=INNER,background=PANEL,foreground=TEXT,arrowcolor=MUTED,bordercolor=BORDER,lightcolor=BORDER,darkcolor=BORDER,padding=7)
 style.map('Market.TCombobox',fieldbackground=[('readonly',INNER)],foreground=[('readonly',TEXT)],selectbackground=[('readonly',INNER)],selectforeground=[('readonly',TEXT)])
 style.configure('Market.Treeview',font=(family,-14),rowheight=38,background=PANEL,fieldbackground=PANEL,foreground=TEXT,bordercolor=PANEL,lightcolor=PANEL,darkcolor=PANEL,borderwidth=0,relief='flat')
 style.layout('Market.Treeview',[('Treeview.treearea',{'sticky':'nswe'})])
 style.configure('Market.Treeview.Heading',font=(family,-12,'bold'),background=INNER,foreground=MUTED,bordercolor=INNER,lightcolor=INNER,darkcolor=INNER,relief='flat',padding=(5,10))
 style.map('Market.Treeview',background=[('selected',SELECTED)],foreground=[('selected',TEXT)])
 style.map('Market.Treeview.Heading',background=[('active',HOVER)])
 master.option_add('*TCombobox*Listbox.background',INNER)
 master.option_add('*TCombobox*Listbox.foreground',TEXT)
 master.option_add('*TCombobox*Listbox.selectBackground',SELECTED)
 master.option_add('*TCombobox*Listbox.selectForeground',TEXT)
 return style

def button(parent,text,command,family,kind='secondary',**kw):
 fill=PRIMARY_BG if kind=='primary' else '#352d21' if kind=='order' else INNER
 fg=BG if kind=='primary' else AMBER if kind=='order' else TEXT
 return tk.Button(parent,text=text,command=command,font=(family,-14,'bold'),bg=fill,fg=fg,activebackground='#d6ff86' if kind=='primary' else HOVER,activeforeground=BG if kind=='primary' else TEXT,disabledforeground='#7c8797',relief='flat',bd=0,highlightthickness=1,highlightbackground=BORDER,highlightcolor=GREEN,padx=10,pady=9,cursor='hand2',**kw)

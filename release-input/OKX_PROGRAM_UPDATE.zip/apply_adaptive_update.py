"""Idempotent local migration. No network, no orders, no credential/state changes."""
import json, os, shutil, socket, tempfile
from pathlib import Path
from okx_rules import load_config


def configure(data):
    data['version']='6.15-relaxed-preview'
    if data['execution'].get('fixed_initial_revision',0)<1:
        data['risk'].update(initial_size_mode='fixed_third',initial_margin_fraction=1/3,fixed_initial_max_rounding_fraction=.03)
        data['execution']['fixed_initial_revision']=1
    data['execution'].setdefault('manual_coexist',True)
    data['execution'].setdefault('entry_pipeline',dict(enabled=True,funding_max_age_seconds=300,estimated_cost_rate=.0025))
    data['liquidity'].setdefault('trade_max_age_seconds',60)
    if data['execution'].get('depth_revision_v614',0)<1:
        data['liquidity']['depth_multiple']=min(10,data['liquidity']['depth_multiple'])
        data['execution']['depth_revision_v614']=1
    from okx_case_entries import DEFAULTS as CASE_DEFAULTS
    data['signals'].setdefault('case_entries',dict(CASE_DEFAULTS))
    case=data['signals']['case_entries']
    for key,value in CASE_DEFAULTS.items():case.setdefault(key,value)
    if data['execution'].get('relaxed_revision_v615',0)<1:
        case.update(zone_atr=.70,tail_body_ratio=1.2,tail_range_fraction=.30,tail_atr=.20,
                    single_wick_enabled=True,consolidation_enabled=True)
        data['execution']['relaxed_revision_v615']=1
    data['risk'].setdefault('reversal_profit',dict(enabled=True,partial_fraction=.6,wick_body_ratio=1.5,wick_range_fraction=.4,wick_atr=.3,reaction_atr=.05,timeframe='5m'))
    from okx_fast_entries import DEFAULTS as FAST_DEFAULTS
    data['signals'].setdefault('fast_entries',dict(FAST_DEFAULTS))
    from okx_short_exit import DEFAULTS as SHORT_EXIT_DEFAULTS
    data['signals'].setdefault('short_support_exit',dict(SHORT_EXIT_DEFAULTS))
    from okx_context_entries import DEFAULTS as CONTEXT_DEFAULTS
    data['signals'].setdefault('context_entries',dict(CONTEXT_DEFAULTS))
    from okx_ai_cost import DEFAULTS as AI_DEFAULTS
    data['execution'].setdefault('ai_cost_control',dict(AI_DEFAULTS))
    from okx_support import DEFAULTS as SUPPORT_DEFAULTS
    data['signals'].setdefault('support_entries',dict(SUPPORT_DEFAULTS))
    data['signals']['strategy_logic']='OR'
    data['selection']['include_majors']=True
    data['risk']['max_positions']=0
    from okx_trend_tail import DEFAULTS
    data['signals'].setdefault('trend_tail',dict(DEFAULTS))
    data['signals']['entry_mode']='wick15'
    w=data['signals']['wick15']
    w.update(scalp_enabled=True,adaptive_enabled=True,entry_window_seconds=240,
             max_entry_gap_atr=.5,max_entry_gap_fraction=.005,sr_zone_atr=.65)
    data['signals']['follow_atr']=.03
    # Compare each token with its own closed hourly history; never cross-token volume.
    data['selection'].update(focus_count=15,mode='kst09_movers',volume_timeframe='1H',
        volume_recent_bars=1,volume_history_bars=72,volume_percentile=data['selection'].get('volume_percentile',60) if data['execution'].get('entry_relax_revision') else 65,relative_volume=data['selection'].get('relative_volume',1.1) if data['execution'].get('entry_relax_revision') else 1.2,
        volume_growth_required=False)
    # Structure + noise buffer; retain the existing maximum loss and cost checks.
    data['risk']['stop_buffer_atr']=max(.25,data['risk']['stop_buffer_atr'])
    data['execution']['ai_confirmation']=True
    # One-time explicit entry relaxation; later user tuning is retained.
    if data['execution'].get('entry_relax_revision',0)<1:
        data['selection'].update(volume_percentile=60,relative_volume=1.1)
        data['signals']['support_entries'].update(zone_atr=.65,rejection_atr=.15,
            close_fraction=.55,base_width_atr=2.)
        data['signals']['trend_tail'].update(body_ratio=1.3,range_fraction=.35,
            atr_fraction=.30,close_fraction=.60,zone_atr=.65)
        data['execution']['entry_relax_revision']=1
    if data['execution'].get('mover_selection_revision',0)<1:
        data['selection'].update(gainers_count=8,losers_count=7,focus_count=15,mode='kst09_movers')
        data['risk']['min_reward_risk']=min(1.1,data['risk']['min_reward_risk'])
        data['signals']['direction_conflict_gap']=1.5
        data['execution']['mover_selection_revision']=1
    data['selection']['focus_count']=data['selection']['gainers_count']+data['selection']['losers_count']
    return data


def apply(root,check_running=True):
    root=Path(root); lock=None
    try:
        if check_running:
            lock=socket.socket()
            if hasattr(socket,'SO_EXCLUSIVEADDRUSE'):lock.setsockopt(socket.SOL_SOCKET,socket.SO_EXCLUSIVEADDRUSE,1)
            try:lock.bind(('127.0.0.1',48736))
            except OSError:raise ValueError('자동매매 창을 먼저 종료한 뒤 다시 실행하세요.') from None
        path=root/'strategy_config.json'
        source=path if path.exists() else root/'strategy_config.default.json'
        data=configure(json.loads(source.read_text(encoding='utf-8-sig')))
        with tempfile.TemporaryDirectory() as folder:
            (Path(folder)/'strategy_config.json').write_text(json.dumps(data),encoding='utf-8')
            load_config(folder)
        if path.exists() and not (root/'strategy_config_before_relaxed_v615.json').exists():
            shutil.copy2(path,root/'strategy_config_before_relaxed_v615.json')
        if path.exists() and not (root/'strategy_config_before_pipeline_v614.json').exists():
            shutil.copy2(path,root/'strategy_config_before_pipeline_v614.json')
        if path.exists() and not (root/'strategy_config_before_cases_v613.json').exists():
            shutil.copy2(path,root/'strategy_config_before_cases_v613.json')
        if path.exists() and not (root/'strategy_config_before_reversal_v612.json').exists():
            shutil.copy2(path,root/'strategy_config_before_reversal_v612.json')
        if path.exists() and not (root/'strategy_config_before_manual_v611.json').exists():
            shutil.copy2(path,root/'strategy_config_before_manual_v611.json')
        if path.exists() and not (root/'strategy_config_before_fixed_third_v610.json').exists():
            shutil.copy2(path,root/'strategy_config_before_fixed_third_v610.json')
        if path.exists() and not (root/'strategy_config_before_movers_v67.json').exists():
            shutil.copy2(path,root/'strategy_config_before_movers_v67.json')
        if path.exists() and not (root/'strategy_config_before_relax_v64.json').exists():
            shutil.copy2(path,root/'strategy_config_before_relax_v64.json')
        if path.exists() and not (root/'strategy_config_before_adaptive.json').exists():
            shutil.copy2(path,root/'strategy_config_before_adaptive.json')
        tmp=path.with_suffix('.adaptive.tmp')
        with tmp.open('w',encoding='utf-8') as out:
            json.dump(data,out,ensure_ascii=False,indent=2,allow_nan=False);out.write('\n');out.flush();os.fsync(out.fileno())
        os.replace(tmp,path)
        return data
    finally:
        if lock:lock.close()

if __name__=='__main__':
    try:
        apply(Path(__file__).resolve().parent)
        print('Adaptive entry / structural stop update applied. No order sent.')
    except Exception as e:
        print('Update failed:',str(e));raise SystemExit(1)

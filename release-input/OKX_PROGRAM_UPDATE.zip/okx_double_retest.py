"""Causal double retests: completed-bar rejection, without a second pivot wait."""
from okx_swing_context import STEPS
DEFAULTS=dict(enabled=True,direct_entry=True,lookback=80,min_gap=2,max_gap=40,
 zone_atr=.8,minimum_swing_atr=.25,rejection_atr=.08,close_location=.5,
 reclaim_tolerance_atr=.15,max_age_bars=2,retry_seconds=30)

def settings(c):return dict(DEFAULTS,**c.get('signals',{}).get('double_retest',{}))
def validate(p):
 return (type(p['enabled']) is bool and type(p['direct_entry']) is bool
  and all(type(p[k]) is int for k in ('lookback','min_gap','max_gap','max_age_bars','retry_seconds'))
  and 30<=p['lookback']<=200 and 2<=p['min_gap']<p['max_gap']<=p['lookback']
  and .1<=p['zone_atr']<=1 and .1<=p['minimum_swing_atr']<=3
  and .01<=p['rejection_atr']<=1 and .4<=p['close_location']<=.9
  and 0<=p['reclaim_tolerance_atr']<=.5 and 0<=p['max_age_bars']<=5 and 10<=p['retry_seconds']<=300)

def enabled(c):return c.get('signals',{}).get('double_retest',{}).get('enabled',False)
def direct(c):return enabled(c) and settings(c)['direct_entry']

def evidence(b,frame,atr,c):
 if not enabled(c) or atr<=0:return {}
 p=settings(c);b=b[-p['lookback']:];out={}
 if len(b)<p['min_gap']+3:return out
 for side,field,action in ((1,3,'LONG'),(-1,2,'SHORT')):
  # Only the first extremum needs a right-hand confirmation. The retest itself
  # may be the latest completed candle; a neckline breakout is not required.
  for j in range(len(b)-1,max(1,len(b)-p['max_age_bars']-2),-1):
   second=b[j][field];span=b[j][2]-b[j][3]
   if span<=0:continue
   location=(b[j][4]-b[j][3])/span if side==1 else (b[j][2]-b[j][4])/span
   if location<p['close_location'] or (b[j][4]-second)*side<atr*p['rejection_atr']:continue
   for i in range(j-p['min_gap'],max(0,j-p['max_gap'])-1,-1):
    if i<1 or i+1>=j:continue
    first=b[i][field]
    pivot=first<b[i-1][field] and first<=b[i+1][field] if side==1 else first>b[i-1][field] and first>=b[i+1][field]
    if not pivot or abs(second-first)>atr*p['zone_atr']:continue
    between=b[i+1:j]
    middle=max(r[2] for r in between) if side==1 else min(r[3] for r in between)
    if (middle-first)*side<atr*p['minimum_swing_atr']:continue
    # No intervening settled breakdown beyond the retest zone.
    if any((r[4]-first)*side < -atr*p['zone_atr'] for r in between):continue
    if (b[-1][4]-first)*side < -atr*p['reclaim_tolerance_atr']:continue
    extreme=min(first,second) if side==1 else max(first,second)
    if any((r[4]-extreme)*side < -atr*p['reclaim_tolerance_atr'] for r in b[j+1:]):continue
    if (b[-1][4]-second)*side<atr*p['rejection_atr']:continue
    out[action]=dict(pattern='double_bottom' if side==1 else 'double_top',frame=frame,
     first=first,second=second,middle=middle,first_ms=b[i][0],second_ms=b[j][0],
     confirmed_ms=b[j][0]+STEPS[frame],gap_bars=j-i,retracement_atr=(middle-first)*side/atr,
     zone_atr=p['zone_atr'],reaction_confirmed=True,early_retest=True,
     stop=extreme-side*atr*c['risk']['stop_buffer_atr'],max_hold_seconds=86400)
    break
   if action in out:break
 if len(out)==2:return {} # A two-sided ambiguous range does not select both directions.
 return out

def select_direct(engine,review):
 if not direct(engine.cfg):return None
 for entry in review.get('_admitted',[]):
  signal=entry['signal']
  if signal.get('pattern') not in ('ai_double_bottom','ai_double_top'):continue
  if engine.api.now_ms()>signal['expires_ms']-5000:continue
  if signal['symbol']+':'+signal['signal_id'] in engine.ai_reviewed:continue
  signal=dict(signal,reason=signal.get('setup_frame','')+' 쌍저점 지지·종가 거부 반응 확인' if signal['action']=='LONG' else signal.get('setup_frame','')+' 쌍고점 저항·종가 거부 반응 확인')
  engine.auto_frozen=signal
  engine.ai_reviewed[signal['symbol']+':'+signal['signal_id']]=True
  engine.pipeline('approved',signal['symbol']+' / '+signal['action']+' / 쌍저·쌍고 거부 반응 규칙 진입 / 유료 진입 AI 호출 없음',count='signals')
  return dict(signal,_ai_precheck=entry['receipt'])
 return None

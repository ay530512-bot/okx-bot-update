"""Serialized exchange writes; AI runs separately from position protection checks."""
import hashlib
import json
import queue
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from decimal import Decimal, ROUND_UP, ROUND_DOWN
from pathlib import Path

from okx_core import (OKX, BotError, Rejected, UnknownOutcome, Journal, KST, STOP_ROE,
                      DAILY_CAP, DAILY_AI_THRESHOLD, dec, fmt, day_key,
                      size_plan, protective_order, owned_position)
from okx_ai import analyze
from okx_additions import Additions
from okx_market import allowed_altcoin
from okx_scale import legs_for
from okx_strategy import (load_frames, entry_signals, invalidation_level, verified_altcoin,
                          quick_exit, chart_exit, POSITION_INTERVAL, ENTRY_INTERVAL, CHART_INTERVAL)


class Engine(Additions):
    def __init__(self, root, settings, events, exchange=None, analyzer=analyze):
        self.root, self.settings, self.events = Path(root), dict(settings, _EXCHANGE_ROOT=str(Path(root).resolve())), events
        self.journal = Journal(self.root / "bot_state.json")
        self.api = exchange if exchange is not None else OKX(dict(self.settings,_EXCHANGE_EXECUTION=True))
        self.analyzer = analyzer
        self.commands = queue.Queue()
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.command_wake = threading.Event()
        self.entry_cancel = threading.Event()
        self.enabled = False
        self.preview = False
        self.budget = 2.00
        self.future = None
        self.future_epoch = None
        self.epoch = 0
        self.next_ai = 0
        self.last_flow = 0
        self.last_close = 0
        self.last_error = None
        self.last_snapshot = None
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="analysis")
        self.worker = None
        self.chart_executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="chart-protection")
        self.chart_future = None
        self.chart_identity = None
        self.next_chart = 0
        self.log("주문 복구 모듈 가동. 실제 전략·지표·한도는 strategy_config.json 및 현재 버전 안내 참조.")
        self.log("프로그램 시작. 실거래는 정지 상태입니다. 계정 조회만 합니다.")
        if self.journal.data["owned"]:
            self.log("이전 주문 기록 발견. 신규 진입 없이 체결·보호 상태를 복구 확인합니다.")

    def log(self, message):
        text = str(message)
        for name in ("OKX_API_KEY", "OKX_SECRET_KEY", "OKX_PASSPHRASE", "BINANCE_API_KEY", "BINANCE_SECRET_KEY", "BITGET_API_KEY", "BITGET_SECRET_KEY", "BITGET_PASSPHRASE", "OPENAI_API_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID"):
            value = self.settings.get(name)
            if value:
                text = text.replace(value, "[숨김]")
        text = datetime.now(KST).strftime("%m-%d %H:%M:%S") + "  " + text[:2500]
        self.events.put(("log", text))
        with (self.root / "bot_log.txt").open("a", encoding="utf-8") as stream:
            stream.write(text + "\n")

    def invalidate(self):
        self.epoch += 1

    def pause(self, reason):
        self.entry_cancel.set()
        self.enabled = self.preview = False
        self.invalidate()
        self.log(reason + " / 신규 진입 중지. 기록된 보유 포지션의 보호 관리는 계속합니다.")

    def start(self):
        self.worker = threading.Thread(target=self.run, daemon=True, name="exchange-monitor")
        self.worker.start()

    def send(self, action, **kwargs):
        if action in ("pause", "close", "quit", "reconnect"):
            self.entry_cancel.set()
        self.commands.put((action, kwargs))
        self.command_wake.set()

    def snapshot(self):
        snapshot = self.api.snapshot()
        cfg = snapshot["config"]
        if cfg.get("acctLv") != "2" or cfg.get("posMode") != "long_short_mode":
            raise BotError("선물 계정 모드 2 / long_short_mode가 필요합니다. 자동 변경하지 않습니다.")
        if not cfg.get("uid"):
            raise BotError("계정 식별을 확인할 수 없습니다.")
        identity = hashlib.sha256(cfg["uid"].encode()).hexdigest()
        recorded = self.journal.data["account"]
        if recorded and identity != recorded:
            raise BotError("기록과 다른 OKX 계정입니다. 기존 기록을 삭제하지 마세요.")
        if not recorded:
            self.journal.data["account"] = identity
            self.journal.save()
        self.last_snapshot = snapshot
        return snapshot

    def algos(self, full=False):
        rows = self.api.pending_algos(full)
        owned = self.journal.data["owned"]
        mine, other = [], []
        ids = set()
        if owned:
            ids.update(leg["algo_client_id"] for leg in legs_for(owned) + owned.get("cleanup_legs", []))
            if owned.get("pending_add"):
                ids.add(owned["pending_add"]["algo_client_id"])
        for row in rows:
            if (owned and row.get("algoClOrdId") in ids
                    and row.get("instId") == owned["symbol"]
                    and row.get("posSide") == owned["direction"]):
                mine.append(row)
            else:
                other.append(row)
        return mine, other

    def activate(self, expected_equity, budget, hours=24):
        snapshot = self.snapshot()
        position = owned_position(self.journal.data["owned"], snapshot["positions"])
        if snapshot["orders"]:
            raise BotError("기존 일반 미체결 주문이 있습니다.")
        mine, other = self.algos(full=True)
        if other:
            raise BotError("기존 조건주문이 있습니다. 자동으로 취소하지 않습니다.")
        if self.journal.data["owned"] and self.journal.data["owned"]["phase"] != "active":
            raise BotError("이전 주문의 체결/청산 상태를 아직 확인 중입니다.")
        equity = snapshot["equity"]
        if equity < 1:
            raise BotError("USDT 거래 잔고가 1 USDT 미만입니다. 자금 이동 후 다시 시작하세요.")
        if abs(equity - dec(expected_equity)) > max(Decimal("0.1"), dec(expected_equity) * Decimal("0.02")):
            raise BotError("확인한 뒤 잔고가 바뀌었습니다. 현재 잔고를 확인하고 다시 시작하세요.")
        budget = float(budget)
        ceiling=getattr(self,'cfg',{}).get('execution',{}).get('model_runtime',{}).get('max_daily_budget',5)
        if not 0.01 <= budget <= ceiling:
            raise BotError(f"AI 일일 예산은 0.01~{ceiling:g}달러 범위로 입력하세요.")
        if position and not mine:
            raise BotError("보유 포지션의 보호 주문이 없습니다. 보호 상태부터 확인하세요.")
        self.budget = budget
        hours = float(hours)
        if not 0.25 <= hours <= 24:
            raise BotError("운용시간은 0.25~24시간으로 입력하세요.")
        session = self.journal.data.get("session")
        continuous=getattr(self,"cfg",{}).get("execution",{}).get("continuous_trading",False)
        if continuous:
            self.journal.data["session"]={"start_ms": session["start_ms"] if session and not session["ended"] else snapshot["ms"],"end_ms":snapshot["ms"]+3650*86400000,"ended":False,"continuous":True}
            self.journal.save()
        elif not session or session["ended"] or snapshot["ms"] >= session["end_ms"]:
            self.journal.data["session"] = {"start_ms": snapshot["ms"],
                "end_ms": snapshot["ms"] + int(hours * 3600000), "ended": False}
            self.journal.save()
        self.journal.roll_day(snapshot["ms"], equity, initialize=True)
        self.enabled, self.preview = True, False
        self.entry_cancel.clear()
        self.invalidate()
        self.next_ai = 0
        self.log(f"실거래 활성화. 현재 평가자산 {equity:.6f} USDT / 규칙20/10 · 신규 유료AI 호출 없음" if getattr(self,"cfg",{}).get("execution",{}).get("rule_channel701") else f"실거래 활성화. 현재 평가자산 {equity:.6f} USDT / AI 일일 예산 ${budget:.2f}.")
        self.log("신규 진입 시간 제한 없음 · PC/프로그램 실행 중 연속 운용" if continuous else "신규 진입 허용 종료 예정: " + datetime.fromtimestamp(self.journal.data["session"]["end_ms"] / 1000, KST).strftime("%m-%d %H:%M:%S KST"))
        if self.journal.data["day"]["partial_first_day"]:
            self.log("첫 거래일 기준은 최초 실거래 시작 시점입니다. 이후 한국시간 자정 직후 첫 조회에서 갱신합니다.")

    def finish_position(self):
        owned = self.journal.data["owned"]
        if not owned:
            return
        mine, _ = self.algos()
        for row in mine:
            self.api.post("/api/v5/trade/cancel-algos", [{"instId": owned["symbol"], "algoId": row["algoId"]}])
        if owned.get("entry_seed") and self.last_snapshot:
            ending = self.last_snapshot["equity"]
            ai_cost = max(0, self.journal.data["api_total_spent"] - owned.get("api_total_at_entry", self.journal.data["api_total_spent"]))
            delta = ending - dec(owned["entry_seed"])
            row = {"trade_id": owned["client_id"], "symbol": owned["symbol"],
                   "exit_observed_ms": self.api.now_ms(), "entry_equity_usdt": owned["entry_seed"],
                   "exit_observed_equity_usdt": fmt(ending), "account_change_usdt": fmt(delta),
                   "estimated_ai_usd": ai_cost, "estimated_net_usdt_at_usd_parity": fmt(delta - dec(ai_cost)),
                   "average_used": owned.get("average_used", False), "pyramid_used": owned.get("pyramid_used", False)}
            with (self.root / "trade_history.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(row, ensure_ascii=False) + "\n")
            self.log(f"종료 조회 평가자산 {ending:.6f} USDT / 계정 변동 {delta:+.6f} / 해당 거래 AI비용 추정 ${ai_cost:.4f}")
        self.journal.data["owned"] = None
        self.journal.save()
        self.last_close = time.monotonic()
        self.next_ai = self.last_close + 300
        self.invalidate()
        self.log("포지션 종료 확인. 해당 포지션의 남은 보호 주문 정리 완료. 다음 분석까지 대기.")

    def reconcile(self, snapshot):
        owned = self.journal.data["owned"]
        if not owned:
            return None
        phase = owned["phase"]
        if phase == "adding":
            return self.reconcile_addition(snapshot)
        if phase == "protecting":
            return self.reconcile_protection(snapshot)
        position = owned_position(owned, snapshot["positions"])
        if phase == "submitted":
            try:
                order = self.api.get("/api/v5/trade/order", instId=owned["symbol"], clOrdId=owned["client_id"])[0]
            except Rejected:
                raise BotError("진입 요청 결과 미확인. 동일 주문을 재전송하지 않습니다. OKX 주문 내역 확인 필요.") from None
            state = order.get("state")
            filled = dec(order.get("accFillSz") or "0")
            if state == "canceled" and filled == 0 and position is None:
                self.log("진입 미체결 취소 확인. 포지션 없음.")
                self.finish_position()
                return None
            if state == "filled":
                if filled != dec(owned["quantity"]):
                    raise BotError("체결 수량이 요청과 다릅니다. 수동 확인 필요.")
                if not position:
                    # A very fast protective exit may already have closed the position.
                    if self.api.now_ms() - owned["entry_ms"] > 15000:
                        self.finish_position()
                    return None
                owned["phase"], owned["posId"] = "active", position["posId"]
                owned["fill_px"] = order.get("avgPx")
                self.journal.save()
                self.log("진입 체결 확인: " + owned["symbol"] + " " + owned["direction"])
            elif state not in ("live", "partially_filled"):
                raise BotError("예상과 다른 주문 상태: " + str(state))
            elif self.api.now_ms() - owned["entry_ms"] > 15000:
                raise BotError("진입 주문이 아직 종결되지 않았습니다. 신규 주문 차단.")
            return position
        if phase == "closing":
            if not position:
                self.finish_position()
                return None
            # A close timeout is reconciled by client ID; never submit another close blindly.
            try:
                order = self.api.get("/api/v5/trade/order", instId=owned["symbol"], clOrdId=owned["close_id"])[0]
            except Rejected:
                raise BotError("청산 결과 미확인. OKX에서 포지션을 직접 확인하세요. 보호 주문은 임의 취소하지 않았습니다.") from None
            if order.get("state") == "canceled":
                raise BotError("청산 주문이 취소됐습니다. OKX에서 직접 확인하세요.")
            return position
        if not position:
            self.finish_position()
            return None
        return position

    def close(self, snapshot, reason, end_day=False):
        owned = self.journal.data["owned"]
        self.invalidate()
        if end_day:
            self.journal.data["day"]["ended"] = True
            self.journal.save()
        if not owned:
            self.log("포지션 없음 / " + reason)
            return
        position = owned_position(owned, snapshot["positions"])
        if owned["phase"] in ("submitted", "adding"):
            owned["close_requested"] = reason
            self.journal.save()
            self.log("진입 요청 결과를 먼저 확인한 뒤 청산합니다: " + reason)
            return
        if not position:
            self.finish_position()
            return
        if owned["phase"] == "closing":
            return
        owned["close_id"] = "OC" + uuid.uuid4().hex[:28]
        owned["phase"] = "closing"
        self.journal.save()
        self.log("보유 포지션 시장가 청산 요청: " + reason)
        # In hedge mode, posSide makes this a close only. No unrelated positions are touched.
        self.api.post("/api/v5/trade/order", {
            "instId": owned["symbol"], "tdMode": "isolated", "posSide": owned["direction"],
            "side": "sell" if owned["direction"] == "long" else "buy",
            "sz": owned["quantity"], "ordType": "market", "clOrdId": owned["close_id"],
        })

    def entry_context(self, symbol, action):
        frames = load_frames(self.api, symbol)
        if not entry_signals(frames).get(action):
            raise BotError("최신 4개 시간봉의 추세/꼬리/눌림 조건 미충족. 진입 생략.")
        return frames

    def margin_room(self, snapshot):
        owned = self.journal.data["owned"]
        committed = dec(owned.get("committed_margin") or 0) if owned else dec(0)
        return max(dec(0), snapshot["equity"] * 2 / 3 - committed)

    def entry(self, result, instruments, analysis_cost=0):
        if self.entry_cancel.is_set():
            return
        snapshot = self.snapshot()  # Recheck after a potentially slow AI call.
        owned_position(self.journal.data["owned"], snapshot["positions"])
        if self.journal.data["owned"] or snapshot["orders"]:
            raise BotError("진입 전 포지션 또는 주문 발견.")
        _, other = self.algos(full=True)
        if other:
            raise BotError("진입 전 기존 조건주문 발견.")
        if not self.enabled or self.entry_cancel.is_set() or self.journal.data["day"]["ended"] or not self.within_session():
            return
        if day_key(snapshot["ms"]) != self.journal.data["day"]["date"]:
            self.invalidate()
            return  # Wait for a fresh analysis in the new day.
        direction = "long" if result["action"] == "LONG" else "short"
        symbol, leverage = result["symbol"], result["leverage"]
        # Pull current contract metadata and quote, never trust AI sizing or stale metadata.
        instrument = self.api.public("/api/v5/public/instruments", instType="SWAP", instId=symbol)[0]
        if not (self.is_allowed_instrument(instrument) if hasattr(self, "is_allowed_instrument") else verified_altcoin(self.api, instrument)):
            raise BotError("허용된 암호화폐 USDT 선물이 아닙니다.")
        self.log('종목 분류 재확인: '+symbol+' / 자산 분류 '+str(instrument.get('instCategory')))
        frames = self.entry_context(symbol, result["action"])
        ticker = self.api.public("/api/v5/market/ticker", instId=symbol)[0]
        if not 0 <= self.api.now_ms() - int(ticker["ts"]) <= 10000:
            raise BotError("진입 시세가 오래됐습니다.")
        fee = self.api.taker_fee(instrument)
        plan = size_plan(instrument, self.allocation_seed(snapshot) if hasattr(self,"allocation_seed") else snapshot["equity"], snapshot["available"], leverage,
                         ticker["bidPx"], ticker["askPx"], fee, margin_cap=self.initial_margin_cap(snapshot) if hasattr(self, "initial_margin_cap") else self.margin_room(snapshot),
                         strict_initial=not frames.get('_v4',{}).get('channel4h730') and getattr(self,'cfg',{}).get('risk',{}).get('initial_size_mode') in ('fixed_third','fixed_half'),
                         initial_fraction=getattr(self,'cfg',{}).get('risk',{}).get('initial_margin_fraction'),
                         max_rounding_fraction=getattr(self,'cfg',{}).get('risk',{}).get('fixed_initial_max_rounding_fraction',.03),
                         band_flow=getattr(self,'cfg',{}).get('signals',{}).get('band_flow',{}).get('enabled',False))
        invalidation = dec(frames["_v4"]["stop"] if "_v4" in frames else invalidation_level(frames, direction))
        tick = dec(instrument["tickSz"])
        level = (invalidation / tick).to_integral_value(rounding=ROUND_UP if direction == "long" else ROUND_DOWN) * tick
        if (direction == "long" and level >= dec(ticker["bidPx"])) or (direction == "short" and level <= dec(ticker["askPx"])):
            self.log("진입 무효화 가격 도달. 추격 진입하지 않습니다.")
            return
        key = direction + "_stop"
        plan[key] = fmt(max(dec(plan[key]), level) if direction == "long" else min(dec(plan[key]), level))
        if hasattr(self, "prepare_entry_plan"):
            plan = self.prepare_entry_plan(plan, instrument, ticker, frames, direction, snapshot, fee)
        limits = self.api.get("/api/v5/account/max-size", instId=symbol, tdMode="isolated", leverage=str(leverage))[0]
        maximum = dec(limits["maxBuy"] if direction == "long" else limits["maxSell"])
        if dec(plan["quantity"]) > maximum:
            raise BotError(f"계정에서 허용하는 주문 수량 초과: 계획 {plan['quantity']}계약 / 거래소 한도 {fmt(maximum)}계약. 진입 생략.")
        if self.entry_cancel.is_set() or not self.within_session():
            self.log("사용자 중지 요청으로 진입 취소. 주문 없음.")
            return
        self.api.post("/api/v5/account/set-leverage", {
            "instId": symbol, "lever": str(leverage), "mgnMode": "isolated", "posSide": direction})
        lever_rows = self.api.get("/api/v5/account/leverage-info", instId=symbol, mgnMode="isolated")
        from okx_leverage738 import confirmed_leverage
        if not confirmed_leverage(lever_rows, symbol, direction, leverage):
            raise BotError("선택한 방향의 레버리지 설정을 확인할 수 없습니다. 주문하지 않습니다.")
        if self.entry_cancel.is_set() or not self.within_session():
            self.log("사용자 중지 요청으로 진입 취소. 레버리지 설정만 완료, 주문 없음.")
            return
        if hasattr(self, "pre_submit_check"):
            self.pre_submit_check(plan, instrument, direction)
        # Persist intent BEFORE sending order. Never lose an unknown order on restart.
        owned = {"symbol": symbol, "direction": direction, "leverage": leverage,
                 "quantity": plan["quantity"], "client_id": "OE" + uuid.uuid4().hex[:28],
                 "algo_client_id": "OS" + uuid.uuid4().hex[:28], "phase": "submitted",
                 "entry_order_type": "market", "planned_entry_px": plan["buy" if direction=="long" else "sell"],
                 "entry_ms": self.api.now_ms(), "stop_px": plan[direction + "_stop"], "posId": None}
        owned.update(entry_seed=fmt(snapshot["equity"]), committed_margin=plan["margin_bound"],
                     average_used=False, pyramid_used=False, entry_taker_fee=fmt(fee),
                     invalidation_px=fmt(level), peak_roe=0.,
                     api_total_at_entry=max(0, self.journal.data["api_total_spent"] - analysis_cost))
        if hasattr(self, "entry_metadata"):
            owned.update(self.entry_metadata(plan, frames))
        owned["legs"] = legs_for(owned)
        self.journal.data["owned"] = owned
        self.journal.save()
        self.invalidate()
        self.log(f"진입 요청: {symbol} {direction} {leverage}배 / {plan['quantity']}계약 / 시장가 / 격리 / 보호 손절 동반")
        body = protective_order(symbol, direction, leverage, plan, owned["client_id"], owned["algo_client_id"])
        try:
            self.api.post("/api/v5/trade/order", body)
        except Rejected:
            # Only explicit exchange rejection is safe to clear; timeouts retain intent.
            self.journal.data["owned"] = None
            self.journal.save()
            self.next_ai = time.monotonic() + 300
            raise

    def reserve_api(self, amount, epoch):
        with self.lock:
            if epoch != self.epoch or not (self.enabled or self.preview or self.journal.data["owned"]):
                raise BotError("상태가 변경되어 AI 요청을 취소했습니다.")
            today = day_key(self.api.now_ms())
            data = self.journal.data
            if data["api_day"] != today:
                data["api_day"], data["api_spent"], data["api_calls"] = today, 0.0, 0
            if data["api_spent"] + amount > self.budget:
                raise BotError("AI 일일 예산 부족")
            data["api_spent"] += amount
            data["api_total_spent"] += amount
            data["api_calls"] += 1
            self.journal.save()
            return today

    def submit_ai(self, snapshot, position):
        if self.future:
            return
        if time.monotonic() < self.next_ai:
            return
        if self.journal.data["owned"] and self.journal.data["owned"]["phase"] != "active":
            return
        self.next_ai = time.monotonic() + (POSITION_INTERVAL if position else ENTRY_INTERVAL)
        today = day_key(snapshot["ms"])
        if self.journal.data["api_day"] != today:
            self.journal.data["api_day"], self.journal.data["api_spent"], self.journal.data["api_calls"] = today, 0.0, 0
            self.journal.save()
        remaining = self.budget - self.journal.data["api_spent"]
        roi = self.strategy_roi(snapshot["equity"])
        self.future_epoch = self.epoch
        epoch = self.epoch
        # Copies prevent the analyzer from sharing mutable position state.
        ai_position = dict(position) if position else None
        if ai_position:
            ai_position["_owned"] = json.loads(json.dumps(self.journal.data["owned"]))
            ai_position["_owned"]["_available_margin_room"] = fmt(self.margin_room(snapshot))
        analysis_settings = dict(self.settings)
        analysis_settings.update(self.analysis_context())
        self.future = self.executor.submit(self.analyzer, analysis_settings, max(snapshot["equity"], Decimal("48")) if self.preview else snapshot["equity"],
                ai_position, roi, remaining, lambda amount: self.reserve_api(amount, epoch))
        self.log("차트·거래량 AI 분석 중. 보호 상태 확인은 별도로 계속합니다.")

    def accept_ai(self, snapshot, position):
        if not self.future or not self.future.done():
            return
        future, epoch = self.future, self.future_epoch
        self.future = self.future_epoch = None
        result = future.result()
        if result.get("reserved"):
            adjustment = result["cost"] - result["reserved"]
            self.journal.data["api_total_spent"] = max(0, self.journal.data["api_total_spent"] + adjustment)
            if result.get("billing_day") == self.journal.data["api_day"]:
                self.journal.data["api_spent"] = max(0.0, self.journal.data["api_spent"] + adjustment)
            self.journal.save()
        if result.get("no_candidates"):
            self.log("필터를 통과한 분석 후보 없음. 대기.")
            return
        decision = result["decision"]
        self.log("AI: " + decision["action"] + " / " + decision["symbol"] + " / " + decision["reason"])
        self.log("위험 요인: " + decision["risk"] + " / " + result["tokens"])
        if epoch != self.epoch or result["age"] > 60 or time.monotonic() - result["completed_monotonic"] > 20:
            self.log("상태 변경 또는 오래된 분석: 매매에 사용하지 않습니다.")
            return
        if self.preview:
            self.log("미리보기: 판단 출력만 완료. 주문 없음.")
            return
        action = decision["action"]
        # Fetching again at entry/close is essential; model output never directly reaches an order.
        if action == "CLOSE" and position:
            self.close(snapshot, "AI 차트 판단 청산")
        elif action in ("ADD_AVERAGE", "ADD_PYRAMID") and position and self.enabled:
            self.scale(action)
        elif action in ("LONG", "SHORT") and self.enabled and not position:
            self.entry(decision, result["instruments"], analysis_cost=result.get("cost", 0))

    def analysis_context(self):
        return {}

    def manage_charts(self, snapshot, position):
        owned = self.journal.data["owned"]
        if self.chart_future and self.chart_future.done():
            future, identity = self.chart_future, self.chart_identity
            self.chart_future = self.chart_identity = None
            try:
                frames, completed = future.result()
                if (owned and position and owned["phase"] == "active" and identity == owned["client_id"]
                        and time.monotonic() - completed < 45):
                    reason = chart_exit(frames, position)
                    if reason:
                        self.close(snapshot, reason)
            except Exception as error:
                self.log("고저점 차트 보호 조회 지연: " + type(error).__name__ + " / 가격 손절·수익 보호는 계속")
        if (owned and position and owned["phase"] == "active" and self.chart_future is None
                and time.monotonic() >= self.next_chart):
            self.next_chart = time.monotonic() + CHART_INTERVAL
            settings, symbol = dict(self.settings), owned["symbol"]
            def read():
                api = OKX(settings)
                try:
                    return load_frames(api, symbol), time.monotonic()
                finally:
                    api.session.close()
            self.chart_identity = owned["client_id"]
            self.chart_future = self.chart_executor.submit(read)

    def within_session(self):
        session = self.journal.data.get("session")
        return bool(session and not session["ended"] and (session.get("continuous") or self.api.now_ms() < session["end_ms"]))

    def strategy_roi(self, equity):
        roi = self.journal.daily_return(equity)
        day = self.journal.data["day"]
        if roi is not None and self.journal.data["api_day"] == day["date"]:
            roi -= dec(self.journal.data["api_spent"]) / dec(day["base"])
        return roi

    def tick(self):
        snapshot = self.snapshot()
        session = self.journal.data.get("session")
        if session and not session.get("continuous") and not session["ended"] and snapshot["ms"] >= session["end_ms"]:
            session["ended"] = True
            self.journal.save()
            self.pause("설정한 신규 진입 허용시간 종료: 보유분 유지·능동 관리 계속")
        # Manage known orders after crashes even when automatic entry is disabled.
        position = self.reconcile(snapshot) if self.journal.data["owned"] else None
        if self.journal.data["owned"] is None:
            owned_position(None, snapshot["positions"])
        if self.enabled or self.journal.data["owned"]:
            if self.journal.roll_day(snapshot["ms"], snapshot["equity"], initialize=self.enabled):
                self.invalidate()
                self.next_ai = 0
                self.log("한국시간 거래일 기준 갱신.")
            day = self.journal.data["day"]
            if day:
                bills = self.api.get("/api/v5/account/bills", ccy="USDT", type="1", begin=str(day["started_ms"]), limit="100")
                if len(bills) >= 100:
                    raise BotError("입출금 보정 내역을 모두 확인할 수 없습니다.")
                self.journal.apply_transfers(bills)
                self.last_flow = time.monotonic()
            roi = self.strategy_roi(snapshot["equity"])
            owned = self.journal.data["owned"]
            if owned and position and owned["phase"] == "active" and owned.get("close_requested"):
                self.close(snapshot, owned["close_requested"])
            if roi is not None and roi >= DAILY_CAP and not self.journal.data["day"]["ended"]:
                self.journal.data["day"]["ended"] = True
                self.journal.save()
                self.invalidate()
                self.log("일일 +200% 도달: 오늘 신규/추가 진입 중지, 보유분은 유지·관리합니다.")
            if position and owned and owned["phase"] == "active":
                reason = quick_exit(owned, position)
                self.journal.save()
                if reason:
                    self.close(snapshot, reason)
                elif dec(position["uplRatio"]) <= STOP_ROE:
                    self.close(snapshot, "포지션 수익률 -30% 손절")
                else:
                    mine, other = self.algos()
                    if other:
                        raise BotError("기록되지 않은 조건주문 발견. 신규 진입 중지.")
                    def is_protected(leg):
                        try:
                            matching = [row for row in mine if row.get("algoClOrdId") == leg["algo_client_id"]]
                            if len(matching) != 1:
                                return False
                            row = matching[0]
                            return (row.get("state") == "live" and dec(row.get("slTriggerPx")) == dec(leg["stop_px"])
                                    and row.get("slTriggerPxType") == "mark" and row.get("slOrdPx") == "-1"
                                    and ((len(legs_for(owned)) == 1 and row.get("closeFraction") == "1") or dec(row.get("sz") or "0") == dec(leg["quantity"])))
                        except (BotError, ArithmeticError, TypeError, ValueError):
                            return False
                    legs = legs_for(owned)
                    protected = sum(dec(leg["quantity"]) for leg in legs) == dec(owned["quantity"]) and all(is_protected(leg) for leg in legs)
                    if protected and not owned.get("protection_verified"):
                        owned["protection_verified"] = True
                        self.journal.save()
                        self.log("거래소 보호 손절 등록 확인: " + owned["symbol"] + " / 마크가격 " + owned["stop_px"] + " 도달 시 시장가 청산")
                    if not protected and self.api.now_ms() - owned["entry_ms"] > 15000:
                        self.pause("거래소 보호 손절 등록을 확인할 수 없음")
                        self.close(snapshot, "보호 주문 미확인으로 청산")
            # Canceling or changing ordinary orders externally must stop further entry.
            if snapshot["orders"] and (not owned or owned["phase"] not in ("submitted", "adding", "closing")):
                raise BotError("기존 일반 미체결 주문 발견.")
        self.manage_charts(snapshot, position)
        self.accept_ai(snapshot, position)
        owned = self.journal.data["owned"]
        day_ended = bool(self.journal.data["day"] and self.journal.data["day"]["ended"])
        if (self.preview or (not day_ended and self.enabled) or (owned and owned["phase"] == "active")):
            self.submit_ai(snapshot, position)
        self.publish(snapshot, position)

    def publish(self, snapshot, position):
        owned = self.journal.data["owned"]
        day = self.journal.data["day"]
        roi = self.strategy_roi(snapshot["equity"])
        mode = "미리보기(주문 없음)" if self.preview else "실거래 가동" if self.enabled else "신규 진입 정지"
        if day and day["ended"]:
            mode += " / 오늘 신규 진입 상한 도달(보유 관리 계속)"
        session = self.journal.data.get("session")
        if session and session.get("continuous"):
            mode += " / 시간 제한 없는 연속 운용"
        elif session:
            mode += " / 신규 진입 시간 종료(보유 관리 계속)" if session["ended"] else " / 신규 종료 " + datetime.fromtimestamp(session["end_ms"] / 1000, KST).strftime("%m-%d %H:%M")
        if owned:
            mode += " / " + owned["phase"]
        if self.last_error:
            mode += " / 확인 필요"
        self.events.put(("status", {"mode": mode, "equity": fmt(snapshot["equity"]),
            "available": fmt(snapshot["available"]), "roi": None if roi is None else float(roi),
            "base": day["base"] if day else None, "position": None if not position else
                f"{position['instId']} {position['posSide']} / {float(dec(position['uplRatio'])) * 100:.2f}% / "
                + ("거래소 손절 확인" if owned and owned.get("protection_verified") else "보호 확인 중"),
            "owned": bool(owned), "api_spent": self.journal.data["api_spent"],
            "api_calls": self.journal.data["api_calls"], "updated": datetime.now(KST).strftime("%H:%M:%S"),
            "live": self.enabled, "preview": self.preview, "error": self.last_error}))

    def handle(self, action, kwargs):
        if action == "live":
            self.activate(kwargs["equity"], kwargs["budget"], kwargs.get("hours", 24))
        elif action == "preview":
            if self.journal.data["owned"]:
                raise BotError("기록된 포지션이 있어 미리보기로 전환할 수 없습니다.")
            self.enabled, self.preview = False, True
            self.budget = float(kwargs["budget"])
            if not 0.01 <= self.budget <= 5:
                self.preview = False
                raise BotError("AI 예산 범위는 0.01~5달러입니다.")
            self.invalidate()
            self.next_ai = 0
            self.log("미리보기 시작. 5분 간격 AI 분석 / 주문·레버리지 변경 없음.")
        elif action == "pause":
            self.pause("사용자가 신규 진입 중지")
        elif action == "close":
            self.pause("사용자가 보유분 청산 후 중지 요청")
            self.close(self.snapshot(), "사용자 청산 요청")
        elif action == "refresh":
            self.log("현재 잔고와 주문 상태를 다시 조회합니다.")
        elif action == "quit":
            if self.journal.data["owned"]:
                raise BotError("진행 중 주문/포지션 기록이 있습니다. 청산 확인 후 창을 닫으세요.")
            self.stop_event.set()
            self.events.put(("quit", None))

    def run(self):
        while not self.stop_event.is_set():
            try:
                with self.lock:
                    while not self.commands.empty():
                        action, kwargs = self.commands.get_nowait()
                        self.handle(action, kwargs)
                    if not self.stop_event.is_set():
                        self.tick()
                    self.last_error = None
            except Exception as error:
                message = str(error) if isinstance(error, BotError) else "실행 오류 종류: " + type(error).__name__
                if message != self.last_error:
                    self.pause(message)
                self.last_error = message
                self.events.put(("error", message))
            self.stop_event.wait(3)
        self.executor.shutdown(wait=False, cancel_futures=True)
        self.chart_executor.shutdown(wait=False, cancel_futures=True)

"""Run on the user's PC. Configures private Serve only; never uses exchange credentials."""
import getpass,json,os,shutil,subprocess,sys,webbrowser
from pathlib import Path
from okx_mobile import credential,valid_config
ROOT=Path(__file__).resolve().parent

def find_tailscale():
 candidates=[shutil.which('tailscale'),str(Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Tailscale/tailscale.exe')]
 return next((p for p in candidates if p and Path(p).is_file()),None)

def main():
 print('OKX 휴대폰 접속 설정 (운용 제어는 로그인/확인 후)\nPC와 iPhone에 Tailscale을 설치하고 같은 계정으로 로그인하세요.\nWindows: https://tailscale.com/download/windows\niPhone: https://tailscale.com/download/ios\n')
 cli=find_tailscale()
 if not cli:raise ValueError('PC에 Tailscale 설치 후 이 파일을 다시 실행하세요.')
 status=json.loads(subprocess.check_output([cli,'status','--json'],timeout=15,encoding='utf-8'))
 dns=str(status.get('Self',{}).get('DNSName','')).rstrip('.')
 config={'enabled':True,'https_host':dns+':8443',**credential('temporary-password-replaced')}
 if status.get('BackendState')!='Running' or not valid_config(config):raise ValueError('Tailscale 로그인과 연결 상태를 확인하세요.')
 existing=subprocess.run([cli,'serve','status','--json'],capture_output=True,text=True,timeout=15)
 if existing.returncode:raise ValueError('Tailscale Serve 상태를 읽지 못했습니다.')
 old=json.loads(existing.stdout or '{}')
 own=old.get('Web',{}).get(config['https_host'],{}).get('Handlers',{}).get('/',{}).get('Proxy')=='http://127.0.0.1:8766'
 if '8443' in old.get('TCP',{}) and not own:raise ValueError('8443에 다른 서비스가 있습니다. 기존 설정을 변경하지 않았습니다.')
 for host,paths in old.get('Web',{}).items():
  if host.endswith(':8443') and any(v.get('Proxy')!='http://127.0.0.1:8766' for v in paths.get('Handlers',{}).values()):raise ValueError('8443에 다른 서비스가 있습니다. 기존 설정을 변경하지 않았습니다.')
 password=getpass.getpass('모바일 접속 전용 비밀번호 (12~128자): ')
 if not 12<=len(password)<=128:raise ValueError('비밀번호는 12~128자로 입력하세요.')
 if password!=getpass.getpass('비밀번호 다시 입력: '):raise ValueError('비밀번호가 일치하지 않습니다.')
 config.update(credential(password));target=ROOT/'mobile_access.json';temp=target.with_suffix('.tmp');temp.write_text(json.dumps(config,ensure_ascii=False),encoding='utf-8');temp.replace(target)
 try:os.chmod(target,0o600)
 except OSError:pass
 print('\n개인 기기용 HTTPS 연결을 설정합니다. HTTPS 활성화 안내가 나오면 본인 계정에서 승인하세요.\n')
 result=subprocess.run([cli,'serve','--bg','--https=8443','http://127.0.0.1:8766'],timeout=180)
 if result.returncode:raise ValueError('HTTPS 설정이 완료되지 않았습니다. 안내를 확인하고 이 파일을 다시 실행하세요.')
 url='https://'+config['https_host']
 (ROOT/'MOBILE_ADDRESS.txt').write_text(url+'\n같은 Tailscale 계정의 휴대폰에서 접속하세요. 로그인 비밀번호는 설정 때 입력한 값입니다.\n',encoding='utf-8')
 print('\n설정 완료. PC 매매 프로그램을 정상 종료 후 다시 실행하세요.\n휴대폰 Tailscale 연결 → Safari에서 아래 주소 입력 → 비밀번호 로그인\n\n'+url+'\n\n주소는 MOBILE_ADDRESS.txt에도 저장했습니다. Safari 공유 → 홈 화면에 추가로 앱처럼 열 수 있습니다.\n집 PC와 프로그램, Tailscale을 계속 켜 두세요. 이 설정은 실거래 시작을 누르지 않습니다.')
if __name__=='__main__':
 try:main()
 except (ValueError,OSError,subprocess.SubprocessError) as exc:print('\n설정 확인: '+str(exc));sys.exit(1)

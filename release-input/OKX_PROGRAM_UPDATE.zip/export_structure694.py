"""Optional public OHLCV only; no account, credentials, AI or orders."""
import argparse,json,time,math
from pathlib import Path
import requests
STEPS={'15m':900000,'1H':3600000,'4H':14400000}
def export(symbol,days,fee,spread,slippage):
 if not symbol.endswith('-USDT-SWAP') or not 15<=days<=365 or any(not math.isfinite(x) or x<0 for x in (fee,spread,slippage)):raise ValueError('invalid symbol/days/rates')
 session=requests.Session();r=session.get('https://www.okx.com/api/v5/public/time',timeout=15);r.raise_for_status();now=int(r.json()['data'][0]['ts']);start=now-days*86400000;frames={}
 for frame,step in STEPS.items():
  since=start-260*step;cursor=now;rows_by_ts={}
  while cursor>since:
   for retry in range(3):
    try:
     r=session.get('https://www.okx.com/api/v5/market/history-candles',params={'instId':symbol,'bar':frame,'limit':'100','after':str(cursor)},timeout=15);r.raise_for_status();data=r.json()
     if data.get('code')!='0':raise RuntimeError('history rejected '+str(data.get('code')))
     break
    except (requests.RequestException,RuntimeError):
     if retry==2:raise
     time.sleep(1+retry)
   rows=data['data']
   if not rows:break
   oldest=min(int(v[0]) for v in rows)
   if oldest>=cursor:raise RuntimeError('pagination stalled')
   for v in rows:
    ts=int(v[0])
    if v[8]=='1' and ts+step<=now and ts>=since:rows_by_ts[ts]=[ts]+[float(x) for x in v[1:6]]
   cursor=oldest;time.sleep(.15)
  frames[frame]=[rows_by_ts[t] for t in sorted(rows_by_ts)]
  if len(frames[frame])<260:raise RuntimeError(frame+' history insufficient')
  print(frame,len(frames[frame]),'closed bars')
 return dict(symbol=symbol,exported_ms=now,evaluation_start_ms=start,fee_rate=fee,spread_rate=spread,slippage_rate=slippage,cost_assumption='User supplied scenarios, not observed historical execution',funding=[],funding_status='Not fetched: supply historical funding to include',candles=frames)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--symbol',required=True);p.add_argument('--days',type=int,default=90);p.add_argument('--fee-rate',type=float,required=True);p.add_argument('--spread-rate',type=float,required=True);p.add_argument('--slippage-rate',type=float,required=True);p.add_argument('--output',default='candles694.json');a=p.parse_args();Path(a.output).write_text(json.dumps(export(a.symbol,a.days,a.fee_rate,a.spread_rate,a.slippage_rate)),encoding='utf-8');print(a.output)

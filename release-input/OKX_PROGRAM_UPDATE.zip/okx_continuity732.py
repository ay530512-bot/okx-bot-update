"""Persist operator intent; resume only after the existing reconciliation checks.

No exchange writes here. A restored intent is never an entry authorization.
The engine must complete account/order/SL checks before re-activation and again
before opening. Explicit pause/close-all/quit/preview always cancel the intent.
"""
import hashlib
import json
import time


KEY = 'entry_continuity732'


def policy_hash(e):
    cfg = {k: v for k, v in e.cfg.items() if k != 'version'}
    return hashlib.sha256(json.dumps(cfg, sort_keys=True, separators=(',', ':'),
                                     ensure_ascii=False).encode()).hexdigest()


def exchange(e):
    return str(e.settings.get('TRADING_EXCHANGE') or 'okx').lower()


def clean(e, reason):
    text = str(reason)
    for k, v in e.settings.items():
        if v and any(t in k.upper() for t in ('KEY', 'SECRET', 'PASS', 'TOKEN', 'CHAT_ID')):
            text = text.replace(str(v), '[숨김]')
    return text[:500]


def record(e, event, reason):
    reason = clean(e, reason)
    row = e.journal.data.setdefault(KEY, {})
    row.update(schema=1, requested=bool(e.run_requested), event=event,
               reason=reason, ms=int(time.time()*1000))
    history = row.setdefault('history', [])
    history.append(dict(event=event, reason=reason, ms=row['ms']))
    row['history'] = history[-100:]
    e.journal.save()
    e.log('진입 운용 상태 / ' + event + ' / ' + reason)


def initialize(e):
    row = e.journal.data.get(KEY) or {}
    e.run_requested = False
    e.resume_pending = False
    e.resume_reason = row.get('reason') or '시작 기록 없음 · 실거래 시작 필요'
    if row.get('schema') == 1 and row.get('requested') is True:
        same = (bool(row.get('account')) and row['account'] == e.journal.data.get('account')
                and row.get('exchange') == exchange(e) and row.get('policy_hash') == policy_hash(e))
        if same and e.cfg.get('execution', {}).get('continuous_trading'):
            e.run_requested = e.resume_pending = True
            e.user_paused = False
            e.resume_reason = '이전 가동 상태 복구 · 계정·미체결·보호SL 대조 중'
            e.budget = float(row.get('budget', e.budget))
            e.entry_cancel.set()
            e.log(e.resume_reason)
        else:
            e.resume_reason = '계정 또는 설정 변경 · 실거래 시작으로 다시 확인 필요'
    publish(e)


def started(e):
    e.run_requested = True
    e.resume_pending = False
    e.resume_reason = ''
    e.journal.data.setdefault(KEY, {}).update(account=e.journal.data.get('account'),
        exchange=exchange(e), policy_hash=policy_hash(e), budget=e.budget)
    record(e, 'started', '사용자가 시작한 연속 운용 · 일시 오류 해소 후 자동 재개')
    publish(e)


def stopped(e, reason):
    e.run_requested = e.resume_pending = False
    e.entry_cancel.set()
    e.enabled = False
    e.user_paused = True
    e.resume_reason = clean(e, reason)
    record(e, 'operator_stop', reason)
    publish(e)


def suspended(e, reason):
    e.resume_reason = clean(e, reason)
    e.resume_pending = bool(getattr(e, 'run_requested', False))
    e.user_paused = not e.resume_pending
    e.recovering = True
    e.good_snapshots = 0
    if e.resume_pending:
        record(e, 'recovery_wait', reason)
    publish(e)


def status(e):
    pending = bool(getattr(e, 'resume_pending', False))
    return dict(live=bool(e.enabled), user_paused=bool(e.user_paused),
                run_requested=bool(getattr(e, 'run_requested', False)),
                resume_pending=pending, pause_reason=getattr(e, 'resume_reason', ''))


def publish(e):
    e.events.put(('entry_control', status(e)))


def resume_if_ready(e):
    if not (e.resume_pending and e.run_requested) or e.enabled or e.preview or e.user_paused:
        return False
    if not e.commands.empty() or e.stop_event.is_set():
        return False
    if (not e.account_stream.fresh() or not e.stream.connected or e.recovering
            or e.good_snapshots < e.cfg['execution']['recovery_snapshots']):
        return False
    if e.queued_risks or not e.risk_queue.empty() or (e.journal.data.get('day') or {}).get('ended'):
        return False
    if (e.journal.data.get('manual_closes716') or getattr(e, 'click_pending716', None)
            or getattr(e, 'approval', None)):
        return False
    # Reconcile may be waiting for partial fills/protection without raising.
    for o in e.records():
        if (o.get('phase') != 'active' or o.get('close_requested') or o.get('pending_add')
                or o.get('market_fill_check_pending')):
            return False
    row = e.journal.data.get(KEY) or {}
    if (row.get('account') != e.journal.data.get('account') or row.get('exchange') != exchange(e)
            or row.get('policy_hash') != policy_hash(e)):
        e.resume_reason = '계정 또는 설정 변경 · 실거래 시작으로 다시 확인 필요'
        publish(e)
        return False
    # Fresh REST account identity and every live SL are checked again. A prior
    # protection_verified flag is not evidence of current exchange protection.
    snap = e.snapshot()
    if snap.get('orders'):
        return False
    from okx_core import owned_position
    for slot in range(e.slot_count()):
        with e.selected(slot):
            o = e.journal.data['owned']
            if o:
                slot_snap = e.snapshot()
                p = owned_position(o, slot_snap['positions'])
                if not p or not e.verify_protection(slot_snap, p, o):
                    return False
    reason = e.resume_reason
    e.activate(snap['equity'], e.budget, 24)
    # activate keeps entry_cancel set until another complete reconciliation.
    record(e, 'auto_resumed', '계정·주문·SL 대조 통과 / 이전 대기: ' + reason)
    return True

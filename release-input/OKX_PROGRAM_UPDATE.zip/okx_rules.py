"""Causal closed-bar rules. No order execution and no future pivot information."""
import json
import math
import statistics
import hashlib
from pathlib import Path
from okx_market import ema, rsi
from okx_core import BotError


def load_config(root):
    c = json.loads((Path(root) / 'strategy_config.json').read_text(encoding='utf-8-sig'))
    if c.get('execution',{}).get('pattern15_only'):
        from okx_pattern15 import validate_config
        validate_config(c);return c
    if c['indicators']['ma_type'] != 'SMA' or c['indicators']['ma_periods'] != [15,20,50,100,120,200]:
        raise BotError('SMA15/20/50/100/120/200 설정이 필요합니다.')
    def check_numbers(value):
        if isinstance(value, dict):
            for v in value.values(): check_numbers(v)
        elif isinstance(value, list):
            for v in value: check_numbers(v)
        elif isinstance(value, (float, int)) and not math.isfinite(value):
            raise BotError('설정에 유효하지 않은 수치가 있습니다.')
    check_numbers(c)
    from okx_oct23 import settings as oct_settings,validate as oct_validate
    from okx_free_ai import settings as free_settings,validate as free_validate
    if not oct_validate(oct_settings(c)) or not free_validate(free_settings(c)):raise BotError('10월23일/AI5배 프로필 설정 오류')
    from okx_flow_structure import settings as flow_settings,validate as flow_validate
    if not flow_validate(flow_settings(c)):raise BotError('재상승/재하락 실패 구조 설정 오류')
    from okx_research_entry import settings as research_settings,validate as research_validate
    if not research_validate(research_settings(c)):raise BotError('리서치 기반 새 진입 설정 오류')
    from okx_kst_turnover import settings as turnover_settings,validate as turnover_validate
    if not turnover_validate(turnover_settings(c)):raise BotError('한국시간 거래대금 순위 설정 오류')
    from okx_double_retest import settings as retest_settings,validate as retest_validate
    if not retest_validate(retest_settings(c)):raise BotError('쌍고점·쌍저점 재시험 설정 오류')
    from okx_dynamic_exit import settings as dynamic_settings,validate as dynamic_validate
    if not dynamic_validate(dynamic_settings(c)):raise BotError('동적 추세 청산 설정 오류')
    from okx_trend_entry import settings as trend_settings,validate as trend_validate
    if not trend_validate(trend_settings(c)):raise BotError('추세 지지/저항 OR 진입 설정 오류')
    from okx_wave_mode import settings as wave_settings,validate as wave_validate
    if not wave_validate(wave_settings(c)):raise BotError('쌍고점/쌍저점 파동 설정 오류')
    from okx_budget_pacing import settings as pace_settings,enabled as pace_enabled,validate as pace_validate
    if pace_enabled(c) and not pace_validate(pace_settings(c)):raise BotError('24시간 AI 예산 설정 오류')
    from okx_model_runtime import settings as model_settings,enabled as model_enabled,validate as model_validate
    if model_enabled(c) and not model_validate(model_settings(c)):raise BotError('AI 모델/요금 설정 오류')
    if type(c.get('execution',{}).get('continuous_trading',False)) is not bool:raise BotError('연속 운용 설정 오류')
    from okx_swing_context import settings as swing_settings,validate as swing_validate
    if not swing_validate(swing_settings(c)):raise BotError('고저점 구조 설정 오류')
    from okx_autonomous import settings as auto_settings, validate as auto_validate
    if not auto_validate(auto_settings(c)):raise BotError('자율 스캘핑 설정 오류')
    from okx_band_flow import enabled as band_enabled,settings as band_settings,validate as band_validate
    band=band_enabled(c)
    if band and not band_validate(band_settings(c)):raise BotError('밴드·거래량 진입 설정 오류')
    s, r, l, i = c['signals'], c['risk'], c['liquidity'], c['indicators']
    se,e=c['selection'],c['execution']
    valid=(2<=i['bb_period']<=200 and 0<i['bb_multiplier']<=10
        and i['frames']==['5m','15m','1H','4H'] and i['rsi_periods']==[6,14,24]
        and type(r['leverage']) is int and 3<=r['leverage']<=10
        and 3<=r['min_leverage']<=r['max_leverage']<=10 and r['leverage_mode'] in ('auto','fixed')
        and -.21<=r['daily_stop']<0 and 0<r['daily_cap']<=10 and -.30<=r['final_stop_roe']<0
        and r.get('initial_size_mode','up_to_third') in ('up_to_third','fixed_third','fixed_half')
        and 0<r.get('fixed_initial_max_rounding_fraction',.03)<=.05
        and (r.get('initial_size_mode')!='fixed_third' or abs(r['initial_margin_fraction']-1/3)<1e-12)
        and type(r.get('max_positions',2)) is int and r.get('max_positions',2)>=0
        and (r.get('initial_size_mode')!='fixed_half' or (e.get('free_ai',{}).get('enabled') and abs(r['initial_margin_fraction']-.5)<1e-12))
        and 0<r['partial_fraction']<1 and 0<r['initial_margin_fraction']<=(.5 if r.get('initial_size_mode')=='fixed_half' else 1/3)
        and 0<r['dynamic_add_room_min_fraction']<=r['dynamic_add_room_max_fraction']<=1 and 0<r['max_total_margin_fraction']<=(1 if band else 2/3)
        and r['initial_margin_fraction']<=r['max_position_margin_fraction']<=(1 if band else 2/3)
        and 0<r['max_position_loss_fraction']<=r['max_open_stop_loss_fraction']<=(1 if band else .21)
        and 0<r['max_total_notional_fraction']<=r['max_total_margin_fraction']*(30 if band else r['max_leverage'])+.000001
        and r['additions_by_confirmation'] is True and r['profit_review_roe']>0 and r['protected_profit_roe']>=0
        and r['min_reward_risk']>0 and r['trailing_atr']>0 and 0<r['liquidation_buffer']<.2
        and 0<l['max_spread']<=.01 and 0<l['max_slippage']<=.01 and 0<l['depth_band']<=.01
        and l['depth_multiple']>=1 and 0<l['max_book_age_ms']<=10000 and l['ws_max_age_seconds']>0
        and s['retest_max_gap']>s['retest_min_gap']>2 and s['pivot_wing']>=1
        and s['wick_body_ratio']>0 and s['wick_atr']>0 and s['zone_atr']>0 and s['follow_atr']>0
        and s['band_return_buffer_atr']>=0 and s['ma_confluence_atr']>0
        and set(s['priority'])=={'band_rejection','failed_retest','trend_pullback','breakout_retest'} and len(s['priority'])==4
        and 30<=se['volume_history_bars']<=290 and 1<=se['volume_recent_bars']<=10
        and se['volume_history_bars']+se['volume_recent_bars']<299 and se['refresh_seconds']>=30
        and 1<=se['focus_count']<=15 and se['turnover_top_n']>=1 and 0<=se['volume_percentile']<=100
        and se.get('mode','turnover_or_volume') in ('turnover_or_volume','hourly_volume','scalp_volume','kst09_movers')
        and se.get('volume_timeframe','5m') in ('5m','1H')
        and (se.get('mode')!='hourly_volume' or se.get('volume_timeframe')=='1H')
        and (se.get('mode')!='scalp_volume' or (se.get('volume_timeframe')=='5m' and s.get('wick15',{}).get('scalp_enabled') is True))
        and type(s.get('trend_only',False)) is bool
        and type(se.get('volume_growth_required',True)) is bool
        and se['relative_volume']>0 and se['volume_growth']>0 and 0<se['rest_requests_per_second']<=12
        and se['min_listing_days']>=1 and 0<se['max_bar_return']<1 and 0<se['max_atr_fraction']<1
        and 1<=s['slope_bars']<=20 and e['recovery_snapshots']>=2
        and type(e.get('manual_coexist',False)) is bool
        and e['chart_refresh_seconds']>=5 and e['signal_max_age_seconds']>0)
    if se.get('mode')=='kst09_movers':
        valid=valid and (type(se.get('gainers_count')) is int and type(se.get('losers_count')) is int
            and 1<=se['gainers_count']<=15 and 1<=se['losers_count']<=15
            and se['gainers_count']+se['losers_count']==se['focus_count'])
    if 'reversal_profit' in r:
        rp=r['reversal_profit']
        try:
            rp_ok=(type(rp['enabled']) is bool and 0<rp['partial_fraction']<1
                and rp['timeframe'] in ('1m','5m','15m') and 0<rp['wick_body_ratio']<=10
                and 0<rp['wick_range_fraction']<1 and 0<rp['wick_atr']<=5 and 0<rp['reaction_atr']<=1)
        except (KeyError,TypeError):rp_ok=False
        if not rp_ok:raise BotError('수익 반전 부분 청산 설정 범위 오류')
    gap=s.get('direction_conflict_gap',2)
    valid=valid and isinstance(gap,(int,float)) and not isinstance(gap,bool) and 0<gap<=10
    if not valid:raise BotError('전략 설정 범위를 확인해주세요.')
    if s.get('entry_mode','legacy') not in ('legacy','wick15'):raise BotError('진입 모드 오류')
    if s.get('entry_mode')=='wick15':
        from okx_wick import validate
        try:valid_wick=validate(s['wick15'])
        except (KeyError,TypeError):valid_wick=False
        if not valid_wick:raise BotError('15m 꼬리 진입 설정 범위를 확인해주세요.')
    if 'trend_tail' in s:
        from okx_trend_tail import validate as validate_tail
        try: tail_ok=validate_tail(s['trend_tail'])
        except (KeyError,TypeError):tail_ok=False
        if not tail_ok:raise BotError('추세 눌림 꼬리 설정 범위를 확인해주세요.')
    if 'support_entries' in s:
        from okx_support import validate as validate_support
        try:support_ok=validate_support(s['support_entries'])
        except (KeyError,TypeError):support_ok=False
        if not support_ok or s.get('strategy_logic')!='OR':raise BotError('독립 지지 진입 설정 범위 오류')
    if 'ai_cost_control' in e:
        from okx_ai_cost import validate as validate_ai_cost
        try:cost_ok=validate_ai_cost(e['ai_cost_control'])
        except (KeyError,TypeError):cost_ok=False
        if not cost_ok:raise BotError('AI 호출 절약 설정 범위 오류')
    if 'fast_entries' in s:
        from okx_fast_entries import validate as validate_fast
        try:fast_ok=validate_fast(s['fast_entries'])
        except (KeyError,TypeError):fast_ok=False
        if not fast_ok:raise BotError('꼬리 추세 전환·스캘핑 설정 범위 오류')
    if 'context_entries' in s:
        from okx_context_entries import validate as validate_context
        try:context_ok=validate_context(s['context_entries'])
        except (KeyError,TypeError):context_ok=False
        if not context_ok:raise BotError('상위 시간봉 배경 진입 설정 범위 오류')
    if 'entry_pipeline' in e:
        v=e['entry_pipeline']
        try:ok=type(v['enabled']) is bool and 60<=v['funding_max_age_seconds']<=600 and 0<=v['estimated_cost_rate']<=.02 and l['ws_max_age_seconds']<=l.get('trade_max_age_seconds',l['ws_max_age_seconds'])<=120
        except (KeyError,TypeError):ok=False
        if not ok:raise BotError('진입 경로 캐시·펀딩·예상비용 설정 범위 오류')
    if 'case_entries' in s:
        from okx_case_entries import validate as validate_case
        try:case_ok=validate_case(s['case_entries'])
        except (KeyError,TypeError):case_ok=False
        if not case_ok:raise BotError('사례 참고 독립 진입 설정 범위 오류')
    if 'short_support_exit' in s:
        from okx_short_exit import validate as validate_short_exit
        try:exit_ok=validate_short_exit(s['short_support_exit'])
        except (KeyError,TypeError):exit_ok=False
        if not exit_ok:raise BotError('숏 지지 회복 청산 설정 범위 오류')
    return c


def metrics(bars, c):
    if len(bars) < max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+1: raise ValueError('MA200 및 기울기 계산 이력 부족')
    close = [b[4] for b in bars]
    n = c['indicators']['bb_period']; k = c['indicators']['bb_multiplier']
    shift = c['signals']['slope_bars']
    def band(v):
        mid = statistics.mean(v[-n:]); sd = statistics.pstdev(v[-n:])
        return mid, mid+k*sd, mid-k*sd
    mid, upper, lower = band(close)
    pmid, pup, plow = band(close[:-shift])
    atr_values = [max(b[2]-b[3], abs(b[2]-a[4]), abs(b[3]-a[4])) for a,b in zip(bars,bars[1:])]
    atr = statistics.mean(atr_values[-14:])
    if atr <= 0: raise ValueError('ATR가 0입니다.')
    ma = {p: statistics.mean(close[-p:]) for p in c['indicators']['ma_periods']}
    slopes = {p: (ma[p]-statistics.mean(close[-p-shift:-shift]))/atr for p in ma}
    previous_widths=[]
    for offset in range(1,21):
        _,u,l=band(close[:-offset]);previous_widths.append(u-l)
    width_ratio=(upper-lower)/statistics.mean(previous_widths) if statistics.mean(previous_widths)>0 else 1
    volume = statistics.mean(b[5] for b in bars[-21:-1])
    return dict(ma=ma, slopes=slopes, mid=mid, upper=upper, lower=lower,
                width=upper-lower, width_ratio=width_ratio, squeeze=width_ratio<c['signals']['squeeze_ratio'], expansion=(upper-lower)/(pup-plow) if pup>plow else 1,
                mid_slope=(mid-pmid)/atr, atr=atr, close=close[-1],
                rsi={p:rsi(close,p) for p in (6,14,24)},
                relative_volume=bars[-1][5]/volume if volume else 0)


def pivots(bars, c):
    """Return timestamp AND confirmation timestamp. Right wing must already be closed."""
    wing = c['signals']['pivot_wing']; result=[]
    start=max(wing,len(bars)-c['signals']['pivot_lookback'])
    for idx in range(start,len(bars)-wing):
        group=bars[idx-wing:idx+wing+1]
        for kind,col,fn in (('support',3,min),('resistance',2,max)):
            if bars[idx][col] == fn(b[col] for b in group) and sum(b[col]==bars[idx][col] for b in group)==1:
                result.append(dict(kind=kind, price=bars[idx][col], index=idx,
                                   time=bars[idx][0], confirmed=bars[idx+wing][0]))
    return result


def regime(m,c):
    s=c['signals']; ma=m['ma']; gap=(ma[20]-ma[50])/m['atr']
    bull=ma[15]>ma[20]>ma[50] and m['slopes'][20]>s['trend_slope_atr'] and m['mid_slope']>0
    bear=ma[15]<ma[20]<ma[50] and m['slopes'][20]<-s['trend_slope_atr'] and m['mid_slope']<0
    if bull and gap>s['trend_ma_gap_atr']: return 'uptrend'
    if bear and gap<-s['trend_ma_gap_atr']: return 'downtrend'
    if abs(m['mid_slope'])<=s['range_slope_atr'] and abs(gap)<s['strong_trend_gap_atr']: return 'range'
    return 'unclear'


def wick(bar, atr, direction, c):
    o,h,l,cl=bar[1:5]; body=abs(cl-o)
    length=min(o,cl)-l if direction=='LONG' else h-max(o,cl)
    return length>=max(body*c['signals']['wick_body_ratio'],atr*c['signals']['wick_atr'])


def signal(b5,b15,c,higher=None):
    """One consolidated signal per symbol/bar. Conflicting directions always WAIT."""
    if c['signals'].get('entry_mode')=='wick15':
        from okx_wick import decision
        return decision(b15,higher or {},c,b5=b5)
    m5,m15=metrics(b5,c),metrics(b15,c)
    s=c['signals']; market=regime(m15,c); atr=m5['atr']; z=atr*s['zone_atr']
    prev,last=b5[-2:]; pm=metrics(b5[:-1],c)
    levels=zones(b15,c); hits=[]
    extra={name:metrics(bars,c) for name,bars in (higher or {}).items()}
    if s.get('trend_only') and market not in ('uptrend','downtrend'):
        return None,'추세 미확정: 횡보·불명확 구간 신규 진입 대기'
    for direction in ('LONG','SHORT'):
        sign=1 if direction=='LONG' else -1
        trend='uptrend' if sign==1 else 'downtrend'
        if s.get('trend_only') and market!=trend: continue
        if s.get('trend_only') and '1H' in extra and regime(extra['1H'],c)!=trend: continue
        follow=(last[4]-prev[4])*sign>=s['follow_atr']*atr and (last[4]-last[1])*sign>0
        support_kind='support' if sign==1 else 'resistance'
        nearby=[p for p in levels if p['kind']==support_kind and abs((prev[3] if sign==1 else prev[2])-p['price'])<=z+m15['atr']*s['zone_atr']]
        current_side=(last[4]-m5['ma'][15])*sign>0 and (m5['ma'][15]-m5['ma'][20])*sign>=0
        ma_levels=[v for v in [*m15['ma'].values(),m15['mid']] if abs((prev[3] if sign==1 else prev[2])-v)<=m15['atr']*s['ma_confluence_atr']]
        if not nearby and ma_levels:
            nearby=[dict(kind=support_kind,price=ma_levels[0],confirmed=0,source='MA confluence')]
        volume=max(m5['relative_volume'],pm['relative_volume'])>=s['min_relative_volume']
        if not follow or not volume or market=='unclear': continue
        # RSI is a secondary conflict veto, never the generator of a direction.
        rsi_conflict=(m5['rsi'][6]<m5['rsi'][14] and m5['rsi'][6]<30) if sign==1 else (m5['rsi'][6]>m5['rsi'][14] and m5['rsi'][6]>70)
        if rsi_conflict: continue
        if extra and not higher_confirmation(extra,sign,c): continue
        # Strong opposite trends require MA15/20/20 reversal and BOTH recent closes across 15m MA20.
        gap=abs(m15['ma'][20]-m15['ma'][50])/m15['atr']
        opposite=market not in (trend,'range')
        reversal=current_side and (m5['ma'][15]-m5['ma'][20])*sign>0 and all((b[4]-m15['ma'][20])*sign>0 for b in b5[-2:])
        if opposite and not reversal: continue
        def add(name, stop, target, detail):
            if (last[4]-stop)*sign<=0 or (target-last[4])*sign<=0: return
            if abs(last[4]-m5['ma'][20])>s['max_extension_atr']*atr: return
            hits.append(dict(action=direction,strategy=name,stop=stop,target=target,reason=detail,
                regime=market,level=nearby[-1]['price'] if nearby else stop,
                ma={str(k):v for k,v in m15['ma'].items()},bb={k:m5[k] for k in ('mid','upper','lower','expansion','width_ratio','squeeze')},
                rsi=m5['rsi'],relative_volume=m5['relative_volume'],
                chart_context={'5m':m5,'15m':m15,**extra,'recent_5m':b5[-8:],'recent_15m':b15[-8:]},
                retest=name=='failed_retest',at_ms=last[0],atr=atr,
                wick_body_ratio=(min(prev[1],prev[4])-prev[3] if sign==1 else prev[2]-max(prev[1],prev[4]))/max(abs(prev[4]-prev[1]),atr*.001),
                higher_confirmation=bool(extra)))
        targets=[p['price'] for p in levels if (p['price']-last[4])*sign>atr*.3]
        target=(min(targets) if sign==1 else max(targets)) if targets else last[4]+sign*atr*3
        stop=(min(prev[3],last[3])-atr*c['risk']['stop_buffer_atr'] if sign==1 else max(prev[2],last[2])+atr*c['risk']['stop_buffer_atr'])
        band_touch=prev[3]<=pm['lower']+s['band_near_atr']*atr if sign==1 else prev[2]>=pm['upper']-s['band_near_atr']*atr
        buffer=s['band_return_buffer_atr']*atr
        reentry=pm['lower']+buffer<=prev[4]<=pm['upper']-buffer and m5['lower']+buffer<=last[4]<=m5['upper']-buffer
        rejection=wick(prev,atr,direction,c) and band_touch and reentry
        if rejection and current_side and nearby and (market=='range' or reversal or market==trend):
            add('band_rejection',stop,target,'밴드 극단의 긴 꼬리·밴드 내부 복귀·후속 마감 반전·15m 지지저항 확인')
        if market==trend and current_side and m5['expansion']>=1:
            touched=any(b[3]-z<=m5['ma'][20]<=b[2]+z for b in b5[-4:-1])
            confirmed=[p for p in nearby if (prev[4]-p['price'])*sign>=0 and (last[4]-p['price'])*sign>s['follow_atr']*atr]
            pullback_ok=(bool(confirmed) if s.get('trend_only') else wick(prev,atr,direction,c))
            if touched and pullback_ok and (last[4]-m5['ma'][20])*sign>0:
                add('trend_pullback',stop,target,'15m 추세·MA 정렬 + 지지/저항 유지·5m 눌림 후 마감 재상승/재하락 확인')
        # Confirmed 15m pivot was known before breakout; closed break then retest, never hindsight.
        for p in levels:
            if p['kind']!=('resistance' if sign==1 else 'support'): continue
            level=p['price']; tol=m15['atr']*s['zone_atr']
            for j in range(max(1,len(b5)-8),len(b5)-2):
                if p['confirmed']+900000>b5[j][0]: continue
                if ((b5[j][4]-level)*sign>s['breakout_atr']*atr
                    and (b5[j-1][4]-level)*sign<=s['breakout_atr']*atr
                    and abs((prev[3] if sign==1 else prev[2])-level)<=tol
                    and (prev[4]-level)*sign>=0 and (last[4]-level)*sign>0
                    and market==trend and m5['expansion']>=s['bb_expansion_ratio']):
                    add('breakout_retest',level-sign*tol,target,'확정 고점/저점 마감 돌파 후 구간 재확인·유지·후속 마감')
        # First pivot, intervening excursion and second test are distinct bars.
        for p in pivots(b5[:-2],c):
            gap=len(b5)-2-p['index']
            if p['kind']!=support_kind or not s['retest_min_gap']<=gap<=s['retest_max_gap']: continue
            middle=b5[p['index']+1:-2]
            excursion=(max(b[2] for b in middle)-p['price'] if sign==1 else p['price']-min(b[3] for b in middle))
            test=prev[3] if sign==1 else prev[2]
            regained=(prev[4]-p['price'])*sign>=0 and (last[4]-p['price'])*sign>0
            settled=any((b[4]-p['price'])*sign < -z for b in b5[p['index']+1:])
            if abs(test-p['price'])<=z and excursion>=s['retest_excursion_atr']*atr and regained and not settled and rejection and current_side:
                add('failed_retest',p['price']-sign*(z+atr*c['risk']['stop_buffer_atr']),target,'첫 극점·중간 1ATR 이상 반등/하락·재접촉·돌파 실패·밴드 복귀·후속 반전')
    if not hits: return None, '지표 충돌/시장 불명확' if market=='unclear' else '마감 신호·후속 반전·거래량·지지저항 조건 미충족'
    if len({h['action'] for h in hits})>1: return None,'롱·숏 신호 충돌'
    chosen=min(hits,key=lambda h:s['priority'].index(h['strategy']))
    chosen['signal_id']=hashlib.sha256(f"{chosen['action']}:{chosen['at_ms']}".encode()).hexdigest()[:24]
    return chosen,''


def manage(b5,b15,position,owned,c):
    """First partial at the configured ROE threshold, then manage the remaining breakout/decline attempt."""
    m=metrics(b5,c);side=1 if position['posSide']=='long' else -1
    last=b5[-1];atr=m['atr'];roe=float(position['uplRatio'])
    if (last[4]-float(owned.get('invalidation_px',owned['stop_px'])))*side<=0:
        return 'CLOSE','차트 구조 손절 구간 마감 이탈',None
    if c['risk'].get('runner_trend_exit'):
        # Require two completed adverse closes AND deteriorating highs/lows.
        # Targets reached or one opposite wick alone do not close the runner.
        prior=metrics(b5[:-1],c)
        adverse=((b5[-2][4]-prior['ma'][20])*side<0 and (last[4]-m['ma'][20])*side<0)
        reversed_ma=(m['ma'][15]-m['ma'][20])*side<0 and m['slopes'][20]*side<0
        structure=(last[2]-b5[-2][2])*side<0 and (last[3]-b5[-2][3])*side<0
        if adverse and reversed_ma and structure:
            return 'CLOSE','5m MA20 2봉 이탈·MA15/20 반전·고저점 악화',None
        if not owned.get('partial_used') and not owned.get('partial_unsplittable'):
            if roe>=c['risk']['profit_review_roe']:
                return 'PARTIAL',f"ROE +{c['risk']['profit_review_roe']*100:g}% 이상: 보유 수량 {c['risk']['partial_fraction']*100:g}% 1차 익절",None
            return 'HOLD','1차 익절 전: 손절·차트 무효화 감시',None
        return 'TRAIL','잔여 물량 추세 유지·유리한 방향으로만 보호 손절 추적',last[4]-side*atr*c['risk']['trailing_atr']
    if roe<c['risk']['profit_review_roe'] and not owned.get('profit_review_armed') and not owned.get('partial_used'):
        return 'HOLD',f"+{c['risk']['profit_review_roe']*100:g}% 전: 구조 무효화·최종 손절 감시",None
    levels=zones(b15,c);zone=atr*c['signals']['zone_atr']
    if not owned.get('partial_used'):
        future=[z['price'] for z in levels if z['kind']==('resistance' if side==1 else 'support') and (z['price']-last[4])*side>=0]
        fallback=max(max(b[2] for b in b5[-21:-1]),m['upper']) if side==1 else min(min(b[3] for b in b5[-21:-1]),m['lower'])
        target=(min(future) if side==1 else max(future)) if future else fallback
        return 'PARTIAL',f"ROE +{c['risk']['profit_review_roe']*100:g}% 도달: 최초 부분 청산, 잔여 추가 진행 여부 감시",target
    sequence=owned.get('profit_sequence')
    if sequence:
        target=float(sequence['target']);start=sequence['signal_bar_ms']
        after=[b for b in b5 if b[0]>start]
    else:
        # Existing partially exited trades have no v5.1 anchor: use current known zones, never invent an old partial time.
        target=None;after=b5[-2:]
    if target is not None and len(after)>=2:
        prev,latest=after[-2:]
        broke=any((b[4]-target)*side>atr*c['signals']['breakout_atr'] for b in after[:-1])
        failed=broke and (latest[4]-target)*side < -atr*c['signals']['breakout_failure_atr']
        more=[z['price'] for z in levels if z['kind']==('resistance' if side==1 else 'support') and (z['price']-target)*side>=0]
        contact=any(prev[3]-zone<=v<=prev[2]+zone for v in [target,*more])
        rejected=contact and wick(prev,atr,'SHORT' if side==1 else 'LONG',c) and (latest[4]-prev[4])*side<=-atr*c['signals']['follow_atr']
        if failed or rejected:
            return 'CLOSE',('부분 청산 후 추가 상향 돌파 실패' if side==1 else '부분 청산 후 추가 하락 실패'),None
    elif target is None:
        # Conservative legacy management: require actual contact with a known zone plus a confirmed reversal.
        prev=b5[-2]
        for level in levels:
            if level['kind']!=('resistance' if side==1 else 'support'):continue
            v=level['price'];contact=prev[3]-zone<=v<=prev[2]+zone
            if contact and wick(prev,atr,'SHORT' if side==1 else 'LONG',c) and (last[4]-prev[4])*side<=-atr*c['signals']['follow_atr']:
                return 'CLOSE','기존 부분 청산 포지션: 확인 구간에서 추가 진행 실패',None
    if not owned.get('holding_rule') and (last[4]-m['mid'])*side<0 and (m['ma'][15]-m['ma'][20])*side<0:
        return 'CLOSE','밴드 중심선 복귀 실패·MA15/20 반전',None
    return 'TRAIL','부분 청산 잔여 추세 유지·보호 SL 검토',last[4]-side*atr*c['risk']['trailing_atr']


def allowed_instrument(i, cfg):
    from okx_free_ai import enabled as free_enabled,allowed as free_allowed
    if free_enabled(cfg):return free_allowed(i,cfg)
    from okx_band_flow import enabled as band_enabled,allowed as band_allowed
    from okx_oct23 import enabled as oct_enabled,allowed as oct_allowed
    if oct_enabled(cfg):return oct_allowed(i,cfg)
    if band_enabled(cfg):return band_allowed(i)
    symbol=i.get('instId',''); base=symbol.split('-')[0]
    return ((base not in ('BTC','ETH','SOL') or cfg['selection'].get('include_majors',False)) and symbol not in cfg['selection'].get('stock_linked_symbols',[])
        and i.get('instCategory')=='1' and i.get('groupId') in ('4','5')
        and symbol.endswith('-USDT-SWAP') and i.get('state')=='live'
        and i.get('settleCcy')=='USDT' and i.get('ctType')=='linear' and i.get('ctValCcy')==base)


def zones(bars,c):
    """Cluster repeated confirmed pivots into volatility-scaled zones, causal at query time."""
    raw=pivots(bars,c)
    if not raw:return []
    tolerance=metrics(bars,c)['atr']*c['signals']['zone_atr'];out=[]
    for level in raw:
        found=next((z for z in out if z['kind']==level['kind'] and abs(z['price']-level['price'])<=tolerance),None)
        if found:
            count=found['touches'];found['price']=(found['price']*count+level['price'])/(count+1)
            found['touches']+=1;found['confirmed']=max(found['confirmed'],level['confirmed'])
        else:out.append(dict(level,touches=1))
    return out


def higher_confirmation(higher,sign,c):
    for name,m in higher.items():
        adverse=sum((m['close']-m['ma'][p])*sign<0 and m['slopes'][p]*sign<0 for p in (50,100,120,200))
        if adverse>=c['signals']['higher_ma_conflict_count']:
            # Additional reversal: higher MA15/20 cross + both slopes and Bollinger centre turn.
            if not ((m['ma'][15]-m['ma'][20])*sign>0 and m['slopes'][15]*sign>0
                    and m['slopes'][20]*sign>0 and m['mid_slope']*sign>0):return False
    return True


def select_leverage(found,c):
    if found.get('autonomous'):
        from okx_autonomous import valid_leverage
        if not valid_leverage(found,c):raise BotError('자율 선택 배율 범위 밖')
        return found['leverage']
    r=c['risk']
    override=c['signals'].get('support_entries',{}).get('major_leverages',{}).get(found.get('symbol','').split('-')[0])
    if override is not None:return override
    if r['leverage_mode']=='fixed':return r['leverage']
    m=found['chart_context'].get('5m') or found['chart_context']['15m'];v=m['atr']/m['close']
    # Highest multipliers require trend alignment and active volume. Reversals use <=5x initially.
    aligned=found['regime']==('uptrend' if found['action']=='LONG' else 'downtrend')
    lev=3
    if aligned and m['relative_volume']>=1.5:
        if v<=r['auto_10x_atr_fraction']:lev=10
        elif v<=r['auto_7x_atr_fraction']:lev=7
        elif v<=r['auto_5x_atr_fraction']:lev=5
    lev=max(r['min_leverage'],min(r['max_leverage'],lev))
    if found.get('strategy')=='wick15_rejection':
        distance=(abs(found['entry_reference']-found['stop'])+found['entry_gap'])/found['entry_reference']
        maximum=abs(r['final_stop_roe'])/distance
        lev=max(r['min_leverage'],max((v for v in (3,5,7,10) if v<=min(lev,maximum)),default=r['min_leverage']))
    return lev


def scale_confirmation(bars,direction,c):
    b=bars['5m'];m=metrics(b,c);m15=metrics(bars['15m'],c);side=1 if direction=='long' else -1
    last,prev=b[-1],b[-2];atr=m['atr']
    follow=(last[4]-prev[4])*side>=c['signals']['follow_atr']*atr and (last[4]-last[1])*side>0
    rebound=wick(prev,atr,'LONG' if side==1 else 'SHORT',c)
    candidate_levels=[z for z in zones(bars['15m'],c) if z['kind']==('support' if side==1 else 'resistance')]
    candidate_levels += [dict(price=v,touches=1) for v in m['ma'].values()]
    test_price=prev[3] if side==1 else prev[2]
    confirmed=[z for z in candidate_levels if abs(test_price-z['price'])<=atr*c['signals']['ma_confluence_atr'] and (prev[4]-z['price'])*side>=0 and (last[4]-z['price'])*side>0]
    supported=bool(confirmed)
    inside=m['lower']<=last[4]<=m['upper']
    higher={k:metrics(v,c) for k,v in bars.items() if k in ('1H','4H')}
    if not (follow and supported and inside and m['relative_volume']>=c['signals']['min_relative_volume']
            and (last[4]-m['ma'][15])*side>0 and (m['ma'][15]-m['ma'][20])*side>=0
            and higher_confirmation(higher,side,c)):return None
    # Reject adding against a clear 15m trend, unless MA15/20 and centre have turned in our direction.
    if regime(m15,c)==('downtrend' if side==1 else 'uptrend') and not ((m15['ma'][15]-m15['ma'][20])*side>0 and m15['mid_slope']*side>0):return None
    return dict(action='LONG' if side==1 else 'SHORT',signal_id=hashlib.sha256(f'{last[0]}:scale:{direction}'.encode()).hexdigest()[:24],
                reason='분할 진입: MA15/20 지지·저항/꼬리와 밴드 내부 후속 마감 확인',
                stop=last[3]-atr*c['risk']['stop_buffer_atr'] if side==1 else last[2]+atr*c['risk']['stop_buffer_atr'],
                target=last[4]+side*atr*3,at_ms=last[0],
                support_resistance=confirmed[0]['price'],touches=max(z.get('touches',1) for z in confirmed),
                relative_volume=m['relative_volume'],higher_aligned=bool(higher) and all((v['ma'][15]-v['ma'][20])*side>0 for v in higher.values()),rejection_wick=bool(rebound))


def protective_target(b5,b15,p,o,c):
    """Only a favourable confirmed support/resistance retest can tighten structural SL."""
    side=1 if p['posSide']=='long' else -1;m=metrics(b5,c);atr=m['atr'];last=b5[-1]
    old=float(o['stop_px']);candidates=[]
    levels=zones(b5,c)+zones(b15,c)
    for level in levels:
        if level['kind']!=('support' if side==1 else 'resistance'):continue
        if level['time']<o.get('entry_ms',0):continue
        price=level['price'];zone=atr*c['signals']['zone_atr']
        # The last completed bar actually tests and rejects the known area in the favourable direction.
        touched=(last[3]<=price+zone and last[4]>price) if side==1 else (last[2]>=price-zone and last[4]<price)
        if touched and (last[4]-last[1])*side>0:
            candidates.append(price-side*atr*c['risk']['stop_buffer_atr'])
    if o.get('profit_review_armed'):
        qty=float(p['pos'])*float(o['ct_val']);avg=float(p['avgPx']);mark=float(p['markPx'])
        exitfee=abs(float(o.get('entry_taker_fee',.0005)))*qty*mark
        incurred=sum(max(0,-float(p.get(k) or 0)) for k in ('fee','fundingFee'))
        # If entry fee is not supplied by exchange, reserve it rather than assume free entry.
        if p.get('fee') in (None,''):incurred+=abs(float(o.get('entry_taker_fee',.0005)))*qty*avg
        margin=qty*avg/o['leverage'];targetprofit=margin*c['risk']['protected_profit_roe']
        exitbuffer=qty*mark*c['liquidity']['max_slippage']
        breakeven=avg+side*(incurred+exitfee+exitbuffer+targetprofit)/qty
        if (mark-breakeven)*side>0:candidates.append(breakeven)
    valid=[v for v in candidates if (v-old)*side>0 and (float(p['markPx'])-v)*side>0]
    return (max(valid) if side==1 else min(valid)) if valid else None


def dynamic_add_fraction(confirmed,c):
    r=c['risk'];weight=r['dynamic_add_room_min_fraction']
    if confirmed.get('touches',1)>=2:weight+=.15
    if confirmed.get('relative_volume',0)>=1.5:weight+=.15
    if confirmed.get('higher_aligned'):weight+=.10
    if confirmed.get('rejection_wick'):weight+=.10
    return min(r['dynamic_add_room_max_fraction'],weight)


def sync_profit_threshold(record,threshold):
    """Reset only an unexecuted old profit latch. Never loosen SL or undo an exit."""
    if record.get('partial_used') or record.get('phase') in ('partial_closing','resizing','closing'):
        return False
    if record.get('profit_review_threshold')==threshold:return False
    record['profit_review_armed']=False;record['profit_review_threshold']=threshold
    return True

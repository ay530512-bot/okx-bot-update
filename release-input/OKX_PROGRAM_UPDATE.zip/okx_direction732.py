"""Read-only directional evidence. Percentages are heuristic scores, NOT probabilities.
No strategy selection, auto-entry, model calls or learned expected returns here.
"""
import math, statistics
from datetime import datetime, timezone, timedelta
from okx_band_flow import atr
from okx_channel701 import closed
from okx_pattern15 import leverage
PERIODS=(50,100,120,150,200,240)
FEE=.0005
SLIP=.0005

def clip(x):return max(-1.,min(1.,x))
def rsi(b):
    changes=[y[4]-x[4] for x,y in zip(b,b[1:])]
    gain=sum(max(0,x) for x in changes[:14])/14
    loss=sum(max(0,-x) for x in changes[:14])/14
    for x in changes[14:]:gain=(gain*13+max(0,x))/14;loss=(loss*13+max(0,-x))/14
    return 50. if gain==loss==0 else 100. if loss==0 else 100-100/(1+gain/loss)

def frame_evidence(raw,now,step):
    # Time-close AND exchange confirmation when available. Forming bars cannot vote.
    b=closed([r for r in raw if len(r)==6 or r[6] is True],now,step,required=50)
    a=atr(b)
    if not math.isfinite(a) or a<=0:raise ValueError('ATR 산정 불가')
    c=b[-1][4];ma={n:sum(x[4] for x in b[-n:])/n for n in PERIODS if len(b)>=n+3}
    if not ma:raise ValueError('MA50 이상 자료 대기')
    votes=[]
    for n,value in ma.items():
        prior=sum(x[4] for x in b[-n-3:-3])/n
        votes.append(.6*clip((c-value)/(2*a))+.4*clip((value-prior)/a))
    m=sum(x[4] for x in b[-20:])/20;sd=statistics.pstdev(x[4] for x in b[-20:]);upper=m+2*sd;lower=m-2*sd
    pm=sum(x[4] for x in b[-21:-1])/20;ps=statistics.pstdev(x[4] for x in b[-21:-1])
    last=b[-1];span=last[2]-last[3]
    bb=clip((c-m)/max(2*sd,a))
    # Rejection has a directional candle confirmation; a band touch alone isn't a reversal.
    if last[3]<pm-2*ps and c>lower and c>last[1]:bb=1.
    elif last[2]>pm+2*ps and c<upper and c<last[1]:bb=-1.
    rv=rsi(b);momentum=clip((rv-50)/20)
    mean=sum(x[5] for x in b[-21:-1])/20;ratio=last[5]/mean if mean>0 else 0
    vol=clip((c-last[1])/span if span else 0)*min(ratio/1.5,1.)
    signals={'MA':sum(votes)/len(votes),'BOLL':bb,'RSI':momentum,'VOLUME':vol}
    weighted=.4*signals['MA']+.25*bb+.2*momentum+.15*vol
    return dict(score=weighted,signals=signals,ma=ma,missing_ma=[n for n in PERIODS if n not in ma],rsi=rv,volume_ratio=ratio,
                bb=dict(mid=m,upper=upper,lower=lower),atr=a,close_ms=last[0]+step,
                support=min(x[3] for x in b[-20:]),resistance=max(x[2] for x in b[-20:]))

def scenario(price,a,lev,side):
    stop=price-side*2*a;target=price*(1+side*.20/lev)
    if stop<=0 or target<=0:raise ValueError('양수 가격 산정 불가')
    # USDT PnL per 1 USDT margin. Closing costs use exit notional.
    def net(exit_price,fraction):
        q=lev/price*fraction
        return q*((exit_price-price)*side-(price+exit_price)*(FEE+SLIP))
    return dict(entry=price,sl=stop,partial_price=target,sl_roe=-2*a/price*lev*100,
                partial_net_per_margin=net(target,.5),sl_net_per_margin=net(stop,1),
                resistance_or_support=None)

def stop_block_reason(price,a):
    distance=2*float(a)/float(price)
    if not math.isfinite(distance) or distance<=0:return '초기2ATR 손절 계산 불가'
    if distance>=.09:return f'진입 차단: 초기2ATR 손절 거리 {distance*100:.2f}% · 기존 허용 조건은 가격 기준9% 미만'
    return ''

def analyze(symbol,frames,quote,now):
    out=dict(symbol=symbol,observed_ms=now,ready=False,probability=None,expected_profit=None,
             label='지표 우세 점수 · 수익 확률 아님',cost_assumption='편도 수수료0.05%+슬리피지0.05% 가정 · 펀딩 미포함')
    try:
        ts=int(quote['ts']);price=float(quote['last'])
        if not 0<=now-ts<=10000 or not math.isfinite(price) or price<=0:raise ValueError('최신 시세 대기')
        fs={f:frame_evidence(frames.get(f,[]),now,step) for f,step in [('15m',900000),('1H',3600000)]}
        score=.65*fs['15m']['score']+.35*fs['1H']['score'];long=round(50+45*score,1)
        out.update(ready=True,quote_ms=ts,price=price,frames=fs,long_score=long,short_score=round(100-long,1),
                   preference='롱 우세' if long>=55 else '숏 우세' if long<=45 else '중립 · 우세 불명확',leverage=5)
        out['entry_block_reason']=''
        out['directions']={}
        for side,name in [(1,'LONG'),(-1,'SHORT')]:
            s=scenario(price,fs['15m']['atr'],out['leverage'],side)
            s['resistance_or_support']=fs['15m']['resistance' if side==1 else 'support']
            out['directions'][name]=s
        out['conflict']=fs['15m']['score']*fs['1H']['score']<0
    except (ValueError,TypeError,KeyError,IndexError,ArithmeticError) as ex:out.update(ready=False,reason=str(ex))
    except Exception as ex:
        from okx_core import BotError
        if not isinstance(ex,BotError):raise
        out.update(ready=False,reason=str(ex))
    return out

def fresh(a,now):return bool(a and a.get('ready') and 0<=now-a.get('observed_ms',0)<=35000 and 0<=now-a.get('quote_ms',0)<=35000 and all(v['close_ms']==now//step*step for f,step in [('15m',900000),('1H',3600000)] for v in [a['frames'][f]]))

def describe(a,margin=None,now=None):
    if not a or not fresh(a,now if now is not None else a.get('observed_ms',0)):return '분석 대기 · '+str((a or {}).get('reason') or '종목 선택 / 최신 확정봉·시세 확인 중')
    p=lambda x:format(x,'.7g')
    stamp=datetime.fromtimestamp(a['observed_ms']/1000,timezone(timedelta(hours=9))).strftime('%H:%M:%S')
    lines=[f"롱 {a['long_score']:.1f}% / 숏 {a['short_score']:.1f}% · {a['preference']}",
           '지표 우세 점수(합계100) · 승률/수익 확률 아님',f"15분·1시간 확정봉 / {stamp} KST / 기준가 {p(a['price'])} / {a['leverage']}배"]
    if a.get('entry_block_reason'):lines.append(a['entry_block_reason'])
    for f,v in a['frames'].items():
        lines.append(f"{f} RSI {v['rsi']:.1f} · 거래량 {v['volume_ratio']:.2f}배 · "+' / '.join(k+('↑' if x>.1 else '↓' if x<-.1 else '↔') for k,x in v['signals'].items()))
        if v['missing_ma']:lines.append(f+': MA '+','.join(map(str,v['missing_ma']))+' 자료 부족 · 점수에서 제외')
    if a['conflict']:lines.append('주의: 15분·1시간 방향 상충')
    if margin is not None and math.isfinite(float(margin)) and float(margin)>0:
        margin=float(margin);lines.append(f'목표 증거금 {margin:.2f} USDT · 유보 후1/4 (계약 반올림 전)')
    else:margin=None;lines.append('증거금 확인 대기 · 손익은 증거금1 USDT당 표시')
    for side,name in [('LONG','롱'),('SHORT','숏')]:
        s=a['directions'][side];factor=margin if margin is not None else 1.
        lines.append(f"{name} SL {p(s['sl'])} (2ATR / ROE {s['sl_roe']:.1f}%)")
        lines.append(f"  +20% 절반익절 기준 {p(s['partial_price'])} → 해당 절반 순손익 {s['partial_net_per_margin']*factor:+.3f} USDT")
        lines.append(f"  익절 전 전량SL 시 {s['sl_net_per_margin']*factor:+.3f} USDT · 참고 {'저항' if side=='LONG' else '지지'} {p(s['resistance_or_support'])}")
    lines+=['조건부 손익 예시 · 통계적 기대수익/최종수익 미산정',a['cost_assumption'],
            '시장가·가격단위·펀딩에 따라 실제 손익/SL은 달라짐',
            '잔량은 기존 수익보호·추적SL / 최대6시간. 고정 전량TP 없음.']
    return '\n'.join(lines)

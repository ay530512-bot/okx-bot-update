"""Narrow engine-thread control: prepare + one-use confirmation, or pause entries."""
import hashlib,json,secrets,time
from okx_core import BotError,dec

def fingerprint(e,budget):return hashlib.sha256(json.dumps(dict(config=e.cfg,budget=budget),sort_keys=True,default=str).encode()).hexdigest()

def handle(e,request):
 rid=request['request_id'];owner=request['owner'];op=request['op'];now=time.monotonic()
 result=dict(request_id=rid,owner=owner,status='failed',message='처리 보류')
 try:
  if op in ('entry','close_one','close_all'):
   from okx_click716 import accept
   accept(e,request);return
  if now-request['issued_at']>30 or now<request['issued_at']:raise BotError('요청 시간이 지났습니다. 다시 요청하세요.')
  tickets=getattr(e,'mobile_tickets',{});tickets={k:v for k,v in tickets.items() if v['expires']>now};e.mobile_tickets=tickets
  if op=='prepare':
   snap=e.snapshot();budget=float(request['budget']);ceiling=min(6.,float(e.cfg['execution']['model_runtime']['max_daily_budget']))
   if not .01<=budget<=ceiling:raise BotError('PC의 AI 예산 설정을 확인하세요.')
   if snap['equity']<1:raise BotError('거래 자산이 1 USDT 미만입니다.')
   if not e.account_stream.fresh():raise BotError('계정 연결과 최초 조회를 확인하세요.')
   if e.cfg['execution'].get('profile')!='FREE5' and not e.cfg['execution'].get('rule_channel701'):raise BotError('지원하는 운용 프로필이 아닙니다.')
   token=secrets.token_urlsafe(24);e.mobile_tickets[token]=dict(owner=owner,expires=now+60,equity=snap['equity'],available=snap['available'],budget=budget,fingerprint=fingerprint(e,budget))
   if len(e.mobile_tickets)>32:e.mobile_tickets.pop(next(iter(e.mobile_tickets)))
   r=e.cfg['risk'];summary=[['계정 총자산',str(snap['equity'])+' USDT'],['가용잔고',str(snap['available'])+' USDT'],['대상','알트 · BTC/ETH/SOL/주식 연동 제외'],['레버리지',str(r.get('leverage'))+'배'],['최초 증거금','자동 운용 자금의 최대 1/3 · 실제 주문 단위/위험 한도 적용'],['AI 일일 예산','$'+str(budget)+' (기존 사용액 유지)'],['AI 검토','진입 '+str(e.cfg['execution']['free_ai']['entry_seconds']//60)+'분 / 보유 '+str(e.cfg['execution']['free_ai']['manage_seconds']//60)+'분'],['일일 손실 중단','사용' if r.get('daily_loss_enabled',True) else '없음'],['일일 수익 상한',str(float(r.get('daily_cap',10))*100)+'%'],['운용','연속 운용 · 기존 보호 주문/위험 점검 유지']]
   if e.cfg['execution'].get('rule_channel701'):
    allocation=e.allocation_seed(snap)
    summary=[['계정 총자산',str(snap['equity'])+' USDT'],['가용잔고',str(snap['available'])+' USDT'],
     ['대상','거래소 허용 USDT 선물 · 수동 종목 제외'],['신규 진입 배율','BTC20 · ETH/SOL15 · 기타10배'],['최대 보유','4개 · 수동 포함'],
     ['배정 기준','자동 운용 시드에서 3 USDT 제외'],['포지션당 목표 증거금',format(allocation*dec('.25'),'.2f')+' USDT · 기준자금의 1/4'],
     ['V7.32 15m 진입','1H ER20 0.30 기준 추세 눌림/확정 반전 / 최초2ATR'],['모든 자동 포지션 익절','관측 ROE +20% 이상 · 최초 절반청산'],
     ['재진입','청산 확인 후 기존 규칙의 새 신호 탐색'],['모든 자동 포지션 시간제한','포지션 진입 후6시간'],
     ['신규 유료 AI 호출','없음']]
   from okx_risk732 import enabled as risk_enabled
   if risk_enabled(e.cfg):
    summary += [['신규 진입 수량','3 USDT 유보 후 자동 운용 시드의 1/4 · 최소 주문·잔고 부족 시 소액 대체 없이 대기'],
                ['연속 운용','24시간 신호 탐색 · 일일 손익으로 신규 진입 중단 없음'],
                ['호가 검사','스프레드·예상 슬리피지 각각0.05% 이내']]
   summary += [['자동 재개','비정상 재시작·일시 오류 해소 후 계정/주문/SL 대조 통과 시 재개'],['직접 중지','신규 진입 중지·전체 청산·정상 종료 시 자동 재개 안 함']]
   result.update(status='prepared',ticket=token,expires_in=60,summary=summary,message='내용을 확인하고 60초 안에 실거래 시작을 확인하세요. 확인 후 자동 주문이 발생할 수 있습니다.')
  elif op=='confirm':
   ticket=e.mobile_tickets.get(request.get('ticket'))
   if not ticket or ticket['owner']!=owner:raise BotError('확인 정보가 없거나 만료됐습니다. 다시 조회하세요.')
   e.mobile_tickets.pop(request['ticket']) # consume before any external effect
   if fingerprint(e,ticket['budget'])!=ticket['fingerprint']:raise BotError('설정이 바뀌었습니다. 다시 확인하세요.')
   snap=e.snapshot()
   for name in ('equity','available'):
    if abs(snap[name]-ticket[name])>max(dec('.1'),abs(ticket[name])*dec('.02')):raise BotError('잔고가 바뀌었습니다. 다시 확인하세요.')
   if e.enabled and not e.preview and not e.user_paused:
    result.update(status='applied',message='이미 실거래가 활성화되어 있습니다. 중복 시작하지 않았습니다.')
   else:
    try:e.handle('live',dict(equity=ticket['equity'],budget=ticket['budget'],hours=24))
    except Exception:
     e.pause('모바일 실거래 시작 검증 실패 · 신규 진입 중지');raise
    e.mobile_entry_pause=False
    result.update(status='applied',message='실거래 활성화 완료 · 계정/보호 주문 대조 후 신규 진입 허용. 즉시 진입이나 수익을 의미하지 않습니다.')
  elif op=='pause':
   e.handle('pause',{});e.mobile_entry_pause=True;e.mobile_tickets.clear()
   result.update(status='applied',message='신규·추가 진입 중지 완료 · 기존 포지션의 보호 손절과 보유·청산 관리는 유지합니다.')
  else:raise BotError('허용되지 않은 제어입니다.')
 except Exception as exc:result.update(status='failed',message=str(exc) if isinstance(exc,BotError) else 'PC 제어 처리 오류 · 상태를 확인하세요.')
 if op=='entry':
  from okx_entry_gate720 import gate
  result['entry_gate']=gate(e)
 result['live']=bool(e.enabled);result['user_paused']=bool(e.user_paused)
 e.events.put(('mobile_control_result',result))
 if op!='prepare':
  try:e.notify('모바일 운용 제어',result['message'],state=rid)
  except Exception:pass

"""Billing shortcuts and visibly estimated user-calibrated API credit balance."""
import tkinter as tk
from datetime import datetime
from okx_core import KST
from okx_ui_theme import BG,PANEL,INNER,BORDER,TEXT,MUTED,GREEN,AMBER,button
from okx_api_credit import open_page
class ApiCreditWindow:
 def __init__(self,view):
  self.view=view;self.win=tk.Toplevel(view);self.win.title('OpenAI API 충전·잔액');self.win.geometry('800x680');self.win.minsize(700,640);self.win.configure(bg=BG);self.win.protocol('WM_DELETE_WINDOW',self.close)
  tk.Label(self.win,text='OpenAI API 충전 · 잔액',bg=BG,fg=TEXT,font=(view.family,-24,'bold')).pack(anchor='w',padx=24,pady=(22,8))
  tk.Label(self.win,text='ChatGPT Plus 구독과 별도로 사용하는 API 크레딧입니다.\n충전 버튼은 공식 웹페이지를 열며 결제는 그 페이지에서 직접 진행합니다.',bg=BG,fg=MUTED,font=(view.family,-14),justify='left').pack(anchor='w',padx=24,pady=6)
  row=tk.Frame(self.win,bg=BG);row.pack(fill='x',padx=24,pady=12)
  self.billing=button(row,'공식 충전·실제 잔액 확인 ↗',lambda:open_page('billing'),view.family,kind='primary');self.billing.pack(side='left',padx=(0,10))
  self.usage=button(row,'공식 사용량 ↗',lambda:open_page('usage'),view.family);self.usage.pack(side='left')
  card=tk.Frame(self.win,bg=PANEL,highlightthickness=1,highlightbackground=BORDER);card.pack(fill='x',padx=24,pady=12)
  tk.Label(card,text='프로그램 계산 추정 잔액',bg=PANEL,fg=MUTED,font=(view.family,-14)).pack(anchor='w',padx=18,pady=(14,5))
  self.amount=tk.Label(card,text='미등록',bg=PANEL,fg=GREEN,font=(view.family,-30,'bold'));self.amount.pack(anchor='w',padx=18)
  self.detail=tk.Label(card,text='',bg=PANEL,fg=MUTED,font=(view.family,-13),wraplength=690,justify='left');self.detail.pack(anchor='w',padx=18,pady=(8,8))
  self.refresh=button(card,'추정 잔액 새로고침 ↻',lambda:self.view.callbacks.get('api_credit_refresh',lambda:None)(),view.family);self.refresh.pack(anchor='e',padx=18,pady=(0,12))
  tk.Label(self.win,text='공식 페이지에서 확인한 현재 잔액 (USD)',bg=BG,fg=TEXT,font=(view.family,-15)).pack(anchor='w',padx=24,pady=(10,5))
  edit=tk.Frame(self.win,bg=BG);edit.pack(fill='x',padx=24)
  self.entry=tk.Entry(edit,bg=INNER,fg=TEXT,insertbackground=GREEN,font=(view.family,-19),relief='flat',highlightthickness=1,highlightbackground=BORDER);self.entry.pack(side='left',fill='x',expand=True,ipady=9,padx=(0,10))
  self.save=button(edit,'확인한 잔액으로 맞추기',self.sync,view.family);self.save.pack(side='right')
  tk.Label(self.win,text='이 값은 충전 금액이 아니라 공식 페이지에 표시된 현재 잔액입니다.\n다른 앱 사용·추가 충전·만료·청구 지연은 자동 반영되지 않습니다.\n이 프로그램 사용 비용도 추정/미확정분을 포함하므로 공식 실제 잔액과 다를 수 있습니다.',bg=BG,fg=AMBER,font=(view.family,-13),justify='left',wraplength=710).pack(anchor='w',padx=24,pady=16)
  self.render(view.state.get('api_credit',{}))
  if view.demo:
   for b in (self.billing,self.usage,self.save,self.refresh):b.configure(state='disabled')
 def render(self,data):
  from okx_dashboard import money
  self.amount.configure(text='미등록 / 확인 필요' if data.get('estimated_balance') is None else '$'+money(data['estimated_balance'],3)+' (추정)')
  text=data.get('status','공식 잔액 미등록')
  if data.get('recorded_ms'):
   stamp=datetime.fromtimestamp(data['recorded_ms']/1000,KST).strftime('%m-%d %H:%M:%S KST')
   text+='\n입력 잔액 $'+money(data.get('recorded_balance'),3)+' / '+stamp+'\n입력 이후 프로그램 사용액 $'+money(data.get('spent_since'),4)
  self.detail.configure(text=text)
 def sync(self):
  callback=self.view.callbacks.get('api_credit_sync')
  if callback:callback(balance=self.entry.get().strip())
 def close(self):
  view=self.view;self.win.destroy()
  if view is not None and view.credit_window is self:view.credit_window=None
  self.view=None

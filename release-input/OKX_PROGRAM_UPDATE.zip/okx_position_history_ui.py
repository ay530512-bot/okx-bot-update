"""Date-filtered read-only closed-position table. Never submits a trade."""
import tkinter as tk
from tkinter import ttk
from datetime import datetime,timedelta
from okx_core import KST
from okx_ui_theme import BG,PANEL,INNER,BORDER,TEXT,MUTED,GREEN,RED,button

def cash(v):
 from okx_dashboard import money
 return money(v,signed=True)+' USDT'
def tone(v):
 from okx_dashboard import numeric
 n=numeric(v);return GREEN if n is not None and n>0 else RED if n is not None and n<0 else TEXT

class PositionHistoryWindow:
 def __init__(self,view):
  self.view=view;self.win=tk.Toplevel(view);self.win.title('이전 포지션 내역 · 날짜별 손익');self.win.geometry('1440x820');self.win.minsize(1000,650);self.win.configure(bg=BG);self.win.protocol('WM_DELETE_WINDOW',self.close)
  today=datetime.now(KST).date();self.day=tk.StringVar(value=today.isoformat());self.status=tk.StringVar(value='조회 대기 · 한국시간 청산일 기준')
  top=tk.Frame(self.win,bg=BG);top.pack(fill='x',padx=20,pady=14)
  tk.Label(top,text='이전 포지션 내역',bg=BG,fg=TEXT,font=(view.family,-22,'bold')).pack(side='left')
  button(top,'다음 날짜 →',lambda:self.shift(1),view.family).pack(side='right',padx=4)
  button(top,'조회·새로고침',self.request,view.family,kind='primary').pack(side='right',padx=4)
  self.date_box=ttk.Combobox(top,textvariable=self.day,values=[(today-timedelta(days=i)).isoformat() for i in range(90)],width=12,style='Market.TCombobox',font=(view.family,-15));self.date_box.pack(side='right',padx=6);self.date_box.bind('<<ComboboxSelected>>',lambda e:self.request())
  button(top,'← 이전 날짜',lambda:self.shift(-1),view.family).pack(side='right',padx=4)
  self.source_filter='all';self.last_data=None;self.filter_buttons={}
  filters=tk.Frame(self.win,bg=BG);filters.pack(fill='x',padx=20,pady=(0,12))
  tk.Label(filters,text='거래 구분',bg=BG,fg=MUTED,font=(view.family,-14)).pack(side='left',padx=(0,10))
  for value,title in (('all','전체'),('auto','자동'),('manual','수동'),('unknown','미분류·혼합')):
   control=button(filters,title,lambda v=value:self.select_source(v),view.family,kind='primary' if value=='all' else 'normal');control.pack(side='left',padx=4);self.filter_buttons[value]=control
  self.summary_vars=[];self.summary_labels=[]
  grid=tk.Frame(self.win,bg=BG);grid.pack(fill='x',padx=20,pady=(0,10))
  for n,title in enumerate(('수익 합계','손실 합계','총 순손익','수동 손익','자동 손익','합산 손익')):
   card=tk.Frame(grid,bg=PANEL,highlightbackground=BORDER,highlightthickness=1);card.grid(row=0,column=n,sticky='nsew',padx=(0,8));grid.columnconfigure(n,weight=1)
   tk.Label(card,text=title,bg=PANEL,fg=MUTED,font=(view.family,-13)).pack(anchor='w',padx=12,pady=(10,3))
   var=tk.StringVar(value='미조회');label=tk.Label(card,textvariable=var,bg=PANEL,fg=TEXT,font=(view.family,-18,'bold'));label.pack(anchor='w',padx=12,pady=(0,10));self.summary_vars.append(var);self.summary_labels.append(label)
  tk.Label(self.win,textvariable=self.status,bg=BG,fg=MUTED,font=(view.family,-13),wraplength=1360,justify='left').pack(fill='x',padx=20,pady=(0,12))
  holder=tk.Frame(self.win,bg=BG);holder.pack(fill='both',expand=True,padx=20,pady=(0,20))
  columns=('symbol','source','side','entry','exit','entry_px','exit_px','pnl')
  self.table=ttk.Treeview(holder,columns=columns,show='headings',style='Market.Treeview')
  for col,title,width in zip(columns,('종목','구분','방향','진입시간(KST)','청산시간(KST)','평균 진입가','평균 청산가','확정 손익(USDT)'),(145,120,60,190,190,125,125,150)):
   self.table.heading(col,text=title);self.table.column(col,width=width,minwidth=60,anchor='w' if col not in ('entry_px','exit_px','pnl') else 'e')
  vs=ttk.Scrollbar(holder,orient='vertical',command=self.table.yview);vs.pack(side='right',fill='y');hs=ttk.Scrollbar(holder,orient='horizontal',command=self.table.xview);hs.pack(side='bottom',fill='x');self.table.configure(yscrollcommand=vs.set,xscrollcommand=hs.set);self.table.pack(fill='both',expand=True)
  self.table.tag_configure('profit',foreground=GREEN);self.table.tag_configure('loss',foreground=RED);self.table.tag_configure('unknown',foreground=MUTED)
  self.request()
 def close(self):
  view=self.view;self.win.destroy()
  if view is not None and view.position_history_window is self:view.position_history_window=None
  self.view=None;self.day=None;self.status=None;self.summary_vars=[]
 def select_source(self,source):
  self.source_filter=source
  for key,control in self.filter_buttons.items():control.configure(bg='#213d33' if key==source else INNER,fg=GREEN if key==source else TEXT)
  if self.last_data:self.render(self.last_data)
 def shift(self,offset):
  try:self.day.set((datetime.strptime(self.day.get(),'%Y-%m-%d').date()+timedelta(days=offset)).isoformat());self.request()
  except ValueError:self.status.set('날짜를 YYYY-MM-DD 형식으로 입력하세요.')
 def request(self):
  try:datetime.strptime(self.day.get(),'%Y-%m-%d')
  except ValueError:self.status.set('날짜를 YYYY-MM-DD 형식으로 입력하세요.');return
  cached=self.view.state.get('position_history_days',{}).get(self.day.get())
  if cached:self.render(cached)
  else:
   self.last_data=None
   self.table.delete(*self.table.get_children())
   for v in self.summary_vars:v.set('조회 중')
  self.status.set(self.day.get()+' 조회 중 · 기존 캐시가 있으면 먼저 표시합니다.')
  callback=self.view.callbacks.get('position_history_query')
  if callback:callback(date=self.day.get())
  else:self.status.set('디자인 미리보기 · 실제 거래소 조회 없음')
 def render(self,data):
  if not self.view or data.get('date')!=self.day.get():return
  from okx_dashboard import money,numeric
  from okx_position_history import filter_report
  self.last_data=data
  data=filter_report(data,self.source_filter)
  summary=data.get('summary',{})
  for var,label,k in zip(self.summary_vars,self.summary_labels,('profit','loss','total','manual','auto','total')):
   var.set(cash(summary.get(k)));label.configure(fg=tone(summary.get(k)))
  self.table.delete(*self.table.get_children())
  source={'auto':'자동','manual':'수동·채팅/외부','mixed':'혼합·미분류','unknown':'미분류'}
  for r in data.get('rows',[]):
   p=numeric(r.get('pnl'));tag='profit' if p is not None and p>0 else 'loss' if p is not None and p<0 else 'unknown'
   self.table.insert('','end',iid=r['key'],values=(r['symbol'].replace('-USDT-SWAP','/USDT'),source.get(r['source'],'미분류'),'롱' if r['direction']=='long' else '숏' if r['direction']=='short' else r['direction'],r['entry_time'],r['exit_time'],r.get('entry_price') or '—',r.get('exit_price') or '—',money(r.get('pnl'),signed=True)),tags=(tag,))
  selected={'all':'전체','auto':'자동','manual':'수동·채팅/외부','unknown':'미분류·혼합'}[self.source_filter]
  text='필터: '+selected+' · 목록 및 합계에 적용 / '+data.get('basis','')+' / '+str(data.get('count',0))+'건 / 수수료·펀딩 포함, AI 비용 제외'
  if data.get('unknown_count'):text+=' / 미분류 '+str(data['unknown_count'])+'건 '+cash(summary.get('unknown'))+' (합산에 포함)'
  if data.get('missing_pnl'):text+=' / 손익 미확인 '+str(data['missing_pnl'])+'건은 합계에서 제외'
  text+=' / 조회 중' if data.get('loading') else ' / 조회 완료' if data.get('complete') else ' / 일부 내역일 수 있음'
  if data.get('error'):text+=' / '+data['error']
  self.status.set(text)

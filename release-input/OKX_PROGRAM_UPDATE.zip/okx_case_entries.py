"""Independent causal routes informed by manual-trade review, not fitted/trained models."""
from okx_rules import metrics
from okx_context_entries import background

STEPS={'1m':60000,'5m':300000,'15m':900000,'1H':3600000,'4H':14400000}
DEFAULTS=dict(enabled=True,frames=['5m','1m','15m'],support_enabled=True,reversal_enabled=True,
    breakout_enabled=True,single_wick_enabled=True,consolidation_enabled=True,zone_atr=.70,break_tolerance_atr=.15,reaction_atr=.03,
    tail_body_ratio=1.2,tail_range_fraction=.30,tail_atr=.20,close_fraction=.55,
    max_opposite_fraction=.35,max_extension_atr=2.,max_body_atr=1.8,max_recovery_atr=1.5,
    breakout_atr=.05,entry_window_seconds=180,consolidation_bars=4,consolidation_width_atr=2.)


def validate(p):
    return (all(type(p[k]) is bool for k in ('enabled','support_enabled','reversal_enabled','breakout_enabled','single_wick_enabled','consolidation_enabled'))
        and p['frames'] and len(set(p['frames']))==len(p['frames']) and all(f in ('1m','5m','15m') for f in p['frames'])
        and 0<p['zone_atr']<=1 and 0<=p['break_tolerance_atr']<=.5 and 0<p['reaction_atr']<=.5
        and 1<=p['tail_body_ratio']<=5 and .2<=p['tail_range_fraction']<=.8 and 0<p['tail_atr']<=2
        and .5<=p['close_fraction']<1 and 0<p['max_opposite_fraction']<.5
        and 0<p['max_extension_atr']<=3 and 0<p['max_body_atr']<=3 and 0<p['max_recovery_atr']<=3
        and type(p['consolidation_bars']) is int and 3<=p['consolidation_bars']<=12
        and .5<=p['consolidation_width_atr']<=3 and 0<p['breakout_atr']<=.5 and 60<=p['entry_window_seconds']<=240)


def setups(frames,c,now):
    p=c['signals'].get('case_entries',{})
    if not p.get('enabled'):return []
    need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+3
    out=[]
    for frame in p['frames']:
        step=STEPS[frame];b=[r for r in frames.get(frame,[]) if r[0]+step<=now]
        if len(b)<need:continue
        prev,last=b[-2:];end=last[0]+step
        # A 1m signal may only enter its immediately following minute.
        window=min(p['entry_window_seconds'],step//1000)
        if not end<=now<end+window*1000:continue
        if any(b[j][0]-b[j-1][0]!=step for j in range(len(b)-need+1,len(b))):continue
        if prev[5]<=0 or last[5]<=0:continue
        prior=b[:-2];m=metrics(prior,c);atr=m['atr'];tol=atr*p['zone_atr']
        if atr<=0 or abs(last[4]-last[1])>atr*p['max_body_atr']:continue
        old=prior[-20:];old_low=min(r[3] for r in old);old_high=max(r[2] for r in old)
        bg={}
        for f in ('15m','1H','4H'):
            known=[r for r in frames.get(f,[]) if r[0]+STEPS[f]<=prev[0]]
            v=background(known,c)
            if v:
                v=dict(v,recent_high=max(r[2] for r in known[-20:]),recent_low=min(r[3] for r in known[-20:]))
                bg[f]=v
        refs=[*m['ma'].values(),m['mid'],m['lower'],m['upper'],old_low,old_high]
        for v in bg.values():refs.extend([*v['ma'].values(),v['mid'],v['upper'],v['lower'],v['recent_high'],v['recent_low']])
        rv=last[5]/(sum(r[5] for r in b[-21:-1])/20) if sum(r[5] for r in b[-21:-1]) else 0
        for side in (1,-1):
            direction='LONG' if side==1 else 'SHORT';test=min(prev[3],last[3]) if side==1 else max(prev[2],last[2])
            span=last[2]-last[3]
            if span<=0:continue
            location=(last[4]-last[3])/span if side==1 else (last[2]-last[4])/span
            reaction=(last[4]-prev[4])*side>=atr*p['reaction_atr'] and (last[4]-last[1])*side>0 and location>=p['close_fraction']
            stable=last[3]>=prev[3]-atr*p['break_tolerance_atr'] if side==1 else last[2]<=prev[2]+atr*p['break_tolerance_atr']
            extension=(last[4]-m['ma'][20])*side/atr
            recovery=(last[4]-test)*side/atr
            if extension>p['max_extension_atr'] or recovery>p['max_recovery_atr']:continue
            targets=[v for v in refs if (v-last[4])*side>atr*.1]
            if not targets:continue
            target=min(targets) if side==1 else max(targets)
            def emit(pattern,level,source,score,details):
                out.append(dict(direction=direction,pattern=pattern,frame=frame,low=min(prev[3],last[3]),
                    high=max(prev[2],last[2]),anchor=last[0],level=level,source=source,shape={},adaptive=True,
                    independent_support=True,independent_case=True,case_priority=True,evidence_score=score,
                    entry_window_seconds=window,target=target,evidence=dict(route=pattern,
                        completed_ms=end,relative_volume=rv,volume_required=False,all_timeframes_required=False,
                        background={f:dict(ma=v['ma'],slopes=v['slopes'],mid=v['mid'],upper=v['upper'],lower=v['lower']) for f,v in bg.items()},
                        reaction_confirmed=True,**dict({'two_bar_price_response':True},**details))))
            # A completed rejection candle is sufficient; no next-candle high/low break.
            if p['single_wick_enabled']:
                lm=metrics(b,c);body=abs(last[4]-last[1]);rng=span
                tail=min(last[1],last[4])-last[3] if side==1 else last[2]-max(last[1],last[4])
                opposite=last[2]-max(last[1],last[4]) if side==1 else min(last[1],last[4])-last[3]
                extreme=last[3] if side==1 else last[2]
                edge=lm['lower'] if side==1 else lm['upper']
                outside=(edge-extreme)*side>0
                returned=lm['lower']<=last[4]<=lm['upper']
                shaped=tail>=max(body*p['tail_body_ratio'],rng*p['tail_range_fraction'],atr*p['tail_atr']) and opposite/rng<p['max_opposite_fraction']
                # Reference levels must be known before this rejection candle.
                support_refs=[*m['ma'].values(),old_low if side==1 else old_high]
                for v in bg.values():support_refs.extend([*v['ma'].values(),v['recent_low'] if side==1 else v['recent_high']])
                nearby=[v for v in support_refs if abs(extreme-v)<=tol]
                if outside and returned and shaped and location>=p['close_fraction'] and nearby:
                    emit('case_single_wick_reversal_long' if side==1 else 'case_single_wick_reversal_short',min(nearby,key=lambda v:abs(extreme-v)),frame+' 확정 꼬리·밴드 복귀',16,
                         dict(tail_body=tail/max(body,atr*.000001),tail_fraction=tail/rng,band_return=True,
                              reference_extreme=old_low if side==1 else old_high,
                              two_bar_price_response=False,signal_candle_only=True))
                    out[-1]['low']=last[3];out[-1]['high']=last[2]
            if not reaction or not stable:continue
            if p['consolidation_enabled']:
                base=b[-p['consolidation_bars']-1:-1]
                aligned=(m['ma'][15]-m['ma'][20])*side>0 and m['slopes'][20]*side>0
                width=max(r[2] for r in base)-min(r[3] for r in base)
                rising=(base[-1][3]-base[0][3])*side>=0 if side==1 else (base[-1][2]-base[0][2])*side>=0
                level=max(r[4] for r in base) if side==1 else min(r[4] for r in base)
                if aligned and rising and width<=atr*p['consolidation_width_atr'] and (last[4]-level)*side>=atr*p['reaction_atr']:
                    emit('case_consolidation_long' if side==1 else 'case_consolidation_short',level,frame+' 추세 속 횡보·방향 재개',15,
                         dict(base_bars=len(base),base_width_atr=width/atr,local_trend_aligned=True))
            if p['support_enabled']:
                levels=[(n,v) for n,v in m['ma'].items()]+[('prior20_extreme',old_low if side==1 else old_high)]
                for n,level in levels:
                    touch=abs(test-level)<=tol
                    held=(prev[4]-level)*side>=-atr*p['break_tolerance_atr'] and (last[4]-level)*side>atr*p['reaction_atr']
                    prior_extreme=old_low if side==1 else old_high
                    intact=(test-prior_extreme)*side>=-atr*p['break_tolerance_atr']
                    if touch and held and intact:
                        emit('case_support_long' if side==1 else 'case_resistance_short',level,frame+' '+('SMA'+str(n) if isinstance(n,int) else '직전20봉 저점/고점'),14,
                             dict(reference=n,previous_extreme=prior_extreme,extreme_preserved=True,long_tail_required=False))
                        break
            if p['reversal_enabled']:
                body=abs(prev[4]-prev[1]);rng=prev[2]-prev[3]
                tail=min(prev[1],prev[4])-prev[3] if side==1 else prev[2]-max(prev[1],prev[4])
                opposite=prev[2]-max(prev[1],prev[4]) if side==1 else min(prev[1],prev[4])-prev[3]
                extreme=prev[3] if side==1 else prev[2];edge=m['lower'] if side==1 else m['upper']
                oldext=old_low if side==1 else old_high
                located=(edge-extreme)*side>=0 or abs(extreme-oldext)<=tol
                shaped=tail>=max(body*p['tail_body_ratio'],rng*p['tail_range_fraction'],atr*p['tail_atr']) and rng>0 and opposite/rng<p['max_opposite_fraction']
                returned=m['lower']<=last[4]<=m['upper']
                rejected=(last[4]-(prev[1]+prev[4])/2)*side>atr*p['reaction_atr']
                if located and shaped and returned and rejected:
                    emit('case_lower_rejection_long' if side==1 else 'case_upper_rejection_short',edge,frame+' 밴드/직전 극점 거부',16,
                         dict(tail_body=tail/max(body,atr*.000001),tail_fraction=tail/rng,band_return=True,reference_extreme=oldext))
            if p['breakout_enabled']:
                level=old_high if side==1 else old_low
                aligned=(m['ma'][15]-m['ma'][20])*side>0 and m['slopes'][20]*side>0
                broke=(prev[4]-level)*side>=atr*p['breakout_atr']
                retest=abs((last[3] if side==1 else last[2])-level)<=tol
                held=(last[4]-level)*side>0
                if aligned and broke and retest and held:
                    emit('case_breakout_long' if side==1 else 'case_breakdown_short',level,frame+' 직전20봉 돌파·재지지/재저항',15,
                         dict(breakout_level=level,retest_confirmed=True,local_trend_aligned=True))
    return out

"""Read-only OKX position history, source evidence and close-date PnL summaries."""
import calendar,hashlib,json,threading,time
from datetime import datetime,timedelta
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal,InvalidOperation
from okx_core import OKX,KST,BotError
FIELDS=('instId','posId','posSide','direction','mgnMode','ccy','cTime','uTime','type','openAvgPx','closeAvgPx','realizedPnl','fee','fundingFee','pnlRatio')

def amount(v):
 try:
  d=Decimal(str(v));return d if d.is_finite() else None
 except (InvalidOperation,ValueError,TypeError):return None

def bounds(day):
 d=datetime.strptime(day,'%Y-%m-%d').replace(tzinfo=KST);return int(d.timestamp()*1000),int((d+timedelta(days=1)).timestamp()*1000)
def key(r):return '|'.join(str(r.get(k) or '') for k in ('instId','posId','cTime','posSide','mgnMode'))
def stamp(v):
 try:return datetime.fromtimestamp(int(v)/1000,KST).strftime('%Y-%m-%d %H:%M:%S') if int(v)>0 else '미확인'
 except (TypeError,ValueError,OverflowError):return '미확인'

def classify(r,sources,settled):
 source=sources.get(key(r),{}).get('source')
 if source in ('auto','manual','mixed'):return source
 # Position IDs can be reused: require the same symbol/direction AND matching time window.
 matches=[s for s in settled if s.get('symbol')==r.get('instId') and s.get('posId') and str(s['posId'])==str(r.get('posId')) and abs(int(s.get('entry_ms',0))-int(r.get('cTime') or 0))<=120000 and abs(int(s.get('end_ms',0))-int(r.get('uTime') or 0))<=120000]
 if len(matches)==1 and matches[0].get('source') in ('auto','manual'):return matches[0]['source']
 return 'unknown'

def report(day,rows,sources=None,settled=None):
 start,end=bounds(day);out=[]
 for r in rows.values():
  if not isinstance(r,dict):continue
  try:closed_ms=int(r.get('uTime') or 0);int(r.get('cTime') or 0)
  except (TypeError,ValueError):continue
  if r.get('type') not in ('2','3','6') or not r.get('instId','').endswith('-USDT-SWAP'):continue
  if not start<=int(r.get('uTime') or 0)<end:continue
  value=amount(r.get('realizedPnl'));source=classify(r,sources or {},settled or [])
  out.append(dict(key=hashlib.sha256(key(r).encode()).hexdigest()[:20],symbol=r['instId'],source=source,
   direction=r.get('direction') or r.get('posSide') or '미확인',entry_time=stamp(r.get('cTime')),exit_time=stamp(r.get('uTime')),
   entry_price=r.get('openAvgPx'),exit_price=r.get('closeAvgPx'),pnl=str(value) if value is not None else None,roe=r.get('pnlRatio'),fee=r.get('fee'),funding=r.get('fundingFee'),exit_ms=int(r['uTime'])))
 out.sort(key=lambda r:r['exit_ms'],reverse=True)
 sums=dict(profit=Decimal(0),loss=Decimal(0),total=Decimal(0),auto=Decimal(0),manual=Decimal(0),unknown=Decimal(0))
 missing=0
 for r in out:
  v=amount(r['pnl'])
  if v is None:missing+=1;continue
  sums['profit' if v>0 else 'loss']+=v;sums['total']+=v;sums[r['source'] if r['source'] in ('auto','manual') else 'unknown']+=v
 return dict(date=day,rows=out,summary={k:str(v) for k,v in sums.items()},count=len(out),missing_pnl=missing,unknown_count=sum(r['source'] not in ('auto','manual') for r in out),basis='한국시간 청산일 기준 · 청산 완료 포지션 확정 손익')


def filter_report(data,source='all'):
 """Local display filter; preserves source evidence and never requests the exchange."""
 if source not in ('all','auto','manual','unknown'):raise ValueError('unknown history filter')
 if source=='all':return dict(data)
 rows=[r for r in data.get('rows',[]) if (r.get('source')==source if source!='unknown' else r.get('source') not in ('auto','manual'))]
 sums={k:Decimal(0) for k in ('profit','loss','total','auto','manual','unknown')};missing=0
 for r in rows:
  value=amount(r.get('pnl'))
  if value is None:missing+=1;continue
  sums['profit' if value>0 else 'loss']+=value;sums['total']+=value;sums[r['source'] if r.get('source') in ('auto','manual') else 'unknown']+=value
 unqueried=not data.get('rows') and data.get('summary') and all(v is None for v in data['summary'].values())
 return dict(data,rows=rows,count=len(rows),missing_pnl=missing,unknown_count=sum(r.get('source') not in ('auto','manual') for r in rows),summary={k:None if unqueried else str(v) for k,v in sums.items()})

class PositionHistory:
 def __init__(self,root,settings,events,api_factory=None):
  self.root=Path(root);self.settings=settings;self.events=events;self.api_factory=api_factory or OKX
  self.lock=threading.RLock();self.pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='position-history');self.future=None;self.active=False;self.pending=None;self.started=False;self.stopped=False;self.next_poll=0
  self.rows={};self.sources={};self.errors=[]
  for name,target in (('position_history_cache.json','rows'),('position_sources.json','sources')):
   try:
    p=self.root/name
    if p.exists():
     value=json.loads(p.read_text(encoding='utf-8'))
     if not isinstance(value,dict):raise ValueError('invalid history cache')
     setattr(self,target,value)
   except Exception:self.errors.append(name+' 읽기 실패: 새 조회 결과만 표시')
 def save(self,name,value):
  from okx_daily_report import atomic_json
  atomic_json(self.root/name,value)
 def start(self):self.started=True
 def stop(self):self.stopped=True;self.pool.shutdown(wait=False,cancel_futures=True)
 def observe(self,snapshot,records):
  changes=False
  with self.lock:
   for p in snapshot.get('positions',[]):
    if not p.get('posId') or not p.get('cTime') or not p.get('instId','').endswith('-USDT-SWAP') or not amount(p.get('pos')):continue
    record=next((r for r in records if (r['symbol'],r['direction'])==(p['instId'],p.get('posSide'))),None)
    source='manual'
    if record:
     source='manual' if record.get('v4_signal',{}).get('user_chat_order') else 'auto'
     if record.get('phase')=='active' and amount(record.get('quantity'))!=amount(p.get('pos')):source='mixed'
     if record.get('posId') and str(record['posId'])!=str(p['posId']):source='mixed'
    k=key(p);old=self.sources.get(k)
    if old and old.get('source')=='mixed':source='mixed'
    if old and old.get('source')!=source:source='mixed'
    value=dict(source=source)
    if old!=value:self.sources[k]=value;changes=True
   if changes:self.save('position_sources.json',self.sources)
 def settled(self):
  rows=[];p=self.root/'position_results.jsonl'
  if p.exists():
   try:lines=p.read_text(encoding='utf-8').splitlines()
   except OSError:return rows
   for line in lines:
    try:
     value=json.loads(line)
     if isinstance(value,dict):rows.append(value)
    except (ValueError,TypeError):continue
  return rows
 def payload(self,day,**extras):
  with self.lock:data=report(day,self.rows,self.sources,self.settled())
  if not data['count'] and (extras.get('loading') or extras.get('error')):data['summary']={k:None for k in data['summary']}
  data.update(extras);return data
 def tick(self,now):
  if self.started and not self.stopped and time.monotonic()>=self.next_poll:
   self.next_poll=time.monotonic()+60;self.request(datetime.fromtimestamp(now/1000,KST).strftime('%Y-%m-%d'),False)
 def request(self,day,force=True):
  bounds(day)
  with self.lock:
   if self.stopped:return
   self.events.put(('position_history',self.payload(day,loading=True,error=None,complete=False)))
   if self.active:
    if force:self.pending=day
    return
   self.pending=day;self.active=True;self.future=self.pool.submit(self.run)
 def run(self):
  api=None
  try:
   try:api=self.api_factory(self.settings)
   except Exception as error:
    with self.lock:day=self.pending;self.pending=None
    if day:self.events.put(('position_history',self.payload(day,loading=False,error='내역 연결 설정 확인: '+(str(error)[:180] if isinstance(error,BotError) else type(error).__name__),complete=False)))
    return
   while not self.stopped:
    with self.lock:day=self.pending;self.pending=None
    if day is None:return
    try:
     start,end=bounds(day);cursor=end;complete=False
     for page in range(20):
      if self.stopped:return
      data=api.get('/api/v5/account/positions-history',instType='SWAP',before=str(start-1),after=str(cursor),limit='100')
      with self.lock:
       for r in data:
        if r.get('instId','').endswith('-USDT-SWAP') and r.get('ccy') in ('USDT',None,''):
         value={k:r.get(k) for k in FIELDS};k=key(value)
         if int(value.get('uTime') or 0)>=int(self.rows.get(k,{}).get('uTime') or 0):self.rows[k]=value
      if not data or len(data)<100:complete=True;break
      oldest=min(int(r.get('uTime') or 0) for r in data)
      if oldest<=start:complete=True;break
      if oldest>=cursor:break
      cursor=oldest;time.sleep(.26)
     with self.lock:self.save('position_history_cache.json',self.rows)
     note='；'.join(self.errors)
     now=datetime.fromtimestamp(api.now_ms()/1000,KST);index=now.year*12+now.month-1-3;y,m=divmod(index,12);cutoff=now.replace(year=y,month=m+1,day=min(now.day,calendar.monthrange(y,m+1)[1]))
     if start<int(cutoff.timestamp()*1000):complete=False;note+=' / 최근3개월 조회 범위 이전 또는 경계 날짜: 저장된 일부 내역일 수 있습니다.'
     if not complete:note+=' / 조회 한도 또는 페이지 진행 제한: 일부 내역일 수 있습니다.'
     self.events.put(('position_history',self.payload(day,loading=False,error=note or None,complete=complete,updated_ms=api.now_ms())))
    except Exception as error:
     self.events.put(('position_history',self.payload(day,loading=False,error='내역 조회 실패: '+(str(error)[:180] if isinstance(error,BotError) else type(error).__name__)+' / 기존 캐시 표시',complete=False)))
    with self.lock:
     if self.pending is None:return
  finally:
   if api is not None:api.session.close()
   with self.lock:
    self.active=False
    if self.pending is not None and not self.stopped:self.active=True;self.future=self.pool.submit(self.run)

"""Post-market-fill arithmetic; no price cap is claimed for an actual market order."""
from okx_core import dec,fmt


def fill_assessment(position,owned,cfg):
    side=1 if owned['direction']=='long' else -1
    qty=abs(dec(position['pos']));ct=dec(owned['ct_val']);price=dec(position['avgPx'])
    stop=dec(owned['stop_px']);lev=dec(owned['leverage']);notional=qty*ct*price
    margin=notional/lev;distance=max(dec(0),(price-stop)*side)
    loss=qty*ct*(distance+price*dec(owned.get('cost_rate') or '.005'))
    stop_roe=(stop/price-1)*side*lev
    bound=owned.get('planned_entry_px');deviation=(price/dec(bound)-1)*side if bound else dec(0)
    stats=dict(avg_px=fmt(price),quantity=fmt(qty),notional_usdt=fmt(notional),margin_usdt=fmt(margin),
               estimated_stop_loss=fmt(loss),stop_roe=fmt(stop_roe),adverse_vs_estimate=fmt(deviation))
    budget=dec(owned.get('original_risk_budget') or dec(owned['entry_seed'])*dec(cfg['risk']['max_position_loss_fraction']))
    reason=None
    if (price-stop)*side<=0:reason='시장가 체결 시 기존 손절가가 진입가 반대편에 없음'
    elif not owned.get('v4_signal',{}).get('strategy')=='band_flow' and stop_roe<dec(cfg['risk']['final_stop_roe']):reason='시장가 실제 체결가 기준 최종 손절 ROE 한도 초과'
    elif owned.get('v4_signal',{}).get('strategy')=='band_flow' and dec(position.get('liqPx') or 0)>0 and (stop-dec(position['liqPx']))*side<=0:
        reason='구조 손절가보다 강제청산가가 먼저 도달: 체결분 정리'
    elif loss>budget and not (owned.get('v4_signal',{}).get('pattern15') and owned.get('initial_size_mode')=='fixed_third'):
        reason='시장가 실제 체결가 기준 포지션 예상 손실 한도 초과'
    return stats,reason

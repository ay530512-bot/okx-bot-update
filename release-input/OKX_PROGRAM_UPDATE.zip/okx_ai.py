"""One bounded analysis call, no exchange writes. Test model, no proven edge."""
import json
import time
from okx_core import BotError, dec
from okx_market import candidate, closed_candles, summarize, FRAMES, allowed_altcoin
from okx_strategy import entry_signals, spot_crypto_bases
from okx_scale import eligible_additions

MODEL = "gpt-4.1-mini"
MAX_OUTPUT = 700
INPUT_RATE = 0.40 / 1_000_000
OUTPUT_RATE = 1.60 / 1_000_000


def collect(api, equity, position=None, excluded_symbols=()):
    instruments = api.public("/api/v5/public/instruments", instType="SWAP")
    by_id = {i["instId"]: i for i in instruments}
    bases = spot_crypto_bases(api.public("/api/v5/public/instruments", instType="SPOT"))
    tickers = {t["instId"]: t for t in api.public("/api/v5/market/tickers", instType="SWAP")}
    candidates = []
    for inst in instruments:
        if inst["instId"] in excluded_symbols or inst["instId"].split("-")[0] not in bases:
            continue
        ticker = tickers.get(inst["instId"])
        if not ticker:
            continue
        try:
            item = candidate(inst, ticker, api.now_ms(), equity)
            if item:
                candidates.append(item)
        except (ValueError, KeyError, ArithmeticError):
            continue
    candidates.sort(key=lambda m: m["approx_24h_turnover_usdt"], reverse=True)
    if position:
        # Never substitute a different symbol when managing an existing position.
        symbol = position["instId"]
        if symbol not in by_id or symbol not in tickers:
            raise BotError("보유 종목의 시세가 없습니다.")
        ticker = tickers[symbol]
        selected = [{"symbol": symbol, "last": float(ticker["last"]),
                     "reference_contracts_by_leverage": {str(int(dec(position["lever"]))): position["pos"]}}]
    else:
        # Screen RSI/patterns for up to 30 liquid alts before selecting five for AI.
        screened = []
        for item in candidates[:24]:
            if item["approx_24h_turnover_usdt"] < 10_000_000:
                continue
            try:
                rows = api.public("/api/v5/market/candles", instId=item["symbol"], bar="15m", limit="150")
                frame = summarize(closed_candles(rows, "15m", api.now_ms()))
                item["screen_15m"] = frame
                volume = min(frame["last_volume_vs_previous20"] or 0, 4)
                item["screen_score"] = volume + max(0, 1 - abs(frame["rsi14"] - 50) / 30)
                screened.append(item)
                time.sleep(0.12)
            except Exception:
                continue
        selected = sorted(screened, key=lambda item: item["screen_score"], reverse=True)[:8]
    markets = []
    for item in selected:
        try:
            frames = {}
            for bar in FRAMES:
                if bar == "15m" and item.get("screen_15m"):
                    frames[bar] = item.pop("screen_15m")
                else:
                    rows = api.public("/api/v5/market/candles", instId=item["symbol"], bar=bar, limit="150")
                    frames[bar] = summarize(closed_candles(rows, bar, api.now_ms()))
                # Trim transmitted price precision while preserving raw significant values.
                frames[bar]["last_24_closed_bars"] = frames[bar]["last_24_closed_bars"][-8:]
                time.sleep(0.12)
            item["frames"] = frames
            item["entry_signals"] = entry_signals(frames)
            if not position and not any(item["entry_signals"].values()):
                continue
            if position:
                item["allowed_additions"] = (eligible_additions(position.get("_owned"), position, item)
                    if allowed_altcoin(by_id[item["symbol"]]) and item["symbol"].split("-")[0] in bases else [])
            markets.append(item)
            if len(markets) == 3:
                break
        except Exception:
            if position:
                raise BotError("보유 종목의 차트 자료가 불완전합니다.") from None
    return markets, by_id


INSTRUCTIONS = (
    "Use only supplied OKX closed-candle data; never invent facts or promise profit. "
    "All reason/risk text MUST be Korean and use supplied numeric evidence. "
    "Analyze RSI6/14/24 and their changes, EMA20/50, confirmed high/low structure, ATR, volume, "
    "upper/lower wicks across 5m/15m/1H/4H. Higher frames define trend; lower frames define "
    "pullback/rebound entries. Avoid chasing extended candles. A wick alone is not confirmation. "
    "No position: WAIT/NONE/3 or one LONG/SHORT only if its entry_signals[action] is true. "
    "Existing position: HOLD or CLOSE; ADD_AVERAGE/ADD_PYRAMID only from allowed_additions. "
    "Keep symbol/leverage. Judge each position independently of the daily return. "
    "Take a suitable profitable exit when continuation weakens; never wait for one trade to "
    "earn 6% of the account. HOLD a winner only with concrete continuation evidence. "
    "On adverse structural reversal close before liquidation; do not wait for -30% ROE. "
    "The account daily +6% is a goal, not an exit threshold. Even after +6%, keep selecting "
    "valid opportunities if new entries are enabled. Never force trades to meet a target. "
    "Midnight/session expiry alone never requires closing a position. END_DAY is not allowed. "
    "Independent rules enforce position loss/profit protection. State a concrete invalidation risk."
    "Apply the observed public trader's principles of repeated position evaluation and conditional "
    "size adjustment, not invented entry rules or copied outcome percentages. Preserve the user's "
    "altcoin-only universe. Execution records do not reveal the original trader's indicators."
)


def prompt_for(markets, position, daily_roi):
    supplied = None
    if position:
        supplied = {k: position.get(k) for k in ("instId", "posSide", "pos", "avgPx", "markPx", "lever", "uplRatio", "liqPx")}
    if supplied:
        owned = position.get("_owned", {})
        supplied["management"] = {k: owned.get(k) for k in ("peak_roe", "profit_floor_roe", "invalidation_px", "entry_ms")}
        supplied["estimated_roundtrip_fee_roe"] = abs(float(owned.get("entry_taker_fee", .0005))) * 2 * int(dec(position["lever"]))
        supplied["fee_note"] = "ROE is unrealized before full costs; fee estimate excludes funding, AI, slippage."
    return json.dumps({"markets": markets, "position": supplied,
                       "daily_equity_return": None if daily_roi is None else float(daily_roi),
                       "daily_goal_return": 0.06, "daily_goal_is_not_position_target": True,
                       "position_stop_roe": -0.30, "initial_margin_fraction": "1/3",
                       "scale_in": "one average and one pyramid, each at most entry seed / 6; maximum total margin 2/3"}, ensure_ascii=False, allow_nan=False)


def schema_for(markets):
    return {"type": "object", "additionalProperties": False,
            "properties": {
                "action": {"type": "string", "enum": ["LONG", "SHORT", "WAIT", "HOLD", "CLOSE", "ADD_AVERAGE", "ADD_PYRAMID"]},
                "symbol": {"type": "string", "enum": ["NONE"] + [m["symbol"] for m in markets]},
                "leverage": {"type": "integer", "enum": [3, 4, 5]},
                "reason": {"type": "string"}, "risk": {"type": "string"}},
            "required": ["action", "symbol", "leverage", "reason", "risk"]}


def upper_cost(prompt, schema):
    # Conservative byte-count upper bound plus protocol overhead, no cache discounts.
    token_bound = len((prompt + INSTRUCTIONS + json.dumps(schema)).encode("utf-8")) + 4096
    if token_bound > 55000:
        raise BotError("분석 자료가 너무 큽니다.")
    return token_bound * INPUT_RATE + MAX_OUTPUT * OUTPUT_RATE


def validate(result, markets, position, daily_roi):
    if not isinstance(result, dict) or set(result) != {"action", "symbol", "leverage", "reason", "risk"}:
        raise BotError("AI 응답 필드 오류")
    if type(result["leverage"]) is not int or result["leverage"] not in (3, 4, 5):
        raise BotError("AI 레버리지 범위 오류")
    if not all(isinstance(result[k], str) and result[k].strip() for k in ("reason", "risk")):
        raise BotError("AI 판단 근거 누락")
    action, symbol = result["action"], result["symbol"]
    if position:
        if action not in ("HOLD", "CLOSE", "ADD_AVERAGE", "ADD_PYRAMID") or symbol != position["instId"]:
            raise BotError("보유 포지션 외 AI 동작 거부")
        if result["leverage"] != int(dec(position["lever"])):
            raise BotError("보유 중 레버리지 변경 거부")
        if action.startswith("ADD_"):
            market = next((m for m in markets if m["symbol"] == symbol), None)
            if not market or action not in market.get("allowed_additions", []):
                raise BotError("추가 진입 조건 미충족: AI 추가 진입 거부")
    else:
        if action not in ("LONG", "SHORT", "WAIT"):
            raise BotError("포지션 없는 상태의 AI 동작 오류")
        if action in ("WAIT",):
            if symbol != "NONE":
                raise BotError("대기 또는 종료 종목 오류")
        else:
            market = next((m for m in markets if m["symbol"] == symbol), None)
            if (not market or str(result["leverage"]) not in market["reference_contracts_by_leverage"]
                    or not market.get("entry_signals", {}).get(action)):
                raise BotError("허용하지 않은 종목 또는 수량")
    return result


def analyze(settings, equity, position, daily_roi, remaining_budget, reserve_callback):
    from okx_core import OKX
    from openai import OpenAI
    api = OKX(settings)
    try:
        markets, instruments = collect(api, equity, position, settings.get("_EXCLUDED_SYMBOLS", ()))
        if not markets:
            return {"no_candidates": True, "cost": 0}
        prompt = prompt_for(markets, position, daily_roi)
        if settings.get("_PORTFOLIO"):
            prompt += "\nExisting portfolio; new candidates must offer strong independent opportunity, otherwise WAIT: " + json.dumps(settings["_PORTFOLIO"], ensure_ascii=False)
        schema = schema_for(markets)
        reserved = upper_cost(prompt, schema)
        if reserved > remaining_budget:
            raise BotError("AI 하루 예산 부족: 신규 분석을 중단합니다.")
        billing_day = reserve_callback(reserved)  # Persist before submitting a paid request.
        started = time.monotonic()
        try:
            client = OpenAI(api_key=settings["OPENAI_API_KEY"], timeout=40, max_retries=0)
            response = client.responses.create(model=MODEL, store=False, max_output_tokens=MAX_OUTPUT,
                    instructions=INSTRUCTIONS, input=prompt,
                    text={"format": {"type": "json_schema", "name": "trade_decision", "strict": True, "schema": schema}})
        except Exception as error:
            # Never leak SDK exception messages containing API keys.
            raise BotError("AI 호출 실패: " + type(error).__name__ + ". 보유 포지션 보호 관리는 계속합니다.") from None
        if response.status != "completed" or not response.output_text:
            raise BotError("AI 응답 미완료·거부: 주문하지 않습니다.")
        actual_cost = reserved
        tokens = "사용량 미확인"
        if response.usage:
            actual_cost = response.usage.input_tokens * INPUT_RATE + response.usage.output_tokens * OUTPUT_RATE
            tokens = f"입력 {response.usage.input_tokens}, 출력 {response.usage.output_tokens}"
        result = validate(json.loads(response.output_text), markets, position, daily_roi)
        return {"decision": result, "instruments": instruments, "markets": markets,
                "age": time.monotonic() - started, "cost": actual_cost, "reserved": reserved,
                "billing_day": billing_day,
                "tokens": tokens, "completed_monotonic": time.monotonic()}
    finally:
        api.session.close()

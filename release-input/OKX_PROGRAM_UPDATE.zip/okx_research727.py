"""Offline-only, predeclared entry filters. No imports by the live engine.

These are research hypotheses, not validated trading recommendations.
The original proof and all exit/SL settings are preserved.
"""
import copy
import math

VARIANTS = ('current_mild726', 'band_reclaim727', 'cost_room727', 'combined727')


def filter_setup(proof, completed, variant):
    if variant not in VARIANTS:
        raise ValueError('Unknown research variant: ' + variant)
    if proof is None:
        return None
    if variant == 'current_mild726':
        return copy.deepcopy(proof)
    try:
        end = int(proof['confirmation_ms']) + 900000
        bars = [r for r in completed if r[0] + 900000 <= end]
        if len(bars) < 21 or bars[-1][0] + 900000 != end:
            return None
        if any(y[0]-x[0] != 900000 for x,y in zip(bars[-21:], bars[-20:])):
            return None
        if any(len(r)<6 or not all(math.isfinite(float(x)) for x in r[:6])
               or min(r[1:5])<=0 or r[5]<0
               or not r[3]<=min(r[1],r[4])<=max(r[1],r[4])<=r[2] for r in bars[-21:]):
            return None
        price, atr = float(proof['reference']), float(proof['atr'])
        if not all(math.isfinite(v) and v > 0 for v in (price, atr)):
            return None
        if proof['action'] not in ('LONG', 'SHORT'):
            return None
        side = 1 if proof['action'] == 'LONG' else -1
        # Fee .05% + slippage .05% on each side => round trip .20%.
        # Require one ATR >= 1.5x that assumed cost (.30% of price).
        # Fixed hypothesis for entry, unchanged between normal/stress replay.
        if variant in ('cost_room727', 'combined727') and atr/price < .003:
            return None
        if variant in ('band_reclaim727', 'combined727') and proof['route721'] == 'exhaustion724':
            prior = bars[-2]
            prior_cs = [float(r[4]) for r in bars[-21:-1]]
            cs = [float(r[4]) for r in bars[-20:]]
            mid = sum(cs)/20
            sd = math.sqrt(sum((c-mid)**2 for c in cs)/20)
            oldmid = sum(prior_cs)/20
            oldsd = math.sqrt(sum((c-oldmid)**2 for c in prior_cs)/20)
            oldedge = oldmid-side*2*oldsd
            extreme = prior[3] if side == 1 else prior[2]
            if sd <= 0 or oldsd <= 0 or (extreme-oldedge)*side >= 0:
                return None
            close = float(bars[-1][4])
            # Re-entry must be inside the signal candle's closed BB(20,2),
            # and recover half of the prior expansion candle's real body.
            if not mid-2*sd < close < mid+2*sd:
                return None
            if (close-(prior[1]+prior[4])/2)*side <= 0:
                return None
        return copy.deepcopy(proof)
    except (KeyError, TypeError, ValueError, IndexError, OverflowError):
        return None

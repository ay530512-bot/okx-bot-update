class CandleReadGate:
    """One process-wide budget for /market/candles across all OKX sessions.

    18/s leaves headroom below the documented 40/2s IP limit. Other
    processes on the same IP are outside this gate; 429 triggers cooldown.
    No order/position/mark-price request waits on this gate.
    """
    def __init__(self, clock=None, sleep=None):
        import time, threading
        self.clock=clock or time.monotonic;self.sleep=sleep or time.sleep
        self.lock=threading.Lock();self.next_at=0.;self.until=0.;self.failures=0;self.last_limit=-1e9
    def acquire(self):
        while True:
            with self.lock:
                now=self.clock();delay=max(self.next_at,self.until)-now
                if delay<=0:
                    self.next_at=now+1/18
                    return
            self.sleep(min(delay,.1))
    def limited(self):
        with self.lock:
            now=self.clock()
            if now<self.until:return # coalesce responses from the same burst
            self.failures=1 if now-self.last_limit>60 else min(self.failures+1,5)
            self.last_limit=now;self.until=now+min(30,2**self.failures)

CANDLE_READ_GATE=CandleReadGate()

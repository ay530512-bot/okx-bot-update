"""Explicit v3 experimental entry and exit rules. No network writes."""
from okx_core import BotError, dec
from okx_market import FRAMES, closed_candles, summarize, allowed_altcoin

ENTRY_INTERVAL = 300
POSITION_INTERVAL = 60
CHART_INTERVAL = 30
PROFIT_ARM_ROE = .04
PROFIT_GIVEBACK_FRACTION = .30
PROFIT_MIN_GIVEBACK_ROE = .02


def load_frames(api, symbol):
    result = {}
    for bar in FRAMES:
        rows = api.public('/api/v5/market/candles', instId=symbol, bar=bar, limit='150')
        result[bar] = summarize(closed_candles(rows, bar, api.now_ms()))
    return result


def spot_crypto_bases(instruments):
    return {i.get('baseCcy') for i in instruments
            if i.get('state') == 'live' and i.get('instCategory') == '1'
            and i.get('quoteCcy') == 'USDT' and i.get('baseCcy')}


def verified_altcoin(api, instrument):
    if not allowed_altcoin(instrument):
        return False
    spot = api.public('/api/v5/public/instruments', instType='SPOT')
    return instrument['instId'].split('-')[0] in spot_crypto_bases(spot)


def entry_signals(frames):
    """Require higher-timeframe trend plus a closed-candle pullback/rebound.

    Numeric cutoffs are implementation assumptions, not inferred trader rules.
    """
    if set(FRAMES) - set(frames):
        return {'LONG': False, 'SHORT': False}
    f, m, h, q = (frames[k] for k in FRAMES)
    bars = f['last_24_closed_bars']
    last = bars[-1]
    atr = max(f['atr14'], last[4] * .0001)
    touched_long = any(b[3] <= f['ema20'] + .35 * atr for b in bars[-4:])
    touched_short = any(b[2] >= f['ema20'] - .35 * atr for b in bars[-4:])
    lower_reject = any((min(b[1], b[4]) - b[3]) / max(b[2] - b[3], 1e-12) >= .35 for b in bars[-3:])
    upper_reject = any((b[2] - max(b[1], b[4])) / max(b[2] - b[3], 1e-12) >= .35 for b in bars[-3:])
    long_trend = all(x['ema20'] > x['ema50'] and x['last_close'] >= x['ema50']
                     and x['rsi24'] >= 48 for x in (h, q))
    short_trend = all(x['ema20'] < x['ema50'] and x['last_close'] <= x['ema50']
                      and x['rsi24'] <= 52 for x in (h, q))
    volume = (f['last_volume_vs_previous20'] or 0) >= .6
    return {
        'LONG': bool(long_trend and m['ema20'] >= m['ema50'] and m['rsi14'] >= 45
                     and touched_long and lower_reject and last[4] > last[1]
                     and last[4] >= f['ema20'] and last[4] >= f['previous_close']
                     and f['rsi6'] > f['rsi6_previous'] and 40 <= f['rsi14'] <= 70
                     and f['rsi24'] >= 45 and last[4] - f['ema20'] <= 1.5 * atr and volume),
        'SHORT': bool(short_trend and m['ema20'] <= m['ema50'] and m['rsi14'] <= 55
                      and touched_short and upper_reject and last[4] < last[1]
                      and last[4] <= f['ema20'] and last[4] <= f['previous_close']
                      and f['rsi6'] < f['rsi6_previous'] and 30 <= f['rsi14'] <= 60
                      and f['rsi24'] <= 55 and f['ema20'] - last[4] <= 1.5 * atr and volume)}


def invalidation_level(frames, direction):
    frame = frames['15m']
    if direction == 'long':
        return (frame['confirmed_swing_low'] or frame['previous_5_low']) - frame['atr14'] * .1
    return (frame['confirmed_swing_high'] or frame['previous_5_high']) + frame['atr14'] * .1


def chart_exit(frames, position):
    """Closed lower-timeframe structure break with confirming momentum."""
    f, m = frames['5m'], frames['15m']
    if position['posSide'] == 'long':
        broken = f['last_close'] < f['previous_5_low'] or m['last_close'] < m['previous_5_low']
        reversal = f['last_close'] < f['ema20'] and f['rsi6'] < f['rsi14'] and m['rsi6'] < m['rsi6_previous']
    else:
        broken = f['last_close'] > f['previous_5_high'] or m['last_close'] > m['previous_5_high']
        reversal = f['last_close'] > f['ema20'] and f['rsi6'] > f['rsi14'] and m['rsi6'] > m['rsi6_previous']
    return '5분/15분 고저점 이탈과 반대 모멘텀 확인' if broken and reversal else None


def quick_exit(owned, position):
    """Fast per-position rules, independent of daily targets and paid AI budget."""
    roe = float(dec(position['uplRatio']))
    old_peak = float(owned.get('peak_roe', roe))
    owned['peak_roe'] = peak = max(old_peak, roe)
    mark = dec(position['markPx'])
    liq = dec(position.get('liqPx') or 0)
    long = position['posSide'] == 'long'
    if liq > 0 and ((long and mark <= liq * dec('1.02')) or (not long and mark >= liq * dec('.98'))):
        return '예상 청산가격 접근: 선제 청산'
    level = dec(owned.get('invalidation_px') or 0)
    if level > 0 and ((long and mark <= level) or (not long and mark >= level)):
        return '진입 당시 고저점 기반 무효화 가격 이탈'
    if peak >= PROFIT_ARM_ROE:
        estimated_cost = abs(float(owned.get('entry_taker_fee', .0005))) * 2 * int(owned['leverage']) + .002
        threshold = max(estimated_cost, peak - max(PROFIT_MIN_GIVEBACK_ROE, peak * PROFIT_GIVEBACK_FRACTION))
        owned['profit_floor_roe'] = threshold
        if roe <= threshold:
            return f'포지션 수익 보호: 최고 ROE {peak * 100:.2f}% → 현재 {roe * 100:.2f}%'
    return None

"""Closed-candle trend reversal exits and volume-aware ROE profit extensions."""
from okx_swing_context import STEPS
DEFAULTS=dict(enabled=True,profit_roe=.10,partial_fraction=.35,strong_relative_volume=1.25,
 strength_bars=3,volume_history=20,strong_move_atr=.5,strong_slope_atr=.03,
 reversal_move_atr=.35,ma_break_atr=.15,trail_buffer_atr=.8,initial_stop_buffer_atr=.8)
def settings(c):return dict(DEFAULTS,**c.get('risk',{}).get('dynamic_exit',{}))
def enabled(c):return c.get('risk',{}).get('dynamic_exit',{}).get('enabled',False)
def validate(p):
 return (type(p['enabled']) is bool and .03<=p['profit_roe']<=1 and .1<=p['partial_fraction']<=.9
  and 1<=p['strong_relative_volume']<=4 and type(p['strength_bars']) is int and 2<=p['strength_bars']<=5
  and type(p['volume_history']) is int and 10<=p['volume_history']<=60 and .1<=p['strong_move_atr']<=2
  and 0<=p['strong_slope_atr']<=1 and .1<=p['reversal_move_atr']<=2 and 0<=p['ma_break_atr']<=1
  and .25<=p['trail_buffer_atr']<=2 and .25<=p['initial_stop_buffer_atr']<=2)

def evaluate(frames,position,owned,c,now):
 cfg=settings(c);rule=owned.get('holding_rule') or {};frame=rule.get('frame','5m');step=STEPS.get(frame,300000)
 result=dict(action='HOLD',reason='기준 시간봉 추세 감시·보호 손절 유지',frame=frame,strong=False,trail=None,bar_ms=0)
 b=[r for r in frames.get(frame,[]) if r[0]+step<=now]
 need=max(c['indicators']['ma_periods'])+c['signals']['slope_bars']+3
 if len(b)<need or not 0<=now-(b[-1][0]+step)<step:
  result['reason']='기준 시간봉 완료 데이터 대기·보호 손절 유지';return result
 result['bar_ms']=b[-1][0]
 if b[-1][0]+step<=owned.get('entry_ms',now):
  result['reason']='진입 후 기준 시간봉 완료 대기·보호 손절 유지';return result
 from okx_rules import metrics
 m=metrics(b,c);atr=m['atr'];side=1 if owned['direction']=='long' else -1;prev,last=b[-2:]
 zone=rule.get('zone');tolerance=rule.get('tolerance',atr*.15)
 broken=zone is not None and all((r[4]-zone)*side < -max(tolerance,atr*.5) for r in b[-2:]) and prev[0]>=owned.get('entry_ms',now)
 # Two completed post-entry bars must confirm the directional move and MA20 failure.
 two=prev[0]+step>owned.get('entry_ms',now)
 adverse=two and (last[4]-b[-3][4])*side < -atr*cfg['reversal_move_atr'] and (last[4]-prev[4])*side<0
 ma_broken=all((r[4]-m['ma'][20])*side < -atr*cfg['ma_break_atr'] for r in b[-2:])
 structure=(last[2]-prev[2])*side<0 and (last[3]-prev[3])*side<0
 entry=float(position.get('avgPx') or 0)
 initial=owned.get('initial_risk_px')
 if initial is None:
  # Frozen entry structure remains stable after stop tightening.
  initial=abs(entry-(float(zone)-side*atr*cfg['initial_stop_buffer_atr'])) if zone is not None else abs(entry-float(owned['stop_px']))
 risk=max(float(initial),1e-12);progress=(float(position['markPx'])-entry)*side/risk
 if broken or (adverse and ma_broken and structure and progress>=1):
  result.update(action='CLOSE',reason=frame+' '+('진입 지지/저항 구간 종가 이탈' if broken else '반대 방향 진행·MA20 이탈·고저점 악화 확인'));return result
 n=cfg['strength_bars'];history=b[-cfg['volume_history']-n:-n]
 baseline=sum(r[5] for r in history)/len(history) if history else 0
 rv=(sum(r[5] for r in b[-n:])/n)/baseline if baseline>0 else 0
 move=(last[4]-b[-n-1][4])*side/atr
 strong=(rv>=cfg['strong_relative_volume'] and move>=cfg['strong_move_atr'] and m['slopes'][20]*side>=cfg['strong_slope_atr'] and (last[4]-m['ma'][20])*side>=0)
 result.update(strong=strong,relative_volume=rv,move_atr=move)
 # Tighten only. Never recompute an existing SL farther away because the new initial buffer grew.
 extreme=min(r[3] for r in b[-n:]) if side==1 else max(r[2] for r in b[-n:])
 target=extreme-side*atr*cfg['trail_buffer_atr'];old=float(owned['stop_px']);mark=float(position['markPx'])
 post=[r for r in b if r[0]>=owned.get('entry_ms',now)]
 # A completed post-entry pivot must form above entry for longs (below for shorts).
 pivot=None
 for i in range(1,len(post)-1):
  a,z,d=post[i-1:i+2]
  if (side==1 and z[3]<a[3] and z[3]<=d[3]) or (side==-1 and z[2]>a[2] and z[2]>=d[2]):
   pivot=z[3] if side==1 else z[2]
 if pivot is not None:target=pivot-side*atr*cfg['trail_buffer_atr']
 if progress>=1 and pivot is not None and (target-entry)*side>entry*float(owned.get('cost_rate') or .003) and (target-old)*side>0 and (mark-target)*side>0:result['trail']=target
 roe=float(position.get('uplRatio') or 0)
 target_hit=rule.get('target') is not None and (mark-float(rule['target']))*side>=0
 if (progress>=1.5 or target_hit) and not owned.get('partial_used') and not owned.get('partial_unsplittable'):
  from okx_wave_mode import net_profitable
  if strong and progress<2 and not target_hit:result.update(action='EXTEND',reason=f"추세 유지·최초 위험 대비 {progress:.2f}R 진행: 1차 익절 유예")
  elif net_profitable(position,owned):result.update(action='PARTIAL',reason=f"최초 위험 대비 {progress:.2f}R / 목표 구간 확인: {cfg['partial_fraction']*100:g}% 익절·잔여 추세 보유")

 return result

def ai_partial_allowed(frames,position,owned,c,now):
 if not enabled(c):return True
 verdict=evaluate(frames,position,owned,c,now)
 return verdict['action']=='PARTIAL'

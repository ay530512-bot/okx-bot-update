"""Persistent $6/day and rolling-24h shared caps, with paced automatic analysis."""
import time,uuid
from datetime import datetime,timedelta
from okx_core import BotError,day_key
DEFAULTS=dict(enabled=True,hard_daily_usd=6.,auto_daily_usd=6.,chat_daily_usd=0.)

def settings(c):return dict(DEFAULTS,**c.get('execution',{}).get('budget_pacing',{}))
def enabled(c):return c.get('execution',{}).get('budget_pacing',{}).get('enabled',False)
def validate(p):return type(p['enabled']) is bool and 0<p['hard_daily_usd']<=6 and 0<p['auto_daily_usd'] and 0<=p['chat_daily_usd'] and abs(p['auto_daily_usd']+p['chat_daily_usd']-p['hard_daily_usd'])<1e-9

def limits(engine):
 p=settings(engine.cfg);cap=min(6.,float(engine.budget),p['hard_daily_usd']);scale=cap/p['hard_daily_usd']
 return cap,p['auto_daily_usd']*scale,p['chat_daily_usd']*scale

def refill(engine,now):
 d=engine.journal.data;cap,auto,chat=limits(engine);capacity=auto/24
 state=d.setdefault('budget_pacing',dict(last_ms=now,credit=capacity,limit=cap))
 previous_limit=state.get('limit',cap)
 if previous_limit>0 and previous_limit!=cap:state['credit']=state['credit']*cap/previous_limit
 elapsed=max(0,now-state['last_ms']);state['last_ms']=max(now,state['last_ms'])
 # One hour's buffer initially; the remaining automatic allowance accrues over 24h.
 state['credit']=min(capacity,max(0,state['credit'])+elapsed*(auto-capacity)/86400000)
 state['limit']=cap
 return state

def guard(engine,reserve,channel):
 if not enabled(engine.cfg):return
 now=engine.api.now_ms();d=engine.journal.data;today=day_key(now);cap,auto,chat=limits(engine)
 rows=d.setdefault('model_usage',[])
 if not d.get('budget_pacing_initialized'):
  prior_day=d.get('api_day');yesterday=(datetime.strptime(today,'%Y-%m-%d')-timedelta(days=1)).strftime('%Y-%m-%d')
  known=sum(r['cost'] for r in rows if r['day']==prior_day)
  older=max(0,float(d.get('api_spent',0))-known) if prior_day in (today,yesterday) else 0
  if older>1e-9:rows.append(dict(id=uuid.uuid4().hex,ms=now,day=prior_day,channel='prior',model='prior-unclassified',cost=older,status='carried',input_tokens=None,output_tokens=None))
  d['budget_pacing_initialized']=True
 active=[r for r in rows if now-86400000<r['ms']<=now]
 rolling=sum(r['cost'] for r in active);daily=float(d.get('api_spent',0)) if d.get('api_day')==today else 0
 group='chat' if channel=='chat' else 'auto'
 group_used=sum(r['cost'] for r in active if (r['channel']=='chat')==(group=='chat'))
 allowance=chat if group=='chat' else auto
 state=refill(engine,now);reason=None
 if max(rolling,daily)+reserve>cap+1e-9:reason='AI 공용 최대 $6 및 최근24시간 예산 대기: 기존 사용액은 초기화하지 않습니다.'
 elif group_used+reserve>allowance+1e-9:reason=('채팅' if group=='chat' else '자동 판단')+f' 최근24시간 배정 ${allowance:.2f} 예산 대기'
 elif group=='auto' and reserve>state['credit']+1e-9:
  rate=(auto-auto/24)/86400;seconds=max(1,int((reserve-state['credit'])/rate)+1)
  reason=f'24시간 분배 예산 대기: 예약 여유 ${state["credit"]:.4f}, 다음 여유 약 {seconds//60}분 {seconds%60}초 후 / 보호 손절 유지'
 if reason:engine.journal.save();raise BotError(reason)
 if group=='auto':state['credit']-=reserve
 engine.journal.save()

def settle(engine,reserved,cost,channel):
 if not enabled(engine.cfg) or channel=='chat':return
 state=refill(engine,engine.api.now_ms());_,auto,_=limits(engine)
 state['credit']=min(auto/24,max(0,state['credit']+reserved-cost))

def snapshot(engine):
 if not enabled(engine.cfg):return None
 now=engine.api.now_ms();cap,auto,chat=limits(engine);rows=[r for r in engine.journal.data.get('model_usage',[]) if now-86400000<r['ms']<=now]
 state=refill(engine,now)
 return dict(cap=cap,auto_cap=auto,chat_cap=chat,rolling_spent=sum(r['cost'] for r in rows),auto_credit=round(state['credit'],4),
  mode='자동 신규5분·보유별5분 / 로컬 위험 감시는 계속',entry_calls_per_hour=12,manage_calls_per_position_per_hour=12)

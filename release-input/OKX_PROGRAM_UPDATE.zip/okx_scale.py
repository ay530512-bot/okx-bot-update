"""Explicit experimental scale-in gates. These thresholds have no proven edge."""
from decimal import ROUND_UP, ROUND_DOWN
from okx_core import dec, fmt, BotError


def legs_for(owned):
    if owned.get("legs"):
        return owned["legs"]
    return [{"algo_client_id": owned["algo_client_id"], "quantity": owned["quantity"], "stop_px": owned["stop_px"]}]


def eligible_additions(owned, position, market):
    if not owned or owned.get("phase") != "active" or not owned.get("entry_seed"):
        return []
    if "_available_margin_room" in owned and dec(owned["_available_margin_room"]) <= 0:
        return []
    from okx_strategy import entry_signals
    frames = market["frames"]
    signal = entry_signals(frames).get("LONG" if position["posSide"] == "long" else "SHORT", False)
    if not signal:
        return []
    roe = dec(position["uplRatio"])
    volume = frames["5m"]["last_volume_vs_previous20"] or 0
    allowed = []
    if (not owned.get("average_used") and not owned.get("pyramid_used")
            and dec("-.25") < roe < dec("-.02") and volume >= .8):
        allowed.append("ADD_AVERAGE")
    if not owned.get("pyramid_used") and roe >= dec(".03") and volume >= .8:
        allowed.append("ADD_PYRAMID")
    return allowed


def tightened_stop(owned, position, instrument, fee):
    """Never loosen original stop. After pyramiding seek estimated fee-adjusted break-even."""
    if owned.get('v4_signal',{}).get('strategy')=='band_flow':return owned['stop_px']
    avg, tick, old = dec(position["avgPx"]), dec(instrument["tickSz"]), dec(owned["stop_px"])
    leverage = owned["leverage"]
    long = owned["direction"] == "long"
    if owned.get("pyramid_used"):
        buffer = abs(dec(fee)) * 2 + dec("0.001")
        target = avg * (1 + buffer if long else 1 - buffer)
    else:
        target = avg * (1 - dec(".30") / leverage if long else 1 + dec(".30") / leverage)
    target = (target / tick).to_integral_value(rounding=ROUND_UP if long else ROUND_DOWN) * tick
    target = max(target, old) if long else min(target, old)
    mark = dec(position["markPx"])
    if (long and target >= mark) or (not long and target <= mark):
        raise BotError("수정할 보호 가격이 현재 가격에 도달했습니다. 추가 보유 대신 청산 필요.")
    return fmt(target)

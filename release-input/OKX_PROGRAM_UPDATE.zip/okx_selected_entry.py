"""Explicit selected-symbol entry: AI chooses among risk-feasible plans, never WAIT-only pattern gating."""
import copy,uuid
from collections import Counter
from okx_core import BotError,dec,size_plan,fmt
from okx_autonomous import packet,make_signal
from okx_rules import metrics
from okx_liquidity import book_check,risk_plan
from okx_entry_pipeline import funding_rate
SCHEMA={'type':'object','properties':{'choice':{'type':'integer'},'reason':{'type':'string'}},'required':['choice','reason'],'additionalProperties':False}
INSTRUCTIONS='''사용자가 이 종목을 선택하고 실제 AI 진입 버튼을 눌렀다. 제공된 choices는 현재 잔고·호가·비용·손절·손실 한도 사전 계산을 통과한 신규 진입 계획이다.
1분/5분/15분/1H/4H 완료봉의 추세와 파동을 종합해 가장 타당한 계획1개의 choice 인덱스를 반드시 선택하라. WAIT 또는 추가 패턴 대기는 이 명시적 선택 진입의 선택지가 아니다.
자동매매의 쌍고점/쌍저점은 이 사용자 선택 요청의 필수가 아니다. 가격 위치·파동 진행·주요 지지저항·이동평균·볼밴과 손익비를 비교하라. 방향·배율·손절은 제공 계획 안에서 고르고 가격을 지어내지 마라.
수익 확률이나 성과를 보장하지 않는다. reason은 한국어160자 이내. 프로그램은 최종 재검증 후 실제 주문하며 조건이 바뀌면 보류할 수 있다.'''

def build_choices(e,symbol,instrument):
 snapshot=e.snapshot();e.risk_snapshot(snapshot)
 if not e.account_stream.fresh():raise BotError('계정 데이터 지연')
 original=e.fresh_bars(symbol);cfg=copy.deepcopy(e.cfg);cfg['signals']['wave_mode']['enabled']=False
 p=packet(symbol,original,cfg,e.api.now_ms())
 ticker=e.api.public('/api/v5/market/ticker',instId=symbol)[0]
 if not 0<=e.api.now_ms()-int(ticker['ts'])<=10000:raise BotError('선택 종목 시세 지연')
 price=(float(ticker['bidPx'])+float(ticker['askPx']))/2;p['price']=price
 fee=e.api.taker_fee(instrument);funding=funding_rate(e.api,symbol,e.cfg);book=e.api.public('/api/v5/market/books',instId=symbol,sz='400')[0]
 seed=e.allocation_seed(snapshot);remaining=seed*dec(e.cfg['risk']['max_total_notional_fraction'])-e.exposure(snapshot)
 open_risk=e.open_risk(snapshot);day_room=e.day_room(snapshot);margin_cap=e.initial_margin_cap(snapshot)
 options=[];reasons=Counter()
 for action,d in p['directions'].items():
  side=1 if action=='LONG' else -1;direction='long' if side==1 else 'short';plans=[]
  for frame in ('5m','15m','1H','4H'):
   b=original.get(frame,[])
   if len(b)<max(e.cfg['indicators']['ma_periods'])+3:continue
   m=metrics(b,e.cfg);bars=b[-12:];extreme=min(r[3] for r in bars) if side==1 else max(r[2] for r in bars)
   at=next(r[0] for r in reversed(bars) if (r[3] if side==1 else r[2])==extreme)
   from okx_dynamic_exit import settings as exit_settings,enabled as exit_enabled
   buffer=exit_settings(e.cfg)['initial_stop_buffer_atr'] if exit_enabled(e.cfg) else .5
   stop=extreme-side*m['atr']*buffer
   target=max(r[2] for r in b[-20:]) if side==1 else min(r[3] for r in b[-20:])
   if (target-price)*side<=0:continue
   if stop<=0 or (price-stop)*side<=0:continue
   h=dict(pattern='selected_closed_range',frame=frame,first=extreme,second=extreme,second_ms=at,wave_extreme=extreme,stop=stop,max_hold_seconds=86400,source='최근12개 완료봉 극점')
   plans.append(dict(frame=frame,stop=stop,target=target,structure=h,wave=True,source='사용자 선택 파동',max_hold_seconds=86400))
  if not plans:continue
  local=copy.deepcopy(p);local['directions'][action].update(stop_options=[x['stop'] for x in plans],stop_plans=plans)
  for index,struct in enumerate(plans):
   local['directions'][action].update(target=struct['target'],target_source=struct['frame']+' 최근20개 완료봉 반대 극점')
   for leverage in (3,5,7,10):
    if leverage>int(float(instrument['lever'])):continue
    try:
     s=make_signal(dict(action=action,symbol=symbol,leverage=leverage,stop_index=index,reason='사용자 선택 종목 AI 진입 요청'),local,e.cfg)
     s['holding_rule']['source']='사용자 선택 완료봉 구간 '+struct['frame']
     s.update(selected_ai_order=True,user_chat_order=True,signal_id='selected-'+uuid.uuid4().hex[:24],valid_from_ms=e.api.now_ms(),expires_ms=e.api.now_ms()+45000,entry_gap=min(p['frames'][struct['frame']]['atr']*.25,price*.005))
     plan=size_plan(instrument,seed,snapshot['available'],leverage,ticker['bidPx'],ticker['askPx'],fee,margin_cap=margin_cap,strict_initial=True,max_rounding_fraction=e.cfg['risk'].get('fixed_initial_max_rounding_fraction',.03))
     check=book_check(book,instrument,plan['quantity'],direction,e.api.now_ms(),e.cfg);plan['buy' if side==1 else 'sell']=check['limit_px']
     risk=risk_plan(plan,instrument,s,direction,seed,snapshot['available'],fee,funding['fundingRate'],dict(e.cfg,risk=dict(e.cfg['risk'],leverage=leverage)),open_risk,day_room)
     if dec(risk['quantity'])*dec(instrument['ctVal'])*dec(plan['buy' if side==1 else 'sell'])>remaining:raise BotError('총노출 한도 부족')
     options.append(dict(signal=s,preview=dict(action=action,leverage=leverage,frame=struct['frame'],stop=s['stop'],target=s['target'],quantity=risk['quantity'],margin=risk['margin_bound'],estimated_loss=risk['estimated_loss'],net_reward_risk=risk['reward_risk'])))
    except BotError as error:reasons[str(error).split(':',1)[0]]+=1
 if not options:raise BotError('선택 진입 가능한 주문 계획 없음: '+str(dict(reasons)))
 # Retain both directions and avoid an oversized, costly prompt.
 groups={side:sorted([r for r in options if r['signal']['action']==side],key=lambda r:(-float(r['preview']['net_reward_risk']),r['signal']['leverage'])) for side in ('LONG','SHORT')}
 ordered=[]
 for n in range(max(len(v) for v in groups.values())):
  for group in groups.values():
   if n<len(group):ordered.append(group[n])
 options=ordered[:12]
 charts={f:dict(v,recent=v['recent'][-4:]) for f,v in p['frames'].items()}
 return options,dict(mode='SELECTED',symbol=symbol,price=price,charts=charts,choices=[dict(choice=n,**o['preview']) for n,o in enumerate(options)])

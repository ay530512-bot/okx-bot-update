"""Two serialized position slots sharing account checks, margin and AI budget.

Both durable records always remain in bot_state.json. Context swaps change only
which record the existing per-position state machine addresses, never ownership.
"""
import json
import time
from contextlib import contextmanager
from datetime import datetime

from okx_core import BotError, dec, fmt, owned_position, KST, day_key
from okx_engine import Engine
from okx_scale import legs_for


class PortfolioEngine(Engine):
    SLOT_FIELDS = ('future', 'future_epoch', 'next_ai', 'last_close', 'last_snapshot',
                   'chart_future', 'chart_identity', 'next_chart')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.journal.data.setdefault('extra_owned', None)
        self.journal.data.setdefault('additional_owned', [])
        self.previous_strategy = self.journal.data.get('strategy_version', 2)
        for record in self.records():
            if record['phase'] == 'active' and record.get('close_requested') == '운용시간 종료: 수익 여부와 관계없이 청산':
                record.pop('close_requested')
        self.journal.save()
        self.slot = 0
        self.slot_runtime = [{k: getattr(self, k) for k in self.SLOT_FIELDS},
                             {k: getattr(self, k) for k in self.SLOT_FIELDS}]
        self.empty_runtime={k:getattr(self,k) for k in self.SLOT_FIELDS}
        self.ensure_slots()
        self.raw_snapshot = None
        self.slot_positions = [None, None]
        self.slot_errors = [None, None]
        self.log('다중 포지션: 고정 2종목 제한 해제 / 전체 증거금·노출·손절 위험 한도 공유')

    def records(self):
        return [r for r in [self.journal.data['owned'],self.journal.data.get('extra_owned'),*self.journal.data.get('additional_owned',[])] if r]

    def ensure_slots(self):
        size=2+len(self.journal.data.get('additional_owned',[]))
        while len(self.slot_runtime)<size:self.slot_runtime.append(dict(self.empty_runtime))
        if hasattr(self,'slot_positions'):
            while len(self.slot_positions)<size:self.slot_positions.append(None)
        if hasattr(self,'slot_errors'):
            while len(self.slot_errors)<size:self.slot_errors.append(None)
        return size

    def slot_count(self):return self.ensure_slots()

    def can_open_position(self):
        from okx_search_capacity import occupied,limit
        return occupied(self)<limit(self)

    def empty_slot(self):
        if not self.can_open_position():raise BotError('설정된 동시 포지션 수 한도')
        rows=[self.journal.data['owned'],self.journal.data.get('extra_owned'),*self.journal.data.get('additional_owned',[])]
        for idx,row in enumerate(rows):
            if not row:return idx
        self.journal.data.setdefault('additional_owned',[]).append(None)
        self.journal.save();self.ensure_slots()
        return len(rows)

    def swap_slot(self,slot):
        if slot==1:
            self.journal.data['owned'],self.journal.data['extra_owned']=self.journal.data['extra_owned'],self.journal.data['owned']
        elif slot>=2:
            extra=self.journal.data['additional_owned']
            self.journal.data['owned'],extra[slot-2]=extra[slot-2],self.journal.data['owned']

    @contextmanager
    def selected(self,slot):
        if self.slot!=0:raise BotError('포지션 문맥 중첩 거부')
        self.ensure_slots()
        if slot<0 or slot>=self.slot_count():raise BotError('포지션 슬롯 범위 오류')
        self.slot_runtime[0]={k:getattr(self,k) for k in self.SLOT_FIELDS}
        swapped=False
        try:
            if slot:
                self.swap_slot(slot);swapped=True
                self.journal.save()
                for key,value in self.slot_runtime[slot].items():setattr(self,key,value)
            self.slot=slot
            yield
        finally:
            # Restore in-memory ownership BEFORE any fallible persistence. A Windows
            # file error must never strand slot=1 and block every later management tick.
            self.slot_runtime[slot]={k:getattr(self,k) for k in self.SLOT_FIELDS}
            if swapped:
                self.swap_slot(slot)
                for key,value in self.slot_runtime[0].items():setattr(self,key,value)
            self.slot=0
            if swapped:self.journal.save()

    def manual_coexist(self):
        return getattr(self,'cfg',{}).get('execution',{}).get('manual_coexist',False)

    def allocation_seed(self,snapshot):
        from okx_manual import allocation_seed
        seed=allocation_seed(snapshot,self.records()) if self.manual_coexist() else dec(snapshot['equity'])
        # One reserve for the account, never one reserve per position.
        reserve=dec(getattr(self,'cfg',{}).get('risk',{}).get('entry_cash_reserve_usdt',0))
        return max(dec(0),seed-max(dec(0),reserve))

    def blocked_manual_symbols(self):
        if not self.manual_coexist():return set()
        raw=getattr(self,'raw_snapshot',None) or {}
        return {r['instId'] for r in raw.get('manual_positions',[])+raw.get('manual_orders',[])} | {
            r['instId'] for r in getattr(self,'manual_algo_rows',[])}

    def snapshot(self):
        snapshot=super().snapshot();records=self.records();coexist=self.manual_coexist()
        if len({r['symbol'] for r in records})!=len(records):raise BotError('복수 슬롯에 같은 종목 기록이 있습니다. 자동 진입 차단.')
        from okx_manual import order_keys
        keys=order_keys(records)
        manual_orders=[r for r in snapshot['orders'] if (r.get('instId'),r.get('clOrdId')) not in keys]
        if manual_orders and not coexist:raise BotError('프로그램 기록 외 일반 주문 발견. 신규 진입 차단.')
        manual_positions=[]
        for p in snapshot['positions']:
            if dec(p.get('pos') or 0)==0:continue
            record=next((r for r in records if (r['symbol'],r['direction'])==(p['instId'],p['posSide'])),None)
            if not record:
                if not coexist:raise BotError('프로그램 기록 외 포지션 발견. 자동으로 청산하거나 인수하지 않습니다.')
                manual_positions.append(p);continue
            # A manual change to the bot's own merged position remains a real ownership conflict.
            owned_position(record,[p])
        snapshot=dict(snapshot,manual_positions=manual_positions,manual_orders=manual_orders)
        self.raw_snapshot=snapshot
        selected=self.journal.data['owned'];view=dict(snapshot)
        if coexist:
            view['positions']=[p for p in snapshot['positions'] if selected and (p['instId'],p['posSide'])==(selected['symbol'],selected['direction'])]
            view['orders']=[o for o in snapshot['orders'] if selected and o.get('instId')==selected['symbol'] and (o.get('instId'),o.get('clOrdId')) in keys]
            excluded=tuple(sorted(self.blocked_manual_symbols()))
            if excluded!=getattr(self,'last_manual_symbols',()):
                self.last_manual_symbols=excluded
                self.log('수동 거래 분리: '+(', '.join(excluded) if excluded else '없음')+' / 자동 자금 기준 '+fmt(self.allocation_seed(snapshot))+' USDT / 다른 종목 탐색 계속')
        else:
            other_symbols={r['symbol'] for r in records if r is not selected}
            view['positions']=[p for p in snapshot['positions'] if p['instId'] not in other_symbols]
            view['orders']=[o for o in snapshot['orders'] if o['instId'] not in other_symbols]
        self.last_snapshot=view
        return view

    def algos(self, full=False):
        full=full or (self.manual_coexist() and time.monotonic()-getattr(self,'manual_full_scan_at',-1e9)>=10)
        rows = self.api.pending_algos(full)
        if full:self.manual_full_scan_at=time.monotonic()
        selected = self.journal.data['owned']
        mine, other = [], []
        for row in rows:
            record = None
            for r in self.records():
                ids = {leg['algo_client_id'] for leg in legs_for(r) + r.get('cleanup_legs', [])}
                if r.get('pending_add'):
                    ids.add(r['pending_add']['algo_client_id'])
                if (row.get('instId') == r['symbol'] and row.get('posSide') == r['direction']
                        and row.get('algoClOrdId') in ids):
                    record = r
                    break
            if record is selected and record is not None:
                mine.append(row)
            elif record is None:
                other.append(row)
        if self.manual_coexist():
            # Partial scans cover conditional only; retain the last fully checked other types.
            saved=[] if full else [r for r in getattr(self,'manual_algo_rows',[]) if r.get('ordType','conditional')!='conditional']
            self.manual_algo_rows=list({(r.get('instId'),r.get('algoId'),r.get('algoClOrdId'),r.get('ordType')):r for r in saved+other}.values())
            other=[]
        return mine, other

    def margin_room(self, snapshot):
        used = dec(0)
        positions = self.raw_snapshot['positions'] if self.raw_snapshot else snapshot['positions']
        for record in self.records():
            if 'committed_margin' not in record:
                # Uncertain allocation must not stop the existing position's exit analysis.
                if not getattr(self, '_legacy_margin_warning', False):
                    self.log('이전 증거금 기록 누락: 신규/추가 진입만 보류하고 기존 보유 분석·보호를 계속합니다.')
                    self._legacy_margin_warning = True
                return dec(0)
            committed = dec(record['committed_margin'])
            actual = next((dec(p.get('imr') or 0) for p in positions
                           if p['instId'] == record['symbol'] and p['posSide'] == record['direction']), dec(0))
            used += max(committed, actual)
            if record.get('pending_add'):
                used += dec(record['pending_add']['margin'])
        return max(dec(0), self.allocation_seed(snapshot) * 2 / 3 - used)

    def analysis_context(self):
        selected = self.journal.data['owned']
        return {'_EXCLUDED_SYMBOLS': [r['symbol'] for r in self.records() if r is not selected],
                '_PORTFOLIO': [{'symbol': p['instId'], 'direction': p['posSide'], 'roe': p.get('uplRatio')}
                               for p in (self.raw_snapshot or {}).get('positions', []) if dec(p.get('pos') or 0) != 0]}

    def submit_ai(self, snapshot, position):
        if self.slot == 1 and not self.records():
            return  # Empty account needs one scanner, including preview mode.
        if not position and not self.preview and self.margin_room(snapshot) <= 0:
            return
        return super().submit_ai(snapshot, position)

    def reserve_api(self, amount, epoch):
        # Background callbacks run with canonical slot 0 selected. A sole slot 1
        # holding must still receive analysis after new entries have stopped.
        with self.lock:
            if epoch != self.epoch or not (self.enabled or self.preview or self.records()):
                raise BotError('상태가 변경되어 AI 요청을 취소했습니다.')
            today = day_key(self.api.now_ms())
            data = self.journal.data
            if data['api_day'] != today:
                data['api_day'], data['api_spent'], data['api_calls'] = today, 0., 0
            hard=min(self.budget,self.cfg['execution'].get('budget_pacing',{}).get('hard_daily_usd',self.budget)) if hasattr(self,'cfg') else self.budget
            if data['api_spent'] + amount > hard:
                raise BotError('AI 일일 예산 부족')
            data['api_spent'] += amount
            data['api_total_spent'] += amount
            data['api_calls'] += 1
            self.journal.save()
            return today

    def entry(self, result, instruments, analysis_cost=0):
        if any(r['symbol'] == result['symbol'] for r in self.records()):
            self.log('보유 종목 중복 진입 생략: ' + result['symbol'])
            return
        snapshot = self.snapshot()
        if result['symbol'] in self.blocked_manual_symbols():
            raise BotError('수동 포지션/주문 종목 제외: '+result['symbol'])
        if self.margin_room(snapshot) <= 0:
            self.log('모든 포지션/추가 진입의 공용 증거금 한도 도달. 새로운 종목은 대기합니다.')
            return
        return super().entry(result, instruments, analysis_cost)

    def activate(self, *args, **kwargs):
        if any(r['phase'] != 'active' for r in self.records()):
            raise BotError('진행 중 주문 결과부터 확인해야 합니다.')
        if self.previous_strategy < 3:
            snapshot = self.snapshot()
            day = self.journal.data['day']
            roi = self.strategy_roi(snapshot['equity'])
            if day and day['ended'] and roi is not None and roi < dec(2):
                day['ended'] = False
                self.journal.save()
                self.log('이전 버전의 +6% 일일 종료 해제. v3는 조건 충족 시 계속 탐색합니다.')
        super().activate(*args, **kwargs)
        self.journal.data['strategy_version'] = 3
        self.journal.save()
        self.previous_strategy = 3
        for slot in range(self.slot_count()):
            self.slot_runtime[slot]['next_ai'] = 0

    def handle(self, action, kwargs):
        if action == 'preview' and self.records():
            raise BotError('보유 포지션이 있어 미리보기 전환 불가. 보유 관리가 계속됩니다.')
        if action == 'quit' and self.records():
            raise BotError('보유 포지션 기록이 있습니다. 관리 창을 유지하세요.')
        if action == 'close':
            self.pause('사용자가 전체 포지션 청산 후 중지 요청')
            errors = []
            for slot in range(self.slot_count()):
                with self.selected(slot):
                    try:
                        self.close(self.snapshot(), '사용자 전체 보유분 청산 요청')
                    except Exception as error:
                        errors.append(error)
            if errors:
                raise errors[0]
            return
        return super().handle(action, kwargs)

    def tick(self):
        errors = []
        for slot in range(self.slot_count()):
            # One slot's uncertain order must not starve the other position's protection.
            with self.selected(slot):
                try:
                    super().tick()
                    self.slot_errors[slot] = None
                except Exception as error:
                    self.slot_errors[slot] = type(error).__name__
                    self.pause(f'{slot + 1}번 포지션 확인 필요')
                    errors.append(error)
        self.publish_portfolio()
        if errors:
            raise errors[0]

    def publish(self, snapshot, position):
        self.slot_positions[self.slot] = position

    def publish_portfolio(self):
        if not self.raw_snapshot:
            return
        snapshot = self.raw_snapshot
        day = self.journal.data['day']
        roi = self.strategy_roi(snapshot['equity'])
        mode = '미리보기(주문 없음)' if self.preview else '실거래 가동' if self.enabled else '신규 진입 정지·보유 관리'
        session = self.journal.data.get('session')
        if session:
            mode += ' / 신규 진입 시간 종료' if session['ended'] else ' / 신규 종료 ' + datetime.fromtimestamp(session['end_ms'] / 1000, KST).strftime('%m-%d %H:%M')
        if day and day['ended']:
            mode += ' / 오늘 일일 수익 상한'
        if self.manual_coexist():mode+=' / 수동 '+str(len(self.blocked_manual_symbols()))+'종목 분리'
        summaries = []
        for record in self.records():
            p = next((p for p in snapshot['positions'] if p['instId'] == record['symbol'] and p['posSide'] == record['direction'] and dec(p.get('pos') or 0) != 0), None)
            summaries.append(record['symbol'] + ' ' + record['direction'] + ' / ' + record['phase']
                             + (f' / ROE {float(dec(p["uplRatio"])) * 100:.2f}%' if p else '')
                             + (' / 손절 확인' if record.get('protection_verified') else ' / 보호 확인 중'))
        self.events.put(('status', {'mode': mode, 'equity': fmt(snapshot['equity']),
            'available': fmt(snapshot['available']), 'auto_seed':fmt(self.allocation_seed(snapshot)),
            'manual_symbols':sorted(self.blocked_manual_symbols()), 'roi': None if roi is None else float(roi),
            'base': day['base'] if day else None, 'position': '\n'.join(summaries) or None,
            'owned': bool(self.records()), 'api_spent': self.journal.data['api_spent'],
            'api_calls': self.journal.data['api_calls'], 'updated': datetime.now(KST).strftime('%H:%M:%S'),
            'live': self.enabled, 'preview': self.preview, 'error': self.last_error}))

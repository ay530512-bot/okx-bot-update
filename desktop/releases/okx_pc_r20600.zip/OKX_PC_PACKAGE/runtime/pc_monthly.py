"""KST trading windows and closed-candle signals for PC 2.0.11."""
from datetime import datetime
import math
import statistics
from collections import namedtuple

import pc_scalp as scalp
import pc_timing as timing
from okx_core import BotError, KST
from okx_pattern15 import allowed

STEP, HOUR, DAY = 900000, 3600000, 86400000
Rule = namedtuple('Rule', 'label start end side stop target trail minutes')
RULES = {
    'afternoon_vwap': Rule('거래량 가중평균 회귀 숏',15,18,-1,2,0,1,480),
    'evening_pullback': Rule('추세 눌림목 롱·숏',18,21,0,3,3,0,1440),
    'late_reversal': Rule('저녁 확정반전 롱·숏',21,24,0,2.8,0,1,720),
    'pullback': Rule('눌림목 숏',0,6,-1,3,3,0,1440),
    'failed_wick': Rule('두꼬리 실패 숏',0,3,-1,3,3,0,1440),
    'rank_short': Rule('전일 상승 상위 3개 숏',0,12,-1,3,3,0,1440),
    'trend_long': Rule('당일 상승 1위 추세 롱',5,8,1,2.5,3,0,360),
    'reversal': Rule('확정반전 숏',9,12,-1,2,0,1,480),
    'two_wick': Rule('두꼬리 숏',9,15,-1,2,2,0,240),
}
PREVIOUS_RULES = RULES.copy()
WINDOWS = {'reversal':(1,4),'two_wick':(1,7),'afternoon_vwap':(7,10),
           'evening_pullback':(10,13),'late_reversal':(13,16),'failed_wick':(16,19),
           'rank_short':(16,4),'trend_long':(21,24)}
RULES = {r: PREVIOUS_RULES[r]._replace(start=a,end=b,trail=1) for r,(a,b) in WINDOWS.items()}

PIVOTS = {'pivot_long': 1, 'pivot_short': -1}
for key, direction in PIVOTS.items():
    label = '15분 저점상승 음봉꼬리 롱' if direction == 1 else '15분 고점하락 양봉꼬리 숏'
    WINDOWS[key] = (8, 12)
    RULES[key] = Rule(label, 8, 12, direction, 2, 0, 1, 60)

for key,(label,start,end,frame,floor,target,hold,cap) in scalp.SPECS.items():
    RULES[key]=Rule(label,start,end,1,1.5,target,1,hold)

def unavailable(e,s):
    route=s['monthly208']
    day=s['valid_from_ms']//DAY
    if route in scalp.SPECS:
        state=e.journal.data.get('scalp_filled',{}).get(route,{})
        if state.get('day')==scalp.day(s['valid_from_ms']) and len(state['ids'])>=scalp.SPECS[route][-1]:
            return True
    elif e.journal.data.get('monthly_filled_day',{}).get(route)==day:
        return True
    return any((o.get('v4_signal') or {}).get('monthly208')==route
               for o in e.records())

RESERVED = {'rank_short','trend_long'}

def active(route, now):
    hour=(now//HOUR+9)%24
    policy=timing.policies()[route]
    return (hour-policy['start'])%24 < (policy['end']-policy['start'])%24

def closing(values, end, step, count):
    bars=[r for r in values if int(r[0])+step<=end][-300:]
    if len(bars)<count or bars[-1][0]!=(end//step-1)*step:
        return []
    if any(y[0]-x[0]!=step for x,y in zip(bars[-count:],bars[-count+1:])):
        return []
    return bars

def ema(values,n):
    result=values[0]
    alpha=2/(n+1)
    for x in values[1:]:result+=alpha*(x-result)
    return result

def strength(values):
    moves=[b-a for a,b in zip(values,values[1:])]
    up,down=max(0,moves[0]),max(0,-moves[0])
    for d in moves[1:]:
        up+=(max(d,0)-up)/14
        down+=(max(-d,0)-down)/14
    return 100*up/(up+down) if up+down else 50.

def proof(b,h,i,market,routes):
    _,op,hi,lo,c,vol=b[-1]
    p=b[-2]; closes=[r[4] for r in b]; avgvol=sum(r[5] for r in b[-21:-1])/20
    if avgvol<=0 or hi<=lo:return {}
    rv=vol/avgvol
    a=sum(max(r[2]-r[3],abs(r[2]-prev[4]),abs(r[3]-prev[4])) for prev,r in zip(b[-16:-2],b[-15:-1]))/14
    turnover=sum(r[4]*r[5] for r in b[-16:])*float(i['ctVal'])
    if not (.0025<=a/c<=.027 and float(i['tickSz'])/c<=.0005 and rv>=1 and turnover>=150000):return {}
    rsi=strength(closes); prsi=strength(closes[:-1]); change=c/closes[-9]-1
    e=ema(closes,20); slope=e-ema(closes[:-4],20)
    red=c<op and p[4]-c>.1*a
    tail=hi-max(c,op)
    two=(timing.prior_upper_wick(b,a) is not None and tail>.33*(hi-lo) and tail>.3*a
         and rsi<prsi and rsi>44 and op-c>.05*a)
    recent=max(r[2] for r in b[-5:-1])
    pivot=max(r[2] for r in b[-13:-1])
    flags={
        'reversal': hi>pivot and pivot-c>.15*a and rsi<prsi and rsi>44 and tail>=.38*(hi-lo) and hi-lo>=1.25*a and rv>=1.7 and turnover>=900000 and a/c>=.006,
        'two_wick': two and p[4]/b[-10][4]-1>.015 and rv>=1.05,
        'rank_short':two and rv>=1.5,
        'failed_wick':min(p[1],p[4])-p[3]>.45*(p[2]-p[3]) and p[3]<min(r[3] for r in b[-14:-2]) and c<p[3] and c<e and 24<rsi<49 and market-change>=.003 and market<=0,
        'trend_long':c>op and c-p[4]>.1*a and c>e and slope>0,
    }
    if 'pullback' in routes and h:
        hs=[r[4] for r in h]
        flags['pullback']=(red and c<p[3] and slope<0 and ema(hs,20)<=ema(hs,50) and 28<=rsi<=50
            and e-recent<.25*a and ema(closes,50)-recent>-.7*a and e-c<2.8*a and rv>=1.7 and turnover>=900000 and a/c>=.006)
    result={r:(rv,c,a,RULES[r].side) for r in routes if flags.get(r)}
    if h and routes.intersection({'afternoon_vwap','evening_pullback'}):
        hourly_closes=[r[4] for r in h]
        up=ema(hourly_closes,20)>ema(hourly_closes,50)
        if 'afternoon_vwap' in routes and not up and rv>=2.5 and red and 44<rsi<prsi:
            current=b[-32:]
            previous=b[-33:-1]
            def weighted(rows):
                volume=sum(r[5] for r in rows)
                return sum(r[4]*r[5] for r in rows)/volume if volume else math.nan
            if p[4]-weighted(previous)>1.25*a and c>weighted(current):
                result['afternoon_vwap']=(rv,c,a,-1)
        if 'evening_pullback' in routes and rv>=2.75:
            direction=1 if up else -1
            extreme=min(r[3] for r in b[-5:-1]) if up else recent
            broken=p[2] if up else p[3]
            if (direction*(c-op)>0 and direction*(c-p[4])>.1*a and direction*(c-broken)>0
                    and direction*slope>0 and 0<=direction*(rsi-50)<=22
                    and direction*(extreme-e)<.25*a and direction*(extreme-ema(closes,50))>-.7*a
                    and direction*(c-e)<2.8*a and direction*change>.005 and direction*market>-.003):
                result['evening_pullback']=(rv,c,a,direction)
    if ('late_reversal' in routes and (b[-1][0]+STEP)%HOUR==0 and
            rv>=2.5 and turnover>=400000 and hi-lo>=1.25*a):
        floor=min(r[3] for r in b[-13:-1])
        if lo<floor and c-floor>.15*a and min(op,c)-lo>=.38*(hi-lo) and prsi<rsi<56:
            result['late_reversal']=(rv,c,a,1)
        elif hi>pivot and pivot-c>.15*a and tail>=.38*(hi-lo) and prsi>rsi>44:
            result['late_reversal']=(rv,c,a,-1)
    for key, direction in PIVOTS.items():
        if key in routes and timing.pivot_pair(b,direction,a):
            result[key]=(rv,c,a,direction)
    return result

def scan_summary(e):
    sample = getattr(e, 'monthly_scan_status', None)
    if sample is None:
        return '이번 실행 첫 검사 전'
    when, end, result = sample
    at = datetime.fromtimestamp(when/1000, KST).strftime('%m-%d %H:%M:%S')
    bar = datetime.fromtimestamp(end/1000, KST).strftime('%H:%M')
    return f'최근 검사 {at} KST · {bar} 마감봉 · {result}'


def collect(e,end):
    from pc_wick_failure import candle_rows
    u=e.universe
    with u.lock:
        market=getattr(u,'full_market',None)
        instruments=dict(getattr(market,'instruments',{}))
        cache=dict(getattr(market,'band_cache',{}))
    active_routes={r for r in WINDOWS if active(r,end)}
    need_ranks=bool(active_routes & RESERVED)
    eligible=[(s,instruments[s]) for s in scalp.SYMBOLS if s in instruments and allowed(instruments[s],e.cfg)]
    entries=[]; ranking={}; previous={}; day=end//DAY*DAY
    for sym,i in eligible:
        if e.api.now_ms()>=end+90000 or (getattr(e,'pc_forward',None) and e.pc_forward.stopping.is_set()):return []
        entry=cache.get((sym,'15m')); bars=closing(entry[1],end,STEP,65) if entry else []
        needed=day-DAY if 'rank_short' in active_routes else day
        if not bars or (need_ranks and bars[0][0]>needed):
            try: bars=closing(candle_rows(e,sym,'15m','300',e.api.now_ms()),end,STEP,65)
            except (BotError,OSError,TypeError,ValueError,KeyError): bars=[]
        entries.append((sym,i,(0,bars),cache.get((sym,'1H'))))
        if bars and need_ranks:
            lookup={r[0]:r for r in bars}
            if day in lookup:ranking[sym]=bars[-1][4]/lookup[day][1]-1
            if day-DAY in lookup and day-STEP in lookup:
                previous[sym]=lookup[day-STEP][4]/lookup[day-DAY][1]-1
    def positive_leaders(values, n):
        if len(values)!=len(eligible) or len(eligible)<2:return []
        return sorted((sym for sym,v in values.items() if v>0),key=lambda sym:(-values[sym],sym))[:n]
    leaders=positive_leaders(ranking,1); leader=leaders[0] if leaders else None
    top=set(positive_leaders(previous,3)); e.pc250_ranks=(end,leader,top)
    inputs=[]; changes=[]
    waiting = checked = 0
    for s,i,b,h in entries:
        bars = closing(b[1],end,STEP,65) if b else []
        if bars:
            changes.append(bars[-1][4]/bars[-9][4]-1)
        if s.startswith('BTC-') or not allowed(i,e.cfg):continue
        routes=active_routes.copy()
        if s!=leader:routes.discard('trend_long')
        if s not in top:routes.discard('rank_short')
        if not routes:continue
        if not bars:
            waiting += 1
            continue
        inputs.append((s,i,bars,h,routes))
    market=statistics.median(changes) if changes else 0
    winners={}
    for s,i,b,h,routes in inputs:
        hourly=closing(h[1],end,HOUR,50) if h and routes.intersection({'pullback','afternoon_vwap','evening_pullback'}) else []
        hourly_routes = {'pullback','afternoon_vwap','evening_pullback'}
        if not hourly and routes & hourly_routes and e.api.now_ms()<end+80000:
            try:hourly=closing(candle_rows(e,s,'1H','100',e.api.now_ms()),end,HOUR,50)
            except (BotError,OSError,TypeError,ValueError,KeyError):pass
        if hourly or routes - hourly_routes:
            checked += 1
        if not hourly and routes & hourly_routes:
            waiting += 1
        for key,(volume,c,a,direction) in proof(b,hourly,i,market,routes).items():
            score=(-volume,s)
            if key in winners and winners[key][0]<=score:continue
            rule=RULES[key]; side='LONG' if direction==1 else 'SHORT'
            policy=timing.policies()[key]; tick=float(i['tickSz'])
            ev=timing.evidence(key,b,direction,tick,a)
            if not timing.passes(policy['filter'],ev):continue
            from pc_sizing import leverage_for
            maximum = float(i.get('lever') or 0)
            lev = leverage_for(ev,c,maximum)
            if not lev:continue
            stop=ev['stop']
            ident=f'm208-{end//DAY}-{key}-{end}-{s}'
            v=dict(action=side,reference=c,atr=a,confirmation_ms=end-STEP,structural_stop=stop,relative_volume=volume,route721='m208_'+key,timing=ev)
            winners[key]=(score,dict(symbol=s,action=side,leverage=lev,strategy='band_flow',pattern='m208_'+key,monthly208=key,
                rule_channel701=True,free_ai=True,pattern15=True,stop=stop,target=None,pc211=True,pc250=True,pc260=True,indicator_limit=maximum,tick250=tick,margin_fraction=1/3,
                signal_id=ident,atr=a,level=stop,reason=rule.label,regime=rule.label,ma={},bb={},rsi={},retest=False,adaptive=False,
                setup_frame='15m',execution_frame='15m',at_ms=end,valid_from_ms=end,expires_ms=end+90000,
                entry_reference=c,entry_gap=c,selection=dict(activity={},asset_category='1'),
                holding_rule=dict(band_flow=True,free_ai=True,pattern15=True,rule_channel701=True,monthly208=key,
                    frame='15m',partial=False,max_hold_seconds=policy['minutes']*60,timing_filter=policy['filter'],kst_window=[policy['start'],policy['end']]),
                decision_record=dict(source='m208_'+key,frames={},volume_wick_proof=v)))
    rank_wait = ('rank_short' in active_routes and not top) or ('trend_long' in active_routes and not leader)
    if checked:
        result = f'조건 검사 {checked}종목 · 신호 후보 {len(winners)}건'
    else:
        result = '검사 0종목'
    if waiting:
        result += f' · 봉 자료 대기 {waiting}종목'
    if rank_wait:
        result += ' · 순위 후보 미확정'
    if checked and not waiting and not rank_wait:
        result = '검사 완료 · ' + result
    elif not checked and not waiting and not rank_wait:
        result += ' · 대상 없음'
    e.monthly_scan_status = (e.api.now_ms(), end, result)
    return [val[1] for val in sorted(winners.values(),key=lambda val:(val[1]['monthly208'] not in RESERVED,val[0]))]

def signal_side(s):
    key=s['monthly208']
    rule=RULES[key] if key in scalp.SPECS or key in PIVOTS else PREVIOUS_RULES[key]
    if rule.side:return rule.side
    if s['action']=='LONG':return 1
    if s['action']=='SHORT':return -1
    raise BotError('저녁 확정반전 방향 오류')

def check(e,s,price):
    from phone_trend_slot import require_slot
    r=s['monthly208']; now=e.api.now_ms()
    if r not in RULES or not active(r,now) or not s['valid_from_ms']<=now<=s['expires_ms'] or (r not in scalp.SPECS and now//DAY!=s['valid_from_ms']//DAY):
        raise BotError('신규 진입 시간 종료 또는 신호 만료')
    state=getattr(e,'monthly_pending',{})
    if unavailable(e,s) or state.get(r)!=s['signal_id'] or s['symbol']+':'+s['signal_id'] in e.journal.data.get('seen_signals',{}):
        raise BotError('당일 첫 신호 소진')
    px=float(price)
    if not math.isfinite(px) or abs(px-s['entry_reference'])>.5*s['atr'] or signal_side(s)*(px-s['stop'])<=0:raise BotError('진입가 또는 손절 범위 이탈')
    if not s.get('pc250') or not getattr(e,'pc_forward',None) or not e.pc_forward.allows(s,now):
        raise BotError('규칙별 모의체결 검증 대기')
    if r in RESERVED:
        stamp,leader,top=getattr(e,'pc250_ranks',(0,None,set()))
        if stamp!=s['valid_from_ms'] or (r=='trend_long' and s['symbol']!=leader) or (r=='rank_short' and s['symbol'] not in top):
            raise BotError('31종목 완료봉 순위 재확인 대기')
    require_slot(e,s)

def candidate(coord,e,d):
    now=e.api.now_ms()
    watcher=getattr(e,'pc_forward',None)
    signals=watcher.live_candidates(now) if watcher else []
    signals=[s for s in signals if not unavailable(e,s) and s['signal_id'] not in getattr(e,'pc_batch_seen',())]
    e.monthly_pending={s['monthly208']:s['signal_id'] for s in signals}
    watches=list({o['symbol'] for o in e.records()}|set(e.chat.watch())|{s['symbol'] for s in signals})
    if hasattr(e,'phone_quote_registry'):e.phone_quote_registry.set_candidates(watches)
    else:e.stream.watch(watches)
    if e.can_open_position():
        for s in signals:
            if s['symbol'] in e.blocked_manual_symbols():continue
            q=coord.market_ready(e,s,d)
            if q:
                try:check(e,s,q['last'])
                except BotError as exc:coord.gate(d,str(exc));continue
                e.pipeline('approved',s['reason'],count='signals')
                return s
    e.pipeline('signal_wait',watcher.status_line(now) if watcher else '시간표 검증 자료 대기')

def manage(e,snap,p,o):
    from okx_profit_guard714 import effective_stop
    s=o['v4_signal'];rule=(RULES if s.get('pc211') else PREVIOUS_RULES)[s['monthly208']];side=signal_side(s)
    if s.get('pc250'):
        rule=rule._replace(target=0,trail=1,minutes=s['holding_rule']['max_hold_seconds']//60)
    mark=float(p['markPx']);entry=float(p['avgPx']);risk=side*(entry-s['stop'])
    if min(mark,entry)<=0:return False
    move=(mark-entry)*side
    stop=effective_stop(o)
    if side*(mark-stop)<=0:
        reason=f'보호 손절선 도달 · 관리 기준 {stop:.10g}'
    elif risk<=0:
        reason='최초 손절가와 진입 방향 불일치'
    elif rule.target and move>=rule.target*risk:
        reason=f'목표가 도달 · {entry+side*rule.target*risk:.10g}'
    elif e.api.now_ms()-o['entry_ms']>=rule.minutes*60000:
        reason=f'최대 보유시간 {rule.minutes}분 만료 · 관리 손절선 {stop:.10g}'
    else:
        reason=None
    if reason:
        e.close(snap,f'{rule.label} · {reason} · 판단 마크가 {mark:.10g}')
        return True
    if rule.trail and move>=risk:
        target=mark-side*risk
        if side*(target-effective_stop(o))>0:
            e.trail(snap,p,o,target);return True
    return False

def validate(e,s,price):
    from okx_band_flow import rows
    check(e,s,price)
    if e.journal.data.get('legacy_entries207'):
        raise BotError('이전 진입 규칙으로 복원됨')
    now=e.api.now_ms()
    if s['monthly208'] in scalp.SPECS:
        from pc_wick_failure import candle_rows
        frame=scalp.SPECS[s['monthly208']][3]
        candles=candle_rows(e,s['symbol'],f'{frame}m','100',now)
        b=closing(candles,s['valid_from_ms'],frame*60000,85)
        live=[r for r in candles if r[0]>=s['valid_from_ms']]
        if (not b or b[-1][4]!=s['entry_reference'] or not scalp.matches(s['monthly208'],b)
                or not live or min(r[3] for r in live)<=s['stop']):
            raise BotError('단타 롱 완료봉 또는 손절 범위 재확인 실패')
        verify_timing(s,b)
        check(e,s,price)
        return s['decision_record']['volume_wick_proof']
    bars=rows(e.api.public('/api/v5/market/candles',instId=s['symbol'],bar='15m',limit='100'),'15m',now)
    last=next((r for r in bars if r[0]==s['valid_from_ms']-STEP),None)
    if not last or last[4]!=s['entry_reference']:raise BotError('신호 확정봉 변경')
    completed=closing(bars,s['valid_from_ms'],STEP,65)
    verify_timing(s,completed)
    side=signal_side(s)
    if any((r[3]<=s['stop'] if side==1 else r[2]>=s['stop']) for r in bars if r[0]>=s['valid_from_ms']):
        raise BotError('대기 중 초기 손절 도달')
    check(e,s,price)
    return s['decision_record']['volume_wick_proof']


def verify_timing(s,bars):
    key=s['monthly208']; policy=timing.policies()[key]
    if len(bars)<32:raise BotError('완료봉 검증 자료 대기')
    latest=len(bars)-1 if key in scalp.SPECS else len(bars)-2
    atr=scalp.atr(bars,latest); ev=timing.evidence(key,bars,signal_side(s),s['tick250'],atr)
    from pc_sizing import leverage_for
    if (not timing.passes(policy['filter'],ev) or ev['stop']!=s['stop'] or not s.get('pc260')
            or leverage_for(ev,s['entry_reference'],s['indicator_limit'])!=s['leverage']):
        raise BotError('확정봉 보조지표 또는 구조 손절가 변경')

"""Entry evidence shared by the live scanner and the historical replay."""
import json
import math
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from functools import lru_cache
from pathlib import Path
from statistics import median

FILTERS = ('reclaim', 'volume', 'trend', 'momentum', 'room')
LABEL = {
    'reclaim': '봉 안에서 진입 방향으로 55% 이상 회복 마감',
    'volume': '회복 마감 · 직전 20봉 평균 대비 거래량 1.6배 이상',
    'trend': '회복 마감 · EMA20과 그 기울기가 진입 방향과 일치',
    'momentum': '회복 마감 · 최근 4봉 이동 0.35 ATR 이상 · EMA20 추격 제한',
    'room': '회복 마감 · ATR이 종가의 0.45% 이상 · 상대 거래량 1.2배 이상',
}


@lru_cache(maxsize=1)
def policies():
    return json.loads(Path(__file__).with_name('pc_timing_rules.json').read_text(encoding='utf-8'))['rules']


def round_stop(value, tick, side):
    unit = Decimal(str(tick))
    rounds = ROUND_FLOOR if side == 1 else ROUND_CEILING
    return float((Decimal(str(value)) / unit).to_integral_value(rounding=rounds) * unit)


def evidence(route, bars, side, tick, atr):
    """All input bars must already be closed at the decision timestamp."""
    from pc_monthly import ema
    if len(bars) < 32 or side not in (-1, 1) or not (tick > 0 and atr > 0):
        return None
    _, op, high, low, close, vol = bars[-1]
    if high <= low or close <= 0 or tick / close > .0005 or high-low > 4*atr:
        return None
    if route in ('pivot_long','pivot_short'):
        pair = pivot_pair(bars, side, atr)
        if not pair:
            return None
        anchor = bars[pair[1]][3 if side == 1 else 2]
    elif route == 'scalp_higher':
        from pc_scalp import higher_pair
        pair = higher_pair(bars, len(bars)-1)
        if not pair:
            return None
        anchor = bars[pair[1]][3]
    else:
        # A retest is invalidated beyond its wick, a breakout beyond its base.
        lookback = {'two_wick': 8, 'rank_short': 8, 'evening_pullback': 5,
                    'trend_long': 5, 'afternoon_vwap': 3, 'failed_wick': 2,
                    'scalp_break': 2}.get(route, 1)
        segment = bars[-lookback:]
        anchor = min(r[3] for r in segment) if side == 1 else max(r[2] for r in segment)
    tails = [min(r[1], r[4])-r[3] if side == 1 else r[2]-max(r[1], r[4]) for r in bars[-13:-1]]
    pad = max(2*tick, .40*atr, median(tails))
    stop = round_stop(anchor-side*pad, tick, side)
    distance = side*(close-stop)
    if stop <= 0 or not (.60*atr <= distance <= 4.5*atr and distance/close <= .06):
        return None
    closes = [r[4] for r in bars[-32:]]
    average = ema(closes, 20)
    slope = side*(average-ema(closes[:-4], 20))/atr
    stretch = side*(close-average)/atr
    location = ((close-low) if side == 1 else (high-close))/(high-low)
    avg_vol = sum(r[5] for r in bars[-21:-1])/20
    if avg_vol <= 0:
        return None
    rv = vol/avg_vol
    momentum = side*(close-closes[-5])/atr
    if not all(map(math.isfinite,(anchor,stop,rv,slope,stretch,location,momentum))):
        return None
    return dict(anchor=anchor, pad=pad, stop=stop, atr=atr, rv=rv, location=location,
                slope=slope, stretch=stretch, momentum=momentum, atr_pct=atr/close)


def passes(filt, ev):
    if ev is None or ev['location'] < .55:
        return False
    if filt == 'reclaim':
        return True
    if filt == 'volume':
        return ev['rv'] >= 1.6
    if filt == 'trend':
        return ev['slope'] > 0 and 0 < ev['stretch'] <= 2.5
    if filt == 'momentum':
        return ev['momentum'] >= .35 and ev['stretch'] <= 2
    if filt == 'room':
        return ev['atr_pct'] >= .0045 and ev['rv'] >= 1.2
    return False


def pivot_pair(bars, side, atr):
    """Two failed tests of the same side, separated by a rebound; first confirming close only."""
    if len(bars) < 34 or atr <= 0:
        return None
    last = len(bars)-1
    def extreme(r): return r[3] if side == 1 else -r[2]
    def opposite(r): return r[2] if side == 1 else -r[3]
    def wick(r): return min(side*r[1],side*r[4])-extreme(r)
    confirm = bars[last]
    if side*(confirm[4]-confirm[1]) <= 0:
        return None
    for j in range(last-1,last-4,-1):
        second = bars[j]; level = opposite(second)
        if (side*(second[4]-second[1]) >= 0 or wick(second) < .18*(second[2]-second[3])
                or side*confirm[4] <= level or max((side*r[4] for r in bars[j+1:last]),default=-math.inf)>level
                or min(extreme(r) for r in bars[j+1:])<extreme(second)
                or extreme(second)>min(extreme(r) for r in bars[j-3:j])):
            continue
        i=min(range(j-24,j-3),key=lambda k:extreme(bars[k]));first=bars[i]
        if side*(first[4]-first[1])>=0 or wick(first)<.2*(first[2]-first[3]):continue
        if not 0<extreme(second)-extreme(first)<=1.5*atr:continue
        between=max(opposite(r) for r in bars[i+1:j])
        if between-extreme(second)<atr:continue
        # The preceding opposite wick must have been followed by a drop/rally into the first pivot.
        if not any((opposite(r)-max(side*r[1],side*r[4])>=.25*(r[2]-r[3]) and
                    opposite(r)-extreme(first)>=atr) for r in bars[max(0,i-6):i]):continue
        return i,j
    return None

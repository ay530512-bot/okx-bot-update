"""Public-data forward observation. Only the existing execution engine can place orders."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import math
from pathlib import Path
import threading

from okx_core import BotError
from pc_timing import policies, round_stop

MINUTE, DAY = 60000, 86400000
FEE = SLIP = .0005
COUNT = 20


def qualifies(history, now):
    recent=[r for r in history if now-60*DAY <= r['entry_ms'] and r['exit_ms']<=now][-COUNT:]
    if len(recent)<COUNT or len({(r['entry_ms']+9*3600000)//DAY for r in recent})<8:return False
    returns=[r['net_r'] for r in recent]
    return sum(returns[:10])>0 and sum(returns[10:])>0 and sum(returns)>max(returns)


def window_bars(api, path, symbol, first, end, mark=False):
    values={};cursor=end
    for _ in range((end-first)//(100*MINUTE)+3):
        rows=api.public('/api/v5/market/'+path,instId=symbol,bar='1m',after=str(cursor),limit='100')
        if not rows:break
        earliest=cursor
        for r in rows:
            t=int(r[0]);earliest=min(earliest,t)
            if not first<=t<end or str(r[5 if mark else 8])!='1':continue
            o,h,l,c=map(float,r[1:5])
            if not (all(map(math.isfinite,(o,h,l,c))) and 0<l<=min(o,c)<=max(o,c)<=h):raise ValueError('invalid OHLC')
            values[t]=(o,h,l,c)
        if earliest<=first or earliest>=cursor:break
        cursor=earliest
    if any(t not in values for t in range(first,end,MINUTE)):raise ValueError('미확정·누락 1분봉')
    return values


def settle(api, sample):
    side=sample['side'];symbol=sample['symbol'];entry=sample['price'];stop=sample['stop']
    first=sample['entry_ms']//MINUTE*MINUTE
    # The minute containing the deadline may include prices observed after expiry.
    # Settle at the open of that minute, without using its subsequent range.
    deadline=sample['entry_ms']+sample['minutes']*MINUTE
    last=deadline//MINUTE*MINUTE; end=last+MINUTE
    path=window_bars(api,'history-candles',symbol,first,end)
    mark=window_bars(api,'history-mark-price-candles',symbol,first,end,True)
    rate_rows=api.public('/api/v5/public/funding-rate-history',instId=symbol,after=str(end),limit='20')
    # Fetch far enough back to prove the entire holding interval is covered.
    if not rate_rows or min(int(r['fundingTime']) for r in rate_rows)>sample['entry_ms']:raise ValueError('펀딩 이력 대기')
    rates={int(r['fundingTime']):float(r['realizedRate']) for r in rate_rows}
    if any(not math.isfinite(v) for v in rates.values()):raise ValueError('펀딩 수치 오류')
    risk=side*(entry-stop);carry=0.
    for t in range(first,end,MINUTE):
        op,hi,lo,cl=path[t];mo,mh,ml,mc=mark[t]
        if t>sample['entry_ms'] and t in rates:carry-=side*mo*rates[t]
        if t==last:
            px=op;reason='time';break
        if (ml<=stop if side==1 else mh>=stop):
            # Conservative execution bound. The first partial minute cannot contribute a favorable peak.
            px=min(op,stop+min(0.,cl-mc)) if side==1 else max(op,stop+max(0.,cl-mc))
            px=max(lo,min(hi,px));reason='stop';break
        if t==first and t!=sample['entry_ms']:continue
        fav=mh if side==1 else ml
        if side*(fav-entry)>=risk:
            candidate=round_stop(fav-side*risk,sample['tick'],side)
            if side*(candidate-stop)>0:stop=candidate
    fill=px*(1-side*SLIP); unit= risk + entry*2*(FEE+SLIP)
    pnl=side*(fill-entry)+carry-FEE*(entry+fill)
    return dict(entry_ms=sample['entry_ms'],exit_ms=(t if reason=='time' else t+MINUTE),symbol=symbol,
                net_r=pnl/unit,net_pct=100*pnl/entry,reason=reason)


class Watcher:
    def __init__(self, engine, root):
        self.e=engine; self.lock=threading.RLock(); self.signals=[]; self.error=''; self.blocked=False
        # Changes to the tested setup, observation costs or time window start a fresh set of samples.
        root=Path(root); code=Path(__file__).parent
        digest=hashlib.sha256(b''.join((code/name).read_bytes() for name in
            ('pc_timing_rules.json','pc_timing.py','pc_monthly.py','pc_scalp.py','pc_forward.py'))).hexdigest()[:16]
        self.path=root/('pc_forward_'+digest+'.json')
        self.data={'format':1,'rules':{}};self.retry={}; self.work=None; self.monthly_job=None; self.stopping=threading.Event()
        self.pool=ThreadPoolExecutor(max_workers=2,thread_name_prefix='pc-public-review')
        try:
            if self.path.exists():
                doc=json.loads(self.path.read_text(encoding='utf-8'))
                if doc.get('format')!=1 or not isinstance(doc.get('rules'),dict):raise ValueError('format')
                for key,v in doc['rules'].items():
                    if key not in policies() or not isinstance(v['history'],list):raise ValueError('reference')
                    for r in v['history']:
                        if not math.isfinite(r['net_r']) or int(r['exit_ms'])<int(r['entry_ms']):raise ValueError('history')
                    if v.get('pending') and v['pending'].get('minutes')!=policies()[key]['minutes']:raise ValueError('pending')
                self.data=doc
        except (OSError,ValueError,KeyError,TypeError):self.blocked=True;self.error='모의체결 기록 읽기 실패'

    def save(self):
        from pc_update import atomic_json
        try:atomic_json(self.path,self.data)
        except OSError:
            self.blocked=True;self.error='모의체결 기록 저장 실패';raise

    def ready(self, key, now):
        with self.lock:
            v=self.data['rules'].get(key,{})
            p=v.get('pending')
            overdue=p and now>p['entry_ms']+(p['minutes']+15)*MINUTE
            return not self.blocked and not overdue and qualifies(v.get('history',[]),now)

    def allows(self, signal, now):
        with self.lock:
            key=signal['monthly208'];v=self.data['rules'].get(key,{})
            return bool(v.get('pending') and v.get('signal')==signal['signal_id'] and self.ready(key,now))

    def report(self, now):
        with self.lock:
            result={}
            for key in policies():
                v=self.data['rules'].get(key,{})
                h=[r for r in v.get('history',[]) if r['entry_ms']>=now-60*DAY][-COUNT:]
                result[key]={'n':len(h),'ready':self.ready(key,now),'pending':bool(v.get('pending'))}
            return dict(rules=result,error=self.error,blocked=self.blocked)

    def status_line(self,now):
        d=self.report(now);n=sum(r['ready'] for r in d['rules'].values())
        return '시간표 실거래 자격 '+str(n)+'개 · 나머지 규칙 모의체결 관찰'+(' · '+d['error'] if d['error'] else '')

    def live_candidates(self,now):
        with self.lock:
            return [s for s in self.signals if s['valid_from_ms']<=now<=s['expires_ms'] and self.allows(s,now)]

    def record(self,s,now):
        import pc_scalp as scalp
        key=s['monthly208'];side=1 if s['action']=='LONG' else -1
        day=(s['valid_from_ms']+(9*3600000 if key in scalp.SPECS else 0))//DAY
        cap=scalp.SPECS[key][-1] if key in scalp.SPECS else 1
        with self.lock:
            if self.blocked:return
            bucket=self.data['rules'].setdefault(key,{'history':[]})
            if bucket.get('pending') or bucket.get('signal')==s['signal_id']:return
            if bucket.get('day')==day and bucket.get('daily',0)>=cap:return
        quote=self.e.stream.read(s['symbol'],'tickers',3,now)
        if not quote or not quote.get('bidPx') or not quote.get('askPx'):
            quote=self.e.api.public('/api/v5/market/ticker',instId=s['symbol'])[0]
        now=self.e.api.now_ms();bid=float(quote['bidPx']);ask=float(quote['askPx']);ts=int(quote['ts'])
        if (not s['valid_from_ms']<=now<=s['expires_ms'] or not -500<=now-ts<=5000 or
                not 0<bid<=ask or (ask-bid)/((ask+bid)/2)>.0005):return
        px=(ask if side==1 else bid)*(1+side*SLIP)
        if not math.isfinite(px) or not (abs(px-s['entry_reference'])<=.5*s['atr'] and side*(px-s['stop'])>0):return
        with self.lock:
            bucket['daily']=(bucket.get('daily',0) if bucket.get('day')==day else 0)+1
            bucket.update(day=day,signal=s['signal_id'],pending=dict(symbol=s['symbol'],side=side,price=px,stop=s['stop'],
                tick=s['tick250'],entry_ms=now,minutes=s['holding_rule']['max_hold_seconds']//60))
            self.save()

    def advance(self,now):
        if self.work:
            key,sample,future=self.work
            if not future.done():return
            self.work=None
            try: row=future.result()
            except Exception:
                self.retry[key]=now+5*MINUTE;self.error='과거 시세·펀딩 재조회 대기';return
            with self.lock:
                bucket=self.data['rules'][key]
                if bucket.get('pending')==sample:
                    bucket['history']=(bucket['history']+[row])[-60:];bucket.pop('pending');self.save()
                self.error=''
        with self.lock:
            for key,bucket in self.data['rules'].items():
                sample=bucket.get('pending')
                if not sample:continue
                if now-sample['entry_ms']>60*DAY:
                    bucket.pop('pending');self.save();continue
                if now<sample['entry_ms']+(sample['minutes']+2)*MINUTE or now<self.retry.get(key,0):continue
                self.work=(key,sample,self.pool.submit(settle,self.e.api,dict(sample)));break

    def run(self):
        import pc_monthly as monthly
        import pc_scalp as scalp
        current=[]; last=0; tried={}; retry_at=0
        while not self.blocked and not self.stopping.is_set():
            try:
                now=self.e.api.now_ms();end=now//monthly.STEP*monthly.STEP
                self.advance(now)
                if self.monthly_job and self.monthly_job[1].done():
                    tag,future=self.monthly_job;self.monthly_job=None
                    try: current=future.result() if tag==end else []
                    except Exception:current=[]; self.error='15분봉 재조회 대기'
                if end!=last:current=[];last=end;retry_at=0
                if (not self.monthly_job and now-end<85000 and now>=retry_at and
                        any(monthly.active(key,end) for key in monthly.WINDOWS)):
                    self.monthly_job=(end,self.pool.submit(monthly.collect,self.e,end));retry_at=now+12000
                signals=[s for s in list(current)+list(scalp.candidates(self.e,now)) if s['valid_from_ms']<=now<=s['expires_ms']]
                for s in signals:
                    ident=s['signal_id']
                    if now<tried.get(ident,0):continue
                    tried[ident]=now+5000
                    try:self.record(s,now)
                    except (BotError,ValueError,OSError,KeyError,TypeError,IndexError):continue
                with self.lock:self.signals=signals
                if len(tried)>100:tried={k:v for k,v in tried.items() if v>=now}
            except Exception:
                if not self.blocked:self.error='모의 시세 재시도 중'
            self.stopping.wait(1)

    def start(self):
        if not self.blocked:threading.Thread(target=self.run,daemon=True,name='pc-forward-review').start()

    def close(self):
        self.stopping.set()
        self.pool.shutdown(wait=False, cancel_futures=True)

"""Local capital ledger for automatic orders opened by the 190 USDT profile."""
from okx_core import BotError, dec, fmt

INITIAL = dec(190)
KEY = 'auto_capital512'


def limits(engine, snapshot):
    data = engine.journal.data
    if any(s.get(KEY) for s in data.get('settlements', ())):
        raise BotError('자동 운용금 · 청산 순손익 정산 대기')
    ledger = data.get(KEY, {})
    balance = INITIAL + dec(ledger.get('net', 0))
    raw = getattr(engine, 'raw_snapshot', None) or snapshot
    live = {(p['instId'], p.get('posSide')): p for p in raw.get('positions', ()) if dec(p.get('pos') or 0)}
    used = dec(0)
    for o in engine.records():
        if not o.get(KEY):
            if (o.get('v4_signal') or {}).get('pc51'):
                raise BotError('기존 자동 포지션 종료 후 190 USDT 운용 시작')
            continue
        pos = live.get((o['symbol'], o['direction']))
        if not pos and o.get('phase') != 'submitted':
            raise BotError('자동 운용금 · 보유 수량 대조 중')
        used += max(dec(o['committed_margin']), dec((pos or {}).get('margin') or 0))
        # Reserve the opening fee until the final exchange settlement.
        fee = dec(o.get('entry_fee_reserve') or 0)
        balance -= fee
        if pos:
            sign = 1 if o['direction'] == 'long' else -1
            unrealized = (dec(pos['markPx'])-dec(pos['avgPx']))*sign*abs(dec(pos['pos']))*dec(o['ct_val'])
            balance += min(dec(0),unrealized) + min(dec(0),dec(pos.get('realizedPnl') or 0)+fee)
    return max(dec(0), balance), max(dec(0), balance-used)


def settle(data, item, profit):
    if not item.get(KEY):
        return
    ledger = data.setdefault(KEY, {'net':'0','booked':{}})
    identity = item['client_id']
    if identity not in ledger['booked']:
        ledger['net'] = fmt(dec(ledger['net']) + dec(profit))
        ledger['booked'][identity] = fmt(profit)

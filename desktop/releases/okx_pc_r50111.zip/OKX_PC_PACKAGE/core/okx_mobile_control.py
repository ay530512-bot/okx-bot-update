"""Narrow engine-thread control: prepare + one-use confirmation, or pause entries."""
import hashlib,json,secrets,time
from okx_core import BotError,dec

def fingerprint(e,budget):return hashlib.sha256(json.dumps(dict(config=e.cfg,budget=budget),sort_keys=True,default=str).encode()).hexdigest()

def handle(e,request):
 rid=request['request_id'];owner=request['owner'];op=request['op'];now=time.monotonic()
 result=dict(request_id=rid,owner=owner,status='failed',message='처리 보류')
 try:
  if op in ('entry','close_one','close_all'):
   from okx_click716 import accept
   accept(e,request);return
  if now-request['issued_at']>30 or now<request['issued_at']:raise BotError('요청 시간이 지났습니다. 다시 요청하세요.')
  tickets=getattr(e,'mobile_tickets',{});tickets={k:v for k,v in tickets.items() if v['expires']>now};e.mobile_tickets=tickets
  if op=='prepare':
   snap=e.snapshot();budget=float(request['budget']);ceiling=min(6.,float(e.cfg['execution']['model_runtime']['max_daily_budget']))
   if not .01<=budget<=ceiling:raise BotError('PC의 AI 예산 설정을 확인하세요.')
   if snap['equity']<1:raise BotError('거래 자산이 1 USDT 미만입니다.')
   if not e.account_stream.fresh():raise BotError('계정 연결과 최초 조회를 확인하세요.')
   if e.cfg['execution'].get('profile')!='FREE5' and not e.cfg['execution'].get('rule_channel701'):raise BotError('지원하는 운용 프로필이 아닙니다.')
   token=secrets.token_urlsafe(24);e.mobile_tickets[token]=dict(owner=owner,expires=now+60,equity=snap['equity'],available=snap['available'],budget=budget,fingerprint=fingerprint(e,budget))
   if len(e.mobile_tickets)>32:e.mobile_tickets.pop(next(iter(e.mobile_tickets)))
   summary=[['계정 총자산',str(snap['equity'])+' USDT'],['가용잔고',str(snap['available'])+' USDT'],
            ['자동 진입','5.1.11 · 차트 적합도 순위 · 롱·숏'],['자동 배율','고정 5배'],
            ['자동 증거금','(자동 운용금 − 3 USDT) ÷ 8'],
            ['자동 진입 한도','최대 8자리 · 수동 보유 및 미체결 포함'],['수동 진입 배율','5배'],
            ['보유분 관리','진입 시 저장한 전략별 손절·청산 조건 적용']]
   result.update(status='prepared',ticket=token,expires_in=60,summary=summary,
                 message='자동 진입과 직접 주문을 사용하려면 60초 안에 확인하세요.')
  elif op=='confirm':
   ticket=e.mobile_tickets.get(request.get('ticket'))
   if not ticket or ticket['owner']!=owner:raise BotError('확인 정보가 없거나 만료됐습니다. 다시 조회하세요.')
   e.mobile_tickets.pop(request['ticket']) # consume before any external effect
   if fingerprint(e,ticket['budget'])!=ticket['fingerprint']:raise BotError('설정이 바뀌었습니다. 다시 확인하세요.')
   snap=e.snapshot()
   for name in ('equity','available'):
    if abs(snap[name]-ticket[name])>max(dec('.1'),abs(ticket[name])*dec('.02')):raise BotError('잔고가 바뀌었습니다. 다시 확인하세요.')
   if e.enabled and not e.preview and not e.user_paused:
    result.update(status='applied',message='이미 실거래가 활성화되어 있습니다. 중복 시작하지 않았습니다.')
   else:
    try:e.handle('live',dict(equity=ticket['equity'],budget=ticket['budget'],hours=24))
    except Exception:
     e.pause('모바일 실거래 시작 검증 실패 · 신규 진입 중지');raise
    e.mobile_entry_pause=False
    result.update(status='applied',message='실거래 활성화 완료 · 계정과 보호 주문 대조 후 자동 진입과 직접 주문을 시작합니다.')
  elif op=='pause':
   e.handle('pause',{});e.mobile_entry_pause=True;e.mobile_tickets.clear()
   result.update(status='applied',message='신규·추가 진입 중지 완료 · 기존 포지션의 보호 손절과 보유·청산 관리는 유지합니다.')
  else:raise BotError('허용되지 않은 제어입니다.')
 except Exception as exc:result.update(status='failed',message=str(exc) if isinstance(exc,BotError) else 'PC 제어 처리 오류 · 상태를 확인하세요.')
 if op=='entry':
  from okx_entry_gate720 import gate
  result['entry_gate']=gate(e)
 result['live']=bool(e.enabled);result['user_paused']=bool(e.user_paused)
 e.events.put(('mobile_control_result',result))
 if op!='prepare':
  try:e.notify('모바일 운용 제어',result['message'],state=rid)
  except Exception:pass

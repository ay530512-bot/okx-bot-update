@echo off
call "%~dp0run_pc.bat" supervise %*
pause

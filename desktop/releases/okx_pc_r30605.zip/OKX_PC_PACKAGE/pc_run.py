"""Windows entry point for the engine and browser dashboard."""
import argparse
from contextlib import contextmanager
import getpass
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

PACKAGE = Path(__file__).resolve().parent
CORE = PACKAGE / 'core'
RUNTIME = PACKAGE / 'runtime'
TRANSFER_FILES = ('strategy_config.json', 'bot_state.json')
PORT = 8766
INSTANCE_PORT = 48736  # Also used by the original PC program.
KEYS = ('OKX_API_KEY', 'OKX_SECRET_KEY', 'OKX_PASSPHRASE')
NOTIFICATIONS = ('TELEGRAM_BOT_TOKEN', 'TELEGRAM_CHAT_ID')


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def activate_package():
    from pc_update import verify_package
    verify_package(PACKAGE)
    sys.path[:0] = [str(RUNTIME), str(CORE)]
    from phone_clock import install
    install()
    return json.loads((RUNTIME / 'phone_sources.json').read_text(encoding='utf-8'))


@contextmanager
def exclusive_engine():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as handle:
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            handle.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            handle.bind(('127.0.0.1', INSTANCE_PORT))
        except OSError:
            raise ValueError('이 PC에 이미 OKX 프로그램이 실행 중입니다. 기존 창을 확인하세요.') from None
        yield


def local_path(value):
    return Path(value.strip().strip('"')).expanduser()


def credentials(root, supplied=None):
    from dotenv import dotenv_values
    from phone_account import validate_keys
    from phone_host import read_json

    path = root / 'pc_credentials.json'
    if supplied is None and path.exists():
        saved = read_json(path)
        keys = validate_keys({key: saved.get(key) for key in KEYS})
        keys.update({key: saved[key] for key in NOTIFICATIONS if saved.get(key)})
        return keys

    value = supplied
    if value is None:
        print('예전 PC 프로그램의 .env 파일이나 그 폴더를 끌어다 놓으세요.')
        value = input('경로 입력 · 키를 직접 입력하려면 Enter: ').strip()
    if value:
        source = local_path(value)
        if source.is_dir():
            source = source / '.env'
        if not source.is_file():
            raise ValueError('선택한 경로에 .env 파일이 없습니다.')
        old = dotenv_values(source, encoding='utf-8-sig', interpolate=False)
        output = validate_keys({key: old.get(key) for key in KEYS})
        output.update({key: old[key] for key in NOTIFICATIONS if old.get(key)})
    else:
        labels = ('OKX API Key', 'OKX Secret Key', 'OKX Passphrase')
        output = validate_keys({key: getpass.getpass(label + ': ').strip()
                                for key, label in zip(KEYS, labels)})
    return output


def read_transfer(path):
    from okx_core import initial_state
    from phone_handover import records

    expected = {*TRANSFER_FILES, 'transfer.json'}
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if len(entries) != len(expected) or {entry.filename for entry in entries} != expected:
            raise ValueError('폴드에서 만든 OKX_PC_TRANSFER.zip 파일을 선택해 주세요.')
        if any(entry.is_dir() or not 0 < entry.file_size <= 32 * 1024 * 1024 for entry in entries):
            raise ValueError('이전 파일 크기를 확인하세요.')
        meta = json.loads(archive.read('transfer.json'))
        payload = {name: archive.read(name) for name in TRANSFER_FILES}
    if meta.get('format') != 1 or meta.get('files') != {k: sha256(v) for k, v in payload.items()}:
        raise ValueError('이전 파일의 기록 검증에 실패했습니다. 폴드에서 다시 내보내세요.')
    journal = json.loads(payload['bot_state.json'])
    if not isinstance(journal, dict) or not (initial_state().keys() - {'session', 'api_total_spent'}) <= journal.keys():
        raise ValueError('이전 운용 기록 형식을 확인하세요.')
    if records(journal) or journal.get('manual_closes716'):
        raise ValueError('폴드 기록에 보유 또는 처리 중인 주문이 있습니다.')
    intent = journal.get('entry_continuity732') or {}
    if intent.get('schema') != 1 or intent.get('requested') is not False:
        raise ValueError('폴드의 신규 진입 중지를 확인한 뒤 다시 내보내세요.')
    return payload, journal


def account_read(api):
    from phone_host import identity
    from phone_account import finite
    snapshot = api.snapshot()
    account = identity(snapshot)
    counts = (sum(finite(row.get('pos', '0')) != 0 for row in snapshot['positions']),
              len(snapshot['orders']), len(api.pending_algos(full=True)))
    return snapshot, account, counts


def require_trade_permission(snapshot):
    permissions = {x.strip() for x in str(snapshot['config'].get('perm') or '').split(',')}
    if 'trade' not in permissions:
        raise ValueError('이 OKX API 키의 Trade 권한을 확인하세요.')


def stage_handover(root, path, api, pins, wait=time.sleep):
    from phone_account import atomic_private, save_json, validate_config
    from phone_host import prepare_runtime

    payload, journal = read_transfer(path)
    target = root / 'trading'
    if target.exists() or target.is_symlink():
        raise ValueError('PC 운용 기록이 이미 있습니다. PC_START.bat로 이어서 실행하세요.')

    with tempfile.TemporaryDirectory(prefix='.incoming-', dir=root) as temp:
        stage = Path(temp) / 'trading'
        stage.mkdir()
        config_sha = sha256(payload['strategy_config.json'])
        markers = dict(source_sha256=pins['archive_sha256'], config_sha256=config_sha)
        atomic_private(stage / 'strategy_config.json', payload['strategy_config.json'])
        validate_config(stage, config_sha)
        runtime = prepare_runtime(stage, markers)
        atomic_private(runtime / 'bot_state.json', payload['bot_state.json'])
        first = None
        for number in range(2):
            if number:
                wait(2)
            snapshot, account, counts = account_read(api)
            require_trade_permission(snapshot)
            if any(counts):
                raise ValueError('이전 대기 · 보유 {} / 미체결 {} / 조건주문 {}. 폴드에서 보유 관리를 이어가세요.'.format(*counts))
            if journal['account'] != sha256(str(snapshot['config']['uid']).encode()):
                raise ValueError('폴드 운용 기록과 이 PC의 OKX 계정이 다릅니다.')
            if first is not None and first != account:
                raise ValueError('계정 대조 사이에 연결 계정이 바뀌었습니다.')
            first = account
        save_json(stage / 'phone_owner.json', dict(**markers, account_sha256=account,
                  first_start_pending=True))
        stage.rename(target)
    return target


def validate_restart(root, api, pins):
    from phone_host import read_json, prepare_runtime, verify_owner, verify_restart_journal

    owner = read_json(root / 'phone_owner.json')
    markers = dict(source_sha256=pins['archive_sha256'], config_sha256=owner['config_sha256'])
    runtime = prepare_runtime(root, markers)
    if owner.get('first_start_pending'):
        snapshot, _, counts = account_read(api)
        if any(counts):
            raise ValueError('PC 첫 기동 대기 · 보유 {} / 미체결 {} / 조건주문 {}'.format(*counts))
    else:
        snapshot = api.snapshot()
    require_trade_permission(snapshot)
    verify_owner(root, markers, snapshot)
    verify_restart_journal(runtime, snapshot)
    return runtime


def tailscale_cli():
    folder = Path(os.environ.get('ProgramFiles', 'C:/Program Files'))
    choices = [shutil.which('tailscale'), folder / 'Tailscale' / 'tailscale.exe']
    for choice in choices:
        if choice and Path(choice).is_file():
            return os.fspath(choice)
    raise ValueError('PC에 Tailscale을 설치하고 아이폰이 사용하는 네트워크에 로그인하세요.')


def tailscale_json(cli, *args):
    result = subprocess.run([cli, *args], capture_output=True, encoding='utf-8', timeout=15)
    if result.returncode:
        raise ValueError('Tailscale 연결 상태를 읽지 못했습니다.')
    return json.loads(result.stdout or '{}')


def serve_route(status, host):
    """Use the existing PC address when it already points to this local port."""
    handlers = status.get('Web') or {}
    tcp = status.get('TCP') or {}
    public = status.get('AllowFunnel') or {}
    if any(on and address.endswith(':8443') for address, on in public.items()):
        raise ValueError('Tailscale 8443에 공개 공유가 설정되어 있습니다. 해당 주소의 공유 설정을 확인하세요.')
    expected = {'/': {'Proxy': f'http://127.0.0.1:{PORT}'}}
    here = handlers.get(host, {}).get('Handlers', {})
    if (here == expected and tcp.get('8443', {}).get('HTTPS') is True
            and not any(address.endswith(':8443') and address != host for address in handlers)):
        return True
    if '8443' in tcp or any(address.endswith(':8443') for address in handlers):
        raise ValueError('Tailscale 8443을 다른 서비스가 사용 중입니다. 기존 주소 설정을 확인하세요.')
    return False


def configure_iphone(root):
    from phone_account import save_json
    from phone_remote import host_from_status

    cli = tailscale_cli()
    host = host_from_status(tailscale_json(cli, 'status', '--json'))
    if not serve_route(tailscale_json(cli, 'serve', 'status', '--json'), host):
        print('Tailscale HTTPS 안내가 나오면 브라우저에서 진행하세요.', flush=True)
        result = subprocess.run([cli, 'serve', '--bg', '--https=8443', f'http://127.0.0.1:{PORT}'], timeout=180)
        if result.returncode or not serve_route(tailscale_json(cli, 'serve', 'status', '--json'), host):
            raise ValueError('PC의 비공개 HTTPS 주소 설정이 완료되지 않았습니다.')
    save_json(root / 'phone_remote.json', dict(https_host=host, transport='private-tailscale-serve', public_access=False))
    print(f'아이폰 Tailscale을 연결하고 Safari에서 여세요. https://{host}', flush=True)


def public_probe(now_ms, duration=24):
    from okx_stream import MarketStream
    import phone_public_ws as wire
    from phone_public_lanes import install

    wire.install()
    install()
    stream = MarketStream()
    symbol = 'AAVE-USDT-SWAP'
    stream.watch([symbol])
    stream.monitor([symbol])
    clock_started = time.monotonic()
    end = clock_started + duration
    stream.start()
    print(f'공개 시세 연결을 {duration}초 확인합니다.', flush=True)
    try:
        while time.monotonic() < end:
            time.sleep(.25)
        at = now_ms + int((time.monotonic() - clock_started) * 1000)
        quotes = [name for name in stream.CHANNELS if stream.read(symbol, name, 15, at)]
        monitor = stream._phone_monitor_stream
        mon_quote = monitor.read(symbol, 'tickers', 15, at)
        with stream.lock:
            execution_drops = wire.diagnostics(stream)['disconnect_count']
        with monitor.lock:
            monitor_drops = wire.diagnostics(monitor)['disconnect_count']
        print('진입·보유 채널', len(quotes), '/', len(stream.CHANNELS), '· 감시 채널', '수신' if mon_quote else '대기')
        print('측정 중 끊김 · 진입·보유', execution_drops, '회 / 감시', monitor_drops, '회')
        if len(quotes) != len(stream.CHANNELS) or not mon_quote or execution_drops or monitor_drops:
            raise ValueError('PC에서 시세 연결 점검을 다시 확인하세요.')
    finally:
        stream.stop()


def start_trading(root, keys, api, pins, transfer):
    from phone_account import save_json
    from phone_host import auth_config, serve, remote_host
    from phone_mobile import mobile_module

    with exclusive_engine():
        trading = root / 'trading'
        if not trading.exists():
            default = Path.home() / 'Downloads' / 'OKX_PC_TRANSFER.zip'
            if transfer is None:
                value = input('폴드에서 가져온 OKX_PC_TRANSFER.zip 경로 (기본 Downloads): ')
                transfer = local_path(value) if value.strip() else default
            print('폴드에서 신규 진입을 중지하고 Termux 실행기까지 종료했는지 확인하세요.')
            if input('완료했다면 FOLD STOPPED 입력: ').strip() != 'FOLD STOPPED':
                raise ValueError('폴드 종료 확인이 필요합니다.')
            trading = stage_handover(root, transfer, api, pins)
        runtime = validate_restart(trading, api, pins)
        save_json(root / 'pc_credentials.json', keys)
        api.session.close()
        access = auth_config(trading, mobile_module(CORE))
        remote = remote_host(root)
        print(f'PC 브라우저 http://127.0.0.1:{PORT}', flush=True)
        if remote:
            print(f'아이폰 주소 https://{remote}', flush=True)
        else:
            print('아이폰 주소는 IPHONE_SETUP.bat에서 설정할 수 있습니다.', flush=True)
        return serve(trading, runtime, CORE, dict(keys, TRADING_EXCHANGE='okx', _EXCHANGE_ROOT=str(runtime)),
                     access, run_engine=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('check', 'start', 'iphone', 'supervise'))
    parser.add_argument('--env')
    parser.add_argument('--transfer', type=Path)
    args = parser.parse_args()
    if sys.platform != 'win32':
        raise ValueError('PC 실행 파일은 Windows용입니다.')
    root = Path(os.environ['LOCALAPPDATA']) / 'OKXTradingPC'
    root.mkdir(exist_ok=True)
    if args.mode == 'supervise':
        from pc_update import supervise
        raise SystemExit(supervise(root, PACKAGE, sys.argv[2:]))
    pins = activate_package()
    if args.mode == 'iphone':
        configure_iphone(root)
        return
    keys = credentials(root, args.env)
    from phone_account import readonly_client, save_json
    api = readonly_client({key: keys[key] for key in KEYS})
    try:
        if args.mode == 'check':
            snapshot, _, counts = account_read(api)
            require_trade_permission(snapshot)
            save_json(root / 'pc_credentials.json', keys)
            print('OKX 계정 확인 · 보유 {} / 미체결 {} / 조건주문 {}'.format(*counts), flush=True)
            public_probe(api.now_ms())
            print('PC 연결 점검 완료. 폴드에서 운용 기록 내보내기 단계로 진행하세요.')
        elif start_trading(root, keys, api, pins, args.transfer):
            from pc_update import RESTART
            raise SystemExit(RESTART)
    finally:
        api.session.close()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print('\n입력을 중단했습니다.')
        raise SystemExit(1)
    except Exception as error:
        from importlib import import_module
        # OKX and input errors contain bounded user-facing text. Never print key data.
        bot_error = import_module('okx_core').BotError if str(CORE) in sys.path else ()
        print('\n진행 확인 · ' + (str(error) if isinstance(error, ValueError) or isinstance(error, bot_error)
                                    else type(error).__name__), flush=True)
        raise SystemExit(1)

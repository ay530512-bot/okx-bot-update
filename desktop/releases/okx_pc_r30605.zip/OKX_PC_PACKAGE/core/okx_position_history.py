"""Read-only OKX position history, source evidence and close-date PnL summaries."""
import calendar,hashlib,json,re,threading,time
from datetime import datetime,timedelta
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal,InvalidOperation
from okx_core import OKX,KST,BotError
FIELDS=('instId','posId','posSide','direction','mgnMode','ccy','cTime','uTime','type','openAvgPx','closeAvgPx','realizedPnl','fee','fundingFee','pnlRatio')

def amount(v):
 try:
  d=Decimal(str(v));return d if d.is_finite() else None
 except (InvalidOperation,ValueError,TypeError):return None

def bounds(day):
 d=datetime.strptime(day,'%Y-%m-%d').replace(tzinfo=KST);return int(d.timestamp()*1000),int((d+timedelta(days=1)).timestamp()*1000)
def key(r):return '|'.join(str(r.get(k) or '') for k in ('instId','posId','cTime','posSide','mgnMode'))
def stamp(v):
 try:return datetime.fromtimestamp(int(v)/1000,KST).strftime('%Y-%m-%d %H:%M:%S') if int(v)>0 else '미확인'
 except (TypeError,ValueError,OverflowError):return '미확인'

SOURCE_LABELS={'auto':'자동','manual':'수동','mixed':'혼합','unknown':'확인 필요'}
FILTER_LABELS={'all':'전체',**SOURCE_LABELS}
EXIT_LABELS={'manual':'수동 청산','auto':'자동청산','sl':'자동청산 (SL)',
             'tpsl':'자동청산 (TP/SL)','trailing':'자동청산 (추적손절)',
             'liquidation':'거래소 강제청산','adl':'거래소 자동감축'}
MANUAL_REASONS={'사용자 개별 전량 청산 버튼','사용자 청산 요청'}
GENERIC_EXIT='거래소 손절 또는 포지션 종료'


def ms(value):
 try:return int(value or 0)
 except (ValueError,TypeError):return 0


def entry_method(record):
 signal=record.get('v4_signal') or {}
 if any(signal.get(flag) for flag in ('click716','user_chat_order','selected_ai_order')):
  return 'manual'
 return 'auto'


def linked_settlement(row,settled):
 opening,closing=ms(row.get('cTime')),ms(row.get('uTime'))
 matches=[s for s in settled if s.get('symbol')==row.get('instId') and s.get('posId')
          and str(s['posId'])==str(row.get('posId'))
          and s.get('direction')==(row.get('direction') or row.get('posSide'))
          and abs(ms(s.get('entry_ms'))-opening)<=120000 and abs(ms(s.get('end_ms'))-closing)<=120000]
 return matches[0] if len(matches)==1 else {}


def order_method(order,closing=False):
 source=str(order.get('source') or '')
 client=str(order.get('clOrdId') or '')
 algo=str(order.get('algoClOrdId') or '')
 if closing:
  if order.get('category') in ('full_liquidation','partial_liquidation'):return 'liquidation'
  if order.get('category')=='adl':return 'adl'
  if source=='25':return 'trailing'
  # OS is this program's exchange-side protective stop identifier.
  if source in ('7','13') and re.fullmatch(r'OS[0-9a-f]{28}',algo):return 'sl'
  if source=='7':return 'tpsl'
  if source in ('6','13'):return 'auto'
  if re.fullmatch(r'MC716[0-9a-f]{26}',client):return 'manual'
 if (order.get('category')=='normal' and source in ('','0')
     and not (client or algo or order.get('algoId'))):
  return 'manual'
 return None


def order_evidence(row,orders):
 direction=row.get('direction') or row.get('posSide')
 if direction not in ('long','short'):return {}
 levels={'entry_order':(ms(row.get('cTime')),'buy' if direction=='long' else 'sell'),
         'exit_order':(ms(row.get('uTime')),'sell' if direction=='long' else 'buy')}
 relevant=[o for o in orders if o.get('instId')==row.get('instId') and o.get('tdMode')==row.get('mgnMode')
           and o.get('posSide')==row.get('posSide') and amount(o.get('accFillSz')) and o.get('ordId')
           and (not o.get('posId') or str(o['posId'])==str(row.get('posId')))]
 out={}
 for name,(time,side) in levels.items():
  candidates={o['ordId']:o for o in relevant if o.get('side')==side and time>0
              and abs(ms(o.get('fillTime'))-time)<=2000}
  if len(candidates)==1:
   method=order_method(next(iter(candidates.values())),name=='exit_order')
   if method:out[name]=method
 return out


def attribution(row,sources,settled):
 evidence=sources.get(key(row)) or {}
 matched=linked_settlement(row,settled)
 legacy=evidence.get('source')
 saved_entry=matched.get('entry_method')
 if (matched.get('learning') or {}).get('setup')=='manual_click716':saved_entry='manual'
 entry=saved_entry or evidence.get('entry_method') or evidence.get('entry_order') or matched.get('source')
 if entry not in ('auto','manual'):
  entry=legacy if legacy in ('auto','manual') else None
 reason=matched.get('reason')
 exit_method=evidence.get('exit_order')
 if row.get('type')=='3':
  exit_method='liquidation'
 if not exit_method and reason and reason!=GENERIC_EXIT:
  exit_method='manual' if reason in MANUAL_REASONS else 'auto'
 if exit_method and entry and ((entry=='manual')!=(exit_method=='manual')):
  source='mixed'
 elif legacy=='mixed':
  source='mixed'
 else:
  source=entry or 'unknown'
 return dict(source=source,entry_method=entry,exit_method=exit_method,entry_label={'auto':'자동 진입','manual':'수동 진입'}.get(entry,'진입 방식 확인 필요'),
             exit_label=EXIT_LABELS.get(exit_method,'청산 방식 확인 필요'))


def classify(r,sources,settled):
 return attribution(r,sources,settled)['source']


def summarize(data,rows):
 sums={k:Decimal(0) for k in ('profit','loss','total','auto','manual','mixed','unknown')}
 missing=0
 for r in rows:
  value=amount(r.get('pnl'))
  if value is None:missing+=1;continue
  sums['profit' if value>0 else 'loss']+=value;sums['total']+=value
  sums[r.get('source') if r.get('source') in SOURCE_LABELS else 'unknown']+=value
 unqueried=not data.get('rows') and data.get('summary') and all(v is None for v in data['summary'].values())
 return dict(data,rows=rows,count=len(rows),missing_pnl=missing,
             mixed_count=sum(r.get('source')=='mixed' for r in rows),
             unknown_count=sum(r.get('source')=='unknown' for r in rows),
             summary={k:None if unqueried else str(v) for k,v in sums.items()})


def report(day,rows,sources=None,settled=None):
 start,end=bounds(day);out=[]
 for r in rows.values():
  if not isinstance(r,dict):continue
  closed_ms=ms(r.get('uTime'))
  if r.get('type') not in ('2','3','6') or not r.get('instId','').endswith('-USDT-SWAP'):continue
  if not start<=closed_ms<end:continue
  value=amount(r.get('realizedPnl'))
  out.append(dict(key=hashlib.sha256(key(r).encode()).hexdigest()[:20],symbol=r['instId'],
   direction=r.get('direction') or r.get('posSide') or '미확인',entry_time=stamp(r.get('cTime')),exit_time=stamp(r.get('uTime')),
   entry_price=r.get('openAvgPx'),exit_price=r.get('closeAvgPx'),pnl=str(value) if value is not None else None,
   roe=r.get('pnlRatio'),fee=r.get('fee'),funding=r.get('fundingFee'),exit_ms=closed_ms,
   **attribution(r,sources or {},settled or [])))
 out.sort(key=lambda r:r['exit_ms'],reverse=True)
 return summarize(dict(date=day,basis='한국시간 청산일 기준 · 청산 완료 포지션 확정 손익'),out)


def filter_report(data,source='all'):
 """Local display filter; preserves source evidence and never requests the exchange."""
 if source not in FILTER_LABELS:raise ValueError('unknown history filter')
 return dict(data) if source=='all' else summarize(data,[r for r in data.get('rows',[]) if r.get('source')==source])


class PositionHistory:
 def __init__(self,root,settings,events,api_factory=None):
  self.root=Path(root);self.settings=settings;self.events=events;self.api_factory=api_factory or OKX
  self.lock=threading.RLock();self.pool=ThreadPoolExecutor(max_workers=1,thread_name_prefix='position-history');self.future=None;self.active=False;self.pending=None;self.started=False;self.stopped=False;self.next_poll=0
  self.rows={};self.sources={};self.errors=[];self.order_lookup={}
  for name,target in (('position_history_cache.json','rows'),('position_sources.json','sources')):
   try:
    p=self.root/name
    if p.exists():
     value=json.loads(p.read_text(encoding='utf-8'))
     if not isinstance(value,dict):raise ValueError('invalid history cache')
     setattr(self,target,value)
   except Exception:self.errors.append(name+' 읽기 실패: 새 조회 결과만 표시')
 def save(self,name,value):
  from okx_daily_report import atomic_json
  atomic_json(self.root/name,value)
 def start(self):self.started=True
 def stop(self):self.stopped=True;self.pool.shutdown(wait=False,cancel_futures=True)
 def observe(self,snapshot,records):
  changes=False
  with self.lock:
   for p in snapshot.get('positions',[]):
    if not p.get('posId') or not p.get('cTime') or not p.get('instId','').endswith('-USDT-SWAP') or not amount(p.get('pos')):continue
    record=next((r for r in records if (r['symbol'],r['direction'])==(p['instId'],p.get('posSide'))),None)
    k=key(p);old=self.sources.get(k) or {}
    method=old.get('entry_method')
    if record and record.get('posId') and str(record['posId'])==str(p['posId']):
     method=entry_method(record)
    elif not record and method is None:
     method=old.get('source') if old.get('source') in ('auto','manual') else 'manual' if not old else None
    if method:
     value=dict(old,entry_method=method,source=method if old.get('source') not in ('auto','manual','mixed') else old['source'])
     if old!=value:self.sources[k]=value;changes=True
   if changes:self.save('position_sources.json',self.sources)
 def reconcile_orders(self,api,day,start,end):
  # Run only on the existing history worker, and never as part of order handling.
  with self.lock:
   rows=[r for r in self.rows.values() if start<=ms(r.get('uTime'))<end and r.get('type')=='2']
   settled=self.settled()
   needs=[]
   for row in rows:
    data=attribution(row,self.sources,settled)
    if not data['entry_method'] or not data['exit_method']:
     needs.append((row,not data['entry_method']))
  if not needs:return
  times=tuple((key(row),ms(row['uTime'])) for row,_ in needs)
  now=time.monotonic()
  cached=self.order_lookup.get(day)
  if cached and cached[0]==times and now-cached[1]<300:return
  self.order_lookup={k:v for k,v in self.order_lookup.items() if now-v[1]<300}
  self.order_lookup[day]=times,now
  orders=[]
  cursor={}
  # Entry evidence is also checked near midnight for positions opened on this date.
  for _ in range(3):
   if self.stopped:return
   page=api.get('/api/v5/trade/orders-history-archive',instType='SWAP',
                begin=str(start-2000),end=str(end+2000),limit='100',**cursor)
   orders.extend(page)
   if len(page)<100:break
   last=page[-1].get('ordId')
   if not last or last==cursor.get('after'):return
   cursor={'after':last}
  else:return  # an incomplete search cannot prove a unique matching order
  found={}
  earlier={}
  for row,missing_entry in needs:
   evidence=order_evidence(row,orders)
   opened=ms(row.get('cTime'))
   if opened and opened<start-2000 and missing_entry:
    query=(row['instId'],opened)
    if query not in earlier and len(earlier)<4:
     try:
      earlier[query]=api.get('/api/v5/trade/orders-history-archive',instType='SWAP',instId=query[0],
                             begin=str(opened-120000),end=str(opened+2000),limit='100')
     except BotError:
      earlier[query]=[]
    page=earlier.get(query,[])
    if len(page)<100:
     entry=order_evidence(row,page).get('entry_order')
     if entry:evidence['entry_order']=entry
   if evidence:found[key(row)]=evidence
  with self.lock:
   changed=False
   for identity,evidence in found.items():
    old=self.sources.get(identity) or {}
    value=dict(old,**evidence)
    if old!=value:self.sources[identity]=value;changed=True
   if changed:self.save('position_sources.json',self.sources)

 def settled(self):
  rows=[];p=self.root/'position_results.jsonl'
  if p.exists():
   try:lines=p.read_text(encoding='utf-8').splitlines()
   except OSError:return rows
   for line in lines:
    try:
     value=json.loads(line)
     if isinstance(value,dict):rows.append(value)
    except (ValueError,TypeError):continue
  return rows
 def payload(self,day,**extras):
  with self.lock:data=report(day,self.rows,self.sources,self.settled())
  if not data['count'] and (extras.get('loading') or extras.get('error')):data['summary']={k:None for k in data['summary']}
  data.update(extras);return data
 def tick(self,now):
  if self.started and not self.stopped and time.monotonic()>=self.next_poll:
   self.next_poll=time.monotonic()+60;self.request(datetime.fromtimestamp(now/1000,KST).strftime('%Y-%m-%d'),False)
 def request(self,day,force=True):
  bounds(day)
  with self.lock:
   if self.stopped:return
   self.events.put(('position_history',self.payload(day,loading=True,error=None,complete=False)))
   if self.active:
    if force:self.pending=day
    return
   self.pending=day;self.active=True;self.future=self.pool.submit(self.run)
 def run(self):
  api=None
  try:
   try:api=self.api_factory(self.settings)
   except Exception as error:
    with self.lock:day=self.pending;self.pending=None
    if day:self.events.put(('position_history',self.payload(day,loading=False,error='내역 연결 설정 확인: '+(str(error)[:180] if isinstance(error,BotError) else type(error).__name__),complete=False)))
    return
   while not self.stopped:
    with self.lock:day=self.pending;self.pending=None
    if day is None:return
    try:
     start,end=bounds(day);cursor=end;complete=False
     for page in range(20):
      if self.stopped:return
      data=api.get('/api/v5/account/positions-history',instType='SWAP',before=str(start-1),after=str(cursor),limit='100')
      with self.lock:
       for r in data:
        if r.get('instId','').endswith('-USDT-SWAP') and r.get('ccy') in ('USDT',None,''):
         value={k:r.get(k) for k in FIELDS};k=key(value)
         if int(value.get('uTime') or 0)>=int(self.rows.get(k,{}).get('uTime') or 0):self.rows[k]=value
      if not data or len(data)<100:complete=True;break
      oldest=min(int(r.get('uTime') or 0) for r in data)
      if oldest<=start:complete=True;break
      if oldest>=cursor:break
      cursor=oldest;time.sleep(.26)
     with self.lock:self.save('position_history_cache.json',self.rows)
     note='；'.join(self.errors)
     try:self.reconcile_orders(api,day,start,end)
     except Exception:note+=' / 주문 기록 대조 지연 · 확인된 방식만 표시'
     now=datetime.fromtimestamp(api.now_ms()/1000,KST);index=now.year*12+now.month-1-3;y,m=divmod(index,12);cutoff=now.replace(year=y,month=m+1,day=min(now.day,calendar.monthrange(y,m+1)[1]))
     if start<int(cutoff.timestamp()*1000):complete=False;note+=' / 최근3개월 조회 범위 이전 또는 경계 날짜: 저장된 일부 내역일 수 있습니다.'
     if not complete:note+=' / 조회 한도 또는 페이지 진행 제한: 일부 내역일 수 있습니다.'
     self.events.put(('position_history',self.payload(day,loading=False,error=note or None,complete=complete,updated_ms=api.now_ms())))
    except Exception as error:
     self.events.put(('position_history',self.payload(day,loading=False,error='내역 조회 실패: '+(str(error)[:180] if isinstance(error,BotError) else type(error).__name__)+' / 기존 캐시 표시',complete=False)))
    with self.lock:
     if self.pending is None:return
  finally:
   if api is not None:api.session.close()
   with self.lock:
    self.active=False
    if self.pending is not None and not self.stopped:self.active=True;self.future=self.pool.submit(self.run)

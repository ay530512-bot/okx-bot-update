"""Position capacity gate; no position management side effects."""

def occupied_keys(engine, snapshot=None):
    keys = {(r['symbol'], r['direction']) for r in engine.records()}
    def count_order(order):
        if not order.get('instId') or str(order.get('reduceOnly','')).lower() in ('true','1'):
            return
        direction, side = order.get('posSide'), order.get('side')
        if (direction,side) in (('long','sell'),('short','buy')):
            return
        if str(order.get('closeFraction') or '0') not in ('0','0.0') or order.get('state') in ('filled','canceled','order_failed'):
            return
        if direction not in ('long','short'):
            direction = {'buy':'long','sell':'short'}.get(side,'unknown')
        keys.add((order['instId'], direction))
    for raw in (snapshot or {}, getattr(engine,'raw_snapshot',None) or {}):
        for p in raw.get('positions',[]) + raw.get('manual_positions',[]):
            qty = float(p.get('pos') or 0)
            if qty:
                direction = p.get('posSide')
                if direction not in ('long','short'):
                    direction = 'long' if qty>0 else 'short'
                keys.add((p['instId'],direction))
        for order in raw.get('orders',[]) + raw.get('manual_orders',[]):
            count_order(order)
    for order in getattr(engine,'manual_algo_rows',[]) or []:
        count_order(order)
    return keys


def occupied(engine, snapshot=None):
    keys=occupied_keys(engine,snapshot)
    if not getattr(engine,'cfg',{}).get('risk',{}).get('pc_three_slots'):
        return len(keys)
    from decimal import Decimal, ROUND_CEILING
    from okx_position_history import entry_method
    raw=getattr(engine,'raw_snapshot',None) or snapshot or {}
    equity=Decimal(str((snapshot or raw).get('equity') or 0))
    if equity<=0:
        return len(keys)
    owned={(r['symbol'],r['direction']):r for r in engine.records()}
    manual={k:Decimal(str(r.get('committed_margin') or 0)) for k,r in owned.items()
            if entry_method(r)=='manual'}
    for row in raw.get('positions',[])+raw.get('manual_positions',[]):
        key=(row.get('instId'),row.get('posSide'))
        if key not in keys or (key in owned and key not in manual):
            continue
        value=Decimal(str(row.get('margin') or 0))
        if value<=0:
            value=Decimal(str(row.get('imr') or 0))
        manual[key]=max(manual.get(key,0),value)
    units=(sum(manual.values())*limit(engine)/equity).to_integral_value(rounding=ROUND_CEILING)
    return len(keys)+max(0,int(units)-len(manual))


def limit(engine):
    value = getattr(engine,'cfg',{}).get('risk',{}).get('max_positions',2)
    return int(value) if type(value) is int and value>0 else 2


def sync(engine):
 previous=getattr(engine,'_search_capacity_full',None)
 maximum=limit(engine);full=occupied(engine)>=maximum
 engine.universe.set_search_paused(full)
 if full:
  job=getattr(engine,'free_jobs',{}).get('ENTRY')
  if job:
   job['discard']=True
   if job['future'].cancel():engine.free_jobs.pop('ENTRY',None)
  engine.free_ready=None
  if hasattr(engine,"channel_pending"):engine.channel_pending.clear()
 if getattr(engine,'_search_capacity_full',None)!=full:
  engine._search_capacity_full=full
  engine.log('신규 탐색 중지 / 포지션 '+str(maximum)+'개 한도 · 보유 관리 계속' if full else '신규 탐색 재개 / 빈 포지션 자리 있음')
 if not full and (previous is True or getattr(engine,'_search_resume_requested',False)):
  engine._search_resume_requested=False
  if hasattr(engine,'channel_pending'):engine.channel_pending.clear()
  engine.universe.request_rescan()
  engine.free_ready=None
  due=engine.journal.data.setdefault('free_ai_next',{})
  due['ENTRY']=min(due.get('ENTRY',engine.api.now_ms()),engine.api.now_ms())
  engine.journal.save()
  engine.log('청산 후 재탐색 요청 / 이전 후보 폐기·새 시세 탐색 시작 / 예산·최종 주문 검사 유지')
 return full

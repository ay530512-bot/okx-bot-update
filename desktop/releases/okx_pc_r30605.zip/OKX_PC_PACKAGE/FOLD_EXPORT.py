"""Run locally in Termux after pausing entries and confirming a flat account."""
from contextlib import ExitStack
import fcntl
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import zipfile


def current_service(root, boot):
    choices = []
    for line in boot.read_text(encoding='utf-8').splitlines():
        if not line.startswith('exec '):
            continue
        for token in shlex.split(line):
            candidate = Path(token)
            if (candidate.name == 'phone_service.py' and candidate.parent.parent == root
                    and re.fullmatch(r'host-v\d+', candidate.parent.name)
                    and candidate.is_file() and not candidate.is_symlink()):
                choices.append(candidate)
    if len(choices) != 1:
        raise ValueError('Termux 자동 실행 파일에서 현재 실행기 위치를 찾지 못했습니다.')
    return choices[0]


def export(root, output, boot):
    if output.exists() or output.is_symlink():
        raise ValueError('Downloads의 예전 OKX_PC_TRANSFER.zip을 옮기거나 이름을 바꾼 뒤 다시 실행하세요.')
    if not output.parent.is_dir():
        raise ValueError('Termux에서 termux-setup-storage를 실행하고 저장 권한을 허용하세요.')
    service = current_service(root, boot)
    if input('신규 진입 중지와 거래소 보유·미체결·조건주문 0을 확인했다면 STOP 입력: ').strip() != 'STOP':
        raise ValueError('폴드 종료를 요청하지 않았습니다.')
    subprocess.run([sys.executable, '-B', str(service), '--root', str(root), '--stop'], check=True)
    with ExitStack() as locks:
        for name in ('phone_service.lock', 'phone_host.lock'):
            path = root / name
            if path.is_symlink():
                raise ValueError('실행 상태 파일을 확인하세요.')
            handle = locks.enter_context(path.open('ab'))
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise ValueError('폴드가 아직 종료 중입니다. 보호 관리가 끝났는지 확인하세요.') from None
        if json.loads((root / 'phone_service.json').read_text(encoding='utf-8')).get('enabled') is not False:
            raise ValueError('폴드 자동 실행 중지를 확인하지 못했습니다.')
        runtime = root / 'runtime-q2x'
        payload = {name: (runtime / name).read_bytes() for name in ('strategy_config.json', 'bot_state.json')}
        journal = json.loads(payload['bot_state.json'])
        intent = journal.get('entry_continuity732') or {}
        records = [journal.get('owned'), journal.get('extra_owned'), *journal.get('additional_owned', [])]
        if (intent.get('schema') != 1 or intent.get('requested') is not False or any(records)
                or journal.get('manual_closes716') or not journal.get('account')):
            raise ValueError('신규 진입 중지, 보유 없음, 계정 기록을 확인하지 못했습니다.')
        meta = dict(format=1, host=service.parent.name,
                    files={k: hashlib.sha256(v).hexdigest() for k, v in payload.items()})
        # Only configuration and the flat trading journal are exported.
        with tempfile.NamedTemporaryFile(dir=output.parent, suffix='.part', delete=False) as file:
            part = Path(file.name)
        try:
            with zipfile.ZipFile(part, 'w', zipfile.ZIP_DEFLATED) as archive:
                archive.writestr('transfer.json', json.dumps(meta))
                for name, raw in payload.items():
                    archive.writestr(name, raw)
            part.rename(output)
        finally:
            part.unlink(missing_ok=True)
    print('폴드 실행 및 부팅 자동 시작 중지 확인')
    print('Downloads의 OKX_PC_TRANSFER.zip을 본인 PC로 복사하세요.')


if __name__ == '__main__':
    try:
        home = Path.home()
        export((home / 'okx-phone').resolve(), home / 'storage' / 'downloads' / 'OKX_PC_TRANSFER.zip',
               home / '.termux' / 'boot' / '40-okx-home')
    except subprocess.CalledProcessError:
        print('폴드가 아직 종료되지 않았습니다. Termux의 위쪽 결과를 확인하세요.')
        raise SystemExit(1)
    except (OSError, ValueError) as error:
        print('진행 확인 · ' + str(error))
        raise SystemExit(1)

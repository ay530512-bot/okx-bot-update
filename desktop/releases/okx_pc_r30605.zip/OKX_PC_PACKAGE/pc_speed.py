"""Windows wake-ups for candidate completion and trade reconciliation."""
import threading
import time


class TradeWake(threading.Event):
    def __init__(self, engine):
        super().__init__()
        self.engine = engine
        self.lock = threading.Lock()
        self.last_position_wake = -float('inf')
        self.last_positions = {}

    def position(self, row):
        # Periodic mark/PnL pushes must not trigger private REST reads.
        key = row.get('instId'), row.get('posSide')
        value = tuple(row.get(k) for k in ('posId', 'pos', 'avgPx'))
        with self.lock:
            if self.last_positions.get(key) == value:
                return
            self.last_positions[key] = value
            stamp = time.monotonic()
            if stamp - self.last_position_wake >= .20:
                self.last_position_wake = stamp
                self.set()

    def wait(self, timeout=None):
        e = self.engine
        if timeout is not None and not e.recovering and not getattr(e, 'last_error', None):
            records = e.records()
            wick = getattr(e,'wick_entries',None)
            if (getattr(e, 'click_pending716', None) or (wick and wick.quote_symbols())
                    or any(r['phase'] in {'submitted', 'protecting', 'partial_closing', 'resizing', 'closing'}
                           for r in records)):
                timeout = min(timeout, .20)
            elif (e.enabled and len(records) < 4
                    and (getattr(e, 'channel_pending', None) or getattr(e, 'entry_candidate_leases', None))):
                timeout = min(timeout, .35)
        return super().wait(timeout)


def install(engine):
    wake = engine.command_wake = TradeWake(engine)
    original = engine.account_stream.callback

    def account_event(kind, row):
        original(kind, row)
        if kind == 'position' and row.get('instId') and row.get('posSide'):
            wake.position(row)

    engine.account_stream.callback = account_event

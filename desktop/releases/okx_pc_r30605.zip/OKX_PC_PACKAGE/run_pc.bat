@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
set "OKX_PC_VENV=%LOCALAPPDATA%\OKXTradingPC\venv"
if exist "%OKX_PC_VENV%\Scripts\python.exe" goto :dependencies
where py >nul 2>nul
if errorlevel 1 goto :use_python
py -3 -X utf8 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>nul
if errorlevel 1 goto :use_python
py -3 -X utf8 -m venv "%OKX_PC_VENV%"
if errorlevel 1 exit /b 1
goto :dependencies
:use_python
python -X utf8 -c "import sys; sys.exit(sys.version_info < (3, 10))" >nul 2>nul
if errorlevel 1 (
  echo Install Python 3.10 or newer for Windows. See START_HERE_KO.txt.
  exit /b 1
)
python -X utf8 -m venv "%OKX_PC_VENV%"
if errorlevel 1 exit /b 1
:dependencies
"%OKX_PC_VENV%\Scripts\python.exe" -X utf8 -c "import requests, dotenv, websocket, psutil" >nul 2>nul
if not errorlevel 1 goto :run
"%OKX_PC_VENV%\Scripts\python.exe" -X utf8 -m pip install --disable-pip-version-check -r "%~dp0requirements-pc.txt"
if errorlevel 1 exit /b 1
:run
"%OKX_PC_VENV%\Scripts\python.exe" -B -X utf8 "%~dp0pc_run.py" %*
exit /b %ERRORLEVEL%

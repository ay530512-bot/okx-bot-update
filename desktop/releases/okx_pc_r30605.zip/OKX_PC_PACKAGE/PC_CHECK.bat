@echo off
call "%~dp0run_pc.bat" check %*
pause

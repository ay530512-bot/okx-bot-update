"""Shadow comparisons at the decision's stated horizon using the same public tape."""
import json
import math
import sqlite3
import threading


HORIZON_MS = 3_600_000
FAST_HORIZON_MS = 900_000
GRACE_MS = 15_000
COST_PCT = 0.20


class FlowJournal:
    """Store each setup once and retain only the nearest horizon per symbol in memory."""

    def __init__(self, path):
        self.db = sqlite3.connect(path, timeout=3, check_same_thread=False)
        self._lock = threading.RLock()
        self.db.row_factory = sqlite3.Row
        with self.db:
            self.db.execute("""
                CREATE TABLE IF NOT EXISTS observations (
                    id INTEGER PRIMARY KEY,
                    symbol TEXT NOT NULL, source TEXT NOT NULL,
                    original_side INTEGER NOT NULL, anchor_ms INTEGER NOT NULL,
                    last_pivot_ms INTEGER NOT NULL, event_ms INTEGER NOT NULL,
                    signal_ms INTEGER NOT NULL, signal_price REAL NOT NULL,
                    due_ms INTEGER NOT NULL, horizon_ms INTEGER NOT NULL, chosen_side INTEGER NOT NULL,
                    cost_pct REAL NOT NULL, flow_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'open',
                    resolved_ms INTEGER, end_ms INTEGER, end_price REAL,
                    original_net_pct REAL, chosen_net_pct REAL,
                    UNIQUE(symbol,source,original_side,anchor_ms,last_pivot_ms,event_ms)
                )
            """)
            self.db.execute("""
                CREATE INDEX IF NOT EXISTS observations_due
                ON observations(symbol, due_ms) WHERE status = 'open'
            """)
        self.pending = dict(self.db.execute("""
            SELECT symbol, MIN(due_ms) FROM observations
            WHERE status = 'open' GROUP BY symbol
        """))

    def _refresh(self, symbol):
        due = self.db.execute("""
            SELECT MIN(due_ms) FROM observations WHERE symbol=? AND status='open'
        """, (symbol,)).fetchone()[0]
        if due is None:
            self.pending.pop(symbol, None)
        else:
            self.pending[symbol] = due

    def add(self, symbol, source, hit, flow):
        side, chosen = hit['side'], flow['side']
        price, ts = float(hit['price']), int(hit['ts'])
        if not symbol or not source or side not in (-1, 1) or chosen not in (-1, 0, 1):
            raise ValueError('invalid flow decision')
        if not math.isfinite(price) or price <= 0 or ts <= 0:
            raise ValueError('invalid flow signal price or time')
        anchor = int(hit.get('anchor_ms', ts))
        pivot = int(hit.get('last_pivot_ms') or 0)
        horizon = flow.get('horizon_ms', FAST_HORIZON_MS if source == 'fast5' else HORIZON_MS)
        if horizon not in (FAST_HORIZON_MS, HORIZON_MS):
            raise ValueError('invalid flow markout horizon')
        # A fast trigger can recur within the same larger setup.
        event = ts if source == 'fast5' else 0
        evidence = json.dumps(flow, ensure_ascii=False, allow_nan=False, separators=(',', ':'))
        with self._lock:
            with self.db:
                cur = self.db.execute("""
                    INSERT INTO observations (
                        symbol,source,original_side,anchor_ms,last_pivot_ms,event_ms,
                        signal_ms,signal_price,due_ms,horizon_ms,chosen_side,cost_pct,flow_json
                    ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT (
                        symbol,source,original_side,anchor_ms,last_pivot_ms,event_ms
                    ) DO NOTHING
                """, (symbol, source, side, anchor, pivot, event, ts, price,
                      ts+horizon, horizon, chosen, COST_PCT, evidence))
            self._refresh(symbol)
        return bool(cur.rowcount)

    def finish(self, symbol, ts, price):
        """Observe an ordered public print. Mark late horizons missing, never backfill."""
        ts = int(ts)
        if price is not None:
            price = float(price)
            if not math.isfinite(price) or price <= 0:
                price = None
        resolved = []
        with self._lock:
            nearest = self.pending.get(symbol)
            if nearest is None or ts < nearest:
                return resolved
            with self.db:
                self.db.execute('BEGIN IMMEDIATE')
                rows = self.db.execute("""
                    SELECT id,source,original_side,signal_ms,signal_price,due_ms,horizon_ms,chosen_side,cost_pct
                    FROM observations WHERE symbol=? AND status='open' AND due_ms<=?
                    ORDER BY due_ms,id
                """, (symbol, ts)).fetchall()
                for row in rows:
                    if ts > row['due_ms']+GRACE_MS:
                        self.db.execute("""
                            UPDATE observations SET status='missing',resolved_ms=? WHERE id=?
                        """, (ts, row['id']))
                        continue
                    if price is None:
                        continue
                    move = 100*(price/row['signal_price']-1)
                    original = row['original_side']*move-row['cost_pct']
                    side = row['chosen_side']
                    chosen = side*move-row['cost_pct'] if side else 0.
                    self.db.execute("""
                        UPDATE observations SET status='done',resolved_ms=?,end_ms=?,end_price=?,
                            original_net_pct=?,chosen_net_pct=? WHERE id=?
                    """, (ts, ts, price, original, chosen, row['id']))
                    resolved.append(dict(symbol=symbol, source=row['source'],
                                         signal_ms=row['signal_ms'], horizon_ms=row['horizon_ms'],
                                         original_side=row['original_side'], original_net_pct=original,
                                         chosen_side=side, chosen_net_pct=chosen))
            self._refresh(symbol)
        return resolved

    def expire(self, now):
        """Expire stale horizons on the session timer, even for silent instruments."""
        now = int(now)
        with self._lock:
            stale = [sym for sym, due in self.pending.items() if due+GRACE_MS < now]
            if not stale:
                return 0
            count = 0
            with self.db:
                for sym in stale:
                    cur = self.db.execute("""
                        UPDATE observations SET status='missing',resolved_ms=?
                        WHERE symbol=? AND status='open' AND due_ms<?
                    """, (now, sym, now-GRACE_MS))
                    count += cur.rowcount
            for sym in stale:
                self._refresh(sym)
            return count

    def close(self):
        with self._lock:
            self.db.close()

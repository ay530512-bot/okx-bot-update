"""A completed five-minute retest of a recent local extreme, symmetric by side."""
from math import isfinite

FIVE = 300_000
ATR_BARS = 14
LOOKBACK = 12


def fast_setup(five_rows, tick):
    """Return the latest defended level before any information from the next bar.

    The first extreme must have a closed candle on each side. The second low
    can stay above the old low by up to one quarter of the first bar's ATR.
    A short uses the identical logic in reflected price coordinates.
    """
    if not isinstance(tick, (int, float)) or not isfinite(tick) or tick <= 0:
        return None
    rows = list(five_rows)[-(LOOKBACK + ATR_BARS + 2):]
    if len(rows) < ATR_BARS + 4:
        return None
    for i, row in enumerate(rows):
        if len(row) < 5 or not all(isfinite(v) for v in row[:5]):
            return None
        t, op, high, low, close = row[:5]
        if t % FIVE or not 0 < low <= min(op, close) <= max(op, close) <= high:
            return None
        if i and t != rows[i-1][0] + FIVE:
            return None

    _, op, high, low, close = rows[-1][:5]
    if close == op:
        return None
    side = 1 if close > op else -1
    # In these coordinates the candidate always defends a floor.
    floors = [r[3] if side == 1 else -r[2] for r in rows]
    ceilings = [r[2] if side == 1 else -r[3] for r in rows]
    prev_close = side * rows[-2][4]
    price = side * close
    second = floors[-1]
    epsilon = tick * 1e-6
    if (price < prev_close + tick - epsilon or price <= (ceilings[-1] + second)/2
            or second > floors[-2] + epsilon):
        return None

    last = len(rows) - 1
    for i in range(last - 2, max(last - LOOKBACK, ATR_BARS) - 1, -1):
        first = floors[i]
        if not (first < floors[i-1] - epsilon and first < floors[i+1] - epsilon):
            continue
        between = floors[i+1:last]
        if min(between) < first - epsilon:
            continue
        total_range = sum(max(rows[j][2], rows[j-1][4]) - min(rows[j][3], rows[j-1][4])
                          for j in range(i-ATR_BARS+1, i+1))
        atr = total_range / ATR_BARS
        if atr <= 0 or second < first - epsilon or second > first + max(tick, atr/4) + epsilon:
            continue
        if max(ceilings[i+1:last]) < first + max(2*tick, atr/2) - epsilon:
            continue
        return dict(side=side, anchor_ms=rows[i][0], first=side*first,
                    second=side*second, anchor_atr=atr, price=close, bars=last-i,
                    trigger_ms=rows[-1][0]+FIVE)
    return None

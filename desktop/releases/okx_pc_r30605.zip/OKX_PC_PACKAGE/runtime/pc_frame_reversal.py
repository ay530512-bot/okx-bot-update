"""Completed higher-timeframe context and ordered minute-level reversal confirmation."""
from okx_band_flow import atr
from okx_pattern15 import band

MINUTE = 60000
QUARTER = 15*MINUTE
HOUR = 4*QUARTER

def candidate(rows,tick):
    if len(rows)<32:
        return None
    t,o,h,l,c,v=rows[-1]
    avg=sum(r[5] for r in rows[-21:-1])/20
    if avg<=0 or h-l<4*tick or v<2*avg or c==o:
        return None
    side=-1 if c>o else 1
    wick=(h-c if side<0 else c-l)/(h-l)
    lower,_,upper=band(rows,len(rows)-1)
    if wick<.20 or (h<upper if side<0 else l>lower):
        return None
    end=(t+QUARTER)//HOUR*HOUR
    hours=[r for r in rows[-12:] if end-HOUR<=r[0]<end]
    if [r[0] for r in hours]!=list(range(end-HOUR,end,QUARTER)):
        return None
    return dict(side=side,anchor_ms=t,first=l if side==1 else h,anchor_atr=atr(rows),
                volume_ratio=v/avg,wick_fraction=wick,hour_agrees=side*(hours[-1][4]-hours[0][1])>0)

def confirmation(setup,minutes,tick):
    if len(minutes)<5:
        return None
    t,o,h,l,c=minutes[-1]
    side=setup['side']
    hour_agrees=setup['hour_agrees']
    end=(t+MINUTE)//(5*MINUTE)*(5*MINUTE)
    five=[r for r in minutes if end-5*MINUTE<=r[0]<end]
    if len(five)!=5 or five[0][0]!=end-5*MINUTE:
        return None
    # A countertrend entry requires a break of the preceding five-minute extreme.
    if side*(five[-1][4]-five[0][1])<=0:
        return None
    prior=[r for r in minutes if end-10*MINUTE<=r[0]<end-5*MINUTE]
    if not hour_agrees and (len(prior)!=5 or side*(five[-1][4]-(max(r[2] for r in prior) if side==1 else min(r[3] for r in prior)))<tick*.999999):
        return None
    prev=minutes[-2]
    trigger=prev[2] if side==1 else prev[3]
    if side*(c-o)<=0 or side*(c-trigger)<tick*.999999:
        return None
    return trigger

class FrameWatch:
    def __init__(self,tick):
        self.tick=tick
        self.arm(None)

    def arm(self,setup):
        self.setup=setup
        self.minutes=[]
        self.live=None
        self.last_id=None

    def trade(self,ts,tid,p,covered):
        s=self.setup
        if not s:return None
        start=s['anchor_ms']+QUARTER
        if not start<=ts<start+QUARTER:return None
        if s['side']*(p-s['first']) < -self.tick*.5:
            self.arm(None)
            return None
        if self.last_id is not None and tid!=self.last_id+1:
            self.arm(None)
            return None
        self.last_id=tid
        t=ts//MINUTE*MINUTE
        if self.live and t==self.live[0]:
            self.live[2]=max(self.live[2],p)
            self.live[3]=min(self.live[3],p)
            self.live[4]=p
            return None
        if self.live and t!=self.live[0]+MINUTE:
            self.minutes=[]
        elif self.live:
            if self.complete:self.minutes.append(self.live)
            level=confirmation(s,self.minutes,self.tick)
            if level is not None and s['side']*(p-level)>=self.tick*.999999:
                self.arm(None)
                return dict(s,frame_trigger=level,ts=ts,trade_id=tid,price=p,second=s['first'],bars=1)
        self.complete=bool(self.live or covered)
        self.live=[t,p,p,p,p]
        return None

class FrameJournal:
    """One local observation per symbol, side and setup candle, including missed outcomes."""
    def __init__(self,path):
        import sqlite3
        self.db=sqlite3.connect(path,timeout=1,check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS signals(symbol TEXT, side INTEGER, anchor INTEGER, ts INTEGER, price REAL, evidence TEXT, end_ts INTEGER, end_price REAL, net_pct REAL, status TEXT, PRIMARY KEY(symbol,side,anchor))')
        self.pending={}
        for sym,side,anchor,t,p in self.db.execute("SELECT symbol,side,anchor,ts,price FROM signals WHERE status='open'"):
            self.pending.setdefault(sym,[]).append((side,anchor,t,p))

    def add(self,sym,h):
        import json
        key=(sym,h['side'],h['anchor_ms'],h['ts'],h['price'])
        with self.db:
            cur=self.db.execute("INSERT OR IGNORE INTO signals VALUES(?,?,?,?,?,?,NULL,NULL,NULL,'open')",(*key,json.dumps(h)))
        if cur.rowcount:
            self.pending.setdefault(sym,[]).append(key[1:])
        return bool(cur.rowcount)

    def finish(self,sym,ts,price):
        import json
        results=[]
        for item in tuple(self.pending.get(sym,())):
            side,anchor,t,p=item
            if ts<t+QUARTER:continue
            lost=ts>t+QUARTER+15000 or price is None
            net=None if lost else 100*(side*(price/p-1)-.002)
            with self.db:
                self.db.execute("UPDATE signals SET end_ts=?,end_price=?,net_pct=?,status=? WHERE symbol=? AND side=? AND anchor=?",
                                (ts,None if lost else price,net,'missing' if lost else 'done',sym,side,anchor))
            if not lost:
                evidence=self.db.execute("SELECT evidence FROM signals WHERE symbol=? AND side=? AND anchor=?",(sym,side,anchor)).fetchone()
                results.append((side,anchor,net,json.loads(evidence[0]).get("frame_chart")))
            self.pending[sym].remove(item)
        if not self.pending.get(sym):self.pending.pop(sym,None)
        return results

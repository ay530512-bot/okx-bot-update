"""Indicator and confirmed price-pattern context available at a two-wick reaction."""
from pc_wick_alert import STEP

CONVERSION, BASE, SPAN, SHIFT = 9, 26, 52, 26
MIN_BARS = SPAN + SHIFT - 1
PATTERN_LOOKBACK = 48
RECENT_BREAK = 6


def midpoint(rows, count):
    section = rows[-count:]
    return (max(r[2] for r in section)+min(r[3] for r in section))/2


def visible_spans(closed):
    # At bucket k, the last completed candle is k-1. The plotted spans come from k-26.
    if len(closed)<MIN_BARS or closed[-1][0]-closed[-MIN_BARS][0]!=(MIN_BARS-1)*STEP:
        return None
    end = len(closed)-SHIFT+1
    past = closed[end-SPAN:end]
    return (midpoint(past,CONVERSION)+midpoint(past,BASE))/2,midpoint(past,SPAN)


def rsi_pair(rows):
    if len(rows)<16:
        return None
    moves = [b[4]-a[4] for a,b in zip(rows,rows[1:])]
    up = sum(max(x,0.) for x in moves[:14])/14
    down = sum(max(-x,0.) for x in moves[:14])/14
    def value():
        return 100*up/(up+down) if up+down else 50.
    previous = value()
    for x in moves[14:]:
        previous = value()
        up = (13*up+max(x,0.))/14
        down = (13*down+max(-x,0.))/14
    return dict(previous=previous,latest=value())


def pivots(rows):
    points = []
    for i in range(2,len(rows)-2):
        neighbors = (rows[i-2],rows[i-1],rows[i+1],rows[i+2])
        high = all(rows[i][2]>r[2] for r in neighbors)
        low = all(rows[i][3]<r[3] for r in neighbors)
        if high == low:
            continue
        kind = 1 if high else -1
        price = rows[i][2 if high else 3]
        if points and points[-1][1] == kind:
            if kind*(price-points[-1][2]) > 0:
                points[-1] = (i,kind,price)
        else:
            points.append((i,kind,price))
    return points


def line(a,b,i):
    return a[2] + (b[2]-a[2])*(i-a[0])/(b[0]-a[0])


def closed_break(rows, last_pivot, a, b, direction, tick):
    # The rightmost pivot itself needs two subsequent closes for confirmation.
    start = max(last_pivot+2,len(rows)-RECENT_BREAK)
    for i in range(start,len(rows)):
        before = direction*(rows[i-1][4]-line(a,b,i-1))
        now = direction*(rows[i][4]-line(a,b,i))
        if before <= 0 and now >= tick*(1-1e-6) and all(
                direction*(rows[k][4]-line(a,b,k))>0 for k in range(i+1,len(rows))):
            return i
    return None


def head_shoulders(rows, points, atr, tick):
    results = []
    for end in range(5,len(points)+1):
        left, neck1, head, neck2, right = points[end-5:end]
        sign = head[1]
        width1, width2 = head[0]-left[0], right[0]-head[0]
        prominence = min(sign*(head[2]-p[2]) for p in (left,right))
        lead = rows[max(0,left[0]-8):left[0]]
        if (min(width1,width2)*2 < max(width1,width2) or len(lead)<3
                or prominence < max(2*tick,.25*atr)
                or abs(left[2]-right[2]) > max(tick,.5*prominence)
                or sign*(left[2]-lead[0][4]) < atr):
            continue
        direction = -sign
        i = closed_break(rows,right[0],neck1,neck2,direction,tick)
        if i is not None and all(sign*(r[2 if sign==1 else 3]-head[2])<=0 for r in rows[right[0]+1:i+1]):
            results.append(dict(kind='inverse_hs' if direction==1 else 'hs',side=direction,
                                confirmed_ms=rows[i][0]+STEP,level=line(neck1,neck2,i)))
    return results


def diamonds(rows, points, atr, tick):
    results = []
    for end in range(6,len(points)+1):
        group = points[end-6:end]
        highs = [p for p in group if p[1]==1]
        lows = [p for p in group if p[1]==-1]
        width = highs[1][2]-lows[1][2]
        protrusion = max(tick,.15*atr)
        if (width < atr or min(highs[1][2]-max(highs[0][2],highs[2][2]),
                               min(lows[0][2],lows[2][2])-lows[1][2]) < protrusion):
            continue
        for side, edge in ((1,highs),(-1,lows)):
            i = closed_break(rows,group[-1][0],edge[1],edge[2],side,tick)
            if i is not None and line(highs[1],highs[2],i)>line(lows[1],lows[2],i):
                results.append(dict(kind='diamond',side=side,confirmed_ms=rows[i][0]+STEP,
                                    level=line(edge[1],edge[2],i)))
    return results


def context(rows, hit, tick):
    """Rows are closed; evaluate the cloud displayed over the current reaction bucket."""
    bucket = hit['ts']//STEP*STEP
    closed = tuple(r for r in rows if r[0]<bucket)
    start = len(closed)-1
    while start>0 and closed[start-1][0]+STEP==closed[start][0]:
        start -= 1
    closed = closed[start:] if closed and closed[-1][0]+STEP==bucket else ()
    result = dict(closed_bars=len(closed),cloud=None,rsi=rsi_pair(closed[-90:]),patterns=[])
    if len(closed)>=PATTERN_LOOKBACK:
        recent = closed[-PATTERN_LOOKBACK:]
        points = pivots(recent)
        matches = head_shoulders(recent,points,hit['anchor_atr'],tick)+diamonds(recent,points,hit['anchor_atr'],tick)
        for key in sorted({(p['kind'],p['side']) for p in matches}):
            result['patterns'].append(max((p for p in matches if (p['kind'],p['side'])==key),
                                          key=lambda p:p['confirmed_ms']))
    spans = visible_spans(closed)
    if spans is None:
        return result
    bottom,top = sorted(spans)
    conversion,base = midpoint(closed,CONVERSION),midpoint(closed,BASE)
    price = hit['price']
    position = 1 if price>top else -1 if price<bottom else 0
    tk = 1 if conversion>base else -1 if conversion<base else 0
    result['cloud'] = dict(bottom=bottom,top=top,conversion=conversion,base=base,position=position,tk=tk)
    return result


def adverse_momentum(evidence, side):
    cloud,rsi = evidence['cloud'],evidence['rsi']
    if not cloud or not rsi or cloud['position']!=-side or cloud['tk']!=-side:
        return False
    extreme = rsi['latest']<=30 if side==1 else rsi['latest']>=70
    return extreme and side*(rsi['latest']-rsi['previous'])<0


def describe(evidence):
    cloud,rsi = evidence['cloud'],evidence['rsi']
    if cloud:
        position = {-1:'아래',0:'안',1:'위'}[cloud['position']]
        relation = {-1:'전환선 < 기준선',0:'전환선 = 기준선',1:'전환선 > 기준선'}[cloud['tk']]
        trend = f'가격은 구름 {position} · {relation}'
    else:
        trend = '일목구름 계산용 완료봉 대기'
    if rsi:
        change = rsi['latest']-rsi['previous']
        trend += f" · RSI {rsi['latest']:.1f} ({change:+.1f})"
    names = {'hs':'헤드앤숄더','inverse_hs':'역헤드앤숄더','diamond':'다이아몬드'}
    patterns = [names[p['kind']]+(' 상향 돌파 ' if p['side']==1 else ' 하향 이탈 ')+format(p['level'],'.8g')
                for p in evidence['patterns']]
    pattern = ', '.join(patterns) if patterns else ('최근 6봉 확정 패턴 없음'
              if evidence['closed_bars']>=PATTERN_LOOKBACK else '패턴 확인용 완료봉 대기')
    return trend,pattern

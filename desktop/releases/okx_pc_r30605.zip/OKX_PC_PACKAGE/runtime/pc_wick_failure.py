"""PC common-slot entry after a failed relaxed two-wick long."""
import functools
import math

from okx_core import BotError
from okx_band_flow import rows
import okx_channel701 as channel
from okx_entry725 import setup as baseline
import okx_two_wick732 as original
from pc_wick20_setup import setup

MINUTE = 60_000
WINDOW = 10 * MINUTE
ROUTE = 'double_wick20_failed_long'


def arm(bars, hourly, end, selected_status):
    if selected_status in {'both_same', 'baseline_only', 'conflict'}:
        return None
    proof = setup(bars, hourly)
    if proof and proof['action'] == 'LONG' and proof['context_volume'] >= 1.35:
        return dict(end=end, reference=proof['reference'], atr=proof['atr'],
                    long_stop=proof['structural_stop'])
    return None


def candle_rows(e, symbol, frame, limit, now):
    raw = e.api.public('/api/v5/market/candles', instId=symbol, bar=frame, limit=limit)
    if frame != '1m':
        return rows(raw, frame, now)
    result = []
    for r in raw:
        if len(r) < 9:
            raise BotError('1분봉 자료 형식 오류')
        t = int(r[0])
        if t % MINUTE or t > now or (t+MINUTE <= now and r[8] != '1'):
            continue
        o,h,l,c,v = map(float,r[1:6])
        if not all(map(math.isfinite,(o,h,l,c,v))) or not 0<l<=min(o,c)<=max(o,c)<=h or v<0:
            raise BotError('1분봉 수치 오류')
        result.append([t,o,h,l,c,v])
    if len({r[0] for r in result}) != len(result):
        raise BotError('1분봉 시각 중복')
    return sorted(result)


def failure(armed, one, now):
    end = armed['end']
    expected = end
    for r in one:
        if r[0] < end:
            continue
        if r[0] != expected or r[0]+MINUTE > min(now, end+WINDOW):
            break
        if r[3] <= armed['long_stop']:
            break
        if r[4] <= armed['reference'] - .5*armed['atr']:
            return r[0]+MINUTE, r[4]
        expected += MINUTE
    return None


def make_signal(e, symbol, armed, failed, now):
    from okx_pattern15 import leverage
    start, reference = failed
    proof = dict(action='SHORT', reference=reference, atr=armed['atr'],
                 structural_stop=reference+2*armed['atr'], confirmation_ms=start-channel.STEP,
                 route721=ROUTE, channel_high=armed['reference'], channel_low=armed['long_stop'],
                 arm=armed, failed_ms=start, evidence704={'score':0})
    p = dict(symbol=symbol, asset_category='1', price=reference, entry_setups=[proof],
             frames={'15m':dict(ma={}, bollinger={}, analysis={})})
    s = channel.make_signal({'action':'SHORT'}, p, e.cfg, now)
    assert s['valid_from_ms'] == start
    s.update(setup_frame='15m', execution_frame='1m', leverage=leverage(symbol),
             reason='두꼬리 20% 롱 실패 확인 · 숏')
    return s


def collect(e, packets, market_rows):
    # Packet work is already memoized by completed 15m candle. Network reads
    # are limited to qualified symbols, at most once per completed minute.
    now=e.api.now_ms()
    minute=now//MINUTE
    if getattr(e,'pc_wick_minute',None) != minute:
        e.pc_wick_minute, e.pc_wick_minutes = minute, {}
    by_symbol = {r['symbol']:r for r in market_rows}
    for symbol,p in packets.items():
        armed=p.get('pc_wick_arm')
        existing=e.channel_pending.get(symbol)
        if not armed or not armed['end']+MINUTE <= now <= armed['end']+WINDOW+90_000:
            continue
        if existing:
            continue
        try:
            row=by_symbol[symbol]
            if float(row['instrument'].get('lever') or 0)<3:
                continue
            if symbol not in e.pc_wick_minutes:
                e.pc_wick_minutes[symbol] = None
                e.pc_wick_minutes[symbol] = candle_rows(e,symbol,'1m','16',now)
            candles=e.pc_wick_minutes[symbol]
            if not candles:
                continue
            found=failure(armed,candles,now)
            if not found or not found[0] <= now <= found[0]+90_000:
                continue
            from pc_sizing import legacy_signal
            s=make_signal(e,symbol,armed,found,now)
            legacy_signal(s,channel.closed(row.get('live_frames',{}).get('15m',[]),now),row['instrument'])
            if symbol+':'+s['signal_id'] not in e.journal.data.get('seen_signals',{}):
                e.channel_pending[symbol]=s
        except (BotError,ValueError,KeyError,TypeError):
            continue


def install():
    import phone_trend_slot as trend
    check=channel.check_entry

    @functools.wraps(check)
    def validate(e,s,price):
        proof=(s.get('decision_record') or {}).get('volume_wick_proof',{})
        if proof.get('route721')!=ROUTE:
            return check(e,s,price)
        trend.require_slot(e,s)
        now=e.api.now_ms()
        if s.get('action')!='SHORT' or not s['valid_from_ms'] <= now <= s['expires_ms']:
            raise BotError('두꼬리 실패 숏 신호 만료')
        sym=s['symbol']; armed=proof['arm']
        b=channel.closed(candle_rows(e,sym,'15m','300',now),armed['end'],required=241)
        h=candle_rows(e,sym,'1H','100',now)
        _, status=original.combine(baseline(b,h,variant='mild726'), original.setup(b,h))
        actual=arm(b,h,armed['end'],status)
        candles=candle_rows(e,sym,'1m','16',now)
        if (actual!=armed or failure(armed,candles,now)!=(proof['failed_ms'],proof['reference'])
                or any(bar[2]>=proof['structural_stop'] for bar in candles if bar[0]>=proof['failed_ms'])
                or not math.isfinite(price) or not channel.window(proof,price)):
            raise BotError('두꼬리 실패 숏: 원래 완료봉 신호 변경 또는 가격·손절 범위 이탈')
    channel.check_entry=validate

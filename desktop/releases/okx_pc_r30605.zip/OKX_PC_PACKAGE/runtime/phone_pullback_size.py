"""Validate the active PC allocation module and its unwrapped entry point."""
import hashlib
import json
from pathlib import Path

def risk_source_hash():
    pins = Path(__file__).with_name('phone_sources.json')
    return json.loads(pins.read_text(encoding='utf-8'))['files']['okx_risk732.py']


def install(source):
    import okx_risk732 as policy
    path = Path(source) / 'okx_risk732.py'
    if (path.is_symlink() or not path.is_file()
            or Path(policy.__file__).resolve() != path.resolve()):
        raise ValueError('PC 주문량 규칙 · Q2X 원본 경로 불일치')
    if hashlib.sha256(path.read_bytes()).hexdigest() != risk_source_hash():
        raise ValueError('PC 주문량 규칙 · Q2X 원본 해시 불일치')
    if getattr(policy.cap_plan, 'phone_pullback_quarter_v120', False):
        raise ValueError('이전 1/16 주문량 규칙이 남아 있습니다. 새 실행기로 재시작 필요')
    if Path(policy.cap_plan.__code__.co_filename).resolve() != path.resolve():
        raise ValueError('PC 주문량 함수 경로 불일치')
    # Retain the original function object, including reserve/lot/depth checks.

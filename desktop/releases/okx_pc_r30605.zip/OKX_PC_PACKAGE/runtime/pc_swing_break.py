"""Three confirmed extrema followed by a trade beyond the last intervening swing."""
from okx_band_flow import atr

RADIUS = 6


def setup(rows, side, window, tick):
    n = len(rows)
    end = n - RADIUS - 1
    if end < 2 * RADIUS + 2:
        return None
    def low(i):
        return side * rows[i][3 if side == 1 else 2]
    def high(i):
        return side * rows[i][2 if side == 1 else 3]
    def pivot(i):
        value = low(i)
        return all(value < low(j) for j in range(i-RADIUS,i+RADIUS+1) if j != i)
    if not pivot(end):
        return None
    previous = next((i for i in range(end-1,max(RADIUS-1,end-window-1),-1) if pivot(i)),None)
    if previous is None or not any(pivot(i) for i in range(previous-1,RADIUS-1,-1)):
        return None
    level = max(high(i) for i in range(previous+1,end))
    if max(high(i) for i in range(end,n)) >= level+tick*.999999:
        return None
    return dict(anchor_ms=rows[previous][0],last_pivot_ms=rows[end][0],first=side*low(previous),
                second=side*low(end),neckline=side*level,side=side,anchor_atr=atr(rows))


def invalid(hit, row, step, window, tick):
    side = hit['side']
    extreme = row[3 if side==1 else 2]
    return (row[0]-hit['last_pivot_ms'] > window*step or
            side*(extreme-hit['second']) < -tick*.5)

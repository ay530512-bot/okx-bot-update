"""Choose a primary chart from this contract's completed five-minute activity."""
import math
from statistics import median, quantiles

MINUTE = 60_000
FIVE = 5 * MINUTE
QUARTER = 15 * MINUTE
HOUR = 60 * MINUTE
COST_PCT = 0.20


def _history(rows, stamp, step, limit):
    expected = (int(stamp)//step-1)*step
    closed = []
    for row in rows or ():
        if not isinstance(row, (tuple, list)) or not row or not isinstance(row[0], (float, int)):
            return [], 'invalid_bar'
        if row[0] <= expected:
            closed.append(row)
    closed=closed[-limit:]
    if not closed:
        return [], 'insufficient_history'
    if closed[-1][0] != expected:
        return [], 'stale_history'
    for i in range(len(closed)-1,0,-1):
        if closed[i][0]-closed[i-1][0]!=step:
            closed=closed[i:]
            break
    for row in closed:
        if len(row)<6 or not all(isinstance(v,(float,int)) and math.isfinite(v) for v in row[1:6]):
            return [], 'invalid_bar'
        _,op,high,low,close,volume=row[:6]
        if not 0<low<=min(op,close)<=max(op,close)<=high or volume<0:
            return [], 'invalid_bar'
    return closed, None


def _range(row, prev_close):
    return max(row[2],prev_close)-min(row[3],prev_close)


def pace(five_rows, signal_ms):
    """Compare latest 3 ranges and turnover to the previous 36 complete bars."""
    bars,error=_history(five_rows,signal_ms,FIVE,40)
    if error or len(bars)<40:
        return dict(pace='unknown',reason=error or 'insufficient_history',fast_bars=None)
    distances=[100*_range(bars[i],bars[i-1][4])/bars[i-1][4] for i in range(1,40)]
    turnovers=[b[4]*b[5] for b in bars[1:]]
    range_cut=quantiles(distances[:-3],n=4,method='inclusive')[2]
    turn_cut=median(turnovers[:-3])
    hits=sum(r>range_cut and v>turn_cut for r,v in zip(distances[-3:],turnovers[-3:]))
    return dict(pace='fast' if hits>=2 else 'normal',reason='symbol_relative',fast_bars=hits,
                range_q75_pct=round(range_cut,5),recent_ranges_pct=[round(x,5) for x in distances[-3:]],
                turnover_median=turn_cut,recent_turnovers=turnovers[-3:])


def _efficiency(bars,i,n):
    travel=sum(_range(bars[j],bars[j-1][4]) for j in range(i-n+1,i+1))
    return (bars[i][4]-bars[i-n][4])/travel if travel else 0.


def _location(bar):
    return (bar[4]-bar[3])/(bar[2]-bar[3]) if bar[2]>bar[3] else .5


def _volume_share(bars,i):
    current=bars[i][5]
    typical=median(row[5] for row in bars[i-16:i])
    return current/(current+typical) if current+typical else .5


def _hours(quarters):
    hours=[]
    for i in range(3,len(quarters)):
        last=quarters[i]; first=quarters[i-3]
        if (last[0]+QUARTER)%HOUR==0 and last[0]-first[0]==3*QUARTER:
            group=quarters[i-3:i+1]
            hours.append((first[0],first[1],max(r[2] for r in group),min(r[3] for r in group),
                          last[4],sum(r[5] for r in group)))
    return hours


def _match(bars, stride, state):
    now=len(bars)-1
    current=state(now)
    if current is None:
        return None
    matches=[]
    for i in range(now-stride, max(now-stride*48-1,15), -stride):
        earlier=state(i)
        if earlier is None:
            continue
        distance=sum((a-b)**2 for a,b in zip(current.values(),earlier.values()))
        move=100*(bars[i+stride][4]/bars[i][4]-1)
        matches.append((distance,-i,move))
    if len(matches)<24:
        return None
    matches.sort()
    k=round(math.sqrt(len(matches)))
    move=median(r[2] for r in matches[:k])
    return len(matches),k,move,current


def with_micro(flow, minute_rows, five_rows, signal_ms):
    """Use the newest complete 1m & 5m bodies as a secondary check on fast flow."""
    def latest(source,step):
        expected=(int(signal_ms)//step-1)*step
        for row in reversed(source or ()):
            if isinstance(row,(tuple,list)) and len(row)>=5 and row[0]==expected:
                if all(isinstance(v,(int,float)) and math.isfinite(v) and v>0 for v in (row[1],row[4])):
                    return int(row[4]>row[1])-int(row[4]<row[1])
        return None
    one,five=latest(minute_rows,MINUTE),latest(five_rows,FIVE)
    result=dict(flow,base_side=flow['side'],micro_state='unavailable')
    if one is None or five is None:
        return result
    result.update(micro_state='checked',minute_side=one,five_minute_side=five)
    if flow['pace']=='fast' and flow['side'] and one==five==-flow['side']:
        result.update(side=0,regime='wait',reason='micro_opposed',micro_state='both_opposed')
    return result


def assess_market(quarter_rows, five_rows, hour_rows, signal_ms, wick_side, minute_rows=None):
    """Pass ascending (open_ms,open,high,low,close,volume) rows for one contract.

    Five-minute analogs have a 15m response horizon. In normal flow the state
    combines 15m and completed exchange-hour observations, with a 1h horizon.
    All historical response windows end by the signal and are nonoverlapping.
    """
    speed=pace(five_rows,signal_ms)
    fast=speed['pace']=='fast'
    out=dict(pace=speed['pace'],speed=speed,side=0,base_side=0,regime='wait',reason='insufficient_history',
             primary_frame='5m' if fast else '15m+1h' if speed['pace']=='normal' else None,
             hour_source=None,micro_state='unavailable',sample_count=0,analogs=0,forward_pct=None,
             cost_pct=COST_PCT,features={})
    if wick_side not in (-1,1):
        return dict(out,reason='invalid_side')
    if speed['pace']=='unknown':
        return dict(out,reason=speed['reason'])
    if fast:
        bars,error=_history(five_rows,signal_ms,FIVE,164)
        if error or len(bars)<89:
            return dict(out,reason=error or 'insufficient_history')
        def state(i):
            return dict(efficiency_20m=(_efficiency(bars,i,4)+1)/2,
                        efficiency_80m=(_efficiency(bars,i,16)+1)/2,
                        close_location_5m=_location(bars[i]),volume_share_5m=_volume_share(bars,i))
        result=_match(bars,3,state)
    else:
        bars,error=_history(quarter_rows,signal_ms,QUARTER,212)
        if error or len(bars)<116:
            return dict(out,reason=error or 'insufficient_history')
        if hour_rows:
            hours,error=_history(hour_rows,signal_ms,HOUR,56)
            if error:
                return dict(out,reason=error)
            # Match the completed-hour warm-up available from this same quarter snapshot.
            first_full_hour=((bars[0][0]+HOUR-1)//HOUR)*HOUR
            hours=[row for row in hours if row[0]>=first_full_hour]
            out['hour_source']='native'
        else:
            hours=_hours(bars)
            out['hour_source']='from_closed_quarters'
        hour_index={h[0]:j for j,h in enumerate(hours)}
        def joint(i):
            complete_hour=((bars[i][0]+QUARTER)//HOUR-1)*HOUR
            j=hour_index.get(complete_hour)
            if j is None or j<4:
                return None
            return dict(efficiency_1h=(_efficiency(bars,i,4)+1)/2,
                        efficiency_4h=(_efficiency(hours,j,4)+1)/2,
                        close_location_1h=_location(hours[j]),close_location_15m=_location(bars[i]),
                        volume_share_15m=_volume_share(bars,i))
        result=_match(bars,4,joint)
    if result is None:
        return out
    n,k,move,features=result
    side=1 if move>COST_PCT else -1 if move < -COST_PCT else 0
    out.update(side=side,reason='local_analogs' if side else 'no_edge',
               regime=('reversal' if side==wick_side else 'continuation') if side else 'wait',
               sample_count=n,analogs=k,forward_pct=round(move,5),
               features={key:round(2*v-1 if key.startswith('efficiency') else v,5) for key,v in features.items()})
    return with_micro(out,minute_rows,five_rows,signal_ms)

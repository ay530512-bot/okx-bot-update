"""Public 15-minute candles and ordered trades for two-wick notifications and entries."""
from collections import deque
from queue import Empty, Full, Queue
import json
import math
import threading
import time

from pc_wick_alert import HISTORY, STEP, MarketWicks, alert_text, candle
from pc_wick_chart import snapshot
from pc_flow_watch import FIVE, HISTORY5, FlowWatch, flow_text
from pc_extra_entries import MorningShort, morning
from pc_flow_journal import FlowJournal
from pc_frame_reversal import FrameJournal, FrameWatch, candidate
from pathlib import Path
import logging

WS_URL = 'wss://ws.okx.com/ws/v5/business'
CANDLES_URL = 'https://www.okx.com/api/v5/market/candles'
CANDLE = 'candle15m'
FIVE_CHANNEL = 'candle5m'
TRADES = 'trades-all'


class SymbolWatch:
    def __init__(self, tick):
        self.tick = tick
        self.rule = MarketWicks(float(tick))
        self.candidate_ends={}
        self.flow = FlowWatch()
        self.morning = MorningShort(tick)
        self.flow_queued=False
        self.flow_retry=0.
        self.frames = FrameWatch(float(tick))
        self.ready = False
        self.queued = False
        self.retry = 0.
        self.recent = {}
        self.forming = None
        self.early_trades = []
        self.ack_at = math.inf
        self.fresh_forming = False

    def invalidate(self):
        self.ready = False
        self.frames.arm(None)
        self.rule = MarketWicks(float(self.tick))
        self.early_trades.clear()
        self.fresh_forming = False

    def ws_bar(self, row, done):
        if done:
            self.recent[row[0]] = row
            self.recent = dict(sorted(self.recent.items())[-HISTORY:])
            if self.ready:
                if row[0] > self.rule.last_close+STEP:
                    self.invalidate()
                else:
                    if row[0]>self.rule.last_close:
                        self.rule.closed(row)
                        self.frames.arm(candidate(list(self.rule.long.rows),float(self.tick)))
        elif self.forming is None or row[0] >= self.forming[0]:
            self.forming = row
            self.fresh_forming = self.ack_at != math.inf
            if self.ready and row[0] == self.rule.last_close+STEP:
                self.rule.forming(row,self.fresh_forming)

    def seed(self, raw, now):
        closed = {}
        current = None
        for r in raw:
            row, done = candle(r)
            if done:
                closed[row[0]] = row
            elif current is None or row[0] > current[0]:
                current = row
        closed.update(self.recent)
        keys = sorted(t for t in closed if t+STEP <= now)[-HISTORY:]
        if not keys or keys[-1] != now//STEP*STEP-STEP:
            return False
        # A newly listed instrument may have less than the full history.
        start = len(keys)-1
        while start > 0 and keys[start-1]+STEP == keys[start]:
            start -= 1
        self.rule.seed([closed[k] for k in keys[start:]])
        # Prefer the most complete intrabar extrema across REST and WS.
        for forming in (current,self.forming):
            if forming and forming[0] == keys[-1]+STEP:
                self.rule.forming(forming,forming is self.forming and self.fresh_forming)
        self.ready = True
        return True

    def print(self, ts, trade_id, price, now):
        if not self.ready or self.ack_at == math.inf or ts > now+2000:
            return []
        bar = ts//STEP*STEP
        if bar == self.rule.last_close+2*STEP:
            # Candles and trades are separate channels; the new bar's trades
            # can precede confirmation of the preceding 15-minute close.
            if len(self.early_trades) >= 8000:
                self.invalidate()
            else:
                self.early_trades.append((ts,trade_id,price))
            return []
        hits = self.rule.trade(ts,trade_id,price,self.ack_at < bar)
        return hits if now-ts <= 5000 else []

    def take_buffered(self):
        if not self.early_trades or self.early_trades[0][0]//STEP*STEP > self.rule.last_close+STEP:
            return []
        values, self.early_trades = self.early_trades, []
        return values


class PublicWickFeed:
    def __init__(self, universe, notifier, cfg, now=None, entries=None):
        self.universe = universe
        self.notifier = notifier
        self.entries = entries
        self.config = cfg
        self.now = now or (lambda: int(time.time()*1000))
        self.stop_event = threading.Event()
        self.jobs = Queue(maxsize=400)
        self.completed = Queue(maxsize=450)
        self.generation = 0
        self.status = '텔레그램 연결 설정 필요'
        self.threads = []
        self.markets = {}
        self.seed_cache = {}
        self.flow_cache = {}
        self.contract_values = {}
        path = getattr(notifier,"path",None)
        self.flow_journal = None
        self.frame_journal = None
        if isinstance(path,Path):
            try:
                self.flow_journal = FlowJournal(path.with_name("symbol_flow_observations.db"))
                self.frame_journal = FrameJournal(path.with_name("frame_observations.db"))
            except Exception:
                logging.exception("복수 시간봉 기록 초기화 실패")

    def start(self):
        if self.entries is None and not self.notifier.enabled:
            return
        self.status = '15분봉 수신 대기'
        for target, name in ((self.bootstrap,'wick-history'),(self.run,'wick-public')):
            thread = threading.Thread(target=target, name=name, daemon=True)
            self.threads.append(thread)
            thread.start()

    def stop(self):
        self.stop_event.set()
        for thread in self.threads:
            thread.join(timeout=1.5)

    def instruments(self):
        from phone_trend_slot import permitted
        full = self.universe.full_market
        if full is None:
            return {}
        with self.universe.lock:
            rows = list(full.instruments.items())
        instruments = {}
        for symbol, row in rows:
            if permitted(dict(symbol=symbol,instrument=row),self.config):
                tick = row.get('tickSz')
                if tick and math.isfinite(float(tick)) and float(tick)>0:
                    instruments[symbol] = str(tick)
                    self.contract_values[symbol]=float(row.get('ctVal') or 0)
        return instruments

    def bootstrap(self):
        import requests
        with requests.Session() as http:
            while not self.stop_event.is_set():
                try:
                    generation, symbol, channel = self.jobs.get(timeout=.4)
                except Empty:
                    continue
                if generation != self.generation:
                    continue
                try:
                    data = http.get(CANDLES_URL,params=dict(instId=symbol,bar=channel.removeprefix('candle'),limit=str(1+(HISTORY if channel==CANDLE else HISTORY5))),
                                    timeout=(3,6)).json()
                    raw = data['data'] if data.get('code')=='0' else []
                except (ValueError,KeyError,requests.RequestException):
                    raw = []
                while not self.stop_event.is_set() and generation == self.generation:
                    try:
                        self.completed.put((generation,symbol,channel,raw),timeout=.5)
                        break
                    except Full:
                        continue
                self.stop_event.wait(.27)

    def history(self, now):
        for _ in range(24):
            try:
                generation, symbol, channel, raw = self.completed.get_nowait()
            except Empty:
                break
            state = self.markets.get(symbol)
            if generation != self.generation or state is None:
                continue
            if channel == FIVE_CHANNEL:
                state.flow_queued=False
                try:
                    rows=[row for row,done in (candle(r,FIVE) for r in raw) if done]
                    seeded=bool(rows) and state.flow.seed(rows,now)
                except (IndexError,TypeError,ValueError):
                    seeded=False
                if seeded:
                    state.morning.seed(state.flow.five)
                    self.flow_cache[symbol]=tuple(state.flow.five)
                else:
                    state.flow_retry=time.monotonic()+12
                continue
            state.queued = False
            try:
                good = bool(raw) and state.seed(raw,now)
            except (ValueError,TypeError,IndexError):
                good = False
            if good:
                self.seed_cache[symbol] = tuple(state.rule.long.rows)
            else:
                state.retry = time.monotonic()+12
        for symbol,state in self.markets.items():
            if not state.flow.ready and not state.flow_queued and state.flow_retry<=time.monotonic():
                try:self.jobs.put_nowait((self.generation,symbol,FIVE_CHANNEL))
                except Full:break
                state.flow_queued=True
            if state.ready or state.queued or state.retry > time.monotonic():
                continue
            try:
                self.jobs.put_nowait((self.generation,symbol,CANDLE))
            except Full:
                break
            state.queued = True

    def trade(self, symbol, state, ts, trade_id, price, now):
        fresh=(state.ack_at<=ts and 0<price<math.inf and -2000<=now-ts<=5000)
        if fresh and (state.flow.last_id is None or state.flow.last_id<trade_id):
            gap=state.flow.last_id is not None and trade_id!=state.flow.last_id+1
            if gap:
                state.flow.pending=None
                state.morning.detector.anchor=None
                state.morning.detector.reset_trade_feed()
                if self.entries:self.entries.invalidate(symbol,candle_step=FIVE)
            state.flow.minute_trade(ts,trade_id,price,state.ack_at)
            if self.flow_journal and symbol in self.flow_journal.pending:
                try:self.flow_journal.finish(symbol,ts,price)
                except Exception:logging.exception('종목 흐름 관찰 수익률 기록 실패')
            fast=state.flow.take(ts,trade_id,price,float(state.tick),state.ack_at)
            if fast:
                self.route_flow(symbol,state,fast,'fast5',tuple(state.flow.five))
            if self.entries:
                extra=state.morning.take(state.flow.five,ts,trade_id,price,state.flow.coverage_start)
                if extra:
                    self.entries.offer(symbol,extra,state.tick,tuple(state.flow.five))
        last_id = state.rule.long.last_id
        hits = state.print(ts,trade_id,price,now)
        if self.entries and math.isfinite(price) and price>0 and ts<=now+2000:
            detector, bar = state.rule.long, state.rule.chart_bar
            ordered = (last_id < trade_id == detector.last_id and ts == detector.last_ts
                       and now-ts <= 5000 and bar and bar[0] == ts//STEP*STEP)
            self.entries.invalidate(symbol,ts=ts,low=price,high=price,
                                    trade_id=trade_id,trade_bar=bar if ordered else None)
        if (self.frame_journal and state.ready and state.ack_at <= ts and last_id < trade_id == state.rule.long.last_id
                and state.rule.chart_bar and state.rule.chart_bar[0]==ts//STEP*STEP and -2000<=now-ts<=5000):
            try:
                journal=self.frame_journal
                if symbol in journal.pending:
                    for side,anchor,net,chart in journal.finish(symbol,ts,price):
                        msg=f"[복수 시간봉 모의 결과] {symbol} · 15분 후 비용 차감 {net:+.2f}% (왕복 비용 0.20% 가정)"
                        self.notifier.wick_result(msg,f"frame-out-{symbol}-{side}-{anchor}",chart=chart)
                h=state.frames.trade(ts,trade_id,price,state.ack_at < ts//60000*60000)
                if h:
                    self.evaluate_flow(symbol,state,h,'multiframe')
                    h["frame_chart"]=snapshot(symbol,dict(h,chart_bar=tuple(state.rule.chart_bar)),state.tick,state.rule.long.rows)
                if h and journal.add(symbol,h):
                    side='롱' if h['side']==1 else '숏'
                    trend='같은 방향' if h['hour_agrees'] else '반대 또는 중립'
                    msg=(f"[복수 시간봉 모의 관찰 · {side}] {symbol}\n"
                         f"15분 거래량 {h['volume_ratio']:.1f}배 · 꼬리 {100*h['wick_fraction']:.0f}%\n"
                         f"직전 1시간봉 {trend} · 5분 반전 · 1분 돌파 {h['frame_trigger']:g}\n"
                         "모의 신호 발생 · 15분 후 결과 자동 기록\n"+flow_text(h['symbol_flow']))
                    chart=h["frame_chart"]
                    self.notifier.wick_result(msg,f"frame-{symbol}-{h['anchor_ms']}-{side}",chart=chart)
            except Exception:
                logging.exception("복수 시간봉 모의 관찰 기록 실패")
        for hit in hits:
            source='swing' if 'neckline' in hit else 'classic'
            self.route_flow(symbol,state,hit,source,tuple(state.rule.long.rows))

    def evaluate_flow(self,symbol,state,hit,source):
        quarters=tuple(state.rule.long.rows) if state.ready else ()
        flow=state.flow.assess(quarters,hit)
        if source=='fast5' and not hit.get('complete_trade_feed'):
            flow=dict(flow,side=0,regime='wait',reason='incomplete_trade_feed',model_side=flow['side'])
        hit['symbol_flow']=flow
        added=True
        if self.flow_journal:
            try:added=self.flow_journal.add(symbol,source,hit,flow)
            except Exception:logging.exception('종목 흐름 판단 기록 실패')
        return added

    def route_flow(self,symbol,state,hit,source,bars):
        added=self.evaluate_flow(symbol,state,hit,source)
        fast=source=='fast5'
        if fast and (not self.entries or self.entries.mode not in ('symbol_flow','both')):
            if added:
                chart=snapshot(symbol,hit,state.tick,bars)
                msg=alert_text(symbol,hit,state.tick)+'\n모의 관찰 · '+flow_text(hit['symbol_flow'])
                key=f"flow5-paper-{symbol}-{hit['side']}-{hit['trigger_ms']}"
                self.notifier.wick_result(msg,key,chart=chart)
            return
        if self.entries:
            self.entries.offer(symbol,hit,state.tick,bars)
        else:
            chart=snapshot(symbol,hit,state.tick,bars)
            msg=alert_text(symbol,hit,state.tick)+'\n'+flow_text(hit['symbol_flow'])
            self.notifier.wick_alert(symbol,hit['side'],hit['anchor_ms'],hit['ts'],msg,chart)

    def closed_candidates(self,symbol,state,now):
        from pc_candidates import signals
        from pc_extra_entries import trend_side
        if not self.entries or not state.flow.ready or not state.flow.five:
            return
        step=FIVE if state.flow.fast else STEP
        rows=tuple(state.flow.five if step==FIVE else state.rule.long.rows)
        if not rows or (step==STEP and not state.ready):
            return
        end=rows[-1][0]+step
        if (state.flow.five[-1][0]+FIVE!=end or not 0<=now-end<=15000
                or state.candidate_ends.get(step,0)>=end):
            return
        state.candidate_ends[step]=end
        bias=trend_side(rows) if step==STEP else 0
        for hit in signals(rows,step,float(state.tick)):
            if step==STEP and hit['variant'] in ('breakout','pullback','retest','cloud') and bias!=hit['side']:
                continue
            self.entries.offer(symbol,hit,state.tick,rows)

    def message(self, obj, now):
        arg = obj.get('arg',{})
        symbol,channel = arg.get('instId'),arg.get('channel')
        if obj.get('event') == 'error':
            raise ValueError('OKX 공개 알림 구독 지연')
        state = self.markets.get(symbol)
        if state is None:
            return
        if obj.get('event') in ('subscribe','unsubscribe'):
            if channel == TRADES:
                if self.entries:
                    self.entries.invalidate(symbol)
                state.ack_at = now if obj['event']=='subscribe' else math.inf
                state.flow.reset_minutes()
                state.morning.detector.reset_trade_feed()
                state.rule.reset_trade_feed()
                state.frames.minutes.clear()
                state.frames.live = state.frames.last_id = None
                state.fresh_forming = False
                state.early_trades.clear()
                if state.forming is not None:
                    state.rule.forming(state.forming,False)
            return
        if channel == FIVE_CHANNEL:
            for raw in sorted(obj.get('data',[]),key=lambda r:int(r[0])):
                row,done=candle(raw,FIVE)
                if done:
                    if self.entries:
                        self.entries.validation.bar(symbol,row)
                    state.flow.closed(row,state.tick,now)
                    state.morning.closed(row)
                    if state.flow.ready:
                        self.flow_cache[symbol]=tuple(state.flow.five)
                        if self.entries and 0 <= now-row[0]-FIVE < FIVE and state.flow.five[-1][0] == row[0]:
                            from pc_candidates import reversal, reversal_frames
                            for step,bars in reversal_frames(self.flow_cache[symbol]):
                                hit = reversal(bars,float(state.tick),step)
                                if hit:
                                    self.entries.offer(symbol,hit,state.tick,bars)
                        self.closed_candidates(symbol,state,now)
                elif self.entries:
                    self.entries.invalidate(symbol,ts=min(now,row[0]+FIVE-1),low=row[3],high=row[2],candle_step=FIVE)
            return
        if channel == CANDLE:
            for raw in sorted(obj.get('data',[]),key=lambda r:int(r[0])):
                row,done = candle(raw)
                state.ws_bar(row,done)
                if self.entries:
                    if state.ready:
                        self.entries.invalidate(symbol,ts=min(now,row[0]+STEP-1),low=row[3],high=row[2],candle_step=STEP)
                    else:
                        self.entries.invalidate(symbol,candle_step=STEP)
                if done and state.ready:
                    self.seed_cache[symbol] = tuple(state.rule.long.rows)
                    for ts,trade_id,price in state.take_buffered():
                        self.trade(symbol,state,ts,trade_id,price,now)
                    self.closed_candidates(symbol,state,now)
                    if state.forming and state.forming[0] == state.rule.last_close+STEP:
                        state.rule.forming(state.forming,state.fresh_forming)
        elif channel == TRADES:
            for r in sorted(obj.get('data',[]),key=lambda d:(int(d['ts']),int(d['tradeId']))):
                if r.get('instId',symbol) != symbol:
                    continue
                self.trade(symbol,state,int(r['ts']),int(r['tradeId']),float(r['px']),now)

    def session(self, ws):
        import websocket
        self.generation += 1
        self.markets = {}
        requested = set()
        ops = deque()
        next_meta = next_check = next_sub = 0.
        last_frame = time.monotonic()
        ping_at = None
        while not self.stop_event.is_set():
            mono = time.monotonic()
            if mono >= next_check:
                if mono >= next_meta:
                    instruments = self.instruments()
                    self.markets = {s:(self.markets[s] if s in self.markets and self.markets[s].tick==tick
                                       else SymbolWatch(tick)) for s,tick in instruments.items()}
                    for symbol,state in self.markets.items():
                        state.morning.detector.contract_value=self.contract_values.get(symbol,0.)
                        five_cache=self.flow_cache.get(symbol)
                        if not state.flow.ready and five_cache and five_cache[-1][0]==self.now()//FIVE*FIVE-FIVE:
                            state.flow.seed(five_cache,self.now())
                            state.morning.seed(state.flow.five)
                        cached = self.seed_cache.get(symbol)
                        if not state.ready and cached and cached[-1][0] == self.now()//STEP*STEP-STEP:
                            state.rule.seed(cached)
                            state.ready = True
                    self.seed_cache = {s:v for s,v in self.seed_cache.items() if s in self.markets}
                    self.flow_cache = {s:v for s,v in self.flow_cache.items() if s in self.markets}
                    next_meta = mono+(60 if instruments else 2)
                if self.frame_journal:
                    for sym,items in list(self.frame_journal.pending.items()):
                        if all(self.now()>t+STEP+15000 for _,_,t,_ in items):
                            try:
                                self.frame_journal.finish(sym,self.now(),None)
                            except Exception:
                                logging.exception("기한이 지난 복수 시간봉 기록 저장 실패")
                self.history(self.now())
                if self.flow_journal:
                    try:self.flow_journal.expire(self.now())
                    except Exception:logging.exception('종목 흐름 만기 처리 실패')
                targets = {(s,ch) for s in self.markets for ch in (CANDLE,FIVE_CHANNEL)}
                targets.update((s,TRADES) for s,state in self.markets.items() if (morning(self.now()+FIVE) or morning(self.now())) and (state.morning.detector.anchor or state.morning.detector.precursor) or state.flow.fast or state.flow.pending or (self.flow_journal and s in self.flow_journal.pending))
                targets.update((s,TRADES) for s,state in self.markets.items() if state.ready and (state.rule.wants_trades() or state.frames.setup or (self.frame_journal and s in self.frame_journal.pending)))
                if self.entries:
                    self.entries.warm = frozenset(s for s,state in self.markets.items()
                                                  if (morning(self.now()) and state.morning.detector.anchor) or state.flow.fast or (state.ready and (state.rule.swings or state.rule.long.anchor or state.rule.short.anchor)))
                    targets.update((s,TRADES) for s in self.entries.quote_symbols() if s in self.markets)
                while ops and mono-ops[0] >= 3600:
                    ops.popleft()
                if mono >= next_sub and len(ops)<400 and requested != targets:
                    added = targets-requested
                    op,pairs = ('subscribe',added) if added else ('unsubscribe',requested-targets)
                    # All pairs are explicit public instruments. One operation
                    # batches multiple symbols and fits the WS message limit.
                    group = sorted(pairs,key=lambda x:(x[1]==TRADES,x[0],x[1]))[:400]
                    ws.send(json.dumps({'op':op,'args':[dict(instId=s,channel=c) for s,c in group]}))
                    if added:
                        requested.update(group)
                    else:
                        requested.difference_update(group)
                    next_sub = mono+1
                    ops.append(mono)
                self.status = (f'15분봉 감시 {sum(s.ready for s in self.markets.values())}/{len(self.markets)}종목'
                               if self.markets else '대상 종목 수신 대기')
                if self.markets:
                    self.status+=f' · 5분봉 수신 {sum(state.flow.ready for state in self.markets.values())} · 빠른 종목 {sum(state.flow.fast for state in self.markets.values())}'
                if not self.notifier.enabled:
                    self.status += ' · 텔레그램 연결 설정 필요'
                next_check = mono+.5
            if mono-last_frame >= 18 and ping_at is None:
                ws.send('ping')
                ping_at = mono
            if ping_at is not None and mono-ping_at > 12:
                raise TimeoutError('공개 알림 연결 재시도')
            try:
                message = ws.recv()
            except websocket.WebSocketTimeoutException:
                continue
            if not message:
                raise ConnectionError('공개 알림 연결 종료')
            last_frame = time.monotonic()
            ping_at = None
            if message != 'pong':
                self.message(json.loads(message),self.now())

    def run(self):
        import websocket
        delay = 1
        while not self.stop_event.is_set():
            ws = None
            started = time.monotonic()
            try:
                ws = websocket.create_connection(WS_URL,timeout=6)
                ws.settimeout(1)
                self.session(ws)
            except (OSError,ValueError,KeyError,TypeError,IndexError,websocket.WebSocketException):
                self.status = '공개 시세 재연결 중'
            finally:
                if self.entries:
                    self.entries.warm = frozenset()
                    self.entries.invalidate()
                self.generation += 1
                if ws:
                    try:
                        ws.close(timeout=1)
                    except (OSError,websocket.WebSocketException):
                        pass
            delay = 1 if time.monotonic()-started>60 else min(30,2*delay)
            self.stop_event.wait(delay)

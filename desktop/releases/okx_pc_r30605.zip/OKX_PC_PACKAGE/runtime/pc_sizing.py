"""PC entry budget, indicator leverage, and structure-based stops."""
import math
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR

SLOTS = 8
RESERVE = 3
TRADE_RISK = .005
OBSERVATION_COST = .002  # Two-way fee and slippage allowance.


def configure(cfg):
    cfg['risk'].update(pc_three_slots=True, max_positions=SLOTS, entry_cash_reserve_usdt=RESERVE,
                       initial_margin_fraction=1/SLOTS, max_total_margin_fraction=1.,
                       leverage=3, min_leverage=3, max_leverage=5, leverage_mode='signal',
                       initial_size_mode='pc_three_slots')


def indicator_level(ev):
    votes = (ev['rv'] >= 1.3, ev['slope'] > 0 and 0 <= ev['stretch'] <= 1.5,
             ev['rsi_direction'] > 0 and ev['location'] >= .60)
    return (3, 3, 4, 5)[sum(votes)]


def leverage_for(ev, price, exchange_limit):
    """Never pull a stop inward to make an entry fit the account risk budget."""
    if price <= 0 or not all(map(math.isfinite, (price, ev['stop'], exchange_limit))):
        return 0
    return 5 if exchange_limit>=5 else 0


def ema(values,n):
    result=values[0]
    alpha=2/(n+1)
    for x in values[1:]:result+=alpha*(x-result)
    return result

def strength(values):
    moves=[b-a for a,b in zip(values,values[1:])]
    up,down=max(0,moves[0]),max(0,-moves[0])
    for d in moves[1:]:
        up+=(max(d,0)-up)/14
        down+=(max(-d,0)-down)/14
    return 100*up/(up+down) if up+down else 50.

def round_stop(value, tick, side):
    unit = Decimal(str(tick))
    rounds = ROUND_FLOOR if side == 1 else ROUND_CEILING
    return float((Decimal(str(value)) / unit).to_integral_value(rounding=rounds) * unit)


def indicators(bars, side, atr):
    if len(bars) < 32 or atr <= 0: return None
    _, op, high, low, close, vol = bars[-1]
    if high <= low or close <= 0: return None
    closes = [r[4] for r in bars[-32:]]
    average = ema(closes, 20)
    slope = side*(average-ema(closes[:-4], 20))/atr
    stretch = side*(close-average)/atr
    location = ((close-low) if side == 1 else (high-close))/(high-low)
    avg_vol = sum(r[5] for r in bars[-21:-1])/20
    if avg_vol <= 0:
        return None
    rv = vol/avg_vol
    momentum = side*(close-closes[-5])/atr
    rsi_direction = side*(strength(closes)-strength(closes[:-1]))
    if not all(map(math.isfinite,(rv,slope,stretch,location,momentum,rsi_direction))):
        return None
    return dict(rv=rv, slope=slope, stretch=stretch, location=location, momentum=momentum,
                atr_pct=atr/close, rsi_direction=rsi_direction)


def legacy_signal(signal, bars, instrument):
    """Apply the PC policy to restored automatic routes using available closed bars."""
    from okx_core import BotError
    direction = 1 if signal['action'] == 'LONG' else -1
    proof = signal['decision_record']['volume_wick_proof']
    tick, atr = float(instrument['tickSz']), float(signal['atr'])
    details = proof.get('pattern_details', {})
    anchor = details.get('prior_low' if direction == 1 else 'prior_high')
    if anchor is not None:
        second = details['second_low' if direction == 1 else 'second_high']
        if direction*(second-anchor) <= 0:
            raise BotError('두 번째 꼬리가 첫 극값 안쪽에서 지지·저항을 확인하지 못함')
        stop = round_stop(anchor-direction*max(2*tick,.15*atr),tick,direction)
        signal.update(stop=stop, level=stop)
        proof.update(structural_stop=stop, first_wick=anchor, second_wick=second)
        signal['holding_rule']['zone'] = stop
    ev = indicators(bars, direction, atr)
    if not ev:
        raise BotError('배율 계산용 확정봉 대기')
    ev['stop'] = signal['stop']
    maximum = float(instrument.get('lever') or 0)
    level = leverage_for(ev, signal['entry_reference'], maximum)
    if not level:
        raise BotError('3배에서도 구조 손절 위험 한도 초과')
    signal.update(pc260=True, leverage=level, indicator_limit=maximum, margin_fraction=1/SLOTS)
    proof['sizing_indicators'] = ev
    return signal


def valid(signal):
    if signal.get('monthly208'):
        return False
    level = signal.get('leverage')
    if type(level) is not int or level != 5:
        return False
    if signal.get('click716'):
        return level == 5
    if not signal.get('pc260'):
        return False
    proof = signal.get('decision_record', {}).get('volume_wick_proof', {})
    ev = proof.get('timing') or proof.get('sizing_indicators')
    if not ev or ev.get('stop') != signal.get('stop'):
        return False
    return level == leverage_for(ev, signal['entry_reference'], signal['indicator_limit'])

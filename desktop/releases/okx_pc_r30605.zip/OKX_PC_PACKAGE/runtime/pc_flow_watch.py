"""Per-instrument native five-minute history and ordered minute observations."""
from collections import deque
import math

from pc_fast_setup import fast_setup
from pc_symbol_flow import assess_market, pace

FIVE = 300_000
MINUTE = 60_000
HISTORY5 = 212


def flow_text(flow):
    route = {'fast': '5분 우선', 'normal': '15분·마감 1시간 우선'}.get(flow.get('pace'), '속도 자료 대기')
    choice = {1: '롱', -1: '숏', 0: '대기'}[flow['side']]
    median = flow.get('forward_pct')
    evidence = (f"유사 구간 {flow['analogs']}개 · 이후 등락 중앙값 {median:+.2f}%" if median is not None else '완료봉 자료 확인 중')
    if flow.get('reason')=='incomplete_trade_feed':
        evidence += ' · 마감 시점 체결 연속성 미확인'
    if flow.get('reason') in ('micro_opposed','minute_opposed') or flow.get('micro_state')=='both_opposed':
        evidence += ' · 단기봉 역방향'
    return f'종목 흐름 · {route} · {choice}\n{evidence}'


class FlowWatch:
    def __init__(self):
        self.five = deque(maxlen=HISTORY5)
        self.ready = self.fast = False
        self.pending = None
        self.reset_minutes()

    def reset_minutes(self):
        self.minutes = deque(maxlen=12)
        self.live = self.last_id = None
        self.coverage_start=None
        self.complete = False

    def minute_trade(self, ts, trade_id, price, subscribed):
        if not (math.isfinite(price) and price>0):
            return
        if self.last_id is not None:
            if trade_id <= self.last_id:
                return
            if trade_id != self.last_id+1:
                self.reset_minutes()
                subscribed = ts
        if self.coverage_start is None:
            self.coverage_start=subscribed
        self.last_id = trade_id
        t = ts//MINUTE*MINUTE
        if self.live and self.live[0] == t:
            self.live[2] = max(self.live[2], price)
            self.live[3] = min(self.live[3], price)
            self.live[4] = price
            return
        if self.live and self.live[0]+MINUTE == t and self.complete:
            self.minutes.append(tuple(self.live))
        elif self.live and self.live[0]+MINUTE != t:
            self.minutes.clear()
        self.complete = subscribed <= t
        self.live = [t,price,price,price,price]

    def seed(self, rows, now):
        by_ts = {r[0]:r for r in rows if r[0]+FIVE<=now}
        by_ts.update((r[0],r) for r in self.five)
        keys = sorted(by_ts)[-HISTORY5:]
        if not keys or keys[-1] != now//FIVE*FIVE-FIVE:
            return False
        first = len(keys)-1
        while first and keys[first-1]+FIVE == keys[first]: first-=1
        self.five=deque((by_ts[t] for t in keys[first:]),maxlen=HISTORY5)
        self.ready=True
        self.fast=pace(tuple(self.five),keys[-1]+FIVE)['pace']=='fast'
        return True

    def closed(self, row, tick, now):
        if self.five and row[0]<=self.five[-1][0]: return
        if self.five and row[0]!=self.five[-1][0]+FIVE:
            self.five.clear()
            self.ready=False
        self.five.append(row)
        if len(self.five)>=40:
            self.ready=True
        self.pending=None
        end=row[0]+FIVE
        self.fast=self.ready and pace(tuple(self.five),end)['pace']=='fast'
        if self.fast and 0<=now-end<=15_000:
            h=fast_setup(tuple(self.five),float(tick))
            if h and self.live and self.live[0]==end:
                # A new minute's prints can precede confirmation of the old 5m candle.
                low,high=self.live[3],self.live[2]
                adverse=low if h['side']==1 else high
                if (h['side']*(adverse-h['second'])<=0 or
                        max(abs(high-h['price']),abs(low-h['price']))>.5*h['anchor_atr']):
                    return
            if h:
                self.pending=dict(h, trigger_ms=end, trigger_close=h['price'], step_ms=FIVE)

    def take(self, ts, trade_id, price, tick, subscribed):
        h=self.pending
        if not h or ts<h['trigger_ms']:return None
        if ts>h['trigger_ms']+15_000 or h['side']*(price-h['second'])<=0:
            self.pending=None
            return None
        if abs(price-h['trigger_close'])>.5*h['anchor_atr']:
            self.pending=None
            return None
        self.pending=None
        return dict(h,ts=ts,trade_id=trade_id,price=price,chart_bar=(ts//FIVE*FIVE,price,price,price,price),
                    complete_trade_feed=max(subscribed,self.coverage_start or subscribed)<=h['trigger_ms'])

    def assess(self, quarters, hit):
        flow=assess_market(quarters,tuple(self.five),None,hit['ts'],hit['side'],minute_rows=tuple(self.minutes))
        return dict(flow, horizon_ms=15*MINUTE if flow.get('pace')=='fast' else 60*MINUTE)

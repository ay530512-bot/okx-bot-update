"""Additional PC entries, using only completed bars and ordered trades."""
from okx_band_flow import atr
from pc_sizing import ema
from pc_wick_alert import Anchor, Detector, band_walk, oriented
from okx_pattern15 import band

FIVE = 300000
QUARTER = 900000
HOUR = 3600000
SHORT = 'morning_band_short5'
TREND = 'wick_ema_consensus'
LABELS = {SHORT:'오전 5분봉 반전 숏', TREND:'15분·1시간 추세 합의'}


def trend_side(rows):
    if len(rows) < 84 or any(b[0]-a[0]!=QUARTER for a,b in zip(rows,rows[1:])):
        return 0
    hourly = [rows[i][4] for i in range(3,len(rows)) if (rows[i][0]+QUARTER)%HOUR == 0]
    if len(hourly)<21:
        return 0
    closes = [r[4] for r in rows[-160:]]
    hourly = hourly[-160:]
    mean = ema(hourly,20)
    votes = (ema(closes,9)-ema(closes,20),hourly[-1]-mean,mean-ema(hourly[:-1],20))
    return int(min(votes)>0)-int(max(votes)<0)


def morning(ts):
    return 8 <= (ts//HOUR+9)%24 < 12


class UpperBandDetector(Detector):
    bounce_ticks=2
    contract_value=0.

    def first(self, rows, tick):
        # Prices in this detector are negated: a new upper wick is a signed low.
        if len(rows)<165:
            return None
        t,o,h,l,c,v=rows[-1]
        a=atr(rows)
        prev=rows[:-1]
        prev_atr=atr(prev)
        if (h<=l or min(o,c)-l<(h-l)/3 or tick/-c>.0005 or not .0014<=a/-c<=.04
                or v<=prev[-1][5] or v<1.5*sum(r[5] for r in prev[-20:])/20
                or l>min(r[3] for r in prev[-4:])+.1*prev_atr
                or max(r[2] for r in prev[-12:])-l<1.5*prev_atr
                or sum(-r[4]*r[5] for r in rows[-12:])*self.contract_value<60000):
            return None
        closes=[rows[i][4] for i in range(2,len(rows)) if (rows[i][0]+FIVE)%QUARTER==0]
        if len(closes)<55 or closes[-1]>=closes[-4] or ema(closes,20)>=ema(closes[:-3],20):
            return None
        hits=band_walk(rows,6)
        if (len(hits)<3 or hits[-1]>=hits[0] or rows[-7][4]-c<a
                or band(rows,len(rows)-1)[1]>=band(rows,len(rows)-6)[1]):
            return None
        zone=l+max(3*tick,.35*a)
        depart=zone+max(tick,.12*a)
        return Anchor(t,l,a,zone,depart,c>=depart-tick*1e-6)


class MorningShort:
    def __init__(self,tick):
        self.detector = UpperBandDetector(float(tick),30,step=FIVE)

    def seed(self,rows):
        self.detector.seed([oriented(row,-1) for row in rows])

    def closed(self,row):
        self.detector.closed(oriented(row,-1))

    def take(self,rows,ts,trade_id,price,coverage):
        bucket = ts//FIVE*FIVE
        if coverage is None or coverage>bucket:
            return None
        d = self.detector
        hit = d.trade(ts,trade_id,-price,covered_from_open=True)
        if not hit or not morning(ts) or not len(rows)>=32:
            return None
        completed = list(rows)
        turnover = [r[4]*r[5] for r in completed[-15:]]
        prior = sum(turnover[:-3])/4
        if hit['price']-hit['second']>max(3*d.tick,.25*hit['anchor_atr'])+d.eps:
            return None
        if prior<=0 or sum(turnover[-3:])<1.25*prior or atr(completed)/price<.006:
            return None
        for k in ('first','second','price'):
            hit[k] *= -1
        t,o,h,l = d.live
        return dict(hit,side=-1,variant=SHORT,step_ms=FIVE,chart_bar=(t,-o,-l,-h,price))

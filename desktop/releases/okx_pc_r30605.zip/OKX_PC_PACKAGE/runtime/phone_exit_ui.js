function phoneHistoryDetails(e,p){
 e.append(node('b','진입 규칙 · '+(p.entry_rule||'미확인')));
 if(p.entry_conditions?.length)e.append(node('p',p.entry_conditions.join(' · ')));
 for(const part of p.partial_details||[]){
  const amount=part.pnl==null?'금액 확인 불가':cash(part.pnl,true)+' USDT';
  e.append(node('p',part.label+' 손익: '+amount+' (비용 전)'));
  if(part.fee!=null&&part.fee_ccy)e.append(node('p','해당 청산 수수료: '+cash(part.fee,true)+' '+part.fee_ccy));
  e.append(node('p','부분청산 이유: '+part.reason));
 }
 e.append(node('p',p.partial_note||'부분청산 기록 확인 불가'));
 e.append(node('p',((p.partial_details||[]).length?'잔량 청산 이유: ':'청산 이유: ')+(p.exit_reason_detail||'기록 확인 불가')));
}

function phoneRuleSummary(rows){
 if(!rows.length)return;
 const groups=new Map();
 for(const p of rows){
  const name=p.entry_rule||'진입 규칙 미확인';
  if(!groups.has(name))groups.set(name,{win:0,loss:0,flat:0,missing:0,pnl:0});
  const g=groups.get(name), value=Number(p.pnl);
  if(p.pnl==null||!Number.isFinite(value)){g.missing++;continue}
  g.pnl+=value;
  if(value>0)g.win++;else if(value<0)g.loss++;else g.flat++;
 }
 const box=node('details'), title=node('summary','진입 규칙별 성과 · '+groups.size+'개 분류');
 box.append(title);
 for(const [name,g] of groups){
  const amount=g.win+g.loss+g.flat?cash(g.pnl,true)+' USDT':'금액 미확인';
  box.append(node('p',name+' · '+g.win+'승 '+g.loss+'패'+(g.flat?' · 본전 '+g.flat+'건':'')+(g.missing?' · 손익 미확인 '+g.missing+'건':'')+' · '+amount));
 }
 $('historyRows').append(box);
}

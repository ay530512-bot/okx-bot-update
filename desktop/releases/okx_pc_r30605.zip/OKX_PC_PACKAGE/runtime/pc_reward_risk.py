"""Estimated price room and structural risk for the four open-ended setups."""
from pc_sizing import OBSERVATION_COST

RULES = {'classic','breakout','retest','pullback'}
MAX_STOP = .004


def objective(rule, side, bars, level):
    if len(bars)<21:
        return None
    if rule=='classic':
        return sum(r[4] for r in bars[-20:])/20
    prior=bars[-21:-1]
    high=max(r[2] for r in prior)
    low=min(r[3] for r in prior)
    if rule=='retest':
        for lag in range(1,5):
            idx=len(bars)-1-lag
            box=bars[idx-20:idx]
            if len(box)!=20:
                continue
            top=max(r[2] for r in box)
            bottom=min(r[3] for r in box)
            if level==(top if side==1 else bottom) and side*(bars[idx][4]-level)>0:
                return level+side*(top-bottom)
        return None
    if rule=='breakout':
        return level+side*(high-low)
    return high if side==1 else low


def permits(entry, stop, target, side):
    if target is None or entry<=0:
        return False
    risk=side*(entry-stop)
    cost=entry*OBSERVATION_COST
    return 0<risk<=entry*MAX_STOP and side*(target-entry)-cost>=2*(risk+cost)


def trailing(entry, initial_stop, mark, side):
    risk=side*(entry-initial_stop)
    if risk>0 and side*(mark-entry)>=2*risk+entry*OBSERVATION_COST:
        return mark-side*1.5*risk
    return None

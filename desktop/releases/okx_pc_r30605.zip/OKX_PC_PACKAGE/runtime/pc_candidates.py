"""Independent closed-candle entries. The signal price is the completed close."""
from okx_band_flow import atr
from okx_pattern15 import band
from pc_sizing import ema
from pc_extra_entries import SHORT,TREND,FIVE,QUARTER
from pc_wick_context import context,visible_spans,midpoint

REVERSAL = 'window30_reversal'
NEW = dict(window30_reversal='7시간 30분 이내 반전 돌파', breakout='거래량 동반 돌파', retest='돌파 후 재시험', pullback='EMA20 추세 눌림',
           reclaim='볼린저 밴드 재진입', cloud='일목구름 돌파', shoulders='헤드앤숄더·역헤드앤숄더',
           diamond='다이아몬드 돌파')
RULES = {'five_reversal15':'5분 15봉 반전 돌파 (이전)', 'classic':'15분 두 꼬리', 'swing':'세 스윙 돌파', 'flow5':'종목 흐름 5분 재시험',
         SHORT:'오전 5분 반전 숏',TREND:'15분·1시간 추세 합의',**NEW}

# Approval for new orders and the dashboard use the same numbered catalogue.
# Each entry requires a condition and separate long/short worked examples.
from typing import NamedTuple

class EntryGuide(NamedTuple):
    number: int
    condition: str
    long_example: str
    short_example: str

ACTIVE = {
    'classic': EntryGuide(1,'15분봉 볼밴 반복 이탈과 거래량 1.5배 이상인 첫 긴 꼬리 후, 첫 극값을 지킨 두 번째 꼬리의 반응 체결. 간격은 롱 100봉·숏 30봉 이내.',
        '틱 0.01, 첫 저점 10.00 → 재시험 저점 10.01 → 10.02 반등 체결.',
        '틱 0.01, 첫 고점 10.00 → 재시험 고점 9.99 → 9.98 하락 체결.'),
    'breakout': EntryGuide(6,'직전 20봉 범위를 종가로 1틱 이상 돌파하고 거래량이 직전 20봉 평균의 1.5배 이상.',
        '20봉 고가 10.00, 평균 거래량 100 → 거래량 160, 종가 10.05.',
        '20봉 저가 10.00, 평균 거래량 100 → 거래량 160, 종가 9.95.'),
    'retest': EntryGuide(7,'최근 1~4봉 전 20봉 범위를 종가로 돌파. 중간 종가가 선을 지킨 뒤 현재 봉이 선을 터치하고 돌파 방향으로 마감.',
        '10.00 상향 돌파 후 지지 → 저가 9.99, 양봉 종가 10.05.',
        '10.00 하향 돌파 후 저항 → 고가 10.01, 음봉 종가 9.95.'),
    'pullback': EntryGuide(8,'EMA20·EMA50 배열과 EMA20 기울기가 같은 방향. 현재 봉이 직전 EMA20을 터치하고 추세 방향으로 마감.',
        'EMA20이 EMA50 위에서 상승. 직전 EMA20 10.00을 터치한 양봉이 10.05 마감.',
        'EMA20이 EMA50 아래에서 하락. 직전 EMA20 10.00을 터치한 음봉이 9.95 마감.'),
    REVERSAL: EntryGuide(13,'최근 최대 7시간 30분에서 롱은 최근 최고가 이후 하락, 숏은 최근 최저가 이후 상승을 확인합니다. 봉 색은 섞여도 됩니다. 5분·15분 각각 직전 반대색 봉의 고가·저가를 종가로 1틱 이상 돌파하면 진입 후보입니다. 다음 5분봉 마감 전까지 롱은 매도 1호가가 돌파선 위, 숏은 매수 1호가가 돌파선 아래이고 신호 종가와의 거리가 0.5 ATR 이내일 때 검토합니다. 체결 후 15분에 전량 청산하며 보호 손절·당일 마감이 먼저면 먼저 정리합니다.',
        '하락 후 직전 5분 음봉 고가 10.00 → 10.01에 양봉 마감. 14:05:08 롱 체결이면 14:20:08부터 전량 청산.',
        '상승 후 직전 15분 양봉 저가 10.00 → 9.99에 음봉 마감. 14:15:03 숏 체결이면 14:30:03부터 전량 청산.'),
}
if any(not all((guide.condition.strip(),guide.long_example.strip(),guide.short_example.strip()))
       for guide in ACTIVE.values()):
    raise ValueError('활성 전략에는 조건과 롱·숏 예시가 필요합니다.')

def rule_id(hit):
    return hit.get('variant') or ('swing' if 'neckline' in hit else 'flow5' if hit.get('step_ms')==FIVE else 'classic')

def switch_key(value):
    if not isinstance(value,str):
        return False
    prefix,_,rule=value.partition(':')
    return prefix in ('on','off') and rule in RULES

def signals(rows,step,tick):
    if len(rows)<55 or rows[-1][0]-rows[-55][0]!=54*step:
        return []
    t,o,h,l,c,v=rows[-1]
    p=rows[-2]
    end=t+step
    a=atr(rows)
    if a<=0 or h<=l:
        return []
    prior=rows[-21:-1]
    closes=[r[4] for r in rows[-160:]]
    avg=ema(closes,20)
    slow=ema(closes,50)
    previous=ema(closes[:-1],20)
    volume=sum(r[5] for r in prior)/20
    if volume<=0:
        return []
    lo,_,hi=band(rows,len(rows)-1)
    found=[]
    def add(name,side,level):
        if side*(c-level)<tick*.999999:
            return
        stop=l if side==1 else h
        found.append(dict(variant=name,side=side,ts=end,trigger_ms=end,price=c,
                          trade_id=0,first=stop,second=level,anchor_ms=t,anchor_atr=a,
                          step_ms=step,bars=1,closed_signal=True))
    for side in (1,-1):
        edge=max(r[2] for r in prior) if side==1 else min(r[3] for r in prior)
        if side*(c-edge)>0 and v>=1.5*volume:
            add('breakout',side,edge)
        for lag in range(1,5):
            idx=len(rows)-1-lag
            setup=rows[idx]
            base=rows[idx-20:idx]
            level=max(r[2] for r in base) if side==1 else min(r[3] for r in base)
            if (side*(setup[4]-level)>0 and all(side*(r[4]-level)>0 for r in rows[idx+1:-1])
                    and l<=level<=h and side*(c-o)>0):
                add('retest',side,level)
                break
        if side*(avg-slow)>0 and side*(avg-previous)>0 and l<=previous<=h and side*(c-o)>0:
            add('pullback',side,previous)
        level=lo if side==1 else hi
        if l<level<h and side*(c-o)>0 and abs(avg-slow)<=a:
            add('reclaim',side,level)
    if step==QUARTER:
        latest=visible_spans(rows[:-1])
        old=visible_spans(rows[:-2])
        if latest and old:
            for side in (1,-1):
                edge=max if side==1 else min
                level=edge(latest)
                if side*(p[4]-edge(old))<=0 and side*(midpoint(rows,9)-midpoint(rows,26))>0:
                    add('cloud',side,level)
        patterns=context(rows,dict(ts=end,price=c,anchor_atr=a),tick)['patterns']
        for pattern in patterns:
            if pattern['confirmed_ms']==end:
                add('diamond' if pattern['kind']=='diamond' else 'shoulders',pattern['side'],pattern['level'])
    return found

def reversal(rows, tick, step):
    limit = 30 * QUARTER // step
    prior = rows[-limit:-1]
    if len(prior)<2 or rows[-1][0]-prior[0][0]!=len(prior)*step:
        return None
    t,op,high,low,close,_ = rows[-1]
    _,prev_open,prev_high,prev_low,prev_close,_ = prior[-1]
    side = 1 if close > op else -1
    level = prev_high if side==1 else prev_low
    if close==op or side*(prev_close-prev_open)>=0 or side*(close-level)<tick*.999999:
        return None
    extreme = max(r[2] for r in prior) if side==1 else min(r[3] for r in prior)
    index = next(i for i in range(len(prior)-1,-1,-1) if prior[i][2 if side==1 else 3]==extreme)
    leg = prior[index:]
    if len(leg)<2 or side*(prev_close-leg[0][4])>=0:
        return None
    slope = sum((2*i-len(leg)+1)*r[4] for i,r in enumerate(leg))
    volatility = atr(rows)
    if side*slope>=0 or volatility<=0:
        return None
    return dict(variant=REVERSAL,side=side,ts=t+step,trigger_ms=t+step,price=close,
                trade_id=0,first=low if side==1 else high,second=level,anchor_ms=t,
                anchor_atr=volatility,step_ms=step,bars=len(leg),closed_signal=True)


def reversal_frames(five):
    yield FIVE, five
    if (five[-1][0]+FIVE)%QUARTER:
        return
    quarters = []
    for i in range(len(five)%3,len(five),3):
        a,b,c=five[i:i+3]
        if a[0]%QUARTER or b[0]!=a[0]+FIVE or c[0]!=b[0]+FIVE:
            quarters.clear()
            continue
        quarters.append((a[0],a[1],max(a[2],b[2],c[2]),min(a[3],b[3],c[3]),c[4],a[5]+b[5]+c[5]))
    if len(quarters)>=32:
        yield QUARTER,tuple(quarters)

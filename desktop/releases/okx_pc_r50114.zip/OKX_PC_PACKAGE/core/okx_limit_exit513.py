"""Serialized post-only exit for the five OKX strategies. All prices are USDT."""
import uuid
from decimal import ROUND_CEILING, ROUND_FLOOR

from okx_core import BotError, Rejected, dec, fmt, owned_position
from okx_scale import legs_for

KEY = 'limit_exit513'
TARGET = '5.1 · 마크가격 목표 도달 · 전량 익절'
LIVE_TARGET = '5.1 · 실시간 마크가격 목표 도달 · 전량 익절'
REQUOTE_MS = 5000
ORDER_TTL_MS = 8000  # Limits how late OKX may ACCEPT a request; resting orders stay GTC.
TERMINAL = {'filled', 'canceled', 'mmp_canceled'}


def kind(reason):
    if reason in (TARGET, LIVE_TARGET):
        return 'target'
    if reason.startswith(('5.1 · 최대 보유 ', '5.1 · 1시간 확정 종가 ')):
        return 'rule'
    return None


def breakeven(o, p):
    sign = 1 if o['direction'] == 'long' else -1
    entry = dec(p['avgPx'])
    rate = abs(dec(o['entry_taker_fee']))
    units = dec(o['quantity']) * dec(o['ct_val'])
    # Use the entry taker rate on both legs and allocate accumulated funding
    # debits across the original position. OKX's own break-even wins if stricter.
    funding = min(dec(0), dec(p.get('fundingFee') or 0)) / units
    needed = (entry * (1 + sign * rate) - sign * funding) / (1 - sign * rate)
    exchange = dec(p.get('bePx') or 0)
    if exchange > 0 and sign * (exchange - needed) > 0:
        needed = exchange
    return needed


def profitable(o, p):
    sign = 1 if o['direction'] == 'long' else -1
    return sign * (dec(p['markPx']) - breakeven(o, p)) > 0


def start(engine, snapshot, o, reason):
    route = kind(reason)
    if (not route or not (o.get('v4_signal') or {}).get('pc51')
            or o['phase'] != 'active' or engine.settings.get('TRADING_EXCHANGE', 'okx') != 'okx'):
        return False
    p = owned_position(o, snapshot['positions'])
    if not p or (route == 'rule' and not profitable(o, p)):
        return False
    engine.invalidate()
    o.update(phase='closing', exit_reason=reason)
    o[KEY] = {'kind': route, 'next_send_ms': 0}
    o.pop('close_id', None)
    engine.journal.save()
    engine.notify('전량 청산 요청', o['symbol'] + ' / ' + reason + ' / 지정가')
    reconcile(engine, snapshot, o)
    return True


def verified_resting_order(o, row):
    state = (o or {}).get(KEY) or {}
    if not ((o or {}).get('v4_signal') or {}).get('direction514') or state.get('kind') != 'resting':
        return False
    return (o.get('phase') == 'active' and not state.get('force') and bool(o.get('close_id'))
            and row.get('clOrdId') == o['close_id'] and row.get('instId') == o['symbol']
            and row.get('posSide') == o['direction'] and row.get('tdMode') == 'isolated'
            and row.get('side') == ('sell' if o['direction'] == 'long' else 'buy')
            and row.get('state') in ('live','partially_filled') and row.get('ordType') == 'post_only'
            and dec(row.get('px') or 0) == dec(state.get('px') or 0) > 0
            and dec(row.get('sz') or 0) == dec(state.get('before') or 0) > 0
            and 0 <= dec(row.get('accFillSz') or 0) < dec(row['sz']))


def arm_target(engine, snapshot, o):
    if o.get(KEY) or o['phase'] != 'active' or not o.get('protection_verified'):
        return
    o[KEY] = {'kind': 'resting', 'next_send_ms': 0}
    engine.journal.save()
    reconcile(engine, snapshot, o)


def force(engine, o, reason):
    state = o[KEY]
    if state.get('force'):
        return
    state['force'] = reason
    o['phase'] = 'closing'
    o['exit_reason'] = reason
    engine.journal.save()
    engine.log(o['symbol'] + ' / ' + reason + ' / 지정가 잔량 취소 후 시장가 청산')


def cancel(engine, o, now):
    state = o[KEY]
    if now < state.get('cancel_after', 0):
        return
    state['cancel_after'] = now + 3000
    engine.journal.save()
    try:
        engine.api.post('/api/v5/trade/cancel-order', {'instId':o['symbol'], 'clOrdId':o['close_id']})
    except Rejected:
        # The fill or a previous cancel may have won the race. Query by the same ID.
        pass


def quote_price(engine, o, p, now):
    state = o[KEY]
    if 'tick' not in state:
        instrument = engine.api.public('/api/v5/public/instruments', instType='SWAP', instId=o['symbol'])[0]
        state['tick'] = fmt(instrument['tickSz'])
    tick = dec(state['tick'])
    if tick <= 0:
        raise BotError('익절 지정가 호가 단위 확인 필요')
    quote = engine.stream.read(o['symbol'], 'tickers', 3, now)
    if not quote or not 0 <= now - int(quote.get('ts') or 0) <= 3000:
        quote = engine.api.public('/api/v5/market/ticker', instId=o['symbol'])[0]
    if not 0 <= engine.api.now_ms() - int(quote.get('ts') or 0) <= 3000:
        raise BotError('익절 지정가 · 최신 매수·매도 호가 대기')
    bid, ask = dec(quote['bidPx']), dec(quote['askPx'])
    if bid <= 0 or ask <= bid:
        raise BotError('익절 지정가 · 유효한 호가 대기')
    floor = breakeven(o, p)
    target = o['v4_signal']['exit_plan'].get('target_price') if state['kind'] in ('target','resting') else None
    if o['direction'] == 'long':
        floor = ((floor / tick).to_integral_value(rounding=ROUND_FLOOR) + 1) * tick
        px = max(ask, floor, dec(target) if target else floor)
        return fmt((px / tick).to_integral_value(rounding=ROUND_CEILING) * tick)
    floor = ((floor / tick).to_integral_value(rounding=ROUND_CEILING) - 1) * tick
    px = min(bid, floor, dec(target) if target else floor)
    if px < tick:
        raise BotError('익절 지정가 · 양수 주문 가격 대기')
    return fmt((px / tick).to_integral_value(rounding=ROUND_FLOOR) * tick)


def protected(engine, o, p):
    mine, _ = engine.algos()
    legs = {leg['algo_client_id']: leg for leg in legs_for(o)}
    remaining = dec(p['pos'])
    coverage = dec(0)
    for row in mine:
        leg = legs.pop(row.get('algoClOrdId'), None)
        if not leg or row.get('state') != 'live' or row.get('slTriggerPxType') != 'mark' or row.get('slOrdPx') != '-1':
            continue
        if (o.get('v4_signal') or {}).get('direction514') and (
                row.get('instId') != o['symbol'] or row.get('posSide') != o['direction']
                or row.get('side') != ('sell' if o['direction'] == 'long' else 'buy')
                or row.get('tdMode') != 'isolated'):
            continue
        if dec(row.get('slTriggerPx') or 0) != dec(leg['stop_px']):
            continue
        coverage += remaining if row.get('closeFraction') == '1' else dec(row.get('sz') or 0)
    return coverage >= remaining


def safeguards(engine, o, p, now):
    state = o[KEY]
    if state.get('force'):
        return
    sign = 1 if o['direction'] == 'long' else -1
    mark = dec(p['markPx'])
    mark_quote = engine.stream.read(o['symbol'], 'mark-price', 3, now)
    if mark_quote and 0 <= now - int(mark_quote.get('ts') or 0) <= 3000 and mark_quote.get('markPx'):
        ws_mark = dec(mark_quote['markPx'])
        if ws_mark > 0 and sign * (ws_mark - mark) < 0:
            mark = ws_mark
    liq = dec(p.get('liqPx') or 0)
    risk = engine.cfg['risk']
    if (sign * (mark - dec(o['stop_px'])) <= 0
            or liq > 0 and sign * (mark - liq) <= liq * dec(risk['liquidation_buffer'])
            or risk.get('final_roe_enabled', True) and dec(p.get('uplRatio') or 0) <= dec(risk['final_stop_roe'])):
        force(engine, o, '5.1 · 익절 지정가 대기 중 보호선 도달')
        return
    plan = o['v4_signal']['exit_plan']
    bars = int(plan.get('max_hold_bars') or 0)
    entered = int(o.get('pc51_fill_ms') or o['entry_ms'])
    if state['kind'] in ('target', 'resting') and bars and now >= entered + bars * int(plan['bar_ms']):
        if state['kind'] == 'resting':
            state['retire_target'] = True
            o['phase'] = 'closing'
        state['kind'] = 'rule'
        o['exit_reason'] = f'5.1 · 최대 보유 {bars * 15}분 만료 · 전량 청산'
        engine.journal.save()
    if state['kind'] == 'rule' and not profitable(o, p):
        force(engine, o, o['exit_reason'] + ' · 순수익 추정 기준 이탈')
        return
    if now >= state.get('verify_after', 0):
        if not protected(engine, o, p):
            force(engine, o, '5.1 · 익절 지정가 대기 중 보호 손절 미확인')
        state['verify_after'] = now + REQUOTE_MS


def submit(engine, o, p, now):
    state = o[KEY]
    if now < state.get('next_send_ms', 0) and not state.get('force'):
        return
    order_type = 'market' if state.get('force') else 'post_only'
    body = dict(instId=o['symbol'], tdMode='isolated', posSide=o['direction'],
                side='sell' if o['direction'] == 'long' else 'buy', sz=fmt(p['pos']), ordType=order_type)
    if order_type == 'post_only':
        body['px'] = quote_price(engine, o, p, now)
    now = engine.api.now_ms()
    o['close_id'] = body['clOrdId'] = 'OP' + uuid.uuid4().hex[:28]
    state.update(order_type=order_type, before=body['sz'], px=body.get('px'), sent_ms=now,
                 cancel_after=0, next_send_ms=now + REQUOTE_MS)
    state.pop('missing_since', None)
    engine.journal.save()
    engine.log(o['symbol'] + (' / 익절 지정가 ' + body['px'] if order_type == 'post_only' else ' / 보호 시장가')
               + ' · ' + body['sz'] + '계약')
    # Position mode is verified on every snapshot. In long/short mode side +
    # posSide closes only this leg. Persist the ID before crossing the network.
    engine.api.post_entry_until(body, now + ORDER_TTL_MS)


def order_status(engine, snapshot, o, p, now):
    state = o[KEY]
    cid = o['close_id']
    pending = next((row for row in snapshot['orders'] if row.get('clOrdId') == cid), None)
    if pending and pending.get('state') in ('live', 'partially_filled'):
        state.pop('missing_since', None)
        return pending
    try:
        rows = engine.api.get('/api/v5/trade/order', instId=o['symbol'], clOrdId=cid)
    except Rejected as error:
        if '51603' not in str(error) or pending or now < state['sent_ms'] + ORDER_TTL_MS + 3000:
            raise
        # A timeout/crash before send is recoverable once expTime has elapsed
        # and two independent order lookups and unchanged exposure show no order.
        if p is not None and dec(p['pos']) != dec(state['before']):
            raise BotError('익절 주문 이력과 잔량 대조 중') from error
        if now - state.setdefault('missing_since', now) < 2000:
            return {}
        return {'state':'canceled', 'accFillSz':'0'}
    if not rows or rows[0].get('clOrdId') != cid or rows[0].get('instId') != o['symbol']:
        raise BotError('청산 주문 ID·종목 재확인 대기')
    state.pop('missing_since', None)
    return rows[0]


def reconcile(engine, snapshot, o):
    state = o[KEY]
    now = engine.api.now_ms()
    p = owned_position(o, snapshot['positions'])
    if p:
        if state.pop('flat_seen_ms', None) is not None:
            engine.journal.save()
        safeguards(engine, o, p, now)
    proven_flat = False
    cid = o.get('close_id')
    if cid:
        if state['order_type'] == 'post_only' and (not p or state.get('force') or state.get('retire_target')):
            cancel(engine, o, now)
        row = order_status(engine, snapshot, o, p, now)
        status = row.get('state')
        if status in ('live', 'partially_filled'):
            if (p and state['kind'] != 'resting' and not state.get('retire_target')
                    and not state.get('force') and state['order_type'] == 'post_only'
                    and now >= state['next_send_ms'] and now >= state.get('cancel_after', 0)):
                px = quote_price(engine, o, p, now)
                state['next_send_ms'] = now + REQUOTE_MS
                if dec(px) != dec(state['px']):
                    cancel(engine, o, now)
            return p
        if status not in TERMINAL:
            return p
        filled = dec(row.get('accFillSz') or 0)
        left = dec(state['before']) - filled
        if p and (left < 0 or dec(p['pos']) > left):
            # fills and positions have different response clocks.
            return p
        proven_flat = not p and left == 0
        if proven_flat and status == 'filled' and state['order_type'] == 'post_only' and (
                state['kind'] == 'resting' or state.get('retire_target')):
            o['exit_reason'] = '5.1.14 · 3R 익절 지정가 체결'
        if p and dec(p['pos']) < left and state['kind'] == 'resting' and not state.get('force'):
            # An independent protective or manual close resized the original leg.
            # Match a second position snapshot before placing a new resting quantity.
            stamp = int(snapshot['ms'])
            last = state.get('residual_check') or {}
            if last.get('size') != p['pos'] or stamp < last.get('ms', 0):
                state['residual_check'] = dict(size=p['pos'], ms=stamp)
                engine.journal.save()
                return p
            if stamp - last['ms'] < 1000:
                return p
    if not p and not proven_flat:
        # Keep ownership and the working stop across a single empty position
        # snapshot unless the linked exit has filled the full prior balance.
        stamp = int(snapshot['ms'])
        first = state.get('flat_seen_ms')
        if first is None or stamp < first:
            state['flat_seen_ms'] = stamp
            engine.journal.save()
            return None
        if stamp - first < 1000:
            return None
    if not p:
        engine.finish_position()
    else:
        if cid:
            state.pop('residual_check', None)
            state.pop('retire_target', None)
            state['remaining'] = fmt(p['pos'])
            o.pop('close_id')
            engine.journal.save()
        state.pop('retire_target', None)
        submit(engine, o, p, now)
    return p

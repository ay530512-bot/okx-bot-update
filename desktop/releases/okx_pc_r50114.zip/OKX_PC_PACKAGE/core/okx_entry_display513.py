"""Single-writer projection of ranked candidates and exchange entry confirmations.

The HTTP threads only read published snapshots. Displaying a candidate never
requests quotes, touches the journal or calls the order engine.
"""
from decimal import Decimal, InvalidOperation

REGIMES = {
    'trend_retest': '추세 돌파 후 재시험',
    'trend_breakout': '추세 돌파',
    'liquidity_sweep': '유동성 돌파 실패 후 반전',
    'trend_compression': '추세 중 변동폭 수축',
    'range_reversion': '횡보 박스 안으로 복귀',
    'hold_until_invalidation': '시간봉 돌파 유지',
}


def positive(value):
    try:
        n = Decimal(str(value))
        if n.is_finite() and n > 0:
            return format(n, 'f')
    except (InvalidOperation, TypeError, ValueError):
        pass
    return None


def key(signal):
    return (signal.get('valid_from_ms'), signal.get('symbol'),
            signal.get('strategy_id'), signal.get('action'), signal.get('regime'),
            (signal.get('direction514') or {}).get('original_action'))


def describe(s):
    model = s.get('direction514') or {}
    return dict(symbol=s.get('symbol'), strategy=s.get('name'), priority=s.get('priority'),
                original_side=model.get('original_action'),
                side=s.get('action'), regime=REGIMES.get(s.get('regime'), '분류 미확인'),
                reason=s.get('reason'), conditions=tuple(s.get('conditions') or ()),
                reference=positive(s.get('reference')), confirmed_ms=s.get('valid_from_ms'),
                expires_ms=s.get('expires_ms'))


class EntryDisplay:
    def __init__(self):
        self.signature = None
        self.period = None
        self.meta = {}
        self.signals = {}
        self.observations = {}
        self.recent = None
        self.published = {}

    def scan(self, engine):
        period = getattr(engine, 'ranked51_start', None)
        signals = getattr(engine, 'ranked51_plans', ())
        complete = getattr(engine, 'ranked51_batch', None) is not None
        status = getattr(engine, 'ranked51_status', '')
        signature = (period, complete, status, tuple(key(s) for s in signals))
        if self.signature == signature:
            return
        if self.period != period:
            self.observations = {}
        self.period = period
        self.signature = signature
        self.signals = {key(s): describe(s) for s in signals}
        self.meta = dict(period=period, complete=complete, scan=status)
        # Recover confirmed entry prices and submitted orders from open records
        # when this process starts or a matching scan becomes available.
        for r in engine.records():
            s = r.get('v4_signal') or {}
            if not s.get('pc51'):
                continue
            if r.get('fill_px') and positive(r['fill_px']):
                k = key(s)
                if k not in self.observations and (self.recent or {}).get('key') != k:
                    self.exchange(r, {'state': 'filled', 'avgPx': r['fill_px'], 'accFillSz': r.get('quantity')})
            elif r.get('phase') == 'submitted' and key(s) not in self.observations:
                self.note(s, '주문 결과 확인 중')
        self.publish()

    def publish(self):
        rows = [dict(row, **self.observations.get(k, {})) for k, row in self.signals.items()]
        recent = self.recent['row'] if self.recent else None
        self.published = dict(self.meta, rows=rows, recent=recent)

    def note(self, signal, stage, *, touch=None, hold_reason=None):
        k = key(signal)
        if self.period is not None and k[0] != self.period:
            return
        observation = dict(self.observations.get(k, {}), stage=stage, hold_reason=hold_reason)
        if touch is not None:
            observation['touch'] = positive(touch)
        if self.observations.get(k) != observation:
            self.observations[k] = observation
            self.publish()

    def exchange(self, record, order):
        s = record.get('v4_signal') or {}
        if not s.get('pc51'):
            return
        k = key(s)
        state = order.get('state')
        filled = positive(order.get('accFillSz'))
        stage = {
            'live': '미체결 · 주문 접수',
            'partially_filled': '일부 체결',
            'filled': '체결 완료',
            'canceled': '잔량 취소 · 일부 체결' if filled else '미체결 취소',
        }.get(state, '주문 결과 확인 중')
        observation = dict(self.observations.get(k, {}), stage=stage, hold_reason=None)
        if filled:
            observation.update(fill=positive(order.get('avgPx')), size=filled)
        changed = False
        if self.period == k[0] and self.observations.get(k) != observation:
            self.observations[k] = observation
            changed = True
        if filled:
            try:
                stamp = int(order.get('fillTime') or record.get('pc51_fill_ms') or order.get('uTime') or record.get('entry_ms') or 0)
            except (TypeError, ValueError, OverflowError):
                stamp = 0
            if not self.recent or k == self.recent['key'] or stamp >= self.recent['stamp']:
                item = dict(key=k, stamp=stamp, row=dict(describe(s), **observation))
                if item != self.recent:
                    self.recent = item
                    changed = True
        if changed:
            self.publish()


def display(engine):
    if not hasattr(engine, 'ranked51_display'):
        engine.ranked51_display = EntryDisplay()
    return engine.ranked51_display

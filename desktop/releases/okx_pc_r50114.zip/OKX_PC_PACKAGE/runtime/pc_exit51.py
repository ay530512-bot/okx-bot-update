"""Manage an owned 5.1 position from the exit plan frozen at submission."""
from okx_core import dec

HOUR = 3_600_000
QUARTER = 900_000


def fill_time(owned, order):
    submitted = int(owned['entry_ms'])
    return max(submitted, int(order.get('fillTime') or order.get('uTime') or submitted))


def target_reached(direction, mark, target):
    if target is None or dec(mark) <= 0:
        return False
    return dec(mark) >= dec(target) if direction == 'long' else dec(mark) <= dec(target)


def next_hour_open(owned):
    entered = int(owned.get('pc51_fill_ms') or owned['entry_ms'])
    return int(owned.get('pc51_checked_until') or entered // HOUR * HOUR)


def invalidation_bars(api, symbol, first):
    """Fetch a bounded page beginning at the first unchecked hour, including after a restart."""
    from okx_brandt import closed   # Shared confirmed-OHLC parser (timestamps are bar opens).
    latest = api.now_ms() // HOUR * HOUR
    end = min(latest, first + 99 * HOUR)
    if end <= first:
        return []
    count = (end - first) // HOUR
    path = '/api/v5/market/candles' if latest-first < 99*HOUR else '/api/v5/market/history-candles'
    rows = api.public(path, instId=symbol, bar='1H', after=str(end), limit=str(count))
    return closed(rows, HOUR, end)


def manage(engine, snapshot, position, owned):
    signal = owned['v4_signal']
    plan = signal['exit_plan']
    direction = owned['direction']
    mark = dec(position['markPx'])
    if mark <= 0:
        return
    stop = dec(owned['stop_px'])   # The actual tick-rounded exchange stop.
    stop_reached = mark <= stop if direction == 'long' else mark >= stop
    if stop_reached:
        engine.close(snapshot, '5.1 · 마크가격 보호 손절 도달')
        return
    if not plan.get('resting_target') and target_reached(direction, mark, plan['target_price']):
        engine.close(snapshot, '5.1 · 마크가격 목표 도달 · 전량 익절')
        return
    now = engine.api.now_ms()
    entered = int(owned.get('pc51_fill_ms') or owned['entry_ms'])
    bars = int(plan['max_hold_bars'])
    if bars > 0 and now >= entered + bars * int(plan['bar_ms']):
        engine.close(snapshot, f'5.1 · 최대 보유 {bars * 15}분 만료 · 전량 청산')
        return
    if plan.get('resting_target'):
        from okx_limit_exit513 import arm_target
        arm_target(engine, snapshot, owned)
        return
    condition = plan.get('closed_invalidation')
    if not condition:
        return
    first = next_hour_open(owned)
    if now < first + HOUR:
        return
    frames = engine.chart_job(owned['symbol']) or {}
    latest_checked = first
    price = dec(condition['price'])
    for bar in frames.get('1H', []):
        stamp = int(bar[0])
        end = stamp + HOUR
        if stamp < first or end > now or end <= entered:
            continue
        close = dec(bar[4])
        broken = close < price if condition['relation'] == 'below' else close > price
        if broken:
            engine.close(snapshot, f'5.1 · 1시간 확정 종가 {close} · 무효화 가격 {price} 이탈')
            return
        if stamp == latest_checked:
            latest_checked = end
    if latest_checked > first:
        owned['pc51_checked_until'] = latest_checked
        engine.journal.save()


def entry_evidence(signal):
    proof = (signal.get('decision_record') or {}).get('volume_wick_proof') or {}
    fields = ('strategy_id', 'priority', 'name', 'score', 'fit', 'reference', 'structural_stop',
              'target_price', 'confirmation_ms', 'regime', 'conditions', 'reason')
    evidence = {key: signal.get(key, proof.get(key)) for key in fields}
    evidence.update(reference=signal.get('entry_reference', evidence['reference']),
                    structural_stop=signal['exit_plan']['stop_price'],
                    target_price=signal['exit_plan']['target_price'], exit_plan=signal['exit_plan'])
    if signal.get('direction514'):
        evidence['direction514'] = signal['direction514']
    if signal.get('allocation511'):
        evidence['allocation511'] = signal['allocation511']
    return evidence


def aot_cooldown_until(journal, symbol):
    """Allow confirmed non-losses immediately, withhold re-entry while recent PnL is unknown."""
    until = int(journal.get('aot51_cooldown_until', {}).get(symbol, 0))
    for item in journal.get('settlements', ()):
        if item.get('symbol') == symbol and (item.get('entry_evidence') or {}).get('strategy_id') == 'aot':
            until = max(until, int(item['end_ms']) + 4 * QUARTER)
    return until


def record_aot_loss(journal, item, pnl, closed_ms):
    if (item.get('entry_evidence') or {}).get('strategy_id') == 'aot' and pnl < 0:
        cooldowns = journal.setdefault('aot51_cooldown_until', {})
        symbol = item['symbol']
        cooldowns[symbol] = max(cooldowns.get(symbol, 0), int(closed_ms) + 4 * QUARTER)

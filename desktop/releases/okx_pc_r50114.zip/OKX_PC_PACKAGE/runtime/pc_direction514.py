"""Deploy the frozen five-pattern direction model using only confirmed public data."""
import hashlib
import json
import math
from functools import lru_cache
from pathlib import Path
from statistics import median
from struct import Struct

import pc_strategy51 as patterns

QUARTER = patterns.QUARTER
HOUR = patterns.HOUR
REGIMES = ('trend_retest', 'trend_breakout', 'liquidity_sweep', 'trend_compression',
           'range_reversion', 'hold_until_invalidation')
HORIZONS = (1, 4, 16, 96)
MODEL_SHA256 = '9f9a4845063ebe9d1c1f36cbfd4519aac5a29375abe63af87544e1358eca4d26'
FLOAT = Struct('f')


@lru_cache(maxsize=1)
def model():
    raw = Path(__file__).with_suffix('.json').read_bytes()
    if hashlib.sha256(raw).hexdigest() != MODEL_SHA256:
        raise ValueError('롱·숏 예측 모델 파일 확인 필요')
    return json.loads(raw)


def score(features):
    spec = model()
    values = [FLOAT.unpack(FLOAT.pack(features[name]))[0] for name in spec['features']]
    estimate = spec['intercept']
    for tree in spec['trees']:
        node = tree[0]
        while not node[5]:
            idx, threshold, left, right, missing_left = node[:5]
            value = values[idx]
            go_left = missing_left if math.isnan(value) else value <= threshold
            node = tree[left if go_left else right]
        estimate += node[6]
    return estimate


def confirmed_market(frames_by_symbol, decision):
    """Cross-sectional reference at one close, equally weighting valid contracts."""
    markets = {}
    for symbol, frames in frames_by_symbol.items():
        rows = sorted((r for r in frames['15m'] if int(r[0]) < decision and str(r[8]) == '1'),
                      key=lambda r: int(r[0]))
        if not rows or int(rows[-1][0]) != decision - QUARTER:
            continue
        last = float(rows[-1][4])
        if not math.isfinite(last) or last <= 0:
            continue
        item = {'close': last, 'hi24': math.nan, 'lo24': math.nan, 'turn4': math.nan}
        closes = {int(row[0]): float(row[4]) for row in rows}
        for h in HORIZONS:
            item[h] = math.nan
            old = closes.get(decision - (h+1)*QUARTER)
            if old and old > 0:
                item[h] = last/old - 1
        if len(rows) >= 96 and int(rows[-96][0]) == decision-96*QUARTER:
            item['hi24'] = max(float(r[2]) for r in rows[-96:])
            item['lo24'] = min(float(r[3]) for r in rows[-96:])
        if len(rows) >= 4 and int(rows[-4][0]) == decision-4*QUARTER:
            item['turn4'] = sum(float(r[7]) for r in rows[-4:])
        markets[symbol] = item
    reference = {}
    for h in HORIZONS[1:]:
        valid = [m[h] for m in markets.values() if math.isfinite(m[h])]
        reference[h] = median(valid) if valid else math.nan
        if h == 16:
            reference['breadth'] = sum(r > 0 for r in valid)/len(valid) if valid else .5
    return markets, reference


def settled_funding(rows, decision):
    events = {}
    for row in rows:
        stamp = int(row['fundingTime'])
        if stamp < decision:
            rate = row.get('realizedRate')
            if rate in ('', None):
                raise ValueError('실제 정산 펀딩률 미수신')
            rate = float(rate)
            if not math.isfinite(rate):
                raise ValueError('펀딩 정산값 미수신')
            events[stamp] = rate
    if not events:
        if rows:
            raise ValueError('확정 시각 이전 펀딩 미수신')
        return 0., 24.
    times = sorted(events, reverse=True)
    latest = times[0]
    interval = min(8., max(1., (latest-times[1])/HOUR)) if len(times) > 1 else 8.
    return events[latest]*8/interval*10000, min(24., (decision-latest)/HOUR)


def inputs(original, frames, decision, market, benchmark, tick, funding, side):
    origin = decision - QUARTER
    bars = patterns._closed(frames['15m'], QUARTER, origin)
    hours = patterns._closed(frames['1H'], HOUR, origin)
    direction = 1 if original['action'] == 'LONG' else -1
    regime = REGIMES.index(original['regime'])
    view = bars if direction == 1 else patterns._mirror(bars)
    if regime == 4:
        box = view[-14:-2]
        lo, hi = min(b.low for b in box), max(b.high for b in box)
        pivot = direction * (lo + .25*(hi-lo))
    elif regime == 5:
        pivot = original['exit_plan']['closed_invalidation']['price']
    else:
        window = (slice(-11,-3), slice(-13,-1), slice(-4,-1), slice(-5,-1))[regime]
        pivot = direction * max(b.high for b in view[window])
    ref, atr = original['reference'], original['atr']
    b = bars[-1]
    vwap = sum(v.volume*(v.high+v.low+v.close)/3 for v in bars[-20:])/sum(v.volume for v in bars[-20:])
    close, hi, lo = market['close'], market['hi24'], market['lo24']
    rate, age = funding
    f = {'setup'+str(j): float(regime == j) for j in range(len(REGIMES))}
    f.update(side=side, aligned=side*direction, fit=original['fit'], rv=math.log1p(original['score']),
             atr_pct=100*atr/ref, signal_range_atr=patterns._true_range(b,bars[-2])/atr,
             body=side*(ref-b.open)/atr, stop_distance=abs(ref-original['structural_stop'])/atr,
             pivot=side*(close-pivot)/atr, mid=side*(close-(b.open+ref)/2)/atr,
             vwap=side*(close-vwap)/atr, signal_location=side*((ref-b.low)/max(b.high-b.low,1e-20)-.5),
             efficiency=side*patterns._efficiency(hours), advance=side*(close-ref)/atr,
             tick_bps=tick/close*10000, turnover=math.log1p(market['turn4']),
             day_location=side*((close-lo)/max(hi-lo,1e-20)-.5), day_range=(hi-lo)/close*100,
             funding=-side*rate, funding_age=age, breadth=side*(benchmark['breadth']-.5))
    for h in HORIZONS:
        f['ret'+str(h)] = side*market[h]*100
        if h != 1:
            f['market'+str(h)] = side*benchmark[h]*100
            f['excess'+str(h)] = f['ret'+str(h)] - f['market'+str(h)]
    return f


def choose(original, decision, close, long_bps, short_bps):
    if not all(math.isfinite(v) for v in (long_bps, short_bps)):
        return None
    best = max(long_bps, short_bps)
    if best <= model()['entry_threshold_bps']:
        return None
    side = 1 if long_bps >= short_bps else -1
    distance = max(.007*close, min(.0225*close, 1.8*original['atr']))
    stop, target = close-side*distance, close+side*3*distance
    action = 'LONG' if side == 1 else 'SHORT'
    side_ko = '롱' if side == 1 else '숏'
    orig_ko = '롱' if original['action'] == 'LONG' else '숏'
    forecast = dict(model_sha256=MODEL_SHA256, original_action=original['action'],
                    original_ms=decision-QUARTER, long_bps=long_bps, short_bps=short_bps,
                    expected_net_bps=best, region_index=REGIMES.index(original['regime']))
    return dict(original, direction514=forecast, action=action, reference=close,
                confirmation_ms=decision-QUARTER, structural_stop=stop, target_price=target,
                exit_plan=dict(stop_price=stop, target_price=target, max_hold_bars=48,
                               bar_ms=QUARTER, resting_target=True),
                reason=f'원래 {orig_ko} 패턴 → 예측 {side_ko} · 비용 반영 기대수익률 {best/100:+.2f}%',
                conditions=[f'롱 {long_bps/100:+.3f}% · 숏 {short_bps/100:+.3f}%',
                            f'확인 종가 {close:.8g} · 손절 {stop:.8g} · 익절 {target:.8g}',
                            '원래 패턴 근거 · '+original['reason'], *original['conditions']])


def candidates(frames_by_symbol, contracts, decision, funding_for, market_frames=None):
    model()  # Validate the deployed weights even on a scan with zero setups.
    markets, benchmark = confirmed_market(frames_by_symbol if market_frames is None else market_frames, decision)
    ticks = {row['instId']: float(row['tickSz']) for row in contracts if row.get('tickSz')}
    passed = []
    stats = dict(patterns=0, below=0, missing=0)
    for symbol, market in markets.items():
        frames = frames_by_symbol.get(symbol)
        if not frames:
            continue
        # The research detector used a nominal 1bp spread on archived candles.
        # Current executable spread/depth are checked independently before each order.
        originals = patterns.evaluate(symbol, frames, decision-QUARTER, spread_bps=1.)
        if not originals:
            continue
        stats['patterns'] += len(originals)
        try:
            funding = funding_for(symbol)
            tick = ticks[symbol]
            if not math.isfinite(tick) or tick <= 0:
                raise ValueError('호가 단위 미확인')
        except (TimeoutError, ConnectionError, KeyError, ValueError, OSError):
            stats['missing'] += len(originals)
            continue
        for original in originals:
            scores = [score(inputs(original, frames, decision, market, benchmark, tick, funding, side))
                      for side in (1, -1)]
            choice = choose(original, decision, market['close'], *scores)
            if choice is None:
                stats['below'] += 1
            else:
                passed.append(choice)
    return passed, stats

@echo off
setlocal EnableExtensions DisableDelayedExpansion
echo Preparing OKX PC 3.4.2 in a clean folder...
set "OKX_REPAIR_PATH_FILE=%TEMP%\okx-repair-%RANDOM%-%RANDOM%.txt"
powershell.exe -NoLogo -NoProfile -Command "$ErrorActionPreference='Stop'; [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; $id=[Guid]::NewGuid().ToString('N'); $dir=Join-Path (Join-Path $env:LOCALAPPDATA 'OKXTradingPC-Launcher') $id; $zip=Join-Path $env:TEMP ($id+'.zip'); try { Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/ay530512-bot/okx-bot-update/54f976c5312a4db4756050681c03d55596c707ca/desktop/releases/okx_pc_r30402.zip' -OutFile $zip; if((Get-FileHash $zip -Algorithm SHA256).Hash -ne 'a536df5760d903a1e58356d773f71056947db663754fcd95f086a9b7ab18c704'){throw 'Download checksum mismatch'}; Expand-Archive -LiteralPath $zip -DestinationPath $dir; $pkg=Join-Path $dir 'OKX_PC_PACKAGE'; $m=Get-Content -LiteralPath (Join-Path $pkg 'pc_release.json') -Raw -Encoding UTF8 | ConvertFrom-Json; $items=@($m.files.psobject.Properties); $actual=@(Get-ChildItem -LiteralPath $pkg -Recurse -File -Force); if($actual.Count -ne ($items.Count+1)){throw 'Unexpected installation files'}; foreach($f in $items){if((Get-FileHash -LiteralPath (Join-Path $pkg $f.Name) -Algorithm SHA256).Hash -ne $f.Value){throw ('Invalid file: '+$f.Name)}}; [IO.File]::WriteAllText($env:OKX_REPAIR_PATH_FILE,$id,[Text.Encoding]::ASCII) } finally {if(Test-Path -LiteralPath $zip){Remove-Item -LiteralPath $zip}}"
if errorlevel 1 goto :failed
set /p "OKX_REPAIR_ID="<"%OKX_REPAIR_PATH_FILE%"
del "%OKX_REPAIR_PATH_FILE%"
call "%LOCALAPPDATA%\OKXTradingPC-Launcher\%OKX_REPAIR_ID%\OKX_PC_PACKAGE\PC_START.bat"
exit /b %ERRORLEVEL%
:failed
echo Setup stopped. The error is printed above.
pause
exit /b 1

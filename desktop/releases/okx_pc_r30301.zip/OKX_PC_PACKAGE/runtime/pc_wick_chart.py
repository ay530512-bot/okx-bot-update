"""15-minute chart frozen on the reaction trade. The Windows updater needs no new packages."""
from datetime import datetime
from decimal import Decimal
from functools import lru_cache
import gzip
import json
import math
from pathlib import Path
import struct
import zlib

from okx_pattern15 import band
from pc_wick_alert import KST, STEP, WINDOW, retest_window
from pc_wick_context import MIN_BARS, context, describe, visible_spans

WIDTH, HEIGHT = 1040, 670
BG = (16, 21, 29)
GRID = (45, 56, 69)
TEXT = (237, 242, 246)
MUTED = (164, 179, 193)
BAND = (116, 156, 212)
MID = (87, 110, 143)
UP = (66, 207, 164)
DOWN = (250, 119, 136)
MARK = (255, 192, 70)
FIRST = (201, 180, 255)
CLOUD_UP = (32, 65, 64)
CLOUD_DOWN = (68, 48, 61)


def visible_bars(signal):
    interval = signal.get('step_ms',STEP)
    age = (signal['ts']//interval*interval - signal['anchor_ms'])//interval
    limit = retest_window(signal['side']) * (2 if signal.get('neckline') is not None else 1)
    return max(WINDOW, min(age, limit)) + 5


def snapshot(symbol, hit, tick, rows):
    """Only closed bars strictly before this bucket and the trades observed through this hit."""
    interval = hit.get('step_ms',STEP)
    bucket = hit['ts'] // interval * interval
    closed = [tuple(row[:6]) for row in rows if row[0] + interval <= hit['ts']]
    cloud = []
    visible = visible_bars(hit)
    for i in range(max(MIN_BARS,len(closed)-visible+1),len(closed)+1):
        spans = visible_spans(closed[:i])
        if spans and interval == STEP:
            cloud.append((closed[i-1][0]+STEP,*spans))
    live = hit.get('chart_bar')
    return dict(step_ms=interval,frame_observation='frame_trigger' in hit,neckline=hit.get('neckline'),symbol=symbol, side=hit['side'], ts=hit['ts'], tick=str(tick),
                anchor_ms=hit['anchor_ms'], first=hit['first'], second=hit['second'],
                price=hit['price'], closed=closed[-(visible+19):], cloud=cloud,
                market_context=context(closed,hit,float(tick)) if interval == STEP else {},
                live=tuple(live) if live and live[0] == bucket else None)


def price_text(value, tick):
    places = max(0, -Decimal(str(tick)).normalize().as_tuple().exponent)
    return f'{value:.{places}f}'


def clock(stamp):
    return datetime.fromtimestamp(stamp/1000, KST)


def signal_time(chart):
    return clock(chart['ts']).strftime('%Y-%m-%d %H:%M:%S') + f".{chart['ts']%1000:03d} KST"


def caption_note(chart):
    name = chart['symbol']+' · ' if not chart['symbol'].isascii() else ''
    note = f"\n\n○ {name}진입 검토가 {price_text(chart['price'],chart['tick'])} USDT · {signal_time(chart)}"
    if chart.get('neckline') is not None:
        note += '\n스윙 돌파 기준가 '+price_text(chart['neckline'],chart['tick'])
    if chart.get('strategy_label'):
        note+='\n'+chart['strategy_label']+' · 마감 확인'
    elif 'anchor_ms' in chart:
        interval=chart.get('step_ms',STEP)
        count = (chart['ts']//interval*interval - chart['anchor_ms'])//interval
        note += f'\n첫 꼬리 이후 {count}번째 15분봉'
    if chart.get('market_context'):
        trend,pattern = describe(chart['market_context'])
        note += '\n'+trend+'\n'+pattern
    return note


@lru_cache(maxsize=1)
def typefaces():
    # Glyphs contain advance, left/top bearings, width, and an 8-bit coverage mask.
    path = Path(__file__).with_name('wick_chart_glyphs.json.gz')
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        data = json.load(stream)
    return {int(size): {c: (*spec[:4], bytes.fromhex(spec[4])) for c,spec in glyphs.items()}
            for size,glyphs in data.items()}


class Canvas:
    def __init__(self):
        self.pixels = bytearray(bytes(BG) * WIDTH * HEIGHT)

    def rect(self, x1, y1, x2, y2, color):
        left, right = max(0,round(x1)), min(WIDTH,round(x2)+1)
        if right <= left:
            return
        strip = bytes(color) * (right-left)
        for y in range(max(0,round(y1)), min(HEIGHT,round(y2)+1)):
            offset = (y*WIDTH + left)*3
            self.pixels[offset:offset+len(strip)] = strip

    def blend(self, x, y, color, alpha):
        if 0 <= x < WIDTH and 0 <= y < HEIGHT and alpha:
            pos = 3*(y*WIDTH + x)
            for j, value in enumerate(color):
                self.pixels[pos+j] += (value-self.pixels[pos+j])*alpha//255

    def line(self, x1, y1, x2, y2, color):
        steps = max(1, math.ceil(max(abs(x2-x1),abs(y2-y1))))
        for i in range(steps+1):
            x, y = x1+(x2-x1)*i/steps, y1+(y2-y1)*i/steps
            self.rect(x, y, x+1, y+1, color)

    def ring(self, x, y, radius, thickness, color):
        for py in range(round(y-radius-1), round(y+radius+1)+1):
            for px in range(round(x-radius-1), round(x+radius+1)+1):
                dist = math.hypot(px-x,py-y)
                cover = min(1, radius+.5-dist, dist-(radius-thickness-.5))
                if cover > 0:
                    self.blend(px,py,color,round(cover*255))

    def text(self, x, baseline, text, color=MUTED, size=20, align='left'):
        font = typefaces()[size]
        chars = [font.get(c,font['?']) for c in text]
        width = sum(g[0] for g in chars)
        if align == 'right':
            x -= width
        elif align == 'center':
            x -= width/2
        x = round(x)
        for advance, left, top, stride, mask in chars:
            for i, alpha in enumerate(mask):
                if alpha:
                    self.blend(x+left+i%stride,baseline+top+i//stride,color,alpha)
            x += advance

    def png(self, height=HEIGHT):
        def chunk(kind, data):
            return struct.pack('!I',len(data)) + kind + data + struct.pack('!I',zlib.crc32(kind+data))
        rows = bytearray()
        for offset in range(0, len(self.pixels), 3*WIDTH):
            rows.append(0)
            rows.extend(self.pixels[offset:offset+3*WIDTH])
        header = struct.pack('!2I5B',WIDTH,height,8,2,0,0,0)
        return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR',header) + chunk(b'IDAT',zlib.compress(rows,4)) + chunk(b'IEND',b'')


def render(chart, *, as_canvas=False):
    closed = chart['closed']
    interval = chart.get('step_ms',STEP)
    bucket = chart['ts']//interval*interval
    live = chart['live']
    # When an older producer supplies no trade range, render the real reference point alone.
    active = live or (bucket, None, None, None, chart['price'])
    rows = [*closed, active]
    first = max(0,len(rows)-visible_bars(chart))
    channels = [band(rows,j) if j >= 19 else None for j in range(first,len(rows))]
    bars = rows[first:]
    levels = [chart['first'],chart['second'],chart['price']]
    cloud = [p for p in chart.get('cloud',()) if bars[0][0]<=p[0]<=bucket]
    for _,a,b in cloud:
        levels.extend((a,b))
    for row, bounds in zip(bars,channels):
        if row[2] is not None:
            levels.extend((row[2],row[3]))
        if bounds:
            levels.extend(bounds)
    low, high = min(levels), max(levels)
    pad = max((high-low)*.115, float(chart['tick'])*2)
    low, high = max(0,low-pad), high+pad
    canvas = Canvas()
    left, right, top, bottom = 36, 843, 132, 439
    origin = bars[0][0]
    step = (right-left)/max(2,(bucket-origin)//interval+1)
    def xpos(stamp):
        return left + ((stamp-origin)/interval+.5)*step
    def ypos(price):
        return bottom-(price-low)/(high-low)*(bottom-top)

    symbol = chart['symbol'].removesuffix('-USDT-SWAP')+'/USDT'
    if not symbol.isascii():
        symbol = 'OKX USDT SWAP'  # The accompanying Telegram caption carries the exact Unicode instrument.
    side = '롱' if chart['side']==1 else '숏'
    title = '진입 검토가  '+price_text(chart['price'],chart['tick'])
    width = sum(typefaces()[36].get(c,typefaces()[36]['?'])[0] for c in symbol+title)
    title_size = 36 if width < WIDTH-105 else 24
    canvas.text(left, 52, symbol, TEXT, title_size)
    canvas.text(left, 91, f"{interval//60_000}분봉  ·  {chart.get('strategy_label') or ('재시험' if interval==300_000 else '모의 관찰' if chart.get('frame_observation') else '스윙 돌파' if chart.get('neckline') is not None else '두 꼬리')} {side}", TEXT, 24)
    canvas.text(WIDTH-32, 50, title, MARK, title_size, 'right')
    canvas.text(WIDTH-32, 91, signal_time(chart), MUTED, 24, 'right')
    canvas.rect(left,111,WIDTH-33,111,GRID)

    for (t,a,b),(t2,a2,b2) in zip(cloud,cloud[1:]):
        if t2-t!=interval:
            continue
        x0,x1 = round(xpos(t)),round(xpos(t2))
        for x in range(x0,x1+1):
            fraction = (x-x0)/max(1,x1-x0)
            first_span,second_span = a+(a2-a)*fraction,b+(b2-b)*fraction
            canvas.rect(x,ypos(max(first_span,second_span)),x,ypos(min(first_span,second_span)),
                        CLOUD_UP if first_span>=second_span else CLOUD_DOWN)
    for i in range(5):
        value = low+(high-low)*i/4
        y = ypos(value)
        canvas.rect(left,y,right,y,GRID)
        canvas.text(right+15,round(y)+7,price_text(value,chart['tick']))
    for j in range(0,len(bars),max(1,math.ceil(len(bars)/5))):
        row = bars[j]
        x = xpos(row[0])
        canvas.rect(x,top,x,bottom,GRID)
        if xpos(bucket)-x > 75:
            canvas.text(max(left+22,x),540,clock(row[0]).strftime('%H:%M'),align='center')
    canvas.text(xpos(bucket),540,clock(chart['ts']).strftime('%H:%M'),MARK,align='center')
    for i in range(1,len(bars)):
        if channels[i-1] and channels[i] and bars[i][0]-bars[i-1][0] == interval:
            for k in range(3):
                canvas.line(xpos(bars[i-1][0]),ypos(channels[i-1][k]),
                            xpos(bars[i][0]),ypos(channels[i][k]),MID if k==1 else BAND)
    half = max(2,min(9,round(step*.27)))
    max_volume = max([row[5] for row in bars[:-1]] or [0])
    for row in bars:
        if row[1] is None:
            continue
        stamp, op, high_px, low_px, close = row[:5]
        x = xpos(stamp)
        color = UP if close >= op else DOWN
        canvas.rect(x-1,ypos(high_px),x+1,ypos(low_px),color)
        body_top, body_bottom = sorted((ypos(op),ypos(close)))
        canvas.rect(x-half,body_top,x+half,max(body_top+2,body_bottom),color)
        # Only completed 15m volumes are known. A partial trade subscription has no full volume.
        if stamp != bucket and max_volume and row[5] > 0:
            volume_color = tuple((value+base)//2 for value,base in zip(color,BG))
            canvas.rect(x-half,511-45*row[5]/max_volume,x+half,511,volume_color)
    canvas.rect(left,513,right,513,GRID)
    canvas.text(right+15,505,'거래량')
    canvas.ring(xpos(chart['anchor_ms']),ypos(chart['first']),6,3,FIRST)
    mark_x, mark_y = xpos(bucket), ypos(chart['price'])
    for x in range(round(mark_x)+16,right+6,8):
        canvas.rect(x,mark_y,x+3,mark_y+1,MARK)
    canvas.ring(mark_x,mark_y,15,6,BG)
    canvas.ring(mark_x,mark_y,13,4,MARK)
    canvas.rect(left,561,WIDTH-33,561,GRID)
    canvas.ring(left+9,594,9,3,MARK)
    canvas.text(left+30,602,'진입 검토',TEXT,24)
    canvas.ring(243,594,6,3,FIRST)
    canvas.text(263,602,'신호봉 극값' if chart.get('strategy_label') else '첫 꼬리' if chart.get('neckline') is None else '직전 저점' if chart['side']==1 else '직전 고점',TEXT,24)
    canvas.rect(439,593,465,595,BAND)
    canvas.text(476,602,'볼린저밴드 (20, 2)',TEXT,24)
    if cloud:
        canvas.rect(722,581,745,597,CLOUD_UP)
        canvas.text(757,602,'일목구름',TEXT,24)
    canvas.text(left,644,'완료봉 종가에서 진입 검토' if chart.get('strategy_label') else '마지막 봉은 신호까지 수신한 체결 기준')
    return canvas if as_canvas else canvas.png()


def execution_photo(event, text, chart):
    """Use confirmed fill direction or the position's realized PnL in the persisted caption."""
    import re
    from decimal import InvalidOperation
    if event not in ('진입 체결','청산 손익','부분 청산 확인'):
        return None
    lines=text.splitlines()
    row=next((line for line in lines if '-USDT-SWAP' in line),'')
    symbol=(chart or {}).get('symbol') or row.split(' / ')[0]
    symbol=symbol.removesuffix('-USDT-SWAP')+'/USDT' if symbol else 'OKX'
    color=MUTED
    detail=''
    if event=='진입 체결':
        match=re.search(r' / (long|short) / ',row)
        side=(1 if match[1]=='long' else -1) if match else (chart or {}).get('side')
        title={1:'롱 진입',-1:'숏 진입'}.get(side,'진입 체결')
        color={1:UP,-1:DOWN}.get(side,MUTED)
    elif event=='부분 청산 확인':
        title='부분 청산'
    else:
        title='청산'
        for line in lines:
            match=re.fullmatch(r'수수료·펀딩 포함 실현손익 (\S+) USDT',line)
            if not match:
                continue
            try:
                pnl=Decimal(match[1])
            except InvalidOperation:
                continue
            if pnl.is_finite():
                title='수익 청산' if pnl>0 else '손실 청산' if pnl<0 else '본전 청산'
                color=UP if pnl>0 else DOWN if pnl<0 else MUTED
                detail=format(pnl,'+f') if pnl else '0'
                if '.' in detail: detail=detail.rstrip('0').rstrip('.')
                detail+=' USDT'
            break
    card=Canvas()
    height=172
    card.rect(0,0,WIDTH, height,tuple(int(c*.22) for c in color))
    card.rect(0,0,12,height,color)
    card.text(35,54,symbol,TEXT,36)
    card.text(35,138,title,color,60)
    if detail:
        size=60 if len(detail)<=17 else 36
        card.text(WIDTH-32,138,detail,color,size,'right')
    del card.pixels[height*WIDTH*3:]
    if chart:
        card.pixels.extend(render(chart,as_canvas=True).pixels)
        height+=HEIGHT
    return card.png(height)

"""Exit policies and display metadata for positions opened by earlier releases."""
from collections import namedtuple

from okx_core import BotError

Rule = namedtuple('Rule','label start end side stop target trail minutes')
EARLY_RULES = {
    'afternoon_vwap': Rule('거래량 가중평균 회귀 숏', 15, 18, -1, 2, 0, 1, 480),
    'evening_pullback': Rule('추세 눌림목 롱·숏', 18, 21, 0, 3, 3, 0, 1440),
    'late_reversal': Rule('저녁 확정반전 롱·숏', 21, 24, 0, 2.8, 0, 1, 720),
    'pullback': Rule('눌림목 숏', 0, 6, -1, 3, 3, 0, 1440),
    'failed_wick': Rule('두꼬리 실패 숏', 0, 3, -1, 3, 3, 0, 1440),
    'rank_short': Rule('전일 상승 상위 3개 숏', 0, 12, -1, 3, 3, 0, 1440),
    'trend_long': Rule('당일 상승 1위 추세 롱', 5, 8, 1, 2.5, 3, 0, 360),
    'reversal': Rule('확정반전 숏', 9, 12, -1, 2, 0, 1, 480),
    'two_wick': Rule('두꼬리 숏', 9, 15, -1, 2, 2, 0, 240),
}

HELD_RULES = {
    'reversal': Rule('확정반전 숏', 1, 4, -1, 2, 0, 1, 480),
    'two_wick': Rule('두꼬리 숏', 1, 7, -1, 2, 2, 1, 240),
    'afternoon_vwap': Rule('거래량 가중평균 회귀 숏', 7, 10, -1, 2, 0, 1, 480),
    'evening_pullback': Rule('추세 눌림목 롱·숏', 10, 13, 0, 3, 3, 1, 1440),
    'late_reversal': Rule('저녁 확정반전 롱·숏', 13, 16, 0, 2.8, 0, 1, 720),
    'failed_wick': Rule('두꼬리 실패 숏', 16, 19, -1, 3, 3, 1, 1440),
    'rank_short': Rule('전일 상승 상위 3개 숏', 16, 4, -1, 3, 3, 1, 1440),
    'trend_long': Rule('당일 상승 1위 추세 롱', 21, 24, 1, 2.5, 3, 1, 360),
    'pivot_long': Rule('15분 저점상승 음봉꼬리 롱', 8, 12, 1, 2, 0, 1, 60),
    'pivot_short': Rule('15분 고점하락 양봉꼬리 숏', 8, 12, -1, 2, 0, 1, 60),
    'scalp_double': Rule('두꼬리 롱', 4, 8, 1, 1.5, 3, 1, 15),
    'scalp_break': Rule('꼬리실패 롱', 10, 14, 1, 1.5, 2, 1, 30),
    'scalp_higher': Rule('새 음봉꼬리 롱', 8, 20, 1, 1.5, 3, 1, 30),
}

FILTER_LABELS = {
    'reclaim': '봉 안에서 진입 방향으로 55% 이상 회복 마감',
    'volume': '회복 마감 · 직전 20봉 평균 대비 거래량 1.6배 이상',
    'trend': '회복 마감 · EMA20과 그 기울기가 진입 방향과 일치',
    'momentum': '회복 마감 · 최근 4봉 이동 0.35 ATR 이상 · EMA20 추격 제한',
    'room': '회복 마감 · ATR이 종가의 0.45% 이상 · 상대 거래량 1.2배 이상',
}

def manage(e,snap,p,o):
    from okx_profit_guard714 import effective_stop
    s=o['v4_signal']
    from pc_intraday import due, CLOSE_REASON
    if due(o,e.api.now_ms()):
        e.close(snap,CLOSE_REASON)
        return True
    from pc_extra_entries import SHORT, TREND
    from pc_candidates import REVERSAL
    if s.get('pc217') == REVERSAL:
        side = 1 if o['direction']=='long' else -1
        if side*(float(p['markPx'])-effective_stop(o)) <= 0:
            e.close(snap,'반전 돌파 · 보호 손절')
            return True
        if not o.get('reversal_fill_ms'):
            opened = int(p.get('cTime') or 0)
            now = e.api.now_ms()
            o['reversal_fill_ms'] = opened if s['at_ms']<=opened<=now else now
            e.journal.save()
        if e.api.now_ms() >= o['reversal_fill_ms']+900_000:
            e.close(snap,'반전 돌파 · 체결 후 15분 전량 청산')
            return True
        return False
    if s.get('pc217') == 'five_reversal15':
        from pc_extra_entries import FIVE
        now = e.api.now_ms()
        first_open = s['at_ms']
        side = 1 if o['direction']=='long' else -1
        mark,entry = float(p['markPx']),float(p['avgPx'])
        if side*(mark-effective_stop(o)) <= 0:
            reason = '5분 반전 · 보호 손절'
        elif now >= first_open+2*FIVE:
            reason = '5분 반전 · 두 번째 봉 마감'
        elif now >= first_open+FIVE:
            bars = e.wick_feed.flow_cache.get(o['symbol'],())
            first = next((bar for bar in reversed(bars) if bar[0]==first_open),None)
            if first is None or side*(first[4]-entry) <= entry*float(o['cost_rate']):
                return False
            reason = '5분 반전 · 첫 봉 마감 예상 비용 차감 수익'
        else:
            return False
        e.close(snap,reason)
        return True
    if s.get('pc217') in (SHORT,TREND):
        side=1 if o['direction']=='long' else -1
        entry,mark=float(p['avgPx']),float(p['markPx'])
        if min(entry,mark)<=0:
            return False
        active=effective_stop(o)
        risk=side*(entry-s['stop'])
        move=side*(mark-entry)
        if side*(mark-active)<=0 or risk<=0:
            e.close(snap,'보호 손절선 도달')
        elif s['pc217']==TREND:
            from pc_sizing import round_stop
            tick=s['decision_record']['volume_wick_proof']['tick']
            stop=round_stop(entry*(1-side*.01),tick,side)
            if move>=entry*.01-1e-12 or side*(mark-stop)<=0:
                e.close(snap,'추세 합의 · 체결가 기준 1% 익절·손절')
            elif side*(stop-active)>tick*1e-6:
                e.trail(snap,p,o,stop)
            else:
                return False
        elif e.api.now_ms()-o['entry_ms']>=150*60000:
            e.close(snap,'오전 반전 숏 · 150분 보유 만료')
        elif move>=2.5*risk and side*(mark-side*1.5*risk-active)>0:
            e.trail(snap,p,o,mark-side*1.5*risk)
        else:
            return False
        return True
    if s.get('monthly208'):
        rule=(HELD_RULES if s.get('pc211') else EARLY_RULES)[s['monthly208']]
        side = rule.side
        if not side:
            if s.get('action') not in ('LONG', 'SHORT'):
                raise BotError('기존 포지션 방향 확인 필요')
            side = 1 if s['action'] == 'LONG' else -1
        if s.get('pc250'):
            rule=rule._replace(target=0,trail=1,minutes=s['holding_rule']['max_hold_seconds']//60)
    else:
        side = 1 if o['direction']=='long' else -1
        label = '15분봉 두 꼬리' if s.get('pc_wick280') else '수동 진입' if s.get('click716') else '복원 규칙'
        duration = e.cfg['risk'].get('profit_guard714',{}).get('max_hold_seconds',21600)//60
        if s.get('pc_wick280') and 'kst_close_ms' not in s:
            duration = s['holding_rule']['max_hold_seconds']//60
        rule = Rule(label,0,0,side,0,0,1,duration)
    mark=float(p['markPx']);entry=float(p['avgPx']);risk=side*(entry-s['stop'])
    if min(mark,entry)<=0:return False
    move=(mark-entry)*side
    stop=effective_stop(o)
    if side*(mark-stop)<=0:
        reason=f'보호 손절선 도달 · 관리 기준 {stop:.10g}'
    elif risk<=0:
        reason='최초 손절가와 진입 방향 불일치'
    elif rule.target and move>=rule.target*risk:
        reason=f'목표가 도달 · {entry+side*rule.target*risk:.10g}'
    elif 'kst_close_ms' not in s and e.api.now_ms()-o['entry_ms']>=rule.minutes*60000:
        reason=f'최대 보유시간 {rule.minutes}분 만료 · 관리 손절선 {stop:.10g}'
    else:
        reason=None
    if reason:
        e.close(snap,f'{rule.label} · {reason} · 판단 마크가 {mark:.10g}')
        return True
    if rule.trail and move>=risk:
        target=mark-side*risk
        if side*(target-effective_stop(o))>0:
            e.trail(snap,p,o,target);return True
    return False

def note_fill(data,s):
    key=s['monthly208']
    if key not in ('scalp_double','scalp_break','scalp_higher'):return
    bucket=data.setdefault('scalp_filled',{});d=(s['valid_from_ms']+9*3600000)//86400000
    state=bucket.get(key)
    if not state or state['day']<d:state=bucket[key]={'day':d,'ids':[]}
    if state['day']==d and s['signal_id'] not in state['ids']:state['ids'].append(s['signal_id'])

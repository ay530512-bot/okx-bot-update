"""Read-only entry evidence from the persisted decision; no strategy inference."""
import math
from datetime import datetime
from okx_core import KST

NAMES = {'top1_ema20_support170': '상승1위 EMA20 지지 반등', 'trend_pullback': '눌림목', 'exhaustion724': '확정반전',
         'double_wick20_failed_long': '두꼬리 20% 롱 실패 후 숏',
         'double_wick': '두꼬리', 'top1_15kst_dip130': '상승률 1위 추세 롱',
         'top1_morning_failed_rebound150': '오전 상승률 1위 숏',
         'prior_top3_indicator_short206': '전일 상승 상위 3종목 숏',
         'prior_top3_night_short207': '전일 상승 상위 3종목 야간 숏'}


from pc_held_labels import NEW, RULES
NAMES.update(RULES)
from pc_held_positions import HELD_RULES, FILTER_LABELS
NAMES.update({"m208_"+r:v.label for r,v in HELD_RULES.items()})
NAMES['bb_wick_retest_15m'] = '15분봉 볼린저밴드 두 꼬리'

def number(value):
    try:
        n = float(value)
        return n if math.isfinite(n) else None
    except (ValueError, TypeError, OverflowError):
        return None


def describe(record):
    s = record.get('v4_signal') or {}
    proof = (s.get('decision_record') or {}).get('volume_wick_proof') or {}
    route = proof.get('route721')
    side = record.get('direction')
    out = dict(rule=NAMES.get(route, '진입 규칙 기록 없음'), route=route if route in NAMES else None,
               summary='저장된 조건 기록 없음', evidence=[], entry_ms=record.get('entry_ms'),
               confirmed_ms=s.get('valid_from_ms'), frame=s.get('setup_frame'),
               source='persisted_entry_decision')
    if s.get('kst_close_ms') is not None:
        deadline = datetime.fromtimestamp(s['kst_close_ms']/1000,KST)
        out['evidence'].append(dict(label='당일 전량 청산 (KST)',value=deadline.strftime('%m-%d %H:%M')))
    from okx_position_history import entry_method
    if entry_method(record)=='manual':
        return dict(out,rule='수동 진입',route=None,summary='사용자 주문 · 프로그램 보호 관리',source='manual')
    if not proof or side not in ('long', 'short') or proof.get('action') != side.upper():
        out.update(rule='진입 규칙 기록 없음', route=None)
        return out
    if s.get('monthly208') in HELD_RULES:
        v=HELD_RULES[s['monthly208']]
        out['summary']=f'{v.label} · KST {v.start:02}:00~{v.end:02}:00 · 상대 거래량 {proof.get("relative_volume",0):.2f}배'
        hold=v.minutes
        if s.get('pc250'):
            entry=s['holding_rule'];start,end=entry['kst_window'];hold=entry['max_hold_seconds']//60
            out['summary']=f'{v.label} · KST {start:02}:00~{end:02}:00 · 최대 {hold}분'
            out['evidence'].append(dict(label='진입 확인',value=FILTER_LABELS[entry['timing_filter']]))
            ev=proof['timing']
            if s.get('pc260'):
                out['evidence'].append(dict(label='진입 배율',value=f"{s['leverage']}배"))
                if ev.get('first_wick') is not None:
                    out['evidence'].extend([dict(label='첫 꼬리 기준가',value=f"{ev['first_wick']:.10g}"),
                                            dict(label='두 번째 꼬리',value=f"{ev['second_wick']:.10g}")])
            for label,k in [('손절 기준 고저점','anchor'),('변동성 여유 폭','pad'),('ATR','atr'),('거래량 배수','rv')]:
                out['evidence'].append(dict(label=label,value=f'{ev[k]:.8g}'))
        for label,price in [('최초 전략 손절가',s.get('stop')),('기록된 보호 손절가',record.get('stop_px'))]:
            if number(price) and number(price)>0:
                out['evidence'].append(dict(label=label,value=f'{float(price):.10g}'))
        if record.get('entry_ms'):
            deadline=datetime.fromtimestamp(record['entry_ms']/1000+hold*60,KST)
            out['evidence'].append(dict(label='최대 보유 만료 (KST)',value=deadline.strftime('%m-%d %H:%M:%S')))
        return out
    rows = out['evidence']
    def value(label, v, style='number'):
        n = number(v)
        if n is not None:
            text = f'{n*100:.1f}%' if style == 'pct' else f'{n:.2f}배' if style == 'ratio' else f'{n:.8g}'
            rows.append(dict(label=label, value=text))
    c = proof.get('confirmation721') or {}
    rank = (s.get('decision_record') or {}).get('rank130') or (s.get('decision_record') or {}).get('rank150') or {}
    rank_label = '현재가 상승률 1위' if rank.get('basis') == 'kst09_live' else '완료1시간봉 상승률 1위'
    if route in NEW or s.get('pc217') in RULES:
        out['summary']=RULES[route]+' · 자동 '+('롱' if side=='long' else '숏')
        value('진입 검토가',proof.get('reference'))
        value('최초 손절가',proof.get('structural_stop'))
        if route in NEW:
            value('마감 확인 기준가',proof.get('second_wick'))
    elif route == 'bb_wick_retest_15m':
        out['summary'] = ('두 번째 높은 저점에서 반등 · 자동 롱' if side=='long' else
                          '두 번째 낮은 고점에서 반락 · 자동 숏')
        value('첫 꼬리',proof.get('first_wick'))
        value('두 번째 꼬리',proof.get('second_wick'))
        if proof.get('market_context'):
            from pc_wick_context import describe as describe_context
            trend,pattern = describe_context(proof['market_context'])
            rows.extend((dict(label='진입 시점 일목·RSI',value=trend),dict(label='확정 차트 패턴',value=pattern)))
            if proof.get('timing_label'):
                rows.append(dict(label='주문을 검토한 체결',value=proof['timing_label']))
    elif route == 'trend_pullback':
        touched = [str(x) for x in proof.get('ma_touched721', []) if type(x) is int and 0 < x <= 1000]
        out['summary'] = ('하락' if side == 'short' else '상승')+' 추세 · 이평선 재확인 후 완료봉 진입'
        if touched: rows.append(dict(label='재확인 이평선', value=' / '.join('MA'+x for x in touched)))
    elif route == 'exhaustion724':
        out['summary'] = ('확장봉 후 음봉·윗꼬리·RSI 하락 확인' if side == 'short'
                          else '확장봉 후 양봉·아랫꼬리·RSI 상승 확인')
        value('확인봉 꼬리', c.get('wick_fraction'), 'pct')
        value('종가 강도', c.get('close_strength'), 'pct')
        value('확인봉 RSI', c.get('rsi14'))
    elif route == 'double_wick':
        detail = proof.get('pattern_details') or {}
        out['summary'] = '연속 윗꼬리 · 고점 미돌파 확인' if side == 'short' else '연속 아랫꼬리 · 저점 미갱신 확인'
        for i, v in enumerate((detail.get('wicks') or [])[:2]): value(f'{i+1}차 꼬리 비율', v, 'pct')
        if side == 'short':
            value('직전 고점', detail.get('prior_high')); value('확인봉 고점', detail.get('second_high'))
        else:
            value('직전 저점', detail.get('prior_low')); value('확인봉 저점', detail.get('second_low'))
    elif route == 'top1_ema20_support170':
        out['summary'] = rank_label+' · 상승 EMA20 접촉 후 지지 회복'
        value('EMA20', proof.get('ema20')); value('접촉 저가', proof.get('support_low'))
        rows.append(dict(label='신호 확인',value='실시간 접촉·회복' if proof.get('mode')=='live' else '확정봉 지지 반등'))
    elif route == 'top1_15kst_dip130':
        out['summary'] = rank_label+' · 돌파 후 눌림 확인'
        value('눌림 기준가', proof.get('dip_level')); value('돌파 기준가', proof.get('channel_high'))
    elif route == 'prior_top3_night_short207':
        decision = s.get('decision_record') or {}
        out['summary'] = '전일 상승률 '+str(rank.get('rank','—'))+'위 · 15분봉 전일 종가 이탈'
        value('전일 종가', proof.get('prior_close'))
        value('RSI(14)', proof.get('rsi14'))
        value('거래량 배수', proof.get('relative_volume'), 'ratio')
        value('직전 정산 펀딩률', (decision.get('settled_funding') or {}).get('rate'), 'pct')
        value('하락 점수', decision.get('bearish_score'))
    elif route == 'prior_top3_indicator_short206':
        out['summary'] = '전일 상승률 '+str(rank.get('rank','—'))+'위 · 15분 EMA20 하락 및 최근 저점 이탈'
        value('EMA20', proof.get('ema20')); value('RSI(14)', proof.get('rsi14'))
        value('거래량 배수', proof.get('relative_volume'), 'ratio')
        value('이탈 기준 저점', proof.get('breakdown_level'))
    elif route == 'top1_morning_failed_rebound150':
        out['summary'] = rank_label+' · 큰 눌림 후 반등 실패'
        value('고점 대비 눌림', proof.get('pullback_pct'), 'pct')
        value('직전 고점', proof.get('peak')); value('반등 고점', proof.get('rebound_high'))
    value('거래량 배수', c.get('volume_ratio', proof.get('context_volume')), 'ratio')
    value('1시간 추세효율', proof.get('hourly_efficiency724', proof.get('context_er')))
    value('진입 기준가', s.get('entry_reference', proof.get('reference')))
    value('최초 손절가', proof.get('structural_stop'))
    return out


def install():
    import okx_dashboard_data as dashboard
    original = dashboard.dashboard_snapshot
    if getattr(original, '_phone_entry_details', False): return
    def snapshot(snapshot, records, *args, **kwargs):
        out = original(snapshot, records, *args, **kwargs)
        by_key = {(r['symbol'], r['direction']): r for r in records}
        for row in out['positions']:
            record = by_key.get((row['symbol'], row['direction']))
            try:
                row['entry_details'] = describe(record) if record is not None else dict(
                    rule='수동 진입', summary='자동 규칙 적용 없음', evidence=[], source='manual')
            except (TypeError,ValueError,AttributeError,KeyError,OverflowError):
                row['entry_details'] = dict(rule='진입 규칙 기록 확인 필요',
                    summary='저장된 조건을 읽지 못했습니다.', evidence=[], source='unavailable')
            if record and record.get('manual_reductions167'):
                pending = bool(record.get('external_reduction167')) or not record.get('protection_verified')
                row['partial_note'] = ('수동 부분청산 후 전량 청산 확인 중' if record.get('phase')=='closing' else
                                       '수동 부분청산 · 잔량 보호 대조 중' if pending else
                                       '수동 부분청산 · 잔량 자동 관리 중')
                previous_note = row.get('protection_note', '')
                row['protection_note'] = (previous_note.replace('잔량 보호 중', row['partial_note'])
                    if '잔량 보호 중' in previous_note else row['partial_note'])
                row['partial_price'] = None
                row['entry_details']['evidence'].append(dict(label='수동 청산 후 잔량',
                                                            value=str(record['quantity'])+'계약'))
        return out
    snapshot._phone_entry_details = True
    dashboard.dashboard_snapshot = snapshot

"""Read-only quarter-hour OKX market comparison for Telegram."""
import logging
import math
import statistics
import threading
import time
from datetime import datetime, timedelta, timezone

from okx_oct23 import allowed

FRAMES = {'1m': 1, '5m': 5, '15m': 15, '1H': 60, '4H': 240}
KST = timezone(timedelta(hours=9))
QUARTER = 900


def stamp(seconds):
    return datetime.fromtimestamp(seconds, KST).strftime('%m-%d %H:%M:%S')


def candidates(instruments, ticks, cfg, now):
    ranks = []
    contracts = {i['instId']: i for i in instruments if allowed(i, cfg)}
    for row in ticks:
        symbol = row['instId']
        if symbol in contracts and float(row['open24h'] or 0) > 0:
            if abs(now - int(row['ts'])) > 90000:
                raise ValueError('등락률 시세 지연')
            change = float(row['last']) / float(row['open24h']) - 1
            ranks.append((change, symbol))
    ranks.sort()
    if len(ranks) < 10:
        raise ValueError('순위 자료 부족')
    return [contracts[symbol] for _, symbol in ranks[:5] + ranks[-5:]]


def bars(data, minutes, cutoff):
    step = minutes * 60000
    rows = sorted((int(r[0]), *map(float,r[1:5])) for r in data
                  if r[8]=='1' and int(r[0])+step <= cutoff)
    if len(rows)<20 or rows[-1][0] != cutoff//step*step-step or any(
            b[0]-a[0]!=step for a,b in zip(rows[-20:-1],rows[-19:])):
        raise ValueError('확정봉 누락')
    return rows[-20:]


def evaluate(instrument, frames, book):
    bids, asks = book['bids'], book['asks']
    bid, ask = float(bids[0][0]), float(asks[0][0])
    if not 0 < bid <= ask:
        raise ValueError('호가 오류')
    mid = (ask+bid)/2
    spread = (ask-bid)/mid
    scale = float(instrument['ctVal'])
    depth = min(sum(float(p)*float(q)*scale for p,q,*_ in levels if abs(float(p)/mid-1)<=.001)
                for levels in (bids,asks))
    moves = {}
    for frame, rows in frames.items():
        closes = [r[4] for r in rows]
        atr = statistics.mean(max(r[2]-r[3],abs(r[2]-prev[4]),abs(r[3]-prev[4])) for prev,r in zip(rows,rows[1:]))
        moves[frame] = max(-1,min(1,(statistics.mean(closes[-3:])-statistics.mean(closes[-12:]))/max(atr,mid*1e-8)))
    rows=frames['15m']
    support=min(r[3] for r in rows[-5:])
    resistance=max(r[2] for r in rows[-5:])
    tick=float(instrument['tickSz'])
    options=[]
    for side in (1,-1):
        live=ask if side==1 else bid
        edge=frames['5m'][-1][2 if side==1 else 3]
        entry=max(live,edge+tick) if side==1 else min(live,edge-tick)
        stop=support-tick if side==1 else resistance+tick
        risk=side*(entry-stop)
        if risk<=0 or stop<=0: continue
        targets=[r[2 if side==1 else 3] for r in rows]
        ahead=[x for x in targets if side*(x-entry)>tick]
        target=min(ahead,key=lambda x:abs(x-entry)) if ahead else entry+side*1.5*risk
        if target<=0: continue
        rr=side*(target-entry)/risk
        trend=sum(w*side*moves[k] for k,w in zip(FRAMES,(.5,1.5,1.5,2,1.5)))
        score=trend+min(2,rr)-min(3,spread*2000)-min(2,abs(live-frames['1m'][-1][4])/risk)+min(1,math.log1p(depth)/15)
        fmt=lambda x:f'{x:.10g}'
        labels=' · '.join(k+(' ↑' if m>.1 else ' ↓' if m<-.1 else ' →') for k,m in moves.items())
        zone=sorted((entry,entry+side*min(.1*risk,.2*abs(target-entry))))
        options.append((score,f"{instrument['instId']} {'🟢 롱' if side==1 else '🔴 숏'} 후보\n호가 확인 {stamp(int(book['ts'])/1000)} KST · {fmt(live)}\n진입 조건: 5분 {'고가 위 유지' if side==1 else '저가 아래 유지'} · {fmt(zone[0])}~{fmt(zone[1])}\n손절 {fmt(stop)} · 1차 목표 {fmt(target)}{' (위험거리 1.5배)' if not ahead else ''}\n{labels}\n15분 지지 {fmt(support)} / 저항 {fmt(resistance)} · 호가차 {spread:.3%}"))
    return max(options)


def report(session, cfg, slot):
    def get(path, **params):
        for attempt in range(2):
            r=session.get('https://www.okx.com/api/v5/'+path,params=params,timeout=(4,6))
            if r.status_code==429 and not attempt:
                time.sleep(1)
                continue
            r.raise_for_status()
            data=r.json()
            if data['code']!='0': raise ValueError('OKX 자료 요청 실패')
            return data['data']
    instruments=get('public/instruments',instType='SWAP')
    ticks=get('market/tickers',instType='SWAP')
    chosen=candidates(instruments,ticks,cfg,time.time()*1000)
    history={}
    for i in chosen:
        symbol=i['instId']
        history[symbol]={}
        for f,minutes in FRAMES.items():
            history[symbol][f]=bars(get('market/candles',instId=symbol,bar=f,limit=32),minutes,slot*1000)
            time.sleep(.12)
    options=[]
    for i in chosen:
        book=get('market/books',instId=i['instId'],sz=50)[0]
        if abs(time.time()*1000-int(book['ts']))>10000: raise ValueError('호가 지연')
        options.append(evaluate(i,history[i['instId']],book))
    score,msg=max(options)
    return msg


def start(notifier,cfg):
    if not notifier.enabled: return
    def run():
        import requests
        with requests.Session() as session:
            while not notifier.stop_event.is_set():
                slot=int(time.time())//QUARTER*QUARTER
                key=str(slot)
                if time.time()-slot<180 and notifier.data['states'].get('15분 후보',{}).get('value')!=key:
                    try:
                        if notifier.stop_event.wait(2): return
                        msg=report(session,cfg,slot)
                    except Exception as exc:
                        logging.warning('15분 후보 시세 확인 실패: %s',exc)
                        msg='데이터 확인 불가 · '+(str(exc)[:100] if isinstance(exc,ValueError) else 'OKX 공개 시세 통신 실패')
                    if time.time()<slot+QUARTER and not notifier.stop_event.is_set():
                        try:
                            notifier._enqueue('15분 후보',f'[OKX 15분 분석] {stamp(slot)} KST\n'+msg,key)
                        except OSError:
                            logging.exception('15분 분석 저장 실패')
                notifier.stop_event.wait(max(1,slot+QUARTER-time.time()))
    threading.Thread(target=run,daemon=True,name='quarter-pick').start()

"""Keep position and manual-entry quotes subscribed across display updates."""
import threading


class Registry:
    def __init__(self, e):
        self.e = e; self.stream = e.stream; self.original = e.stream.update_watch
        self.lock = threading.RLock(); self.requested = set()
        self.stream.update_watch = self.update

    def publish(self):
        # Short critical section only. Underlying stream never performs I/O here.
        priority = {o['symbol'] for o in self.e.records()}
        for request in (getattr(self.e, 'click_pending716', None), getattr(self.e, 'executing_signal', None)):
            if request:
                priority.add(request['symbol'])
        wick = getattr(self.e,'wick_entries',None)
        if wick:
            priority.update(wick.quote_symbols())
        relay=getattr(self.e,'hourly_relay',None)
        plan=relay.offer if relay else None
        if plan and plan['hour']<=self.e.api.now_ms()<plan['hour']+3600000:
            priority.add(plan['symbol'])
        quarter=getattr(relay,'quarter_offer',None)
        if quarter and self.e.api.now_ms() <= quarter['issued']+90000:
            priority.add(quarter['symbol'])
        keep = set(self.requested) | priority
        if wick:
            keep.update(wick.warm)
        with self.stream.lock:
            self.stream._phone_priority_symbols = frozenset(priority)
        self.original(sorted(keep), monitor=False)

    def update(self, symbols, monitor=False):
        if monitor: return self.original(symbols, monitor=True)
        with self.lock:
            self.requested = set(symbols)
            self.publish()


def attach(e):
    e.phone_quote_registry = Registry(e)


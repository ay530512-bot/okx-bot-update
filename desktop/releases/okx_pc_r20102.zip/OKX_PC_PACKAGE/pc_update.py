"""Authenticated dashboard updates for the supervised Windows runner."""
from contextlib import contextmanager
import copy
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets
import socket
import subprocess
import sys
import tempfile
import threading
import time
from urllib.request import build_opener, HTTPRedirectHandler, Request
import zipfile

BASE = 'https://raw.githubusercontent.com/ay530512-bot/okx-bot-update/'
CHANNEL = BASE + 'main/desktop/pc_latest.json'
MAX_ZIP = 24 * 1024 * 1024
MAX_EXPANDED = 80 * 1024 * 1024
RESTART = 42
PACKAGE_DIR = 'OKX_PC_PACKAGE'
STAGE_NAME = re.compile(r'r[1-9][0-9]{0,6}-[0-9a-f]{16}')
TOKEN = re.compile(r'[0-9a-f]{32}')


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('업데이트 주소가 변경되었습니다.')


def fetch(url, limit):
    with build_opener(NoRedirect()).open(Request(url, headers={'Cache-Control': 'no-cache',
                                                                'User-Agent': 'OKX-PC-Updater/1'}),
                                         timeout=12) as response:
        raw = response.read(limit + 1)
        if len(raw) > limit:
            raise ValueError('업데이트 파일 크기 제한을 초과했습니다.')
        return raw


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', dir=path.parent, delete=False) as out:
        temp = Path(out.name)
        try:
            json.dump(value, out, ensure_ascii=False)
            out.flush()
            os.fsync(out.fileno())
        except BaseException:
            out.close()
            temp.unlink(missing_ok=True)
            raise
    try:
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def package_manifest(package):
    return read_json(package / 'pc_release.json')


def verify_manifest(data, revision):
    if (not isinstance(data, dict) or data.get('format') != 1
            or type(data.get('revision')) is not int or not 1 <= data['revision'] < 10_000_000
            or not re.fullmatch(r'[0-9a-f]{40}', str(data.get('commit', '')))
            or not re.fullmatch(r'[0-9a-f]{64}', str(data.get('sha256', '')))
            or type(data.get('bytes')) is not int or not 0 < data['bytes'] <= MAX_ZIP
            or not isinstance(data.get('version'), str) or len(data['version']) > 60
            or not isinstance(data.get('notes'), str) or len(data['notes']) > 1000):
        raise ValueError('PC 업데이트 배포 정보 형식이 맞지 않습니다.')
    return data if data['revision'] > revision else None


def valid_member(name):
    path = PurePosixPath(name)
    if path.as_posix() != name or path.parts[:1] != (PACKAGE_DIR,) or len(path.parts) < 2:
        return False
    for part in path.parts[1:]:
        if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*', part) or part.endswith('.'):
            return False
        if re.fullmatch(r'(CON|PRN|AUX|NUL|COM[0-9]|LPT[0-9])', part.split('.')[0], re.I):
            return False
    return True


def verify_package(package):
    manifest = package_manifest(package)
    files = manifest['files']
    required = {'pc_run.py', 'pc_update.py', 'pc_speed.py', 'requirements-pc.txt',
                'core/okx_v5.py', 'runtime/phone_host.py'}
    actual = {p.relative_to(package).as_posix() for p in package.rglob('*')
              if p.is_file() and '__pycache__' not in p.relative_to(package).parts}
    if not required <= set(files) or actual != set(files) | {'pc_release.json'}:
        raise ValueError('설치 파일 목록이 다릅니다. ZIP을 새 폴더에 풀어 주세요.')
    for name, digest in files.items():
        if not valid_member(PACKAGE_DIR + '/' + name):
            raise ValueError('설치 파일 경로가 다릅니다.')
        path = package / name
        if (path.is_symlink() or any(p.is_symlink() for p in path.parents if p != package)
                or hashlib.sha256(path.read_bytes()).hexdigest() != digest):
            raise ValueError('설치 파일 확인 실패 · ' + name)
    return manifest


def download_stage(root, package, manifest, download=fetch):
    asset = f"desktop/releases/okx_pc_r{manifest['revision']}.zip"
    raw = download(BASE + manifest['commit'] + '/' + asset, manifest['bytes'])
    if len(raw) != manifest['bytes'] or hashlib.sha256(raw).hexdigest() != manifest['sha256']:
        raise ValueError('업데이트 파일 해시가 일치하지 않습니다.')
    staging = root / 'pc_versions'
    staging.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(dir=staging) as temp:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            members = archive.infolist()
            names = [entry.filename.casefold() for entry in members]
            if (len(names) > 2000 or len(names) != len(set(names))
                    or sum(entry.file_size for entry in members) > MAX_EXPANDED
                    or any(entry.is_dir() or not valid_member(entry.filename) for entry in members)):
                raise ValueError('업데이트 ZIP 내부 경로를 확인할 수 없습니다.')
            for entry in members:
                target = Path(temp).joinpath(*PurePosixPath(entry.filename).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(entry))
        candidate = Path(temp) / PACKAGE_DIR
        new = verify_package(candidate)
        old = package_manifest(package)
        if (new.get('revision') != manifest['revision'] or new.get('version') != manifest['version']
                or new.get('launcher_protocol') != old.get('launcher_protocol')
                or (candidate / 'requirements-pc.txt').read_bytes() != (package / 'requirements-pc.txt').read_bytes()):
            raise ValueError('이 버전은 PC 설치 파일에서 적용해야 합니다.')
        name = f"r{manifest['revision']}-{secrets.token_hex(8)}"
        candidate.rename(staging / name)
    return name


def resolve_stage(root, name):
    if not isinstance(name, str) or not STAGE_NAME.fullmatch(name):
        raise ValueError('잘못된 PC 버전 경로입니다.')
    folder = root / 'pc_versions' / name
    if folder.is_symlink() or not folder.is_dir():
        raise ValueError('설치할 PC 버전 폴더가 없습니다.')
    return folder


def signal_ready(root):
    token = os.environ.get('OKX_PC_SUPERVISOR', '')
    if TOKEN.fullmatch(token):
        atomic_json(root / 'pc_child_ready.json', {'token': token})


@contextmanager
def launcher_lock():
    with socket.socket() as s:
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        try:
            s.bind(('127.0.0.1', 48737))
        except OSError:
            raise ValueError('PC_START가 이미 실행 중입니다.') from None
        yield


def supervise(root, bootstrap, args, launch=subprocess.Popen):
    pointer = root / 'pc_current.json'
    handoff = root / 'pc_update_handoff.json'
    ready = root / 'pc_child_ready.json'
    result = root / 'pc_update_result.json'

    def is_ready():
        try:
            return read_json(ready).get('token') == token
        except (OSError, ValueError):
            return False

    def commit_ready():
        nonlocal pending
        if pending and is_ready():
            atomic_json(pointer, {'folder': pending})
            pending = None
            atomic_json(result, {'message': f"{package_manifest(current)['version']} 설치 완료"})

    with launcher_lock():
        current = bootstrap
        try:
            saved = resolve_stage(root, read_json(pointer)['folder'])
            if package_manifest(saved)['revision'] >= package_manifest(bootstrap)['revision']:
                current = saved
        except (OSError, ValueError, KeyError, TypeError):
            pass
        previous = current
        pending = None
        while True:
            token = secrets.token_hex(16)
            ready.unlink(missing_ok=True)
            handoff.unlink(missing_ok=True)
            env = dict(os.environ, OKX_PC_SUPERVISOR=token)
            interrupted = False
            try:
                child = launch([sys.executable, '-B', '-X', 'utf8', str(current / 'pc_run.py'), 'start', *args],
                               env=env)
            except OSError:
                if pending is None:
                    raise
                code = 1
            else:
                while True:
                    try:
                        code = child.wait(timeout=.20)
                        break
                    except subprocess.TimeoutExpired:
                        commit_ready()
                    except KeyboardInterrupt:
                        interrupted = True  # The console signal also reaches the child.
                commit_ready()
            if interrupted:
                return code
            if pending:
                atomic_json(result, {'message': '새 버전 시작 실패 · 기존 버전으로 복귀했습니다.'})
                current, pending = previous, None
                continue
            if code != RESTART:
                return code
            request = read_json(handoff)
            if request.get('token') != token:
                raise ValueError('이 실행기의 업데이트 요청을 확인하지 못했습니다.')
            previous, pending = current, request['folder']
            current = resolve_stage(root, pending)


def position_handover(journal, snapshot, algos):
    """Reconcile managed protection and carry independent exchange positions through read-only."""
    from phone_handover import digest, number, records, validate_protected

    managed = {(r['symbol'], r['direction']) for r in records(journal)}
    external = {}
    positions = []
    for row in snapshot['positions']:
        if not number(row.get('pos', '0')):
            continue
        key = (row['instId'], row['posSide'])
        if key in managed:
            positions.append(row)
        else:
            external.setdefault(key, []).append({
                field: row.get(field) for field in ('instId', 'posSide', 'posId', 'mgnMode', 'pos', 'avgPx')
            })

    # Delegate every managed position, its orders and all unassociated algos
    # to the original strict validator. Keep external stops at the exchange.
    managed_algos = []
    external_facts = [digest(row) for rows in external.values() for row in rows]
    for algo in algos:
        if (algo.get('instId'), algo.get('posSide')) in external:
            external_facts.append(digest({key: value for key, value in algo.items()
                                          if key not in ('last', 'markPx', 'lastPx', 'idxPx')}))
        else:
            managed_algos.append(algo)
    protected = validate_protected(journal, dict(snapshot, positions=positions), managed_algos)
    return digest([protected, sorted(external_facts)])


class PCUpdater:
    def __init__(self, root, mobile):
        self.root, self.mobile = root, mobile
        self.package = Path(__file__).resolve().parent
        self.release = package_manifest(self.package)
        self.token = os.environ.get('OKX_PC_SUPERVISOR', '')
        self.lock = threading.RLock()
        self.installing = False
        self.ticket = None
        self.busy = False
        self.restart = False
        self.message = 'PC 새 버전 확인'
        if TOKEN.fullmatch(self.token):
            try:
                self.message = read_json(root / 'pc_update_result.json')['message']
            except (OSError, ValueError, KeyError):
                pass

    def snapshot(self):
        with self.lock:
            data = dict(busy=self.busy, message=self.message, display_version=self.release['version'],legacy_entries207=bool(getattr(self,'engine',None) and self.engine.journal.data.get('legacy_entries207')))
            if self.ticket and time.monotonic() < self.ticket[1]:
                manifest = self.ticket[3]
                data.update(ticket=self.ticket[0], target_version=manifest['version'], notes=manifest['notes'])
            return data

    def request(self, command):
        def result(status, message):
            self.mobile.complete_control(dict(request_id=command['request_id'], owner=command['owner'],
                                              status=status, message=message))

        with self.lock:
            if not TOKEN.fullmatch(self.token):
                result('failed', 'PC_START.bat로 실행한 뒤 업데이트하세요.')
                return
            if self.busy or not 0 <= time.monotonic() - command['issued_at'] <= 30:
                result('failed', '업데이트 처리 중이거나 요청 시간이 지났습니다.')
                return
            mode=command.get('key')
            if mode in ('legacy207','monthly208'):
                self.engine.send('pc_entry_mode',mode=mode,command=command)
                result('accepted','진입 규칙 변경 요청')
                return
            manifest = None
            ticket = command.get('ticket')
            if ticket:
                saved = self.ticket
                if (not saved or ticket != saved[0] or time.monotonic() >= saved[1]
                        or saved[2] != command['owner']):
                    result('failed', '새 버전 확인부터 다시 눌러주세요.')
                    return
                manifest = saved[3]
            self.ticket = None
            self.busy = True
            self.message = '설치 파일 확인 중' if manifest else '새 버전 확인 중'
            result('accepted', self.message)

        def work():
            try:
                if manifest:
                    folder = download_stage(self.root, self.package, manifest)
                    with self.lock:
                        self.installing = True
                        self.message = '거래소 보유·주문 상태 확인 중'
                    self.engine.send('pc_update_restart', folder=folder)
                else:
                    found = verify_manifest(json.loads(fetch(CHANNEL, 8192)), self.release['revision'])
                    with self.lock:
                        if found:
                            self.ticket = (secrets.token_hex(16), time.monotonic() + 300, command['owner'], found)
                        self.busy = False
                        self.message = '새 버전 설치 가능' if found else '이미 최신 버전입니다.'
            except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile):
                self.fail('배포 확인 또는 파일 검증 실패 · 현재 버전으로 계속 실행합니다.')
        threading.Thread(target=work, name='pc-update-download', daemon=True).start()

    def fail(self, message):
        with self.lock:
            self.message = message
            self.installing = self.busy = False

    def bind(self, engine):
        self.engine = engine
        engine.pc211_capacity = True
        original = engine.handle
        send = engine.send

        def guarded_send(action, **kwargs):
            with self.lock:
                if not self.restart:
                    send(action, **kwargs)
                    return
            if action == 'mobile_control':
                engine.events.put(('mobile_control_result', dict(
                    request_id=kwargs['request_id'], owner=kwargs['owner'], status='failed',
                    message='PC 재시작 중 · 재연결 후 다시 요청하세요.')))

        def handle(action, kwargs):
            if self.restart:
                return
            if action == 'pc_entry_mode':
                command=kwargs['command']
                self.engine.journal.data['legacy_entries207']=kwargs['mode']=='legacy207'
                self.engine.journal.save()
                self.engine.channel_pending={}
                self.engine.monthly208_candidates=[]
                self.engine.monthly_scan_status=None
                self.mobile.complete_control(dict(request_id=command['request_id'],owner=command['owner'],status='done',message='진입 규칙 변경 완료'))
                return
            if action != 'pc_update_restart':
                return original(action, kwargs)
            from phone_handover import BusyHandover, busy_work, digest
            try:
                folder = kwargs['folder']
                resolve_stage(self.root, folder)
                blockers = busy_work(engine)
                if blockers:
                    raise BusyHandover(blockers)
                journal = copy.deepcopy(engine.journal.data)
                if bool(journal.get('entry_continuity732', {}).get('requested')) != bool(engine.run_requested):
                    raise ValueError('신규 진입 운용 상태 대조 실패')
                first = position_handover(journal, engine.api.snapshot(), engine.api.pending_algos(full=True))
                second = position_handover(journal, engine.api.snapshot(), engine.api.pending_algos(full=True))
                if first != second:
                    raise ValueError('대조 중 포지션 또는 보호 주문이 변경됐습니다.')
                with self.lock, engine.risk_lock:
                    blockers = busy_work(engine)
                    if blockers:
                        raise BusyHandover(blockers)
                    if digest(engine.journal.data) != digest(journal):
                        raise ValueError('대조 중 운용 기록이 변경됐습니다.')
                    engine.journal.save()
                    atomic_json(self.root / 'pc_update_handoff.json', dict(token=self.token, folder=folder))
                    engine.entry_cancel.set()
                    engine.enabled = False
                    self.restart = True
                    self.message = 'PC 재시작 중 · 같은 주소로 다시 접속하세요.'
                    engine.stop_event.set()
                    engine.command_wake.set()
                    engine.events.put(('quit', None))
            except ValueError as error:
                self.fail(str(error) + ' · 현재 버전으로 계속 실행합니다.')
            except Exception:
                self.fail('업데이트 전 계정 확인 실패 · 현재 버전으로 계속 실행합니다.')

        engine.handle = handle
        engine.send = guarded_send

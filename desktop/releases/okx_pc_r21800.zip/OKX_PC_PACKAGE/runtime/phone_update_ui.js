// Reconcile text in place; never empty a live reading region on refresh.
function phoneUiKey(el,key){el.phoneUiKey=key;return el}
function phoneUiText(el,value){const text=String(value);if(el.textContent!==text)el.textContent=text}
function phoneUiSync(target,source){
 if(target.className!==source.className)target.className=source.className;
 const incoming=Array.from(source.children);
 if(!incoming.length){phoneUiText(target,source.textContent);return}
 // The initial HTML may contain a plain-text placeholder before its first rows.
 if(!target.children.length&&target.textContent)phoneUiText(target,'');
 const key=(el,i)=>el.phoneUiKey??(el.id||(el.tagName+':'+i));
 const old=new Map(Array.from(target.children,(el,i)=>[key(el,i),el])),keep=new Set();
 for(let i=0;i<incoming.length;i++){
  const wanted=incoming[i],id=key(wanted,i);let child=old.get(id);
  if(child&&child.tagName===wanted.tagName)phoneUiSync(child,wanted);else child=wanted;
  keep.add(child);
  if(target.children[i]!==child)target.insertBefore(child,target.children[i]||null);
 }
 for(const child of Array.from(target.children))if(!keep.has(child))child.remove();
}
function phoneUiScrollMark(el){
 if(!el)return null;
 const mark={el,top:el.scrollTop||0};
 if(mark.top&&el.getBoundingClientRect&&el.querySelectorAll){
  const box=el.getBoundingClientRect();
  for(const child of el.querySelectorAll('h3,h4,p')){
   const rect=child.getBoundingClientRect();
   if(rect.bottom>box.top&&rect.top<box.bottom){mark.anchor=child;mark.offset=rect.top-box.top;break}
  }
 }
 return mark;
}
function phoneUiScrollRestore(mark){
 if(!mark)return;
 const {el,anchor}=mark;
 if(anchor?.isConnected){
  const delta=(anchor.getBoundingClientRect().top-el.getBoundingClientRect().top)-mark.offset;
  if(Math.abs(delta)>.5)el.scrollTop+=delta;
 }
 else if(el.scrollTop!==mark.top)el.scrollTop=mark.top;
}

// Phone release controls. Reuse authenticated same-origin control endpoint.
const phoneOriginalRender = render;
render = function(d) {
 phoneOriginalRender(d);
 renderPCUpdate(d);
};
function renderWickAlertStatus(d){
 phoneUiText($('pcWickStatus'),d.wick_alert_status||'시세 수신 대기');
 const button=$('pcWickTiming'),mode=d.wick_indicator_mode;
 if(!button)return;
 for(const el of document.querySelectorAll('[data-entry-rule]')){
  const rule=el.dataset.entryRule;
  const ready=Array.isArray(d.pc_disabled_rules);
  const enabled=ready&&!d.pc_disabled_rules.includes(rule);
  el.dataset.label??=el.textContent;
  phoneUiText(el,el.dataset.label+' · '+(ready?(enabled?'켜짐':'꺼짐'):'확인 중'));
  el.setAttribute('aria-checked',String(enabled));
  el.disabled=wickTimingBusy||!ready||!d.controls_enabled;
  el.onclick=()=>changeWickTiming(el,(enabled?'off:':'on:')+rule);
 }
 const known=['confirm','standard','symbol_flow'].includes(mode);
 const flow=$('pcSymbolFlow');
 if(flow){
  flow.disabled=wickTimingBusy||!known||!d.controls_enabled;flow.dataset.mode=known?mode:'';
  flow.setAttribute('aria-checked',String(mode==='symbol_flow'));
  phoneUiText(flow,'종목 흐름에 맞춰 진입 · '+(known?(mode==='symbol_flow'?'켜짐':'꺼짐'):'상태 확인 중'));
 }
 button.disabled=wickTimingBusy||!known||!d.controls_enabled;
 button.dataset.mode=known?mode:'';
 button.setAttribute('aria-checked',String(mode==='confirm'));
 phoneUiText(button,'일목·RSI 추가 확인 · '+(known?(mode==='confirm'?'켜짐':'꺼짐'):'상태 확인 중'));
}
let wickTimingBusy=false;
async function changeWickTiming(button,choice){
 if(button.disabled||wickTimingBusy)return;
 const key=button.dataset.mode===choice?'standard':choice;
 wickTimingBusy=true;button.disabled=true;
 const feedback=$('pcWickTimingFeedback');
 phoneUiText(feedback,'PC에 설정 저장 중');
 try{
  let result=await api('/api/control/wick_timing',{method:'POST',headers:{'Content-Type':'application/json'},
       body:JSON.stringify({client_id:'wick_'+clientId(),key})});
  for(let i=0;result.status==='queued'&&i<20;i++){
   await new Promise(resolve=>setTimeout(resolve,300));
   result=await api('/api/control/result?id='+encodeURIComponent(result.request_id));
  }
  if(result.status==='done'&&state.data){
   if(key.includes(':')){
    const [action,id]=key.split(':');
    const disabled=new Set(state.data.pc_disabled_rules||[]);
    if(action==='on')disabled.delete(id);else disabled.add(id);
    state.data.pc_disabled_rules=[...disabled];
   }else state.data.wick_indicator_mode=key;
  }
  phoneUiText(feedback,result.status==='queued'?'설정 저장 결과 대기':result.message);
 }catch(err){phoneUiText(feedback,'설정 변경 미확인 · '+err.message);}
 finally{wickTimingBusy=false;renderWickAlertStatus(state.data||{});}
};
$('pcWickTiming').onclick=()=>changeWickTiming($('pcWickTiming'),'confirm');
$('pcSymbolFlow').onclick=()=>changeWickTiming($('pcSymbolFlow'),'symbol_flow');
let pcUpdatePosting=false,pcUpdateFeedback='';
function renderPCUpdate(d){
 const u=d.program_update||{};
 renderUpdateNotice(u);
 renderWickAlertStatus(d);
 $('mobileUpdateButton').textContent=u.available||u.ticket?'PC 업데이트 설치':'PC 새 버전 확인';
 $('mobileUpdateButton').disabled=pcUpdatePosting||Boolean(u.busy)||!d.controls_enabled;
 const lines=['현재 PC '+(u.display_version||'확인 중')];
 if(u.target_version)lines.push('설치 가능 PC '+u.target_version);
 if(u.message)lines.push(u.message);
 if(pcUpdateFeedback&&pcUpdateFeedback!==u.message)lines.push(pcUpdateFeedback);
 if(u.target_version&&u.notes)lines.push('PC '+u.target_version+' 변경 사항\n'+u.notes);
 phoneUiText($('mobileUpdateStatus'),lines.join('\n'));
 $('mobileUpdateStatus').style.whiteSpace='pre-wrap';
};
$('mobileUpdateButton').onclick=async()=>{
 if(pcUpdatePosting)return;
 const u=state.data?.program_update||{};
 const body={client_id:'phone_update_'+clientId()};
 if(u.available||u.ticket){
  if(!confirm('PC 버전 '+u.target_version+' 설치\n'+u.notes+'\n\n신규 진입만 자동으로 잠시 멈추고 보유분과 거래소 손절을 인계합니다. 완료 후 기존 운용 상태로 복구하며, 원래 중지 상태였다면 계속 중지합니다. 교체 중 로컬 추적 관리는 잠시 쉬고 거래소 손절은 유지됩니다. 설치할까요?'))return;
  if(u.available)body.key='install_'+u.target_revision;
  else body.ticket=u.ticket;
 }
 pcUpdatePosting=true;pcUpdateFeedback='PC 응답 대기';renderPCUpdate(state.data||{});
 try{
  let r=await api('/api/control/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  for(let i=0;r.status==='queued'&&r.request_id&&i<20;i++){
   await new Promise(resolve=>setTimeout(resolve,300));
   r=await api('/api/control/result?id='+encodeURIComponent(r.request_id));
  }
  pcUpdateFeedback=r.status==='failed'?r.message:r.status==='queued'?'PC 응답 대기 중 · 설치 상태를 확인하세요.':'';
 }catch(e){pcUpdateFeedback='PC 응답 미확인 · 재접속 후 현재 버전을 확인하세요.'}
 finally{pcUpdatePosting=false;renderPCUpdate(state.data||{});void refresh()}
};

const perfRender113 = render;
render = function(d){
 perfRender113(d);
 if(typeof activePart!=='undefined'&&activePart!=='settings')return;
 let el=document.getElementById('phonePerfSummary');
 if(!el){el=document.createElement('p');el.id='phonePerfSummary';el.className='muted';document.getElementById('programUpdate').appendChild(el);}
 const p=d.performance||{}, r=p.recent||{}, c=p.cache||{}, m=p.resources||{};
 const rows=['계산 성능','최근 '+(r.count||0)+'회 검사 · 평균 '+(Number.isFinite(r.mean_s)?r.mean_s.toFixed(3):'측정 중')+'초 · 95% 지점 '+(Number.isFinite(r.p95_s)?r.p95_s.toFixed(3):'측정 중')+'초',
  '계산 재사용 '+(c.hit_pct??'측정 중')+'% · 입력 저장 '+(c.input_mib??0)+' MiB · 밀려난 계산 '+(c.evictions??0)+'개',
  '프로세스 메모리 '+(m.rss_mib??'측정 중')+' MiB · CPU '+(m.cpu_one_core_pct??'측정 중')+'% (1코어 기준)'];
 const last=p.last_admission?.[0];
 if(last)rows.push('최근 진입 확인 결과: '+last.category+' · '+last.type);
 rows.push('실측 참고값 · 새 시세와 주문 직전 조건은 매번 확인');
 el.style.whiteSpace='pre-line';el.textContent=rows.join('\n');
};

// Separate diagnostic sections. All observed values are text, never HTML.
async function phoneSaveDiagnostics(d){
 const p=d.performance||{},h=p.runtime_health||{};
 // Authenticated, read-only export also includes retained prior-run records.
 const report=await api('/api/phone/diagnostic');
 const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json'}));
 const link=document.createElement('a');link.href=url;link.download='okx_phone_diagnostic_'+(h.program_version||'unknown')+'.json';
 document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function phoneDiagnosticSection(parent,title,lines){
 const box=phoneUiKey(node('div',undefined,'phone-diagnostic-section'),title);
 box.append(node('h3',title));for(const line of lines)box.append(node('p',line));
 parent.append(box);return box;
}
const healthRender123=render;
let phoneDiagnosticData=null;
const phoneDiagnosticView={lastHealth:null,paused:false};
function phoneDiagnosticPanel(d){
 phoneDiagnosticData=d;
 let el=$('phoneHealthSummary');
 if(el)return el;
 const toolbar=node('div',undefined,'phone-diagnostic-toolbar');
 const save=node('button','연결·진입 진단 저장');save.id='phoneDiagnosticSave';save.type='button';
 const reading=node('button','읽기 고정');reading.id='phoneDiagnosticRead';reading.type='button';
 const readStatus=node('p','자동 갱신', 'muted');readStatus.id='phoneDiagnosticReadStatus';
 if(reading.setAttribute)reading.setAttribute('aria-pressed','false');
 if(readStatus.setAttribute)readStatus.setAttribute('role','status');
 reading.onclick=()=>{
  phoneDiagnosticView.paused=!phoneDiagnosticView.paused;
  phoneUiText(reading,phoneDiagnosticView.paused?'최신 보기':'읽기 고정');
  if(reading.setAttribute)reading.setAttribute('aria-pressed',String(phoneDiagnosticView.paused));
  phoneRenderDiagnostics(phoneDiagnosticData||{});
 };
 const status=node('p','', 'muted');status.id='phoneDiagnosticSaveStatus';
 if(status.setAttribute)status.setAttribute('role','status');
 save.onclick=async()=>{
  if(save.disabled)return;
  save.disabled=true;status.textContent='진단 파일 준비 중';
  try{await phoneSaveDiagnostics(phoneDiagnosticData||{});status.textContent='진단 파일 저장 요청 완료';}
  catch(e){status.textContent='진단 저장 실패: '+e.message;}
  finally{save.disabled=false;}
 };
 const actions=node('div',undefined,'phone-diagnostic-actions');actions.append(save,reading);
 toolbar.append(actions,status,readStatus);
 el=node('div');el.id='phoneHealthSummary';el.tabIndex=0;
 if(el.setAttribute){el.setAttribute('role','region');el.setAttribute('aria-label','연결·진입 진단 · 내부 스크롤');}
 $('programUpdate').append(toolbar,el);return el;
}
function phoneRenderDiagnostics(d){
 const live=phoneDiagnosticPanel(d),incoming=d.performance?.runtime_health;
 const usable=incoming&&!incoming.unavailable&&Number.isFinite(incoming.observed_at);
 if(usable)phoneDiagnosticView.lastHealth=incoming;
 if(phoneDiagnosticView.paused){phoneUiText($('phoneDiagnosticReadStatus'),'읽기 고정 · 화면만 멈춤 · 시세·매매는 계속');return}
 phoneUiText($('phoneDiagnosticReadStatus'),usable?'자동 갱신':'진단 갱신 대기 · 마지막 확인값 유지');
 const panelMark=phoneUiScrollMark(live),journeyMark=phoneUiScrollMark($('phoneSignalJourney'));
 const el=node('div'),h=usable?incoming:phoneDiagnosticView.lastHealth;
 const commit=()=>{phoneUiSync(live,el);phoneUiScrollRestore(journeyMark);phoneUiScrollRestore(panelMark)};
 if(!h){
  phoneDiagnosticSection(el,'연결·진입 진단',['진단 수집 중']);commit();return;
 }
 const fresh=Math.max(0,Date.now()/1000-h.observed_at);
 const allowed=h.entry_enabled&&!h.user_paused&&!h.entry_cancelled&&!h.recovering&&h.public_connected&&h.account_fresh;
 const connection=[Math.round(fresh)+'초 전 확인 · 이번 실행 '+Math.floor((h.elapsed_s||0)/60)+'분',
  '진입·보유 시세 '+(h.public_connected===true?'연결':h.public_connected===false?'끊김':'확인 대기')+' / 계좌 '+(h.account_connected&&h.account_fresh?'최신 자료 수신':'연결·자료 확인 중'),
  '수동 진입: '+(!usable||fresh>10?'진단 자료 지연':allowed?'사용자 요청 대기':'대기·차단'),
  '이번 실행 시세 끊김 '+(h.disconnect_count??'확인 중')+'회'];
 if(h.monitor_connected!==undefined)connection.push('전체 종목 감시 '+(h.monitor_connected===true?'연결':h.monitor_connected===false?'복구 중':'확인 대기')+' · 진입·보유 끊김 '+(h.execution_disconnect_count??0)+'회 / 감시 끊김 '+(h.monitor_disconnect_count??0)+'회');
 if(h.execution_upgrade_count||h.monitor_upgrade_count)connection.push('거래소 종료 예고 사전 연결 교체 · 진입·보유 '+(h.execution_upgrade_count||0)+'회 / 감시 '+(h.monitor_upgrade_count||0)+'회');
 if(h.last_disconnect_at)connection.push('마지막 끊김 '+new Date(h.last_disconnect_at*1000).toLocaleTimeString('ko-KR',{timeZone:'Asia/Seoul',hour12:false})+' KST');
 const causes={read_eof:'소켓 수신 종료(EOF)',socket_already_closed:'이미 닫힌 소켓',websocket_closed:'웹소켓 종료',tcp_reset:'TCP 연결 초기화',write_broken_pipe:'송신 연결 종료',idle_timeout:'수신 무응답',peer_close_frame:'상대 종료 프레임',other_transport_error:'기타 통신 오류'};
 if(h.last_disconnect_cause)connection.push('종료 유형: '+(causes[h.last_disconnect_cause]||'분류 확인 필요'));
 for(const x of (h.disconnect_history||[]).slice(-3)){
  const time=new Date(x.observed_at*1000).toLocaleTimeString('ko-KR',{timeZone:'Asia/Seoul',hour12:false});
  connection.push(time+' · '+(causes[x.cause]||x.cause)+' · 이전 연결 '+Math.round(x.connection_uptime_s||0)+'초 유지'+(x.server_notice?.code==='64008'?' · OKX 서버 점검 사전통지 수신':''));
 }
 if(h.risk_work?.pending_risks)connection.push('처리 중인 보호 요청 '+h.risk_work.pending_risks+'개');
 phoneDiagnosticSection(el,'연결 상태',connection);
 const journey=h.signal_journey;
 if(journey){
  const section=phoneDiagnosticSection(el,'최근 신호 진행 기록',[]);
  section.append(node('p','최근 보존된 고유 신호 '+journey.unique_observed+'개 · 처음 볼 때 이미 90초 경과 '+journey.first_seen_expired+'개 (최대 1,024개 보존 · 놓친 거래 수 아님)','phone-journey-count'));
  const scroll=node('div',undefined,'phone-signal-scroll');scroll.id='phoneSignalJourney';scroll.tabIndex=0;
  if(scroll.setAttribute){scroll.setAttribute('role','region');scroll.setAttribute('aria-label','최근 신호 진행 기록 · 스크롤');}
  section.append(scroll);
  for(const x of journey.rows||[]){
   const lines=[],origin=x.signal_mode==='live'?'지지 회복':'봉 마감';
   lines.push(x.symbol+' '+x.action+' · '+x.stage_label);
   lines.push((x.signal_mode==='live'?'실시간 지지 회복 ':'확인봉 마감 ')+phoneMoveStamp(x.valid_from_ms)+' KST · 첫 관측 '+x.first_delay_s+'초 후');
   if(x.route)lines.push('진입 경로: '+x.route);
   const timing=x.timing||{};
   const stamps=[['input_published_ms','입력 묶음 게시'],['rank_inputs_captured_ms','순위 입력 확인'],['computation_submitted_ms','계산 요청'],['computation_published_ms','계산 결과 확인']]
    .filter(([k])=>Number.isFinite(timing[k])).map(([k,label])=>label+' '+((timing[k]-x.valid_from_ms)/1000).toFixed(3)+'초');
   if(stamps.length)lines.push(origin+' 기준 · '+stamps.join(' / ')+' (원격 수신시각과 다를 수 있음)');
   if(Number.isFinite(x.first_market_ready_ms))lines.push('시세 준비 확인: '+origin+' '+((x.first_market_ready_ms-x.valid_from_ms)/1000).toFixed(3)+'초 후');
   if(x.rejection)lines.push('재검사 사유: '+x.rejection);
   if(x.last_market){
    const missing=Object.entries(x.last_market.channels||{}).filter(([k,v])=>!v.ready);
    const at=x.last_market.observed_ms??x.last_market_wait_ms;
    if(Number.isFinite(at))lines.push('마지막 시세 대기 관측: '+origin+' '+((at-x.valid_from_ms)/1000).toFixed(3)+'초 후 · 당시 기록');
    lines.push('마지막 시세 대기: '+missing.map(([k,v])=>k+' '+(v.receive_age_s==null?'미수신':v.receive_age_s+'초 전 수신')+
     (v.acknowledged?' · 거래소 구독 확인':v.subscribed?' · 구독 요청 전송됨':v.wanted?' · 구독 전송 대기':' · 구독 대상 지정 전')).join(' / '));
    if(Number.isFinite(x.last_market.request_wait_s))lines.push('당시 요청 간격·횟수 제한 대기: '+x.last_market.request_wait_s+'초');
   }
   const item=phoneUiKey(node('div',undefined,'phone-signal-item'),[x.symbol,x.action,x.valid_from_ms,x.route||''].join('|'));
   for(const line of lines)item.append(node('p',line));
   scroll.append(item);
  }
 }
 const notes=['진입 허용은 체결 확인이 아닙니다. 끊김 횟수는 재시작 시 초기화됩니다.'];
 if(h.program_version)notes.push('진입 진단 기록은 재시작 후에도 보존됩니다 (최근 파일 최대 약 4MiB).');
 if(h.history_write_errors)notes.push('진단 기록 저장 오류 '+h.history_write_errors+'회');
 phoneDiagnosticSection(el,'기록 안내',notes);
 commit();
}
render=function(d){
 healthRender123(d);
 if(typeof activePart!=='undefined'&&activePart!=='settings')return;
 phoneRenderDiagnostics(d);
};

// Calculation mode: authenticated controls, no order or trading-mode action.
const parallelRender126=render;
render=function(d){
 parallelRender126(d);
 if(typeof activePart!=='undefined'&&activePart!=='settings')return;
 let box=document.getElementById('parallel126');
 if(!box){
  box=document.createElement('div');box.id='parallel126';
  const text=document.createElement('p');text.id='parallelState126';text.className='muted';box.appendChild(text);
  for(const [key,label] of [['parallel4','4개 분산 사용'],['serial','단일 계산으로 전환']]){
   const b=document.createElement('button');b.textContent=label;b.type='button';
   b.onclick=async()=>{b.disabled=true;try{
    const r=await api('/api/control/calculation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:'calc_'+clientId(),key})});
    document.getElementById('parallelState126').textContent=r.message;
   }catch(e){document.getElementById('parallelState126').textContent='변경 미확인: '+e.message;}finally{b.disabled=false;}};
   box.appendChild(b);
  }
  document.getElementById('programUpdate').appendChild(box);
 }
 const p=d.performance?.parallel||{};
 const lines=['계산 방식: '+(p.effective===4?'4개 분산':p.effective===0?'PC 단일 계산':'확인 중'),
  '선택: '+(p.requested===4?'4개 분산':p.requested===0?'PC 단일 계산':'확인 중')+' · 실행 작업자 '+(p.workers_alive??0)+'개'];
 if(p.architecture==='mobile140')lines.push('PC 계산 · '+(p.calculating?'새 봉 계산 중':'계산 결과 준비')+' · 후보 시세·주문 검사 별도 진행');
 if(p.last_error)lines.push('계산 오류 · PC 단일 계산으로 복원: '+p.last_error);
 if(p.aggregate_rss_mib!=null)lines.push('부모+작업자 RSS 합계 '+p.aggregate_rss_mib+' MiB · CPU '+(p.aggregate_cpu_one_core_pct??'측정 중')+'% (1코어 환산)');
 lines.push('변경은 다음 신호 검사부터 적용 · 재시작 후에도 선택 유지 · 포지션/매매 규칙 유지');
 document.getElementById('parallelState126').style.whiteSpace='pre-line';
 document.getElementById('parallelState126').textContent=lines.join('\n');
};

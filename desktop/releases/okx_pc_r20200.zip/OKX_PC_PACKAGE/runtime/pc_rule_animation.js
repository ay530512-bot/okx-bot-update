// The same illustrative OHLC values drive the static view and the replay.
(() => {
 const root = document.getElementById('rules208');
 if (!root) return;
 const rows = Array.from(root.querySelectorAll('details.entry-example'));
 const duration = 1050;
 let frame = 0;

 function readChart(svg) {
  const bars = Array.from(svg.querySelectorAll('[data-prices]'), group => {
   const [open, high, low, close] = group.dataset.prices.split(',').map(Number);
   const ticks = close >= open ? [open, low, high, close] : [open, high, low, close];
   return {group, wick: group.querySelector('path'), body: group.querySelector('rect'),
           x: Number(group.dataset.x), ticks};
  });
  return {bars, marker: svg.querySelector('.entry-marker')};
 }

 function paintBar(bar, progress) {
  const ticks = bar.ticks;
  const step = Math.min(2, Math.floor(progress * 3));
  const price = ticks[step] + (ticks[step+1] - ticks[step]) * (progress * 3 - step);
  const seen = [...ticks.slice(0, step+1), price];
  const color = price >= ticks[0] ? '#58d6a3' : '#ff8793';
  bar.wick.setAttribute('d', 'M'+bar.x+' '+(132-Math.max(...seen))+'V'+(132-Math.min(...seen)));
  bar.wick.setAttribute('stroke', color);
  bar.body.setAttribute('y', 132-Math.max(ticks[0],price));
  bar.body.setAttribute('height', Math.max(1,Math.abs(ticks[0]-price)));
  bar.body.setAttribute('fill', color);
 }

 function play(row, animate) {
  cancelAnimationFrame(frame);
  const charts = Array.from(row.querySelectorAll('svg'), readChart);
  const start = performance.now();
  function draw(now) {
   if (!row.open) return;
   let unfinished = false;
   for (const chart of charts) {
    const elapsed = animate ? (now-start)/duration : chart.bars.length;
    chart.bars.forEach((bar, index) => {
     const progress = elapsed-index;
     bar.group.style.visibility = progress >= 0 ? 'visible' : 'hidden';
     if (progress >= 0) paintBar(bar, Math.min(1, progress));
    });
    const complete = elapsed >= chart.bars.length;
    chart.marker.style.visibility = complete ? 'visible' : 'hidden';
    unfinished ||= !complete;
   }
   if (unfinished) frame = requestAnimationFrame(draw);
  }
  draw(start);
 }

 function select(row, animate) {
  for (const other of rows) if (other !== row && other.open) other.open = false;
  play(row, animate);
 }
 for (const row of rows) {
  row.addEventListener('toggle', () => {
   if (row.open) select(row, !matchMedia('(prefers-reduced-motion: reduce)').matches);
  });
  row.querySelector('.entry-replay').addEventListener('click', () => play(row, true));
 }
})();

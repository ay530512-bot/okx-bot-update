"""Closed-candle scalp entries using the same symbol set as the November replay."""
import threading
import time
from okx_core import BotError
from okx_pattern15 import allowed
from pc_wick_failure import candle_rows

MINUTE = 60000
SYMBOLS = tuple(x+'-USDT-SWAP' for x in
    'ACT INIT PENDLE EDGE XRP DOGE ADA LINK AVAX SUI DOT LTC BCH TRX UNI AAVE NEAR FIL ATOM ARB OP APT INJ ETC PEPE WIF LDO CRV ZEC BONK BREV'.split())
# Label, KST start/end, signal minutes, stop floor, target R, hold minutes, daily fills
SPECS = {
    'scalp_double': ('두꼬리 롱',4,8,1,.006,3,15,3),
    'scalp_break': ('꼬리실패 롱',10,14,15,.003,2,30,3),
    'scalp_higher': ('새 음봉꼬리 롱',8,20,1,.006,3,30,1),
}

def atr(b,j):
    return sum(max(r[2]-r[3],abs(r[2]-b[i-1][4]),abs(r[3]-b[i-1][4]))
               for i in range(j-13,j+1) for r in [b[i]])/14

def wick(r,upper=False):
    _,o,h,l,c,_=r
    return ((h-max(o,c)) if upper else (min(o,c)-l))/max(h-l,1e-15)

def rising_rsi(b,k):
    def value(j):
        moves=[b[n][4]-b[n-1][4] for n in range(j-13,j+1)]
        return sum(max(0,x) for x in moves)/max(sum(map(abs,moves)),1e-15)
    return value(k)>value(k-1)

def matches(route,b):
    k=len(b)-1
    _,o,h,l,c,_=b[k]
    a=atr(b,k)
    if route=='scalp_double':
        i=min(range(k-8,k),key=lambda n:b[n][3])
        return (c>o and wick(b[k])>=.2 and wick(b[i])>=.25 and 0<l-b[i][3]<=a
                and max(r[2] for r in b[i-12:i])-b[i][3]>=1.5*a
                and rising_rsi(b,k) and c/b[k-30][4]-1>=.01)
    if a/c<.002:return False
    if route=='scalp_break':
        from pc_monthly import ema
        closes=[r[4] for r in b]
        p=b[k-1]
        return (wick(p,True)>=.3 and p[2]==max(r[2] for r in b[k-6:k]) and c>p[2]
                and c>ema(closes,20)>ema(closes[:-5],20))
    for j in range(k-4,k):
        sec=b[j]; low=sec[3]; aj=atr(b,j)
        if (wick(sec)<.12 or not (sec[4]<sec[1] or b[j-1][4]<b[j-1][1])
                or low>min(r[3] for r in b[j-4:j])):continue
        i=min(range(j-48,j-4),key=lambda n:b[n][3]);first=b[i]
        mid=max(range(i+1,j),key=lambda n:b[n][2])
        if (first[4]>=first[1] or wick(first)<.2 or not 0<low-first[3]<=2*aj or
            not i+2<=mid<=j-2 or b[mid][2]-first[3]<1.5*aj or b[mid][2]-low<aj):continue
        if not any(wick(r,True)>=.25 and r[2]-first[3]>=atr(b,i) for r in b[i-12:i]):continue
        if (min(r[3] for r in b[j+1:])>=low and c>o and c>sec[2] and
            not any(r[4]>r[1] and r[4]>sec[2] for r in b[j+1:k])):return True
    return False

def day(ts):
    return (ts+9*3600000)//86400000

def note_fill(data,s):
    key=s['monthly208']
    if key not in SPECS:return
    bucket=data.setdefault('scalp_filled',{});d=day(s['valid_from_ms'])
    state=bucket.get(key)
    if not state or state['day']<d:state=bucket[key]={'day':d,'ids':[]}
    if state['day']==d and s['signal_id'] not in state['ids']:state['ids'].append(s['signal_id'])

def signal(route,sym,b,end):
    from pc_monthly import RULES
    label,_,_,frame,floor,mult,hold,_=SPECS[route]
    a=atr(b,len(b)-1);c=b[-1][4];stop=c-max(c*floor,1.5*a)
    if stop<=0 or (c-stop)/c>.075:return
    rv=b[-1][5]/max(1,sum(r[5] for r in b[-21:-1])/20)
    proof=dict(action='LONG',reference=c,atr=a,confirmation_ms=end-frame*MINUTE,
               structural_stop=stop,relative_volume=rv,route721='m208_'+route)
    return dict(symbol=sym,action='LONG',leverage=10,strategy='band_flow',pattern='m208_'+route,
        monthly208=route,rule_channel701=True,free_ai=True,pattern15=True,stop=stop,target=None,
        pc211=True,margin_fraction=.10,signal_id=f'{route}-{sym}-{end}',atr=a,level=stop,
        reason=label,regime=label,ma={},bb={},rsi={},retest=False,adaptive=False,
        setup_frame=f'{frame}m',execution_frame='1m',at_ms=end,valid_from_ms=end,expires_ms=end+MINUTE-1,
        entry_reference=c,entry_gap=c,selection=dict(activity={},asset_category='1'),
        holding_rule=dict(band_flow=True,free_ai=True,pattern15=True,rule_channel701=True,
            monthly208=route,frame=f'{frame}m',partial=False,max_hold_seconds=hold*60),
        decision_record=dict(source='m208_'+route,frames={},volume_wick_proof=proof))

def scan(e,end,jobs,universe):
    from pc_monthly import closing
    winners={}
    for frame,routes in jobs.items():
        step=frame*MINUTE
        for sym in universe:
            if e.api.now_ms()>=end+MINUTE:return
            try:
                raw=candle_rows(e,sym,f'{frame}m','100',e.api.now_ms())
                b=closing(raw,end,step,85)
                if not b:continue
                for route in routes:
                    if matches(route,b):
                        s=signal(route,sym,b,end)
                        if s:
                            rank=(-s['decision_record']['volume_wick_proof']['relative_volume'],sym)
                            if route not in winners or rank<winners[route][0]:winners[route]=(rank,s)
            except (BotError,ValueError,TypeError,KeyError,OSError):continue
            finally:time.sleep(.12)
    e.scalp_result=(end,[v[1] for v in winners.values()])

def candidates(e,now):
    from pc_monthly import active
    end=now//MINUTE*MINUTE
    jobs={}
    for route,spec in SPECS.items():
        if not active(route,end) or end%(spec[3]*MINUTE):continue
        jobs.setdefault(spec[3],[]).append(route)
    if not jobs:return []
    worker=getattr(e,'scalp_worker',None)
    if getattr(e,'scalp_end',None)!=end and not (worker and worker.is_alive()):
        u=e.universe
        with u.lock:
            instruments=getattr(getattr(u,'full_market',None),'instruments',{})
            universe=[sym for sym in SYMBOLS if sym in instruments and allowed(instruments[sym],e.cfg)
                      and float(instruments[sym].get('lever') or 0)>=10]
        if universe:
            e.scalp_end=end
            e.scalp_worker=threading.Thread(target=scan,args=(e,end,jobs,universe),daemon=True)
            e.scalp_worker.start()
    stamp,signals=getattr(e,'scalp_result',(0,[]))
    return signals if stamp==end else []

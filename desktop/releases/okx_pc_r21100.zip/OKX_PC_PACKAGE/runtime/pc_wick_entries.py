"""Route the live 15m two-wick reaction to Telegram and the serialized PC order engine."""
from dataclasses import dataclass, field
import logging
import math
import threading

from okx_core import BotError, UnknownOutcome
from okx_entry_gate720 import gate
from okx_pattern15 import band, summary
from pc_sizing import SLOTS, indicators, leverage_for, round_stop
from pc_wick_alert import STEP, WINDOW, alert_text
from pc_wick_chart import price_text, snapshot
from pc_wick_context import adverse_momentum

ROUTE = 'bb_wick_retest_15m'
TTL_MS = 15_000


@dataclass
class Reaction:
    symbol: str
    hit: dict
    tick: str
    bars: tuple
    initial_block: str
    timing_mode: str = 'standard'
    chart: dict = field(init=False)
    wait_retest: bool = field(init=False)
    wait_follow: bool = field(init=False)
    nearest: float = field(init=False, default=math.inf)
    confirmation: tuple = field(init=False, default=None)
    invalid: threading.Event = field(default_factory=threading.Event)
    announced: threading.Event = field(default_factory=threading.Event)

    def __post_init__(self):
        self.chart = snapshot(self.symbol, self.hit, self.tick, self.bars)
        side, tick = self.hit['side'], float(self.tick)
        spacing = side*(self.hit['second']-self.hit['first'])
        jump = side*(self.hit['price']-self.hit['second'])
        self.wait_retest = jump > max(2*tick, spacing) + tick*1e-6
        self.wait_follow = (self.timing_mode=='confirm' and not self.wait_retest
                            and adverse_momentum(self.chart['market_context'],side))

    @property
    def needs_confirmation(self):
        return self.wait_retest or self.wait_follow

    @property
    def timing_label(self):
        if self.wait_follow:
            return '일목·RSI 역방향 · 추가 1틱 체결'
        if self.wait_retest:
            return '두 번째 꼬리 근처 재반응 체결'
        return '두 번째 꼬리의 첫 반응 체결'

    def follows_price(self, price):
        move = self.hit['side']*(price-self.hit['price'])/float(self.tick)
        return 1-1e-6 <= move <= 2+1e-6

    def waiting_note(self):
        def fmt(price):
            return price_text(price,self.tick)
        step = self.hit['side']*float(self.tick)
        if self.wait_follow:
            ref = self.hit['price']
            return (f"일목·RSI 역방향 · {fmt(ref+step)}~{fmt(ref+2*step)} 추가 체결 대기"
                    ' · 첫 신호부터 15초')
        if self.wait_retest:
            second = self.hit['second']
            return (f"첫 반응 가격이 멀어 두 번째 꼬리 {fmt(second)}~{fmt(second+step)} 재반응 대기"
                    ' · 첫 신호부터 15초')
        return '자동 주문 조건 확인 중'

    def observe_retest(self, ts, trade_id, price, bar):
        """Called under the pending lock, only for fresh, ordered public trades."""
        if (not self.needs_confirmation or self.confirmation or self.initial_block or self.invalid.is_set()
                or trade_id <= self.hit['trade_id'] or not self.hit['ts'] <= ts <= self.expires_ms):
            return False
        tick = float(self.tick)
        distance = self.hit['side']*(price-self.hit['second'])
        eps = tick*1e-6
        confirmed = self.follows_price(price) if self.wait_follow else self.nearest+tick-eps<=distance<=2*tick+eps
        if confirmed:
            hit = dict(self.hit, ts=ts, trade_id=trade_id, price=price, chart_bar=tuple(bar))
            self.confirmation = (hit, snapshot(self.symbol, hit, self.tick, self.bars))
            return True
        if self.wait_retest and -eps <= distance <= tick+eps:
            self.nearest = min(self.nearest, max(0., distance))
        return False

    @property
    def entry_hit(self):
        return self.confirmation[0] if self.confirmation else self.hit

    @property
    def entry_chart(self):
        return self.confirmation[1] if self.confirmation else self.chart

    @property
    def expires_ms(self):
        start = self.hit['ts']
        deadline = start + TTL_MS
        return min(deadline, (start//STEP+1)*STEP-1) if self.needs_confirmation else deadline

    @property
    def key(self):
        return self.symbol + ('/long' if self.hit['side'] == 1 else '/short')

    @property
    def signal_id(self):
        return f"wick280-{self.key}-{self.hit['anchor_ms']}"


def entry_distances(reaction, hit=None):
    """Observable at the reaction print, including signals later rejected by the order gate."""
    if len(reaction.bars) < 20:
        return None
    hit = reaction.hit if hit is None else hit
    if reaction.bars[-1][0] != hit['ts']//STEP*STEP - STEP:
        return None
    side, price, tick = hit['side'], hit['price'], float(reaction.tick)
    mid = sum(row[4] for row in reaction.bars[-20:])/20
    stop = round_stop(hit['first'] - side*max(2*tick, .15*hit['anchor_atr']),tick,side)
    return dict(mid=mid, stop=stop, room_pct=100*side*(mid-price)/price,
                risk_pct=100*side*(price-stop)/price)


def make_signal(engine, reaction):
    from phone_trend_slot import permitted
    hit, bars, symbol = reaction.entry_hit, reaction.bars, reaction.symbol
    side, price, first, second = (hit[k] for k in ('side','price','first','second'))
    tick, atr = float(reaction.tick), hit['anchor_atr']
    now = engine.api.now_ms()
    expires = reaction.expires_ms
    if reaction.needs_confirmation and not reaction.confirmation:
        raise BotError('두 꼬리 추가 체결 확인 대기')
    if not (hit['ts'] <= now <= expires and bars and
            bars[-1][0] == hit['ts']//STEP*STEP-STEP and
            1 <= (hit['ts']//STEP*STEP-hit['anchor_ms'])//STEP <= WINDOW and
            side in (-1,1) and min(price, first, second, tick, atr)>0 and
            side*(second-first)>0 and side*(price-second)>0):
        raise BotError('두 꼬리 반응 체결 또는 완료봉 확인 시간 만료')
    instrument = engine.api.public('/api/v5/public/instruments', instType='SWAP', instId=symbol)[0]
    if (instrument.get('instId') != symbol or not permitted(dict(symbol=symbol,instrument=instrument),engine.cfg)
            or float(instrument['tickSz']) != tick):
        raise BotError('허용 종목 또는 호가 단위 변경')
    stop = round_stop(first-side*max(2*tick,.15*atr),tick,side)
    ev = indicators(bars,side,atr)
    if not ev or not 0<stop or side*(price-stop)<=0:
        raise BotError('배율·첫 꼬리 손절 계산 자료 부족')
    ev['stop'] = stop
    maximum = float(instrument.get('lever') or 0)
    leverage = leverage_for(ev,price,maximum)
    if not leverage:
        raise BotError('3배에서도 첫 꼬리 손절과 거래비용이 위험 한도를 초과함')
    action = 'LONG' if side == 1 else 'SHORT'
    frame = summary(bars)
    lo,mid,hi = band(bars,len(bars)-1)
    proof = dict(route721=ROUTE, action=action, first_wick=first, second_wick=second,
                 anchor_ms=hit['anchor_ms'], reaction_ms=hit['ts'], trade_id=hit['trade_id'],
                 reference=price, structural_stop=stop, atr=atr, sizing_indicators=ev,
                 market_context=reaction.entry_chart['market_context'],
                 initial_market_context=reaction.chart['market_context'],
                 indicator_mode=reaction.timing_mode, timing_label=reaction.timing_label,
                 first_reaction_ms=reaction.hit['ts'], first_reaction_price=reaction.hit['price'],
                 retest_confirmed=bool(reaction.wait_retest and reaction.confirmation),
                 follow_confirmed=bool(reaction.wait_follow and reaction.confirmation),
                 timing_distances=entry_distances(reaction,hit))
    return dict(symbol=symbol,action=action,pc_wick280=True,pc260=True,rule_channel701=True,
                free_ai=True,pattern15=True,strategy='band_flow',pattern=ROUTE,
                leverage=leverage,indicator_limit=maximum,margin_fraction=1/SLOTS,
                reason='15분봉 볼린저밴드 두 꼬리 · '+reaction.timing_label,
                regime='두 꼬리 반전',ma=frame['ma'],bb=dict(lower=lo,mid=mid,upper=hi),
                rsi={'15m':frame['rsi14']},atr=atr,level=stop,stop=stop,target=None,retest=True,
                adaptive=False,setup_frame='15m',execution_frame='15m',signal_id=reaction.signal_id,
                at_ms=hit['ts'],valid_from_ms=hit['ts'],expires_ms=expires,
                entry_reference=price,entry_gap=price,selection=dict(activity={},asset_category='1',origin=ROUTE),
                holding_rule=dict(frame='15m',zone=stop,target=None,target_mode='trailing_only',
                                  partial=False,rule_channel701=True,pattern15=True),
                decision_record=dict(source=ROUTE,frames={'15m':{'analysis':frame}},volume_wick_proof=proof))


class WickEntries:
    def __init__(self, engine):
        self.engine = engine
        self.lock = threading.Lock()
        self.pending = {}
        self.warm = frozenset()
        self.current = None
        stored = engine.journal.data.get('wick_indicator_mode')
        self.mode = 'confirm' if stored=='confirm' else 'standard'
        self.seen = dict(engine.journal.data.get('pc_wick280_seen',{}))
        # A 2.7.0 alert may already have been acted on manually before the update.
        for key, stamp in engine.notifier.data.get('wick_15m_seen',{}).items():
            self.seen[key] = max(stamp,self.seen.get(key,-1))

    def set_mode(self, mode):
        if mode not in ('standard','confirm'):
            raise BotError('두 꼬리 지표 설정값 오류')
        if mode==self.mode:
            return
        data = self.engine.journal.data
        previous = data.get('wick_indicator_mode')
        data['wick_indicator_mode'] = mode
        try:
            self.engine.journal.save()
        except Exception:
            if previous is None:
                data.pop('wick_indicator_mode',None)
            else:
                data['wick_indicator_mode'] = previous
            raise
        self.mode = mode

    def blocked(self):
        e = self.engine
        if e.stop_event.is_set():
            return '프로그램 종료 중'
        if getattr(getattr(e,'pc_updater',None),'installing',False):
            return 'PC 업데이트 설치 중'
        state = gate(e)
        return '' if state['allowed'] else state['reason']

    def offer(self, symbol, hit, tick, bars):
        from pc_intraday import session_close_ms, ENTRY_CLOSED
        block = self.blocked()
        if self.engine.api.now_ms() >= session_close_ms(hit['ts']):
            block = block or ENTRY_CLOSED
        reaction = Reaction(symbol,dict(hit),tick,bars,block,self.mode)
        with self.lock:
            if self.seen.get(reaction.key,-1) >= hit['anchor_ms']:
                return
            self.seen[reaction.key] = hit['anchor_ms']
            self.pending[reaction.signal_id] = reaction
        if reaction.initial_block:
            note = '자동 미진입 · '+reaction.initial_block
        else:
            note = reaction.waiting_note()
        msg = alert_text(symbol,hit,tick)
        distances = entry_distances(reaction)
        if distances:
            msg += (f"\n진입 방향으로 볼밴 중심선까지 {distances['room_pct']:+.2f}%"
                    f" · 첫 손절까지 {distances['risk_pct']:.2f}%")
        msg += '\n'+note
        try:
            self.engine.notifier.wick_alert(symbol,hit['side'],hit['anchor_ms'],hit['ts'],msg,chart=reaction.chart)
        except Exception:
            logging.exception('두 꼬리 신호 알림 보관 실패')
        reaction.announced.set()
        self.engine.command_wake.set()
        try:
            self.engine.log(msg)
        except OSError:
            logging.exception('두 꼬리 신호의 최근 활동 저장 실패')

    def quote_symbols(self):
        with self.lock:
            return {r.symbol for r in self.pending.values() if not r.initial_block}

    def invalidate(self, symbol=None, *, ts=None, low=None, high=None, trade_id=None, trade_bar=None):
        with self.lock:
            for r in self.pending.values():
                if symbol is not None and symbol != r.symbol:
                    continue
                if ts is not None:
                    if ts < r.hit['ts']:
                        continue
                    side = r.hit['side']
                    extreme = low if side == 1 else high
                    if side*(extreme-r.hit['second']) >= -float(r.tick)*1e-6:
                        if trade_bar is not None and r.observe_retest(ts,trade_id,low,trade_bar):
                            self.engine.command_wake.set()
                        continue
                r.invalid.set()

    def authorized(self, signal):
        return self.current is not None and self.current[1] is signal

    def validate(self, signal, price):
        if not self.current or self.current[1] != signal:
            raise BotError('실시간 두 꼬리 신호 확인 필요')
        r = self.current[0]
        reason = self.blocked()
        if reason:
            raise BotError(reason)
        if r.invalid.is_set() or not signal['valid_from_ms'] <= self.engine.api.now_ms() <= signal['expires_ms']:
            raise BotError('두 번째 꼬리 이탈, 시세 단절 또는 신호 만료')
        side = r.hit['side']
        distance = side*(price-r.hit['second'])
        if (not math.isfinite(price) or distance<=0
                or abs(price-r.entry_hit['price'])>.5*r.hit['anchor_atr']
                or (r.wait_retest and distance>(2+1e-6)*float(r.tick))
                or (r.wait_follow and not r.follows_price(price))):
            raise BotError('호가가 두 번째 꼬리의 반응 범위를 벗어남')
        return signal['decision_record']['volume_wick_proof']

    def record(self, r):
        e = self.engine
        previous = e.journal.data.get('pc_wick280_seen',{})
        if previous.get(r.key,-1)>=r.hit['anchor_ms']:
            return False
        e.journal.data['pc_wick280_seen'] = {**previous, r.key:r.hit['anchor_ms']}
        try:
            e.journal.save()
        except Exception:
            e.journal.data['pc_wick280_seen'] = previous
            raise
        return True

    def report(self, r, text):
        side = '롱' if r.hit['side']==1 else '숏'
        msg = f"[두 꼬리 자동 {side}] {r.symbol}\n{text}"
        if r.confirmation:
            msg += '\n'+r.timing_label+' 확인'
        try:
            self.engine.log(msg)
        except OSError:
            logging.exception('두 꼬리 자동 주문 결과의 최근 활동 저장 실패')
        try:
            self.engine.notifier.wick_result(msg,r.signal_id,chart=r.entry_chart)
        except Exception:
            logging.exception('두 꼬리 자동 주문 결과 알림 보관 실패')

    def poll(self):
        """Called only on the engine worker, after position protection and manual requests."""
        e = self.engine
        with self.lock:
            batch = tuple(self.pending.values())
        for r in batch:
            if not r.announced.is_set():
                continue
            reason = r.initial_block or self.blocked()
            if not reason and r.invalid.is_set():
                reason = '두 번째 꼬리 이탈, 시세 단절 또는 신호 만료'
            if not reason and e.api.now_ms() > r.expires_ms:
                if r.expires_ms < r.hit['ts']+TTL_MS:
                    reason = '15분봉 전환으로 재반응 신호 만료'
                elif r.wait_follow and not r.confirmation:
                    reason = '일목·RSI 추가 체결 없이 신호 15초 만료'
                else:
                    reason = ('두 번째 꼬리 재반응 없이 신호 15초 만료'
                              if r.wait_retest and not r.confirmation else '두 꼬리 신호 15초 만료')
            if not reason and (not e.can_open_position() or r.symbol in e.blocked_manual_symbols()
                               or any(o['symbol']==r.symbol for o in e.records())):
                reason = '포지션 한도 또는 같은 종목 보유·주문 중'
            if not reason and r.needs_confirmation and not r.confirmation:
                continue
            if not reason and not e.stream.ready(r.symbol,e.cfg,e.api.now_ms()):
                continue
            claimed = self.record(r)
            try:
                if not claimed or r.initial_block:
                    continue
                if reason:
                    self.report(r,'자동 미진입 · '+reason)
                    continue
                signal = make_signal(e,r)
                self.current = (r,signal)
                self.validate(signal,r.entry_hit['price'])
                with e.selected(e.empty_slot()):
                    try:
                        e.executing_signal = signal
                        e.entry(signal)
                    finally:
                        e.executing_signal = None
                submitted = any(o.get('v4_signal',{}).get('signal_id')==r.signal_id for o in e.records())
                self.report(r,'자동 주문 접수 · 체결·손절 등록 확인 중' if submitted else '자동 미진입 · 주문 전 계정 또는 시세 상태 변경')
                return submitted  # Reconcile positions before another new submission.
            except UnknownOutcome:
                self.report(r,'자동 주문 결과 미확인 · 재주문 없이 거래소 대조 중')
                raise
            except BotError as exc:
                self.report(r,'자동 미진입 · '+str(exc))
            except Exception:
                self.report(r,'자동 처리 결과 미확인 · 거래소 대조 중')
                raise
            finally:
                self.current = None
                with self.lock:
                    self.pending.pop(r.signal_id,None)

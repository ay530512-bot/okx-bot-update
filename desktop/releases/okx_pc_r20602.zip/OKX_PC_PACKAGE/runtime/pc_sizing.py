"""PC entry budget, indicator leverage, and structure-based stops."""
import math

SLOTS = 3
RESERVE = 3
TRADE_RISK = .005
OBSERVATION_COST = .002  # Same two-way fee and slip model as pc_forward.


def configure(cfg):
    cfg['risk'].update(pc_three_slots=True, max_positions=SLOTS, entry_cash_reserve_usdt=RESERVE,
                       initial_margin_fraction=1/SLOTS, max_total_margin_fraction=1.,
                       leverage=3, min_leverage=3, max_leverage=5, leverage_mode='signal',
                       initial_size_mode='pc_three_slots')


def indicator_level(ev):
    votes = (ev['rv'] >= 1.3, ev['slope'] > 0 and 0 <= ev['stretch'] <= 1.5,
             ev['rsi_direction'] > 0 and ev['location'] >= .60)
    return (3, 3, 4, 5)[sum(votes)]


def leverage_for(ev, price, exchange_limit):
    """Never pull a stop inward to make an entry fit the account risk budget."""
    if price <= 0 or not all(map(math.isfinite, (price, ev['stop'], exchange_limit))):
        return 0
    distance = abs(price-ev['stop'])/price + OBSERVATION_COST
    ceiling = min(indicator_level(ev), int(exchange_limit))
    for level in range(ceiling, 2, -1):
        if distance * level / SLOTS <= TRADE_RISK:
            return level
    return 0


def legacy_signal(signal, bars, instrument):
    """Apply the PC policy to restored automatic routes using available closed bars."""
    from okx_core import BotError
    from pc_timing import indicators, round_stop
    direction = 1 if signal['action'] == 'LONG' else -1
    proof = signal['decision_record']['volume_wick_proof']
    tick, atr = float(instrument['tickSz']), float(signal['atr'])
    details = proof.get('pattern_details', {})
    anchor = details.get('prior_low' if direction == 1 else 'prior_high')
    if anchor is not None:
        second = details['second_low' if direction == 1 else 'second_high']
        if direction*(second-anchor) <= 0:
            raise BotError('두 번째 꼬리가 첫 극값 안쪽에서 지지·저항을 확인하지 못함')
        stop = round_stop(anchor-direction*max(2*tick,.15*atr),tick,direction)
        signal.update(stop=stop, level=stop)
        proof.update(structural_stop=stop, first_wick=anchor, second_wick=second)
        signal['holding_rule']['zone'] = stop
    ev = indicators(bars, direction, atr)
    if not ev:
        raise BotError('배율 계산용 확정봉 대기')
    ev['stop'] = signal['stop']
    maximum = float(instrument.get('lever') or 0)
    level = leverage_for(ev, signal['entry_reference'], maximum)
    if not level:
        raise BotError('3배에서도 구조 손절 위험 한도 초과')
    signal.update(pc260=True, leverage=level, indicator_limit=maximum, margin_fraction=1/SLOTS)
    proof['sizing_indicators'] = ev
    return signal


def valid(signal):
    level = signal.get('leverage')
    if type(level) is not int or not 3 <= level <= 5:
        return False
    if signal.get('click716'):
        return level == 5
    if not signal.get('pc260'):
        return False
    proof = signal.get('decision_record', {}).get('volume_wick_proof', {})
    ev = proof.get('timing') or proof.get('sizing_indicators')
    if not ev or ev.get('stop') != signal.get('stop'):
        return False
    return level == leverage_for(ev, signal['entry_reference'], signal['indicator_limit'])


def submit_batch(engine, first, submit_one):
    """The existing single engine worker serializes writes and reserves each slot before the next."""
    if (not engine.cfg['risk'].get('pc_three_slots') or not first.get('monthly208')
            or engine.cfg['execution']['ai_confirmation']):
        submit_one(first)
        return
    from okx_search_capacity import occupied
    from pc_monthly import RULES
    remaining = max(0,SLOTS-occupied(engine))
    signal = first
    engine.pc_batch_seen = set()
    try:
        # Each unique, time-valid candidate gets at most one attempt in this pass.
        while signal and len(engine.pc_batch_seen)<len(RULES):
            if (remaining <= 0 or not engine.can_open_position() or not engine.enabled or engine.recovering
                    or engine.stop_event.is_set() or engine.entry_cancel.is_set() or not engine.within_session()
                    or (engine.journal.data.get('day') or {}).get('ended')):
                break
            ident = signal['signal_id']
            if ident in engine.pc_batch_seen:break
            engine.pc_batch_seen.add(ident)
            before = len(engine.records())
            submit_one(signal)
            remaining -= max(0,len(engine.records())-before)
            if not remaining or not engine.can_open_position():break
            signal = engine.candidate_decision()
    finally:
        engine.pc_batch_seen.clear()

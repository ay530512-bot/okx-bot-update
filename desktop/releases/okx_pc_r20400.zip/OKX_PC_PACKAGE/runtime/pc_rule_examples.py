"""Display-only examples for the KST schedule. All chart prices are illustrative."""

# Each candle is (open, high, low, close) in illustrative price units.
# The last close is the reference used to evaluate an entry.
SWEEP = [(50,61,46,57),(57,69,54,66),(66,74,59,61),(61,70,57,68),(68,87,60,64)]
WICKS = [(44,54,40,51),(51,74,49,60),(60,65,54,57),(57,67,55,64),(64,75,53,56)]
PULL = [(47,61,44,58),(58,72,56,68),(68,70,56,60),(60,64,53,58),(58,74,56,70)]


def inverse(bars):
    return [(120-o, 120-lo, 120-hi, 120-c) for o, hi, lo, c in bars]


# (direction, explanation, illustrated candles, reference label, reference path)
EXAMPLES = {
    'reversal': [('숏', '직전 12봉 고점을 넘겼다가 긴 윗꼬리를 남기고 그 고점 아래로 마감합니다. 거래량이 직전 20봉 평균의 1.7배 이상이고 RSI가 내려갈 때 마지막 봉 종가를 봅니다.', SWEEP, '직전 12봉 고점', [74]*5)],
    'two_wick': [('숏', '앞선 상승 후 윗꼬리가 나온 고점 부근을 다시 시험합니다. 두 번째 윗꼬리 봉이 음봉으로 마감하고 RSI가 내려가면 그 종가가 숏 기준입니다.', WICKS, '앞선 윗꼬리 고점', [74]*5)],
    'afternoon_vwap': [('숏', '1시간 EMA20이 EMA50 이하이고 직전 종가가 32봉 거래량가중평균보다 1.25 ATR 넘게 높았던 경우입니다. 거래량이 평균의 2.5배 이상인 음봉이 평균선 위에서 마감하고 RSI가 하락하면 숏을 평가합니다.', [(48,59,46,56),(56,66,52,63),(63,74,61,70),(70,86,67,82),(82,84,64,68)], '32봉 거래량가중평균', [48,50,52,55,57])],
    'evening_pullback': [
        ('롱', '1시간 EMA20이 EMA50 위에 있고 15분 EMA20도 상승 중입니다. 최근 눌림이 이평선 부근에서 멈춘 뒤 거래량이 평균의 2.75배 이상인 양봉이 직전 봉 고점 위에서 마감하면 롱을 평가합니다.', PULL, '직전 봉 고점', [64]*5),
        ('숏', '1시간 EMA20이 EMA50 이하이고 15분 EMA20도 하락 중입니다. 이평선 부근 반등 후 거래량이 평균의 2.75배 이상인 음봉이 직전 봉 저점 아래에서 마감하면 숏을 평가합니다.', inverse(PULL), '직전 봉 저점', [56]*5)],
    'late_reversal': [
        ('롱', '정각에 끝나는 15분봉이 직전 12봉 저점을 깼다가 긴 아랫꼬리를 남기고 그 저점 위로 복귀합니다. RSI가 상승하고 거래량이 평균의 2.5배 이상이면 복귀한 종가를 봅니다.', inverse(SWEEP), '직전 12봉 저점', [46]*5),
        ('숏', '정각에 끝나는 15분봉이 직전 12봉 고점을 넘겼다가 긴 윗꼬리를 남기고 그 고점 아래로 복귀합니다. RSI가 하락하고 거래량이 평균의 2.5배 이상이면 복귀한 종가를 봅니다.', SWEEP, '직전 12봉 고점', [74]*5)],
    'failed_wick': [('숏', '직전 봉이 앞선 12봉 저점을 깨고 긴 아랫꼬리로 반등했지만 다음 봉 종가가 그 꼬리 저점과 EMA20 아래로 떨어집니다. 시장 상승률 중앙값이 0 이하이고 종목이 시장보다 0.3%p 이상 약하면 숏을 평가합니다.', [(74,78,64,68),(68,71,57,60),(60,67,54,64),(64,66,42,60),(60,61,33,36)], '직전 아랫꼬리 저점', [42]*5)],
    'rank_short': [('숏', '전일 상승률 상위 3개 종목에서 앞선 윗꼬리 고점 부근에 두 번째 윗꼬리가 생기는지 봅니다. 거래량이 평균의 1.5배 이상이고 RSI가 내려가며 음봉으로 마감하면 그 종가에서 숏을 평가합니다.', WICKS, '앞선 윗꼬리 고점', [74]*5)],
    'trend_long': [('롱', '당일 상승률 1위 종목에서 15분 EMA20이 상승하고, 양봉이 EMA20 위에서 마감해야 합니다. 종가가 직전 종가보다 0.1 ATR 넘게 높으면 롱을 평가하고 주문 직전에도 1위 여부를 재확인합니다.', [(44,54,42,51),(51,61,48,58),(58,63,52,55),(55,66,53,62),(62,76,60,72)], '15분 EMA20', [42,44,46,49,52])],
}


def figure(example, frame=15):
    side, explanation, bars, reference, levels = example
    xs = [26, 65, 104, 143, 182]
    def y(value):
        return 132 - value
    points = ' '.join(f'{x},{y(v)}' for x, v in zip(xs, levels))
    candles = []
    for x, (op, high, low, close) in zip(xs, bars):
        color = '#58d6a3' if close >= op else '#ff8793'
        candles.append(f'<g data-prices="{op},{high},{low},{close}" data-x="{x}"><path d="M{x} {y(high)}V{y(low)}" stroke="{color}" stroke-width="2"/>'
                       f'<rect x="{x-6}" y="{y(max(op,close))}" width="12" height="{max(abs(op-close),1)}" fill="{color}"/></g>')
    cy = y(bars[-1][3])
    return (f'<figure><figcaption><b>{side} 진입 예시</b> · 가상 {frame}분봉</figcaption>'
            f'<svg role="img" aria-label="{side} 예시 차트. 점선은 {reference}, 원은 마지막 확인봉 종가" viewBox="0 0 300 128">'
            f'<text x="12" y="19" fill="#a7bce3">┄ {reference}</text>'
            f'<polyline points="{points}" fill="none" stroke="#91aacd" stroke-dasharray="4 3"/>'
            + ''.join(candles) +
            f'<g class="entry-marker"><circle cx="182" cy="{cy}" r="4" fill="#101010" stroke="white" stroke-width="2"/>'
            f'<path d="M187 {cy}h18" stroke="white"/><text x="209" y="{cy+4}" fill="white">{side} 기준 종가</text></g>'
            f'</svg><p>{explanation}</p></figure>')


LABELS = {
    'reversal': ('확정반전 숏', '윗꼬리·RSI 하락'),
    'two_wick': ('두꼬리 숏', '윗꼬리 반복·음봉'),
    'afternoon_vwap': ('VWAP 회귀 숏', '시간봉 약세·고가 반락'),
    'evening_pullback': ('눌림목 롱·숏', '이평 눌림·재돌파'),
    'late_reversal': ('정각 반전 롱·숏', '고저점 이탈 후 복귀'),
    'failed_wick': ('꼬리 실패 숏', '저점 이탈·상대 약세'),
    'rank_short': ('전일 상위3 숏', '윗꼬리·RSI 하락'),
    'trend_long': ('당일 1위 롱', '상승 EMA20 위 양봉'),
}


LABELS.update({
    'scalp_double': ('두꼬리 롱','1분봉 · 하루 최대 3회'),
    'scalp_break': ('꼬리실패 롱','15분봉 · 하루 최대 3회'),
    'scalp_higher': ('새 음봉꼬리 롱','1분봉 · 하루 최대 1회'),
})
EXAMPLES.update({
    'scalp_double':[('롱','첫 꼬리보다 높은 두 번째 저점에서 양봉 마감과 RSI 상승을 확인합니다. 최근 30분 상승률 1% 이상, 최대 15분 보유입니다.',[(71,74,53,54),(54,55,32,48),(48,60,45,58),(58,60,45,47),(47,59,38,55)],'첫 꼬리 저점',[32]*5)],
    'scalp_break':[('롱','최근 6봉 최고가에 윗꼬리가 생긴 뒤 다음 봉 종가가 그 고점을 돌파해야 합니다. 상승 중인 EMA20과 변동성을 확인하고 최대 30분 보유합니다.',[(42,52,40,50),(50,56,48,54),(54,62,52,60),(60,74,56,62),(62,84,60,79)],'직전 윗꼬리 고점',[74]*5)],
    'scalp_higher':[('롱','윗꼬리 이후 하락해 첫 음봉 아랫꼬리를 만들고 반등합니다. 두 번째 저점이 높고, 그 저점을 지킨 채 4봉 안에 양봉이 두 번째 꼬리 봉 고점을 넘어서 마감하면 진입합니다. 최대 30분 보유입니다.',[(70,86,59,61),(61,63,30,49),(49,72,47,66),(62,64,38,48),(48,74,45,69)],'두 번째 꼬리 봉 고점',[64]*5)],
})

def schedule(rules):
    rows = []
    for key, rule in rules.items():
        label, hint = LABELS[key]
        midnight = '익일 ' if rule.end < rule.start else ''
        hours = f'{rule.start:02}:00–{midnight}{rule.end:02}:00'
        rows.append(f'<details name="pc-rule-examples" class="entry-example"><summary><span><b>{label}</b>'
                    f'<small>{hours} KST · {hint}</small></span><strong>예시보기 <i aria-hidden="true">→</i></strong>'
                    '</summary>' + ''.join(figure(item, 1 if key in ("scalp_double","scalp_higher") else 15) for item in EXAMPLES[key]) + '<button type="button" class="entry-replay">예시 다시 보기 ↻</button></details>')
    return ('<aside id="rules208" class="phone-host-notice"><h2>신규 진입 시간표</h2>'
            '<p class="schedule-note">한국시간 · 종료 시각 미포함 · 기존 규칙은 09시 기준 첫 체결 · 단타 롱은 자정 기준 일일 한도</p>'
            '<p class="schedule-note">증거금 10% · 공용 9 + 전용 1 · 모든 시간표 규칙 · +1R부터 추적손절</p>'
            '<p class="schedule-note">차트의 흰 원은 신호를 확인한 종가입니다. 마감 후 신호 유효시간 안에 가격과 주문 조건을 다시 확인하므로 실제 체결가는 달라질 수 있습니다.</p>'
            + ''.join(rows) + '</aside>')

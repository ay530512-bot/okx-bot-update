"""Completed prior-session top-three short scan and existing position management."""
import copy
import hashlib
import math
from pathlib import Path

STEP = 900000
HOUR = 3600000
DAY = 86400000
LEGACY_ROUTE = 'top1_morning_failed_rebound150'
ROUTE = 'prior_top3_indicator_short206'
BASIS = 'kst09_prev_completed'
STATE = 'phone_morning150'
STOP_BUFFER_ATR = .2
TRAIL_ATR = 2.
SIGNAL_BARS = 60

def is_signal(s):
    return bool(s and (s.get('morning150') or s.get('pattern') in (ROUTE, LEGACY_ROUTE)
                      or str(s.get('signal_id', '')).startswith('ms150-')))


def is_owned(o):
    return bool(o and (is_signal(o.get('v4_signal')) or (o.get('holding_rule') or {}).get('morning150')))


def in_window(t):
    return 11 * HOUR <= (int(t) + 9 * HOUR) % DAY < 15 * HOUR


def pattern(b):
    from okx_market import ema, rsi
    from phone_trend_slot import atr
    if len(b) < SIGNAL_BARS:
        return None
    b = b[-SIGNAL_BARS:]
    closes = [r[4] for r in b]
    last = b[-1]
    previous = b[-5:-1]
    average = ema(closes, 20)
    strength = rsi(closes)
    baseline = sum(r[5] for r in b[-21:-1])/20
    a = atr(b[:-1])
    if baseline <= 0 or not math.isfinite(a) or a <= 0:
        return None
    volume = last[5]/baseline
    support = min(r[3] for r in previous)
    if not (last[4] < min(last[1], support, average) and average < ema(closes[:-3], 20)
            and 35 <= strength <= 48 and strength < rsi(closes[:-1]) and volume >= 1.2):
        return None
    stop = max(r[2] for r in b[-5:])+STOP_BUFFER_ATR*a
    if not 0 < stop-last[4] < .09*last[4]:
        return None
    return dict(action='SHORT', reference=last[4], atr=a, structural_stop=stop,
                confirmation_ms=int(last[0]), route721=ROUTE, morning150=True,
                ema20=average, rsi14=strength, relative_volume=volume, breakdown_level=support,
                breakdown_atr=(support-last[4])/a)


def rank_rows(rows, day):
    start = day-DAY
    ranks, missing = [], []
    for row in rows:
        bars = {int(b[0]): b for b in row['live_frames'].get('1H', ())
                if int(b[0]) in (start,day-HOUR)}
        try:
            opening, closing = float(bars[start][1]), float(bars[day-HOUR][4])
            gain = closing/opening-1
            if min(opening, closing) <= 0 or not math.isfinite(gain):
                raise ValueError('invalid previous session')
        except (KeyError, ValueError, TypeError, ZeroDivisionError, OverflowError):
            missing.append(row['symbol'])
            continue
        if gain > 0:
            ranks.append((gain, row['symbol']))
    if missing or not rows:
        raise ValueError(f'전일 상승률 자료 대기 · {len(rows)-len(missing)}/{len(rows)}종목')
    ranks.sort(key=lambda x: (-x[0], x[1]))
    return [dict(symbol=symbol, gain=gain, rank=i, day=day, start=start, basis=BASIS)
            for i,(gain,symbol) in enumerate(ranks[:3], 1)]


def shortlist(e, day):
    from phone_trend_slot import permitted
    from phone_trend_inputs import listed_after_reference
    state = e.journal.data[STATE]
    if state.get('top3_day') == day and isinstance(state.get('top3'), list):
        return state['top3']
    u = e.universe
    with u.lock:
        m = u.full_market
        cache = getattr(m, 'band_cache', {})
        rows = []
        for symbol, instrument in m.instruments.items():
            if not permitted(dict(symbol=symbol,instrument=instrument),e.cfg):
                continue
            if listed_after_reference(symbol,instrument,day-DAY,e.api.now_ms()):
                continue
            cached = cache.get((symbol,'1H'))
            rows.append(dict(symbol=symbol,live_frames={'1H':tuple(cached[1]) if cached else ()}))
    top = rank_rows(rows,day)
    state.update(top3_day=day,top3=top)
    e.journal.save()
    return top


def day_prefix(day):
    return f'ms150-d{day//DAY}-'


def used_today(e, day):
    prefix=day_prefix(day)
    return any(k.partition(':')[2].startswith(prefix) for k in e.journal.data.get('seen_signals', {}))


def check_selection(e,s,now):
    from okx_core import BotError
    day = now//DAY*DAY
    state = e.journal.data.get(STATE,{})
    rank = next((r for r in state.get('top3', []) if r['symbol']==s['symbol']),None)
    if (s.get('pattern')!=ROUTE or state.get('top3_day')!=day or not rank
            or rank!=s.get('decision_record',{}).get('rank150')
            or s.get('signal_id')!=(state.get('pending') or {}).get('signal_id')
            or used_today(e,day)):
        raise BotError('전일 상위3 숏 후보 또는 당일 진입 한도 재확인')
    return rank


def make_signal(symbol, proof, rank, now):
    start = proof['confirmation_ms']+STEP
    return dict(symbol=symbol, action='SHORT', leverage=5, strategy='band_flow',
                pattern=ROUTE, morning150=True, rule_channel701=True, free_ai=True, pattern15=True,
                stop=proof['structural_stop'], target=None, margin_fraction=.25,
                signal_id=day_prefix(rank['day'])+hashlib.sha256(f"{symbol}|{start}".encode()).hexdigest()[:16],
                atr=proof['atr'], level=proof['structural_stop'],
                reason=f'전일 상승 {rank["rank"]}위 숏 · KST11~15 · 15분 EMA·RSI·거래량 확인 · 5배 전량 추적',
                regime='전일 상승 상위3 · 15분 하락 확인', ma={}, bb={}, rsi={}, retest=False, adaptive=False,
                setup_frame='15m', execution_frame='15m', at_ms=now,
                valid_from_ms=start, expires_ms=start+90000,
                entry_reference=proof['reference'], entry_gap=proof['reference'],
                selection=dict(activity={}, asset_category='1', change=rank['gain'], mover_rank=rank['rank'],
                               ranking_start_ms=rank['start'], ranking_end_ms=rank['day'], ranking_basis=BASIS),
                holding_rule=dict(band_flow=True, free_ai=True, pattern15=True, rule_channel701=True,
                                  morning150=True, frame='15m', target=None, target_mode='morning150',
                                  max_hold_seconds=259200, partial=False),
                decision_record=dict(source=ROUTE, frames={}, volume_wick_proof=proof,
                                     evidence704=dict(score=0), rank150=rank))


def scan(e):
    from phone_live_rank import selected_rows
    from phone_trend_slot import completed
    now = e.api.now_ms(); t = now//STEP*STEP; day = now//DAY*DAY
    state = e.journal.data.setdefault(STATE, {})
    if state.get('session') != day:
        state.update(session=day,pending=None,last=0,rank=None)
        e.journal.save()
    # At 09:00 the preceding KST09 session ends; prepare the list before 11:00.
    if now % DAY >= 6*HOUR or used_today(e, day):
        e.phone_morning_status = ('오늘 숏 진입 처리 완료' if used_today(e, day)
                                  else '신규 숏 진입 KST11:00~15:00 미만')
        if state.get('pending'):
            state['pending']=None; e.journal.save()
        return None
    if state.get('top3_day') != day:
        if now-getattr(e,'_phone_top3_attempt',0)<3000:
            return None
        e._phone_top3_attempt=now
    try:
        top = shortlist(e, day)
    except (ValueError, KeyError, TypeError, AttributeError, IndexError, OverflowError) as error:
        e.phone_morning_status = str(error)
        return None
    if not in_window(now):
        e.phone_morning_status='전일 상승률 후보 확정 · KST11:00부터 숏 검사'
        return None
    if not top:
        e.phone_morning_status='전일 상승 종목 없음'
        return None
    if state.get('last') != t:
        if now>t+90000:
            e.phone_morning_status='15분봉 신호 유효시간 종료 · 다음 완료봉 대기'
            return None
        options=[]
        blocked=set(e.blocked_manual_symbols())
        from phone_trend_slot import is_owned as trend_owned
        blocked.update(r['symbol'] for r in e.records() if not trend_owned(r))
        raw=getattr(e,'raw_snapshot',None) or {}
        blocked.update(r['instId'] for r in raw.get('orders',[])+raw.get('manual_orders',[]))
        if t==state.get('retry_t') and now-state.get('retry_at',0)<1000:
            return None
        state.update(retry_t=t,retry_at=now)
        for rank in top:
            if rank['symbol'] in blocked:
                continue
            try:
                row=selected_rows(e,rank)[0]
                if float(row['instrument'].get('lever') or 0)<5:
                    continue
                b=completed(row['live_frames'].get('15m', [])[-(SIGNAL_BARS+2):],t,STEP,SIGNAL_BARS)
                proof=pattern(b)
            except (ValueError, KeyError, TypeError, IndexError, OverflowError):
                e.phone_morning_status='전일 상위3 숏용 15분 완료봉 대기'
                return None
            if proof:
                options.append((proof,rank,row))
        state.update(last=t,pending=None,rank=None)
        if options:
            proof,rank,row=max(options,key=lambda x:(x[0]['relative_volume'],x[0]['breakdown_atr'],-x[1]['rank']))
            state.update(pending=make_signal(rank['symbol'],proof,rank,now),rank=rank)
            e.phone_morning_timing=dict(input_published_ms=row.get('observed_ms'),
                rank_inputs_captured_ms=row.get('cache_read_ms'),
                computation_submitted_ms=now,computation_published_ms=e.api.now_ms())
        e.journal.save()
    pending=state.get('pending')
    if pending and pending['valid_from_ms']<=now<=pending['expires_ms']:
        e.phone_morning_status='전일 상위3 중 '+pending['symbol']+' 숏 조건 확인 · 주문 검사 대기'
        return copy.deepcopy(pending)
    e.phone_morning_status='전일 상위3 · EMA20·RSI·거래량 하락 조건 대기'
    return None


def prewarm_symbols(e, now):
    state=e.journal.data.get(STATE,{})
    if 2*HOUR-300000 <= now%DAY < 6*HOUR and state.get('top3_day')==now//DAY*DAY:
        return {r['symbol'] for r in state.get('top3',())}
    return set()


def validate_entry(e, s, price, closing_owned=None):
    from okx_core import BotError
    from okx_band_flow import rows as parse
    from phone_trend_slot import completed, require_slot
    now = e.api.now_ms()
    try:
        if not is_signal(s) or type(s.get('leverage')) is not int or s['leverage'] != 5 or s.get('action') != 'SHORT':
            raise ValueError('오전 숏 신호/방향/배율 불일치')
        if (Path(e.root).parent/'phone_trend_activation_hold').exists():
            raise ValueError('새 실행기 준비 확인 후 전용 진입 재개')
        if not in_window(now):
            raise ValueError('전일 상위3 숏 진입 시간 종료 · KST11~15')
        if not s['valid_from_ms'] <= now <= s['expires_ms'] or not in_window(s['valid_from_ms']):
            raise ValueError('오전 숏 신호 90초 만료 또는 시간 밖 완료봉')
        if closing_owned is None:
            require_slot(e, s)
            verify_switch_flat(e, s)
        else:
            validate_switch_scope(e, s, closing_owned)
        rank = check_selection(e, s, now)
        raw = parse(e.api.public('/api/v5/market/candles', instId=s['symbol'], bar='15m', limit='100'), '15m', now)
        b = completed(raw[-(SIGNAL_BARS+2):], now, STEP, SIGNAL_BARS)
        proof = pattern(b)
        if proof != s['decision_record']['volume_wick_proof']:
            raise ValueError('오전 숏 원래 확정봉 신호 변경')
        if (s['stop'] != proof['structural_stop'] or s['valid_from_ms'] != proof['confirmation_ms']+STEP
                or s['expires_ms'] != s['valid_from_ms']+90000
                or s['signal_id'] != make_signal(s['symbol'], proof, rank, now)['signal_id']):
            raise ValueError('오전 숏 저장 신호 변경')
        price = float(price)
        if (not math.isfinite(price) or price <= 0 or not 0 < s['stop']-price < .09*price
                or abs(price-proof['reference']) > .5*proof['atr']):
            raise ValueError('오전 숏 진입 호가/손절 범위 이탈')
        if any(r[0] >= s['valid_from_ms'] and r[2] >= s['stop'] for r in raw):
            raise ValueError('오전 숏 대기 중 초기SL 도달')
        # A slow REST call must not carry an otherwise valid signal past 15:00.
        final_now = e.api.now_ms()
        if not in_window(final_now) or final_now > s['expires_ms']:
            raise ValueError('오전 숏 주문 직전 시간 종료 또는 신호 만료')
        from phone_live_rank import check
        check(e, s)
        return proof
    except (ValueError, KeyError, TypeError, IndexError, OverflowError) as error:
        raise BotError(str(error)) from None


def switch_enabled(e):
    return (bool(getattr(e, 'enabled', False)) and not getattr(e, 'preview', False)
            and not getattr(e, 'user_paused', True) and not getattr(e, 'recovering', True)
            and not e.entry_cancel.is_set() and e.within_session()
            and not (e.journal.data.get('day') or {}).get('ended', False))


def validate_switch_scope(e, s, o):
    from okx_core import BotError
    from phone_trend_slot import is_owned as long_owned, slot_counts
    if (not long_owned(o) or o.get('direction') != 'long' or o.get('phase') != 'active'
            or not o.get('protection_verified') or e.journal.data.get('owned') is not o
            or not switch_enabled(e)):
        raise BotError('롱→숏 전환 운용/보유 상태 대기')
    total, reserved, _ = slot_counts(e)
    if total > 4 or reserved != 1:
        raise BotError('롱→숏 전환 자리 대조 실패')
    others = [r for r in e.records() if r['client_id'] != o['client_id']]
    if s['symbol'] in e.blocked_manual_symbols() or any(r['symbol'] == s['symbol'] for r in others):
        raise BotError('전환 대상에 별도 보유/수동 주문 존재')
    raw = getattr(e, 'raw_snapshot', None) or {}
    if any(p['instId'] == s['symbol'] and float(p.get('pos') or 0)
           and (p['instId'], p.get('posSide')) != (o['symbol'], 'long') for p in raw.get('positions', [])):
        raise BotError('전환 대상에 다른 포지션 존재')
    if any(p['instId'] in (s['symbol'], o['symbol']) for p in raw.get('orders', [])+raw.get('manual_orders', [])):
        raise BotError('전환 대상 미체결 대조 대기')


def verify_switch_flat(e, s):
    """Durable close intent is not a fill. Require exchange-confirmed flatness."""
    from okx_core import BotError, dec
    switch = e.journal.data.get(STATE, {}).get('switch')
    if not switch or switch.get('confirmed_ms'):
        return
    if not switch.get('close_id') or any(r['client_id'] == switch['long_client_id'] for r in e.records()):
        raise BotError('롱 청산 완료 대기 · 숏 주문 보류')
    raw = e.api.snapshot()
    if not 0 <= e.api.now_ms()-int(raw['ms']) <= 15000:
        raise BotError('전환 계좌 자료 지연')
    if any(p['instId'] == switch['long_symbol'] and p.get('posSide') == 'long'
           and dec(p.get('pos') or 0) != 0 for p in raw.get('positions', [])):
        raise BotError('롱 잔량 존재 · 숏 주문 보류')
    if any(p['instId'] == switch['long_symbol'] for p in raw.get('orders', [])):
        raise BotError('롱 미체결 정리 대기 · 숏 주문 보류')
    order = e.api.get('/api/v5/trade/order', instId=switch['long_symbol'], clOrdId=switch['close_id'])[0]
    if (order.get('state') != 'filled' or dec(order.get('accFillSz') or 0) != dec(switch['quantity'])
            or order.get('posSide') != 'long' or order.get('side') != 'sell'):
        raise BotError('롱 청산 체결 확인 대기 · 숏 주문 보류')
    if any(p['instId'] == switch['long_symbol'] and p.get('posSide') == 'long'
           for p in e.api.pending_algos(full=True)):
        raise BotError('롱 보호주문 정리 대기 · 숏 주문 보류')
    switch['confirmed_ms'] = e.api.now_ms()
    e.journal.save()


def maybe_switch(e, snap, p, o):
    """Called only by the serialized management of the original reserved long."""
    from okx_core import BotError
    if not in_window(e.api.now_ms()) or not switch_enabled(e):
        return False
    s = scan(e)
    if not s:
        return False
    e.stream.watch([s['symbol']]+[r['symbol'] for r in e.records()]+e.chat.watch())
    if not e.stream.ready(s['symbol'], e.cfg, e.api.now_ms()):
        e.phone_morning_status = '롱 유지 · 전환 대상 실시간 시세 대기'
        return False
    q = e.stream.read(s['symbol'], 'tickers', 15, e.api.now_ms())
    if not q or not q.get('last'):
        return False
    try:
        validate_entry(e, s, q['last'], closing_owned=o)
    except BotError as error:
        e.phone_morning_status = '롱 유지 · '+str(error)
        return False
    # Persist before the close request; never place a short here. Existing
    # reconciliation owns retries, full close, and protective-order cleanup.
    state = e.journal.data[STATE]
    state['switch'] = dict(signal_id=s['signal_id'], long_symbol=o['symbol'],
                           long_client_id=o['client_id'], quantity=o['quantity'],
                           requested_ms=e.api.now_ms(), target_symbol=s['symbol'], close_id=None)
    e.journal.save()
    e.phone_morning_status = '롱 청산 요청 → 실제 청산 확인 후 오전 숏 재검사'
    try:
        e.close(snap, '전일 상승 상위3 숏 조건 · 추세 롱→숏 전환')
    finally:
        state['switch']['close_id'] = o.get('close_id')
        e.journal.save()
    return True


def needs_reversal_search(e):
    from phone_trend_slot import is_owned as long_owned
    return in_window(e.api.now_ms()) and switch_enabled(e) and any(
        long_owned(o) and o.get('direction') == 'long' for o in e.records())


def observe(e, snapshot, p, o):
    from okx_core import BotError
    if o.get('direction') != 'short' or float(o.get('leverage') or 0) != 5:
        raise BotError('오전 숏 보유 기록 방향/배율 불일치 · 거래소 보호 유지')
    entry, mark = float(p.get('avgPx') or 0), float(p.get('markPx') or 0)
    if not all(math.isfinite(x) and x > 0 for x in (entry, mark)):
        return p
    now = e.api.now_ms(); state = o.setdefault('profit_state714', {})
    low = min(entry, mark, float(state.get('peak_mark') or entry))
    if hasattr(e, 'profit_lock714'):
        with e.profit_lock714:
            buf = e.profit_marks714.pop(o['client_id'], None)
        if (buf and int(o.get('entry_ms') or 0) <= buf['last_ms'] <= now
                and buf['side'] == -1 and abs(float(buf['entry'])-entry) <= entry*1e-8):
            low = min(low, buf['peak'])
            if now-buf['last_ms'] <= 15000:
                mark = buf['last']; p = dict(p, markPx=str(mark))
    before = dict(state)
    state.update(peak_mark=low, peak_roe=max(0., (1-low/entry)*5), entry=entry, side=-1)
    if state != before:
        state['observed_ms'] = now; e.journal.save()
    return p


def manage(e, snap, p, o):
    from okx_core import BotError
    from okx_profit_guard714 import effective_stop
    from phone_trend_slot import completed, atr
    if o.get('direction') != 'short' or float(o.get('leverage') or 0) != 5:
        raise BotError('오전 숏 보유 기록 방향/배율 불일치 · 거래소 보호 유지')
    # No entry-window check here: filled positions remain protected after the entry window.
    now = e.api.now_ms(); mark = float(p['markPx'])
    if not math.isfinite(mark) or mark <= 0:
        return False
    if mark >= effective_stop(o):
        e.close(snap, '오전 숏 전량 보호 SL 도달'); return True
    if now-int(o['entry_ms']) >= 259200000:
        e.close(snap, '오전 숏 최대72시간 만료'); return True
    bars = e.chart_job(o['symbol']) or {}
    try:
        a = atr(completed(bars.get('15m', []), now, STEP, 15))
        if not math.isfinite(a) or a <= 0:
            return False
    except (ValueError, TypeError, KeyError, IndexError, OverflowError):
        return False
    state = o.setdefault('profit_state714', {})
    target = min(effective_stop(o), float(state.get('peak_mark') or mark)+TRAIL_ATR*a)
    if target < effective_stop(o):
        state.update(desired_stop=target, stop_reason='오전 숏 최저 관측가격 + 2×15분 ATR')
        e.journal.save()
    if mark >= target:
        e.close(snap, '오전 숏 전량 추적 SL 도달'); return True
    if target >= float(o['stop_px']) or now-o.get('morning_amend_ms', 0) < 2000:
        return False
    e.trail(snap, p, o, target)
    o['morning_amend_ms'] = now; e.journal.save()
    return True

"""Rank the full market's closed-bar strategy signals before admitting an order."""
import math
import queue
import threading
import time
from concurrent.futures import ThreadPoolExecutor

from okx_core import BotError, Rejected, UnknownOutcome
from okx_entry_display513 import display

QUARTER = 900_000
HOUR = 3_600_000
FRAMES = (('15m', QUARTER), ('1H', HOUR))


def spread_bps(quote):
    try:
        bid, ask = float(quote['bidPx']), float(quote['askPx'])
        if math.isfinite(ask) and 0 < bid <= ask:
            return (ask-bid) / ((ask+bid)/2) * 10_000
    except (TypeError, KeyError, ValueError, OverflowError):
        pass
    return None


def make_signal(candidate):
    signal = dict(candidate)
    start = signal['confirmation_ms'] + QUARTER
    signal.update(pc51=True, strategy='ranked51', pattern=signal['strategy_id'],
                  leverage=None, stop=signal['structural_stop'], target=signal['target_price'],
                  entry_reference=signal['reference'], level=signal['reference'], at_ms=start,
                  valid_from_ms=start, expires_ms=start+QUARTER,
                  signal_id=f'v51-{start}', holding_rule={},
                  selection={'rank':signal['priority'], 'activity':{'volume_ratio':signal['score']}})
    return signal


def rank_candidates(candidates):
    ordered = sorted(candidates, key=lambda s: (-s['fit'], -s['score'], s['symbol'], s['action'], s['strategy_id']))
    for rank, signal in enumerate(ordered, 1):
        signal['priority'] = signal['selection']['rank'] = rank
    return ordered


def closed_frame(raw, step, start):
    """Only consecutive exchange-confirmed raw rows ending at this frame's close."""
    rows = {int(r[0]): r for r in raw if len(r) >= 9 and str(r[8]) == '1'}
    ending = start // step * step - step
    if ending not in rows:
        raise ValueError('최근 마감봉 미수신')
    suffix = []
    while ending in rows:
        suffix.append(rows[ending])
        ending -= step
    return suffix[::-1]


def scan(settings, cfg, start, events, stop, deadline):
    from okx_core import OKX
    from okx_pattern15 import allowed
    from pc_strategy51 import evaluate

    def active():
        return not stop.is_set() and time.monotonic() < deadline

    lock = threading.Lock()
    next_read = 0.

    def read_frame(api, symbol, frame, step):
        nonlocal next_read
        with lock:
            when = max(time.monotonic(), next_read)
            next_read = when + .12
        if when >= deadline or stop.wait(max(0., when-time.monotonic())):
            raise TimeoutError()
        rows = api.public('/api/v5/market/candles', instId=symbol, bar=frame, limit='100')
        return closed_frame(rows, step, start)

    api = None
    try:
        api = OKX(settings)
        contracts = api.public('/api/v5/public/instruments', instType='SWAP')
        symbols = sorted({row['instId'] for row in contracts if row.get('instType') == 'SWAP'
                          and allowed(row, cfg) and row['instId'].split('-')[0] not in ('BTC','ETH','SOL')})
        if not symbols:
            raise ValueError('허용 알트 무기한 계약 목록 미수신')
        events.put(('universe', len(symbols)))
        frames_by_symbol = {}

        def attempt(pending):
            todo = queue.Queue()
            failed = []
            for symbol in pending:
                todo.put(symbol)

            def worker():
                client = OKX(settings)
                try:
                    while active():
                        try:
                            symbol = todo.get_nowait()
                        except queue.Empty:
                            break
                        try:
                            frames = {name: read_frame(client, symbol, name, step) for name,step in FRAMES}
                        except Exception:
                            with lock:
                                failed.append(symbol)
                            continue
                        with lock:
                            frames_by_symbol[symbol] = frames
                            events.put(('progress', len(frames_by_symbol)))
                finally:
                    client.session.close()

            with ThreadPoolExecutor(max_workers=4, thread_name_prefix='rank51-candle') as pool:
                futures = [pool.submit(worker) for _ in range(min(4, len(pending)))]
                for future in futures:
                    future.result()
            return failed

        failed = attempt(symbols)
        if failed and active() and not stop.wait(3):
            failed = attempt(failed)
        if not active():
            return
        if not frames_by_symbol:
            raise ValueError('확정봉 수신 실패')
        # A single timestamped spread snapshot makes simultaneous cross-symbol
        # decisions comparable. Revalidate the live bid/ask again at dispatch.
        quotes = {q['instId']: q for q in api.public('/api/v5/market/tickers', instType='SWAP')}
        quote_time = api.now_ms()
        plans = []
        for symbol, frames in frames_by_symbol.items():
            quote = quotes.get(symbol) or {}
            try:
                fresh = 0 <= quote_time - int(quote.get('ts') or 0) <= 10_000
            except (ValueError, TypeError):
                fresh = False
            spread = spread_bps(quote) if fresh else None
            signals = evaluate(symbol, frames, start, spread_bps=spread)
            plans.extend(make_signal(signal) for signal in signals)
        if active():
            events.put(('complete', (rank_candidates(plans), len(failed))))
    except Exception as error:
        if active():
            events.put(('error', f'{type(error).__name__} · {str(error)[:100]}'))
    finally:
        if api is not None:
            api.session.close()


def refresh(e):
    now = e.api.now_ms()
    start = now // QUARTER * QUARTER
    if start != getattr(e, 'ranked51_start', None) or time.monotonic() >= getattr(e, 'ranked51_retry', math.inf):
        if hasattr(e, 'ranked51_stop'):
            e.ranked51_stop.set()
        e.ranked51_start = start
        e.ranked51_plans = []
        e.ranked51_batch = None
        e.ranked51_retry = math.inf
        e.ranked51_delays = {}
        e.ranked51_events = queue.Queue()
        e.ranked51_stop = threading.Event()
        e.ranked51_total = 0
        e.ranked51_status = '5.1 · 전체 알트 무기한 계약 조회 중'
        deadline = time.monotonic() + (start + QUARTER - now)/1000
        threading.Thread(target=scan, args=(e.settings, e.cfg, start, e.ranked51_events,
                         e.ranked51_stop, deadline), name='rank51-market', daemon=True).start()
    while True:
        try:
            kind, value = e.ranked51_events.get_nowait()
        except queue.Empty:
            break
        if kind == 'universe':
            e.ranked51_total = value
            e.ranked51_status = f'5.1 · 0/{value}종목 확정봉 조회 중'
        elif kind == 'progress':
            e.ranked51_status = f'5.1 · {value}/{e.ranked51_total}종목 확정봉 조회 중'
        elif kind == 'error':
            e.ranked51_status = f'5.1 · 스캔 재시도 대기 · {value}'
            e.ranked51_retry = time.monotonic() + 10
        elif kind == 'complete':
            e.ranked51_batch = value
    batch = getattr(e, 'ranked51_batch', None)
    if batch is not None:
        from pc_exit51 import aot_cooldown_until
        plans, missing = batch
        e.ranked51_plans = [s for s in plans if s['strategy_id'] != 'aot'
                            or now >= aot_cooldown_until(e.journal.data, s['symbol'])]
        e.ranked51_status = (f'5.1 · {e.ranked51_total-missing}/{e.ranked51_total}종목 확인'
                             f' · 조건 충족 {len(e.ranked51_plans)}개')
        if missing:
            e.ranked51_status += f' · 확정봉 미수신 {missing}종목 제외'

    display(e).scan(e)


def check_direction(journal, signal):
    prior = journal.get('ranked51_direction_entries', {}).get(signal['action'], {})
    if prior.get('bar') == signal['valid_from_ms']:
        side = '롱' if signal['action'] == 'LONG' else '숏'
        raise BotError(f"이번 15분봉 {side}은 {prior['symbol']} 주문에 배정 · 다음 확정봉 대기")


def reserve_direction(journal, owned):
    signal = owned.get('v4_signal') or {}
    if signal.get('pc51'):
        check_direction(journal, signal)
        journal.setdefault('ranked51_direction_entries', {})[signal['action']] = dict(
            bar=signal['valid_from_ms'], symbol=owned['symbol'], order=owned['client_id'])


def release_unfilled_direction(journal, owned):
    signal = owned.get('v4_signal') or {}
    if signal.get('pc51'):
        sides = journal.get('ranked51_direction_entries', {})
        if sides.get(signal['action'], {}).get('order') == owned['client_id']:
            del sides[signal['action']]


def check(e, s, price):
    now = e.api.now_ms()
    if not s['valid_from_ms'] <= now < s['expires_ms']:
        raise BotError('5.1 확정봉 신호 만료')
    check_direction(e.journal.data, s)
    if s['symbol']+':'+s['signal_id'] in e.journal.data['seen_signals']:
        raise BotError('같은 종목·확정봉에 이미 진입 요청')
    if s['strategy_id'] == 'aot':
        from pc_exit51 import aot_cooldown_until
        if now < aot_cooldown_until(e.journal.data, s['symbol']):
            raise BotError('AOT 손실 후 재진입 대기')
    quote = e.stream.read(s['symbol'], 'tickers', 3, now)
    spread = spread_bps(quote)
    if spread is None:
        raise BotError('5.1 현재 매수·매도 호가 미수신')
    if s['strategy_id'] == 'todd' and spread > 12:
        raise BotError('todd 실행 스프레드 12bp 초과')
    side = 1 if s['action'] == 'LONG' else -1
    touch = float(quote['askPx' if side == 1 else 'bidPx'])
    target = s['target']
    for px in (touch, float(price)):
        if not math.isfinite(px) or abs(px-s['reference']) > .25*s['atr']:
            raise BotError(f"현재 검사 가격 {px:.8g} · 진입 허용 범위 {s['reference']-.25*s['atr']:.8g}~{s['reference']+.25*s['atr']:.8g} 이탈")
        if side*(px-s['stop']) <= 0 or (target is not None and side*(target-px) <= 0):
            raise BotError('5.1 구조 손절 또는 목표 가격 이탈')

    return touch


def key_for_record(record, signal):
    previous = record.get('v4_signal') or {}
    return (record.get('symbol') == signal['symbol'] and previous.get('signal_id') == signal['signal_id'])


def poll(e):
    now = e.api.now_ms()
    records = e.records()
    owned = {r['symbol'] for r in records}
    manual = set(e.blocked_manual_symbols())
    for s in getattr(e, 'ranked51_plans', ()):
        symbol = s['symbol']
        key = (symbol, s['strategy_id'], s['action'])
        if symbol in owned or symbol in manual:
            if not any(key_for_record(r, s) for r in records):
                display(e).note(s, '최종 검사 후 진입 보류', hold_reason='이 종목에 기존 포지션 또는 주문이 있습니다.')
            continue
        if time.monotonic() < e.ranked51_delays.get(key, 0):
            continue
        if not e.stream.ready(symbol, e.cfg, now):
            display(e).note(s, '최종 검사 후 진입 보류', hold_reason='주문에 필요한 최신 실시간 시세를 기다리는 중입니다.')
            continue
        try:
            touch = check(e, s, s['reference'])
        except BotError as error:
            display(e).note(s, '최종 검사 후 진입 보류', hold_reason=str(error))
            continue
        # Bound preflight attempts. Written or ambiguous intents remain protected
        # by the persistent seen_signals key and owned client order identifier.
        with e.selected(e.empty_slot()):
            try:
                e.executing_signal = s
                display(e).note(s, '호가 통과 · 주문 전 최종 검사', touch=touch)
                e.entry(s)
                submitted = e.journal.data.get('owned')
                display(e).note(s, '주문 결과 확인 중' if submitted else '최종 검사 후 진입 보류',
                                hold_reason=None if submitted else '주문 직전 진입 상태가 변경됐습니다.')
            except UnknownOutcome:
                display(e).note(s, '거래소 응답 미확인 · 주문 대조 중')
                raise
            except (Rejected, BotError) as error:
                display(e).note(s, '주문 거부' if isinstance(error, Rejected) else '최종 검사 후 진입 보류', hold_reason=str(error))
                e.pipeline('preflight_rejected', symbol+' / '+str(error))
            finally:
                e.executing_signal = None
                # Begin the backoff after potentially slow private account checks.
                # Other eligible signals can now use the next engine tick.
                e.ranked51_delays[key] = time.monotonic()+30
        return
    e.pipeline('signal_wait', e.ranked51_status)

"""Local capital ledger for automatic orders opened by the 190 USDT profile."""
import json
import time
from decimal import InvalidOperation

from okx_core import BotError, day_key, dec, fmt

INITIAL = dec(190)
KEY = 'auto_capital512'


def limits(engine, snapshot):
    data = engine.journal.data
    if any(s.get(KEY) for s in data.get('settlements', ())):
        raise BotError('자동 운용금 · 청산 순손익 정산 대기')
    ledger = data.get(KEY, {})
    balance = INITIAL + dec(ledger.get('net', 0))
    raw = getattr(engine, 'raw_snapshot', None) or snapshot
    live = {(p['instId'], p.get('posSide')): p for p in raw.get('positions', ()) if dec(p.get('pos') or 0)}
    used = dec(0)
    for o in engine.records():
        if not o.get(KEY):
            if (o.get('v4_signal') or {}).get('pc51'):
                raise BotError('기존 자동 포지션 종료 후 190 USDT 운용 시작')
            continue
        pos = live.get((o['symbol'], o['direction']))
        if not pos and o.get('phase') != 'submitted':
            raise BotError('자동 운용금 · 보유 수량 대조 중')
        used += max(dec(o['committed_margin']), dec((pos or {}).get('margin') or 0))
        # Reserve the opening fee until the final exchange settlement.
        fee = dec(o.get('entry_fee_reserve') or 0)
        balance -= fee
        if pos:
            sign = 1 if o['direction'] == 'long' else -1
            unrealized = (dec(pos['markPx'])-dec(pos['avgPx']))*sign*abs(dec(pos['pos']))*dec(o['ct_val'])
            balance += min(dec(0),unrealized) + min(dec(0),dec(pos.get('realizedPnl') or 0)+fee)
    return max(dec(0), balance), max(dec(0), balance-used)


def _close_day(item):
    # 5.1.2/3 stored the local observation of the closed position, but did
    # not retain OKX's positions-history update time.
    stamp = int(item.get('exchange_close_ms') or item.get('end_ms') or 0)
    return day_key(stamp) if stamp > 0 else None


def _calendar(ledger, today):
    if 'calendar514' not in ledger:
        ledger['calendar514'] = {'days': {}, 'undated': list(ledger['booked']),
                                 'unknown_through': today if ledger['booked'] else None}
    return ledger['calendar514']


def _credit_day(calendar, date, profit):
    days = calendar['days']
    days[date] = fmt(dec(days.get(date, 0)) + dec(profit))


def _historical_days(path, booked, undated):
    found = {}
    wanted = set(undated)
    try:
        with path.open('rb') as history:
            for line in history:
                try:
                    row = json.loads(line)
                    if not isinstance(row, dict) or row.get(KEY) is not True:
                        continue
                    identity = row.get('client_id')
                    if identity not in wanted or dec(row.get('realizedPnl')) != dec(booked[identity]):
                        continue
                    date = _close_day(row)
                    if date:
                        # Duplicate appends can follow a crash before the journal save.
                        # Conflicting dates cannot be assigned to a day reliably.
                        previous = found.setdefault(identity, date)
                        if previous != date:
                            found[identity] = None
                except (ValueError, OSError, TypeError, OverflowError, InvalidOperation, BotError):
                    continue
    except OSError:
        pass
    return found


# The requested retrospective covers the Korean calendar day of the request,
# even if the update is installed later.
BACKFILL_DAY = '2026-11-28'


def eligible_settlement(item):
    if item.get(KEY):
        return True
    return (item.get('entry_method') == 'auto' and item.get('source') != 'manual'
            and _close_day(item) == BACKFILL_DAY)


def _restore_settlements(engine):
    data = engine.journal.data
    path = engine.root / 'position_results.jsonl'
    try:
        history = path.open('rb')
    except FileNotFoundError:
        return
    with history:
        for line in history:
            try:
                row = json.loads(line)
                if (not isinstance(row, dict) or not isinstance(row.get('client_id'), str)
                        or not row['client_id'] or _close_day(row) != BACKFILL_DAY
                        or not eligible_settlement(row)):
                    continue
                profit = dec(row.get('realizedPnl'))
            except (ValueError, OSError, TypeError, OverflowError, InvalidOperation, BotError):
                continue
            settle(data, row, profit)


def initialize_capital(engine, now_ms=None):
    # Runs on startup, before the engine worker and HTTP clients can observe it.
    # The existing startup journal save commits this migration atomically.
    ledger = engine.journal.data.setdefault(KEY, {'net': '0', 'booked': {}})
    today = day_key(int(time.time() * 1000) if now_ms is None else now_ms)
    calendar = _calendar(ledger, today)
    if calendar['undated']:
        found = _historical_days(engine.root / 'position_results.jsonl', ledger['booked'], calendar['undated'])
        missing = []
        for identity in calendar['undated']:
            date = found.get(identity)
            if date:
                _credit_day(calendar, date, ledger['booked'][identity])
            else:
                missing.append(identity)
        calendar['undated'] = missing
        if not missing:
            calendar['unknown_through'] = None
    _restore_settlements(engine)
    publish_capital(engine)


def settle(data, item, profit):
    if not eligible_settlement(item):
        return
    ledger = data.setdefault(KEY, {'net':'0','booked':{}})
    identity = item['client_id']
    if identity in ledger['booked']:
        return
    today = day_key(int(time.time() * 1000))
    calendar = _calendar(ledger, today)
    date = _close_day(item)
    if date:
        _credit_day(calendar, date, profit)
    else:
        calendar['undated'].append(identity)
        calendar['unknown_through'] = max(calendar['unknown_through'] or today, today)
    ledger['net'] = fmt(dec(ledger['net']) + dec(profit))
    ledger['booked'][identity] = fmt(profit)


def publish_capital(engine):
    # Single-writer copy on ledger/pending changes. HTTP reads one immutable-in-
    # practice snapshot and never touches an exchange or locks the trade loop.
    data = engine.journal.data
    ledger = data[KEY]
    calendar = ledger['calendar514']
    pending = sum(1 for item in data['settlements'] if item.get(KEY))
    engine.auto_capital_display514 = (INITIAL + dec(ledger['net']), dict(calendar['days']),
                                      calendar['unknown_through'], pending)


def capital_display(engine, now_ms):
    snapshot = getattr(engine, 'auto_capital_display514', None)
    if snapshot is None:
        return None
    balance, days, uncertain_through, pending = snapshot
    today = day_key(now_ms)
    incomplete = bool(uncertain_through and today <= uncertain_through)
    today_net = None if incomplete else dec(days.get(today, 0))
    today_pct = None
    if today_net is not None and balance - today_net > 0:
        today_pct = fmt(100 * today_net / (balance - today_net))
    return dict(initial=fmt(INITIAL), capital=fmt(balance), day=today,
                today_net=fmt(today_net) if today_net is not None else None,
                today_pct=today_pct, pending=pending, incomplete=incomplete)

"""Stop-budget allocation for ranked 5.1 signals on linear USDT perpetuals."""
from decimal import Decimal, ROUND_DOWN, ROUND_UP

from okx_core import BotError, dec, fmt

TRADE_RISK = Decimal('.0025')
PORTFOLIO_RISK = Decimal('.02')
MAX_MARGIN_FRACTION = Decimal('.25')
MAX_LEVERAGE = 10
STRESS_MARGIN_FRACTION = Decimal('.5')
ONE_WAY_SLIPPAGE = Decimal('.0005')


class BelowMinimum(BotError):
    """No eligible leverage can buy/sell one exchange minimum."""


def allocate(*, price, stop, atr, ct, lot, minimum, exchange_leverage, max_quantity,
             fee, equity, room, free_slots, risk_budget, notional_room, leverage=None):
    """Maximize whole-lot exposure under the supplied caps. Resolve ties at lower leverage."""
    price, stop, atr, ct, lot, minimum = map(dec, (price, stop, atr, ct, lot, minimum))
    equity, room, risk_budget, notional_room = map(dec, (equity, room, risk_budget, notional_room))
    if (min(price, stop, atr, ct, lot, minimum, equity) <= 0 or type(free_slots) is not int
            or free_slots < 1 or min(room, risk_budget, notional_room) < 0 or price == stop):
        raise BotError('5.1 자동 배분 입력값 오류')
    fee = abs(dec(fee))
    unit = price * ct
    cost = 2 * (fee + ONE_WAY_SLIPPAGE)
    stop_fraction = abs(price - stop) / price
    loss_unit = ct * abs(price - stop) + unit * cost
    stressed_move = stop_fraction + atr / price + cost
    highest = int(min(dec(MAX_LEVERAGE), dec(exchange_leverage), STRESS_MARGIN_FRACTION / stressed_move))
    if highest < 1:
        raise BotError('거래소 배율 또는 손절·변동성 기준으로 1배 진입 불가')
    if leverage is not None and (type(leverage) is not int or not 1 <= leverage <= highest):
        raise BotError('주문 전 변동으로 선택 배율의 위험 상한 초과')

    cap = min(equity * MAX_MARGIN_FRACTION, room / free_slots)
    limit = min(risk_budget / loss_unit, notional_room / unit)
    if max_quantity is not None:
        limit = min(limit, dec(max_quantity))
    best = dec(0)
    selected = None
    for level in (range(1, highest + 1) if leverage is None else (leverage,)):
        margin_unit = unit / level
        qty = min(limit, cap / margin_unit, room / (margin_unit + unit * fee))
        qty = (qty / lot).to_integral_value(rounding=ROUND_DOWN) * lot
        if qty > best:
            best, selected = qty, level
    if best < minimum:
        raise BelowMinimum('5.1 손절 예산·가용 증거금·거래소 수량 한도 내 최소 계약 미달')
    nominal = best * unit
    return dict(leverage=selected, quantity=fmt(best), margin=fmt(nominal / selected),
                margin_cap=fmt(cap), risk_budget=fmt(risk_budget), estimated_loss=fmt(best * loss_unit),
                notional=fmt(nominal), equity=fmt(equity), free_slots=free_slots, stress_limit=highest,
                cost_rate=fmt(cost), stop_fraction=fmt(stop_fraction), spendable=fmt(room))


def ranked_plan(engine, plan, instrument, signal, direction, snapshot, fee):
    from okx_ranked51 import check
    from okx_risk732 import portfolio
    from okx_search_capacity import occupied, limit
    from pc_sizing import valid

    long = direction == 'long'
    price = dec(plan['buy' if long else 'sell'])
    tick = dec(instrument['tickSz'])
    if tick <= 0:
        raise BotError('5.1 가격 호가단위 오류')
    stop = (dec(signal['stop']) / tick).to_integral_value(rounding=ROUND_DOWN if long else ROUND_UP) * tick
    check(engine, signal, price)
    if (price <= stop if long else price >= stop):
        raise BotError('5.1 호가단위 반영 후 구조 손절 이탈')
    slots = limit(engine) - occupied(engine, snapshot)
    if slots < 1:
        raise BotError('5.1 사용 가능한 포지션 자리 없음')
    risk, exposure = portfolio(engine, snapshot)
    from okx_seed512 import limits as capital_limits
    capital, cash_room = capital_limits(engine, snapshot)
    equity = min(capital, dec(engine.allocation_seed(snapshot)), dec(snapshot['equity']))
    risk_budget = min(equity * TRADE_RISK, equity * PORTFOLIO_RISK - risk)
    if risk_budget <= 0:
        raise BotError('5.1 보유·미체결 손절 위험 예산 소진')
    reserve = dec(engine.cfg['risk']['entry_cash_reserve_usdt'])
    fees_pending = sum((dec(o.get('entry_fee_reserve') or 0) for o in engine.records()
                        if o.get('phase') == 'submitted'), dec(0))
    room = max(dec(0), min(cash_room, dec(snapshot['available']) - reserve, dec(engine.margin_room(snapshot)) - fees_pending))
    max_sizes = [dec(n) for n in (instrument.get('maxMktSz'), plan.get('_max_quantity511'),
                                  plan.get('_submit_qty250')) if n not in (None, '')]
    params = dict(price=price, stop=stop, atr=signal['atr'], ct=instrument['ctVal'], lot=instrument['lotSz'],
                  minimum=instrument['minSz'], exchange_leverage=instrument['lever'],
                  max_quantity=min(max_sizes) if max_sizes else None, fee=fee, equity=equity, room=room,
                  free_slots=slots, risk_budget=risk_budget,
                  notional_room=max(dec(0), equity * dec(engine.cfg['risk']['max_total_notional_fraction']) - exposure))
    chosen = allocate(**params, leverage=plan.get('_locked_leverage511'))
    engine.entry_leverage = signal['leverage'] = chosen['leverage']
    if not valid(signal):
        raise BotError('5.1 동적 배율 신호 불일치')
    signal['allocation511'] = chosen
    sizing = 'stop_budget511'
    result = dict(plan, quantity=chosen['quantity'], margin_bound=chosen['margin'],
                  estimated_loss=chosen['estimated_loss'], cost_rate=chosen['cost_rate'], reward_risk=None,
                  fixed_initial=False, initial_size_mode=sizing, initial_margin_target=chosen['margin'],
                  initial_quantity=chosen['quantity'], _allocation_inputs511=params,
                  _initial_risk_budget=chosen['risk_budget'], _allocation_seed=chosen['equity'],
                  entry_fee_reserve=fmt(dec(chosen['notional']) * abs(dec(fee))),
                  _account_equity=fmt(snapshot['equity']), _fee=fmt(fee), _funding='0', _ct=instrument['ctVal'],
                  risk732=dict(sizing=sizing, allocation511=chosen, target_margin=chosen['margin'],
                               estimated_loss=chosen['estimated_loss'], open_risk=fmt(risk),
                               total_notional=fmt(exposure), route=signal['strategy_id']))
    result[direction + '_stop'] = fmt(stop)
    return result


def fit_account(engine, plan, instrument, signal, direction, snapshot, fee):
    """Account maximum depends on leverage. Query alternatives only when the first choice binds."""
    params = dict(plan['_allocation_inputs511'], max_quantity=dec(plan['quantity']))
    first = signal['allocation511']
    field = 'maxBuy' if direction == 'long' else 'maxSell'

    def exchange_limit(level):
        limits = engine.api.get('/api/v5/account/max-size', instId=instrument['instId'],
                                tdMode='isolated', leverage=str(level))[0]
        return dec(limits[field])

    first_limit = exchange_limit(first['leverage'])
    best = None
    if first_limit >= params['max_quantity']:
        best = first
    else:
        for level in range(1, first['stress_limit'] + 1):
            try:
                possible = allocate(**params, leverage=level)
                if best and dec(possible['quantity']) <= dec(best['quantity']):
                    continue
                available = first_limit if level == first['leverage'] else exchange_limit(level)
                capped = min(params['max_quantity'], available)
                proposal = allocate(**dict(params, max_quantity=capped), leverage=level)
            except BelowMinimum:
                continue
            if best is None or dec(proposal['quantity']) > dec(best['quantity']):
                best = proposal
                if dec(best['quantity']) == params['max_quantity']:
                    break
    if best is None:
        raise BelowMinimum('모든 허용 배율에서 거래소 계정 주문 가능량 미달')
    locked = dict(plan, _locked_leverage511=best['leverage'], _max_quantity511=best['quantity'])
    return ranked_plan(engine, locked, instrument, signal, direction, snapshot, fee)

"""Stop-budget allocation for ranked 5.1 signals on linear USDT perpetuals."""
from decimal import Decimal, ROUND_DOWN, ROUND_UP

from okx_core import BotError, dec, fmt

TRADE_RISK = Decimal('.0025')
PORTFOLIO_RISK = Decimal('.02')
MAX_MARGIN_FRACTION = Decimal('.25')
MAX_LEVERAGE = 10
STRESS_MARGIN_FRACTION = Decimal('.5')
ONE_WAY_SLIPPAGE = Decimal('.0005')


class BelowMinimum(BotError):
    """No eligible leverage can buy/sell one exchange minimum."""


def allocate(*, price, stop, atr, ct, lot, minimum, exchange_leverage, max_quantity,
             fee, equity, room, free_slots, risk_budget, notional_room, leverage=None):
    """Maximize whole-lot exposure under the supplied caps. Resolve ties at lower leverage."""
    price, stop, atr, ct, lot, minimum = map(dec, (price, stop, atr, ct, lot, minimum))
    equity, room, risk_budget, notional_room = map(dec, (equity, room, risk_budget, notional_room))
    if (min(price, stop, atr, ct, lot, minimum, equity) <= 0 or type(free_slots) is not int
            or free_slots < 1 or min(room, risk_budget, notional_room) < 0 or price == stop):
        raise BotError('5.1 자동 배분 입력값 오류')
    fee = abs(dec(fee))
    unit = price * ct
    cost = 2 * (fee + ONE_WAY_SLIPPAGE)
    stop_fraction = abs(price - stop) / price
    loss_unit = ct * abs(price - stop) + unit * cost
    stressed_move = stop_fraction + atr / price + cost
    highest = int(min(dec(MAX_LEVERAGE), dec(exchange_leverage), STRESS_MARGIN_FRACTION / stressed_move))
    if highest < 1:
        raise BotError('거래소 배율 또는 손절·변동성 기준으로 1배 진입 불가')
    if leverage is not None and (type(leverage) is not int or not 1 <= leverage <= highest):
        raise BotError('주문 전 변동으로 선택 배율의 위험 상한 초과')

    cap = min(equity * MAX_MARGIN_FRACTION, room / free_slots)
    limit = min(risk_budget / loss_unit, notional_room / unit)
    if max_quantity is not None:
        limit = min(limit, dec(max_quantity))
    best = dec(0)
    selected = None
    for level in (range(1, highest + 1) if leverage is None else (leverage,)):
        margin_unit = unit / level
        qty = min(limit, cap / margin_unit, room / (margin_unit + unit * fee))
        qty = (qty / lot).to_integral_value(rounding=ROUND_DOWN) * lot
        if qty > best:
            best, selected = qty, level
    if best < minimum:
        raise BelowMinimum('5.1 손절 예산·가용 증거금·거래소 수량 한도 내 최소 계약 미달')
    nominal = best * unit
    return dict(leverage=selected, quantity=fmt(best), margin=fmt(nominal / selected),
                margin_cap=fmt(cap), risk_budget=fmt(risk_budget), estimated_loss=fmt(best * loss_unit),
                notional=fmt(nominal), equity=fmt(equity), free_slots=free_slots, stress_limit=highest,
                cost_rate=fmt(cost), stop_fraction=fmt(stop_fraction), spendable=fmt(room))


def target_economics(signal, side, price, loss_per_unit, one_way_cost):
    """Check the frozen take-profit level against the executable entry and rounded stop."""
    if signal.get('target') is None:
        return {}
    target = dec(signal['target'])
    gross_reward = side * (target - price)
    costs = (price + target) * one_way_cost
    net_reward = gross_reward - costs
    if net_reward <= 0:
        raise BotError(f'목표가까지 {gross_reward / price:.3%} · 왕복 예상 비용 {costs / price:.3%} 미충당')
    ratio = net_reward / loss_per_unit
    return dict(net_reward_risk=fmt(ratio), target_cost_fraction=fmt(costs / price))


def ranked_plan(engine, plan, instrument, signal, direction, snapshot, fee):
    from okx_ranked51 import check
    from okx_search_capacity import occupied, limit

    long = direction == 'long'
    price = dec(plan['buy' if long else 'sell'])
    tick = dec(instrument['tickSz'])
    if tick <= 0:
        raise BotError('5.1 가격 호가단위 오류')
    stop = (dec(signal['stop']) / tick).to_integral_value(rounding=ROUND_DOWN if long else ROUND_UP) * tick
    check(engine, signal, price)
    if (price <= stop if long else price >= stop):
        raise BotError('5.1 호가단위 반영 후 구조 손절 이탈')
    one_way_cost = abs(dec(fee)) + ONE_WAY_SLIPPAGE
    loss_per_unit = abs(price - stop) + (price + stop) * one_way_cost
    economics = target_economics(signal, 1 if long else -1, price, loss_per_unit, one_way_cost)
    slots = limit(engine) - occupied(engine, snapshot)
    if slots < 1:
        raise BotError('5.1 사용 가능한 포지션 자리 없음')
    from okx_seed512 import INITIAL, KEY, limits as capital_limits
    _, cash_room = capital_limits(engine, snapshot)
    ledger = engine.journal.data.get(KEY, {})
    equity = INITIAL + dec(ledger.get('net', 0))
    target = max(dec(0), (equity - 3) / 8)
    leverage = 5
    if dec(instrument['lever']) < leverage:
        raise BotError('거래소 종목 허용 배율 5배 미만')
    unit = price * dec(instrument['ctVal'])
    lot = dec(instrument['lotSz'])
    qty = (target * leverage / unit / lot).to_integral_value(rounding=ROUND_DOWN) * lot
    if plan.get('_submit_qty250') is not None:
        qty = min(qty, dec(plan['_submit_qty250']))
    if qty <= 0 or qty < dec(instrument['minSz']):
        raise BotError('8분의 1 증거금으로 거래소 최소 계약 미달')
    for cap in (instrument.get('maxMktSz'), plan.get('_max_quantity511')):
        if cap not in (None,'') and qty > dec(cap):
            raise BotError('8분의 1 주문이 거래소 수량 한도 초과')
    # Reserve fees on all eight slots without borrowing from the other funds.
    available = min(cash_room, dec(snapshot['available'])) - 3
    if slots == 1:
        affordable = (available / (unit / leverage + unit * abs(dec(fee))) / lot).to_integral_value(rounding=ROUND_DOWN) * lot
        qty = min(qty, affordable)
        if qty < dec(instrument['minSz']) or qty <= 0:
            raise BotError('마지막 포지션에 쓸 증거금 부족 · 수수료와 3 USDT 유보')
    nominal = qty * unit
    margin = nominal / leverage
    fee_reserve = nominal * abs(dec(fee))
    if margin + fee_reserve > min(cash_room - 3, dec(snapshot['available']) - 3):
        raise BotError('자동 운용금 또는 거래소 가용잔고 부족 · 3 USDT 유보')
    cost = 2 * one_way_cost
    loss = qty * dec(instrument['ctVal']) * loss_per_unit
    chosen = dict(leverage=5, quantity=fmt(qty), margin=fmt(margin), margin_cap=fmt(target),
                  estimated_loss=fmt(loss), equity=fmt(equity), notional=fmt(nominal), **economics)
    engine.entry_leverage = signal['leverage'] = 5
    signal['allocation511'] = chosen
    result = dict(plan, quantity=fmt(qty), margin_bound=fmt(margin), estimated_loss=fmt(loss),
                  cost_rate=fmt(cost), reward_risk=None, fixed_initial=False,
                  initial_size_mode='fixed_eighth518', initial_margin_target=fmt(target),
                  initial_quantity=fmt(qty), _initial_risk_budget=fmt(loss), _allocation_seed=fmt(equity),
                  entry_fee_reserve=fmt(fee_reserve), _account_equity=fmt(snapshot['equity']),
                  _fee=fmt(fee), _funding='0', _ct=instrument['ctVal'],
                  risk732=dict(sizing='fixed_eighth518', loss_estimate_only=True,
                               allocation511=chosen, target_margin=fmt(target), estimated_loss=fmt(loss),
                               route=signal['strategy_id']))
    result[direction + '_stop'] = fmt(stop)
    return result


def fit_account(engine, plan, instrument, signal, direction, snapshot, fee):
    limits = engine.api.get('/api/v5/account/max-size', instId=instrument['instId'],
                            tdMode='isolated', leverage='5')[0]
    locked = dict(plan, _locked_leverage511=5, _max_quantity511=limits['maxBuy' if direction=='long' else 'maxSell'])
    return ranked_plan(engine, locked, instrument, signal, direction, snapshot, fee)

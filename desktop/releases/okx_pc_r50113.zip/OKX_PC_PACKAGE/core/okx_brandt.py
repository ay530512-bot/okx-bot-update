"""Closed-bar Brandt long setup for the full OKX altcoin perpetual market."""
import math
import time
import queue
import threading
from concurrent.futures import ThreadPoolExecutor
from statistics import median

NAME = 'brandt_box_long'
QUARTER = 900000
HOUR = 3600000


def closed(raw, step, end):
    """Return the contiguous confirmed suffix ending at the expected boundary."""
    by_time = {int(r[0]): r for r in raw if len(r) >= 9 and str(r[8]) == '1'}
    result = []
    stamp = end - step
    while stamp in by_time:
        r = by_time[stamp]
        values = tuple(float(r[i]) for i in (1, 2, 3, 4, 7))
        op, hi, lo, cl, quote = values
        if not all(map(math.isfinite, values)) or not (0 < lo <= min(op, cl) <= max(op, cl) <= hi and quote >= 0):
            break
        result.append((stamp, *values))
        stamp -= step
    return result[::-1]


def acceptable(s, price, fee=.0005):
    slip = .0002
    entry = price*(1+slip)
    stop = s['stop']*(1-slip)
    target = s['target']*(1-slip)
    return (price >= s['trigger'] and price > s['stop'] and
            target-entry-fee*(entry+target) >= 2*(entry-stop+fee*(entry+stop)))


def setup(symbol, minutes, hours, start):
    if len(minutes) < 31 or len(hours) < 23:
        return
    ema = hours[0][4]
    averages = []
    for bar in hours:
        ema += (bar[4]-ema)*2/21
        averages.append(ema)
    if not hours[-1][4] > ema > averages[-4]:
        return
    atr = sum(max(b[2], a[4])-min(b[3], a[4]) for a,b in zip(minutes[-31:-1],minutes[-30:]))/30
    box = minutes[-16:]
    high, low = max(b[2] for b in box), min(b[3] for b in box)
    if atr <= 0 or not 2*atr <= high-low <= 8*atr:
        return
    for col, boundary in ((2, high),(3, low)):
        hits = [i for i,b in enumerate(box) if abs(b[col]-boundary) <= .5*atr]
        if not hits or hits[0]>=8 or hits[-1]<8 or hits[-1]-hits[0]<3:
            return
    base = median(b[5] for b in minutes[-21:-1])
    if base <= 0 or minutes[-1][5] < 1.3*base:
        return
    trigger = high+.25*atr
    s = dict(symbol=symbol, strategy=NAME, pattern=NAME, action='LONG', leverage=5,
             valid_from_ms=start, expires_ms=start+QUARTER, at_ms=start,
             signal_id=f'{NAME}-{start}', stop=box[-1][3], target=2*high-low,
             trigger=trigger, entry_reference=trigger, level=high, atr=atr,
             regime='1시간 상승', ma=ema, bb='미사용', rsi='미사용', retest='박스 양단 재시험',
             reason='15분 박스 돌파 · 확정봉 거래대금 %.2f배' % (minutes[-1][5]/base),
             holding_rule={}, selection={'activity':{'quote_ratio':minutes[-1][5]/base}},
             decision_record={'volume_wick_proof':{'route721':NAME}})
    return s if acceptable(s, trigger) else None


def universe(api, cfg):
    from okx_pattern15 import allowed
    rows = api.public('/api/v5/public/instruments', instType='SWAP')
    if not rows:
        raise ValueError('OKX 계약 목록이 비어 있습니다')
    return sorted({r['instId'] for r in rows if r.get('instType') == 'SWAP'
                   and allowed(r, cfg) and r['instId'].split('-')[0] not in ('BTC','ETH','SOL')})


def scan(settings, cfg, start, events, stopped, deadline):
    """Stream results as each symbol is checked. Never wait for the last symbol to admit the first."""
    from okx_core import OKX
    def active():
        return not stopped.is_set() and time.monotonic() < deadline
    def wait(seconds):
        return active() and not stopped.wait(min(seconds,max(0,deadline-time.monotonic()))) and active()
    pace = threading.Lock()
    next_read = 0.
    def candles(api,symbol,frame,step,limit):
        nonlocal next_read
        with pace:
            slot = max(time.monotonic(),next_read)
            next_read = slot+.10
        if not wait(max(0,slot-time.monotonic())):
            return []
        raw = api.public('/api/v5/market/candles',instId=symbol,bar=frame,limit=str(limit))
        return closed(raw,step,start//step*step)
    def workers(symbols):
        todo = queue.Queue()
        for symbol in symbols:
            todo.put(symbol)
        failed = queue.Queue()
        def worker():
            api = OKX(settings)
            try:
                while active():
                    try:
                        symbol = todo.get_nowait()
                    except queue.Empty:
                        return
                    try:
                        mins = candles(api,symbol,'15m',QUARTER,64)
                        if not mins:
                            raise ValueError('15분 확정봉 대기')
                        signal = None
                        if len(mins)>=31 and mins[-1][5]>=1.3*median(b[5] for b in mins[-21:-1]):
                            hours = candles(api,symbol,'1H',HOUR,200)
                            if not hours:
                                raise ValueError('1시간 확정봉 대기')
                            signal = setup(symbol,mins,hours,start)
                        if active():
                            events.put(('checked',symbol,signal))
                    except Exception:
                        failed.put(symbol)
            finally:
                api.session.close()
        with ThreadPoolExecutor(max_workers=4,thread_name_prefix='brandt-candles') as pool:
            jobs = [pool.submit(worker) for _ in range(min(4,len(symbols)))]
            for job in jobs:
                job.result()
        return list(failed.queue)
    try:
        api = OKX(settings)
        try:
            while active():
                try:
                    symbols = universe(api,cfg)
                    break
                except Exception as err:
                    events.put(('status','계약 목록 재조회 대기 · '+type(err).__name__,None))
                    if not wait(15):
                        return
            else:
                return
        finally:
            api.session.close()
        events.put(('universe',len(symbols),None))
        # Rotate the starting symbol so reconnects near a bar boundary do not always favor the same names.
        offset = (start//QUARTER*37)%max(len(symbols),1)
        pending = symbols[offset:]+symbols[:offset]
        while pending and active():
            pending = workers(pending)
            if pending and active():
                events.put(('status',f'{len(pending)}종목 확정봉 재조회 대기',None))
                if not wait(12):
                    return
    except Exception as err:
        events.put(('error','전체 알트 조회 재시도 · '+type(err).__name__,None))


def refresh(e):
    now = e.api.now_ms()
    start = now//QUARTER*QUARTER
    if getattr(e,'brandt_start',None) != start or time.monotonic()>=getattr(e,'brandt_retry',float('inf')):
        if hasattr(e,'brandt_stop'):
            e.brandt_stop.set()
        e.brandt_start, e.brandt_retry = start, float('inf')
        e.brandt_events, e.brandt_stop = queue.Queue(), threading.Event()
        e.brandt_plans, e.brandt_checked, e.brandt_total = {}, set(), None
        e.brandt_note = '계약 목록 조회 중'
        deadline = time.monotonic()+(start+QUARTER-now)/1000
        threading.Thread(target=scan,args=(e.settings,e.cfg,start,e.brandt_events,e.brandt_stop,deadline),
                         name='brandt-market',daemon=True).start()
    while True:
        try:
            kind, value, signal = e.brandt_events.get_nowait()
        except queue.Empty:
            break
        if kind=='universe':
            e.brandt_total, e.brandt_note = value, ''
        elif kind=='checked':
            e.brandt_checked.add(value)
            if signal:
                e.brandt_plans[value] = signal
            if len(e.brandt_checked)==e.brandt_total:
                e.brandt_note = ''
        else:
            e.brandt_note = value
            if kind=='error':
                e.brandt_retry = time.monotonic()+15
    count = '?' if e.brandt_total is None else str(e.brandt_total)
    e.brandt_status = f'전체 알트 {len(e.brandt_checked)}/{count}종목 확인 · 돌파 감시 {len(e.brandt_plans)}종목'
    if e.brandt_note:
        e.brandt_status += ' · '+e.brandt_note


def check(e, s, price):
    from okx_core import BotError
    now = e.api.now_ms()
    tick = e.stream.read(s['symbol'], 'tickers', 3, now)
    if (not s['valid_from_ms'] <= now < s['expires_ms'] or not tick
            or float(tick['last']) < s['trigger'] or not acceptable(s, float(price), s.get('fee_floor', .0005))):
        raise BotError('ZK형 돌파 유효시간·현재가·비용 후 2R 재확인 대기')


def poll(e):
    from okx_core import BotError, Rejected, UnknownOutcome
    now = e.api.now_ms()
    owned = {r['symbol'] for r in e.records()}
    for symbol,s in getattr(e, 'brandt_plans', {}).items():
        if symbol in owned or symbol+':'+s['signal_id'] in e.journal.data['seen_signals']:
            continue
        if not e.stream.ready(symbol,e.cfg,now) or s['expires_ms'] <= now:
            continue
        ticker = e.stream.read(symbol,'tickers',3,now)
        if not ticker or float(ticker['last']) < s['trigger'] or not acceptable(s,float(ticker['askPx'])):
            continue
        if time.monotonic() < s.get('retry_at', 0):
            continue
        s['retry_at'] = time.monotonic()+5
        with e.selected(e.empty_slot()):
            try:
                e.executing_signal = s
                e.entry(s)
            except UnknownOutcome:
                raise
            except (Rejected,BotError) as err:
                e.pipeline('preflight_rejected', symbol+' / '+str(err))
            finally:
                e.executing_signal = None
        return
    e.pipeline('signal_wait',e.brandt_status)


def manage(e, snap, p, o):
    bars = e.chart_job(o['symbol']) or {}
    s = o['v4_signal']
    now = e.api.now_ms()
    opened = int(o.get('fill_ms') or o['entry_ms'])
    five = [b for b in bars.get('5m',[]) if opened <= b[0] and b[0]+300000 <= now]
    if any(b[0]-a[0]==300000 and max(a[4],b[4])<s['level'] for a,b in zip(five,five[1:])):
        e.close(snap,'ZK형 돌파 실패 · 5분봉 2개 연속 박스 상단 아래 마감')
        return
    entry = float(p['avgPx'])
    fifteen = [b for b in bars.get('15m',[]) if b[0]+QUARTER <= now]
    target = float(o['stop_px'])
    armed = o.get('brandt_armed', False)
    last = o.get('brandt_last_close',opened)
    for idx,b in enumerate(fifteen):
        if b[0]+QUARTER <= last:
            continue
        armed = armed or b[4] >= entry+(entry-s['stop'])
        if armed and idx>=2 and b[0]-fifteen[idx-2][0]==2*QUARTER:
            target = max(target,min(r[3] for r in fifteen[idx-2:idx+1]))
    if target > float(o['stop_px']):
        e.trail(snap,p,o,target)
    if fifteen and fifteen[-1][0]+QUARTER>last:
        o.update(brandt_armed=armed,brandt_last_close=fifteen[-1][0]+QUARTER)
        e.journal.save()

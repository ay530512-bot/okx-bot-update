"""Deadline of the originating Korean calendar session, in OKX server milliseconds."""
DAY_MS = 86_400_000
KST_OFFSET_MS = 9 * 3_600_000
FINAL_MINUTE_MS = 60_000
CLOSE_REASON = '진입 당일 23:59 KST · 남은 수량 전량 청산'
ENTRY_CLOSED = '진입 당일 23:59 KST 마감 · 신규 주문 시간 종료'


def session_close_ms(timestamp):
    next_midnight = ((timestamp + KST_OFFSET_MS) // DAY_MS + 1) * DAY_MS - KST_OFFSET_MS
    return next_midnight - FINAL_MINUTE_MS


def due(owned, now):
    signal = owned.get('v4_signal') or {}
    if signal.get('pc51'):
        return False
    deadline = signal.get('kst_close_ms')
    return deadline is not None and now >= deadline

"""Trailing protection for positions opened by previous versions."""
from pc_sizing import OBSERVATION_COST


def trailing(entry, initial_stop, mark, side):
    risk=side*(entry-initial_stop)
    if risk>0 and side*(mark-entry)>=2*risk+entry*OBSERVATION_COST:
        return mark-side*1.5*risk
    return None

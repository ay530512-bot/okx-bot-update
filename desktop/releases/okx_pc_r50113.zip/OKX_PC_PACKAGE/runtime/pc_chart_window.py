"""Window sizes for rendering historical execution charts."""
from datetime import timedelta, timezone

STEP = 15 * 60_000
WINDOW = 30  # Upper-wick window and the historical default for external callers.
LONG_WINDOW = 100
KST = timezone(timedelta(hours=9))


def retest_window(side):
    return LONG_WINDOW if side == 1 else WINDOW

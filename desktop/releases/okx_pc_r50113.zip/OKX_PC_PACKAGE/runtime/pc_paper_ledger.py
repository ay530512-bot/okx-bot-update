"""Virtual USDT ledgers driven by closed OKX candles. No exchange order interface."""
from math import ceil, floor
from pc_swing_paper import FEE_MAKER, FEE_TAKER, HALF_SPREAD_SLIPPAGE, MAX_HOURS

MINUTE = 60000
SEED = 195.
BOOKS = ('swing','follow','fade')


def initial(now):
    return dict(version=1,cursor=now//MINUTE*MINUTE,previous={},batch={},
        books={key:dict(equity=SEED,open={},cooldown={},closed=0,wins=0,fees=0.,funding=0.,recent=[]) for key in BOOKS})


def round_price(price, sign, tick):
    n = price/tick
    return (ceil(n) if sign>0 else floor(n))*tick


def market(price, sign, tick):
    n=price*(1+sign*HALF_SPREAD_SLIPPAGE)/tick
    return (ceil(n-1e-10) if sign>0 else floor(n+1e-10))*tick


def settle(book, symbol, price, ts, maker, reason):
    p=book['open'].pop(symbol)
    if not maker:
        price=market(price,-p['side'],p['tick'])
    exit_fee=price*p['qty']*(FEE_MAKER if maker else FEE_TAKER)
    pnl=p['qty']*p['side']*(price-p['entry'])-exit_fee-p['entry_fee']+p['funding']
    book['equity']+=pnl
    book['fees']+=p['entry_fee']+exit_fee
    book['funding']+=p['funding']
    book['closed']+=1
    book['wins']+=int(pnl>0)
    if p['rule']=='aot' and pnl<0:
        book['cooldown'][symbol]=ts+60*MINUTE
    book['recent'].append(dict(symbol=symbol,rule=p['rule'],side=p['side'],time=ts,entered=p['opened'],
        entry=p['entry'],exit=price,net=pnl,fees=exit_fee+p['entry_fee'],funding=p['funding'],reason=reason))
    book['recent']=book['recent'][-40:]


def open_positions(book, model, batch, bars, timestamp):
    occupied=book['open']
    sent=0
    for p in batch['plans']:
        if len(occupied)>=8 or sent>=3:
            break
        symbol=p['symbol']
        if symbol in occupied or symbol in batch['taken'][model] or (p['rule']=='aot' and book['cooldown'].get(symbol,0)>timestamp):
            continue
        if symbol not in bars:
            continue
        row, previous_turn, _rate=bars[symbol]
        side=p['side'] if model=='swing' else p['original'] if model=='follow' else -p['original']
        meta=p['meta'];tick=meta['tick']
        if tick/row[0]>(.0012 if p['rule']=='todd' else .0005):
            continue
        px=market(row[0],side,tick)
        if side==p['side']:
            target=p['target']
            planned_stop=p['stop']
        else:
            target=p['reference']+side*3.5*p['risk']
            planned_stop=p['reference']-side*p['risk']
        stop=round_price(planned_stop,-side,tick)
        if abs(px-p['reference'])>.25*p['atr15'] or side*(px-stop)<=0 or side*(target-px)<=(target+px)*.001:
            continue
        funds=book['equity']-3
        for holding in occupied.values():
            value=holding['qty']*holding['side']*(holding['last']-holding['entry'])+holding['funding']
            funds+=min(0.,value)-holding['margin']-holding['entry_fee']
        margin=max(0.,(book['equity']-3)/8)
        if len(occupied)==7:
            margin=min(margin,funds/(1+5*FEE_TAKER))
        if margin<=0:continue
        lots=floor(margin*5/px/meta['ct']/meta['lot'])*meta['lot']
        quantity=lots*meta['ct']
        cost=px*quantity;fee=cost*FEE_TAKER
        if lots<meta['minimum'] or (meta['maximum'] and lots>meta['maximum']) or cost/5+fee>funds+1e-9 or previous_turn<50*cost:
            continue
        occupied[symbol]=dict(rule=p['rule'],side=side,tick=tick,qty=quantity,entry=px,margin=cost/5,
            entry_fee=fee,funding=0.,last=px,stop=stop,target=target,opened=timestamp,
            risk=abs(p['reference']-stop),atr_hour=p['atr_hour'])
        batch['taken'][model].append(symbol)
        sent+=1


def minute(ledger, timestamp, bars):
    """Input bars map symbol to ((OHLC and USDT turnover), previous turnover, settled rate)."""
    if timestamp!=ledger['cursor']:
        raise ValueError('모의 봉 순서 오류')
    batch=ledger['batch']
    for name,book in ledger['books'].items():
        for symbol,p in list(book['open'].items()):
            row,_previous,rate=bars[symbol]
            op=row[0];side=p['side'];p['last']=op
            p['funding']-=side*p['qty']*op*rate
            if side*(op-p['stop'])<=0:
                settle(book,symbol,op,timestamp,False,'갭 손절')
            elif timestamp>=p['opened']+MAX_HOURS*60*MINUTE:
                if p['qty']*side*(op-p['entry'])-p['entry_fee']-FEE_MAKER*op*p['qty']+p['funding']<=0:
                    settle(book,symbol,op,timestamp,False,'보유 만료')
        if batch.get('from',0)<=timestamp<batch.get('until',0):
            open_positions(book,name,batch,bars,timestamp)
        for symbol,p in list(book['open'].items()):
            row,_previous,_rate=bars[symbol];op,hi,lo,close,turn=row
            side=p['side'];tick=p['tick'];adverse=lo if side>0 else hi
            if side*(adverse-p['stop'])<=0:
                settle(book,symbol,min(op,p['stop']) if side>0 else max(op,p['stop']),timestamp+MINUTE,False,'보호 손절')
                continue
            expired=timestamp>=p['opened']+MAX_HOURS*60*MINUTE
            if expired:
                be=(p['entry']*(1+side*FEE_TAKER)-side*min(0.,p['funding'])/p['qty'])/(1-side*FEE_TAKER)
                target=max(op+tick,be+tick) if side>0 else min(op-tick,be-tick)
            else:
                target=p['target']
            target=round_price(target,side,tick)
            if (timestamp>p['opened'] and side*((hi if side>0 else lo)-target)>max(tick,target*(.0001 if expired else .0002))
                    and turn>50*p['qty']*target):
                settle(book,symbol,target,timestamp+MINUTE,True,'만료 지정가' if expired else '지정가 익절')
                continue
            p['last']=close
            if (timestamp+MINUTE)%(240*MINUTE)==0 and side*(close-p['entry'])>=2*p['risk']:
                new_stop=round_price(close-side*2*p['atr_hour'],-side,tick)
                p['stop']=max(p['stop'],new_stop) if side>0 else min(p['stop'],new_stop)
    ledger['cursor']=timestamp+MINUTE

"""Five chart setups with relative momentum and a structural-failure reversal, for paper replay."""
from math import isfinite

VERSION = 'swing-1'
HALF_SPREAD_SLIPPAGE = .0005
FEE_TAKER = .0005
FEE_MAKER = .0002
MAX_HOURS = 72

def decide(direction, reference, structural_stop, bar_midpoint, atr15, chart_fit,
           confirmed_close, atr1h, rank7, rank1, market7):
    """Ranks are contemporaneous, from zero (weakest) to one (strongest)."""
    values = (reference, structural_stop, bar_midpoint, atr15, chart_fit, confirmed_close,
              atr1h, rank7, rank1, market7)
    if direction not in (-1, 1) or not all(isfinite(x) for x in values):
        return None
    if min(reference, structural_stop, atr15, confirmed_close, atr1h) <= 0:
        return None
    strength = (.65*(2*rank7-1) + .25*(2*rank1-1)
                + .10*max(-1., min(1., market7/.05)))
    if abs(strength) < .30:
        return None
    side = 1 if strength > 0 else -1
    if side == direction:
        if side*(confirmed_close-structural_stop) <= 0:
            return None
        reason = '추세와 차트 신호 일치'
    else:
        if side*(confirmed_close-bar_midpoint) <= 0:
            return None
        reason = '역방향 신호가 다음 봉에서 몸통 중앙선 이탈'
    risk = min(confirmed_close*.03, max(confirmed_close*.012, 1.4*atr1h))
    retrace = -side*(confirmed_close-reference)/atr15
    score = (65*abs(strength) + 20*(max(-1., min(1., retrace)) + 1)/2
             + .15*max(0., min(100., chart_fit)))
    return dict(side=side, reference=confirmed_close, stop=confirmed_close-side*risk,
                target=confirmed_close+side*3.5*risk, atr_hour=atr1h, risk=risk,
                score=score, reason=reason)


def ranks(values):
    ordered = sorted(values, key=values.get)
    result = {}
    start = 0
    while start < len(ordered):
        end = start + 1
        while end < len(ordered) and values[ordered[end]] == values[ordered[start]]:
            end += 1
        rank = ((start + end - 1) / 2) / max(1, len(ordered)-1)
        result.update((symbol, rank) for symbol in ordered[start:end])
        start = end
    return result


def market_snapshot(frames, instruments, plans, quotes, timestamp, quote_ms):
    from statistics import median
    ctx, week, day, anchors = {}, {}, {}, []
    meta = {r['instId']: r for r in instruments}
    for symbol, frame in frames.items():
        quarter, hours = frame['15m'], frame['1H']
        if len(hours) < 169 or not quarter:
            continue
        try:
            prices = [float(r[4]) for r in hours[-169:]]
            if min(prices) <= 0:
                continue
            hourly_atr = sum(max(float(row[2])-float(row[3]), abs(float(row[2])-previous),
                                 abs(float(row[3])-previous)) for row,previous in zip(hours[-14:],prices[-15:-1]))/14
            quote = quotes.get(symbol) or {}
            spread = None
            try:
                bid, ask = float(quote['bidPx']), float(quote['askPx'])
                if 0 < bid <= ask and 0 <= quote_ms-int(quote['ts']) <= 10000:
                    spread = (ask-bid)/((ask+bid)/2)*10000
            except (ValueError, TypeError, KeyError):
                pass
            instrument = meta[symbol]
            ctx[symbol] = dict(close=float(quarter[-1][4]), atr=hourly_atr, spread=spread,
                tick=float(instrument['tickSz']), ct=float(instrument['ctVal']),
                lot=float(instrument['lotSz']), minimum=float(instrument['minSz']),
                maximum=float(instrument['maxMktSz'] or 0))
            week[symbol] = prices[-1]/prices[0]-1
            day[symbol] = prices[-1]/prices[-25]-1
        except (ValueError, TypeError, KeyError, ZeroDivisionError):
            continue
    for s in plans:
        symbol = s['symbol']
        if symbol in ctx:
            anchors.append(dict(symbol=symbol, rule=s['strategy_id'], direction=1 if s['action']=='LONG' else -1,
                ref=s['reference'], stop=s['structural_stop'], atr=s['atr'], fit=s['fit'],
                stage=s['regime'], rv=s['score'],
                mid=(float(frames[symbol]['15m'][-1][1])+s['reference'])/2))
    if week:
        r7, r1, m7 = ranks(week), ranks(day), median(week.values())
        for symbol in week:
            ctx[symbol].update(rank7=r7[symbol],rank1=r1[symbol],market7=m7)
    return dict(stamp=timestamp, anchors=anchors, context=ctx)


def make_plans(previous, snapshot):
    plans = []
    if previous.get('stamp') != snapshot['stamp']-900000:
        return plans
    for a in previous['anchors']:
        ctx = snapshot['context'].get(a['symbol'])
        if not ctx or ctx['spread'] is None or ctx['spread'] > (12 if a['rule']=='todd' else 5):
            continue
        choice = decide(a['direction'], a['ref'], a['stop'], a['mid'], a['atr'], a['fit'],
                        ctx['close'], ctx['atr'], ctx['rank7'],ctx['rank1'],ctx['market7'])
        if choice:
            plans.append(dict(**choice, symbol=a['symbol'], rule=a['rule'], original=a['direction'],
                atr15=a['atr'], rv=a['rv'], meta={k:ctx[k] for k in ('tick','ct','lot','minimum','maximum')}))
    return sorted(plans, key=lambda p:(-p['score'],-p['rv'],p['symbol'],p['rule']))

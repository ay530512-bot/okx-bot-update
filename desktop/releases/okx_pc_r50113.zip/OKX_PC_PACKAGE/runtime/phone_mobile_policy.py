"""Published worker packets contain no automatic entry candidates."""


def install(channel, cache, pins):
    def packet(row, cfg, now, quote=None, swing_frame=None):
        return dict(entry_setups=[], or_status='ZK형 롱 · 15분 박스 돌파', entry_diagnostic={})

    channel._phone_worker_packet = packet

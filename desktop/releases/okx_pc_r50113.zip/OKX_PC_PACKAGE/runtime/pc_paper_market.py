"""Read-only public market replay for the three virtual comparison books."""
import copy
import json
import math
import os
from pathlib import Path
import queue
import threading
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from pc_paper_ledger import BOOKS, MINUTE, SEED, initial, minute
from pc_swing_paper import make_plans


def public(path, **params):
    url='https://www.okx.com/api/v5/'+path+'?'+urlencode(params)
    with urlopen(Request(url,headers={'User-Agent':'OKX-Paper-Research/5.1.13'}),timeout=6) as r:
        data=json.load(r)
    if data.get('code')!='0':
        raise ValueError('공개 시세 응답 '+str(data.get('code')))
    return data['data']


def fetch_rows(symbol, first, end, now):
    endpoint='market/candles' if end>=now-3*3600000 else 'market/history-candles'
    rows=public(endpoint,instId=symbol,bar='1m',after=end,limit=(end-first)//MINUTE+2)
    values={}
    for row in rows:
        stamp=int(row[0])
        if len(row)<9 or str(row[8])!='1':
            continue
        o,h,l,c=map(float,row[1:5]);turn=float(row[7])
        if all(math.isfinite(x) for x in (o,h,l,c,turn)) and 0<l<=min(o,c)<=max(o,c)<=h and turn>=0:
            values[stamp]=(o,h,l,c,turn)
    rates={}
    if (first-1)//3600000!=(end-1)//3600000:
        funding=public('public/funding-rate-history',instId=symbol,after=end,limit=8)
        rates={int(row['fundingTime']):float(row.get('realizedRate') or row['fundingRate']) for row in funding}
    return {t:(bar,values[t-MINUTE][4],rates.get(t,0.)) for t,bar in values.items()
            if first<=t<end and t-MINUTE in values}


def save(path, ledger):
    temp=path.with_suffix('.tmp')
    with temp.open('w',encoding='utf-8') as handle:
        json.dump(ledger,handle,ensure_ascii=False,allow_nan=False,separators=(',',':'))
        handle.flush()
        os.fsync(handle.fileno())
    temp.replace(path)


def summary(ledger, text):
    return dict(message=text,through=ledger['cursor'],books={
        name:dict(net=round(b['equity']-SEED,4),open=len(b['open']),closed=b['closed'],wins=b['wins'],
                  funding=round(b['funding'],4),fees=round(b['fees'],4),recent=b['recent'][-3:][::-1])
        for name,b in ledger['books'].items()})


def register(ledger, snap, now):
    if snap['stamp']<=ledger['previous'].get('stamp',0):
        return
    plans=make_plans(ledger['previous'],snap)
    start=max(snap['stamp']+2*MINUTE,((now+MINUTE-1)//MINUTE)*MINUTE,ledger['cursor'])
    if plans and start<snap['stamp']+15*MINUTE:
        ledger.setdefault('queued',[]).append(dict(plans=plans,taken={k:[] for k in BOOKS},
            **{'from':start,'until':snap['stamp']+15*MINUTE}))
    ledger['previous']={'stamp':snap['stamp'],'anchors':snap['anchors']}


def advance(ledger, end, clock, read=fetch_rows):
    start=ledger['cursor']
    if start>=end:
        return
    batch=ledger['batch'];pending=ledger.setdefault('queued',[])
    if batch and batch['until']<=start:
        ledger['batch']=batch={}
    while pending and pending[0]['from']<=start:
        item=pending.pop(0)
        if item['until']>start:
            ledger['batch']=batch=item
    if pending:
        end=min(end,pending[0]['from'])
    opened={s for b in ledger['books'].values() for s in b['open']}
    if not opened and not batch:
        ledger['cursor']=end
        return
    end=min(end,start+35*MINUTE,batch['until'] if batch else end)
    symbols=opened|{p['symbol'] for p in batch.get('plans',())}
    # Fetching completes before a clock step is committed. Retry incomplete candles for held positions.
    samples={s:read(s,start,end,clock) for s in sorted(symbols)}
    for t in range(start,end,MINUTE):
        bars={s:rows[t] for s,rows in samples.items() if t in rows}
        for b in ledger['books'].values():
            missing=set(b['open'])-bars.keys()
            if missing:
                raise ValueError(sorted(missing)[0]+' 확정 1분봉 재조회 중')
        minute(ledger,t,bars)


class PaperMarket:
    def __init__(self, path, stop):
        self.path=Path(path).with_name('paper_5_1_13.json')
        self.stop=stop
        self.incoming=queue.Queue()
        self.published={'message':'모의 장부 준비 중','books':{}}
        threading.Thread(target=self.run,daemon=True,name='public-paper-513').start()

    def run(self):
        ledger=None
        pending=[]
        while not self.stop.is_set():
            try:
                now=int(time.time()*1000)
                if ledger is None:
                    if self.path.exists():
                        loaded=json.loads(self.path.read_text(encoding='utf-8'))
                        if loaded['version']!=1 or set(loaded['books'])!=set(BOOKS):
                            raise ValueError('모의 장부 형식 확인 필요')
                        ledger=loaded
                    else:
                        ledger=initial(now)
                work=copy.deepcopy(ledger)
                while True:
                    try:pending.append(self.incoming.get_nowait())
                    except queue.Empty:break
                for snap,arrival in pending:register(work,snap,arrival)
                end=((now-5000)//MINUTE)*MINUTE
                advance(work,end,now)
                if work!=ledger:
                    save(self.path,work)
                ledger=work;pending.clear()
                msg='공개 1분봉 모의체결' if ledger['previous'] else '첫 확정봉 대기'
                self.published=summary(ledger,msg)
                if ledger['cursor']<end:
                    continue
            except Exception as exc:
                msg='모의 자료 대조 중 · '+str(exc)[:75]
                self.published=summary(ledger,msg) if ledger else {'message':msg,'books':{}}
            self.stop.wait(8)

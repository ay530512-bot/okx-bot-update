"""Five independent, closed-candle interpretations of published AI trading approaches.

This module is pure: it reads supplied observations and never contacts an exchange.
The case returns are ranking metadata, not returns earned by these rules.
"""
from math import isfinite
from statistics import median
from typing import NamedTuple, Optional


QUARTER = 15 * 60 * 1000
HOUR = 4 * QUARTER
HISTORY = 30


class Candle(NamedTuple):
    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float


def _closed(raw, interval, now):
    """Require each of the most recent 30 completed UTC buckets exactly once."""
    end = (now // interval - 1) * interval
    start = end - (HISTORY - 1) * interval
    selected = {}
    for row in raw:
        ts = int(row[0])
        if ts < start or ts > end:
            continue
        if ts % interval or ts in selected or len(row) < 6:
            return []
        # Six-column rows are normalized completed-candle cache entries.
        if len(row) != 6 and (len(row) < 9 or str(row[8]) != '1'):
            return []
        candle = Candle(ts, *(float(x) for x in row[1:6]))
        if (not all(isfinite(x) for x in candle[1:]) or candle.volume < 0
                or not 0 < candle.low <= min(candle.open, candle.close)
                or max(candle.open, candle.close) > candle.high):
            return []
        selected[ts] = candle
    if len(selected) != HISTORY:
        return []
    return [selected[ts] for ts in range(start, end + 1, interval)]


def _mirror(bars):
    # Reflection lets the short use exactly the same comparisons as the long.
    return [Candle(b.ts, -b.open, -b.low, -b.high, -b.close, b.volume) for b in bars]


def _true_range(bar, previous):
    return max(bar.high - bar.low, abs(bar.high - previous.close), abs(bar.low - previous.close))


def _atr(bars):
    pairs = zip(bars[-15:-1], bars[-14:])
    return sum(_true_range(bar, previous) for previous, bar in pairs) / 14


def _efficiency(hourly):
    # Signed ten-hour move divided by the distance traveled between hourly closes.
    closes = [b.close for b in hourly[-11:]]
    distance = sum(abs(b - a) for a, b in zip(closes, closes[1:]))
    return (closes[-1] - closes[0]) / distance if distance else 0.0


def _location(bar):
    width = bar.high - bar.low
    return (bar.close - bar.low) / width if width else 0.5


class Setup(NamedTuple):
    regime: str
    stop: float
    target: Optional[float]
    max_hold_bars: int
    reason: str
    conditions: tuple
    invalidation: Optional[float] = None


def _fixed(regime, close, stop, multiple, hold, reason, conditions):
    return Setup(regime, stop, close + multiple * (close - stop), hold, reason, conditions)


def _sparta(bars, hours, atr, volume, **unused):
    last = bars[-1]
    fast = sum(b.close for b in hours[-8:]) / 8
    slow = sum(b.close for b in hours[-21:]) / 21
    if not hours[-1].close > fast > slow:
        return None
    barrier = max(b.high for b in bars[-11:-3])
    breakout, retest = bars[-3:-1]
    if not (breakout.close > barrier and abs(retest.low - barrier) <= 0.25 * atr
            and retest.close >= barrier and last.close > retest.high and volume >= 1.2):
        return None
    recent_volume = sum(b.volume for b in bars[-3:])
    if recent_volume <= 0:
        return None
    # OHLCV proxy for signed pressure, not measured aggressor flow or order-book data.
    pressure = sum((2 * _location(b) - 1) * b.volume for b in bars[-3:]) / recent_volume
    if not isfinite(pressure) or pressure < 0.25:
        return None
    stop = min(retest.low, last.low) - 0.25 * atr
    return _fixed('trend_retest', last.close, stop, 2.0, 32,
                  f'1시간 추세 정렬 · 돌파선 재시험 후 재돌파 · 방향성 압력 {pressure:.2f}',
                  (f'시간봉 종가 {abs(hours[-1].close):.8g} / 8봉 평균 {abs(fast):.8g} / 21봉 평균 {abs(slow):.8g}',
                   f'돌파선 {abs(barrier):.8g} / 재시험 거리 {abs(retest.low - barrier) / atr:.2f} ATR',
                   f'3봉 방향 압력 {pressure:.2f} / 거래량 {volume:.2f}배'))


def _todd(bars, hours, atr, volume, *, spread, **unused):
    last = bars[-1]
    if spread is None or not 0 <= spread <= 12:
        return None
    # Extreme volatility veto takes precedence over the trend/range classification.
    efficiency = _efficiency(hours)
    true_range = _true_range(last, bars[-2])
    if true_range > 2.2 * atr or efficiency < 0.55:
        return None
    barrier = max(b.high for b in bars[-13:-1])
    if not (last.close > barrier and last.close > last.open and _location(last) >= 0.75
            and volume >= 1.10):
        return None
    return _fixed('trend_breakout', last.close, last.close - 1.25 * atr, 1.5, 16,
                  f'1시간 방향 효율 확인 · 12봉 돌파 · 스프레드 {spread:.2f}bp',
                  (f'진입 방향 효율 {efficiency:.2f} / 신호 진폭 {true_range / atr:.2f} ATR',
                   f'돌파선 {abs(barrier):.8g} / 진입 방향 종가 위치 {_location(last):.1%}',
                   f'호가 스프레드 {spread:.2f}bp / 거래량 {volume:.2f}배'))


def _shadow(bars, hours, atr, volume, **unused):
    sweep, last = bars[-2:]
    floor = min(b.low for b in bars[-14:-2])
    context = hours[-12:]
    midpoint = (min(b.low for b in context) + max(b.high for b in context)) / 2
    if not (sweep.low < floor < sweep.close and sweep.low <= midpoint
            and last.close > max(b.high for b in bars[-4:-1]) and last.close > last.open):
        return None
    # If the confirmation itself invalidated the sweep, the setup was lost.
    if last.low <= sweep.low:
        return None
    return _fixed('liquidity_sweep', last.close, sweep.low - 0.15 * atr, 2.0, 12,
                  '1시간 범위 위치 확인 · 유동성 저점/고점 회복 · 3봉 구조 전환',
                  (f'12시간 중앙선 {abs(midpoint):.8g} / 12봉 유동성 경계 {abs(floor):.8g}',
                   f'스윕 극점 {abs(sweep.low):.8g} / 회복 종가 {abs(sweep.close):.8g}',
                   f'직전 3봉 구조선 {abs(max(b.high for b in bars[-4:-1])):.8g} / 확정 종가 {abs(last.close):.8g}'))


def _aot(bars, hours, atr, volume, *, cooldown, **unused):
    last = bars[-1]
    if cooldown or volume < 0.9 or _true_range(last, bars[-2]) > 1.8 * atr:
        return None
    efficiency = _efficiency(hours)
    if efficiency >= 0.50:
        box = bars[-5:-1]
        top, base = max(b.high for b in box), min(b.low for b in box)
        if top - base <= 2 * atr and last.close > top and last.close > last.open:
            return _fixed('trend_compression', last.close, base - 0.2 * atr, 1.8, 24,
                          '추세 국면 · 4봉 변동폭 수축 · 돌파 확인',
                          (f'진입 방향 효율 {efficiency:.2f} / 4봉 폭 {(top - base) / atr:.2f} ATR',
                           f'돌파선 {abs(top):.8g} / 확정 종가 {abs(last.close):.8g}',
                           f'신호 진폭 {_true_range(last, bars[-2]) / atr:.2f} ATR / 거래량 {volume:.2f}배'))
    elif abs(efficiency) <= 0.25:
        box = bars[-14:-2]
        base, top = min(b.low for b in box), max(b.high for b in box)
        width = top - base
        prev = bars[-2]
        if (width > 0 and base <= prev.low <= base + 0.20 * width
                and last.low >= base and last.close > last.open
                and base + 0.25 * width < last.close < base + 0.5 * width
                and last.close > prev.close):
            return Setup('range_reversion', min(prev.low, last.low) - 0.2 * atr,
                         base + 0.5 * width, 8, '횡보 국면 · 박스 경계 방어 · 안쪽으로 복귀',
                         (f'방향 효율 절댓값 {abs(efficiency):.2f} / 진입 쪽 박스 경계 {abs(base):.8g}',
                          f'지지·저항 극점 {abs(prev.low):.8g} / 경계로부터 종가 위치 {(last.close - base)/width:.1%}',
                          f'신호 진폭 {_true_range(last, prev) / atr:.2f} ATR / 거래량 {volume:.2f}배'))
    return None


def _grok(bars, hours, atr, volume, *, weekend, **unused):
    reference = max(b.high for b in hours[-10:-2])
    last = bars[-1]
    minimum_volume = 1.5 if weekend else 1.0
    if not (min(b.close for b in hours[-2:]) > reference
            and abs(last.low - reference) <= 0.35 * atr
            and last.close > reference and last.close > bars[-2].high
            and last.close > last.open and volume >= minimum_volume):
        return None
    return Setup('hold_until_invalidation', reference - 0.75 * atr, None, 0,
                 '2개 시간봉 돌파 유지 · 15분봉 되돌림 후 재상승/재하락 · 거래량 확인',
                 (f'8시간 기준선 {abs(reference):.8g} / 시간봉 종가 {abs(hours[-2].close):.8g}, {abs(hours[-1].close):.8g}',
                  f'재시험 거리 {abs(last.low-reference) / atr:.2f} ATR / 직전 봉 재돌파선 {abs(bars[-2].high):.8g}',
                  f'거래량 {volume:.2f}배 / 시간대 기준 {minimum_volume:.1f}배'), reference)


def chart_fit(setup, bars, hours, atr):
    last = bars[-1]
    if setup.regime == 'trend_retest':
        barrier = max(b.high for b in bars[-11:-3])
        pattern = 1 - abs(bars[-2].low - barrier) / (.25 * atr)
    elif setup.regime == 'hold_until_invalidation':
        pattern = 1 - abs(last.low - setup.invalidation) / (.35 * atr)
    elif setup.regime == 'trend_breakout':
        pattern = (_efficiency(hours) - .55) / .45
    elif setup.regime == 'liquidity_sweep':
        floor = min(b.low for b in bars[-14:-2])
        pattern = (bars[-2].close - floor) / atr
    elif setup.regime == 'trend_compression':
        box = bars[-5:-1]
        pattern = 1 - (max(b.high for b in box) - min(b.low for b in box)) / (2 * atr)
    else:
        pattern = 1 - abs(_efficiency(hours)) / .25
    strength = max(0., min(1., pattern))
    close = max(0., min(1., _location(last)))
    return round(60 * strength + 40 * close, 2), f'패턴 {60*strength:.1f}/60 · 방향별 종가 위치 {40*close:.1f}/40'


def evaluate(symbol, frames, now_ms, *, spread_bps=None, aot_cooldown=False):
    """Return all currently eligible signals, in case-return priority order.

    Times are UTC epoch milliseconds. The last eligible quarter-hour close is the
    decision time for all indicators. At an exact hour boundary the hourly bar
    that has just finished is available. Spread is in basis points.
    """
    try:
        now = int(now_ms)
        bars = _closed(frames.get('15m') or (), QUARTER, now)
        hours = _closed(frames.get('1H') or (), HOUR, now)
    except (TypeError, ValueError, IndexError, OverflowError, AttributeError):
        return []
    if not bars or not hours or bars[-1].volume <= 0:
        return []
    try:
        spread = float(spread_bps)
    except (TypeError, ValueError, OverflowError):
        spread = None
    base_volume = median(b.volume for b in bars[-21:-1])
    atr = _atr(bars[:-1])
    if atr <= 0 or base_volume <= 0:
        return []
    ratio = bars[-1].volume / base_volume
    if not isfinite(ratio) or not isfinite(atr):
        return []
    # Unix day 0 is Thursday; use the UTC date of the signal close.
    signal_close = bars[-1].ts + QUARTER
    weekend = (signal_close // 86400000 + 3) % 7 >= 5
    results = []
    strategies = (_sparta, _todd, _shadow, _aot, _grok)
    reflected_bars, reflected_hours = _mirror(bars), _mirror(hours)
    for priority, strategy in enumerate(strategies, 1):
        guide = _GUIDE[priority - 1]
        for direction, view, context in ((1, bars, hours), (-1, reflected_bars, reflected_hours)):
            setup = strategy(view, context, atr, ratio, spread=spread,
                             cooldown=aot_cooldown, weekend=weekend)
            if setup is None:
                continue
            reference = bars[-1].close
            stop = direction * setup.stop
            target = None if setup.target is None else direction * setup.target
            if not isfinite(stop) or stop <= 0 or direction * (reference - stop) <= 0:
                continue
            if target is not None and (not isfinite(target) or target <= 0
                                       or direction * (target - reference) <= 0):
                continue
            plan = dict(stop_price=stop, target_price=target, max_hold_bars=setup.max_hold_bars,
                        bar_ms=QUARTER)
            if setup.invalidation is not None:
                plan['closed_invalidation'] = dict(frame='1H',
                    relation='below' if direction == 1 else 'above',
                    price=direction * setup.invalidation)
            fit, evidence = chart_fit(setup, view, context, atr)
            results.append(dict(fit=fit, symbol=symbol, strategy_id=guide['id'], priority=priority,
                name=guide['name'], action='LONG' if direction == 1 else 'SHORT',
                reference=reference, structural_stop=stop, target_price=target, atr=atr,
                confirmation_ms=bars[-1].ts, score=ratio, regime=setup.regime,
                exit_plan=plan, reason=setup.reason, conditions=[evidence, *setup.conditions]))
    return results


def rule_guide():
    """UI fields and the identity metadata also used to construct each signal."""
    return [dict(item) for item in _GUIDE]


_GUIDE = (
    dict(id='sparta', priority=1, name='Sparta', roi='+2,319.52%',
         source_label='OKX.AI Trading Hackathon 시즌 1 · 2026.08.11~08.25',
         method='추세·주문 흐름·찬론(纏論) 구조를 함께 확인하는 방식. 공개 설명의 주문 흐름과 구조를 이 프로그램에서는 완료봉 거래량 압력과 돌파선 재시험으로 수치화했다.',
         source_url='https://www.okx.ai/zh-hant/hackathon/trading-01',
         entry='1시간 종가 > 8봉 종가평균 > 21봉 종가평균. 15분봉에서 직전 8봉 최고가를 돌파한 뒤 다음 봉 저점이 돌파선 ±0.25 ATR에 닿고 종가가 선을 지킨다. 그다음 종가가 재시험 봉 고가를 넘고 거래량이 1.2배 이상이어야 한다. 최근 3봉의 거래량 가중 방향성 압력은 0.25 이상이다.',
         short='1시간 하락 정렬에서 8봉 최저가 하향 돌파 → 되돌림 고점이 돌파선을 재시험 → 직전 저점 아래 마감. 매도 방향 압력과 거래량 기준은 같다.',
         exit='재시험 봉과 신호 봉 중 낮은 저점에서 0.25 ATR 아래에 손절, 2R에 익절. 숏은 두 고점 위에 손절한다. 최대 8시간 보유한다.',
         example='롱 예시 · 시간봉 종가 105, 평균 103·101. 15분 돌파선 100, ATR 1, 재시험 저점 100.1·고점 101.0. 다음 봉이 저점 100.3·종가 101.2, 거래량 1.4배, 압력 +0.38이면 손절 99.85, 목표 103.90.'),
    dict(id='todd', priority=2, name='todd', roi='+91.97%',
         source_label='WEEX AI Trading Hackathon 시즌 1 결선 · 2026',
         method='추세·횡보·극단적 변동을 나누고 스프레드가 작은 명확한 추세에서 손절·익절을 지정하는 방식.',
         result_url='https://www.weex.com/zh-CN/events/ai-trading',
         source_url='https://www.weex.global/news/detail/champion-crowned-at-weex-ai-hackathon-revealing-strategy-that-won-600k-365217',
         entry='15분 신호 봉의 갭 포함 진폭이 2.2 ATR를 넘으면 대기한다. 1시간 10구간 방향 효율이 +0.55 이상인 추세에서 호가 스프레드가 12bp 이하이고, 양봉 종가가 직전 12봉 최고가를 넘으며 봉 상단 25% 안에 마감해야 한다. 거래량은 1.1배 이상이다. 횡보에서는 대기한다.',
         short='방향 효율 −0.55 이하인 하락 추세에서 음봉이 직전 12봉 최저가 아래, 봉 하단 25% 안에 마감한다.',
         exit='신호 종가에서 1.25 ATR 역방향에 손절, 1.5R에 익절. 최대 4시간 보유한다.',
         example='롱 예시 · 방향 효율 +0.70, 스프레드 4bp, ATR 1. 직전 최고가 100, 신호 봉 시가 99.9·저가 99.6·고가 100.6·종가 100.5, 거래량 1.3배, 갭 포함 진폭 1.0이면 손절 99.25, 목표 102.375.'),
    dict(id='shadow', priority=3, name='Shadow Trading AI', roi='+74.08%',
         source_label='WEEX AI Trading Hackathon 시즌 1 결선 · 2026',
         method='여러 시간봉의 유동성 이동과 가격 구조 변화를 확인하는 SMC 방식.',
         result_url='https://www.weex.com/zh-CN/events/ai-trading',
         source_url='https://www.weex.com/news/detail/from-human-strategy-to-ai-trading-bot-how-shadow-trading-ai-won-2nd-place-in-the-weex-hackathon-375034',
         entry='15분 봉 저점이 앞선 12봉 최저가를 깬 뒤 같은 봉 종가가 그 가격을 회복한다. 이 저점은 최근 12개 시간봉 범위의 하단 절반에 있어야 한다. 바로 다음 양봉이 해당 저점을 지키며 직전 3봉 최고가 위에서 마감하면 진입한다.',
         short='시간봉 범위 상단에서 12봉 고점을 넘었다가 종가가 되밀린 뒤, 다음 음봉이 그 고점을 재돌파하지 않고 직전 3봉 저점 아래에서 마감한다.',
         exit='유동성을 쓸고 되돌린 봉의 극점에서 0.15 ATR 밖에 손절, 2R에 익절. 최대 3시간 보유한다.',
         example='롱 예시 · 시간봉 범위 중간 102, 15분 직전 저점 100. 저점 99.6·종가 100.2로 회복한 뒤 다음 양봉 저점 100.1·종가 101.1이 3봉 최고가 100.9를 돌파. ATR 1이면 손절 99.45, 목표 104.40.'),
    dict(id='aot', priority=4, name='AOT Matrix', roi='+43.86%',
         source_label='WEEX AI Trading Hackathon 시즌 1 결선 · 2026',
         method='시장 국면을 판별한 뒤 별도 규칙으로 주문하고, 연속 손실 구간에는 거래를 줄이는 방식.',
         result_url='https://www.weex.com/zh-CN/events/ai-trading',
         source_url='https://www.weex.com/news/detail/from-theory-to-live-markets-aot-matrixs-dual-brain-system-in-weex-ai-trading-hackathon-301317',
         entry='1시간 10구간 방향 효율이 +0.50 이상이면 직전 4개 15분봉 전체 폭이 2 ATR 이내로 좁아진 뒤 양봉 종가가 그 고점을 넘을 때 진입한다. 효율 절댓값이 0.25 이하면 횡보로 본다. 직전 봉 저점이 앞선 12봉 박스 하단 20% 안에서 지지받고, 다음 양봉이 하단을 지키며 직전 종가와 박스 25%선을 넘어 중앙선 아래에서 마감해야 한다. 두 경우 모두 갭 포함 진폭 1.8 ATR 이하, 거래량 0.9배 이상이어야 한다. 같은 종목의 AOT 손실 청산 후 60분 대기한다.',
         short='추세에서는 상하단을 반대로 적용해 4봉 박스 하향 돌파를 거래한다. 횡보에서는 상단 20%에서 저항을 확인한 뒤 박스 75%선 아래, 중앙선 위로 되돌아온 음봉을 거래한다.',
         exit='추세에서는 4봉 박스 반대쪽에서 0.2 ATR 밖에 손절, 1.8R 익절, 최대 6시간. 횡보에서는 직전 두 봉 극점에서 0.2 ATR 밖에 손절, 박스 중앙선 익절, 최대 2시간.',
         example='횡보 롱 예시 · 효율 +0.12, 박스 98~102, ATR 1. 직전 저점 98.5·종가 98.8, 다음 양봉 저점 98.6·종가 99.3, 진폭 1.1·거래량 1.0배이고 대기시간이 끝났으면 손절 98.3, 목표 100.'),
    dict(id='grok', priority=5, name='Grok 4.20', roi='+33.7%',
         source_label='Alpha Arena 1.5 · Situational Awareness 주식 무기한선물 계좌 · 2025',
         method='진입 근거가 무효화될 때까지 보유하고 주말 유동성을 고려한 계좌의 운용 방식을 코인 선물에 적용했다.',
         source_url='https://tradingagentstack.com/alpha-arena-results/grok-4-20/',
         entry='최근 2개 시간봉이 모두 그 앞 8개 시간봉의 최고가 위에서 마감하면 그 고점을 기준선으로 고정한다. 15분봉 저점이 기준선 ±0.35 ATR에 닿고 양봉 종가가 기준선과 직전 봉 고가를 모두 넘을 때 진입한다. 신호 봉 거래량은 UTC 평일 1.0배, 주말 1.5배 이상이어야 한다.',
         short='2개 시간봉이 이전 8시간 저점 아래에서 마감한 뒤 15분봉 고점이 기준선을 재시험하고, 음봉 종가가 기준선과 직전 봉 저가 아래에 마감한다.',
         exit='기준선에서 역방향으로 0.75 ATR 떨어진 곳에 보호 손절을 둔다. 진입 후 1시간 종가가 기준선 반대편에서 마감하면 청산한다. 고정 익절가와 시간 만료 없이 보유한다.',
         example='주말 롱 예시 · 8시간 고점 100, 다음 두 시간봉 종가 101.0·100.7. ATR 1, 15분 저점 100.2, 양봉 종가 100.8이 직전 고점 100.6을 넘고 거래량이 1.6배면 진입. 보호 손절 99.25, 시간봉 종가가 100 미만이면 청산.'),
)

// Evidence captured by the strategy and by the exchange's entry order response.
let phoneEntrySignature='',phoneEntryDeadline=0;
function phoneEntryKey(row){return [row.confirmed_ms,row.symbol,row.strategy,row.side].join('|')}
function phoneEntryItem(row,opened,globalHold){
 const card=node('details',undefined,'entry-candidate');
 card.dataset.key=phoneEntryKey(row);card.open=opened;
 const heading=node('summary'),side=row.side==='LONG'?'롱':'숏';
 const name=node('strong',row.symbol.replace(/-USDT-SWAP$/,''));
 const strategy=({'Shadow Trading AI':'Shadow','AOT Matrix':'AOT','Grok 4.20':'Grok'})[row.strategy]||row.strategy;
 const globalBlock=globalHold&&(!row.stage||row.stage==='최종 검사 후 진입 보류');
 const stage=globalBlock?'보류':({'호가 통과 · 주문 전 최종 검사':'검사 중','주문 결과 확인 중':'주문 확인','최종 검사 후 진입 보류':'보류',
  '거래소 응답 미확인 · 주문 대조 중':'응답 대기','미체결 · 주문 접수':'미체결','체결 완료':'체결',
  '잔량 취소 · 일부 체결':'부분체결·잔량취소','전략 조건 통과':'통과'})[row.stage]||row.stage||'통과';
 heading.title=[row.symbol,row.strategy,row.stage||'전략 조건 통과'].join(' · ');
 heading.append(name,node('b',side,row.side==='LONG'?'positive':'negative'),
  node('span',row.priority+'위 '+strategy),node('span',stage,'entry-stage'));
 card.append(heading);
 if(globalBlock)card.append(node('p','전체 진입 보류 · '+globalHold,'entry-evidence'));
 if(row.hold_reason)card.append(node('p','후보 사유 · '+row.hold_reason,'entry-evidence'));
 if(!row.stage&&!globalBlock)card.append(node('p','전략 조건 통과 · 주문 검사 순서 대기','entry-evidence'));
 const prices=node('dl',undefined,'entry-prices');
 function metric(label,value){prices.append(node('dt',label),node('dd',value))}
 metric('진입 기준가',row.reference?row.reference+' USDT':'확인 중');
 if(row.touch)metric('주문 검사 당시 '+(row.side==='LONG'?'매도 1호가':'매수 1호가'),row.touch+' USDT');
 metric(row.stage?.includes('일부 체결')?'체결분 평균가':'실제 평균 체결가',
  row.fill?row.fill+' USDT':row.size?'거래소 평균가 확인 중':'—');
 card.append(prices);
 const details=node('div',undefined,'entry-evidence');
 details.append(node('p',row.strategy+' · '+row.regime));
 const list=node('ul');for(const condition of row.conditions||[])list.append(node('li',condition));
 details.append(list);
 if(row.confirmed_ms)details.append(node('small',kst(row.confirmed_ms)+' KST · 15분봉 종가 확정'));
 card.append(details);
 return card;
}
function phoneRenderEntryCandidates(d){
 const feed=d.entry_candidates||{},now=Date.now();
 const expired=!!feed.period&&now>=feed.period+900000;
 const staleResult=!!d.display_ms&&now-d.display_ms>15000;
 const rows=expired?[]:feed.rows||[];
 const state=d.state||{},paused=state.user_paused||state.preview||state.live===false;
 const note=expired?'이전 신호 만료 · 다음 확정봉 스캔 대기':
  !feed.complete?(feed.scan||'확정봉 스캔 대기'):
  rows.length?(feed.scan||rows.length+'개 전략 조건 통과'):(feed.scan||'스캔 완료')+' · 진입 후보 없음';
 const status=[feed.capacity,note.replace(/^5\.1 · /,'').replace('종목 확인 · 조건 충족 ',' 확인 · 후보 '),staleResult?'화면 수신 지연':null,
  paused?'자동 진입 중지':state.recovering?'계정 대조 중':null].filter(Boolean).join(' · ');
 const label=$('entryCandidateStatus');
 if(label.textContent!==status)label.textContent=status;
 const recent=feed.recent&&!rows.some(row=>phoneEntryKey(row)===phoneEntryKey(feed.recent))?feed.recent:null;
 const signature=JSON.stringify([rows,recent||null,feed.global_hold]);
 phoneEntryDeadline=(!expired&&feed.period)?feed.period+900000:0;
 if(signature===phoneEntrySignature)return;
 const container=$('entryCandidateRows'),last=$('entryCandidateRecent');
 const prior=new Map(Array.from(container.children,card=>[card.dataset.key,card.open]));
 const scroll=container.scrollTop;
 const cards=document.createDocumentFragment();
 rows.forEach(row=>cards.appendChild(phoneEntryItem(row,prior.get(phoneEntryKey(row))??false,feed.global_hold)));
 while(container.firstChild)container.removeChild(container.firstChild);
 container.appendChild(cards);
 container.scrollTop=scroll;
 const previous=last.querySelector('details');
 while(last.firstChild)last.removeChild(last.firstChild);
 if(recent){last.append(node('h3','최근 체결 후보'),phoneEntryItem(recent,
  previous?.dataset.key===phoneEntryKey(recent)?previous.open:false))}
 phoneEntrySignature=signature;
}
function phoneExpireEntryCandidates(d){
 if((phoneEntryDeadline&&Date.now()>=phoneEntryDeadline)||(d.display_ms&&Date.now()-d.display_ms>15000)){
  phoneRenderEntryCandidates(d);
 }
}

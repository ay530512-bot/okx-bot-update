"""Labels for previously opened positions and their history."""
SHORT = 'morning_band_short5'
TREND = 'wick_ema_consensus'
REVERSAL = 'window30_reversal'
NEW = dict(window30_reversal='7시간 30분 이내 반전 돌파', breakout='거래량 동반 돌파', retest='돌파 후 재시험', pullback='EMA20 추세 눌림',
           reclaim='볼린저 밴드 재진입', cloud='일목구름 돌파', shoulders='헤드앤숄더·역헤드앤숄더',
           diamond='다이아몬드 돌파')
RULES = {'five_reversal15':'5분 15봉 반전 돌파 (이전)', 'classic':'15분 두 꼬리', 'swing':'세 스윙 돌파', 'flow5':'종목 흐름 5분 재시험',
         SHORT:'오전 5분 반전 숏',TREND:'15분·1시간 추세 합의',**NEW}

"""Read-only diagnostics history."""
import json
import os
from pathlib import Path
import time


def accumulate(d,p,symbol):
    detail=p.get('entry_diagnostic')
    if not detail:return
    routes=d.setdefault('routes',{})
    for name,value in detail['routes'].items():
        item=routes.setdefault(name,dict(pass_count=0,wait_count=0,inactive_count=0,data_wait_count=0,reasons={}))
        item[value['status']+'_count']+=1
        if value['status']!='pass':
            reason=value['reason'];item['reasons'][reason]=item['reasons'].get(reason,0)+1
    if len(d.setdefault('examples',[]))<3:
        d['examples'].append(dict(symbol=symbol,**detail))


class History:
    """Called by the existing performance writer, never by the order thread.

    Samples are at most one per minute, plus a bounded latest-observation tail.
    These are observations, not unique trading signals or proof of fills.
    """
    def __init__(self,root):
        self.root=Path(root);self.last=0;self.errors=0
        self.run_id=str(os.getpid())+'-'+str(time.time_ns())
        self.last_result=None

    def observe(self,health,report):
        now=time.time()
        if now-self.last<60:return
        self.last=now
        target=self.root/'phone_entry_history.jsonl'
        backup=self.root/'phone_entry_history.previous.jsonl'
        try:
            if target.is_symlink() or backup.is_symlink():raise ValueError('history link')
            if target.exists() and target.stat().st_size>2*1024*1024:
                os.replace(target,backup)
            admission=[dict(group=x['group'],calls=x['calls'],errors=x['errors'])
                       for x in report.get('metrics',[]) if x['label']=='entry.admission_and_order']
            row=dict(version='phone-entry-history-1',run_id=self.run_id,observed_at=now,
                     health=health,admission=admission)
            with target.open('a',encoding='utf-8') as f:
                os.chmod(target,0o600)
                f.write(json.dumps(row,ensure_ascii=False,allow_nan=False)+'\n')
            self.last_result=now
        except Exception:self.errors+=1

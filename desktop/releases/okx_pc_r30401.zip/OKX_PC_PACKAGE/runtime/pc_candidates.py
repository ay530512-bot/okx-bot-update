"""Independent closed-candle entries. The signal price is the completed close."""
from okx_band_flow import atr
from okx_pattern15 import band
from pc_sizing import ema
from pc_extra_entries import SHORT,TREND,FIVE,QUARTER
from pc_wick_context import context,visible_spans,midpoint

NEW = dict(breakout='거래량 동반 돌파', retest='돌파 후 재시험', pullback='EMA20 추세 눌림',
           reclaim='볼린저 밴드 재진입', cloud='일목구름 돌파', shoulders='헤드앤숄더·역헤드앤숄더',
           diamond='다이아몬드 돌파')
RULES = {'classic':'15분 두 꼬리', 'swing':'세 스윙 돌파', 'flow5':'종목 흐름 5분 재시험',
         SHORT:'오전 5분 반전 숏',TREND:'15분·1시간 추세 합의',**NEW}

def rule_id(hit):
    return hit.get('variant') or ('swing' if 'neckline' in hit else 'flow5' if hit.get('step_ms')==FIVE else 'classic')

def switch_key(value):
    if not isinstance(value,str):
        return False
    prefix,_,rule=value.partition(':')
    return prefix in ('on','off') and rule in RULES

def signals(rows,step,tick):
    if len(rows)<55 or rows[-1][0]-rows[-55][0]!=54*step:
        return []
    t,o,h,l,c,v=rows[-1]
    p=rows[-2]
    end=t+step
    a=atr(rows)
    if a<=0 or h<=l:
        return []
    prior=rows[-21:-1]
    closes=[r[4] for r in rows[-160:]]
    avg=ema(closes,20)
    slow=ema(closes,50)
    previous=ema(closes[:-1],20)
    volume=sum(r[5] for r in prior)/20
    if volume<=0:
        return []
    lo,_,hi=band(rows,len(rows)-1)
    found=[]
    def add(name,side,level):
        if side*(c-level)<tick*.999999:
            return
        stop=l if side==1 else h
        found.append(dict(variant=name,side=side,ts=end,trigger_ms=end,price=c,
                          trade_id=0,first=stop,second=level,anchor_ms=t,anchor_atr=a,
                          step_ms=step,bars=1,closed_signal=True))
    for side in (1,-1):
        edge=max(r[2] for r in prior) if side==1 else min(r[3] for r in prior)
        if side*(c-edge)>0 and v>=1.5*volume:
            add('breakout',side,edge)
        for lag in range(1,5):
            idx=len(rows)-1-lag
            setup=rows[idx]
            base=rows[idx-20:idx]
            level=max(r[2] for r in base) if side==1 else min(r[3] for r in base)
            if (side*(setup[4]-level)>0 and all(side*(r[4]-level)>0 for r in rows[idx+1:-1])
                    and l<=level<=h and side*(c-o)>0):
                add('retest',side,level)
                break
        if side*(avg-slow)>0 and side*(avg-previous)>0 and l<=previous<=h and side*(c-o)>0:
            add('pullback',side,previous)
        level=lo if side==1 else hi
        if l<level<h and side*(c-o)>0 and abs(avg-slow)<=a:
            add('reclaim',side,level)
    if step==QUARTER:
        latest=visible_spans(rows[:-1])
        old=visible_spans(rows[:-2])
        if latest and old:
            for side in (1,-1):
                edge=max if side==1 else min
                level=edge(latest)
                if side*(p[4]-edge(old))<=0 and side*(midpoint(rows,9)-midpoint(rows,26))>0:
                    add('cloud',side,level)
        patterns=context(rows,dict(ts=end,price=c,anchor_atr=a),tick)['patterns']
        for pattern in patterns:
            if pattern['confirmed_ms']==end:
                add('diamond' if pattern['kind']=='diamond' else 'shoulders',pattern['side'],pattern['level'])
    return found

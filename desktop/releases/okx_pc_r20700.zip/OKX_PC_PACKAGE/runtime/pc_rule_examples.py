"""Illustrated 15-minute Telegram alerts for manual entries."""

def inverse(bars):
    return [(120-o, 120-lo, 120-hi, 120-c) for o, hi, lo, c in bars]


def figure(example):
    side, explanation, bars, reference, levels = example
    xs = [26, 65, 104, 143, 182]
    def y(value):
        return 132 - value
    points = ' '.join(f'{x},{y(v)}' for x, v in zip(xs, levels))
    candles = []
    for x, (op, high, low, close) in zip(xs, bars):
        color = '#58d6a3' if close >= op else '#ff8793'
        candles.append(f'<g data-prices="{op},{high},{low},{close}" data-x="{x}"><path d="M{x} {y(high)}V{y(low)}" stroke="{color}" stroke-width="2"/>'
                       f'<rect x="{x-6}" y="{y(max(op,close))}" width="12" height="{max(abs(op-close),1)}" fill="{color}"/></g>')
    cy = y(bars[-1][3])
    return (f'<figure><figcaption><b>{side} 알림 예시</b> · 가상 15분봉</figcaption>'
            f'<svg role="img" aria-label="{side} 예시 차트. 점선은 {reference}, 원은 두 번째 꼬리에서 돌아선 첫 체결" viewBox="0 0 300 128">'
            f'<text x="12" y="19" fill="#a7bce3">┄ {reference}</text>'
            f'<polyline points="{points}" fill="none" stroke="#91aacd" stroke-dasharray="4 3"/>'
            + ''.join(candles) +
            f'<g class="entry-marker"><circle cx="182" cy="{cy}" r="4" fill="#101010" stroke="white" stroke-width="2"/>'
            f'<path d="M187 {cy}h18" stroke="white"/><text x="209" y="{cy+4}" fill="white">{side} 알림</text></g>'
            f'</svg><p>{explanation}</p></figure>')


# Last bar stops at the reaction trade, before the second wick candle has closed.
MANUAL_LONG = [(90,92,69,74),(74,76,51,55),(55,56,28,44),(44,48,40,46),(46,47,30,31)]
LOWER_BAND = [74,58,41,38,35]
MANUAL_EXAMPLES = [
    ('롱', '볼린저밴드 하단을 거듭 뚫으며 하락하다 거래량을 동반한 긴 아랫꼬리 음봉이 나옵니다. '
     '잠시 횡보한 뒤 첫 저점보다 높은 두 번째 저점에서 한 호가 이상 반등하는 첫 체결에 알립니다.',
     MANUAL_LONG, '볼밴 하단', LOWER_BAND),
    ('숏', '볼린저밴드 상단을 거듭 뚫으며 상승하다 거래량을 동반한 긴 윗꼬리 양봉이 나옵니다. '
     '잠시 횡보한 뒤 첫 고점보다 낮은 두 번째 고점에서 한 호가 이상 밀리는 첫 체결에 알립니다.',
     inverse(MANUAL_LONG), '볼밴 상단', [120-v for v in LOWER_BAND]),
]

EXAMPLE_LINK = '<strong>예시보기 <i aria-hidden="true">→</i></strong>'
REPLAY = '<button type="button" class="entry-replay">예시 다시 보기 ↻</button></details>'


def alert_panel():
    return ('<aside id="pcEntryAlerts" class="phone-host-notice" aria-labelledby="pcAlertHeading">'
            '<div class="pc-schedule-heading"><h2 id="pcAlertHeading">진입 알림</h2><small>한국시간 (KST)</small></div>'
            '<details id="pcManualWicks" name="pc-rule-examples" class="entry-example"><summary><span>'
            '<b>15분봉 두 꼬리 · 텔레그램 알림</b><small>24시간 · 롱·숏 수동 진입</small>'
            '<small id="pcWickStatus">시세 수신 대기</small></span>' + EXAMPLE_LINK + '</summary>'
            '<p>첫 꼬리 뒤 15분봉 30개 이내에 다시 시험하는 자리를 봅니다. 두 번째 봉이 움직이는 중에 알림을 보냅니다.</p>'
            + ''.join(figure(item) for item in MANUAL_EXAMPLES) + REPLAY + '</aside>')

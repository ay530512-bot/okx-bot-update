"""Durable asynchronous Telegram outbox. Does not block exchange protection."""
import hashlib
import json
import logging
import queue
import threading
import time
import uuid
from pathlib import Path
from okx_daily_report import PhotoRefused, atomic_json, telegram

WICK_EVENT = '15분 두 꼬리 관찰'
WICK_RESULT = '15분 두 꼬리 자동 주문'
DELAY_NOTE = '\n전송 지연 · 당시 신호 기록'
ALLOWED_EVENTS = frozenset(('진입 체결','부분 청산 확인','청산 손익'))


def allowed_pending(item):
    # Older outboxes did not store the event key. Match their exact header.
    key = item.get('event')
    if key is None:
        header = str(item.get('text', '')).split('\n', 1)[0]
        prefix = '[OKX v5.1] '
        key = header[len(prefix):] if header.startswith(prefix) else None
    return key in ALLOWED_EVENTS


def outbox_items(event, text, chart=None):
    if chart is None:
        return [dict(id=uuid.uuid4().hex,event=event,text=text[i:i+3000]) for i in range(0,len(text),3000)]
    from pc_wick_chart import caption_note
    # Reserve room for the timestamp and possible delay notice, including emoji surrogate pairs.
    limit = 1024 - len((caption_note(chart)+DELAY_NOTE).encode('utf-16-le'))//2
    parts, start, units = [], 0, 0
    for i, char in enumerate(text):
        size = 1 if ord(char) <= 0xffff else 2
        if units+size > limit:
            parts.append(text[start:i])
            start, units = i, 0
        units += size
    parts.append(text[start:])
    return [dict(id=uuid.uuid4().hex,event=event,text=part,chart=chart) for part in parts]


class Notifier:
    def __init__(self,root,settings,c):
        self.path=Path(root)/'trade_notifications.json'; self.lock=threading.Lock()
        self.token=settings.get('TELEGRAM_BOT_TOKEN'); self.chat=settings.get('TELEGRAM_CHAT_ID')
        self.enabled=bool(c['notifications']['enabled'] and self.token and self.chat)
        self.identity=hashlib.sha256(f'{self.token}:{self.chat}'.encode()).hexdigest()
        self.data=json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {'identity':self.identity,'pending':[],'states':{}}
        if self.data['identity']!=self.identity: raise ValueError('텔레그램 대상 변경: 기존 알림 기록 확인 필요')
        self.data['pending'] = [p for p in self.data['pending'] if allowed_pending(p)]
        from okx_telegram_brief import brief,migrate_pending_label
        for item in self.data['pending']:
            if item.get('event') in (WICK_EVENT, WICK_RESULT):
                continue
            migrate_pending_label(item)
            if not item['text'].startswith(('[진입]','[대기]','[보유중]','[진입 전 대기]','[거절]','[청산]')):item['text']=brief(item.get('event',''),item['text'])
        self.data.pop('wait_digest',None)
        atomic_json(self.path,self.data)
        self.on_success=None;self.on_failure=None
        self.repeat=c['notifications']['repeat_wait_seconds']; self.stop_event=threading.Event()
    def start(self):
        if self.enabled: threading.Thread(target=self.run,daemon=True,name='telegram-outbox').start()
    def emit(self,key,text,state=None,*,chart=None):
        if not self.enabled or key not in ALLOWED_EVENTS: return
        try:
            from okx_telegram_brief import brief
            self._enqueue(key,brief(key,text),state,chart)
        except Exception:
            # Notification persistence must not interrupt position protection.
            logging.getLogger(__name__).error('텔레그램 알림 기록 실패: 로컬 파일 권한을 확인하세요.')

    def _enqueue(self,key,text,state=None,chart=None):
        with self.lock:
            prior=self.data['states'].get(key)
            if state is not None and prior and prior['value']==state: return
            pending = list(self.data['pending'])
            priority = ('진입 체결','부분 청산 확인','청산 손익','보호 오류')
            index = len(pending)
            if key in priority:
                index = next((i for i,p in enumerate(pending) if p.get('event') not in priority),index)
            items = outbox_items(key,text,chart)
            if chart and key == '진입 체결':
                # Keep this fill's signal and submission in order even if none was sent yet.
                # Compare scalar identity fields, also after tuples have round-tripped through JSON.
                # A re-tested signal has a later intended entry on the same unique anchor.
                fields = ('symbol','side','anchor_ms')
                earlier = [p for p in pending[index:] if p.get('event') in (WICK_EVENT,WICK_RESULT)
                           and p.get('chart') and all(p['chart'][k] == chart[k] for k in fields)]
                ids = {p['id'] for p in earlier}
                pending = [p for p in pending if p['id'] not in ids]
                items = earlier + items
            pending[index:index] = items
            states = dict(self.data['states'])
            states[key] = {'value':state,'time':time.time()}
            data = dict(self.data,pending=pending,states=states)
            atomic_json(self.path,data)
            self.data = data

    def wick_alert(self, symbol, side, anchor_ms, ts, text, chart=None):
        # Signal observations remain available in the PC activity log.
        return

    def wick_result(self, text, signal_id, *, chart=None):
        return

    def deliver(self, session, item):
        chart = item.get('chart')
        execution=item['event'] in ('진입 체결','청산 손익','부분 청산 확인')
        if not chart and not execution:
            return telegram(session,self.token,'sendMessage',chat_id=self.chat,text=item['text'])
        from pc_wick_chart import caption_note, render, execution_photo, settlement_caption
        from pc_wick_entries import TTL_MS
        caption = item['text'] + (caption_note(chart) if chart and not execution else '')
        if item['event'] == '청산 손익':
            caption = settlement_caption(caption)
        if item['event'] == WICK_EVENT and time.time()*1000 > chart['ts']+TTL_MS:
            caption += DELAY_NOTE
        try:
            png = execution_photo(item['event'],item['text'],chart) if execution else render(chart)
        except (OSError, ValueError, TypeError, KeyError, IndexError, ArithmeticError):
            logging.getLogger(__name__).error('두 꼬리 알림 차트 생성 실패')
            caption += '\n차트 생성 실패'
        else:
            try:
                return telegram(session,self.token,'sendPhoto',chat_id=self.chat,caption=caption,
                                files={'photo':('execution.png' if execution else 'wick-15m.png',png,'image/png')})
            except PhotoRefused:
                caption += '\n텔레그램이 사진 전송을 거절했습니다.'
        return telegram(session,self.token,'sendMessage',chat_id=self.chat,text=caption)

    def run(self):
        import requests
        session=requests.Session()
        while not self.stop_event.is_set():
            with self.lock:
                pending = self.data['pending']
                fresh = [p for p in pending if p.get('event') != WICK_EVENT or p.get('chart') or p.get('expires',0) > time.time()]
                if len(fresh) != len(pending):
                    self.data['pending'] = fresh
                    atomic_json(self.path,self.data)
                item=self.data['pending'][0] if self.data['pending'] else None
            if not item: self.stop_event.wait(1); continue
            try:
                self.deliver(session,item)
                if self.on_success:self.on_success()
                with self.lock:
                    self.data['pending']=[p for p in self.data['pending'] if p['id']!=item['id']]
                    atomic_json(self.path,self.data)
            except Exception:
                if self.on_failure:self.on_failure()
                # On ambiguous delivery retain message. A retry may duplicate it; never lose risk alerts silently.
                self.stop_event.wait(30)
        session.close()

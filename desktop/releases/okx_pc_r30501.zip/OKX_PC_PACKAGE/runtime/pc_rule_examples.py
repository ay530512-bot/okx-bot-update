"""Illustrated 15-minute live entries and Telegram signals."""

def inverse(bars):
    return [(120-o, 120-lo, 120-hi, 120-c) for o, hi, lo, c in bars]


def figure(example):
    side, explanation, bars, reference, levels = example
    xs = [26, 65, 104, 143, 182]
    def y(value):
        return 132 - value
    points = ' '.join(f'{x},{y(v)}' for x, v in zip(xs, levels))
    candles = []
    for x, (op, high, low, close) in zip(xs, bars):
        color = '#58d6a3' if close >= op else '#ff8793'
        candles.append(f'<g data-prices="{op},{high},{low},{close}" data-x="{x}"><path d="M{x} {y(high)}V{y(low)}" stroke="{color}" stroke-width="2"/>'
                       f'<rect x="{x-6}" y="{y(max(op,close))}" width="12" height="{max(abs(op-close),1)}" fill="{color}"/></g>')
    cy = y(bars[-1][3])
    return (f'<figure><figcaption><b>{side} 알림 예시</b> · 가상 15분봉</figcaption>'
            f'<svg role="img" aria-label="{side} 예시 차트. 점선은 {reference}, 원은 두 번째 꼬리에서 돌아선 첫 체결" viewBox="0 0 300 128">'
            f'<text x="12" y="19" fill="#a7bce3">┄ {reference}</text>'
            f'<polyline points="{points}" fill="none" stroke="#91aacd" stroke-dasharray="4 3"/>'
            + ''.join(candles) +
            f'<g class="entry-marker"><circle cx="182" cy="{cy}" r="4" fill="#101010" stroke="white" stroke-width="2"/>'
            f'<path d="M187 {cy}h18" stroke="white"/><text x="209" y="{cy+4}" fill="white">{side} 알림</text></g>'
            f'</svg><p>{explanation}</p></figure>')


# Last bar stops at the reaction trade, before the second wick candle has closed.
MANUAL_LONG = [(90,92,69,74),(74,76,51,55),(55,56,28,44),(44,48,40,46),(46,47,30,31)]
LOWER_BAND = [74,58,41,38,35]
MANUAL_EXAMPLES = [
    ('롱', '볼린저밴드 하단을 거듭 뚫으며 하락하다 거래량을 동반한 긴 아랫꼬리 음봉이 나옵니다. '
     '잠시 횡보한 뒤 첫 저점보다 높은 두 번째 저점에서 한 호가 이상 반등하는 첫 체결을 기록합니다.',
     MANUAL_LONG, '볼밴 하단', LOWER_BAND),
    ('숏', '볼린저밴드 상단을 거듭 뚫으며 상승하다 거래량을 동반한 긴 윗꼬리 양봉이 나옵니다. '
     '잠시 횡보한 뒤 첫 고점보다 낮은 두 번째 고점에서 한 호가 이상 밀리는 첫 체결을 기록합니다.',
     inverse(MANUAL_LONG), '볼밴 상단', [120-v for v in LOWER_BAND]),
]

EXAMPLE_LINK = '<strong>예시보기 <i aria-hidden="true">→</i></strong>'
REPLAY = '<button type="button" class="entry-replay">예시 다시 보기 ↻</button></details>'


def alert_panel():
    from pc_candidates import ACTIVE, RULES
    listing=''.join(f'<details><summary>{guide.number}번 · {RULES[key]}</summary>'
                    f'<p>{guide.condition}</p><p>롱 예시 · {guide.long_example}</p>'
                    f'<p>숏 예시 · {guide.short_example}</p></details>'
                    for key, guide in ACTIVE.items())
    return ('<aside id="pcEntryAlerts" class="phone-host-notice" aria-labelledby="pcAlertHeading">'
            '<div class="pc-schedule-heading"><h2 id="pcAlertHeading">자동 진입과 알림</h2><small>한국시간 (KST)</small></div>'
            '<button type="button" role="switch" aria-checked="false" aria-label="일목·RSI 추가 확인" id="pcWickTiming" disabled>일목·RSI 추가 확인 · 상태 확인 중</button>'
            '<p class="muted">켜면 구름·전환선·기준선이 역방향이고 RSI가 30 이하에서 더 하락하거나 70 이상에서 더 상승할 때, 첫 반응보다 진입 방향으로 1~2틱 움직인 체결을 15초 안에 확인합니다. 큰 폭으로 튄 신호는 두 번째 꼬리 재시험을 우선합니다.</p>'
            '<button type="button" role="switch" aria-checked="false" aria-label="종목 흐름에 맞춰 진입" id="pcSymbolFlow" disabled>종목 흐름에 맞춰 진입</button>'
            '<p class="muted">종목 흐름 확인이 켜진 기본 두 꼬리는 보통 속도에서 15분·마감된 1시간봉을 확인합니다. 켜면 종목 흐름과 진입 방향이 일치할 때 주문을 검토합니다. 일목·RSI 추가 확인과 함께 사용할 수 있습니다.</p>'
            '<h3>자동 진입조건표</h3><p>6·7·8번은 빠른 종목은 5분봉, 보통은 15분봉을 사용합니다. 15분봉에서는 15분·1시간 추세 방향도 일치해야 합니다. 예시 가격은 가상이며 공통 주문 검사를 통과해야 진입합니다.</p>'+listing+
            '<small id="pcWickTimingFeedback" role="status"></small>'
            '<details id="pcManualWicks" name="pc-rule-examples" class="entry-example"><summary><span>'
            '<b>15분봉 두 꼬리 · PC 신호 기록</b><small>24시간 신호 · 롱·숏 자동 및 수동 진입</small>'
            '<small id="pcWickStatus">시세 수신 대기</small></span>' + EXAMPLE_LINK + '</summary>'
            '<p>롱은 긴 아랫꼬리가 나온 봉 다음 1~100번째 15분봉에서 더 높은 두 번째 저점을 찾습니다. 100번째 봉까지 포함하며 봉 시작 시각 기준 최대 25시간입니다. 숏은 첫 윗꼬리 다음 1~30번째 봉에서 재시험합니다. 허용 스프레드는 0.08%입니다. 시장가 주문의 예상 슬리피지는 기록용이며 별도 진입 한도가 없습니다. 첫 반응 폭이 두 꼬리 가격 차이와 2틱을 모두 넘으면, 최초 신호부터 15초 안에 두 번째 꼬리 1틱 이내로 돌아온 뒤 진입 방향으로 다시 움직일 때만 주문을 검토합니다. 직접 주문은 차트·포지션에서 할 수 있습니다. 새 포지션은 초기 손절과 +1R 전량 추적을 적용하고, 남은 수량은 진입한 날 한국시간 23:59부터 정리합니다.</p>'
            + ''.join(figure(item) for item in MANUAL_EXAMPLES) + REPLAY + '</aside>')

"""Independent closed-candle entries. The signal price is the completed close."""
from okx_band_flow import atr
from okx_pattern15 import band
from pc_sizing import ema
from pc_extra_entries import SHORT,TREND,FIVE,QUARTER
from pc_wick_context import context,visible_spans,midpoint

REVERSAL15 = 'five_reversal15'
NEW = dict(five_reversal15='5분 15봉 반전 돌파', breakout='거래량 동반 돌파', retest='돌파 후 재시험', pullback='EMA20 추세 눌림',
           reclaim='볼린저 밴드 재진입', cloud='일목구름 돌파', shoulders='헤드앤숄더·역헤드앤숄더',
           diamond='다이아몬드 돌파')
RULES = {'classic':'15분 두 꼬리', 'swing':'세 스윙 돌파', 'flow5':'종목 흐름 5분 재시험',
         SHORT:'오전 5분 반전 숏',TREND:'15분·1시간 추세 합의',**NEW}

# Approval for new orders and the dashboard use the same numbered catalogue.
# Each entry requires a condition and separate long/short worked examples.
from typing import NamedTuple

class EntryGuide(NamedTuple):
    number: int
    condition: str
    long_example: str
    short_example: str

ACTIVE = {
    'classic': EntryGuide(1,'15분봉 볼밴 반복 이탈과 거래량 1.5배 이상인 첫 긴 꼬리 후, 첫 극값을 지킨 두 번째 꼬리의 반응 체결. 간격은 롱 100봉·숏 30봉 이내.',
        '틱 0.01, 첫 저점 10.00 → 재시험 저점 10.01 → 10.02 반등 체결.',
        '틱 0.01, 첫 고점 10.00 → 재시험 고점 9.99 → 9.98 하락 체결.'),
    'breakout': EntryGuide(6,'직전 20봉 범위를 종가로 1틱 이상 돌파하고 거래량이 직전 20봉 평균의 1.5배 이상.',
        '20봉 고가 10.00, 평균 거래량 100 → 거래량 160, 종가 10.05.',
        '20봉 저가 10.00, 평균 거래량 100 → 거래량 160, 종가 9.95.'),
    'retest': EntryGuide(7,'최근 1~4봉 전 20봉 범위를 종가로 돌파. 중간 종가가 선을 지킨 뒤 현재 봉이 선을 터치하고 돌파 방향으로 마감.',
        '10.00 상향 돌파 후 지지 → 저가 9.99, 양봉 종가 10.05.',
        '10.00 하향 돌파 후 저항 → 고가 10.01, 음봉 종가 9.95.'),
    'pullback': EntryGuide(8,'EMA20·EMA50 배열과 EMA20 기울기가 같은 방향. 현재 봉이 직전 EMA20을 터치하고 추세 방향으로 마감.',
        'EMA20이 EMA50 위에서 상승. 직전 EMA20 10.00을 터치한 양봉이 10.05 마감.',
        'EMA20이 EMA50 아래에서 하락. 직전 EMA20 10.00을 터치한 음봉이 9.95 마감.'),
    REVERSAL15: EntryGuide(13,'항상 5분봉. 직전 15봉의 종가 기울기와 첫 시가 대비 마지막 종가가 같은 방향. 반대색 신호봉이 바로 앞 봉의 고가·저가를 종가로 1틱 이상 돌파. 첫 봉 마감에 예상 비용 차감 후 수익이면 전량 청산, 아니면 두 번째 봉 마감에 전량 청산. 보호 손절 우선.',
        '15봉 하락, 직전 음봉 고가 10.00 → 양봉 종가 10.01이면 롱(틱 0.01).',
        '15봉 상승, 직전 양봉 저가 10.00 → 음봉 종가 9.99이면 숏(틱 0.01).'),
}
if any(not all((guide.condition.strip(),guide.long_example.strip(),guide.short_example.strip()))
       for guide in ACTIVE.values()):
    raise ValueError('활성 전략에는 조건과 롱·숏 예시가 필요합니다.')

def rule_id(hit):
    return hit.get('variant') or ('swing' if 'neckline' in hit else 'flow5' if hit.get('step_ms')==FIVE else 'classic')

def switch_key(value):
    if not isinstance(value,str):
        return False
    prefix,_,rule=value.partition(':')
    return prefix in ('on','off') and rule in RULES

def signals(rows,step,tick):
    if len(rows)<55 or rows[-1][0]-rows[-55][0]!=54*step:
        return []
    t,o,h,l,c,v=rows[-1]
    p=rows[-2]
    end=t+step
    a=atr(rows)
    if a<=0 or h<=l:
        return []
    prior=rows[-21:-1]
    closes=[r[4] for r in rows[-160:]]
    avg=ema(closes,20)
    slow=ema(closes,50)
    previous=ema(closes[:-1],20)
    volume=sum(r[5] for r in prior)/20
    if volume<=0:
        return []
    lo,_,hi=band(rows,len(rows)-1)
    found=[]
    def add(name,side,level):
        if side*(c-level)<tick*.999999:
            return
        stop=l if side==1 else h
        found.append(dict(variant=name,side=side,ts=end,trigger_ms=end,price=c,
                          trade_id=0,first=stop,second=level,anchor_ms=t,anchor_atr=a,
                          step_ms=step,bars=1,closed_signal=True))
    for side in (1,-1):
        edge=max(r[2] for r in prior) if side==1 else min(r[3] for r in prior)
        if side*(c-edge)>0 and v>=1.5*volume:
            add('breakout',side,edge)
        for lag in range(1,5):
            idx=len(rows)-1-lag
            setup=rows[idx]
            base=rows[idx-20:idx]
            level=max(r[2] for r in base) if side==1 else min(r[3] for r in base)
            if (side*(setup[4]-level)>0 and all(side*(r[4]-level)>0 for r in rows[idx+1:-1])
                    and l<=level<=h and side*(c-o)>0):
                add('retest',side,level)
                break
        if side*(avg-slow)>0 and side*(avg-previous)>0 and l<=previous<=h and side*(c-o)>0:
            add('pullback',side,previous)
        level=lo if side==1 else hi
        if l<level<h and side*(c-o)>0 and abs(avg-slow)<=a:
            add('reclaim',side,level)
    if step==QUARTER:
        latest=visible_spans(rows[:-1])
        old=visible_spans(rows[:-2])
        if latest and old:
            for side in (1,-1):
                edge=max if side==1 else min
                level=edge(latest)
                if side*(p[4]-edge(old))<=0 and side*(midpoint(rows,9)-midpoint(rows,26))>0:
                    add('cloud',side,level)
        patterns=context(rows,dict(ts=end,price=c,anchor_atr=a),tick)['patterns']
        for pattern in patterns:
            if pattern['confirmed_ms']==end:
                add('diamond' if pattern['kind']=='diamond' else 'shoulders',pattern['side'],pattern['level'])
    return found

def reversal15(rows, tick):
    if len(rows) < 16:
        return None
    window = rows[-16:]
    if any(b[0]-a[0] != FIVE for a,b in zip(window,window[1:])):
        return None
    t,op,high,low,close,_ = window[-1]
    prior = window[:-1]
    _,prev_open,prev_high,prev_low,prev_close,_ = prior[-1]
    if close == op:
        return None
    side = 1 if close > op else -1
    level = prev_high if side == 1 else prev_low
    slope = sum((i-7)*row[4] for i,row in enumerate(prior))
    if (side*(prev_close-prev_open) >= 0 or side*(prev_close-prior[0][1]) >= 0
            or side*slope >= 0 or side*(close-level) < tick*.999999):
        return None
    volatility = atr(rows)
    if volatility <= 0:
        return None
    return dict(variant=REVERSAL15,side=side,ts=t+FIVE,trigger_ms=t+FIVE,price=close,
                trade_id=0,first=low if side==1 else high,second=level,anchor_ms=t,
                anchor_atr=volatility,step_ms=FIVE,bars=15,closed_signal=True)

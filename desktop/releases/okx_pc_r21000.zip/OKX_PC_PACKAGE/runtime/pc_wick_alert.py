"""Long/short reactions on confirmed 15-minute anchors and ordered live OKX trades."""
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import math

from okx_band_flow import atr
from okx_pattern15 import band

STEP = 15 * 60_000
WINDOW = 30
HISTORY = 60
KST = timezone(timedelta(hours=9))


def candle(raw):
    if len(raw) < 9 or raw[8] not in ('0', '1'):
        raise ValueError('15분봉 형식')
    stamp = int(raw[0])
    o, h, l, c, v = (float(x) for x in raw[1:6])
    if (stamp < 0 or stamp % STEP or not all(math.isfinite(x) for x in (o,h,l,c,v))
            or not 0 < l <= min(o,c) <= max(o,c) <= h or v < 0):
        raise ValueError('15분봉 가격')
    return (stamp,o,h,l,c,v), raw[8] == '1'


def band_walk(rows, count):
    # The last five bars having two breaches is enough to subscribe to trades
    # before the sixth bar can become an anchor.
    hits = []
    for i in range(len(rows)-count, len(rows)):
        lower, mid, _ = band(rows, i)
        if rows[i][3] < lower:
            hits.append(rows[i][3])
    return hits


@dataclass
class Anchor:
    stamp: int
    low: float
    atr: float
    zone: float
    depart: float
    away: bool
    pause_open: float = 0.
    pause_close: float = 0.
    pause_high: float = -math.inf
    pause_low: float = math.inf


def first_wick(rows, tick):
    if len(rows) < 25:
        return None
    t, o, h, l, c, v = rows[-1]
    if c >= o or c-l < max((h-l)*.5, 2*tick)-tick*1e-7:
        return None
    volume_mean = sum(r[5] for r in rows[-21:-1])/20
    if volume_mean <= 0 or v < 1.5*volume_mean:
        return None
    a = atr(rows)
    hits = band_walk(rows, 6)
    previous = rows[:-1]
    # A single dump from a flat box is not a band walk. The close and band
    # were already falling, with distinct, successively lower breaches.
    prior_hits = band_walk(previous,5)
    if (len(prior_hits) < 2 or prior_hits[-1] >= prior_hits[0]
            or previous[-1][4] >= rows[-7][4] or band(rows,len(rows)-2)[1] >= band(rows,len(rows)-6)[1]):
        return None
    if (len(hits) < 3 or hits[-1] >= hits[0] or a <= 0
            or rows[-7][4]-c < a or band(rows,len(rows)-1)[1] >= band(rows,len(rows)-6)[1]):
        return None
    zone = l + max(3*tick,.20*a)
    depart = zone + max(tick,.12*a)
    return Anchor(t,l,a,zone,depart,c >= depart-tick*1e-7)


class Detector:
    def __init__(self, tick):
        self.tick = tick
        self.eps = tick*1e-6
        self.rows = deque(maxlen=HISTORY)
        self.anchor = None
        self.precursor = False
        self.reset_trade_feed()

    def reset_trade_feed(self):
        self.live = None
        self.partial_ready = False
        self.test_low = None
        self.last_id = -1
        self.last_ts = -1
        self.live_trade_bar = None
        self.observed_from_open = False

    def seed(self, rows):
        self.rows.clear()
        self.anchor = None
        self.precursor = False
        self.reset_trade_feed()
        # Only the most recent 30 bars can anchor the present retest. Preserve
        # warm-up bars for their Bollinger, volume and ATR calculations.
        for row in rows[:-WINDOW]:
            self.rows.append(row)
        for row in rows[-WINDOW:]:
            self.closed(row,historical=True)

    def closed(self, row, historical=False):
        if self.rows and row[0] <= self.rows[-1][0]:
            return
        if self.rows and row[0] != self.rows[-1][0]+STEP:
            self.rows.clear()
            self.anchor = None
            self.reset_trade_feed()
        a = self.anchor
        if a:
            t,o,h,l,c,_ = row
            missed = historical or self.live_trade_bar != t or not self.observed_from_open
            # On boot / reconnect only carry forward an anchor whose past candles
            # could not already have completed a retest. Never send old signals.
            if (t-a.stamp >= WINDOW*STEP or l <= a.low+self.eps
                    or (missed and l <= a.zone+self.eps and (a.away or h >= a.depart-self.eps))):
                self.anchor = None
            else:
                if not a.pause_open:
                    a.pause_open = o
                a.pause_close = c
                a.pause_high = max(a.pause_high,h)
                a.pause_low = min(a.pause_low,l)
                if a.pause_high-a.pause_low > 1.5*a.atr+self.eps:
                    self.anchor = None
                elif h >= a.depart-self.eps:
                    a.away = True
        self.rows.append(row)
        rows = list(self.rows)
        fresh = first_wick(rows, self.tick)
        if fresh:
            self.anchor = fresh
            self.test_low = None
        self.precursor = len(rows) >= 24 and len(band_walk(rows,5)) >= 2

    def forming(self, row, partial_ready=True):
        if self.rows and row[0] <= self.rows[-1][0]:
            return
        # An official cumulative low can invalidate a setup, but cannot generate
        # a signal. Only a fresh trade can establish the low and a later trade can turn.
        t,o,h,l,_,_ = row
        if self.live and t < self.live[0]:
            return
        if not self.live or t != self.live[0]:
            self.live = [t,o,h,l]
            self.test_low = None
        else:
            self.live[1] = o
            self.live[2] = max(self.live[2],h)
            self.live[3] = min(self.live[3],l)
        self.partial_ready = partial_ready
        if self.test_low is not None and l < self.test_low-self.eps:
            self.test_low = None
        if self.anchor and t > self.anchor.stamp and l <= self.anchor.low+self.eps:
            self.anchor = None

    def trade(self, ts, trade_id, px, *, covered_from_open=False):
        if trade_id <= self.last_id or ts < self.last_ts or not math.isfinite(px):
            return None
        self.last_id, self.last_ts = trade_id, ts
        t = ts//STEP*STEP
        if not self.rows or self.rows[-1][0] != t-STEP:
            return None
        if self.live_trade_bar != t:
            self.live_trade_bar = t
            self.observed_from_open = covered_from_open
        if self.live is None or self.live[0] != t:
            if not covered_from_open:
                return None
            self.forming((t,px,px,px,px,0))
        elif not covered_from_open and not self.partial_ready:
            return None
        else:
            self.live[2] = max(self.live[2],px)
            self.live[3] = min(self.live[3],px)
        a = self.anchor
        if a is None or not STEP <= t-a.stamp <= WINDOW*STEP:
            return None
        low = self.live[3]
        if low <= a.low+self.eps:
            self.anchor = None
            return None
        if not a.away:
            if px >= a.depart-self.eps:
                a.away = True
            return None
        if a.pause_open:
            quiet = abs(a.pause_close-a.pause_open) <= .5*a.atr+self.eps
        else:
            quiet = self.live[2]-low <= 1.5*a.atr+self.eps and abs(px-self.live[1]) <= .5*a.atr+self.eps
        if px <= a.zone+self.eps and px <= low+self.eps:
            self.test_low = px
        bottom = self.test_low
        if (not quiet or bottom is None or bottom < a.low+self.tick-self.eps
                or min(self.live[1],px)-bottom < self.tick-self.eps):
            return None
        self.anchor = None
        self.test_low = None
        return dict(anchor_ms=a.stamp, anchor_atr=a.atr, first=a.low, second=bottom,
                    price=px, ts=ts, trade_id=trade_id, bars=(t-a.stamp)//STEP)


def oriented(row, side):
    if side == 1:
        return row
    t,o,h,l,c,v = row
    return t,-o,-l,-h,-c,v


class MarketWicks:
    """Run the same lower-wick logic in signed prices, mirroring every threshold."""
    def __init__(self, tick):
        self.long = Detector(tick)
        self.short = Detector(tick)
        self.chart_bar = None

    @property
    def last_close(self):
        return self.long.rows[-1][0] if self.long.rows else -1

    def seed(self, rows):
        self.chart_bar = None
        self.long.seed(rows)
        self.short.seed([oriented(r,-1) for r in rows])

    def closed(self, row, historical=False):
        self.long.closed(row,historical)
        self.short.closed(oriented(row,-1),historical)

    def forming(self, row, partial_ready=True):
        self.long.forming(row,partial_ready)
        self.short.forming(oriented(row,-1),partial_ready)

    def wants_trades(self):
        return bool(self.long.anchor or self.short.anchor or self.long.precursor or self.short.precursor)

    def reset_trade_feed(self):
        self.chart_bar = None
        self.long.reset_trade_feed()
        self.short.reset_trade_feed()

    def trade(self, ts, trade_id, price, covered):
        if not math.isfinite(price) or price <= 0:
            return []
        # Candle updates and trades can arrive out of order across channels. Build the
        # unfinished chart candle from ordered trades so later extrema never enter a photo.
        bucket = ts//STEP*STEP
        if bucket == self.last_close+STEP and trade_id > self.long.last_id and ts >= self.long.last_ts:
            bar = self.chart_bar
            if bar is None or bar[0] != bucket:
                self.chart_bar = [bucket, price, price, price, price]
            else:
                bar[2], bar[3], bar[4] = max(bar[2],price), min(bar[3],price), price
        hits = []
        for side, detector in ((1,self.long),(-1,self.short)):
            hit = detector.trade(ts,trade_id,side*price,covered_from_open=covered)
            if hit:
                hit['side'] = side
                hit['chart_bar'] = tuple(self.chart_bar)
                for key in ('first','second','price'):
                    hit[key] *= side
                hits.append(hit)
        return hits


def alert_text(symbol, hit, tick_text):
    from decimal import Decimal
    places = max(0,-Decimal(str(tick_text)).normalize().as_tuple().exponent)
    def price(x):
        return format(x, f'.{places}f')
    def clock(t):
        return datetime.fromtimestamp(t/1000,KST).strftime('%m/%d %H:%M:%S')
    side = hit['side']
    direction, first_bar, extreme, reaction = (
        ('롱','음봉 아랫꼬리','저점','반등') if side == 1 else ('숏','양봉 윗꼬리','고점','하락'))
    return (f"[두 꼬리 {direction} 신호 · 15분봉] {symbol.replace('-USDT-SWAP','/USDT')}\n"
            f"첫 {first_bar} {extreme} {price(hit['first'])} ({clock(hit['anchor_ms'])} 봉)\n"
            f"두 번째 {extreme} {price(hit['second'])} · {reaction} 체결가 {price(hit['price'])}\n"
            f"{clock(hit['ts'])} KST · 첫 꼬리 이후 {hit['bars']}번째 봉")

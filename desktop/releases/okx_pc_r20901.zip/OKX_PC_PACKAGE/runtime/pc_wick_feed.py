"""Public 15-minute candles and ordered trades for two-wick notifications and entries."""
from collections import deque
from queue import Empty, Full, Queue
import json
import math
import threading
import time

from pc_wick_alert import HISTORY, STEP, MarketWicks, alert_text, candle
from pc_wick_chart import snapshot

WS_URL = 'wss://ws.okx.com/ws/v5/business'
CANDLES_URL = 'https://www.okx.com/api/v5/market/candles'
CANDLE = 'candle15m'
TRADES = 'trades-all'


class SymbolWatch:
    def __init__(self, tick):
        self.tick = tick
        self.rule = MarketWicks(float(tick))
        self.ready = False
        self.queued = False
        self.retry = 0.
        self.recent = {}
        self.forming = None
        self.early_trades = []
        self.ack_at = math.inf
        self.fresh_forming = False

    def invalidate(self):
        self.ready = False
        self.rule = MarketWicks(float(self.tick))
        self.early_trades.clear()
        self.fresh_forming = False

    def ws_bar(self, row, done):
        if done:
            self.recent[row[0]] = row
            self.recent = dict(sorted(self.recent.items())[-HISTORY:])
            if self.ready:
                if row[0] > self.rule.last_close+STEP:
                    self.invalidate()
                else:
                    self.rule.closed(row)
        elif self.forming is None or row[0] >= self.forming[0]:
            self.forming = row
            self.fresh_forming = self.ack_at != math.inf
            if self.ready and row[0] == self.rule.last_close+STEP:
                self.rule.forming(row,self.fresh_forming)

    def seed(self, raw, now):
        closed = {}
        current = None
        for r in raw:
            row, done = candle(r)
            if done:
                closed[row[0]] = row
            elif current is None or row[0] > current[0]:
                current = row
        closed.update(self.recent)
        keys = sorted(t for t in closed if t+STEP <= now)[-HISTORY:]
        if not keys or keys[-1] != now//STEP*STEP-STEP:
            return False
        # A newly listed instrument may have less than the full history.
        start = len(keys)-1
        while start > 0 and keys[start-1]+STEP == keys[start]:
            start -= 1
        self.rule.seed([closed[k] for k in keys[start:]])
        # Prefer the most complete intrabar extrema across REST and WS.
        for forming in (current,self.forming):
            if forming and forming[0] == keys[-1]+STEP:
                self.rule.forming(forming,forming is self.forming and self.fresh_forming)
        self.ready = True
        return True

    def print(self, ts, trade_id, price, now):
        if not self.ready or self.ack_at == math.inf or ts > now+2000:
            return []
        bar = ts//STEP*STEP
        if bar == self.rule.last_close+2*STEP:
            # Candles and trades are separate channels; the new bar's trades
            # can precede confirmation of the preceding 15-minute close.
            if len(self.early_trades) >= 8000:
                self.invalidate()
            else:
                self.early_trades.append((ts,trade_id,price))
            return []
        hits = self.rule.trade(ts,trade_id,price,self.ack_at < bar)
        return hits if now-ts <= 5000 else []

    def take_buffered(self):
        if not self.early_trades or self.early_trades[0][0]//STEP*STEP > self.rule.last_close+STEP:
            return []
        values, self.early_trades = self.early_trades, []
        return values


class PublicWickFeed:
    def __init__(self, universe, notifier, cfg, now=None, entries=None):
        self.universe = universe
        self.notifier = notifier
        self.entries = entries
        self.config = cfg
        self.now = now or (lambda: int(time.time()*1000))
        self.stop_event = threading.Event()
        self.jobs = Queue(maxsize=400)
        self.completed = Queue(maxsize=450)
        self.generation = 0
        self.status = '텔레그램 연결 설정 필요'
        self.threads = []
        self.markets = {}
        self.seed_cache = {}

    def start(self):
        if self.entries is None and not self.notifier.enabled:
            return
        self.status = '15분봉 수신 대기'
        for target, name in ((self.bootstrap,'wick-history'),(self.run,'wick-public')):
            thread = threading.Thread(target=target, name=name, daemon=True)
            self.threads.append(thread)
            thread.start()

    def stop(self):
        self.stop_event.set()
        for thread in self.threads:
            thread.join(timeout=1.5)

    def instruments(self):
        from phone_trend_slot import permitted
        full = self.universe.full_market
        if full is None:
            return {}
        with self.universe.lock:
            rows = list(full.instruments.items())
        instruments = {}
        for symbol, row in rows:
            if permitted(dict(symbol=symbol,instrument=row),self.config):
                tick = row.get('tickSz')
                if tick and math.isfinite(float(tick)) and float(tick)>0:
                    instruments[symbol] = str(tick)
        return instruments

    def bootstrap(self):
        import requests
        with requests.Session() as http:
            while not self.stop_event.is_set():
                try:
                    generation, symbol = self.jobs.get(timeout=.4)
                except Empty:
                    continue
                if generation != self.generation:
                    continue
                try:
                    data = http.get(CANDLES_URL,params=dict(instId=symbol,bar='15m',limit='61'),
                                    timeout=(3,6)).json()
                    raw = data['data'] if data.get('code')=='0' else []
                except (ValueError,KeyError,requests.RequestException):
                    raw = []
                while not self.stop_event.is_set() and generation == self.generation:
                    try:
                        self.completed.put((generation,symbol,raw),timeout=.5)
                        break
                    except Full:
                        continue
                self.stop_event.wait(.27)

    def history(self, now):
        for _ in range(24):
            try:
                generation, symbol, raw = self.completed.get_nowait()
            except Empty:
                break
            state = self.markets.get(symbol)
            if generation != self.generation or state is None:
                continue
            state.queued = False
            try:
                good = bool(raw) and state.seed(raw,now)
            except (ValueError,TypeError,IndexError):
                good = False
            if good:
                self.seed_cache[symbol] = tuple(state.rule.long.rows)
            else:
                state.retry = time.monotonic()+12
        for symbol,state in self.markets.items():
            if state.ready or state.queued or state.retry > time.monotonic():
                continue
            try:
                self.jobs.put_nowait((self.generation,symbol))
            except Full:
                break
            state.queued = True

    def trade(self, symbol, state, ts, trade_id, price, now):
        if self.entries and math.isfinite(price) and price>0 and ts<=now+2000:
            self.entries.invalidate(symbol,ts=ts,low=price,high=price)
        for hit in state.print(ts,trade_id,price,now):
            if self.entries:
                self.entries.offer(symbol,hit,state.tick,tuple(state.rule.long.rows))
            else:
                chart = snapshot(symbol,hit,state.tick,state.rule.long.rows)
                self.notifier.wick_alert(symbol,hit['side'],hit['anchor_ms'],hit['ts'],alert_text(symbol,hit,state.tick),chart)

    def message(self, obj, now):
        arg = obj.get('arg',{})
        symbol,channel = arg.get('instId'),arg.get('channel')
        if obj.get('event') == 'error':
            raise ValueError('OKX 공개 알림 구독 지연')
        state = self.markets.get(symbol)
        if state is None:
            return
        if obj.get('event') in ('subscribe','unsubscribe'):
            if channel == TRADES:
                if self.entries:
                    self.entries.invalidate(symbol)
                state.ack_at = now if obj['event']=='subscribe' else math.inf
                state.rule.reset_trade_feed()
                state.fresh_forming = False
                state.early_trades.clear()
                if state.forming is not None:
                    state.rule.forming(state.forming,False)
            return
        if channel == CANDLE:
            for raw in sorted(obj.get('data',[]),key=lambda r:int(r[0])):
                row,done = candle(raw)
                state.ws_bar(row,done)
                if self.entries:
                    if state.ready:
                        self.entries.invalidate(symbol,ts=min(now,row[0]+STEP-1),low=row[3],high=row[2])
                    else:
                        self.entries.invalidate(symbol)
                if done and state.ready:
                    self.seed_cache[symbol] = tuple(state.rule.long.rows)
                    for ts,trade_id,price in state.take_buffered():
                        self.trade(symbol,state,ts,trade_id,price,now)
                    if state.forming and state.forming[0] == state.rule.last_close+STEP:
                        state.rule.forming(state.forming,state.fresh_forming)
        elif channel == TRADES and state.ready:
            for r in sorted(obj.get('data',[]),key=lambda d:(int(d['ts']),int(d['tradeId']))):
                if r.get('instId',symbol) != symbol:
                    continue
                self.trade(symbol,state,int(r['ts']),int(r['tradeId']),float(r['px']),now)

    def session(self, ws):
        import websocket
        self.generation += 1
        self.markets = {}
        requested = set()
        ops = deque()
        next_meta = next_check = next_sub = 0.
        last_frame = time.monotonic()
        ping_at = None
        while not self.stop_event.is_set():
            mono = time.monotonic()
            if mono >= next_check:
                if mono >= next_meta:
                    instruments = self.instruments()
                    self.markets = {s:(self.markets[s] if s in self.markets and self.markets[s].tick==tick
                                       else SymbolWatch(tick)) for s,tick in instruments.items()}
                    for symbol,state in self.markets.items():
                        cached = self.seed_cache.get(symbol)
                        if not state.ready and cached and cached[-1][0] == self.now()//STEP*STEP-STEP:
                            state.rule.seed(cached)
                            state.ready = True
                    self.seed_cache = {s:v for s,v in self.seed_cache.items() if s in self.markets}
                    next_meta = mono+(60 if instruments else 2)
                self.history(self.now())
                targets = {(s,CANDLE) for s in self.markets}
                targets.update((s,TRADES) for s,state in self.markets.items() if state.ready and state.rule.wants_trades())
                if self.entries:
                    self.entries.warm = frozenset(s for s,state in self.markets.items()
                                                  if state.ready and (state.rule.long.anchor or state.rule.short.anchor))
                    targets.update((s,TRADES) for s in self.entries.quote_symbols() if s in self.markets)
                while ops and mono-ops[0] >= 3600:
                    ops.popleft()
                if mono >= next_sub and len(ops)<400 and requested != targets:
                    added = targets-requested
                    op,pairs = ('subscribe',added) if added else ('unsubscribe',requested-targets)
                    # All pairs are explicit public instruments. One operation
                    # batches multiple symbols and fits the WS message limit.
                    group = sorted(pairs,key=lambda x:(x[1]!=CANDLE,x[0]))[:400]
                    ws.send(json.dumps({'op':op,'args':[dict(instId=s,channel=c) for s,c in group]}))
                    if added:
                        requested.update(group)
                    else:
                        requested.difference_update(group)
                    next_sub = mono+1
                    ops.append(mono)
                self.status = (f'15분봉 감시 {sum(s.ready for s in self.markets.values())}/{len(self.markets)}종목'
                               if self.markets else '대상 종목 수신 대기')
                if not self.notifier.enabled:
                    self.status += ' · 텔레그램 연결 설정 필요'
                next_check = mono+.5
            if mono-last_frame >= 18 and ping_at is None:
                ws.send('ping')
                ping_at = mono
            if ping_at is not None and mono-ping_at > 12:
                raise TimeoutError('공개 알림 연결 재시도')
            try:
                message = ws.recv()
            except websocket.WebSocketTimeoutException:
                continue
            if not message:
                raise ConnectionError('공개 알림 연결 종료')
            last_frame = time.monotonic()
            ping_at = None
            if message != 'pong':
                self.message(json.loads(message),self.now())

    def run(self):
        import websocket
        delay = 1
        while not self.stop_event.is_set():
            ws = None
            started = time.monotonic()
            try:
                ws = websocket.create_connection(WS_URL,timeout=6)
                ws.settimeout(1)
                self.session(ws)
            except (OSError,ValueError,KeyError,TypeError,IndexError,websocket.WebSocketException):
                self.status = '공개 시세 재연결 중'
            finally:
                if self.entries:
                    self.entries.warm = frozenset()
                    self.entries.invalidate()
                self.generation += 1
                if ws:
                    try:
                        ws.close(timeout=1)
                    except (OSError,websocket.WebSocketException):
                        pass
            delay = 1 if time.monotonic()-started>60 else min(30,2*delay)
            self.stop_event.wait(delay)

"""Route the live 15m two-wick reaction to Telegram and the serialized PC order engine."""
from dataclasses import dataclass, field
import logging
import math
import threading

from okx_core import BotError, UnknownOutcome
from okx_entry_gate720 import gate
from okx_pattern15 import band, summary
from pc_sizing import SLOTS, indicators, leverage_for, round_stop
from pc_wick_alert import STEP, WINDOW, alert_text

ROUTE = 'bb_wick_retest_15m'
TTL_MS = 15_000


@dataclass
class Reaction:
    symbol: str
    hit: dict
    tick: str
    bars: tuple
    initial_block: str
    invalid: threading.Event = field(default_factory=threading.Event)
    announced: threading.Event = field(default_factory=threading.Event)

    @property
    def key(self):
        return self.symbol + ('/long' if self.hit['side'] == 1 else '/short')

    @property
    def signal_id(self):
        return f"wick280-{self.key}-{self.hit['anchor_ms']}"


def entry_distances(reaction):
    """Observable at the reaction print, including signals later rejected by the order gate."""
    if len(reaction.bars) < 20:
        return None
    hit = reaction.hit
    if reaction.bars[-1][0] != hit['ts']//STEP*STEP - STEP:
        return None
    side, price, tick = hit['side'], hit['price'], float(reaction.tick)
    mid = sum(row[4] for row in reaction.bars[-20:])/20
    stop = round_stop(hit['first'] - side*max(2*tick, .15*hit['anchor_atr']),tick,side)
    return dict(mid=mid, stop=stop, room_pct=100*side*(mid-price)/price,
                risk_pct=100*side*(price-stop)/price)


def make_signal(engine, reaction):
    from phone_trend_slot import permitted
    hit, bars, symbol = reaction.hit, reaction.bars, reaction.symbol
    side, price, first, second = (hit[k] for k in ('side','price','first','second'))
    tick, atr = float(reaction.tick), hit['anchor_atr']
    now = engine.api.now_ms()
    if not (0 <= now-hit['ts'] <= TTL_MS and bars and
            bars[-1][0] == hit['ts']//STEP*STEP-STEP and
            1 <= (hit['ts']//STEP*STEP-hit['anchor_ms'])//STEP <= WINDOW and
            side in (-1,1) and min(price, first, second, tick, atr)>0 and
            side*(second-first)>0 and side*(price-second)>0):
        raise BotError('두 꼬리 반응 체결 또는 완료봉 확인 시간 만료')
    instrument = engine.api.public('/api/v5/public/instruments', instType='SWAP', instId=symbol)[0]
    if (instrument.get('instId') != symbol or not permitted(dict(symbol=symbol,instrument=instrument),engine.cfg)
            or float(instrument['tickSz']) != tick):
        raise BotError('허용 종목 또는 호가 단위 변경')
    stop = round_stop(first-side*max(2*tick,.15*atr),tick,side)
    ev = indicators(bars,side,atr)
    if not ev or not 0<stop or side*(price-stop)<=0:
        raise BotError('배율·첫 꼬리 손절 계산 자료 부족')
    ev['stop'] = stop
    maximum = float(instrument.get('lever') or 0)
    leverage = leverage_for(ev,price,maximum)
    if not leverage:
        raise BotError('3배에서도 첫 꼬리 손절과 거래비용이 위험 한도를 초과함')
    action = 'LONG' if side == 1 else 'SHORT'
    frame = summary(bars)
    lo,mid,hi = band(bars,len(bars)-1)
    proof = dict(route721=ROUTE, action=action, first_wick=first, second_wick=second,
                 anchor_ms=hit['anchor_ms'], reaction_ms=hit['ts'], trade_id=hit['trade_id'],
                 reference=price, structural_stop=stop, atr=atr, sizing_indicators=ev,
                 timing_distances=entry_distances(reaction))
    return dict(symbol=symbol,action=action,pc_wick280=True,pc260=True,rule_channel701=True,
                free_ai=True,pattern15=True,strategy='band_flow',pattern=ROUTE,
                leverage=leverage,indicator_limit=maximum,margin_fraction=1/SLOTS,
                reason='15분봉 볼린저밴드 두 꼬리 · 두 번째 꼬리의 첫 반응 체결',
                regime='두 꼬리 반전',ma=frame['ma'],bb=dict(lower=lo,mid=mid,upper=hi),
                rsi={'15m':frame['rsi14']},atr=atr,level=stop,stop=stop,target=None,retest=True,
                adaptive=False,setup_frame='15m',execution_frame='15m',signal_id=reaction.signal_id,
                at_ms=hit['ts'],valid_from_ms=hit['ts'],expires_ms=hit['ts']+TTL_MS,
                entry_reference=price,entry_gap=price,selection=dict(activity={},asset_category='1',origin=ROUTE),
                holding_rule=dict(frame='15m',zone=stop,target=None,target_mode='trailing_only',
                                  partial=False,rule_channel701=True,pattern15=True),
                decision_record=dict(source=ROUTE,frames={'15m':{'analysis':frame}},volume_wick_proof=proof))


class WickEntries:
    def __init__(self, engine):
        self.engine = engine
        self.lock = threading.Lock()
        self.pending = {}
        self.warm = frozenset()
        self.current = None
        self.seen = dict(engine.journal.data.get('pc_wick280_seen',{}))
        # A 2.7.0 alert may already have been acted on manually before the update.
        for key, stamp in engine.notifier.data.get('wick_15m_seen',{}).items():
            self.seen[key] = max(stamp,self.seen.get(key,-1))

    def blocked(self):
        e = self.engine
        if e.stop_event.is_set():
            return '프로그램 종료 중'
        if getattr(getattr(e,'pc_updater',None),'installing',False):
            return 'PC 업데이트 설치 중'
        state = gate(e)
        return '' if state['allowed'] else state['reason']

    def offer(self, symbol, hit, tick, bars):
        from pc_intraday import session_close_ms, ENTRY_CLOSED
        block = self.blocked()
        if self.engine.api.now_ms() >= session_close_ms(hit['ts']):
            block = block or ENTRY_CLOSED
        reaction = Reaction(symbol,dict(hit),tick,bars,block)
        with self.lock:
            if self.seen.get(reaction.key,-1) >= hit['anchor_ms']:
                return
            self.seen[reaction.key] = hit['anchor_ms']
            self.pending[reaction.signal_id] = reaction
        note = ('자동 미진입 · '+reaction.initial_block) if reaction.initial_block else '자동 주문 조건 확인 중'
        msg = alert_text(symbol,hit,tick)
        distances = entry_distances(reaction)
        if distances:
            msg += (f"\n진입 방향으로 볼밴 중심선까지 {distances['room_pct']:+.2f}%"
                    f" · 첫 손절까지 {distances['risk_pct']:.2f}%")
        msg += '\n'+note
        try:
            self.engine.notifier.wick_alert(symbol,hit['side'],hit['anchor_ms'],hit['ts'],msg)
        except Exception:
            logging.exception('두 꼬리 신호 알림 보관 실패')
        reaction.announced.set()
        self.engine.command_wake.set()
        try:
            self.engine.log(msg)
        except OSError:
            logging.exception('두 꼬리 신호의 최근 활동 저장 실패')

    def quote_symbols(self):
        with self.lock:
            return {r.symbol for r in self.pending.values() if not r.initial_block}

    def invalidate(self, symbol=None, *, ts=None, low=None, high=None):
        with self.lock:
            for r in self.pending.values():
                if symbol is not None and symbol != r.symbol:
                    continue
                if ts is not None:
                    if ts < r.hit['ts']:
                        continue
                    side = r.hit['side']
                    extreme = low if side == 1 else high
                    if side*(extreme-r.hit['second']) >= -float(r.tick)*1e-6:
                        continue
                r.invalid.set()

    def authorized(self, signal):
        return self.current is not None and self.current[1] is signal

    def validate(self, signal, price):
        if not self.current or self.current[1] != signal:
            raise BotError('실시간 두 꼬리 신호 확인 필요')
        r = self.current[0]
        reason = self.blocked()
        if reason:
            raise BotError(reason)
        if r.invalid.is_set() or not signal['valid_from_ms'] <= self.engine.api.now_ms() <= signal['expires_ms']:
            raise BotError('두 번째 꼬리 이탈, 시세 단절 또는 신호 만료')
        side = r.hit['side']
        if (not math.isfinite(price) or side*(price-r.hit['second'])<=0
                or abs(price-r.hit['price'])>.5*r.hit['anchor_atr']):
            raise BotError('호가가 두 번째 꼬리의 반응 범위를 벗어남')
        return signal['decision_record']['volume_wick_proof']

    def record(self, r):
        e = self.engine
        previous = e.journal.data.get('pc_wick280_seen',{})
        if previous.get(r.key,-1)>=r.hit['anchor_ms']:
            return False
        e.journal.data['pc_wick280_seen'] = {**previous, r.key:r.hit['anchor_ms']}
        try:
            e.journal.save()
        except Exception:
            e.journal.data['pc_wick280_seen'] = previous
            raise
        return True

    def report(self, r, text):
        side = '롱' if r.hit['side']==1 else '숏'
        msg = f"[두 꼬리 자동 {side}] {r.symbol}\n{text}"
        self.engine.log(msg)
        try:
            self.engine.notifier.wick_result(msg,r.signal_id)
        except Exception:
            logging.exception('두 꼬리 자동 주문 결과 알림 보관 실패')

    def poll(self):
        """Called only on the engine worker, after position protection and manual requests."""
        e = self.engine
        with self.lock:
            batch = tuple(self.pending.values())
        for r in batch:
            if not r.announced.is_set():
                continue
            reason = r.initial_block or self.blocked()
            if not reason and (r.invalid.is_set() or e.api.now_ms() > r.hit['ts']+TTL_MS):
                reason = '두 번째 꼬리 이탈, 시세 단절 또는 신호 만료'
            if not reason and (not e.can_open_position() or r.symbol in e.blocked_manual_symbols()
                               or any(o['symbol']==r.symbol for o in e.records())):
                reason = '포지션 한도 또는 같은 종목 보유·주문 중'
            if not reason and not e.stream.ready(r.symbol,e.cfg,e.api.now_ms()):
                continue
            claimed = self.record(r)
            try:
                if not claimed or r.initial_block:
                    continue
                if reason:
                    self.report(r,'자동 미진입 · '+reason)
                    continue
                signal = make_signal(e,r)
                self.current = (r,signal)
                self.validate(signal,r.hit['price'])
                with e.selected(e.empty_slot()):
                    try:
                        e.executing_signal = signal
                        e.entry(signal)
                    finally:
                        e.executing_signal = None
                submitted = any(o.get('v4_signal',{}).get('signal_id')==r.signal_id for o in e.records())
                self.report(r,'자동 주문 접수 · 체결·손절 등록 확인 중' if submitted else '자동 미진입 · 주문 전 계정 또는 시세 상태 변경')
                return submitted  # Reconcile positions before another new submission.
            except UnknownOutcome:
                self.report(r,'자동 주문 결과 미확인 · 재주문 없이 거래소 대조 중')
                raise
            except BotError as exc:
                self.report(r,'자동 미진입 · '+str(exc))
            except Exception:
                self.report(r,'자동 처리 결과 미확인 · 거래소 대조 중')
                raise
            finally:
                self.current = None
                with self.lock:
                    self.pending.pop(r.signal_id,None)

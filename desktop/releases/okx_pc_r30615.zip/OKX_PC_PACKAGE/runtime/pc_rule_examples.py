"""Illustrated 15-minute live entries and Telegram signals."""

def inverse(bars):
    return [(120-o, 120-lo, 120-hi, 120-c) for o, hi, lo, c in bars]


def figure(example):
    side, explanation, bars, reference, levels = example
    xs = [26, 65, 104, 143, 182]
    def y(value):
        return 132 - value
    points = ' '.join(f'{x},{y(v)}' for x, v in zip(xs, levels))
    candles = []
    for x, (op, high, low, close) in zip(xs, bars):
        color = '#58d6a3' if close >= op else '#ff8793'
        candles.append(f'<g data-prices="{op},{high},{low},{close}" data-x="{x}"><path d="M{x} {y(high)}V{y(low)}" stroke="{color}" stroke-width="2"/>'
                       f'<rect x="{x-6}" y="{y(max(op,close))}" width="12" height="{max(abs(op-close),1)}" fill="{color}"/></g>')
    cy = y(bars[-1][3])
    return (f'<figure><figcaption><b>{side} 알림 예시</b> · 가상 15분봉</figcaption>'
            f'<svg role="img" aria-label="{side} 예시 차트. 점선은 {reference}, 원은 두 번째 꼬리에서 돌아선 첫 체결" viewBox="0 0 300 128">'
            f'<text x="12" y="19" fill="#a7bce3">┄ {reference}</text>'
            f'<polyline points="{points}" fill="none" stroke="#91aacd" stroke-dasharray="4 3"/>'
            + ''.join(candles) +
            f'<g class="entry-marker"><circle cx="182" cy="{cy}" r="4" fill="#101010" stroke="white" stroke-width="2"/>'
            f'<path d="M187 {cy}h18" stroke="white"/><text x="209" y="{cy+4}" fill="white">{side} 알림</text></g>'
            f'</svg><p>{explanation}</p></figure>')


# Last bar stops at the reaction trade, before the second wick candle has closed.
MANUAL_LONG = [(90,92,69,74),(74,76,51,55),(55,56,28,44),(44,48,40,46),(46,47,30,31)]
LOWER_BAND = [74,58,41,38,35]
MANUAL_EXAMPLES = [
    ('롱', '볼린저밴드 하단을 거듭 뚫으며 하락하다 거래량을 동반한 긴 아랫꼬리 음봉이 나옵니다. '
     '잠시 횡보한 뒤 첫 저점보다 높은 두 번째 저점에서 한 호가 이상 반등하는 첫 체결을 기록합니다.',
     MANUAL_LONG, '볼밴 하단', LOWER_BAND),
    ('숏', '볼린저밴드 상단을 거듭 뚫으며 상승하다 거래량을 동반한 긴 윗꼬리 양봉이 나옵니다. '
     '잠시 횡보한 뒤 첫 고점보다 낮은 두 번째 고점에서 한 호가 이상 밀리는 첫 체결을 기록합니다.',
     inverse(MANUAL_LONG), '볼밴 상단', [120-v for v in LOWER_BAND]),
]

EXAMPLE_LINK = '<strong>예시보기 <i aria-hidden="true">→</i></strong>'
REPLAY = '<button type="button" class="entry-replay">예시 다시 보기 ↻</button></details>'


# Last few example candles around the trigger, in ticks relative to 10 USDT.
# Short examples reflect these candles around the same reference level.
TRIGGER_BARS = {
    'classic': [(10,11,5,6),(7,8,0,6),(6,9,5,8),(8,8,1,2)],
    'breakout': [(-4,-1,-6,-3),(-3,0,-5,-2),(-2,-1,-4,-3),(-3,6,-4,5)],
    'retest': [(-3,0,-5,-2),(-2,6,-2,4),(4,7,2,3),(3,6,-1,5)],
    'pullback': [(-4,2,-5,1),(1,6,1,5),(5,7,2,3),(3,6,0,5)],
    'window30_reversal': [(6,8,3,4),(4,5,0,1),(-1,0,-5,-4),(-4,2,-5,1)],
}

def trigger_chart(key, short):
    bars = TRIGGER_BARS.get(key)
    if not bars:
        return ''
    parts = ['<svg class="rule-trigger" viewBox="0 0 190 70" aria-hidden="true">',
             '<path d="M5 43H180" stroke="#9299a3" stroke-dasharray="4 3"/>']
    def y(ticks):
        return 43 + ticks*2.25 if short else 43 - ticks*2.25
    for i,(op,hi,lo,cl) in enumerate(bars):
        x = 24+i*44
        color = '#60cd95' if (cl>op) != short else '#f1899d'
        parts.append(f'<path d="M{x} {y(hi)}V{y(lo)}" stroke="{color}" stroke-width="2"/>')
        parts.append(f'<rect x="{x-5}" y="{min(y(op),y(cl))}" width="10" height="{max(1,abs(y(cl)-y(op)))}" fill="{color}"/>')
    parts.append(f'<circle cx="156" cy="{y(bars[-1][3])}" r="8" fill="none" stroke="#f7ce61" stroke-width="2"/></svg>')
    return ''.join(parts)

def alert_panel():
    from pc_candidates import ACTIVE, RULES
    from pathlib import Path
    import json
    from html import escape
    from pc_hourly_relay import ENTER_TTL_SECONDS
    version = escape(json.loads((Path(__file__).resolve().parents[1]/'pc_release.json').read_text(encoding='utf-8'))['version'])
    listing = []
    for key,guide in ACTIVE.items():
        listing.append(f'<article class="rule-guide"><h4>{guide.number}번 · {RULES[key]}</h4><p>{guide.condition}</p>')
        for short,example in ((False,guide.long_example),(True,guide.short_example)):
            label = '숏' if short else '롱'
            listing.append(f'<div class="rule-case"><strong>{label} 예시</strong>{trigger_chart(key,short)}<p>{example}</p></div>')
        listing.append('</article>')
    listing = ''.join(listing)
    return ('<aside id="pcEntryAlerts" class="phone-host-notice" aria-labelledby="pcAlertHeading">'
            '<div class="pc-schedule-heading"><h2 id="pcAlertHeading">자동 진입과 알림</h2><small>PC '+version+' · 한국시간</small></div>'
            '<p>1회 목표 증거금은 총 시드에서 3 USDT를 뺀 금액의 3분의 1입니다. 격리 5배로 계약 단위에 맞춰 주문합니다. 정각·15분 신호는 발행 즉시 주문 엔진으로 전달되며 개별·합산 예상 손실률은 진입을 차단하지 않습니다.</p>'
            '<h3>매시 정각 · 채팅 신호 자동주문</h3><p id="pcHourlyStatus">정각 주문 항상 켜짐 · 실거래 가동 중에만 주문</p>'
            f'<p>발행된 종목과 방향으로 추가 봉 마감을 기다리지 않고 주문을 시도합니다. 즉시 신호는 발행 후 {ENTER_TTL_SECONDS}초 동안 지정한 가격 범위에서 유효합니다. 시간당 최대 한 번이며 실거래 상태, 호가, 계좌 한도를 확인합니다.</p>'
            '<h3>15분 텔레그램 후보 분석</h3><p>등락률 상·하위 각 5종목의 4시간·1시간 추세, 15분 지지·저항, 5분 재시험, 1분 움직임과 호가를 비교해 선정한 한 종목의 방향으로 실거래 중 즉시 주문을 시도합니다. 재시험과 예상 손익비는 후보 비교에 사용합니다. 확정봉이 늦으면 해당 종목·시간대만 최대 4회 조회합니다.</p>'
            '<button type="button" role="switch" aria-checked="false" aria-label="일목·RSI 추가 확인" id="pcWickTiming" disabled>일목·RSI 추가 확인 · 상태 확인 중</button>'
            '<p class="muted">켜면 구름·전환선·기준선이 역방향이고 RSI가 30 이하에서 더 하락하거나 70 이상에서 더 상승할 때, 첫 반응보다 진입 방향으로 1~2틱 움직인 체결을 15초 안에 확인합니다. 큰 폭으로 튄 신호는 두 번째 꼬리 재시험을 우선합니다.</p>'
            '<button type="button" role="switch" aria-checked="false" aria-label="종목 흐름에 맞춰 진입" id="pcSymbolFlow" disabled>종목 흐름에 맞춰 진입</button>'
            '<p class="muted">종목 흐름 확인이 켜진 기본 두 꼬리는 보통 속도에서 15분·마감된 1시간봉을 확인합니다. 켜면 종목 흐름과 진입 방향이 일치할 때 주문을 검토합니다. 일목·RSI 추가 확인과 함께 사용할 수 있습니다.</p>'
            '<h3>자동 진입조건표</h3><p>1·6·7·8번은 구조 손절까지 0.40% 이내, 왕복 0.20% 비용 차감 후 예상 손익비 2:1 이상이어야 합니다. 1번은 볼린저 중심선, 6·7번은 돌파선에서 이전 박스 높이만큼 연장한 가격, 8번은 직전 20봉 고가·저가로 여유를 계산합니다. 예시: 롱 100, 손절 99.70이면 기준가 101.20 이상, 숏 100, 손절 100.30이면 98.80 이하입니다. 6·7·8번은 최초 위험거리의 2배와 왕복 비용만큼 유리해진 뒤 1.5배 거리로 추적합니다. 이 기준가는 고정 익절가가 아닙니다.</p><p>아래 번호 규칙의 신규 주문은 전략·방향·시간봉별 모의 검증 후 허용합니다. 매일 한국시간 자정까지 직전 7일씩 세 구간 모두 20건 이상·3종목 이상, 결과 누락 없이 왕복 비용 0.20%와 추가 비용 0.10%를 차감한 평균이 양수여야 합니다. 예를 들어 13번 5분 롱이 통과해도 5분 숏은 따로 검증합니다. 처음에는 모의 기록만 쌓입니다.</p><p>6·7·8번은 빠른 종목은 5분봉, 보통은 15분봉을 사용합니다. 15분봉에서는 15분·1시간 추세 방향도 일치해야 합니다. 차트는 신호 전후를 확대한 가상 예시입니다. 점선은 10.00, 원은 진입 검토 시점입니다.</p>'+listing+
            '<small id="pcWickTimingFeedback" role="status"></small>'
            '<details id="pcManualWicks" name="pc-rule-examples" class="entry-example"><summary><span>'
            '<b>15분봉 두 꼬리 · PC 신호 기록</b><small>24시간 신호 · 롱·숏 자동 및 수동 진입</small>'
            '<small id="pcWickStatus">시세 수신 대기</small></span>' + EXAMPLE_LINK + '</summary>'
            '<p>롱은 긴 아랫꼬리가 나온 봉 다음 1~100번째 15분봉에서 더 높은 두 번째 저점을 찾습니다. 100번째 봉까지 포함하며 봉 시작 시각 기준 최대 25시간입니다. 숏은 첫 윗꼬리 다음 1~30번째 봉에서 재시험합니다. 허용 스프레드는 0.08%입니다. 시장가 주문의 예상 슬리피지는 기록용이며 별도 진입 한도가 없습니다. 첫 반응 폭이 두 꼬리 가격 차이와 2틱을 모두 넘으면, 최초 신호부터 15초 안에 두 번째 꼬리 1틱 이내로 돌아온 뒤 진입 방향으로 다시 움직일 때만 주문을 검토합니다. 직접 주문은 차트·포지션에서 할 수 있습니다. 새 포지션은 초기 손절과 +1R 전량 추적을 적용하고, 남은 수량은 진입한 날 한국시간 23:59부터 정리합니다.</p>'
            + ''.join(figure(item) for item in MANUAL_EXAMPLES) + REPLAY + '</aside>')

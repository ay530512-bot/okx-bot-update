// Evidence captured by the strategy and by the exchange's entry order response.
let phoneEntrySignature='',phoneEntryDeadline=0;
function phoneEntryKey(row){return [row.confirmed_ms,row.symbol,row.strategy,row.side].join('|')}
function phoneEntryItem(row,opened){
 const card=node('details',undefined,'entry-candidate');
 card.dataset.key=phoneEntryKey(row);card.open=opened;
 const heading=node('summary'),side=row.side==='LONG'?'롱':'숏';
 const name=node('strong',row.symbol.replace('-USDT-SWAP','/USDT'));
 heading.append(name,node('b',side,row.side==='LONG'?'positive':'negative'),
  node('span',row.priority+'순위 · '+row.strategy),node('span',row.stage||'전략 조건 통과','entry-stage'));
 card.append(heading);
 const prices=node('dl',undefined,'entry-prices');
 function metric(label,value){prices.append(node('dt',label),node('dd',value))}
 metric('진입 기준가',row.reference?row.reference+' USDT':'확인 중');
 if(row.touch)metric('주문 검사 당시 '+(row.side==='LONG'?'매도 1호가':'매수 1호가'),row.touch+' USDT');
 metric(row.stage?.includes('일부 체결')?'체결분 평균가':'실제 평균 체결가',
  row.fill?row.fill+' USDT':row.size?'거래소 평균가 확인 중':'—');
 card.append(prices);
 const details=node('div',undefined,'entry-evidence');
 details.append(node('p',row.regime+' · '+(row.reason||'전략 조건 통과')));
 const list=node('ul');for(const condition of row.conditions||[])list.append(node('li',condition));
 details.append(list);
 if(row.confirmed_ms)details.append(node('small',kst(row.confirmed_ms)+' KST · 15분봉 종가 확정'));
 card.append(details);
 return card;
}
function phoneRenderEntryCandidates(d){
 const feed=d.entry_candidates||{},now=Date.now();
 const expired=!!feed.period&&now>=feed.period+900000;
 const staleResult=!!d.display_ms&&now-d.display_ms>15000;
 const rows=expired?[]:feed.rows||[];
 const state=d.state||{},paused=state.user_paused||state.preview||state.live===false;
 const note=expired?'이전 신호 만료 · 다음 확정봉 스캔 대기':
  !feed.complete?(feed.scan||'확정봉 스캔 대기'):
  rows.length?(feed.scan||rows.length+'개 전략 조건 통과'):(feed.scan||'스캔 완료')+' · 진입 후보 없음';
 const status=[note.replace(/^5\.1 · /,''),staleResult?'화면 수신 지연':null,
  paused?'자동 진입 중지':state.recovering?'계정 대조 중':null].filter(Boolean).join(' · ');
 const label=$('entryCandidateStatus');
 if(label.textContent!==status)label.textContent=status;
 const recent=feed.recent&&!rows.some(row=>phoneEntryKey(row)===phoneEntryKey(feed.recent))?feed.recent:null;
 const signature=JSON.stringify([rows,recent||null]);
 phoneEntryDeadline=(!expired&&feed.period)?feed.period+900000:0;
 if(signature===phoneEntrySignature)return;
 const container=$('entryCandidateRows'),last=$('entryCandidateRecent');
 const prior=new Map(Array.from(container.children,card=>[card.dataset.key,card.open]));
 const scroll=container.scrollTop;
 const cards=document.createDocumentFragment();
 rows.forEach((row,i)=>cards.appendChild(phoneEntryItem(row,prior.get(phoneEntryKey(row))??(i===0))));
 while(container.firstChild)container.removeChild(container.firstChild);
 container.appendChild(cards);
 container.scrollTop=scroll;
 const previous=last.querySelector('details');
 while(last.firstChild)last.removeChild(last.firstChild);
 if(recent){last.append(node('h3','최근 체결 후보'),phoneEntryItem(recent,
  previous?.dataset.key===phoneEntryKey(recent)?previous.open:!rows.length))}
 phoneEntrySignature=signature;
}
function phoneExpireEntryCandidates(d){
 if((phoneEntryDeadline&&Date.now()>=phoneEntryDeadline)||(d.display_ms&&Date.now()-d.display_ms>15000)){
  phoneRenderEntryCandidates(d);
 }
}

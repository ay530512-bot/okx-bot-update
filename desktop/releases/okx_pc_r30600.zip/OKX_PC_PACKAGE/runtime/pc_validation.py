"""Persistent prospective candle replay for new automated orders only."""
import logging
import sqlite3
import threading
from pathlib import Path

FIVE = 300_000
DAY = 86_400_000
COST = .002
STRESS = .001


def qualifies(rows, now):
    midnight = (now + 9 * 3_600_000) // DAY * DAY - 9 * 3_600_000
    for week in range(3):
        end = midnight - week * 7 * DAY
        sample = [(value, symbol) for at, value, symbol in rows if end - 7 * DAY <= at < end]
        if len(sample) < 20 or len({symbol for _, symbol in sample}) < 3:
            return False
        if any(value is None for value, _ in sample):
            return False
        if sum(value - STRESS for value, _ in sample) <= 0:
            return False
    return True


class Validation:
    def __init__(self, root):
        self.lock = threading.Lock()
        self.status = '모의 검증 대기'
        self.active = set()
        self.db = None
        try:
            db = sqlite3.connect(Path(root) / 'pc_forward_v360.sqlite', check_same_thread=False)
            db.executescript("""
                CREATE TABLE IF NOT EXISTS samples(
                    id TEXT PRIMARY KEY, cohort TEXT, symbol TEXT, side INTEGER,
                    entry REAL, initial REAL, stop REAL, next INTEGER, deadline INTEGER,
                    short_hold INTEGER, bars INTEGER DEFAULT 0, ended INTEGER, net REAL);
                CREATE UNIQUE INDEX IF NOT EXISTS pending ON samples(cohort,symbol) WHERE ended IS NULL;
                CREATE INDEX IF NOT EXISTS history ON samples(cohort,ended);
            """)
            self.active.update(r[0] for r in db.execute('SELECT DISTINCT symbol FROM samples WHERE ended IS NULL'))
            self.db = db
        except (OSError, sqlite3.Error):
            self.status = '검증 장부 열기 실패 · 신규 자동 주문 보류'
            logging.exception('모의 검증 장부 열기 실패')

    def admit(self, rule, signal, now):
        from pc_intraday import session_close_ms
        if self.db is None:
            return False
        symbol, side = signal['symbol'], 1 if signal['action']=='LONG' else -1
        cohort = '|'.join((rule,signal['setup_frame'],signal['action']))
        entry, stop = signal['entry_reference'], signal['stop']
        if not (0 < side*(entry-stop)/entry <= .008-COST):
            return False
        bucket = now // FIVE * FIVE
        try:
            with self.lock, self.db:
                self.db.execute("UPDATE samples SET ended=next+?,net=NULL WHERE ended IS NULL AND next+?<?",
                                (FIVE,FIVE+60_000,now))
                history = self.db.execute('SELECT ended,net,symbol FROM samples WHERE cohort=? AND ended>=?',
                                          (cohort,now-22*DAY)).fetchall()
                saved = self.db.execute("""INSERT OR IGNORE INTO samples
                    (id,cohort,symbol,side,entry,initial,stop,next,deadline,short_hold)
                    VALUES(?,?,?,?,?,?,?,?,?,?)""",(signal['signal_id'],cohort,symbol,side,
                    entry,stop,stop,bucket,session_close_ms(now),int(rule=='five_reversal15')))
                if saved.rowcount != 1:
                    return False
                self.active.add(symbol)
                allowed = qualifies(history,now)
                from pc_candidates import ACTIVE
                self.status = f'{ACTIVE[rule].number}번 {signal["setup_frame"]} {("롱" if side==1 else "숏")} · '+('실주문 기준 통과' if allowed else '모의 검증 중')
                return allowed
        except sqlite3.Error:
            logging.exception('모의 검증 기록 실패')
            return False

    def bar(self, symbol, row):
        if symbol not in self.active or self.db is None:
            return
        at, opening, high, low, close = row[:5]
        end = at + FIVE
        try:
            with self.lock, self.db:
                pending = self.db.execute("""SELECT id,side,entry,initial,stop,next,deadline,short_hold,bars
                    FROM samples WHERE symbol=? AND ended IS NULL""",(symbol,)).fetchall()
                for key,side,entry,initial,stop,expected,deadline,short_hold,bars in pending:
                    if at < expected:
                        continue
                    net = None
                    if at == expected:
                        # The first bar may include pre-signal prices. Count a touched stop conservatively.
                        hit = low <= stop if side==1 else high >= stop
                        price = (min(stop,opening) if side==1 else max(stop,opening)) if hit else close
                        net = side*(price-entry)/entry-COST
                        if not (hit or end>=deadline or short_hold and (net>0 or bars>=1)):
                            risk = abs(entry-initial)
                            if not short_hold and side*(close-entry)>=risk:
                                stop = max(stop,close-risk) if side==1 else min(stop,close+risk)
                            self.db.execute('UPDATE samples SET next=?,stop=?,bars=bars+1 WHERE id=?',(end,stop,key))
                            continue
                    self.db.execute('UPDATE samples SET ended=?,net=? WHERE id=?',(end,net,key))
                if not self.db.execute('SELECT 1 FROM samples WHERE symbol=? AND ended IS NULL LIMIT 1',(symbol,)).fetchone():
                    self.active.discard(symbol)
        except sqlite3.Error:
            logging.exception('모의 봉 처리 실패')

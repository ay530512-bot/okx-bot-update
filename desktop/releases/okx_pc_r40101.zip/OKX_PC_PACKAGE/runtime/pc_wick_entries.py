"""Route the live 15m two-wick reaction to Telegram and the serialized PC order engine."""
from dataclasses import dataclass, field
import logging
import math
import threading

from okx_core import BotError, UnknownOutcome
from okx_entry_gate720 import gate
from okx_pattern15 import band, summary
from pc_candidates import ACTIVE, RULES, NEW, REVERSAL, rule_id, switch_key
from pc_extra_entries import SHORT, TREND, trend_side, morning
from pc_sizing import indicator_level, SLOTS, indicators, leverage_for, round_stop
from pc_wick_alert import STEP, alert_text, retest_window
from pc_wick_chart import price_text, snapshot

ROUTE = 'bb_wick_retest_15m'
TTL_MS = 15_000
FAST_STEP = 300_000


@dataclass
class Reaction:
    symbol: str
    hit: dict
    tick: str
    bars: tuple
    initial_block: str
    chart: dict = field(init=False)
    invalid: threading.Event = field(default_factory=threading.Event)
    announced: threading.Event = field(default_factory=threading.Event)

    def __post_init__(self):
        self.chart = snapshot(self.symbol, self.hit, self.tick, self.bars)
        side = self.hit['side']
        if self.hit.get('closed_signal'):
            self.chart['strategy_label']=RULES[self.hit['variant']]
        self.chart['side'] = self.hit.get('entry_side',side)

    @property
    def interval(self):
        return self.hit.get('step_ms',STEP)

    @property
    def timing_label(self):
        return RULES.get(self.hit.get('variant'), '두 번째 꼬리의 첫 반응 체결')

    @property
    def entry_chart(self):
        return self.chart

    @property
    def expires_ms(self):
        start = self.hit['ts']
        if self.hit.get('variant') == REVERSAL:
            return self.hit['trigger_ms'] + FAST_STEP - 1
        return self.hit.get('trigger_ms', start) + TTL_MS

    @property
    def key(self):
        if self.hit.get("variant") == "window30_reversal":
            return f"{self.symbol}/{self.hit['side']}/window30_reversal/{self.interval}"
        if self.hit.get('variant'):
            return f"{self.symbol}/{self.hit['side']}/{self.hit['variant']}"
        if self.interval==FAST_STEP:
            return self.symbol + ('/long/flow5' if self.hit['side']==1 else '/short/flow5')
        return self.symbol + ('/long' if self.hit['side'] == 1 else '/short') + ('/swing' if 'neckline' in self.hit else '')

    @property
    def signal_id(self):
        return f"wick280-{self.key}-{self.hit.get('last_pivot_ms',self.hit['anchor_ms'])}"


def entry_distances(reaction, hit=None):
    """Observable at the reaction print, including signals later rejected by the order gate."""
    if len(reaction.bars) < 20:
        return None
    hit = reaction.hit if hit is None else hit
    if reaction.bars[-1][0] != hit['ts']//reaction.interval*reaction.interval - reaction.interval:
        return None
    side, price, tick = hit['side'], hit['price'], float(reaction.tick)
    mid = sum(row[4] for row in reaction.bars[-20:])/20
    stop = round_stop(hit['second' if 'neckline' in hit else 'first'] - side*max(2*tick, .15*hit['anchor_atr']),tick,side)
    return dict(mid=mid, stop=stop, room_pct=100*side*(mid-price)/price,
                risk_pct=100*side*(price-stop)/price)


def make_signal(engine, reaction):
    from phone_trend_slot import permitted
    hit, bars, symbol = reaction.hit, reaction.bars, reaction.symbol
    side, price, first, second = (hit[k] for k in ('side','price','first','second'))
    tick, atr = float(reaction.tick), hit['anchor_atr']
    now = engine.api.now_ms()
    expires = reaction.expires_ms
    swing = 'neckline' in hit
    interval=reaction.interval
    bucket = hit['ts']//interval*interval
    timing_ok = (1 <= (bucket-hit['anchor_ms'])//STEP <= retest_window(side) and side*(second-first)>0)
    if interval==FAST_STEP:
        flow=hit.get('symbol_flow',{})
        timing_ok=(hit.get('complete_trade_feed') and
                   flow.get('pace')=='fast' and flow.get('side')==side and
                   hit['trigger_ms']==bucket and 1 <= (bucket-hit['anchor_ms'])//interval <= 15 and
                   side*(second-first)>=0 and abs(price-hit['trigger_close'])<=.5*atr)
    variant=hit.get('variant')
    if variant in NEW:
        timing_ok=hit.get('closed_signal') and hit['trigger_ms']==bucket and hit['anchor_ms']==bucket-interval
    if variant==SHORT:
        timing_ok=(interval==FAST_STEP and side==-1 and morning(now) and
                   1<=(bucket-hit['anchor_ms'])//interval<=30 and second<first)
    if swing:
        timing_ok = (1 <= (hit['last_pivot_ms']-hit['anchor_ms'])//STEP <= retest_window(side)
                     and 1 <= (bucket-hit['last_pivot_ms'])//STEP <= retest_window(side)
                     and side*(price-hit['neckline'])>=tick*.999999)
    if not (hit['ts'] <= now <= expires and bars and
            bars[-1][0] == bucket-interval and
            side in (-1,1) and
            timing_ok and
            min(price, first, second, tick, atr)>0 and
            side*(price-second)>0):
        raise BotError('두 꼬리 반응 체결 또는 완료봉 확인 시간 만료')
    instrument = engine.api.public('/api/v5/public/instruments', instType='SWAP', instId=symbol)[0]
    if (instrument.get('instId') != symbol or not permitted(dict(symbol=symbol,instrument=instrument),engine.cfg)
            or float(instrument['tickSz']) != tick):
        raise BotError('허용 종목 또는 호가 단위 변경')
    stop = round_stop((second if swing else first)-side*max(2*tick,.15*atr),tick,side)
    original_stop=stop
    original_leverage=0
    if variant==TREND:
        original=indicators(bars,side,atr)
        if original:
            original_leverage=leverage_for(dict(original,stop=stop),price,float(instrument.get('lever') or 0))
        side=trend_side(bars)
        if not original_leverage or not side or side!=hit.get('entry_side'):
            raise BotError('원 신호 위험 한도 또는 추세 합의 미충족')
        stop=round_stop(price*(1-side*.01),tick,side)
    elif variant==SHORT:
        stop=round_stop(first+max(2*tick,.075*atr),tick,-1)
    ev = indicators(bars,side,atr)
    if not ev or not 0<stop or side*(price-stop)<=0:
        raise BotError('배율·첫 꼬리 손절 계산 자료 부족')
    ev['stop'] = stop
    maximum = float(instrument.get('lever') or 0)
    if maximum<5:
        raise BotError('거래소 5배 진입 불가')
    leverage=5
    action = 'LONG' if side == 1 else 'SHORT'
    frame = summary(bars)
    lo,mid,hi = band(bars,len(bars)-1)
    route = 'symbol_flow_retest_5m' if interval==FAST_STEP else ROUTE
    route=variant or route
    label = '5m' if interval==FAST_STEP else '15m'
    proof = dict(route721=route,symbol_flow=hit.get('symbol_flow'), action=action, first_wick=first, second_wick=second,
                 anchor_ms=hit['anchor_ms'], reaction_ms=hit['ts'], trade_id=hit['trade_id'],
                 reference=price, structural_stop=stop, original_stop=original_stop, original_side=hit['side'], tick=tick, atr=atr, sizing_indicators=ev,
                 market_context=reaction.entry_chart['market_context'],
                 initial_market_context=reaction.chart['market_context'],
                 indicator_mode="immediate", timing_label=reaction.timing_label,
                 first_reaction_ms=reaction.hit['ts'], first_reaction_price=reaction.hit['price'],
                 retest_confirmed=False,
                 follow_confirmed=False,
                 timing_distances=entry_distances(reaction,hit))
    if swing:
        proof.update(neckline=hit['neckline'],last_pivot_ms=hit['last_pivot_ms'])
    from pc_reward_risk import RULES as reward_rules, objective
    rule = rule_id(hit)
    if rule in reward_rules:
        proof['room_target'] = objective(rule,side,bars,hit['second'])
    return dict(symbol=symbol,action=action,reward_policy362=rule if rule in reward_rules else None,pc217=variant,pc_wick280=True,pc260=True,rule_channel701=True,
                free_ai=True,pattern15=True,strategy='band_flow',pattern=route,
                leverage=leverage,indicator_limit=maximum,margin_fraction=1/3,
                reason=(label+' 마감 · ' if variant in NEW else '5분봉 재시험 · ' if interval==FAST_STEP else '15분봉 세 스윙 돌파 · ' if swing else '15분봉 볼린저밴드 두 꼬리 · ')+reaction.timing_label,
                regime=RULES[variant] if variant in NEW else '두 꼬리 반전',ma=frame['ma'],bb=dict(lower=lo,mid=mid,upper=hi),
                rsi={label:frame['rsi14']},atr=atr,level=stop,stop=stop,target=None,retest=True,
                adaptive=False,setup_frame=label,execution_frame=label,signal_id=reaction.signal_id,
                at_ms=hit['ts'],valid_from_ms=hit['ts'],expires_ms=expires,
                entry_reference=price,entry_gap=price,selection=dict(activity={},asset_category='1',origin=route),
                holding_rule=dict(frame=label,zone=stop,target=None,target_mode='trailing_only',
                                  partial=False,rule_channel701=True,pattern15=True),
                decision_record=dict(source=route,frames={label:{'analysis':frame}},volume_wick_proof=proof))


class WickEntries:
    def __init__(self, engine):
        from pc_validation import Validation
        self.validation = Validation(engine.root)
        self.engine = engine
        self.lock = threading.Lock()
        self.pending = {}
        self.warm = frozenset()
        self.current = None
        self.mode = "immediate"
        self.seen = dict(engine.journal.data.get('pc_wick280_seen',{}))
        # A 2.7.0 alert may already have been acted on manually before the update.
        for key, stamp in engine.notifier.data.get('wick_15m_seen',{}).items():
            self.seen[key] = max(stamp,self.seen.get(key,-1))

    @property
    def disabled_rules(self):
        return [key for key in RULES if key not in ACTIVE]

    def change_rule(self,key):
        raise BotError('모든 진입 전략이 항상 활성화됩니다.')

    def set_mode(self, mode):
        raise BotError('현재 활성 규칙은 신호 발생 즉시 자동 주문합니다.')

    def blocked(self):
        e = self.engine
        if e.stop_event.is_set():
            return '프로그램 종료 중'
        if getattr(getattr(e,'pc_updater',None),'installing',False):
            return 'PC 업데이트 설치 중'
        state = gate(e)
        return '' if state['allowed'] else state['reason']

    def offer(self, symbol, hit, tick, bars):
        if rule_id(hit) in ACTIVE:
            return self._offer(symbol,hit,tick,bars)

    def _offer(self,symbol,hit,tick,bars):
        from pc_intraday import session_close_ms, ENTRY_CLOSED
        if rule_id(hit) not in ACTIVE:
            return
        block = self.blocked()
        if self.engine.api.now_ms() >= session_close_ms(hit['ts']):
            block = block or ENTRY_CLOSED
        fast=hit.get('step_ms')==FAST_STEP
        flow=hit.get('symbol_flow',{})
        reaction = Reaction(symbol, dict(hit), tick, bars, block)
        with self.lock:
            if self.seen.get(reaction.key,-1) >= hit.get('last_pivot_ms',hit['anchor_ms']):
                return
            self.seen[reaction.key] = hit.get('last_pivot_ms',hit['anchor_ms'])
            self.pending[reaction.signal_id] = reaction
        reaction.announced.set()
        self.engine.command_wake.set()
        if reaction.initial_block:
            note = '자동 미진입 · '+reaction.initial_block
        else:
            note = '실거래 자동 주문 요청'
        msg = alert_text(symbol,hit,tick)
        if hit.get('variant'):
            action='롱' if hit.get('entry_side',hit['side'])==1 else '숏'
            msg=f"[{RULES[hit['variant']]} · 주문 방향 {action}] {symbol}\n반응가 {price_text(hit['price'],tick)}"
        if flow:
            from pc_flow_watch import flow_text
            msg += '\n'+flow_text(flow)
        distances = entry_distances(reaction)
        if distances and not hit.get('variant'):
            msg += (f"\n진입 방향으로 볼밴 중심선까지 {distances['room_pct']:+.2f}%"
                    f" · 첫 손절까지 {distances['risk_pct']:.2f}%")
        msg += '\n'+note
        try:
            if fast or hit.get('variant'):
                self.engine.notifier.wick_result(msg,'flow5-candidate-'+reaction.signal_id,chart=reaction.chart)
            else:
                self.engine.notifier.wick_alert(symbol,hit['side'],hit['anchor_ms'],hit['ts'],msg,chart=reaction.chart)
        except Exception:
            logging.exception('두 꼬리 신호 알림 보관 실패')
        try:
            self.engine.log(msg)
        except OSError:
            logging.exception('두 꼬리 신호의 최근 활동 저장 실패')
        return reaction

    def quote_symbols(self):
        with self.lock:
            return {r.symbol for r in self.pending.values() if not r.initial_block}

    def invalidate(self, symbol=None, *, ts=None, low=None, high=None, trade_id=None, trade_bar=None, candle_step=None):
        with self.lock:
            for r in self.pending.values():
                if candle_step is not None and candle_step != r.interval:
                    continue
                if symbol is not None and symbol != r.symbol:
                    continue
                if ts is not None:
                    if ts < r.hit['ts']:
                        continue
                    # The confirmed entry is invalidated if its protective structure breaks.
                    if r.hit['side']*((low if r.hit['side']==1 else high)-r.hit['first']) >= 0:
                        continue
                r.invalid.set()

    def authorized(self, signal):
        return self.current is not None and self.current[1] is signal

    def validate(self, signal, price):
        if not self.current or self.current[1] != signal:
            raise BotError('실시간 두 꼬리 신호 확인 필요')
        r = self.current[0]
        if rule_id(r.hit) not in ACTIVE:
            raise BotError('사용자가 끈 진입 규칙')
        reason = self.blocked()
        if reason:
            raise BotError(reason)
        if r.invalid.is_set() or not signal['valid_from_ms'] <= self.engine.api.now_ms() <= signal['expires_ms']:
            raise BotError('두 번째 꼬리 이탈, 시세 단절 또는 신호 만료')
        side = 1 if signal['action'] == 'LONG' else -1
        if not math.isfinite(price) or price <= 0 or side*(price-signal['stop']) <= 0:
            raise BotError('주문 호가가 보호 손절가를 벗어났습니다.')
        return signal['decision_record']['volume_wick_proof']

    def record(self, r):
        e = self.engine
        previous = e.journal.data.get('pc_wick280_seen',{})
        if previous.get(r.key,-1)>=r.hit.get('last_pivot_ms',r.hit['anchor_ms']):
            return False
        e.journal.data['pc_wick280_seen'] = {**previous, r.key:r.hit.get('last_pivot_ms',r.hit['anchor_ms'])}
        try:
            e.journal.save()
        except Exception:
            e.journal.data['pc_wick280_seen'] = previous
            raise
        return True

    def report(self, r, text):
        side = '롱' if r.hit.get('entry_side',r.hit['side'])==1 else '숏'
        label = '5분 재시험' if r.interval==FAST_STEP else '스윙 돌파' if 'neckline' in r.hit else '두 꼬리'
        label=RULES.get(r.hit.get('variant'),label)
        msg = f"[{label} 자동 {side}] {r.symbol}\n{text}"
        if r.hit.get('symbol_flow'):
            from pc_flow_watch import flow_text
            msg+='\n'+flow_text(r.hit['symbol_flow'])
        try:
            self.engine.log(msg)
        except OSError:
            logging.exception('두 꼬리 자동 주문 결과의 최근 활동 저장 실패')
        try:
            self.engine.notifier.wick_result(msg,r.signal_id,chart=r.entry_chart)
        except Exception:
            logging.exception('두 꼬리 자동 주문 결과 알림 보관 실패')

    def poll(self):
        """Called only on the engine worker, after position protection and manual requests."""
        e = self.engine
        with self.lock:
            batch = sorted(self.pending.values(),key=lambda r:r.hit.get('variant') in NEW)
        for r in batch:
            if not r.announced.is_set():
                continue
            reason = r.initial_block or self.blocked()
            if not reason and r.invalid.is_set():
                reason = ('돌파선 이탈 또는 시세 단절' if r.hit.get('variant') == REVERSAL
                          else '두 번째 꼬리 이탈, 시세 단절 또는 신호 만료')
            if not reason and e.api.now_ms() > r.expires_ms:
                if r.hit.get('variant') == REVERSAL:
                    reason = '반전 돌파 후 다음 5분봉 마감 · 진입 기회 종료'
                elif r.interval==FAST_STEP:
                    reason = '5분 재시험 마감 후 15초 만료'
                else:
                    reason = '진입 신호 유효시간 만료'
            if not reason and (not e.can_open_position() or r.symbol in e.blocked_manual_symbols()
                               or any(o['symbol']==r.symbol for o in e.records())):
                reason = '포지션 한도 또는 같은 종목 보유·주문 중'
            if not reason and not e.stream.ready(r.symbol,e.cfg,e.api.now_ms()):
                continue
            entry_price = r.hit['price']
            claimed = self.record(r)
            try:
                if not claimed or r.initial_block:
                    continue
                if reason:
                    self.report(r,'자동 미진입 · '+reason)
                    continue
                signal = make_signal(e,r)
                self.current = (r,signal)
                self.validate(signal,entry_price)
                observed_ms = e.api.now_ms()
                with e.selected(e.empty_slot()):
                    try:
                        e.executing_signal = signal
                        e.entry(signal)
                    finally:
                        e.executing_signal = None
                submitted = any(o.get('v4_signal',{}).get('signal_id')==r.signal_id for o in e.records())
                if submitted:
                    with self.lock:
                        for other in self.pending.values():
                            if (other is not r and other.symbol==r.symbol
                                    and (other.hit.get('variant') or r.hit.get('variant'))
                                    and other.hit['ts']==r.hit['ts']):
                                other.invalid.set()
                self.report(r,'자동 주문 접수 · 체결·손절 등록 확인 중' if submitted else '자동 미진입 · 주문 전 계정 또는 시세 상태 변경')
                try:
                    self.validation.observe(rule_id(r.hit),signal,observed_ms)
                except Exception:
                    logging.exception('주문 처리 후 모의 관찰 저장 실패')
                return submitted  # Reconcile positions before another new submission.
            except UnknownOutcome:
                self.report(r,'자동 주문 결과 미확인 · 재주문 없이 거래소 대조 중')
                raise
            except BotError as exc:
                self.report(r,'자동 미진입 · '+str(exc))
            except Exception:
                self.report(r,'자동 처리 결과 미확인 · 거래소 대조 중')
                raise
            finally:
                self.current = None
                with self.lock:
                    self.pending.pop(r.signal_id,None)

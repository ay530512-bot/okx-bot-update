"""Read-only quarter-hour OKX market comparison for Telegram."""
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from pc_hourly_relay import validate_prices
import logging
import math
import statistics
import threading
import time
from datetime import datetime, timedelta, timezone

from okx_oct23 import allowed

FRAMES = {'1m': 1, '5m': 5, '15m': 15, '1H': 60, '4H': 240}
KST = timezone(timedelta(hours=9))
QUARTER = 900


def stamp(seconds):
    return datetime.fromtimestamp(seconds, KST).strftime('%m-%d %H:%M:%S')


def candidates(instruments, ticks, cfg, now):
    ranks = []
    contracts = {i['instId']: i for i in instruments if allowed(i, cfg)}
    for row in ticks:
        symbol = row['instId']
        if symbol in contracts and float(row['open24h'] or 0) > 0:
            if abs(now - int(row['ts'])) > 90000:
                raise ValueError('등락률 시세 지연')
            change = float(row['last']) / float(row['open24h']) - 1
            ranks.append((change, symbol))
    ranks.sort()
    if len(ranks) < 10:
        raise ValueError('순위 자료 부족')
    return [contracts[symbol] for _, symbol in ranks[:5] + ranks[-5:]]


def bars(data, minutes, cutoff):
    step = minutes * 60000
    rows = sorted((int(r[0]), *map(float,r[1:5])) for r in data
                  if r[8]=='1' and int(r[0])+step <= cutoff)
    if len(rows)<20 or rows[-1][0] != cutoff//step*step-step or any(
            b[0]-a[0]!=step for a,b in zip(rows[-20:-1],rows[-19:])):
        raise ValueError(f'확정봉 {len(rows)}개 · 최근 마감 {stamp((rows[-1][0]+step)/1000) if rows else chr(45)} · 필요한 마감 {stamp((cutoff//step*step)/1000)}')
    return rows[-20:]


def evaluate(instrument, frames, book):
    bids, asks = book['bids'], book['asks']
    bid, ask = float(bids[0][0]), float(asks[0][0])
    if not 0 < bid <= ask:
        raise ValueError('호가 오류')
    mid = (ask+bid)/2
    spread = (ask-bid)/mid
    if not all(any(float(level[1]) > 0 for level in levels) for levels in (bids, asks)):
        return None
    five = frames['5m']
    quarter = frames['15m']
    tick = float(instrument['tickSz'])
    typical = max(tick, statistics.median(r[2]-r[3] for r in five[-12:]))
    tolerance = max(2*tick, typical*.3)
    options = []
    for side in (1,-1):
        # Mirror prices so support, breakout and risk use identical logic for shorts.
        def oriented(rows):
            return [(side*r[1], max(side*r[2], side*r[3]), min(side*r[2],side*r[3]),side*r[4]) for r in rows]
        live = side*(ask if side==1 else bid)
        structures = []
        for frame in ('4H','1H'):
            series = oriented(frames[frame])
            early, late = series[-6:-3], series[-3:]
            structures.append(sum(int(b>a)-int(b<a) for a,b in (
                (max(r[1] for r in early),max(r[1] for r in late)),
                (min(r[2] for r in early),min(r[2] for r in late)),
                (early[-1][3],late[-1][3]))))
        q = oriented(quarter)
        recent = oriented(five)
        # Only older candles define the level tested by the completed five-minute bar.
        history = q[:-1]
        lows = [r[2] for r in history]
        highs = [r[1] for r in history]
        levels = []
        for index, level in enumerate(lows):
            repeated = any(abs(level-other)<=tolerance and abs(index-j)>=2 for j,other in enumerate(lows))
            if repeated and level<=live+tolerance and q[-1][3]>=level-tolerance:
                levels.append(level)
        broken = [level for level in highs if q[-2][3]<=level<q[-1][3] and level<=live+tolerance]
        if broken: levels.extend(broken)
        established = bool(levels)
        level = max(levels) if levels else min(lows[-5:])
        tested = recent[-1]
        confirmed = (level-tolerance<=tested[2]<=level+tolerance and tested[3]>max(level,tested[0])
                     and (level not in broken or five[-1][0]>=quarter[-1][0]+900000))
        entry = level+tolerance
        stop = min(level-tolerance, tested[2] if confirmed else level)-max(tick,.35*typical)
        obstacles = [h for h in highs if h>entry+tolerance]
        target = min(obstacles)-tick if obstacles else entry+2*(entry-stop)
        risk = entry-stop
        cost = abs(entry)*.002
        rr = (target-entry-cost)/(risk+cost)
        minute = oriented(frames['1m'])
        near = abs(live-entry)<=tolerance and live>level and abs(live-minute[-1][3])<=typical*.5
        aligned = min(structures)>=0 and sum(structures)>=2
        ready = established and confirmed and near and aligned and rr>=1.5
        score = (ready, sum(structures)+min(3,max(-2,rr))+int(established)+int(confirmed)
                 -min(4,abs(live-entry)/typical)-min(2,spread*1000))
        unit = Decimal(instrument['tickSz']).normalize()
        def tick_price(value, rounding):
            ticks = (value / unit).to_integral_value(rounding=rounding)
            return format(ticks * unit, 'f')
        def price(x):
            return tick_price(Decimal(str(side*x)), 'ROUND_HALF_EVEN')
        if not stop < live < target: continue
        live_cost=abs(live)*.002
        live_rr=(target-live-live_cost)/(live-stop+live_cost)
        msg = (f"{instrument['instId']} {'롱' if side==1 else '숏'} 우세 · "
               f"즉시 주문 신호\n{stamp(int(book['ts'])/1000)} KST · 호가 {price(live)}\n"
               f"15분 기준선 {price(level)} · 주문 기준 호가 {price(live)}\n"
               f"손절 {price(stop)} · 전량 목표 {price(target)}{' (가격 투영)' if not obstacles else ''} · 왕복 비용 0.20% 가정 손익비 {live_rr:.2f}:1\n"
               f"4H·1H 방향 점수 {structures[0]:+d}/{structures[1]:+d} · 15분 기준 {'확인' if established else '미확인'} · 5분 재시험 {'확인' if confirmed else '대기'} · 1분·현재가 {'범위 내' if near else '대기'}\n"
               f"호가차 {spread:.3%}")
        window = min(abs(live)*.0005, (live-stop)/2, (target-live)/2)
        if window <= 0:
            continue
        actual = Decimal(asks[0][0] if side == 1 else bids[0][0])
        radius = Decimal(str(window))
        plan = dict(symbol=instrument['instId'], side='LONG' if side==1 else 'SHORT',
                    issued=int(book['ts']), mode='enter',
                    low=tick_price(actual-radius, ROUND_CEILING),
                    high=tick_price(actual+radius, ROUND_FLOOR),
                    stop=price(stop), target=price(target))
        try:
            validate_prices(plan)
        except ValueError:
            continue
        options.append((score,msg,plan))
    return max(options, key=lambda item:item[0]) if options else None


def report(session, cfg, slot):
    def get(path, **params):
        for attempt in range(2):
            r=session.get('https://www.okx.com/api/v5/'+path,params=params,timeout=(4,6))
            if r.status_code==429 and not attempt:
                time.sleep(1)
                continue
            r.raise_for_status()
            data=r.json()
            if data['code']!='0': raise ValueError('OKX 자료 요청 실패')
            return data['data']
    instruments=get('public/instruments',instType='SWAP')
    ticks=get('market/tickers',instType='SWAP')
    chosen=candidates(instruments,ticks,cfg,time.time()*1000)
    history={}
    pending = [(i['instId'], f, minutes) for i in chosen for f, minutes in FRAMES.items()]
    for attempt in range(4):
        missing = []
        for symbol, f, minutes in pending:
            try:
                cutoff = slot * 1000
                # Pin the history window so retries cannot drift past the scheduled close.
                data = get('market/candles', instId=symbol, bar=f, after=cutoff, limit=32)
                history.setdefault(symbol, {})[f] = bars(data, minutes, cutoff)
            except (ValueError, OSError) as exc:
                missing.append((symbol, f, minutes))
                detail = f'{symbol} {f} · {exc}'
            time.sleep(.12)
        if not missing:
            break
        pending = missing
        if attempt < 3:
            time.sleep(5 * (attempt + 1))
    else:
        raise ValueError(f'{detail} · 4회 조회 후 {len(pending)}개 시간대 미확인')
    options=[]
    for i in chosen:
        book=get('market/books',instId=i['instId'],sz=50)[0]
        if abs(time.time()*1000-int(book['ts']))>10000: raise ValueError('호가 지연')
        options.append(evaluate(i,history[i['instId']],book))
    valid = [item for item in options if item]
    if not valid: raise ValueError('현재 호가에서 유효한 손절·목표·유동성 조합 없음')
    _,msg,plan = max(valid,key=lambda item:item[0])
    plan.update(quarter=slot*1000,hour=slot//3600*3600000)
    return msg,plan


def start(notifier,cfg,relay):
    def run():
        import requests
        with requests.Session() as session:
            while not notifier.stop_event.is_set():
                slot=int(time.time())//QUARTER*QUARTER
                key=str(slot)
                if time.time()-slot<180 and notifier.data['states'].get('15분 후보',{}).get('value')!=key:
                    try:
                        if notifier.stop_event.wait(2): return
                        msg,plan=report(session,cfg,slot)
                        if not 0 <= relay.e.api.now_ms()-plan['issued'] <= 10000:
                            raise ValueError('선정 호가 지연')
                        relay.quarter_offer=plan
                        relay.e.command_wake.set()
                    except Exception as exc:
                        logging.warning('15분 후보 시세 확인 실패: %s',exc)
                        msg='데이터 확인 불가 · '+(str(exc)[:100] if isinstance(exc,ValueError) else 'OKX 공개 시세 통신 실패')
                    if notifier.enabled and time.time()<slot+QUARTER and not notifier.stop_event.is_set():
                        try:
                            notifier._enqueue('15분 후보',f'[OKX 15분 분석] {stamp(slot)} KST\n'+msg,key)
                        except OSError:
                            logging.exception('15분 분석 저장 실패')
                notifier.stop_event.wait(max(1,slot+QUARTER-time.time()))
    threading.Thread(target=run,daemon=True,name='quarter-pick').start()

"""Public hourly analysis feed. Only the serial engine may submit orders."""
import logging
import re
import threading
import time

from okx_core import BotError, UnknownOutcome

ENTER_TTL_SECONDS = 90
HOUR = 3600000
BASE = 'https://raw.githubusercontent.com/ay530512-bot/okx-bot-update/main/desktop/hourly/'
FIELDS = {'open':1,'high':2,'low':3,'close':4}
MINUTES = {'1m':1,'5m':5,'15m':15}


def price(x):
    if not isinstance(x,str) or not re.fullmatch(r'[0-9]{1,16}(?:\.[0-9]{1,16})?',x) or float(x)<=0:
        raise ValueError('가격 형식 오류')
    return float(x)


def validate_prices(p):
    lo,hi,stop,tp=map(price,(p['low'],p['high'],p['stop'],p['target']))
    if not (stop<lo<=hi<tp if p['side']=='LONG' else tp<lo<=hi<stop):
        raise ValueError('정각 신호 가격 순서 오류')


def validate(p, now):
    slot = now//HOUR*HOUR
    if (p['v']!=1 or p['hour']!=slot or type(p['issued'])!=int
            or not slot<=p['issued']<=now<slot+HOUR or p['side'] not in ('LONG','SHORT')
            or not re.fullmatch('[A-Z0-9]+-USDT-SWAP',p['symbol'])
            or p['symbol'].split('-')[0] in ('BTC','ETH','SOL')):
        raise ValueError('정각 신호 종목·시간·방향 오류')
    validate_prices(p)
    steps=p['steps']
    if not isinstance(steps,list) or len(steps)>4 or p['mode']!=('conditional' if steps else 'enter'):
        raise ValueError('정각 신호 진입 방식 오류')
    for frame,tests in steps:
        if frame not in MINUTES or not 1<=len(tests)<=6:raise ValueError('확정봉 조건 오류')
        for field,op,x in tests:
            if field not in FIELDS or op not in ('ge','le','gt','lt'):raise ValueError('봉 비교 오류')
            price(x)


def matches(steps, frames, issued, now):
    after=issued
    for frame,tests in steps:
        for r in sorted(frames[frame],key=lambda v:int(v[0])):
            t=int(r[0]);end=t+MINUTES[frame]*60000
            if r[8]!='1' or t<after or end>now:continue
            def passed(test):
                field,op,x=test
                v=float(r[FIELDS[field]]);bound=price(x)
                return {'ge':v>=bound,'le':v<=bound,'gt':v>bound,'lt':v<bound}[op]
            if all(map(passed,tests)):
                after=end
                break
        else:return False
    return True


class Relay:
    def __init__(self,e):
        self.e=e
        self.offer=None
        self.current=None
        self.quarter_offer=None

    def run(self):
        import requests
        e=self.e
        with requests.Session() as session:
            plan=None
            while not e.stop_event.wait(4):
                try:
                    now=e.api.now_ms();slot=now//HOUR*HOUR
                    if not e.enabled or e.user_paused:
                        self.offer=None
                        continue
                    if e.journal.data.get('hourly_claim')==slot:continue
                    if not plan or plan['hour']!=slot:
                        self.offer=None
                        resp=session.get(BASE+str(slot)+'.json',params={'t':now//30000},timeout=(3,6))
                        if resp.status_code==404:
                            e.stop_event.wait(12)
                            continue
                        resp.raise_for_status()
                        candidate=resp.json()
                        validate(candidate,now)
                        plan=candidate
                    if plan['mode']=='enter' and now>plan['issued']+ENTER_TTL_SECONDS*1000:
                        self.offer=None
                        continue
                    frames={}
                    for frame,_ in plan['steps']:
                        if frame in frames:continue
                        response=session.get('https://www.okx.com/api/v5/market/candles',params={
                            'instId':plan['symbol'],'bar':frame,'limit':'65'},timeout=(3,6))
                        response.raise_for_status()
                        frames[frame]=response.json()['data']
                    if matches(plan['steps'],frames,plan['issued'],now):
                        if self.offer is not plan:
                            self.offer=plan
                            e.command_wake.set()
                except Exception:
                    self.offer=None
                    logging.warning('정각 신호 수신 또는 조건 검증 대기')
                    e.stop_event.wait(10)

    @staticmethod
    def entry_price_allowed(plan, px):
        if 'quarter' in plan:
            stop, target = price(plan['stop']), price(plan['target'])
            return min(stop,target) < px < max(stop,target)
        return price(plan['low']) <= px <= price(plan['high'])

    def check(self,s,px):
        p=self.current
        if (not p or (self.quarter_offer if "quarter" in p else self.offer) is not p or s.get('hourly')!=p
                or (p['mode']=='enter' and self.e.api.now_ms()>p['issued']+ENTER_TTL_SECONDS*1000)
                or self.e.api.now_ms()>=p['hour']+HOUR or not self.entry_price_allowed(p,px)):
            raise BotError('신호 만료 또는 진입 가격 이탈')
        return s['decision_record']['volume_wick_proof']

    def poll(self):
        from okx_click716 import signal,quote
        from okx_entry_gate720 import gate
        e=self.e
        for plan in (self.quarter_offer,self.offer):
            if plan and self.poll_plan(plan): return True
        return False

    def poll_plan(self,p):
        from okx_click716 import signal,quote
        from okx_entry_gate720 import gate
        e=self.e
        quarter='quarter' in p
        if quarter:
            try:
                validate_prices(p)
            except (ValueError, KeyError) as exc:
                if self.quarter_offer is p:
                    self.quarter_offer=None
                e.log('15분 신호 제외 · '+str(exc))
                return False
        claim='quarter_claim' if quarter else 'hourly_claim'
        slot=p.get('quarter',p['hour'])
        if p['mode']=='enter' and e.api.now_ms()>p['issued']+90000:return False
        if not p or p['hour']!=e.api.now_ms()//HOUR*HOUR or e.journal.data.get(claim)==slot:return False
        if not gate(e)['allowed'] or not e.can_open_position() or not e.enabled or e.user_paused:return False
        symbol=p['symbol']
        if symbol in e.blocked_manual_symbols() or any(o['symbol']==symbol for o in e.records()):return False
        try:
            # Rate-limit public preflight and let the engine's quote registry warm.
            if not quarter:
                if time.monotonic()<getattr(self,'next_poll',0):return False
                self.next_poll=time.monotonic()+4
            q=quote(e,symbol)
            px=float(q['askPx' if p['side']=='LONG' else 'bidPx'])
            if not self.entry_price_allowed(p,px):return False
            with e.phone_quote_registry.lock:
                e.phone_quote_registry.publish()
            if not e.stream.ready(symbol,e.cfg,e.api.now_ms()):return False
            s=signal(e,symbol,p['side'])
            s.pop('click716')
            stop,tp=price(p['stop']),price(p['target'])
            s.update(hourly=p,signal_id=('quarter-' if quarter else 'hourly-')+str(slot),pc260=True,stop=stop,level=stop,target=tp,
                     entry_reference=px,reason='15분 텔레그램 신호' if quarter else '정각 채팅 신호',regime='15분 분석' if quarter else '정각 분석',valid_from_ms=p['issued'],
                     expires_ms=p['hour']+HOUR)
            s['decision_record'].update(source='HOURLY_CHAT')
            s['decision_record']['volume_wick_proof'].update(structural_stop=stop,reference=px,setup='hourly_chat')
            s['selection']['origin']='HOURLY_CHAT'
            s['holding_rule'].update(zone=stop,target=tp,partial=False,target_mode='hourly_full')
            self.current=p
            self.check(s,px)
            with e.selected(e.empty_slot()):
                e.executing_signal=s
                e.entry(s)
            return e.journal.data.get(claim) == slot
        except UnknownOutcome:raise
        except BotError as exc:
            e.log(('15분' if quarter else '정각')+' 진입 대기 · '+str(exc))
            return False
        finally:
            self.current=None
            e.executing_signal=None


def start(e):
    e.hourly_relay=Relay(e)
    threading.Thread(target=e.hourly_relay.run,daemon=True,name='hourly-chat-feed').start()

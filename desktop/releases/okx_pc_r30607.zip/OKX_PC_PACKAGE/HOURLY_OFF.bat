@echo off
if exist "%LOCALAPPDATA%\OKXTradingPC\hourly-live.on" del "%LOCALAPPDATA%\OKXTradingPC\hourly-live.on"

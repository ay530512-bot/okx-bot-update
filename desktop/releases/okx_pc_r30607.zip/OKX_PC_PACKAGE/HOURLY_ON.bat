@echo off
if not exist "%LOCALAPPDATA%\OKXTradingPC" mkdir "%LOCALAPPDATA%\OKXTradingPC"
echo enabled>"%LOCALAPPDATA%\OKXTradingPC\hourly-live.on"

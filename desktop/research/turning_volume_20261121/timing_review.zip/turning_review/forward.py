"""Evaluate the frozen timing rules on any subsequent completed 60-day KST window."""
import argparse
import json
import os
from datetime import date, datetime, timedelta
from pathlib import Path
import subprocess
import sys
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from signals import COINS, location, symbol_signals, price_signals, meta
from inputs import PERIODS, MINUTE, dates, prepare
from paths import SO, SOURCE


def collect(section):
    instruments=meta()
    rows=[]
    with np.errstate(divide="ignore",invalid="ignore"):
        for symbol in sorted(COINS):
            rows.extend(symbol_signals(section,symbol,instruments[symbol]))
    frame=pd.DataFrame(rows)
    if frame.empty:
        return frame
    keys=["rule","profile","mode","clock"]
    return frame.sort_values(keys+["quality","symbol"],ascending=[True]*4+[False,True]).drop_duplicates(keys)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--end", type=date.fromisoformat, required=True, help="Exclusive date at 00:00 KST")
    parser.add_argument("--fetch", action="store_true", help="Download a fresh public snapshot before preparing candle inputs")
    args=parser.parse_args()
    if args.end>datetime.now(ZoneInfo("Asia/Seoul")).date():
        parser.error("The entire requested window must be complete in Korea.")
    start=args.end-timedelta(days=60)
    interval=[start.isoformat(),args.end.isoformat()]
    section="forward_"+args.end.isoformat()
    PERIODS[section]=tuple(interval)
    folder=location(section)
    folder.mkdir(parents=True,exist_ok=True)
    if args.fetch:
        subprocess.run([sys.executable,"timing_research/fetch_public.py","--start",interval[0],
                        "--end",interval[1]],check=True)
    if not SO.is_file() or SO.stat().st_mtime < SOURCE.stat().st_mtime:
        subprocess.run([sys.executable,"target_research/paths.py","compile"],check=True)
    # The execution module loads the instrument table and compiled replay on import.
    from experiment import limits, replay, timings
    from minute_timing import generate, MinuteBook
    coverage=dict(prepare((section,sym)) for sym in COINS)
    instruments=meta()
    _, start_ms, end_ms=dates(section)
    for sym, row in coverage.items():
        instrument=instruments[sym]
        listed=int(instrument.get("listTime") or 0)
        ended=int(instrument.get("expTime") or 0)
        active=max(start_ms,listed)<min(end_ms,ended or end_ms)
        allowed_tail=max(0,(end_ms-ended+MINUTE-1)//MINUTE) if ended else 0
        if (row["missing_inside"] or row["missing_tail"]>allowed_tail
                or (active and row["valid_minutes"]==0)):
            raise RuntimeError(f"Incomplete active candle history for {sym}")
    if not any(row["valid_minutes"] for row in coverage.values()):
        raise RuntimeError("No listed instrument has candles in this interval")
    frozen=json.loads(Path("turning_review/frozen.json").read_text())["selected"]
    configurations=[r["config"] for r in frozen.values()]
    families=[(collect(section),("frozen_5m",)),(generate(section,configurations),("level_1m","higher_low_1m"))]
    result={"period":interval,"coverage":coverage,"hypotheses":{}}
    for candidates, modes in families:
        for stress in (False,True):
            frame=price_signals(section,candidates,stress) if not candidates.empty else pd.DataFrame(
                columns=["rule","profile","mode","hold","signal","entry","exit","coin","price","dist","net"])
            book=MinuteBook(frame,stress,configurations)
            for mode in modes:
                rules=[dict(c) if mode=="frozen_5m" else dict(c,mode=mode) for c in configurations]
                for c in rules:
                    book.groups.setdefault(book.key(c),np.empty((0,7),dtype="f8"))
                individual={c["rule"]:book.single(c,limits(interval)) for c in rules}
                account=replay(book,rules,section)
                ledger=account.pop("ledger")
                account["direction"]=timings(section,ledger)
                result["hypotheses"].setdefault(mode,{})["stress" if stress else "base"]=dict(
                    individual=individual,shared=account)
    out=Path("turning_review/forward")
    out.mkdir(exist_ok=True)
    target=out/(interval[1]+".json")
    tmp=target.with_suffix(".tmp")
    tmp.write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")
    os.replace(tmp,target)
    print(target)


if __name__=="__main__":
    main()

import unittest

import numpy as np

from signals import confirmation, last_rebound, parent_before_setup, signed_prices


class TimingTests(unittest.TestCase):
    def setUp(self):
        self.bars = np.array([
            [99.8,100.0,98.0,99.5],
            [99.5,100.2,99.3,99.8],
            [99.8,100.5,99.6,100.4],
            [100.07,100.35,99.96,100.30],
            [100.3,101.2,100.2,100.9],
        ])
        self.vol = np.array([2.,.8,1.7,1.,1.2])

    def test_close_then_retest(self):
        p=signed_prices(self.bars,1)
        self.assertEqual(confirmation(p,self.vol,0,100.,1.,.01,1.),{"break":2,"retest":3})
        self.assertEqual(confirmation(tuple(x[:2] for x in p),self.vol[:2],0,100.,1.,.01,1.),{})
        self.assertEqual(confirmation(tuple(x[:3] for x in p),self.vol[:3],0,100.,1.,.01,1.),{"break":2})

    def test_exact_price_mirror(self):
        op, high, low, close=self.bars.T
        reflected=np.column_stack((200-op,200-low,200-high,200-close))
        self.assertEqual(confirmation(signed_prices(reflected,-1),self.vol,0,-100.,1.,.01,1.),
                         confirmation(signed_prices(self.bars,1),self.vol,0,100.,1.,.01,1.))

    def test_failed_first_break_and_invalidated_wick(self):
        p=signed_prices(self.bars,1)
        self.assertEqual(confirmation(p,self.vol,0,100.,1.,.01,2.),{})
        changed=self.bars.copy()
        changed[1,2]=97.99
        self.assertEqual(confirmation(signed_prices(changed,1),self.vol,0,100.,1.,.01,1.),{})

    def test_pivot_and_completed_parent(self):
        high=np.array([1.,2.,6.,3.,4.,2.,2.,8.])
        close=high-.5
        self.assertIsNone(last_rebound(high,close,4))
        self.assertEqual(last_rebound(high,close,5),6.)
        self.assertEqual(last_rebound(high,close,7),6.)
        np.testing.assert_array_equal(parent_before_setup(np.arange(6,12)),[1,1,1,2,2,2])


if __name__=="__main__":
    unittest.main()

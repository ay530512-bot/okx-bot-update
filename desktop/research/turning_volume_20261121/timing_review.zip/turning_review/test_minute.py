import unittest
import numpy as np
from minute_timing import decisions
from signals import signed_prices


class MinuteTests(unittest.TestCase):
    def setUp(self):
        self.raw=np.array([[99.8,100.0,99.0,99.7],[99.7,100.1,99.5,100.0],
            [100.0,100.4,99.9,100.3],[100.2,100.3,99.5,99.8],
            [99.8,100.6,99.55,100.55],[100.5,100.7,100.25,100.5],
            [100.55,101.1,100.5,101.05]])
        self.row=dict(clock=5,atr=1.,wick_price=99.,level=100.9,side=1,profile="standard")
        self.ratio=np.full(len(self.raw),1.5)

    def run_rows(self,bars,row):
        return decisions(signed_prices(bars,row["side"]),self.ratio[:len(bars)],
            self.ratio[:len(bars)],row,.01)

    def test_confirmations_and_next_open(self):
        result=self.run_rows(self.raw,self.row)
        self.assertEqual(result["higher_low_1m"],(4,100.4))
        self.assertEqual(result["level_1m"],(6,100.9))
        self.assertEqual(result["higher_low_1m"][0]+1,self.row["clock"])
        self.assertEqual(self.run_rows(self.raw[:5],self.row),{"higher_low_1m":(4,100.4)})

    def test_short_mirror_and_invalidation(self):
        op,high,low,close=self.raw.T
        reflected=np.column_stack((200-op,200-low,200-high,200-close))
        row=dict(self.row,side=-1,wick_price=101.,level=99.1)
        short=self.run_rows(reflected,row);long=self.run_rows(self.raw,self.row)
        for mode,(minute, trigger) in long.items():
            self.assertEqual(short[mode][0],minute)
            self.assertAlmostEqual(short[mode][1],trigger-200)
        changed=self.raw.copy();changed[5,2]=98.9
        self.assertNotIn("level_1m",self.run_rows(changed,self.row))


if __name__=="__main__":
    unittest.main()

"""Animate actual one-minute OHLCV accumulating inside each five-minute candle."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

from signals import OUT, MINUTE, dates, location, meta

NAMES = {"reversal_long":"하락 후 전환 롱","reversal_short":"상승 후 전환 숏",
         "continuation_long":"상승 추세 · 눌림 후 롱","continuation_short":"하락 추세 · 반등 후 숏"}
BG, GRID, FG, MUTED = "#11161C","#34404B","#F5F5F2","#A7B4BF"
UP, DOWN, WICK, CHECK = "#54BF9B","#EB7889","#FFC069","#89D9FF"
FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
FONTS = {n:ImageFont.truetype(BOLD if n>=20 else FONT,n,index=1) for n in (12,14,16,20,24)}


def choose():
    selected=json.loads((OUT/"frozen.json").read_text())["selected"]
    trades=pd.DataFrame(json.loads((OUT/"recent-trades.json").read_text()))
    frame=pd.read_pickle(OUT/"recent.pkl")
    for rule in NAMES:
        c=selected[rule]["config"]
        rows=frame[(frame.rule==rule)&(frame["mode"]==c["mode"])&(frame.profile==c["profile"])&(frame.hold==c["hold"])]
        joined=trades[trades.rule==rule].merge(rows,on=["rule","symbol","entry","exit"])
        # Choose by time only and require two distinguishable candles for illustration.
        example=joined[joined.confirmation>joined.setup].sort_values("entry").iloc[0]
        yield example


def chapter(example):
    bars=np.load(location("recent")/(example.symbol+"-1.npy"),mmap_mode="r")
    five=np.load(location("recent")/(example.symbol+"-5.npy"),mmap_mode="r")
    epoch=dates("recent")[0]//MINUTE
    wick,confirm=int(example.setup),int(example.confirmation)
    fill=int(example.entry)-epoch
    tick=meta()[example.symbol]["tickSz"]
    digits=len(tick.rstrip("0").split(".")[-1]) if "." in tick else 0
    price=lambda value:f"{value:.{digits}f}"
    first,last=wick-16,confirm+3
    full=five[first:last+1,:5]
    low,high=min(full[:,2]),max(full[:,1])
    pad=(high-low)*.22
    y0,y1=low-pad,high+pad
    vmax=float(max(full[:,4]))*1.12
    xleft,xright=22,614
    step=(xright-xleft)/(last-first+1)
    x=lambda i:int(xleft+(i-first+.5)*step)
    y=lambda p:int(256-(p-y0)/(y1-y0)*163)
    vy=lambda v:int(327-47*v/vmax)
    def local_time(i,fmt="%H:%M"):
        return pd.Timestamp((epoch+i)*60,unit="s",tz="UTC").tz_convert("Asia/Seoul").strftime(fmt)
    def frame(seen,filled):
        im=Image.new("RGB",(720,424),BG)
        dr=ImageDraw.Draw(im)
        def txt(at,msg,size,color=FG,anchor="la"):
            dr.text(at,msg,font=FONTS[size],fill=color,anchor=anchor)
        txt((19,6),NAMES[example.rule],24)
        txt((700,16),f"{example.symbol} / USDT   ·   {local_time(seen,'%m.%d  %H:%M')} KST",16,MUTED,"ra")
        txt((20,46),"5분봉",16)
        for xx,color,label in [(100,WICK,"거래량 꼬리"),(241,CHECK,"구조 돌파 마감"),(421,FG,"다음 봉 모의 진입")]:
            dr.ellipse((xx,55,xx+6,61),fill=color)
            txt((xx+12,47),label,14,color)
        for v in np.linspace(low,high,4):
            yy=y(v);dr.line((xleft,yy,xright,yy),fill=GRID)
            txt((626,yy),price(v),12,MUTED,"lm")
        for idx in range(first,last+1):
            start=idx*5
            if start>=seen:
                break
            segment=bars[start:min(start+5,seen)]
            o,h,l,c=segment[0,0],max(segment[:,1]),min(segment[:,2]),segment[-1,3]
            color=UP if c>=o else DOWN
            xx=x(idx);half=max(2,int(step*.31))
            dr.line((xx,y(h),xx,y(l)),fill=color,width=2)
            top,bottom=sorted((y(o),y(c)))
            dr.rectangle((xx-half,top,xx+half,max(top+1,bottom)),fill=color)
            dr.rectangle((xx-half,vy(sum(segment[:,4])),xx+half,328),fill=color)
        if seen >= 5*(wick+1):
            yy=y(example.level)
            for j in range(x(wick),xright,11):
                dr.line((j,yy,min(j+6,xright),yy),fill=CHECK,width=1)
            wx,wy=x(wick),y(example.wick_price)
            dr.ellipse((wx-4,wy-4,wx+4,wy+4),outline=WICK,width=3)
            txt((wx,273),f"×{example.setup_volume:.1f}",12,WICK,"mm")
        if seen>=5*(confirm+1):
            xx=x(confirm);yy=y(five[confirm,3])
            dr.rectangle((xx-4,yy-4,xx+4,yy+4),outline=CHECK,width=2)
        if filled:
            xx=x(fill//5);yy=y(example.entry_price)
            dr.polygon([(xx,yy),(xx-6,yy-10),(xx+6,yy-10)] if example.side_x<0 else
                       [(xx,yy),(xx-6,yy+10),(xx+6,yy+10)],fill=FG)
        txt((626,305),"거래량",12,MUTED)
        for idx in [first,(first+last)//2,last]:
            txt((x(idx),335),local_time(idx*5),12,MUTED,"ma")
        if filled:
            msg=f"{local_time(fill)}  다음 봉 모의 진입  {price(example.entry_price)}"
        elif seen>=5*(confirm+1):
            msg=f"{local_time((confirm+1)*5)}  기준선 {price(example.level)}을 종가로 돌파"
        elif seen>=5*(wick+1):
            msg=f"꼬리 봉 마감   ·   거래량 {example.setup_volume:.2f}배   ·   기준선 {price(example.level)}"
        else:
            msg="꼬리 봉 진행 중"
        txt((20,365),msg,20)
        txt((20,399),"OKX 1분 OHLCV로 재생   ·   표시 시각은 한국시간",12,MUTED)
        return im.convert("P",palette=Image.Palette.ADAPTIVE,colors=96)
    images, durations = [], []
    for seen in range(wick*5,fill+7):
        if seen==fill:
            images.append(frame(seen,False));durations.append(1050)
        images.append(frame(seen,seen>=fill))
        durations.append(1100 if seen in (wick*5,fill,fill+6) else 230)
    return images,durations


if __name__=="__main__":
    frames,delays=[],[]
    cases=[]
    for trade in choose():
        images,durations=chapter(trade)
        frames.extend(images);delays.extend(durations)
        cases.append({"rule":trade.rule,"symbol":trade.symbol,"entry_minute":int(trade.entry),
                      "level":float(trade.level),"entry":float(trade.entry_price),"volume":float(trade.setup_volume)})
    frames[0].save(OUT/"entries.gif",save_all=True,append_images=frames[1:],duration=delays,loop=0,optimize=True,disposal=1)
    (OUT/"examples.json").write_text(json.dumps(cases,indent=2)+"\n")
    print("frames",len(frames),"bytes",(OUT/"entries.gif").stat().st_size)

"""Select fixed sessions on earlier blocks, then replay individual rules and a shared account."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path.cwd() / "target_research"))
from inputs import MINUTE, dates, location
from evaluate import CONTRACTS, METRICS, limits, score
from paths import lib
from portfolio import replay

ROOT = Path("turning_review")
PLAN = json.loads((ROOT/"plan.json").read_text())
RULES = tuple(f"{regime}_{side}" for regime in ("reversal","continuation") for side in ("long","short"))
ENGINE = lib()


def write_json(name, obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+"\n")


def fingerprint():
    return {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ("plan.json","signals.py","experiment.py")}


class Book:
    def __init__(self, section, stress=False):
        self.stress = stress
        self.frame = pd.read_pickle(ROOT/(section+("-stress" if stress else "")+".pkl"))
        self.groups = {}
        columns = ["signal","entry","exit","coin","price","dist","net"]
        for key, group in self.frame.groupby(["rule","profile","mode","hold"]):
            self.groups[key] = np.ascontiguousarray(group[columns].to_numpy(dtype="f8"))
        for rule in RULES:
            for profile in profiles(rule):
                for mode, hold in itertools.product(("wick","break","retest"),(45,120)):
                    self.groups.setdefault((rule,profile,mode,hold), np.empty((0,7),dtype="f8"))

    @staticmethod
    def key(c):
        return c["rule"], c["profile"], c["mode"], c["hold"]

    def single(self, c, interval):
        rows = self.groups[self.key(c)]
        out = np.zeros(8)
        ENGINE.single(rows,len(rows),CONTRACTS,*interval,c["start"],c["end"],540,c["cap"],c["hold"],10,0,
                      .0005,.001 if self.stress else .0005,out)
        result = dict(zip(METRICS,map(float,out)))
        for k in ("wins","trades","active_days"):
            result[k] = int(result[k])
        result["net_pct"] = 100*(result["final"]/150-1)
        return result


def profiles(rule):
    return ("standard","strong","quiet_pullback") if rule.startswith("continuation") else ("standard","strong")


def freeze():
    book = Book("development")
    a, b = map(limits,PLAN["development"])
    validation = limits(PLAN["validation"])
    selected, totals, grid = {}, {}, []
    for rule in RULES:
        candidates = []
        for profile, mode, hold, session in itertools.product(profiles(rule),("break","retest"),(45,120),PLAN["sessions"]):
            c = dict(rule=rule,profile=profile,mode=mode,hold=hold,start=session[0],end=session[1],cap=4)
            x, y = book.single(c,a), book.single(c,b)
            enough = min(x["trades"],y["trades"]) >= 8
            passed = enough and min(x["net_pct"],y["net_pct"]) > 0 and x["final"]+y["final"]-300 > max(x["largest_gain"],y["largest_gain"])
            row = dict(config=c,development=[x,y],enough=enough,development_pass=passed,score=score(x,y))
            candidates.append(row)
            grid.append(dict(**c,development_1=x["net_pct"],development_2=y["net_pct"],trades_1=x["trades"],trades_2=y["trades"],passed=passed))
        totals[rule] = len(candidates)
        candidates.sort(key=lambda r:(r["development_pass"],r["enough"],r["score"]),reverse=True)
        shortlist, seen = [], set()
        for r in candidates:
            distinct = tuple((v["trades"],round(v["final"],8),round(v["closed_dd_pct"],8)) for v in r["development"])
            if distinct in seen:
                continue
            seen.add(distinct)
            v = book.single(r["config"],validation)
            r["validation"] = v
            r["prior_pass"] = r["development_pass"] and v["trades"] >= 10 and v["net_pct"] > 0
            shortlist.append(r)
            if len(shortlist)==3:
                break
        selected[rule] = max(shortlist,key=lambda r:(r["prior_pass"],r["validation"]["trades"]>=10,
            r["validation"]["net_pct"]-.18*r["validation"]["closed_dd_pct"],r["score"]))
    pd.DataFrame(grid).to_csv(ROOT/"development.csv",index=False)
    write_json("frozen.json",dict(source_hashes=fingerprint(),configurations=totals,selected=selected))
    for rule,r in selected.items():
        print(rule, r["config"], round(r["validation"]["net_pct"],2),r["prior_pass"])


def timings(section, ledger):
    base = dates(section)[0]//MINUTE
    moves = {n:[] for n in (5,15,30)}
    bars = {sym:np.load(location(section)/f"{sym}-1.npy",mmap_mode="r") for sym in {x["symbol"] for x in ledger}}
    for trade in ledger:
        frame = bars[trade["symbol"]]
        i = trade["entry"]-base
        for n,values in moves.items():
            values.append(trade["side"]*100*(frame[i+n-1,3]/frame[i,0]-1))
    return {n:dict(n=len(v),favorable=int(np.sum(np.array(v)>0)),median_pct=float(np.median(v)) if v else None,
                   mean_pct=float(np.mean(v)) if v else None) for n,v in moves.items()}


def run(section):
    frozen = json.loads((ROOT/"frozen.json").read_text())
    assert fingerprint() == frozen["source_hashes"], "Selection code or criteria changed after freeze"
    configs = [x["config"] for x in frozen["selected"].values()]
    period = limits(PLAN[section])
    for stress in (False, True):
        book = Book(section,stress)
        output = dict(steps={}, joint={},individually_eligible=[])
        for c in configs:
            stages = {}
            for mode in ("wick","break","retest"):
                variant = dict(c,mode=mode)
                stats = book.single(variant,period)
                stages[mode] = stats
                if mode==c["mode"] and not stress:
                    ledger = replay(book,[variant],section)["ledger"]
                    assert stats["trades"]==len(ledger) and abs(stats["final"]-150-sum(t["net_usdt"] for t in ledger))<1e-7
                    stats["direction"] = timings(section,ledger)
            output["steps"][c["rule"]] = stages
            chosen = stages[c["mode"]]
            if frozen["selected"][c["rule"]]["prior_pass"] and chosen["net_pct"]>=10 and chosen["trades"]>=15:
                output["individually_eligible"].append(c["rule"])
        subset = [c for c in configs if c["rule"] in output["individually_eligible"]]
        for group, choices in [("all_four",configs),("passing_only",subset)]:
            portfolio = replay(book,choices,section)
            ledger = portfolio.pop("ledger")
            if group=="all_four" and not stress:
                write_json(section+"-trades.json",ledger)
                portfolio["direction"] = timings(section,ledger)
            output["joint"][group] = portfolio
        write_json(section+("-stress" if stress else "")+"-results.json",output)
        print(section,stress,[(c["rule"], round(output["steps"][c["rule"]][c["mode"]]["net_pct"],2),
               output["steps"][c["rule"]][c["mode"]]["trades"]) for c in configs],
              output["joint"]["all_four"]["final"],output["individually_eligible"],flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("stage",choices=["freeze","recent","earlier"])
    stage=parser.parse_args().stage
    if stage=="freeze":
        freeze()
    else:
        run(stage)

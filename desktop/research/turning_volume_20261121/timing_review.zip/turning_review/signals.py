"""Closed-bar trend context, volume, rejection wick and subsequent structure confirmation."""
import argparse
from pathlib import Path
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path.cwd() / "target_research"))
from inputs import COINS, MINUTE, dates, location
from paths import lib, meta
from patterns import ema, roll, shift

OUT = Path("turning_review")
PROFILES = {
    "standard": (1/3, 1.5, 1.0),
    "strong": (.45, 2.0, 1.25),
    "quiet_pullback": (.25, 1.0, 1.5),
}


def signed_prices(bars, side):
    op, high, low, close = bars[:, :4].T
    if side == 1:
        return op, high, low, close
    return -op, -low, -high, -close


def parent_before_setup(indices):
    return indices // 3 - 1


def last_rebound(high, close, j):
    # Both candles to the right of a pivot must have closed before the wick candle starts.
    for k in range(j-3, max(2, j-19)-1, -1):
        if (high[k] > max(high[k-2:k]) and high[k] >= max(high[k+1:k+3])
                and np.max(close[k+1:j]) <= high[k]):
            return float(high[k])
    return None


def confirmation(prices, relative_volume, j, level, atr, tick, required_volume):
    op, high, low, close = prices
    floor = low[j]
    found = {}
    for k in range(j, min(j+7, len(close))):
        if not np.isfinite(close[k]) or low[k] < floor-.5*tick:
            return found
        if close[k] < level+.5*tick:
            continue
        spread = high[k]-low[k]
        if (spread <= 0 or close[k] <= op[k] or close[k]-level > .60*atr
                or close[k]-low[k] < .60*spread or relative_volume[k] < required_volume):
            return found
        found["break"] = k
        touch = None
        for t in range(k+1, min(k+4, len(close))):
            if (not np.isfinite(close[t]) or low[t] <= floor+.5*tick
                    or low[t] < level-.45*atr):
                return found
            if touch is None and low[t] <= level+.25*atr:
                touch = t
            if touch is None:
                continue
            reclaim = level if touch == t else max(level, high[touch])
            if (close[t] >= reclaim+.5*tick and close[t] > op[t] and close[t]-level <= .60*atr
                    and close[t]-low[t] >= .55*(high[t]-low[t]) and relative_volume[t] >= .6):
                found["retest"] = t
                break
        return found
    return found


def symbol_signals(section, symbol, instrument):
    folder = location(section)
    five = np.load(folder / f"{symbol}-5.npy", mmap_mode="r")
    parent = np.load(folder / f"{symbol}-15.npy", mmap_mode="r")
    _, high, low, close, volume = five[:, :5].T
    base, begin, end = dates(section)
    indices = np.arange(len(close))
    pos = parent_before_setup(indices).clip(0, len(parent)-1)
    ts = base + (indices+1)*5*MINUTE
    tick = float(instrument["tickSz"])
    previous = shift(close)
    tr = np.maximum.reduce((high-low, abs(high-previous), abs(low-previous)))
    atr = shift(roll(tr, 14, "mean"))
    mean_volume = shift(roll(volume, 20, "mean"))
    rel = volume/mean_volume
    sma3_vol = shift(roll(volume, 3, "mean"))
    turn = roll(volume*close*float(instrument["ctVal"]), 12, "sum")
    eligible = ((ts >= begin) & (ts < end) & (roll(np.isfinite(close).astype(float), 100, "sum") == 100)
                & (high > low) & (tick/close <= .0005) & (turn >= 60000)
                & (atr/close >= .0014) & (atr/close <= .04) & (volume > 0))
    parent_close = parent[:, 3]
    parent_ready = (roll(np.isfinite(parent_close).astype(float), 55, "sum") == 55)[pos]
    fast, slow = ema(parent_close,20), ema(parent_close,50)
    slope = (fast-shift(fast,3))[pos]
    change = (parent_close-shift(parent_close,3))[pos]
    fast5 = shift(ema(close,20))
    records = []
    for side in (1, -1):
        prices = signed_prices(five, side)
        op, top, floor, last = prices
        spread = top-floor
        wick = (np.minimum(op,last)-floor)/spread
        location_close = (last-floor)/spread
        earlier_high = shift(roll(top,12,"max"))
        earlier_low = shift(roll(floor,4,"min"))
        amplitude = (earlier_high-floor)/atr
        pre_fall = (side*slope < 0) & (side*change < 0)
        with_trend = (side*slope > 0) & (side*(fast[pos]-slow[pos]) > 0) & (side*(parent_close[pos]-fast[pos]) > 0)
        setups = {
            "reversal": pre_fall & (amplitude >= 1.5) & (floor <= earlier_low+.10*atr),
            "continuation": with_trend & (amplitude >= 1.0) & (floor <= earlier_low+.15*atr)
                    & (floor <= side*fast5+.30*atr) & (floor >= side*fast5-1.5*atr),
        }
        for family, context in setups.items():
            rule = family + ("_long" if side == 1 else "_short")
            for profile, (wick_min, volume_limit, confirm_volume) in PROFILES.items():
                if profile == "quiet_pullback":
                    if family != "continuation":
                        continue
                    volume_ok = (rel <= volume_limit) & (volume < sma3_vol)
                else:
                    volume_ok = (rel >= volume_limit) & (volume > shift(volume))
                mask = eligible & parent_ready & context & volume_ok & (wick >= wick_min) & (location_close >= .55)
                next_setup = 0
                for j in np.flatnonzero(mask):
                    if j < next_setup:
                        continue
                    level = last_rebound(top,last,j) if family == "reversal" else max(top[j-2:j+1])
                    if level is None or not (.45*atr[j] <= level-floor[j] <= 3.5*atr[j]):
                        continue
                    pad = max(2*tick,.25*atr[j])
                    signed_stop = np.floor((floor[j]-pad)/tick + 1.e-10)*tick
                    next_setup = j+10
                    times = {"wick": j, **confirmation(prices,rel,j,level,atr[j],tick,confirm_volume)}
                    for mode, k in times.items():
                        dist = last[k]-signed_stop
                        if not (.60*atr[j] <= dist <= 4.5*atr[j] and dist/close[k] <= .06):
                            continue
                        quality = min(max(rel[j],rel[k]),4.) + wick[j] + .1*min(amplitude[j],5.)
                        records.append(dict(rule=rule,profile=profile,mode=mode,side=side,
                            symbol=symbol,coin=COINS.index(symbol),setup=int(j),confirmation=int(k),
                            break_bar=int(times.get("break",-1)) if mode=="retest" else (-1 if mode=="wick" else int(k)),
                            clock=int((k+1)*5),ref=close[k],atr=atr[j],stop=side*signed_stop,
                            level=side*level,wick_price=side*floor[j],wick_share=wick[j],
                            setup_volume=rel[j],confirm_volume=rel[k],quality=quality))
    return records


def signals(section):
    instruments = meta()
    parts = []
    with np.errstate(divide="ignore",invalid="ignore"):
        for symbol in sorted(COINS):
            parts.extend(symbol_signals(section,symbol,instruments[symbol]))
    frame = pd.DataFrame(parts)
    keys = ["rule","profile","mode","clock"]
    # Pick a single symbol per rule/setting at the decision time, before pricing any fills.
    frame.sort_values(keys+["quality","symbol"],ascending=[True]*4+[False,True],inplace=True)
    return frame.drop_duplicates(keys).reset_index(drop=True)


def price_signals(section, frame, stress):
    instruments = meta()
    epoch = dates(section)[0] // MINUTE
    engine = lib()
    priced = []
    for (symbol,side), group in frame.groupby(["symbol","side"],sort=False):
        market = np.ascontiguousarray(np.load(location(section)/f"{symbol}-1.npy",mmap_mode="r"))
        orders = np.ascontiguousarray(group[["clock","ref","atr","stop"]].to_numpy(dtype="f8"))
        results = np.empty((len(group),7))
        engine.paths(market,len(market),orders,len(group),int(side),5,0,float(instruments[symbol]["tickSz"]),
                     .001 if stress else .0005,.0005,int(stress),results)
        for column, hold in [(3,45),(5,120)]:
            ok = np.isfinite(results[:,column+1])
            subset = group.loc[ok].copy()
            subset["hold"] = hold
            subset["signal"] = subset.clock+epoch
            subset["entry"] = (results[ok,0]+epoch).astype(int)
            subset["exit"] = (results[ok,column]+epoch).astype(int)
            subset["price"] = results[ok,1]
            subset["dist"] = results[ok,2]
            subset["net"] = results[ok,column+1]
            priced.append(subset)
    return pd.concat(priced,ignore_index=True).sort_values("entry",kind="stable")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("section", choices=["development","earlier","recent"])
    args = parser.parse_args()
    raw = signals(args.section)
    print(args.section,"signals",len(raw),flush=True)
    for stress in ([False] if args.section=="development" else [False,True]):
        frame = price_signals(args.section,raw,stress)
        frame.to_pickle(OUT/(args.section+("-stress" if stress else "")+".pkl"))
        print("priced",stress,len(frame),flush=True)

"""Replay two faster entry decisions on the four previously fixed five-minute setups."""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from signals import OUT, PROFILES, COINS, dates, location, meta, roll, shift, signed_prices, symbol_signals, price_signals
from experiment import Book, RULES, PLAN, limits, replay, timings, write_json

MODES = ("level_1m","higher_low_1m")


def decisions(prices, minute_volume, recent_five_volume, row, tick):
    op, high, low, close = prices
    first = row["clock"]-5
    ready = first+4
    atr = row["atr"]
    extreme = row["wick_price"]*row["side"]
    structure = row["level"]*row["side"]
    # Last occurrence resolves double touches inside the formation candle.
    wick = first+int(np.flatnonzero(low[first:ready+1] <= extreme+.25*tick)[-1])
    wave_level = None
    done = {}
    major_expired = False
    early_expired = False
    required = PROFILES[row["profile"]][2]
    for k in range(wick, min(len(close), ready+31)):
        if not np.isfinite(close[k]) or low[k] < extreme-.5*tick:
            break
        if (k>=wick+4 and low[k-1]>extreme+.5*tick and low[k-1]<=low[k-2]
                and low[k-1]<low[k]):
            peak = max(high[wick+1:k-1])
            if (peak-extreme>=.35*atr and peak-low[k-1]>=.10*atr and peak<structure-.5*tick):
                wave_level = peak
        if k<ready:
            continue
        good_close = (high[k]>low[k] and close[k]>op[k] and close[k]-low[k]>=.60*(high[k]-low[k]))
        if not major_expired and "level_1m" not in done and close[k]>=structure+.5*tick:
            if good_close and close[k]-structure<=.60*atr and recent_five_volume[k]>=required:
                done["level_1m"] = (k,structure)
            major_expired=True
        if (not early_expired and "higher_low_1m" not in done and k<=ready+15
                and wave_level is not None and close[k]>=wave_level+.5*tick):
            if good_close and close[k]-wave_level<=.60*atr and close[k]<structure and minute_volume[k]>1.:
                done["higher_low_1m"] = (k,wave_level)
            early_expired = True
        if close[k]>=structure:
            early_expired=True
        if major_expired and (early_expired or k>=ready+15):
            break
    return done


def generate(section, settings):
    instruments = meta()
    rows = []
    wanted = {r["rule"]:r["profile"] for r in settings}
    for symbol in sorted(COINS):
        instrument=instruments[symbol]
        with np.errstate(divide="ignore",invalid="ignore"):
            setups=[r for r in symbol_signals(section,symbol,instrument)
                    if r["mode"]=="wick" and r["profile"]==wanted[r["rule"]]]
            market=np.load(location(section)/f"{symbol}-1.npy",mmap_mode="r")
            volume=market[:,4]
            minute_ratio=volume/shift(roll(volume,20,"mean"))
            # Each current five-minute sum is compared with the preceding 100 disjoint minutes.
            five_ratio=roll(volume,5,"sum")/(5*shift(roll(volume,100,"mean"),5))
        coordinates={side:signed_prices(market,side) for side in (1,-1)}
        tick=float(instrument["tickSz"])
        for setup in setups:
            side=setup["side"]
            for mode,(k,trigger) in decisions(coordinates[side],minute_ratio,five_ratio,setup,tick).items():
                ref=market[k,3]
                risk=side*(ref-setup["stop"])
                if not (.60*setup["atr"]<=risk<=4.5*setup["atr"] and risk/ref<=.06):
                    continue
                quality=setup["quality"]-min(4.,setup["setup_volume"])+min(4.,max(setup["setup_volume"],five_ratio[k]))
                rows.append(dict(setup,mode=mode,clock=k+1,ref=ref,confirmation_minute=k,
                                 trigger_price=side*trigger,confirm_volume=five_ratio[k],quality=quality))
    frame=pd.DataFrame(rows)
    if frame.empty:
        return frame
    keys=["rule","profile","mode","clock"]
    frame=frame.sort_values(keys+["quality","symbol"],ascending=[True]*4+[False,True])
    return frame.drop_duplicates(keys)


class MinuteBook(Book):
    def __init__(self, frame, stress, settings):
        self.frame=frame
        self.stress=stress
        self.groups={}
        fields=["signal","entry","exit","coin","price","dist","net"]
        for keys, group in frame.groupby(["rule","profile","mode","hold"]):
            self.groups[keys]=np.ascontiguousarray(group[fields].to_numpy(dtype="f8"))
        for cfg in settings:
            for mode in MODES:
                self.groups.setdefault(self.key(dict(cfg,mode=mode)),np.empty((0,7),dtype="f8"))


def run(section):
    frozen=json.loads((OUT/"frozen.json").read_text())["selected"]
    settings=[frozen[k]["config"] for k in RULES]
    events=generate(section,settings)
    intervals=([*PLAN["development"],PLAN["validation"]] if section=="development" else [PLAN[section]])
    for stress in ((False,True) if section=="recent" else (False,)):
        frame=price_signals(section,events,stress)
        book=MinuteBook(frame,stress,settings)
        data={}
        for mode in MODES:
            rules=[dict(c,mode=mode) for c in settings]
            by_interval={}
            for interval in intervals:
                by_interval[interval[0]]={c["rule"]:book.single(c,limits(interval)) for c in rules}
            data[mode]=dict(individual=by_interval)
            if section!="development":
                full=replay(book,rules,section)
                ledger=full.pop("ledger")
                if not stress:
                    full["direction"]=timings(section,ledger)
                data[mode]["shared"]=full
        write_json("minute-"+section+("-stress" if stress else "")+".json",data)
        print(section,stress,[(mode,[(k,round(s["net_pct"],2),s["trades"]) for k,s in
            data[mode]["individual"][intervals[-1][0]].items()],data[mode].get("shared",{}).get("final")) for mode in MODES],flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("section",choices=("development","recent","earlier"))
    run(p.parse_args().section)

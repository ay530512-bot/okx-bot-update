"""Conservative retrospective upper bound for subsets of the reconstructed, fixed-exit signals."""
import json
import numpy as np
import pandas as pd
from run import BASE,CACHE,DAY,END,HERE,M,START,bars,prior,trend_paths

def main():
    rev=prior.reversals()
    cases=pd.concat([rev[rev.qualifies],trend_paths(),pd.read_pickle(CACHE/'scalp_paths.pkl')],ignore_index=True)
    cases=cases[(~cases.stress)&(cases.signal>=START)&(cases.signal<END)]
    # Necessary at every account size: a live-sized slot must reach 97% of one-third
    # of unreserved equity, and planned risk may not exceed 0.5% of that equity.
    cases=cases[cases.distance*cases.leverage*.97/3<=.005+1e-12]
    cases=cases.sort_values(['signal','rule','quality','symbol'],ascending=[True,True,False,True])
    one={s:bars(s,1) for s in cases.symbol.unique()}
    daily=pd.read_csv(HERE/'daily.csv.gz')
    daily=daily[~daily.stress]
    out=[]
    for begin in range(START+DAY,END-DAY,DAY):
        end=begin+DAY
        if ((cases.signal<begin)&(cases.exit>=begin)).any() or ((cases.signal<end)&(cases.exit>=end)).any():continue
        day=cases[(cases.signal>=begin)&(cases.signal<end)]
        peak=1.;net_upper=0.
        for r in day.itertuples():
            view=one[r.symbol][(r.fill-BASE)//M:(r.exit-BASE)//M+1]
            favorable=view[:,1].max() if r.side==1 else view[:,2].min()
            temporary=max(0.,r.net,r.side*(favorable/r.price-1)+sum(max(0.,v) for v in r.funding))
            # Drop reserve, fees in the sizing denominator, lot rounding, overlapping-position,
            # cap and funding-payment constraints to make this upper bound more generous.
            notional_ceiling=peak*(r.leverage/3)*(r.price/r.expected)
            net_upper+=notional_ceiling*max(0.,r.net)
            peak+=notional_ceiling*temporary
        date=pd.Timestamp(begin,unit='ms',tz='UTC').tz_convert('Asia/Seoul').date().isoformat()
        assert net_upper*100+1e-8>=daily[date].max(),date
        out.append(dict(date_kst=date,possible_opportunities=len(day),profitable_opportunities=int((day.net>0).sum()),
                        best_case_ceiling_pct=net_upper*100))
    assert out
    (HERE/'envelope.json').write_text(json.dumps({'scope':'Only the reproduced entries, four fixed wick/EMA opening windows, any scalp hour, fixed protected exits and original risk limits. This bound is intentionally unattainable and is not an actual strategy return. Only uncensored interior KST dates with no possible carry at either boundary are included.', 'observations':out},indent=2))
    print('First eligible day:',out[0],'checked',len(out),'bounds')
if __name__=='__main__':main()

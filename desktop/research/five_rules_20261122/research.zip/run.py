"""Compare causal filters on five protected, tick-replayed rules sharing a single account."""
from collections import Counter
from itertools import product
from pathlib import Path
import json
import os
import sys
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(Path(os.environ['PC_DAILY_SOURCE']).resolve()))
from study import closing_equity,prior
from data import BASE,CACHE,DAY,DAYSET,END,FLOW,LAST_DAY,M,START,bars

FAMILIES=json.loads((HERE/'plan.json').read_text())['families']
TL='wick_touch_trend_long'
TS='wick_touch_trend_short'

def trend_paths():
    historical=pd.read_pickle(FLOW/'cache/variants.pkl')
    historical=historical[historical.rule.isin([TL,TS])&(historical['mode']=='current')].copy()
    recent=[]
    for file in sorted((DAYSET/'cache').glob('*.events')):
        for r in json.loads(file.read_text()):
            if r['rule'] not in (TL,TS) or r['mode']!='current':continue
            one=prior.tape(r['symbol']).one
            begin=(r['fill']-BASE)//M+1
            end=(r['exit']-BASE)//M
            fidx=np.flatnonzero(one[begin:end+1,5])+begin
            r.update(group='wick',clock=r['signal'],leverage=r['lev'],flags=1,cap=4,
                     hold=45 if r['rule']==TL else 120,mfe=np.nan,reason=0,
                     tick=float(prior.engine.tr.meta()[r['symbol']]['tickSz']),
                     funding_t=(BASE+fidx*M).tolist(),funding=(-r['side']*one[fidx,0]*one[fidx,5]/r['price']).tolist())
            recent.append(r)
    ids={k:3000000+i for i,k in enumerate(sorted({(r['symbol'],r['rule'],r['signal']) for r in recent}))}
    for r in recent:r['id']=ids[(r['symbol'],r['rule'],r['signal'])]
    return pd.concat([historical,pd.DataFrame(recent)],ignore_index=True)

def signal_features(symbol,frame):
    five=bars(symbol,5)
    series=pd.Series(five[:,3])
    mid=series.rolling(20).mean().to_numpy()
    dev=2*series.rolling(20).std(ddof=0).to_numpy()
    lower=mid-dev
    long_t=sorted(frame.loc[frame.rule==prior.REV_LONG,'signal'])
    out=[]
    for r in frame.itertuples():
        j=(r.signal-BASE)//(5*M)-1
        family='scalp' if r.rule==prior.SCALP else 'trend' if r.rule in (TS,TL) else 'reversal'
        target=mid[j] if family=='reversal' else mid[j]+r.side*dev[j]
        room=r.side*(target/r.quote-1)>=.006
        flow=bool(r.flags&64) if r.signal<LAST_DAY else bool(r.breadth) if family!='scalp' else False
        op,high,low,close=five[j,:4]
        strong=family=='scalp' and r.quality>=3 and close-low>=.75*(high-low)
        reclaim=bool(np.count_nonzero(five[j-6:j,2]<lower[j-6:j])>=3 and mid[j-1]<mid[j-6]
                     and five[j-1,3]<five[j-6,3] and low<=lower[j] and close>=lower[j])
        i=np.searchsorted(long_t,r.signal,side='left')
        linked=i>0 and 0<r.signal-long_t[i-1]<=30*5*M
        masks={'reversal':(True,room,room and flow),'trend':(True,flow,room and flow),
               'scalp':(True,strong,reclaim,linked)}
        out.append((r.id,family,sum(1<<k for k,on in enumerate(masks[family]) if on)))
    return out

def evaluate_portfolio(rows,stress,censored):
    stats,book=prior.engine.simulate(rows,'base','current',START,END,'wick',stress)
    paths={r.id:r for r in rows}
    balances=np.array([150.]+[closing_equity(book,paths,day,stress) for day in range(START+DAY,END+1,DAY)])
    daily=100*(balances[1:]/balances[:-1]-1)
    checked=daily[:-1] if censored else daily
    assert len(daily)==60 and abs(balances[-1]-stats['final'])<1e-7
    first=checked[:30];second=checked[30:]
    summary=dict(trades=stats['n'],final_usdt=balances[-1],first30_usdt=balances[30],
                 days_checked=len(checked),days_at_target=int((checked>=10-1e-10).sum()),
                 first_half_days_at_target=int((first>=10-1e-10).sum()),
                 second_half_days_at_target=int((second>=10-1e-10).sum()),
                 worst_day_pct=checked.min(),best_day_pct=checked.max(),
                 biggest_gain_usd=stats['biggest_gain_usd'],net_without_biggest=stats['without_biggest_usd'],
                 closed_drawdown_pct=stats['closed_dd_pct'],max_slots=stats['max_simultaneous'],
                 actual_fills_by_rule=json.dumps(dict(Counter(r['rule'] for r in book)),sort_keys=True))
    return summary,daily,book

def main():
    prior.engine.past_mark=prior.past_mark
    reversals=prior.reversals()
    cases=pd.concat([reversals[reversals.qualifies],trend_paths(),pd.read_pickle(CACHE/'scalp_paths.pkl')],ignore_index=True)
    cases=cases[(cases.signal>=START)&(cases.signal<END)]
    normal=cases[~cases.stress]
    assert normal.id.is_unique
    rules=pd.DataFrame([r for sym,frame in normal.groupby('symbol') for r in signal_features(sym,frame)],
                       columns=['id','family','allow'])
    cases=cases.merge(rules,on='id',validate='many_to_one')
    cases['hour']=(cases.signal//M//60+9)%24
    stats=[];details=[];examples=[]
    for (_,_,stress),ordered in prior.engine.ordered(cases).items():
        rank={r.id:i for i,r in enumerate(ordered)}
        assert len(rank)==len(ordered)
        parts={}
        for family,variants in FAMILIES.items():
            for k,variant in enumerate(variants):
                windows=range(0,24,4) if family=='scalp' else [-1]
                for h in windows:
                    subset=[r for r in ordered if r.family==family and (r.allow&(1<<k)) and (h<0 or h<=r.hour<h+4)]
                    parts[family,k,h]=subset
                    directions=(prior.REV_LONG,prior.REV_SHORT) if family=='reversal' else (TL,TS) if family=='trend' else (prior.SCALP,)
                    for rule in directions:
                        result,_,_=evaluate_portfolio([r for r in subset if r.rule==rule],stress,h==20)
                        stats.append(dict(account='standalone',name=f'{rule}|{variant}|{h}',stress=stress,**result))
        for i,j,k,h in product(range(3),range(3),range(4),range(0,24,4)):
            rows=sorted(parts['reversal',i,-1]+parts['trend',j,-1]+parts['scalp',k,h],key=lambda r:rank[r.id])
            result,daily,book=evaluate_portfolio(rows,stress,h==20)
            tag='|'.join([FAMILIES['reversal'][i],FAMILIES['trend'][j],FAMILIES['scalp'][k],str(h)])
            stats.append(dict(account='shared',name=tag,stress=stress,**result))
            details.append([tag,stress,*daily])
            if (i,j,k,h)==(1,1,3,16):
                examples.extend(dict(x,stress=stress) for x in book)
    s=pd.DataFrame(stats);s.to_csv(HERE/'runs.csv',index=False)
    pd.DataFrame(details,columns=['combination','stress',*pd.date_range('2026-09-23',periods=60).strftime('%Y-%m-%d')]).to_csv(HERE/'daily.csv.gz',index=False)
    pd.DataFrame(examples).to_csv(HERE/'example_fills.csv.gz',index=False)
    shared=s.query("account=='shared' and not stress")
    assert len(shared)==216 and len(s.query("account=='standalone' and not stress"))==36
    assert np.all(shared.days_checked>=59)
    print('Combinations:',len(shared),'that met every daily close:',int((shared.days_at_target==shared.days_checked).sum()),flush=True)
    print('Observed first-half and second-half passes:',int((shared.first_half_days_at_target==30).sum()),int((shared.second_half_days_at_target==(shared.days_checked-30)).sum()),flush=True)
if __name__=='__main__':main()

from fetch import *
import sys
sys.path.insert(0,str(Path('pc260').resolve()))
import market_check as m, account_check as ac
from types import SimpleNamespace
# Use new day with four-day warmup, concatenate eligible prior rows by timestamp for rolling account.
m.run(SimpleNamespace(start='2026-11-21',end='2026-11-22',workers=4,fee=.0005,slip=.0005,close_only=False,out='cache/scheduled_day.pkl'))
ac.END=E
old=pd.read_pickle('pc260/market_cache/opportunities.pkl');today=pd.read_pickle('cache/scheduled_day.pkl')
joined=pd.concat([old[old.entry>=E-60*86400000],today[today.entry>=S]]).drop_duplicates(['entry','rule','symbol','hold'])
joined.to_pickle('cache/scheduled_60.pkl')
def audit(p):
 x=ac.audit(p,json.loads(Path('ins.json').read_text()));return {k:v for k,v in x.items() if k in ('fresh_gate','signals_without_qualification')}
r={'day':audit('cache/scheduled_day.pkl'),'rolling60':audit('cache/scheduled_60.pkl'),'by_rule':{}}
for k in m.timing.policies():
 joined[joined.rule==k].to_pickle('cache/one_rule.pkl');r['by_rule'][k]=audit('cache/one_rule.pkl')
Path('cache/schedule.json').write_text(json.dumps(r))
print(r['day'],r['rolling60'])

from fetch import *
import pickle,sys
root=Path.cwd();d=root/'exchange_frames';d.mkdir(exist_ok=True)
for name in ['OKX_PC_PACKAGE','target_research','wick_touch_review','timing_research','ins.json','pc260']:
 if not (d/name).exists():(d/name).symlink_to((root/name).resolve())
dest=d/'target_cache/recent';dest.mkdir(parents=True,exist_ok=True)
for sym in syms:
 for k in (1,5,15):
  p=root/'target_cache/recent'/f'{sym}-{k}.npy'
  if k==1:
   if not (dest/p.name).exists():(dest/p.name).symlink_to(p)
  else:
   a=np.load(p);rows=json.loads((P/'native'/f'{sym}-{k}.json').read_text());a[-len(rows):,:5]=np.array([r[1:6] for r in rows],float);np.save(dest/p.name,a)
os.chdir(d)
from proxy import collect
baseline=pickle.load(open(root/'cache/setups.pkl','rb'));diff={}
for sym in syms:
 _,curr=collect(sym);prev=baseline[sym]
 diff[sym]=dict(count=len(curr),identical=(prev==curr),changes=len(set(x[0] for x in curr)^set(x[0] for x in prev)))
(root/'cache/native_setup_check.json').write_text(json.dumps(diff));print({s:v for s,v in diff.items() if not v['identical']},flush=True)
(d/'cache').mkdir(exist_ok=True);os.environ['PC_REPLAY_INPUT']=str(dest)
exec((root/'scheduled.py').read_text())

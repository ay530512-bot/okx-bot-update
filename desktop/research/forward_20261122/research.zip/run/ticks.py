from proxy import *
import math,pickle,threading,traceback
from zipfile import ZipFile
from signals import Probe
from pc_timing import indicators
from pc_sizing import leverage_for
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor,as_completed
D=Path('cache/minutes');D.mkdir(exist_ok=True)
A=pickle.load(open('cache/setups.pkl','rb'))
META=tr.meta()
CLOSES=np.stack([np.load(f'target_cache/recent/{s}-1.npy')[:,3] for s in syms])
class Tape:
 def __init__(self,s):
  self.s=s;self.b=np.load(f'target_cache/recent/{s}-1.npy');self.five=np.load(f'target_cache/recent/{s}-5.npy')
  self.old={}
  if any(BASE+a.start*M<S+3600000 for a,_ in A[s]):
   file=Path('../d1a62ad153ed/study/tick_cache')/(s+'-2026-11-20.zip')
   with ZipFile(file) as z:
    for member in z.namelist():
     if not member.endswith('.csv'):continue
     for tab in pd.read_csv(z.open(member),chunksize=100000):
      tab=tab[tab.created_time>=S-4*3600000]
      for k,v in tab.groupby((tab.created_time-BASE)//M):
       self.old[int(k)]=self.old.get(int(k),[])+[(int(t),int(i),float(p),float(sz),side) for t,i,p,sz,side in v[['created_time','trade_id','price','size','side']].itertuples(index=False,name=None)]
 @lru_cache(maxsize=500)
 def minute(self,k):
  s=self.s;t=BASE+k*M
  if self.b[k,4]==0:return []
  file=D/f'{s}-{t}.json'
  if file.exists():return json.loads(file.read_text())
  if k in self.old:rows=self.old[k]
  else:
   rows=[];kw={'type':2,'after':t+M}
   while True:
    page=api('market/history-trades',instId=s+'-USDT-SWAP',limit=100,**kw)
    if not page:break
    rows.extend([(int(r['ts']),int(r['tradeId']),float(r['px']),float(r['sz']),r['side']) for r in page if t<=int(r['ts'])<t+M])
    if min(int(r['ts']) for r in page)<t:break
    nxt=min(int(r['tradeId']) for r in page)
    if kw.get('type')==1 and nxt>=kw['after']:raise ValueError('cursor')
    kw={'type':1,'after':nxt}
  rows=sorted(set(map(tuple,rows)))
  assert rows and np.isclose(sum(r[3] for r in rows),self.b[k,4],rtol=1e-7) and np.allclose([max(r[2] for r in rows),min(r[2] for r in rows)],self.b[k,1:3],rtol=1e-9,atol=1e-15),(s,t,'minute reconciliation')
  file.write_text(json.dumps(rows));return rows
 def after(self,t):
  k=(t-BASE)//M
  while k<len(self.b):
   for r in self.minute(k):
    if r[0]>t:return r
   k+=1
  return None
 def signal(self,a):
  obs=Probe(a);s=a.side
  for k in range(a.start,a.end):
   o,h,l,c,v=self.b[k,:5]
   if v<=0:continue
   lo,hi=(l,h) if s==1 else (-h,-l)
   eps=a.tick*1e-5
   if hi<a.lower-eps:return
   if not obs.armed and lo>=a.lower-eps and hi<a.depart-eps:continue
   if lo>a.upper+eps and (obs.bar!=k//5 or not math.isfinite(obs.low)):
    if not obs.armed and hi>=a.depart-eps:obs.armed=True
    continue
   for r in self.minute(k):
    extreme=obs.observe(k//5,s*self.five[k//5,0],s*r[2],s*r[2])
    if extreme is not None:return r,extreme
    if obs.done:return
 def outcome(self,a,entry,stop,hold,slip,arm,gap):
  s=a.side;fee=.0005;t=entry[0];p=entry[2]*(1+s*slip);risk=(p-stop)*s;deadline=t+hold*M
  def raised(best,old):
   if s*(best-p)<arm*risk:return old
   z=(best-s*gap*risk)/a.tick
   q=(math.floor(z+1e-10) if s==1 else math.ceil(z-1e-10))*a.tick
   return q if s*(q-old)>0 else old
  out=None;active=stop
  if risk<=0:out=self.after(t)
  for k in range((t-BASE)//M,min(len(self.b),(deadline-BASE)//M+2)):
   if out:break
   tm=BASE+k*M;o,h,l,c,v=self.b[k,:5]
   if not v:continue
   best,worst=(h,l) if s==1 else (l,h)
   new=raised(best,active)
   if tm>t and tm+M<=deadline and s*(worst-new)>0:
    active=new;continue
   for r in self.minute(k):
    if (r[0],r[1])<=(entry[0],entry[1]):continue
    if r[0]>=deadline:out=r;break
    if s*(r[2]-active)<=0:out=self.after(r[0]);break
    active=raised(r[2],active)
  if not out and deadline<E:out=self.after(deadline-1)
  if not out:return
  q=out[2]*(1-s*slip);k0=(t-BASE)//M+1;k1=(out[0]-BASE)//M;carry=-s*float(np.sum(self.b[k0:k1+1,0]*self.b[k0:k1+1,5]))/p
  gross=s*(out[2]-entry[2])/p;price=s*(q-p)/p;fees=fee*(p+q)/p
  return dict(fill=t,exit=out[0],price=p,exit_px=q,net=price-fees+carry,gross=gross,slip=gross-price,fees=fees,carry=carry)
 def complete(self,a,spec):
  hit=self.signal(a)
  if hit is None:return []
  r,ext=hit;t=r[0];s=a.side
  if not S<=t<E-spec['hold']*M or not tr.in_session(t,spec):return []
  anchor=a.level if a.family=='reversal' else ext
  stop=s*math.floor((anchor-max(2*a.tick,(.15 if a.family=='reversal' else .25)*a.atr))/a.tick+1e-9)*a.tick
  k=(t-BASE)//M;j=k//5
  ev=indicators([[0,*x[:5]] for x in self.five[j-32:j]],s,a.atr)
  if not ev:return []
  ev['stop']=stop;lev=leverage_for(ev,r[2],float(META[self.s]['lever']))
  if not lev:return []
  entry=self.after(t)
  if not entry:return []
  boundary=t//1000*1000
  ticks=[x for n in range((boundary-60000-BASE)//M,(boundary-1-BASE)//M+1) for x in self.minute(n) if boundary-60000<=x[0]<boundary]
  pre=[x for x in ticks if x[0]<boundary-10000];last=ticks[len(pre):]
  def share(xs):
   v=sum(x[2]*x[3] for x in xs);return sum(x[2]*x[3] for x in xs if x[4]==('buy' if s==1 else 'sell'))/v if v else -1
  d=s*(CLOSES[:,k-1]/CLOSES[:,k-16]-1);d[syms.index(self.s)]=np.nan;d=d[np.isfinite(d)]
  flow=len(last)>=5 and share(last)>=.6
  breadth=flow and len(d)>=20 and (d>0).mean()>=.6
  absorption=flow and len(pre)>=5 and share(pre)<=.4 and abs(pre[-1][2]-pre[0][2])<=.25*abs(r[2]-stop) and s*(last[-1][2]-last[0][2])>=a.tick*(1-1e-8)
  rows=[]
  for stress,slip in [(False,.0005),(True,.001)]:
   ep=r[2]*(1+s*slip);distance=s*(ep-stop)/ep+2*(.0005+slip)
   if (ep-stop)*s<=0:continue
   for mode,arm,gap in [('current',1,1),('runner',3,2)]:
    path=self.outcome(a,entry,stop,spec['hold'],slip,arm,gap)
    if path:
     moves={str(n):s*(self.b[k+n-1,3]/r[2]-1) if k+n<=len(self.b) else None for n in (5,15,30)}
     rows.append(dict(**path,symbol=self.s,signal=t,side=s,rule=a.rule,quality=a.quality,stop=stop,quote=r[2],lev=lev,distance=distance,expected=ep,breadth=bool(breadth),absorption=bool(absorption),stress=stress,mode=mode,moves_from_signal_minute=moves))
  return rows
def run(sym):
 path=P/(sym+'.events')
 if path.exists():return
 tape=Tape(sym);out=[]
 for a,spec in A[sym]:out+=tape.complete(a,spec)
 path.write_text(json.dumps(out));print(sym,len(A[sym]),len(out),flush=True)
if __name__=='__main__':
 with ThreadPoolExecutor(12) as p:
  jobs={p.submit(run,s):s for s in syms}
  for f in as_completed(jobs):
   try:f.result()
   except Exception as e:print(jobs[f],type(e).__name__,str(e),flush=True)

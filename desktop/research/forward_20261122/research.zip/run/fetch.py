import concurrent.futures as cf, json,time,os
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError
import numpy as np,pandas as pd
P=Path('cache');src=Path('../d1a62ad153ed/study/target_cache/recent')
S=int(pd.Timestamp('2026-11-21',tz='Asia/Seoul').timestamp()*1000); E=S+86400000;M=60000
BASE=(S-4*86400000)//86400000*86400000
syms=sorted(x.name.split('-')[0] for x in src.glob('*-1.npy'))
def api(endpoint,**kw):
 for j in range(4):
  try:
   r=json.load(urlopen(Request('https://www.okx.com/api/v5/'+endpoint+'?'+urlencode(kw),headers={'User-Agent':'OKX-public-research'}),timeout=20))
   if r['code']!='0':raise ValueError(r['code'])
   return r['data']
  except Exception:
   if j==3:raise
   time.sleep(1+j)
def fetch(sym):
 ins=sym+'-USDT-SWAP'; path=P/(sym+'.json')
 if path.exists():raw=json.loads(path.read_text())
 else:
  rows={};end=E
  while end>S:
   page=api('market/history-candles',instId=ins,bar='1m',after=end,limit=300)
   if not page:break
   rows.update({int(r[0]):r for r in page if S<=int(r[0])<E and r[8]=='1'})
   n=min(int(r[0]) for r in page)
   if n>=end:raise ValueError('no progress')
   end=n
  f=api('public/funding-rate-history',instId=ins,before=S-1,after=E,limit=100)
  raw=dict(rows=list(rows.values()),funding=f);path.write_text(json.dumps(raw))
 n=(E-BASE)//M;one=np.full((n,6),np.nan);cut=(S-BASE)//M;one[:cut]=np.load(src/(sym+'-1.npy'),mmap_mode='r')[-cut:];one[cut:,5]=0
 for r in raw['rows']:one[(int(r[0])-BASE)//M,:5]=r[1:6]
 for r in raw['funding']:
  t=int(r['fundingTime'])
  if S<=t<E:one[(t-BASE)//M,5]=float(r['realizedRate'] or r['fundingRate'])
 out=Path('target_cache/recent')
 np.save(out/(sym+'-1.npy'),one)
 for k in (5,15):
  b=one.reshape(-1,k,6);agg=np.column_stack([b[:,0,0],b[:,:,1].max(1),b[:,:,2].min(1),b[:,-1,3],b[:,:,4].sum(1),np.zeros(len(b)),np.zeros(len(b))]);np.save(out/(sym+f'-{k}.npy'),agg)
 return sym,len(raw['rows']),len(raw['funding'])
if __name__=='__main__':
 with cf.ThreadPoolExecutor(8) as p:
  for item in p.map(fetch,syms):print(*item,flush=True)

from fetch import *
import sys
sys.path[:0]=[str(Path(x).resolve()) for x in ['target_research','wick_touch_review','timing_research','OKX_PC_PACKAGE/runtime','OKX_PC_PACKAGE/core']]
import tick_replay as tr
from signals import minute_event
tr.PERIODS['recent']=('2026-11-21','2026-11-22')
def collect(sym):
 bars=np.load('target_cache/recent/'+sym+'-1.npy'); setups,need=tr.eligible_setups('recent',sym,bars)
 out=[];items=[]
 for s in setups:
  spec=tr.configs()[s.rule];hit=minute_event(s,bars)
  if hit:
   k,ref,ext=hit;t=BASE+(k+1)*M
   if S<=t<E and tr.in_session(t,spec):out.append([sym,s.rule,t,ref,s.level,s.atr])
  items.append((s,spec))
 return out,items
if __name__=='__main__':
 import pickle
 all_rows=[];setup_map={}
 for sym in syms:
  r,items=collect(sym);all_rows.extend(r);setup_map[sym]=items
 pd.DataFrame(all_rows,columns=['sym','rule','ts','ref','level','atr']).to_csv('cache/proxy.csv',index=False)
 with open('cache/setups.pkl','wb') as f:pickle.dump(setup_map,f)
 print(len(all_rows),sum(map(len,setup_map.values())))

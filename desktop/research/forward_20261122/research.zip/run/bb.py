from pathlib import Path
import os,sys,json,math
import numpy as np,pandas as pd
from bb_filter import preceding_decline_and_pause
ROOT=Path(__file__).resolve().parent
OLD=(ROOT/'../d1a62ad153ed/study').resolve()
new=sys.argv[1]=='new'
os.chdir(ROOT if new else OLD)
sys.path.insert(0,str(OLD/'wick_touch_review'))
import tick_replay as tr
if new:tr.PERIODS['recent']=('2026-11-21','2026-11-22')
base,_,_=tr.dates('recent')
if new:
 files=list((ROOT/'cache').glob('*.events'));df=pd.DataFrame([r for f in files for r in json.loads(f.read_text())]);df=df[~df.stress & (df['mode']=='current')].copy()
else:df=pd.read_pickle(ROOT/'flow_source/cache/variants.pkl').query("group=='wick' and not stress and mode=='current'").copy()
df=df[df.rule.str.contains('reversal')]
stats=[]
for sym,block in df.groupby('symbol'):
 one=np.load(tr.location('recent')/f'{sym}-1.npy',mmap_mode='r');five=np.load(tr.location('recent')/f'{sym}-5.npy',mmap_mode='r')
 setups,_=tr.eligible_setups('recent',sym,one);cs=pd.Series(five[:,3]);ma=cs.rolling(20).mean().to_numpy();sig=cs.rolling(20).std(ddof=0).to_numpy()
 for r in block.itertuples():
  k=(r.signal-base)//60000;j=k//5;s=r.side;matches=[a for a in setups if a.rule==r.rule and a.start<=k<a.end and a.quality==r.quality and abs(s*math.floor((a.level-max(2*a.tick,.15*a.atr))/a.tick+1e-9)*a.tick-r.stop)<a.tick/5]
  assert len(matches)==1,(r.symbol,r.signal,len(matches))
  a=matches[0];i=a.source;ix=np.arange(i-5,i+1)
  ext=five[ix,2] if s==1 else -five[ix,1];band=s*ma[ix]-2*sig[ix];hits=np.where(ext<band)[0]
  approach=(len(hits)>=3 and ext[hits[-1]]<ext[hits[0]] and s*(cs.iloc[i]-cs.iloc[i-6])<=-a.atr and s*(ma[i]-ma[i-5])<0)
  b=five[i+1:j,:];pause=2<=len(b)<=5 and b[:,1].max()-b[:,2].min()<=1.5*a.atr and abs(b[-1,3]-b[0,0])<=.5*a.atr and (b[:,2].min()>a.level if s==1 else -b[:,1].max()>a.level)
  count,ap,pa=preceding_decline_and_pause(five,ma,sig,i,j,s,a.atr)
  assert (count,ap,pa)==(len(hits),bool(approach),bool(pause))
  stats.append([sym,r.rule,r.signal,r.stop,i,len(hits),len(b),bool(approach),bool(pause),bool(approach and pause)])
pd.DataFrame(stats,columns='symbol rule signal stop anchor breaches pause_bars approach pause eligible'.split()).to_csv(ROOT/'cache'/('bb_'+sys.argv[1]+'.csv'),index=False)
print(len(stats),sum(x[-1] for x in stats))

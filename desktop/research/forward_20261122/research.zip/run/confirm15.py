from fetch import *
from concurrent.futures import ThreadPoolExecutor
native=P/'native';native.mkdir(exist_ok=True)
def check(arg):
 s,k=arg
 path=native/f'{s}-{k}.json'
 if path.exists():bars=json.loads(path.read_text())
 else:
  data=api('market/history-candles',instId=s+'-USDT-SWAP',bar=f'{k}m',after=E,limit=300)
  bars=sorted([r for r in data if S<=int(r[0])<E and r[8]=='1'],key=lambda r:int(r[0]))
  path.write_text(json.dumps(bars))
 assert [int(r[0]) for r in bars]==list(range(S,E,k*M)),(s,k,len(bars))
 v=np.array([x[1:6] for x in bars],dtype=float);b=np.load(f'target_cache/recent/{s}-1.npy')[-1440:,:5].reshape(-1,k,5);raw=np.load(f'target_cache/recent/{s}-{k}.npy')[-1440//k:,:5]
 active=[]
 for chunk in b:
  sub=chunk[chunk[:,4]>0];q=sub if len(sub) else chunk
  active.append([q[0,0],q[:,1].max(),q[:,2].min(),q[-1,3],q[:,4].sum()])
 ok=np.isclose(v,active,rtol=1e-9,atol=1e-12).all(axis=1)
 return f'{s}-{k}',dict(n=len(bars),valid=int(ok.sum()),mismatches=np.flatnonzero(~ok).tolist(),simple_difference=int((~np.isclose(v,raw,rtol=1e-9,atol=1e-12).all(axis=1)).sum()))
with ThreadPoolExecutor(8) as p:r=dict(p.map(check,[(s,k) for s in syms for k in (5,15)]))
Path('cache/frames_check.json').write_text(json.dumps(r))
Path('cache/validated_15m.json').write_text(json.dumps({s:r[s+'-15']['valid'] for s in syms}));print({k:[sum(v[x] for key,v in r.items() if key.endswith('-'+str(k))) for x in ['n','valid','simple_difference']] for k in [5,15]})

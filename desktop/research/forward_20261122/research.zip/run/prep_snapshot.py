from fetch import *
import hashlib,zipfile
with zipfile.ZipFile('publish/okx_20261121_kst.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for s in syms:
  j=json.loads((P/(s+'.json')).read_text());rs=sorted(j['rows'],key=lambda r:int(r[0]))
  assert len(rs)==1440 and [int(r[0]) for r in rs]==list(range(S,E,M)) and all(r[-1]=='1' for r in rs)
  z.writestr(s+'.json',json.dumps(dict(rows=rs,funding=j['funding']),separators=(',',':')))

import sys,os,subprocess,json,hashlib
from pathlib import Path
from functools import lru_cache
import pandas as pd,numpy as np
ROOT=Path(__file__).resolve().parent;OLD=(ROOT/'../d1a62ad153ed').resolve()
os.chdir(OLD/'study');sys.path.insert(0,str(OLD/'flow260'))
import evaluate as e
from features import tapes
prior=pd.read_pickle(e.CACHE/'variants.pkl');prior=prior[prior.group=='wick'].copy()
dates={s:int(pd.Timestamp(s,tz='Asia/Seoul').timestamp()*1000) for s in ['2026-09-22','2026-09-23','2026-11-21','2026-11-22']}
S,E=list(dates.values())[-2:]
bb=pd.read_csv(ROOT/'cache/bb_old.csv'); bbkeys=set(zip(bb[bb.eligible].symbol,bb[bb.eligible].rule,bb[bb.eligible].signal))
def old_abs(group):
 ts,px=tapes(group.name,False)
 mirror=e.CACHE/group.name/'absorption_ticks.npy';extra=np.load(mirror,mmap_mode='r') if mirror.exists() else None
 out=[]
 for r in group.itertuples():
  boundary=r.signal//1000*1000;cuts=[boundary-60000,boundary-10000,boundary]
  a,b,c=ts.searchsorted(cuts);p=px
  if (b-a,c-b)!=(r.n50,r.n10):a,b,c=extra['ts'].searchsorted(cuts);p=extra['px']
  if abs(p[b-1]-p[a])<=.25*abs(r.quote-r.stop) and r.side*(p[c-1]-p[b])>=r.tick*(1-1e-8):out.append(r.id)
 return out
abs_old=set()
for sym,g in prior.query("mode=='current' and not stress and n50>=5 and n10>=5 and flow50<=.4 and flow10>=.6").groupby('symbol'):
 g.name=sym;abs_old.update(old_abs(g))
prior['bb']=[(s,r,t) in bbkeys for s,r,t in zip(prior.symbol,prior.rule,prior.signal)]
prior['absorption']=prior.id.isin(abs_old)
original=e.past_mark
@lru_cache(maxsize=None)
def mark(symbol,scheduled,fill,now,side,entry):
 if fill<S:return original(symbol,scheduled,fill,now,side,entry)
 return json.loads(subprocess.check_output([sys.executable,str(ROOT/'mark.py'),symbol,str(fill),str(now),str(side)],cwd=ROOT))
e.past_mark=mark
raw=[]
if 'day' in sys.argv:
 nb=pd.read_csv(ROOT/'cache/bb_new.csv');newbb=set(zip(nb[nb.eligible].symbol,nb[nb.eligible].rule,nb[nb.eligible].signal))
 for file in (ROOT/'cache').glob('*.events'):raw+=json.loads(file.read_text())
 ids={k:1000000+i for i,k in enumerate(sorted(set((r['symbol'],r['rule'],r['signal']) for r in raw)))}
 for r in raw:
  key=(r['symbol'],r['rule'],r['signal']);r['id']=ids[key];r['bb']=key in newbb;r['group']='wick';r['flags']=1|(64 if r['breadth'] else 0);r['leverage']=r['lev'];r['clock']=r['signal'];r['cap']=4
  r['tick']=float(e.tr.meta()[r['symbol']]['tickSz']);r['hold']=e.tr.configs()[r['rule']]['hold'];r['mfe']=np.nan;r['reason']=0
  daybase=(S-4*86400000)//86400000*86400000
  candles=np.load(ROOT/f"target_cache/recent/{r['symbol']}-1.npy",mmap_mode='r');ix=np.flatnonzero(candles[:,5]!=0);times=daybase+ix*60000
  ix=ix[(times>r['fill'])&(times<=r['exit'])];r['funding_t']=(daybase+ix*60000).tolist();r['funding']=(-r['side']*candles[ix,0]*candles[ix,5]/r['price']).tolist()
full=pd.concat([prior,pd.DataFrame(raw)],ignore_index=True) if raw else prior
metrics=[];books={}
for span,a,b in ([('original',list(dates.values())[0],S)] if not raw else [('rolling',list(dates.values())[1],E),('day',S,E)]):
 for f,frame,bit in [('base',full,'base'),('reversal_control',full[full.rule.str.contains('reversal')],'base'),('participation',full,'participation'),('absorption',full[full.absorption],'base'),('bollinger_pause',full[full.bb],'base')]:
  if span=='original' and f not in ('bollinger_pause','reversal_control'):continue
  grouped=e.ordered(frame)
  for (g,mode,stress),rows in grouped.items():
   if mode not in ('current','runner'):continue
   for rule in [None,*sorted(set(prior.rule) if f not in ('bollinger_pause','reversal_control') else {k for k in prior.rule.unique() if 'reversal' in k})]:
    stat,book=e.simulate(rows,bit,mode,a,b,g,stress,rule=rule)
    stat.pop('hit2_opportunity',None)
    metrics.append(dict(span=span,filter=f,mode=mode,stress=stress,rule=rule or 'combined',**stat))
    if rule is None and span=='day':books[f+'-'+mode+'-'+str(stress)]=book
pd.DataFrame(metrics).to_csv(ROOT/('cache/metrics_'+('day' if raw else 'old')+'.csv'),index=False)
if raw:
 (ROOT/'cache/daybooks.json').write_text(json.dumps(books))
 for f,b in books.items():
  for row in b:
   r=next(x for x in raw if x['id']==row['id'] and x['mode']==('runner' if 'runner' in f else 'current') and x['stress']==f.endswith('True'))
   row.update({k:r[k]*row['notional'] for k in ('gross','fees','slip','carry')});row['margin']=row['notional']/row['leverage'];row['moves']=r['moves_from_signal_minute']
 (ROOT/'cache/daybooks.json').write_text(json.dumps(books))
print(pd.DataFrame(metrics).query("rule=='combined' and not stress and mode=='current'")[['span','filter','n','final','booked2']].to_string(index=False))

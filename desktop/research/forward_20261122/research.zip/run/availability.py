from fetch import *
from concurrent.futures import ThreadPoolExecutor
from urllib.error import HTTPError
from zipfile import ZipFile
import shutil
def tick(s):
 tag='2026-11-21';name=f'{s}-USDT-SWAP-trades-{tag}.zip';url=f'https://static.okx.com/cdn/okex/traderecords/trades/daily/20261121/{name}'
 dest=Path('tick_cache')/(s+'-'+tag+'.zip')
 try:
  with urlopen(Request(url,headers={'User-Agent':'public-replay'}),timeout=20) as r, dest.with_suffix('.part').open('wb') as f:shutil.copyfileobj(r,f)
  with ZipFile(dest.with_suffix('.part')) as z:assert z.testzip() is None
  os.replace(dest.with_suffix('.part'),dest);return s,200
 except HTTPError as e:return s,e.code
 except Exception as e:return s,str(e)
with ThreadPoolExecutor(10) as p:
 data=dict(p.map(tick,syms))
 Path('cache/archives.json').write_text(json.dumps(data))
 print(data)

from fetch import *
from collections import Counter
import zipfile,io,hashlib
C=Path('cache')
files=list(C.glob('*.events'));assert len(files)==31
raw=[r for f in files for r in json.loads(f.read_text())];all_rows=pd.DataFrame(raw)
result=pd.read_csv(C/'metrics_day.csv')
book=json.loads((C/'daybooks.json').read_text());frozen=book['base-current-False']
pairs=[]
for v in frozen:
 same=all_rows[(all_rows.symbol==v['symbol'])&(all_rows.rule==v['rule'])&(all_rows.signal==v['signal'])&~all_rows.stress].set_index('mode')
 a,b=same.loc['current'],same.loc['runner'];size=v['notional']
 assert abs(a['net']*size-v['usd'])<1e-8
 pairs.append(dict(symbol=v['symbol'],rule=v['rule'],signal=v['signal'],quantity=v['qty'],margin=v['margin'],leverage=v['leverage'],current_net=v['usd'],runner_net=b['net']*size,current_net_R=a['net']/a.distance,runner_net_R=b['net']/b.distance,fees_usdt=v['fees'],slip_usdt=v['slip'],funding_usdt=v['carry'],gross_usdt=v['gross']))
for v in raw:
 f=C/'moves'/f"{v['symbol']}-{v['signal']}.json"
 v['moves_asof_trade'] = json.loads(f.read_text())
 v.pop('moves_from_signal_minute',None)
for books in book.values():
 for v in books:
  v['moves']=json.loads((C/'moves'/f"{v['symbol']}-{v['signal']}.json").read_text())
today=json.loads((C/'schedule.json').read_text())
keep=['span','filter','mode','stress','rule','n','net_pct','final','closed_dd_pct','wins','booked2','without_biggest_usd','max_simultaneous']
summary=dict(end_exclusive_kst='2026-11-22T00:00:00+09:00',rolling_start_kst='2026-09-23',source_revision='27308be76be6889b9d71cf66ecd32dc56ea4783c',symbols=len(files),one_minute_confirmed=44640,funding_settlements=sum(len(json.loads((P/(s+'.json')).read_text())['funding']) for s in syms),fifteen_minute_direct_matches=sum(json.loads((C/'validated_15m.json').read_text()).values()),archive_status=json.loads((C/'archives.json').read_text()),verified_tick_minutes=len(list((C/'minutes').glob('*.json'))),tick_signal_count=len(set((v['symbol'],v['rule'],v['signal']) for v in raw)),matched_day=pairs,scheduled=today,decision='no release',bollinger_spec='bb_plan.json',bollinger_retrospective_through='2026-11-21 KST',day_halves='Flow candidates were frozen during Nov 21. Full day is mixed, not a new prospective sample; Bollinger parameters defined after close.',portfolio_risk='One third after reserving 3 USDT. No averaging. Up to 3 positions, 0.5% estimated single risk, 2% managed exposure. Costs 5bp fee and 5bp slippage per side, stress 10bp slippage.')
security_manifest={'pc_latest':json.loads(Path('pc260/pc_latest_20600.json').read_text()),'utc_public_archive_21':'404 at capture time; used OKX History trades and prior UTC+8 daily archive. REST used for the price-sensitive minutes, not an assumed intrabar OHLC order. High/low shortcut only where no stop or entry can trigger.'}
summary['provenance']=security_manifest
(C/'summary.json').write_text(json.dumps(summary,indent=2))
def dump(z,name,d):z.writestr(name,json.dumps(d,ensure_ascii=False,separators=(',',':')))
with zipfile.ZipFile('publish/research.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in ['summary.json','metrics_old.csv','metrics_day.csv','bb_old.csv','bb_new.csv','validated_15m.json','schedule.json']:
  z.write(C/f,'results/'+f)
 dump(z,'results/paired.json',pairs);dump(z,'results/day_books.json',book);dump(z,'results/events.json',raw)
 for f in ['fetch.py','availability.py','confirm15.py','proxy.py','ticks.py','moves.py','bb_filter.py','bb.py','accounts.py','scheduled.py','bb_plan.json','mark.py','finalize.py','prep_snapshot.py']:
  z.write(f,'run/'+f)
 digests={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (C/'minutes').glob('*.json')};dump(z,'results/tick_minute_sha256.json',digests)
r=result.query("rule=='combined' and not stress and mode=='current'")
print(r[keep[:2]+['n','final','booked2']].to_string(index=False))
print('day pair',len(pairs),sum(v['current_net'] for v in pairs),sum(v['runner_net'] for v in pairs))

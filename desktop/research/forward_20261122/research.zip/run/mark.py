from ticks import *
sym,fill,now,side=sys.argv[1:];fill,now,side=map(int,(fill,now,side));tape=Tape(sym);parts=[]
for k in range((fill-BASE)//M,(now-BASE)//M+1):
 tm=BASE+k*M
 if fill<=tm and tm+M<=now and tape.b[k,4]>0:
  v=tape.b[k];parts.extend([float(v[1] if side==1 else v[2]),float(v[3])])
 else:parts.extend(r[2] for r in tape.minute(k) if fill<=r[0]<now)
print(json.dumps([parts[-1],max(parts) if side==1 else min(parts)]))

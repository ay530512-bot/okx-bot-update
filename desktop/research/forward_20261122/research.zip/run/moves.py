from fetch import *
from concurrent.futures import ThreadPoolExecutor
import threading
work=P/'moves';work.mkdir(exist_ok=True)
def one(arg):
 sym,signal,price,side=arg
 target=work/f'{sym}-{signal}.json'
 if target.exists():return
 moves={}
 for n in (5,15,30):
  t=signal+n*M
  if t>=E:continue
  r=api('market/history-trades',instId=sym+'-USDT-SWAP',type=2,after=t+1,limit=1)[0]
  assert int(r['ts'])<=t
  moves[str(n)]=dict(horizon=t,tick_ts=int(r['ts']),move=side*(float(r['px'])/price-1))
 target.write_text(json.dumps(moves))
with ThreadPoolExecutor(8) as p:
 args={(r['symbol'],r['signal'],r['quote'],r['side']) for f in P.glob('*.events') for r in json.loads(f.read_text())}
 list(p.map(one,args))

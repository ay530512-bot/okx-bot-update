from bisect import bisect_left, bisect_right
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime
from functools import lru_cache
import json, sys, zipfile
import numpy as np
import pandas as pd
from get_bars import HERE, KST, SYMBOLS, START, SPLIT, END, STEP
from tapes import dayname, download
from pc_wick_alert import MarketWicks
from pc_wick_context import context,adverse_momentum
from pc_wick_entries import TTL_MS
from pc_sizing import indicators, leverage_for, round_stop
from pc_intraday import session_close_ms

@lru_cache(maxsize=2)
def daily(sym,day):
    archive=download((sym,day))
    with zipfile.ZipFile(archive) as z,z.open(z.namelist()[0]) as file:
        frame=pd.read_csv(file,usecols=['created_time','trade_id','price'],dtype={'created_time':'int64','trade_id':'int64','price':'float64'})
    times=frame['created_time'].to_numpy();ids=frame['trade_id'].to_numpy();px=frame['price'].to_numpy()
    assert len(times) and np.all(times[1:]>=times[:-1]) and np.all(ids[1:]==ids[:-1]+1) and np.all(px>0),(sym,day)
    return times,ids,px

def following(sym,t):
    for day in dict.fromkeys((dayname(t),dayname(t+86400000))):
        times,ids,prices=daily(sym,day)
        i=times.searchsorted(t)
        if i<len(times):return int(times[i]),int(ids[i]),float(prices[i])
    raise ValueError((sym,t,'missing next trade'))

def make_candidate(sym,h,history,tick,meta):
    side,ref,ts=h['side'],h['price'],h['ts']
    first=round_stop(h['first']-side*max(2*tick,.15*h['anchor_atr']),tick,side)
    ev=indicators(history,side,h['anchor_atr'])
    if not ev:return None
    ev['stop']=first
    c=context(history,h,tick)
    cloud=c['cloud']
    assert cloud
    opposed=cloud['position']==cloud['tk']==-side
    aligned=cloud['position']==cloud['tk']==side
    opposite_pattern=any(p['side']==-side for p in c['patterns'])
    weak=opposed or opposite_pattern
    selective=adverse_momentum(c,side)
    expiry=min(ts+TTL_MS,session_close_ms(ts)-1)
    second=h['second']
    wait=side*(ref-second)>max(2*tick,side*(second-h['first']))+tick*1e-6
    times,ids,prices=daily(sym,dayname(ts))
    lo=ids.searchsorted(h['trade_id'],side='right');hi=times.searchsorted(min(expiry,(ts//STEP+1)*STEP-1),side='right')
    retest=follow=None;near=float('inf');events=[]
    for i in range(lo,hi):
        t,tid,p=int(times[i]),int(ids[i]),float(prices[i])
        distance=side*(p-second);eps=tick*1e-6
        if distance < -eps:break
        if retest is None and near+tick-eps<=distance<=2*tick+eps:retest=(t,tid,p)
        if distance<=tick+eps:near=min(near,max(0.,distance))
        if follow is None and tick-eps<=side*(p-ref)<=2*tick+eps:follow=(t,tid,p)
    normal=(ts,h['trade_id'],ref)
    baseline=retest if wait else normal
    # Fixed before comparing realized outcomes. All candidates retain the jump retest.
    choices={'base':baseline,'aligned_only':baseline if aligned else None,
             'context_retest':retest if wait or weak else normal,
             'context_follow':baseline if wait or not weak else follow,
             'selective':baseline if wait or not selective else follow}
    paths={}
    for name,decision in choices.items():
        if not decision:continue
        t,tid,p=decision; deadline=min(expiry,(ts//STEP+1)*STEP-1) if t!=ts or wait else expiry
        fill=following(sym,t+1000)
        if fill[0]>deadline:continue
        # Model a fresh executable quote with the last public trade at send time.
        # The first following print approximates the market fill.
        idx=times.searchsorted(t+1000,side='right')-1
        if idx<0:continue
        quote=float(prices[idx])
        source=ids.searchsorted(h['trade_id'])
        if np.any(side*(prices[source:idx+1]-second)<-tick*1e-6):continue
        if side*(quote-second)<=0 or abs(quote-p)>.5*h['anchor_atr']:continue
        if (wait or (weak and name=='context_retest')) and side*(quote-second)>(2+1e-6)*tick:continue
        if ((name=='context_follow' and weak or name=='selective' and selective) and not wait
                and not (1-1e-6)*tick<=side*(quote-ref)<=(2+1e-6)*tick):continue
        level=leverage_for(ev,p,float(meta['lever']))
        if level==0:continue
        price=quote*(1+side*.0005)
        target=49.;lot=float(meta['lotSz']);ct=float(meta['ctVal'])
        qty=np.floor(target/((1/level+.0005)*price*ct*lot))*lot
        est=qty*ct*(side*(price-first)+price*.002)
        if (side*(price-first)<=0 or est>.735 or qty<float(meta['minSz']) or qty*ct*price/level<target*.97):continue
        paths[name]=dict(decision=t,reference=p,entry=fill[0],raw=fill[2],qty=float(qty*ct),level=level)
    return dict(symbol=sym,ts=ts,side=side,reference=ref,second=second,stop=first,tick=tick,
                wait=wait,cloud=cloud,rsi=c['rsi'],patterns=c['patterns'],weak=weak,selective=selective,paths=paths)

def run_symbol(sym):
    doc=json.loads((HERE/'data'/f'{sym}-bars.json').read_bytes())
    watched=set(json.loads((HERE/'data'/'candidates.json').read_bytes())[sym])
    rows,tick=doc['rows'],doc['tick']
    rule=MarketWicks(tick)
    pos=next(i for i,r in enumerate(rows) if r[0]>=START)
    rule.seed(rows[max(0,pos-60):pos])
    signals=[]
    for i in range(pos,len(rows)):
        row=rows[i];t=row[0]
        possible=any(d.anchor and (row[3] if side==1 else -row[2])<=d.anchor.zone+d.eps
                     for side,d in ((1,rule.long),(-1,rule.short)))
        if possible:
            assert t in watched,(sym,t)
            ts,ids,prices=daily(sym,dayname(t))
            lo,hi=ts.searchsorted([t,t+STEP])
            if hi>lo:
                arr=prices[lo:hi]
                assert abs(arr.max()-row[2])<tick*.01 and abs(arr.min()-row[3])<tick*.01,(sym,t,row,arr.min(),arr.max())
            for k in range(lo,hi):
                for h in rule.trade(int(ts[k]),int(ids[k]),float(prices[k]),True):
                    val=make_candidate(sym,h,rows[i-90:i],tick,doc['meta'])
                    if val:signals.append(val)
                if not rule.long.anchor and not rule.short.anchor:break
        rule.closed(row)
    file=HERE/'data'/f'{sym}-signals.json'
    file.write_text(json.dumps(signals,separators=(',',':')))
    print(sym,len(signals),sum(bool(s['paths']) for s in signals),flush=True)
    return signals

if __name__=='__main__':
    with ProcessPoolExecutor(4) as pool:
        all_signals=[s for group in pool.map(run_symbol,SYMBOLS) for s in group]
    print('Total signals',len(all_signals),'with entry',sum(bool(s['paths']) for s in all_signals),flush=True)
    (HERE/'data'/'all-signals.json').write_text(json.dumps(sorted(all_signals,key=lambda s:s['ts']),separators=(',',':')))

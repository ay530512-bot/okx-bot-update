from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from pathlib import Path
import json, os, sys, time, zipfile
from urllib.request import Request, urlopen
from shutil import copyfileobj
from get_bars import HERE, SYMBOLS, START, END, STEP
sys.path[:0] = [str(HERE/'OKX_PC_PACKAGE/runtime'),str(HERE/'OKX_PC_PACKAGE/core')]
from pc_wick_alert import first_wick, oriented, WINDOW

ARCHIVE = HERE/'data'/'tapes'
ARCHIVE.mkdir(exist_ok=True)
FILE_TZ = timezone(timedelta(hours=8))
def dayname(t):
    return datetime.fromtimestamp(t/1000,FILE_TZ).date().isoformat()

def collect(sym):
    d=json.loads((HERE/'data'/f'{sym}-bars.json').read_bytes())
    rows,tick=d['rows'],d['tick']
    watched=set()
    for side in (1,-1):
        sequence=[oriented(row,side) for row in rows]
        for i in range(55,len(sequence)-1):
            anchor=first_wick(sequence[max(0,i-59):i+1],tick)
            if not anchor:continue
            high,low=float('-inf'),float('inf')
            for row in sequence[i+1:i+1+WINDOW]:
                t,op,h,l,c,_=row
                if l<=anchor.zone+tick*1e-6:
                    watched.add(t)
                high,low=max(high,h),min(low,l)
                if l<=anchor.low+tick*1e-6 or high-low>1.5*anchor.atr+tick*1e-6:break
    return sorted(t for t in watched if START<=t<END)

def download(job):
    sym,day=job
    path=ARCHIVE/f'{sym}-{day}.zip'
    if path.is_file():return path
    name=f'{sym}-USDT-SWAP-trades-{day}.zip'
    url='https://static.okx.com/cdn/okex/traderecords/trades/daily/'+day.replace('-','')+'/'+name
    for attempt in range(4):
        try:
            tmp=path.with_suffix('.part')
            with urlopen(Request(url,headers={'User-Agent':'public-history-replay'}),timeout=30) as resp,tmp.open('wb') as dst:
                copyfileobj(resp,dst,262144)
            with zipfile.ZipFile(tmp) as z:
                assert len(z.namelist())==1 and z.namelist()[0].endswith('.csv')
            os.replace(tmp,path)
            return path
        except OSError:
            if attempt==3:raise
            time.sleep(1+attempt)

if __name__=='__main__':
    candidates={sym:collect(sym) for sym in SYMBOLS}
    (HERE/'data'/'candidates.json').write_text(json.dumps(candidates))
    jobs=sorted({(sym,dayname(t)) for sym,events in candidates.items() for t in events})
    print('Candidate intervals',sum(map(len,candidates.values())),'public daily archives',len(jobs),flush=True)
    with ThreadPoolExecutor(7) as pool:
        for n, future in enumerate(as_completed([pool.submit(download,j) for j in jobs]),1):
            future.result()
            if n%25==0 or n==len(jobs):print('Ready',n,'of',len(jobs),flush=True)

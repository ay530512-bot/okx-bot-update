from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict
from functools import lru_cache
from datetime import datetime
import json, threading
from get_bars import HERE, KST, START, SPLIT, END, SYMBOLS, public
from replay import following, round_stop, session_close_ms

MIN=60000
FEE=SLIP=.0005
@lru_cache(maxsize=4000)
def marks(sym,frame,end,limit):
    step=MIN if frame=='1m' else 1000
    raw=public.api.get('market/history-mark-price-candles',dict(instId=sym+'-USDT-SWAP',bar=frame,after=end,limit=limit))
    result={int(r[0]):list(map(float,r[1:5])) for r in raw if r[-1]=='1'}
    assert set(range(end-step*limit,end,step))<=result.keys(),(sym,frame,end,limit,len(result))
    return result

@lru_cache(maxsize=40)
def funding(sym):
    out={}
    cursor=END+MIN
    while cursor>START:
        raw=public.api.get('public/funding-rate-history',dict(instId=sym+'-USDT-SWAP',after=cursor,limit=100))
        if not raw:break
        for r in raw:out[int(r['fundingTime'])]=float(r['realizedRate'] or r['fundingRate'])
        last=min(int(r['fundingTime']) for r in raw)
        assert last<cursor
        cursor=last
    assert out and min(out)<=START,(sym,'funding')
    return out

def exit_time(s,path):
    sym,side,stop,tick=s['symbol'],s['side'],s['stop'],s['tick']
    start=path['entry'];deadline=session_close_ms(s['ts'])
    entry=path['raw']*(1+side*SLIP)
    active=stop
    risk=side*(entry-stop)
    if risk<=0:return start,'initial'
    def new(mark):
        if side*(mark-entry)<risk:return active
        p=round_stop(mark-side*risk,tick,side)
        return max(active,p) if side==1 else min(active,p)
    for m in range(start//MIN*MIN,deadline,MIN):
        block=(m//(100*MIN)+1)*100*MIN
        op,hi,lo,cl=marks(sym,'1m',block,100)[m]
        best,bad=(hi,lo) if side==1 else (lo,hi)
        if side*(new(best)-active)<=tick*1e-6 and side*(bad-active)>tick*1e-6:continue
        for t,(o,h,l,c) in sorted(marks(sym,'1s',m+MIN,60).items()):
            if t+1000<=start or t+1000>deadline:continue
            adverse=(l if side==1 else h) if t>=start else c
            if side*(adverse-active)<=tick*1e-6:
                return t+1000,'initial' if abs(active-stop)<tick*1e-6 else 'trail'
            active=new(c)
    return deadline,'day'

def calculate(s,path):
    sym,side=s['symbol'],s['side']
    trigger,reason=exit_time(s,path)
    stamp,_,raw=following(sym,trigger)
    carry=0.
    for ft,rate in funding(sym).items():
        if path['entry']<ft<=stamp:
            mark=marks(sym,'1m',ft+MIN,1)[ft][0]
            carry-=side*rate*mark
    def pnl(cost):
        ep=path['raw']*(1+side*cost);xp=raw*(1-side*cost)
        return path['qty']*(side*(xp-ep)-(ep+xp)*FEE+carry)
    return dict(exit=stamp,reason=reason,net=pnl(SLIP),stress=pnl(.001),
                early=reason=='initial' and trigger-path['entry']<=60_000,hold=stamp-path['entry'])

def go(sym):
    file=HERE/'data'/f'{sym}-signals.json'
    records=json.loads(file.read_bytes())
    for s in records:
        tracked={}
        for name,path in s['paths'].items():
            key=(path['entry'],path['qty'])
            if key not in tracked:tracked[key]=calculate(s,path)
            path.update(tracked[key])
    (HERE/'data'/f'{sym}-outcomes.json').write_text(json.dumps(records,separators=(',',':')))
    print('Completed',sym,len(records),flush=True)
    return records

def metrics(arr,key):
    paths=[s['paths'][key] for s in arr if key in s['paths']]
    return dict(n=len(paths),wins=sum(p['net']>0 for p in paths),early=sum(p['early'] for p in paths),
                init=sum(p['reason']=='initial' for p in paths),net=round(sum(p['net'] for p in paths),3),
                stress=round(sum(p['stress'] for p in paths),3))

if __name__=='__main__':
    arr=[]
    with ThreadPoolExecutor(6) as pool:
        for task in as_completed([pool.submit(go,s) for s in SYMBOLS]):arr.extend(task.result())
    arr.sort(key=lambda s:s['ts'])
    (HERE/'data'/'outcomes.json').write_text(json.dumps(arr,separators=(',',':')))
    summary={}
    for group,sample in [('early',[s for s in arr if s['ts']<SPLIT]),('late',[s for s in arr if s['ts']>=SPLIT]),('all',arr)]:
        summary[group]={k:metrics(sample,k) for k in ('base','aligned_only','context_retest','context_follow','selective')}
        print(group,len(sample),summary[group],flush=True)
    print('Patterns',[(s['symbol'],s['side'],[p['kind'] for p in s['patterns']]) for s in arr if s['patterns']],flush=True)
    (HERE/'data'/'summary.json').write_text(json.dumps(summary,indent=2))

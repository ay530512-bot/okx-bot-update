from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timedelta,timezone
from decimal import Decimal as D, ROUND_DOWN
from pathlib import Path
from threading import Lock,local
import hashlib,json,time,sys
import requests

KST=timezone(timedelta(hours=9)); ROOT=Path(__file__).resolve().parent/'checkdata'
class Public:
    def __init__(self):
        self.local=local();self.lock=Lock();self.next=0.
    def get(self,path,params,cached=True):
        name=ROOT/(hashlib.sha256((path+json.dumps(params,sort_keys=True)).encode()).hexdigest()+'.json')
        if cached and name.exists():return json.loads(name.read_text())
        if not hasattr(self.local,'http'):self.local.http=requests.Session()
        for n in range(4):
            with self.lock:
                pause=self.next-time.monotonic()
                if pause>0:time.sleep(pause)
                self.next=time.monotonic()+.13
            try:
                r=self.local.http.get('https://www.okx.com/api/v5/'+path,params=params,timeout=(8,14))
                r.raise_for_status();doc=r.json()
                if doc.get('code')!='0':raise ValueError(str(doc)[:90])
                data=doc['data']
                if cached:name.write_text(json.dumps(data,separators=(',',':')))
                return data
            except (requests.RequestException,ValueError):
                if n==3:raise
                time.sleep(1+n)
api=Public()
def marketbars(sym,frame,start,end,mark=False):
    path='market/history-'+('mark-price-' if mark else '')+'candles';cursor=end+1; rows={}
    # OKX mark-candle API caps each page at 100.
    while cursor>start:
        data=api.get(path,dict(instId=sym+'-USDT-SWAP',bar=frame,after=cursor,limit=100 if mark else 300))
        if not data:break
        for r in data:
            if r[-1]=='1' and start<=int(r[0])<=end:rows[int(r[0])]=r
        oldest=min(int(r[0]) for r in data)
        if oldest>=cursor:raise ValueError('stalled candle cursor')
        cursor=oldest
    return [rows[t] for t in sorted(rows)]
def instrument(sym):
    return api.get('public/instruments',dict(instId=sym+'-USDT-SWAP',instType='SWAP'))[0]

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from pathlib import Path
import json
import sys, os

HERE = Path(__file__).resolve().parent
import public_check as public
public.ROOT = HERE/'data'
public.ROOT.mkdir(exist_ok=True)
KST = timezone(timedelta(hours=9))
def stamp(day):
    return int(datetime.fromisoformat(day).replace(tzinfo=KST).timestamp()*1000)
DATES = ('2026-10-01','2026-10-16','2026-11-01') if os.environ.get('WICK_OCTOBER') else ('2026-11-01','2026-11-15','2026-11-22')
START, SPLIT, END = map(stamp,DATES)
STEP = 900_000
SYMBOLS = 'AVAX DOT ZAMA DGAI PNUT RAVE AKE ALLO JELLYJELLY AI CT CP ZRO ACT INIT PENDLE EDGE ARB LINK DOGE OP BONK'.split()

def fetch(sym):
    rows = public.marketbars(sym,'15m',START-96*STEP,END-STEP)
    meta = public.instrument(sym)
    assert meta['instId']==sym+'-USDT-SWAP'
    rows = [(int(r[0]),*map(float,r[1:6])) for r in rows]
    assert all(b[0]-a[0] == STEP for a,b in zip(rows,rows[1:])),sym
    data = {'rows':rows,'tick':float(meta['tickSz']),'meta':{k:meta[k] for k in ('ctVal','lotSz','minSz','lever')}}
    (HERE/'data'/f'{sym}-bars.json').write_text(json.dumps(data,separators=(',',':')))
    print(sym,len(rows),flush=True)

if __name__=='__main__':
    with ThreadPoolExecutor(7) as pool:
        for task in as_completed([pool.submit(fetch,s) for s in SYMBOLS]):
            task.result()

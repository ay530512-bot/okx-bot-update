"""Independent account replay of archived public-derived fills (standard library only).
Run after extracting research.zip: python reproduce.py
"""
from collections import Counter
import csv
import gzip
import json
import math
from pathlib import Path
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parent
M=60000
DAY=1440*M
FEE=.0005
LONG='wick_touch_reversal_long'
SHORT='wick_touch_reversal_short'
SCALP='volume_wick_scalp_long'

def subset(r,name):
    if name=='old_window_control':return r.old_qualifies
    if name=='all_three':return True
    if name=='reversal_both':return r.rule in (LONG,SHORT)
    if name=='reversal_long':return r.rule==LONG
    if name=='reversal_short':return r.rule==SHORT
    if r.rule!=SCALP:return False
    if name=='scalp':return True
    _,lo,hi=name.split('_')
    return int(lo)<=((r.signal//M+540)//60)%24<int(hi)

def simulate(inputs,records,lo,hi,stress):
    cash=150.;positions={};days=Counter();book=[]
    slip=.001 if stress else .0005
    def settle(t):
        nonlocal cash
        for k,(r,qty,nominal,planned) in sorted(list(positions.items()),key=lambda item:item[1][0].exit):
            if r.exit>t:break
            pnl=nominal*r.net;cash+=pnl;book.append(pnl);del positions[k]
    for r in records:
        if not lo<=r.signal or r.signal+r.hold*M>=hi:continue
        settle(r.signal);d=((r.signal+9*3600000)//DAY,r.rule)
        if days[d]>=r.cap or r.rule in positions or len(positions)>=3 or any(p[0].symbol==r.symbol for p in positions.values()):continue
        equity=cash;used=risk=0.
        for old,_,notional,planned in positions.values():
            if r.signal<=old.fill:
                used+=planned*(1/old.leverage+FEE);risk+=planned*old.distance
                continue
            mark,peak=inputs['marks'][f'{old.symbol}/{old.fill}/{r.signal}']
            s=old.side;structural=s*(old.price-old.stop);stop=old.stop
            if structural>0 and s*(peak-old.price)>=structural:
                z=(peak-s*structural)/old.tick
                trail=old.tick*(math.floor(z+1e-10) if s==1 else math.ceil(z-1e-10))
                if s*(trail-stop)>0:stop=trail
            funding=sum(v for t,v in zip(old.funding_t,old.funding) if t<=r.signal)
            equity+=notional*(s*(mark/old.price-1)-FEE+funding)
            used+=notional/old.leverage
            risk+=notional/old.price*(max(0,s*(mark-stop))+2*(FEE+slip)*mark)
        seed=max(0,equity-3);target=seed/3
        ct,lot,minimum,maximum=inputs['instruments'][r.symbol]
        qty=math.floor(target/(r.expected*ct*(1/r.leverage+FEE)*lot))*lot
        planned=qty*ct*r.expected
        if not minimum<=qty<=maximum or planned/r.leverage<.97*target or planned*(1/r.leverage+FEE)>seed-used:continue
        if planned*r.distance>min(.005*seed,.02*seed-risk):continue
        positions[r.rule]=(r,qty,qty*ct*r.price,planned);days[d]+=1
    settle(hi);assert not positions
    return len(book),cash

def main():
    with gzip.open(ROOT/'account_inputs.json.gz','rt') as f:data=json.load(f)
    cases=sorted([SimpleNamespace(**r) for r in data['cases']],key=lambda r:(r.signal,r.rule,-r.quality,r.symbol))
    ranges={'60d':(data['start'],data['end']),'first_30d':(data['start'],data['split']),'last_30d':(data['split'],data['end'])}
    with (ROOT/'accounts.csv').open() as f:expected=list(csv.DictReader(f))
    for target in expected:
        name=target['account'];phase=target['phase'];stress=target['stress']=='True'
        rows=[r for r in cases if r.stress==stress and subset(r,name)]
        n,cash=simulate(data,rows,*ranges[phase],stress)
        assert n==int(target['n']) and abs(cash-float(target['final']))<1e-7,(name,phase,stress,n,cash)
        if phase=='60d' and not stress:print(f'{name:20} {n:4d} {cash:10.4f} USDT')
    print(f'Confirmed {len(expected)} independent account, cost and time-period results.')
if __name__=='__main__':main()

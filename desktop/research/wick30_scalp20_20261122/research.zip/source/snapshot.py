"""Freeze the replay inputs and observable marks used at overlapping entries, without account data."""
import gzip
import json
from pathlib import Path
import numpy as np
import pandas as pd
import accounts as research
from data import CACHE,END,SPLIT,START
def main():
    marks={}
    original=research.past_mark
    def capture(sym,scheduled,fill,now,side,entry):
        key=f'{sym}/{fill}/{now}'
        v=original(sym,scheduled,fill,now,side,entry)
        if key in marks:assert marks[key]==v
        marks[key]=v
        return v
    research.past_mark=capture
    research.main()
    rev=research.reversals()
    rev=rev[rev.qualifies|rev.old_qualifies].copy()
    scalp=pd.read_pickle(CACHE/'scalp_paths.pkl')
    scalp['qualifies']=True;scalp['old_qualifies']=False
    rows=pd.concat([rev,scalp],ignore_index=True)
    cols='id rule symbol signal fill exit price expected side leverage stop distance net tick cap hold quality stress funding_t funding old_qualifies'.split()
    cases=rows[cols].to_dict(orient='records')
    data={'start':START,'split':SPLIT,'end':END,'instruments':research.engine.instruments(),'marks':marks,'cases':cases}
    with gzip.open(CACHE/'account_inputs.json.gz','wt',encoding='utf8') as f:json.dump(data,f,separators=(',',':'),allow_nan=False,default=lambda x: x.item() if isinstance(x,np.generic) else x.tolist())
    print('snapshot',len(cases),len(marks),flush=True)
if __name__=='__main__':main()

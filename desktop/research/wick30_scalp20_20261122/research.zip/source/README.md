# 시장 자료로 신호와 체결을 다시 만들기

간편 재현은 압축파일 최상위 reproduce.py에서 가능하다. 원시 재현에는 Python, NumPy, pandas, C++17 컴파일러와 거래소 공개 자료가 필요하다.

- PC_STUDY는 955e2b31a6475fcf79a475530d3fb38027c43701의 desktop/research/wick_touch_20261121 및 368221bdc7b9c7a4e012cc96a16212edd8858123의 target10 재현 자료를 푼 연구 루트다. timing_research, target_research, wick_touch_review, ins.json, target_cache, tick_cache를 이 루트에 둔다. 기존 실험 README의 1분·5분·15분 및 체결 다운로드/대조 절차를 사용한다.
- PC_RELEASE는 27308be76be6889b9d71cf66ecd32dc56ea4783c의 desktop/research/pc260과 같은 버전의 배포 ZIP에서 OKX_PC_PACKAGE/runtime 및 core를 푼 경로다. 같은 위치에 wick_recheck.py를 둔다.
- PC_FLOW는 압축파일의 source/flow260 코드와 해당 공개 시장 중간 캐시를 두는 경로다. PC_STUDY에서 collect_signals.py, extract.py, features.py 순으로 실행해 cache/candidates.pkl, cache/variants.pkl, 원시 자료 추출기 cache/aggregate를 생성한다. 기존 연구 스크립트의 PC_RELEASE, PC_STUDY 변수를 전달한다.
- PC_DAYSET는 f05b0819342fe846e18d962172b18a6dc68dde23의 desktop/research/forward_20261122에서 해당 날짜의 31종목 봉·펀딩 자료와 연구 ZIP을 복원한 경로다. 원래 검증의 fetch.py, proxy.py, ticks.py, bb.py와 연구 ZIP의 기존 결과로 target_cache/recent, cache/bb_old.csv, cache/bb_new.csv, cache/setups.pkl 및 cache/*.events를 준비한다. 거래소 5분/15분봉 대조본은 exchange_frames/target_cache/recent에 둔다. 이 문서의 4개 경로 변수는 절대경로로 설정한다.

그 후 source/ 아래의 다음 스크립트를 순서대로 실행한다. 연구의 원자료 처리는 9월 23일~11월 21일 KST로 고정돼 있다. 미래의 마감된 구간에는 날짜 범위를 옮기고 신호를 새로 만든다.

```shell
python scalp.py
python scalp_tapes.py
python reversal.py
python scalp_replay.py
python snapshot.py
python exit_audit.py
python check.py
```

reversal.py는 일반 반전의 기존 첫 반응 기회에서 1~30번째인지 확인하고 볼린저 하단·상단 접근과 횡보를 검증한다. 바로 다음 봉의 신호는 기존 거래 ID 순서로 정렬된 체결을 하나씩 다시 읽어 같은 타점에서 멈춘 뒤 횡보 폭을 검사한다. scalp_tapes.py는 기존 대조를 통과한 분의 체결과 OKX 일별·월별 체결을 사용한다. 추가로 읽은 기록은 분별 거래량·고저와 대조한다. 최근 일별 ZIP이 없는 구간은 history-trades에서 시간/거래 ID로 페이지를 순회해 확인한다. 원시 재현에서 최초 신호·비용·계좌 판단을 바꾸면 별도 실험으로 구분한다.

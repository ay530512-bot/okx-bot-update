"""Create closed-candle scalp signals. Later candles are used only to model exit rules."""
import json
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import pandas as pd

from data import BASE,CACHE,COINS,END,M,START,STUDY,bars,indicators,leverage_for,round_stop

def wick_flags(five,tick):
    """Boolean candle definitions; current volume is compared to earlier completed bars only."""
    op,high,low,close,volume = five[:,:5].T
    cl = pd.Series(close)
    spread = high-low
    mean_volume = pd.Series(volume).rolling(20).mean().shift().to_numpy()
    relative = np.divide(volume,mean_volume,out=np.zeros_like(volume),where=mean_volume>0)
    upper = (cl.rolling(20).mean()+2*cl.rolling(20).std(ddof=0)).to_numpy()
    tolerance = tick*1e-7
    bullish = (spread>0)&(close>op)&(op-low+tolerance>=.5*spread)&(relative>=2)&(volume>0)
    bearish = (spread>0)&(close<op)&(high-op+tolerance>=.5*spread)&(high+tolerance>=upper)&(volume>0)
    return bullish,bearish,relative

def exit_boundary(bearish,signal_bar):
    subsequent=np.flatnonzero(bearish[signal_bar+1:signal_bar+21])
    return (int(subsequent[0])+1,True) if len(subsequent) else (20,False)

def candidates(symbol):
    five = bars(symbol,5)
    op,high,low,close,volume = five[:,:5].T
    instrument = next(x for x in json.loads((STUDY/'ins.json').read_text())['data'] if x['instId']==symbol+'-USDT-SWAP')
    tick = float(instrument['tickSz'])
    bullish,bearish,relative=wick_flags(five,tick)
    prev = pd.Series(close).shift().to_numpy()
    atr = pd.Series(np.maximum.reduce((high-low,abs(high-prev),abs(low-prev)))).rolling(14).mean().to_numpy()
    res=[];rejected=0
    for j in np.flatnonzero(bullish):
        signal=BASE+(int(j)+1)*5*M
        if not START<=signal<END-100*M:continue
        stop=round_stop(float(low[j])-max(2*tick,.15*atr[j]),tick,1)
        ev=indicators([[0,*row] for row in five[j-31:j+1,:5]],1,atr[j]) if (close[j]-stop)/close[j]<=.00300000001 else None
        lev=leverage_for(dict(ev,stop=stop),close[j],float(instrument['lever'])) if ev else 0
        if not lev:
            rejected+=1
            continue
        count,band=exit_boundary(bearish,j)
        res.append(dict(symbol=symbol,signal=signal,quote=close[j],tick=tick,stop=stop,leverage=lev,
                        quality=relative[j],exit_bar=count,deadline=signal+count*5*M,band=band))
    print(symbol,'raw',len(res)+rejected,'risk-admitted',len(res),flush=True)
    return res, rejected

if __name__=='__main__':
    with ProcessPoolExecutor(4) as pool:
        results=list(pool.map(candidates,COINS))
    allrows=[r for group,_ in results for r in group]
    pd.DataFrame(allrows).sort_values(['signal','symbol']).to_pickle(CACHE/'scalps.pkl')
    (CACHE/'scalp_counts.json').write_text(json.dumps({'setup_candidates':sum(n+len(g) for g,n in results),'leverage_admitted':len(allrows)}))
    print(len(allrows),flush=True)

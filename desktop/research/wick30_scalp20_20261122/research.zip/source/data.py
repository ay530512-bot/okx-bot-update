"""Read matching fixed public market snapshots to replay the two independent rules."""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
STUDY = Path(os.environ.get('PC_STUDY', HERE.parent / 'study')).resolve()
PC = Path(os.environ.get('PC_RELEASE', HERE.parent / 'pc260')).resolve()
FLOW = Path(os.environ.get('PC_FLOW', HERE.parent / 'flow260')).resolve()
DAYSET = Path(os.environ['PC_DAYSET']).resolve()
CACHE = HERE / 'cache'
CACHE.mkdir(exist_ok=True)
os.chdir(STUDY)
sys.path[:0] = [str(STUDY/'timing_research'),str(PC/'OKX_PC_PACKAGE/runtime'), str(PC/'OKX_PC_PACKAGE/core'), str(STUDY/'wick_touch_review'), str(STUDY/'target_research'), str(FLOW)]
from pc_sizing import leverage_for
from pc_timing import indicators, round_stop
import pc_monthly
from inputs import COINS, dates

M = 60000
DAY = 1440*M
BASE, _, LAST_DAY = dates('recent')
DAYBASE = (LAST_DAY - 4*DAY)//DAY*DAY
END = LAST_DAY+DAY
START = END-60*DAY
SPLIT = START+30*DAY

def bars(symbol, n):
    old = np.load(STUDY/f'target_cache/recent/{symbol}-{n}.npy')
    verify = DAYSET/'exchange_frames/target_cache/recent'
    folder = verify if (verify/f'{symbol}-{n}.npy').exists() else DAYSET/'target_cache/recent'
    new = np.load(folder/f'{symbol}-{n}.npy')
    assert BASE+len(old)*M*n == LAST_DAY and DAYBASE+len(new)*M*n == END
    out = np.concatenate([old, new[-1440//n:]])
    assert np.isfinite(out[(START-BASE)//(M*n):,:5]).all(),symbol
    return out

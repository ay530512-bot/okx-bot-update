"""Boundary, no-look-ahead, exchange-order and account regressions for this study."""
import json
from functools import lru_cache
import numpy as np
import pandas as pd
from data import BASE,CACHE,M,END
from bb_filter import within_retest_window,preceding_decline_and_pause,close_bands
from scalp import wick_flags,exit_boundary
from scalp_replay import advance_stop,simulate
from prints import Prints

def checks():
    assert [within_retest_window(50,n) for n in (50,51,52,79,80,81)]==[False,True,True,True,True,False]
    a=np.zeros(43,dtype=bool)
    for j,want in [(1,(20,False)),(2,(1,True)),(21,(20,True)),(22,(20,False))]:
        a[:]=False;a[j]=True;assert exit_boundary(a,1)==want
    a[8]=True;a[10]=True;assert exit_boundary(a,1)==(7,True)
    # Last candle at exactly twice preceding mean and exactly half wick; extra future bars have no effect.
    five=np.tile([100.,101.,99.,100.,10.],(50,1));five[32]=[100,101,99,100.8,20]
    before=wick_flags(five[:33],.01)[0][-1];five[33:]=[300,900,250,700,900]
    assert before and wick_flags(five,.01)[0][32]
    five[32,4]=19.99;assert not wick_flags(five,.01)[0][32]
    five[32]=[100.,102.,99.,99.5,20];assert wick_flags(five,.01)[1][32]
    five[32,3]=100.5;assert not wick_flags(five,.01)[1][32]
    assert advance_stop(100.99,99.,100.,1.,.01)==99.
    assert advance_stop(101.,99.,100.,1.,.01)==100.
    assert advance_stop(100.5,100.2,100.,1.,.01)==100.2

def outcome_benchmark(r,tape,slip):
    k,i,t,raw=tape.first(r.signal);entry=raw*(1+slip);risk=entry-r.stop;live=r.stop
    if risk<=0:
        *_,t2,p=tape.first(t+1);return t2,p*(1-slip),'initial_stop'
    for minute in range(k,(r.deadline-BASE)//M):
        ts,px=tape.minute(minute)
        start=i+1 if minute==k else 0
        for t,p in zip(ts[start:],px[start:]):
            if p<=live:
                *_,t2,v=tape.first(int(t)+1)
                return t2,v*(1-slip),'trailing_stop' if live>r.stop else 'initial_stop'
            live=advance_stop(p,live,entry,risk,r.tick)
    *_,t2,v=tape.first(r.deadline)
    return t2,v*(1-slip),'upper_band' if r.band else 'time_20'

def audits():
    p=pd.read_pickle(CACHE/'scalp_paths.pkl');normal=p[~p.stress].copy();s=pd.read_csv(CACHE/'accounts.csv')
    assert len(p)==2*len(normal) and normal.signal.lt(END-100*M).all()
    # Compare optimized replay with an exhaustive print walk across every symbol on both cost settings.
    tests=0
    for sym,g in normal.sort_values('signal').groupby('symbol'):
        tape=Prints(sym)
        for r in g.iloc[sorted(set([0,len(g)//2,len(g)-1]))].itertuples():
            for slip in [.0005,.001]:
                path=p[(p.id==r.id)&(p.stress==(slip==.001))].iloc[0]
                t,px,reason=outcome_benchmark(r,tape,slip)
                assert t==path['exit'] and abs(px-path.exit_px)<r.tick*1e-6 and reason==path.reason,(sym,r.signal)
                tests+=1
    ctrl=s.query("phase=='60d' and not stress and account=='old_window_control'").iloc[0]
    assert int(ctrl.n)==41 and abs(ctrl.final-137.4717419)<1e-5
    books=pd.read_csv(CACHE/'trades.csv')
    assert (books.fill>=books.signal).all() and (books.exit>=books.fill).all()
    for name,b in books.groupby('account'):
        stats=s.query("phase=='60d' and not stress and account==@name").iloc[0]
        assert stats.n==len(b) and abs(150+b.usd.sum()-stats.final)<1e-8
    return {'benchmark_outcomes':tests,'symbols':len(normal.symbol.unique()),'history_control_n':int(ctrl.n),'history_control_final':ctrl.final,'account_reconciliations':len(set(books.account))}
if __name__=='__main__':
    checks();result=audits();print(json.dumps(result));(CACHE/'verification.json').write_text(json.dumps(result,indent=2))

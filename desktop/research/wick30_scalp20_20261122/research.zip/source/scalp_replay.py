"""Replay first tradable scalp fills, protected exits, costs and funding on matched public prints."""
from concurrent.futures import ProcessPoolExecutor
import math
import numpy as np
import pandas as pd
from data import BASE,CACHE,M,END
from prints import Prints

def advance_stop(best, active, entry, risk, tick):
    if best-entry < risk:return active
    return max(active,math.floor((best-risk)/tick+1e-10)*tick)

def simulate(r,tape,slip):
    entry_k,entry_i,fill,raw_open=tape.first(r.signal)
    if fill>=r.deadline:return None
    price=raw_open*(1+slip)
    expected=r.quote*(1+slip)
    stop=r.stop
    risk=price-stop
    distance=(expected-stop)/expected+2*(.0005+slip)
    deadline_k=(r.deadline-BASE)//M
    reason=None;best=raw_open
    if risk<=0:
        _,_,exit_t,raw_exit=tape.first(fill+1)
        reason='initial_stop'
    for k in range(entry_k,deadline_k):
        if reason:break
        _,high,low,_,vol=tape.one[k,:5]
        if not vol:continue
        # Safe for every order of intraminute extremes, otherwise inspect each print.
        max_stop=advance_stop(high,stop,price,risk,r.tick)
        if k!=entry_k and low>max_stop:
            best=max(best,high);stop=max_stop
            continue
        ts,px=tape.minute(k)
        start=entry_i+1 if k==entry_k else 0
        for t,p in zip(ts[start:],px[start:]):
            if p<=stop:
                _,_,exit_t,raw_exit=tape.first(int(t)+1)
                reason='trailing_stop' if stop>r.stop else 'initial_stop'
                break
            best=max(best,p)
            stop=advance_stop(p,stop,price,risk,r.tick)
    if reason is None:
        _,_,exit_t,raw_exit=tape.first(r.deadline)
        reason='upper_band' if r.band else 'time_20'
    if exit_t>=END:return None
    exit_px=raw_exit*(1-slip)
    rate=(exit_px-price)/price
    fee=.0005*(1+exit_px/price)
    start_k=(fill-BASE)//M+1;end_k=(exit_t-BASE)//M
    idx=np.flatnonzero(tape.one[start_k:end_k+1,5])+start_k
    carry=-tape.one[idx,0]*tape.one[idx,5]/price
    return dict(fill=fill,exit=exit_t,price=price,exit_px=exit_px,net=rate-fee+float(carry.sum()),
                mfe=max(0.,best/price-1),distance=distance,expected=expected,reason=reason,initial_r=max(risk,0)/price,
                funding_t=(BASE+idx*M).tolist(),funding=carry.tolist(),gross=(raw_exit-raw_open)/price,fees=fee,
                slip=(raw_exit-raw_open)/price-rate,carry=float(carry.sum()))

def per_symbol(job):
    symbol,signals=job;tape=Prints(symbol);result=[]
    for r in signals.itertuples():
        for stress,slippage in [(False,.0005),(True,.001)]:
            p=simulate(r,tape,slippage)
            if p is None:continue
            out=r._asdict();out.pop('Index')
            out.update(p);out.update(rule='volume_wick_scalp_long',side=1,group='wick',mode='current',flags=1,
                                     stress=stress,clock=r.signal,cap=4,hold=100,id=2000000+r.Index)
            result.append(out)
    print(symbol,len(result),flush=True)
    return result

if __name__=='__main__':
    raw=pd.read_pickle(CACHE/'scalps.pkl').reset_index(drop=True)
    with ProcessPoolExecutor(5) as pool: groups=list(pool.map(per_symbol,raw.groupby('symbol')))
    pd.DataFrame([r for rows in groups for r in rows]).to_pickle(CACHE/'scalp_paths.pkl')

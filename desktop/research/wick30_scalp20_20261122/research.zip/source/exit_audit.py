"""At the accepted, protected scalp entries, count the original candle exit even after a stop."""
import pandas as pd
from data import CACHE

def main():
    fills=pd.read_csv(CACHE/'trades.csv').query("account=='scalp'")
    paths=pd.read_pickle(CACHE/'scalp_paths.pkl')
    joined=fills[['id','notional','price','usd','reason']].merge(paths[~paths.stress][['id','symbol','deadline','exit_bar','band','fill','funding','signal','quote']],on='id',validate='one_to_one')
    output=[]
    for sym,g in joined.groupby('symbol'):
        for r in g.itertuples():
            output.append({'symbol':sym,'signal':r.signal,'id':r.id,'exit_if_held':('upper_band' if r.band else 'time_20'),'exit_bar':r.exit_bar,'actual_exit':r.reason})
    audit=pd.DataFrame(output)
    audit.to_csv(CACHE/'scalp_exit_audit.csv',index=False)
    print(audit.groupby(['actual_exit','exit_if_held']).size().to_string())
if __name__=='__main__':main()

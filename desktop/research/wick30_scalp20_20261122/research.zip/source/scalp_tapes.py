"""Extract all missing minutes in possible scalp holdings from OKX archives; validate coverage against public bars."""
import json
import os
from concurrent.futures import ProcessPoolExecutor
from datetime import date
from pathlib import Path
import shutil
import subprocess
from zipfile import ZipFile
import numpy as np
import pandas as pd
from data import BASE,CACHE,COINS,FLOW,HERE,LAST_DAY,M,STUDY,bars
from tick_inputs import periods
from tick_replay import span_of,locations
from extract import TAPE

def original_tape(sym):
    t,p,*_ = locations('recent',sym)
    return np.load(t,mmap_mode='r'),np.load(p,mmap_mode='r')

def extract(job):
    symbol,group=job
    one=bars(symbol,1)
    folder=CACHE/symbol
    folder.mkdir(exist_ok=True)
    ts,px=original_tape(symbol)
    wanted=set()
    for r in group.itertuples():
        if r.signal>=LAST_DAY:continue
        lo=(r.signal-BASE)//M
        hi=(r.deadline-BASE)//M
        while hi<len(one) and one[hi,4]<=0:hi+=1
        wanted.update(k for k in range(lo,min(hi+2,(LAST_DAY-BASE)//M)) if one[k,4]>0)
    ks=np.array(sorted(wanted),dtype=np.int64);begins=BASE+M*ks
    in_original=ts.searchsorted(begins+M)>ts.searchsorted(begins)
    missing=ks[~in_original]+BASE//M
    report={'symbol':symbol,'minutes':len(ks),'cached':int(in_original.sum()),'archives':[]}
    if len(missing):
        manifest=folder/'need.txt'
        manifest.write_text(''.join(f'{k} 2\n' for k in missing))
        prefix=folder/'extra';cov=folder/'cov.txt'
        proc=subprocess.Popen([str(FLOW/'cache/aggregate'),str(missing[0]),str(missing[-1]+1),str(manifest),str(prefix),str(cov)],stdin=subprocess.PIPE)
        try:
            for tag in periods(date(2026,9,23),date(2026,11,21)):
                a,b=span_of(tag)
                if missing.searchsorted(b//M)<=missing.searchsorted(a//M):continue
                archive=STUDY/f'tick_cache/{symbol}-{tag}.zip'
                with ZipFile(archive) as z:
                    for member in sorted(n for n in z.namelist() if n.endswith('.csv')):
                        with z.open(member) as stream:shutil.copyfileobj(stream,proc.stdin,1024*1024)
                        report['archives'].append([archive.name,member,z.getinfo(member).CRC])
            proc.stdin.close()
            if proc.wait():raise ValueError('archive extraction failed')
        except BaseException:
            proc.kill();proc.wait();raise
        seen=np.loadtxt(cov,ndmin=2)
        expected=one[missing-BASE//M]
        ok=np.isclose(seen[:,1],expected[:,4],rtol=1e-7,atol=1e-7)&np.isclose(seen[:,2],expected[:,2],rtol=1e-9,atol=1e-15)&np.isclose(seen[:,3],expected[:,1],rtol=1e-9,atol=1e-15)
        if not ok.all():raise ValueError((symbol,'coverage',missing[~ok][:10]))
        trades=np.fromfile(str(prefix)+'.ticks',dtype=TAPE)
        ts1,ids=trades['ts'],trades['id']
        if np.any(ts1[1:]<ts1[:-1]) or np.any((ts1[1:]==ts1[:-1])&(ids[1:]<=ids[:-1])):trades.sort(order=('ts','id'))
        assert not np.any((ts1[1:]==ts1[:-1])&(ids[1:]==ids[:-1]))
        np.save(folder/'ts.npy',trades['ts']);np.save(folder/'px.npy',trades['px'])
        Path(str(prefix)+'.ticks').unlink()
        report['extra_prints']=len(trades)
    (folder/'coverage.json').write_text(json.dumps(report))
    print(symbol,len(ks),len(missing),flush=True)
if __name__=='__main__':
    signals=pd.read_pickle(CACHE/'scalps.pkl')
    with ProcessPoolExecutor(4) as pool:list(pool.map(extract,signals.groupby('symbol')))

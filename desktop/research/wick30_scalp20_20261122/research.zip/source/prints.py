"""Public prints in exchange order, cached per minute. Reconcile REST trades before use."""
import json
from functools import lru_cache
import sys
import numpy as np
from data import BASE,CACHE,DAYSET,END,LAST_DAY,M,bars
from scalp_tapes import original_tape

class Prints:
    def __init__(self,symbol):
        self.symbol=symbol
        self.one=bars(symbol,1)
        self.old=original_tape(symbol)
        folder=CACHE/symbol
        self.extra=(np.load(folder/'ts.npy',mmap_mode='r'),np.load(folder/'px.npy',mmap_mode='r')) if (folder/'ts.npy').exists() else None

    @lru_cache(maxsize=512)
    def minute(self,k):
        t=BASE+k*M
        if not self.one[k,4]>0:return np.empty(0,dtype=np.int64),np.empty(0)
        if t<LAST_DAY:
            for tape in (self.old,self.extra):
                if tape is not None:
                    ts,px=tape
                    lo,hi=ts.searchsorted([t,t+M])
                    if hi>lo:return ts[lo:hi],px[lo:hi]
            raise ValueError((self.symbol,t,'uncovered active archived minute'))
        f=DAYSET/f'cache/minutes/{self.symbol}-{t}.json'
        alt=CACHE/f'{self.symbol}-{t}.json'
        if f.is_file() or alt.is_file():
            rows=json.loads((f if f.is_file() else alt).read_text())
        else:
            sys.path.insert(0,str(DAYSET))
            from fetch import api
            rows=[]
            cursor={'type':2,'after':t+M}
            while True:
                page=api('market/history-trades',instId=self.symbol+'-USDT-SWAP',limit=100,**cursor)
                if not page:break
                rows += [(int(r['ts']),int(r['tradeId']),float(r['px']),float(r['sz']),r['side']) for r in page if t<=int(r['ts'])<t+M]
                if min(int(r['ts']) for r in page)<t:break
                nxt=min(int(r['tradeId']) for r in page)
                if cursor['type']==1 and nxt>=cursor['after']:raise ValueError('trade cursor did not advance')
                cursor={'type':1,'after':nxt}
            rows=sorted(set(rows))
        assert rows and np.isclose(sum(r[3] for r in rows),self.one[k,4],rtol=1e-7) and np.allclose([max(r[2] for r in rows),min(r[2] for r in rows)],self.one[k,1:3],rtol=1e-9,atol=1e-15),(self.symbol,t)
        if not f.is_file() and not alt.is_file():alt.write_text(json.dumps(rows))
        return np.array([r[0] for r in rows],dtype=np.int64),np.array([r[2] for r in rows])

    def first(self,when):
        """First print at or after this millisecond."""
        for k in range((when-BASE)//M,len(self.one)):
            ts,px=self.minute(k)
            i=ts.searchsorted(when)
            if i<len(ts):return k,int(i),int(ts[i]),float(px[i])
        raise ValueError((self.symbol,when,'no executable exit'))

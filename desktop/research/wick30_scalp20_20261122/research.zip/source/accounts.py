"""Separate and shared 150 USDT account runs, fees, disaggregated outcomes and KST windows."""
from bisect import bisect_right
from collections import Counter
from functools import lru_cache
import json
import numpy as np
import pandas as pd
from data import BASE,CACHE,COINS,DAYSET,END,FLOW,LAST_DAY,M,SPLIT,START,bars
from prints import Prints
from importlib.util import module_from_spec, spec_from_file_location
engine_spec=spec_from_file_location("verified_account_engine",FLOW/"evaluate.py")
engine=module_from_spec(engine_spec)
engine_spec.loader.exec_module(engine)

REV_LONG='wick_touch_reversal_long'
REV_SHORT='wick_touch_reversal_short'
SCALP='volume_wick_scalp_long'
@lru_cache(maxsize=32)
def tape(sym):return Prints(sym)

@lru_cache(maxsize=32768)
def past_mark(sym,scheduled,fill,now,side,entry):
    """Known traded prices in [fill,now), using exact partial minutes at both ends."""
    book=tape(sym);last=entry;best=None
    for k in range((fill-BASE)//M,(now-1-BASE)//M+1):
        begin=BASE+k*M
        if book.one[k,4]<=0:continue
        if fill<=begin and begin+M<=now:
            extremum=book.one[k,1 if side==1 else 2];last=book.one[k,3]
        else:
            ts,px=book.minute(k);view=px[ts.searchsorted(fill):ts.searchsorted(now)]
            if not len(view):continue
            extremum=np.max(view) if side==1 else np.min(view);last=view[-1]
        if best is None or side*(extremum-best)>0:best=extremum
    return float(last),float(best if best is not None else entry)

def reversals():
    prior=pd.read_pickle(FLOW/'cache/variants.pkl')
    prior=prior[prior.rule.isin([REV_LONG,REV_SHORT]) & (prior['mode']=='current')].copy()
    more=[]
    for f in sorted((DAYSET/'cache').glob('*.events')):
        for r in json.loads(f.read_text()):
            if r['rule'] not in (REV_LONG,REV_SHORT) or r['mode']!='current':continue
            r.update(group='wick',clock=r['signal'],leverage=r['lev'],cap=4,hold=120,flags=1,
                     tick=float(engine.tr.meta()[r['symbol']]['tickSz']),mfe=np.nan,reason=0)
            k=(r['fill']-BASE)//M+1;j=(r['exit']-BASE)//M
            one=tape(r['symbol']).one;ix=np.flatnonzero(one[k:j+1,5])+k
            r['funding_t']=(BASE+ix*M).tolist();r['funding']=(-r['side']*one[ix,0]*one[ix,5]/r['price']).tolist()
            more.append(r)
    ids={k:1000000+i for i,k in enumerate(sorted({(r['symbol'],r['rule'],r['signal']) for r in more}))}
    for r in more:r['id']=ids[(r['symbol'],r['rule'],r['signal'])]
    full=pd.concat([prior,pd.DataFrame(more)],ignore_index=True)
    labels=pd.read_csv(CACHE/'reversal_signals.csv')
    return full.merge(labels,on=['rule','signal','symbol'],how='inner',validate='many_to_one')

def enrich(book, paths, slip):
    out=[]
    for p in book:
        r=paths[p['id']];side=r.side
        buy=r.price/(1+side*slip);sell=r.exit_px/(1-side*slip)
        units=p['notional']/r.price;fees=.0005*(r.price+r.exit_px)*units
        gross=side*(sell-buy)*units;net_price=side*(r.exit_px-r.price)*units
        carry=sum(r.funding)*p['notional'];slippage=gross-net_price
        audit=gross+carry-fees-slippage
        assert abs(audit-p['usd'])<1e-7,(p['id'],audit,p['usd'])
        pfill=buy*(1+side*.001);pexit=sell*(1-side*.001)
        matched=side*(pexit-pfill)*units-.0005*(pfill+pexit)*units+carry
        z=dict(p,margin=p['notional']/r.leverage,signal_quote=r.quote,usd_gross=gross,usd_fee=fees,usd_slip=slippage,usd_funding=carry,matched_stress_usd=matched)
        one=tape(r.symbol).one
        for h in (5,15,30):
            k=(r.signal+h*M-BASE)//M-1
            z[f'after_{h}m_pct']=100*side*(one[k,3]/r.quote-1)
        out.append(z)
    return pd.DataFrame(out)

def main():
    engine.past_mark=past_mark
    rev=reversals()
    scalp=pd.read_pickle(CACHE/'scalp_paths.pkl')
    mask=rev.qualifies
    new=rev[mask].copy();joined=pd.concat([new,scalp],ignore_index=True)
    groups={'reversal_long':new[new.rule==REV_LONG],'reversal_short':new[new.rule==REV_SHORT],
            'reversal_both':new,'scalp':scalp,'all_three':joined,'old_window_control':rev[rev.old_qualifies]}
    hr=((scalp.signal//M+540)//60)%24
    for h in range(0,24,4):groups[f'scalp_{h:02d}_{h+4:02d}']=scalp[(hr>=h)&(hr<h+4)]
    summaries=[];books=[]
    for group,frame in groups.items():
        for (_,mode,stress),rows in engine.ordered(frame).items():
            paths={r.id:r for r in rows}
            assert len(paths)==len(rows)
            for period,a,b in [('60d',START,END),('first_30d',START,SPLIT),('last_30d',SPLIT,END)]:
                stats,book=engine.simulate(rows,'base',mode,a,b,'wick',stress)
                enriched=enrich(book,paths,.001 if stress else .0005)
                stats.update(phase=period,account=group,stress=stress)
                if len(enriched):
                    stats.update(gross=enriched.usd_gross.sum(),fees=enriched.usd_fee.sum(),slippage=enriched.usd_slip.sum(),
                                 funding=enriched.usd_funding.sum(),fixed_size_stress_final=150+enriched.matched_stress_usd.sum())
                    stats['minutes_held_mean']=((enriched.exit-enriched.fill)/M).mean()
                    stats['by_exit']=json.dumps(enriched.reason.value_counts().to_dict(),ensure_ascii=False)
                    if period=='60d' and not stress:
                        enriched['account']=group
                        books.append(enriched)
                summaries.append(stats)
    s=pd.DataFrame(summaries);s.to_csv(CACHE/'accounts.csv',index=False)
    b=pd.concat(books,ignore_index=True);b.to_csv(CACHE/'trades.csv',index=False)
    print(s.query("phase=='60d' and not stress")[['account','n','wins','final','net_pct','closed_dd_pct','gross','fees','slippage','funding','by_exit']].to_string(index=False),flush=True)
if __name__=='__main__':main()

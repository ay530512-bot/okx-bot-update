import ctypes
import json,math,subprocess
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
import numpy as np
import pandas as pd
from collect_signals import tr,CACHE,BASE,START,END,M,SECTION,HERE
PLAN=json.loads((HERE/'plan.json').read_text())
FEE=.0005
@lru_cache(maxsize=1)
def native():
    f=ctypes.CDLL(str((CACHE/'paths.so').resolve())).path
    L=np.ctypeslib.ndpointer(dtype=np.int64,flags='C_CONTIGUOUS')
    D=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    i=ctypes.c_int;d=ctypes.c_double
    f.argtypes=[L,D,i,i,i,d,d,d,d,i,d,d,D];f.restype=i
    return f
@lru_cache(maxsize=1)
def closes():
    return np.column_stack([np.load(tr.location(SECTION)/f'{sym}-1.npy',mmap_mode='r')[:,3] for sym in tr.COINS])
@lru_cache(maxsize=64)
def tapes(symbol,scheduled):
    if scheduled:
        a=np.load(CACHE/symbol/'schedule_ticks.npy',mmap_mode='r')
        return np.ascontiguousarray(a['ts']),np.ascontiguousarray(a['px'])
    t,p,*_=tr.locations(SECTION,symbol)
    return np.load(t,mmap_mode='r'),np.load(p,mmap_mode='r')

def flow_window(flow, t, side):
    sec=t//1000
    a,b,c=np.searchsorted(flow['sec'],[sec-60,sec-10,sec])
    if (c-a!=60 or b-a!=50 or not np.all(np.diff(flow['sec'][a:c])==1)):return math.nan,math.nan,0,0,math.nan
    def total(q):
        buy=q['buy'].sum();sell=q['sell'].sum();n=q['n'].sum()
        volume=buy+sell
        share=(buy if side==1 else sell)/volume if volume else math.nan
        return share,volume,int(n)
    prev,pv,pn=total(flow[a:b]);last,lv,ln=total(flow[b:c])
    return last,prev,ln,pn,5*lv/pv if pv>0 else math.nan

def distances(five,q,idx,s):
    k=idx//5;bars=five[k-12:k,:5]
    # Nearest confirmed local extreme on the favorable side, inclusive of both neighbouring completed bars.
    x=bars[:,1] if s==1 else -bars[:,2]
    piv=x[1:-1][(x[1:-1]>=x[:-2])&(x[1:-1]>=x[2:])&((x[1:-1]>x[:-2])|(x[1:-1]>x[2:]))]
    overhead=piv[piv>s*q]
    return (overhead.min()-s*q)/q if len(overhead) else math.nan

def build_symbol(job):
    symbol,df=job;data=tr.location(SECTION);ci=tr.COINS.index(symbol)
    flow=np.load(CACHE/symbol/'flow.npy',mmap_mode='r')
    one=np.load(data/f'{symbol}-1.npy',mmap_mode='r');five=np.load(data/f'{symbol}-5.npy',mmap_mode='r');qtr=np.load(data/f'{symbol}-15.npy',mmap_mode='r')
    bad=set(json.loads((CACHE/symbol/'done.json').read_text())['bad_minutes'])
    fidx=np.flatnonzero(one[:,5]!=0);fts=BASE+fidx*M
    rows=[];dropped={}
    def skip(why):dropped[why]=dropped.get(why,0)+1
    for c in df.itertuples():
        scheduled=c.group=='schedule';signal=c.signal
        ts,px=tapes(symbol,scheduled)
        if scheduled:
            qidx=int(ts.searchsorted(signal,'left'))
            expires=signal+(M if c.rule in tr_sc_specs() else 90000)
            if qidx>=len(ts) or ts[qidx]>=expires or abs(px[qidx]-c.ref)>.5*c.atr:
                skip('expired_or_chase');continue
            obs=int(ts[qidx]);quote=float(px[qidx])
            if any(m in bad for m in range(signal//M,signal//M+c.hold+5)):
                skip('unreconciled_ticks');continue
        else:obs=signal;quote=c.ref
        sec=signal//1000
        if any(m in bad for m in range((sec-60)//60,(sec-1)//60+1)):
            skip('unreconciled_flow');continue
        side=c.side;idx=(signal-BASE)//M
        # Peer breadth and pivots use candles which were already closed at the original signal.
        allc=closes()
        with np.errstate(invalid='ignore',divide='ignore'):
            pct=(allc[idx-1]/allc[idx-16]-1)*side
        good=np.isfinite(pct);good[ci]=False
        breadth=float((pct[good]>0).mean()) if good.sum()>=20 else math.nan
        room=distances(five,quote,idx,side)
        k=idx//15;qr=qtr[k-9:k,:5]
        vr=np.maximum.reduce((qr[1:,1]-qr[1:,2],abs(qr[1:,1]-qr[:-1,3]),abs(qr[1:,2]-qr[:-1,3])))
        rng=float(np.median(vr)/quote)
        last,prev,nlast,nprev,activity=flow_window(flow,signal,side)
        j=int(ts.searchsorted(obs,'right'))
        if j>=len(ts) or ts[j]>=END:skip('missing_fill');continue
        for stress,slip in ((False,.0005),(True,.001)):
            expected=quote*(1+side*slip)
            if (expected-c.stop)*side<=0:skip('crossed_preorder');continue
            distance=(expected-c.stop)*side/expected+2*(FEE+slip)
            structural=(quote-c.stop)*side/quote
            # The same frozen entry feature thresholds are used under both cost assumptions.
            thresholds=structural+.002
            strong=nlast>=5 and last>=.60
            space=room>=2*thresholds
            flags=dict(base=True,flow=strong,flip=strong and nprev>=5 and prev<=.45,
                       burst=strong and nprev>=5 and activity>=1.5,room=space,flow_room=strong and space,
                       participation=strong and breadth>=.6,range_room=space and rng>=2*thresholds)
            bits=sum((1<<k) for k,key in enumerate(PLAN['filters']) if flags[key])
            for mode,(arm,gap) in PLAN['exits'].items():
                out=np.empty(8,dtype='float64')
                if not native()(ts,px,len(ts),j,side,c.stop,c.tick,slip,FEE,int(c.hold),arm,gap,out):
                    skip('missing_path');continue
                fill,exit=int(out[0]),int(out[1]);entry=out[2]
                ids=fidx[np.searchsorted(fts,fill,side='right'):np.searchsorted(fts,exit,side='right')]
                funding=(-side*one[ids,0]*one[ids,5]/entry)
                net=float(out[4]+funding.sum())
                rows.append(dict(id=c.Index,group=c.group,rule=c.rule,symbol=symbol,
                    clock=signal,signal=obs,quote=quote,side=side,stop=c.stop,tick=c.tick,leverage=c.leverage,
                    hold=c.hold,cap=c.cap,quality=c.quality,stress=stress,mode=mode,
                    flow10=last,flow50=prev,n10=nlast,n50=nprev,activity=activity,room=room,breadth=breadth,range15=rng,
                    flags=bits,expected=expected,distance=distance,fill=fill,exit=exit,price=entry,exit_px=out[3],
                    net=net,mfe=float(out[5]),reason=int(out[6]),initial_r=float(out[7]),
                    funding_t=(BASE+ids*M).tolist(),funding=funding.tolist()))
    return rows,dropped

def tr_sc_specs():
    from pc_scalp import SPECS
    return SPECS

if __name__=='__main__':
    subprocess.run(['g++','-std=c++17','-O3','-fPIC','-shared',str(HERE/'paths.cpp'),'-o',str(CACHE/'paths.so')],check=True)
    # tr.COINS is the exchange universe of the frozen strategy, including symbols not trading on a given date.
    df=pd.read_pickle(CACHE/'candidates.pkl');jobs=list(df.groupby('symbol'));ledger=[];drops={}
    with ProcessPoolExecutor(5) as pool:
        for (sym,_),(rs,d) in zip(jobs,pool.map(build_symbol,jobs)):
            ledger.extend(rs);drops[sym]=d
    out=pd.DataFrame(ledger);out.to_pickle(CACHE/'variants.pkl');(CACHE/'drops.json').write_text(json.dumps(drops))
    print(out.groupby(['group','mode','stress']).size().to_string())

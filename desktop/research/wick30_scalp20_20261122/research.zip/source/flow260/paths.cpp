// For an entry at a known observation time, simulate one exit and the best marked
// outcome before the original stop. Both use chronological public prints, without candles' OHLC ordering.
#include <algorithm>
#include <cmath>
#include <cstdint>

extern "C" int path(const int64_t* ts,const double* px,int n,int start,int side,double stop,
                    double tick,double slip,double fee,int hold,double arm,double gap,double* out) {
    if(start<0||start>=n||tick<=0||stop<=0)return 0;
    const double entry=px[start]*(1+side*slip);
    const double risk=side*(entry-stop);
    const auto deadline=ts[start]+int64_t(hold)*60000;
    int exit=-1,why=0;
    double best_net=0, initial_stop=stop,live_stop=stop;
    bool original_alive=risk>0;
    if(!original_alive) {
        exit=std::upper_bound(ts+start,ts+n,ts[start])-ts;
        why=1;
    }
    for(int i=start+1;i<n;i++){
        const double p=px[i];
        if(ts[i]>=deadline) {
            if(exit<0){exit=i;why=3;}
            break;
        }
        if(original_alive && side*(p-initial_stop)<=0) original_alive=false;
        if(original_alive) {
            const double market=p*(1-side*slip);
            const double possible=(side*(market-entry)-fee*(entry+market))/entry;
            best_net=std::max(best_net,possible);
        }
        if(exit<0 && side*(p-live_stop)<=0) {
            exit=std::upper_bound(ts+i,ts+n,ts[i])-ts;why=(live_stop==initial_stop?1:2);
        } else if(exit<0 && side*(p-entry)>=arm*risk) {
            const double raw=(p-side*gap*risk)/tick;
            const double tr=(side==1?std::floor(raw+1.e-10):std::ceil(raw-1.e-10))*tick;
            if(side*(tr-live_stop)>0)live_stop=tr;
        }
        if(exit>=0&&!original_alive)break;
    }
    if(exit<0||exit>=n)return 0;
    double filled=px[exit]*(1-side*slip);
    out[0]=ts[start];out[1]=ts[exit];out[2]=entry;out[3]=filled;
    out[4]=(side*(filled-entry)-fee*(entry+filled))/entry;
    out[5]=best_net;out[6]=why;out[7]=risk/entry;
    return 1;
}

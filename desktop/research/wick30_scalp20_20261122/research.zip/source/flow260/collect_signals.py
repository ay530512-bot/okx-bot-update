"""Collect pre-existing signals. Price paths are observed separately from candidate construction."""
import math,os,sys,json
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from tempfile import TemporaryDirectory
import subprocess
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent
STUDY=Path(os.environ.get('PC_STUDY',Path.cwd())).resolve()
PC=Path(os.environ.get('PC_RELEASE',STUDY.parent/'pc260')).resolve()
sys.path[:0]=[str(PC),str(PC/'OKX_PC_PACKAGE/runtime'),str(PC/'OKX_PC_PACKAGE/core'),str(STUDY/'wick_touch_review')]
import wick_recheck as wr
from pc_timing import indicators
from pc_sizing import leverage_for
from pc_scalp import atr as calc_atr, SPECS
from pc_timing import policies
tr=wr.tr
CACHE=HERE/'cache'
SECTION='recent'
BASE,START,END=tr.dates(SECTION)
SPLIT=int(pd.Timestamp('2026-10-22',tz='Asia/Seoul').timestamp()*1000)
M=60000

def collect(sym):
    raw=np.load(tr.location(SECTION)/f'{sym}-1.npy',mmap_mode='r')
    five=np.load(tr.location(SECTION)/f'{sym}-5.npy',mmap_mode='r')
    tick=float(tr.meta()[sym]['tickSz']);maximum=float(tr.meta()[sym]['lever'])
    active,_=tr.eligible_setups(SECTION,sym,raw)
    tf,pf,*_=tr.locations(SECTION,sym)
    tape=np.load(tf,mmap_mode='r');prices=np.load(pf,mmap_mode='r')
    o5=np.ascontiguousarray(five[:,0]);rows=[];policies_w=tr.configs()
    for s in active:
        spec=policies_w[s.rule];status,v=tr.public_path(s,raw,o5,tape,prices,BASE,spec['hold'],.0005)
        if status<=0:continue
        signal=int(v[0])
        if not (START<=signal<END-spec['hold']*M and tr.in_session(signal,spec)):continue
        k=(signal-BASE)//(5*M);bars=five[k-32:k,:5]
        if len(bars)!=32 or not np.isfinite(bars).all():continue
        ev=indicators([[0,*x] for x in bars],s.side,s.atr)
        if ev is None:continue
        anchor=s.level if s.family=='reversal' else s.side*v[2]
        stop=s.side*math.floor((anchor-max(2*tick,(.15 if s.family=='reversal' else .25)*s.atr))/tick+1e-9)*tick
        if s.side*(v[1]-stop)<=0:continue
        ev['stop']=stop;lev=leverage_for(ev,v[1],maximum)
        if lev:
            rows.append(dict(group='wick',rule=s.rule,symbol=sym,signal=signal,side=s.side,
                             ref=v[1],stop=stop,atr=s.atr,leverage=lev,hold=spec['hold'],
                             tick=tick,quality=s.quality,cap=4,session_valid=1))
    return rows

def schedules():
    source=pd.read_pickle(PC/'market_cache/opportunities.pkl')
    source=source.sort_values(['entry','rule','rv','symbol'],ascending=[True,True,False,True]).drop_duplicates(['entry','rule'])
    rows=[];meta=tr.meta()
    for r in source.itertuples():
        spec=policies()[r.rule]
        if r.hold!=spec['minutes'] or not START<=r.entry<END-r.hold*M:continue
        n=SPECS[r.rule][3] if r.rule in SPECS else 15
        k=(r.entry-BASE)//(n*M)
        bars=np.load(tr.location(SECTION)/f'{r.symbol}-{n}.npy',mmap_mode='r')[k-65:k,:5]
        bs=[[0,*x] for x in bars]
        a=calc_atr(bs,len(bs)-1 if r.rule in SPECS else len(bs)-2)
        rows.append(dict(group='schedule',rule=r.rule,symbol=r.symbol,signal=int(r.entry),side=int(r.side),
                         ref=bs[-1][4],stop=r.stop,atr=a,leverage=r.leverage,hold=r.hold,
                         tick=float(meta[r.symbol]['tickSz']),quality=r.rv,cap=SPECS[r.rule][-1] if r.rule in SPECS else 1,session_valid=1))
    return rows

if __name__=='__main__':
    CACHE.mkdir(exist_ok=True)
    tr.LIB=(STUDY/'tick_cache/wick_path.so').resolve()
    assert tr.LIB.is_file()
    with ProcessPoolExecutor(5) as pool:chunks=list(pool.map(collect,tr.COINS))
    a=pd.DataFrame([x for chunk in chunks for x in chunk]+schedules())
    a=a.drop_duplicates(['group','symbol','rule','signal']).sort_values(['signal','rule','quality','symbol'],ascending=[True,True,False,True]).reset_index(drop=True)
    a.index.name='id';a.to_pickle(CACHE/'candidates.pkl')
    print(a.groupby('group').size().to_string(),flush=True)

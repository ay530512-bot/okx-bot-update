"""Read real initiating side and sizes, and exchange prints for the published scheduler's events."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
from zipfile import ZipFile
from datetime import date
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import pandas as pd
from collect_signals import tr,CACHE,BASE,START,END,M,SECTION,HERE
FLOW=np.dtype([('sec','<i8'),('buy','<f8'),('sell','<f8'),('n','<i8')])
TAPE=np.dtype([('ts','<i8'),('id','<i8'),('px','<f8')])

def extract(job):
    sym,rows=job; root=CACHE/sym;root.mkdir(exist_ok=True)
    mask={}
    for r in rows:
        sec=r['signal']//1000
        for minute in range((sec-60)//60,(sec-1)//60+1):mask[minute]=mask.get(minute,0)|1
        if r['group']=='schedule':
            minute=r['signal']//M
            for j in range(minute,minute+r['hold']+6):mask[j]=mask.get(j,0)|2
    a,b=min(mask),max(mask)+1
    manifest=root/'need.txt';manifest.write_text(''.join(f'{k} {v}\n' for k,v in sorted(mask.items())))
    stem=root/'public';cov=root/'coverage.txt'
    if not (root/'done.json').exists():
        cmd=[str(CACHE/'aggregate'),str(a),str(b),str(manifest),str(stem),str(cov)]
        p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
        archives=[]; times=np.array(sorted(mask))*M
        try:
            for tag in tr.periods(date.fromisoformat('2026-09-21'),date.fromisoformat('2026-11-21')):
                start,finish=tr.span_of(tag)
                if times.searchsorted(finish)<=times.searchsorted(start):continue
                f=tr.CACHE/f'{sym}-{tag}.zip'
                if not f.is_file():raise ValueError(f'missing {f}')
                with ZipFile(f) as z:
                    for name in sorted(n for n in z.namelist() if n.endswith('.csv')):
                        archives.append([f.name,name,z.getinfo(name).CRC])
                        with z.open(name) as src:shutil.copyfileobj(src,p.stdin,1024*1024)
            p.stdin.close()
            if p.wait():raise RuntimeError(f'{sym} archive reader status {p.returncode}')
        except BaseException:
            p.kill();p.wait();raise
        candles=np.load(tr.location(SECTION)/f'{sym}-1.npy',mmap_mode='r')
        observed=np.loadtxt(cov,ndmin=2)
        mins=observed[:,0].astype('int64');idx=mins-BASE//M;good=(idx>=0)&(idx<len(candles))
        expected=candles[np.clip(idx,0,len(candles)-1)]
        ok=good & np.isclose(expected[:,4],observed[:,1],rtol=1e-7,atol=1e-7)
        nonempty=expected[:,4]>0
        ok &= (~nonempty)|(np.isclose(expected[:,2],observed[:,2],rtol=1e-9,atol=1e-15)&np.isclose(expected[:,1],observed[:,3],rtol=1e-9,atol=1e-15))
        tape=np.fromfile(str(stem)+'.ticks',dtype=TAPE)
        if len(tape):
            if np.any(tape['ts'][1:]<tape['ts'][:-1]) or np.any((tape['ts'][1:]==tape['ts'][:-1])&(tape['id'][1:]<tape['id'][:-1])):
                tape.sort(order=('ts','id'))
            assert not np.any((tape['ts'][1:]==tape['ts'][:-1])&(tape['id'][1:]==tape['id'][:-1]))
        np.save(root/'schedule_ticks.npy',tape);Path(str(stem)+'.ticks').unlink()
        np.save(root/'flow.npy',np.fromfile(str(stem)+'.flow',dtype=FLOW));Path(str(stem)+'.flow').unlink()
        report=dict(symbol=sym,requested_minutes=len(mask),bad_minutes=mins[~ok].tolist(),outside=int((~good).sum()),
                    schedule_prints=len(tape),archives=archives,query_hash=hashlib.sha256(manifest.read_bytes()).hexdigest())
        (root/'done.json').write_text(json.dumps(report))
    return json.loads((root/'done.json').read_text())

if __name__=='__main__':
    subprocess.run(['g++','-O3','-std=c++17',str(HERE/'aggregate.cpp'),'-o',str(CACHE/'aggregate')],check=True)
    data=pd.read_pickle(CACHE/'candidates.pkl');jobs=[(sym,g.to_dict('records')) for sym,g in data.groupby('symbol')]
    with ProcessPoolExecutor(5) as pool:
        tasks=[pool.submit(extract,j) for j in jobs]
        for f in as_completed(tasks):
            r=f.result();print(r['symbol'],r['requested_minutes'],len(r['bad_minutes']),r['schedule_prints'],flush=True)

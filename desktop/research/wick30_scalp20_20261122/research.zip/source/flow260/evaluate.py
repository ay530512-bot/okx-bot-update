"""Chronological portfolios on the exact same armed entries, budgets and trading clocks."""
import argparse,json,math
from bisect import bisect_right
from collections import Counter,defaultdict
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd
from collect_signals import tr,HERE,CACHE,START,SPLIT,END,M
from features import PLAN,tapes
from pc_forward import qualifies
from pc_scalp import SPECS

FEE=.0005;DAY=M*1440;FILTERS=list(PLAN['filters']);EXITS=PLAN['exits']
GROUPS=('schedule','wick')
@lru_cache(maxsize=65536)
def past_mark(symbol,scheduled,fill,now,side,entry):
    ts,px=tapes(symbol,scheduled)
    a,b=np.searchsorted(ts,[fill,now])
    if b<=a:return entry,entry
    path=px[a:b]
    return float(path[-1]),float(np.max(path) if side==1 else np.min(path))
@lru_cache(maxsize=1)
def instruments():
    return {s:tuple(float(i[k]) for k in ('ctVal','lotSz','minSz','maxMktSz')) for s,i in tr.meta().items()}
def metrics(ledger):
    amount=np.array([x['usd'] for x in ledger]);rr=np.array([x['net_r'] for x in ledger])
    capital=np.r_[150.,150.+amount.cumsum()]
    winners=rr[rr>0];losers=rr[rr<0]
    return dict(n=len(ledger),days=len({(x['signal']+9*3600000)//DAY for x in ledger}),final=float(capital[-1]),
        net_pct=float((capital[-1]/150.-1)*100),closed_dd_pct=float(np.max(1-capital/np.maximum.accumulate(capital))*100),
        wins=len(winners),win_pct=100*len(winners)/len(ledger) if ledger else None,
        mean_winning_r=float(winners.mean()) if len(winners) else None,mean_losing_r=float(losers.mean()) if len(losers) else None,
        mean_winning_usd=float(amount[rr>0].mean()) if len(winners) else None,
        mean_losing_usd=float(amount[rr<0].mean()) if len(losers) else None,
        payoff=float(-winners.mean()/losers.mean()) if len(winners) and len(losers) else None,
        biggest_gain_usd=float(max([0.,*amount])),without_biggest_usd=float(amount.sum()-max([0.,*amount])),
        hit2_opportunity=sum(x['mfe_r']>=2 for x in ledger),booked2=sum(x['net_r']>=2 for x in ledger),
        booked3=sum(x['net_r']>=3 for x in ledger),mean_r=float(rr.mean()) if len(rr) else None)

def simulate(rows,filter_key,mode,start,end,group,stress,rule=None,live_gate=False):
    bit=1<<FILTERS.index(filter_key);arm,gap=EXITS[mode]
    ins=instruments();slip=.001 if stress else .0005;cash=150.;pos={};ledger=[]
    days=Counter();watch_days=Counter();history=defaultdict(list);pending={};high_slots=0;samples=Counter()
    def settle(t):
        nonlocal cash
        for key,p in sorted(list(pos.items()),key=lambda item:item[1]['row'].exit):
            r=p['row']
            if r.exit>t:break
            usd=p['notional']*r.net;cash+=usd
            ledger.append(dict(id=r.id,rule=r.rule,symbol=r.symbol,signal=r.signal,fill=r.fill,exit=r.exit,qty=p['qty'],notional=p['notional'],
                        usd=usd,net_r=r.net/r.distance,mfe_r=r.mfe/r.distance,net_pct=r.net*100,stop=r.stop,
                        side=r.side,price=r.price,exit_px=r.exit_px,reason=r.reason,leverage=r.leverage))
            del pos[key]
        for key,(known,result) in list(pending.items()):
            if known<=t:
                history[key].append(result);samples[key]+=1;del pending[key]
    for r in rows:
        if r.signal<start or r.signal+r.hold*M>=end or not (r.flags&bit) or (rule and r.rule!=rule):continue
        t=r.signal;settle(t)
        # Each elapsed cutoff and entry decision is independent of future exits.
        d=(r.clock+(0 if group=='schedule' and r.rule not in SPECS else 9*3600000))//DAY
        key=r.rule;dk=(d,key)
        if group=='schedule':
            if r.distance*r.leverage/3>.005 or key in pending or watch_days[dk]>=r.cap:continue
            ready=qualifies(history[key],t)
            pending[key]=(t+(r.hold+1)*M,dict(entry_ms=t,exit_ms=r.exit,net_r=r.net/r.distance))
            watch_days[dk]+=1
            if live_gate and not ready:continue
        if days[dk]>=r.cap or key in pos or len(pos)>=3 or any(p['row'].symbol==r.symbol for p in pos.values()):continue
        equity=cash;used=open_risk=0.
        for p in pos.values():
            old=p['row']
            if t<=old.fill:
                used+=p['planned_notional']*(1/old.leverage+FEE)
                open_risk+=p['planned_notional']*old.distance
                continue
            mark,peak=past_mark(old.symbol,group=='schedule',old.fill,t,old.side,old.price)
            usd=p['notional'];initial=old.side*(old.price-old.stop);stop=old.stop
            if initial>0 and old.side*(peak-old.price)>=arm*initial:
                z=(peak-old.side*gap*initial)/old.tick
                moved=(math.floor(z+1e-10) if old.side==1 else math.ceil(z-1e-10))*old.tick
                if old.side*(moved-stop)>0:stop=moved
            funding=sum(old.funding[:bisect_right(old.funding_t,t)])
            equity+=usd*(old.side*(mark/old.price-1)-FEE+funding)
            used+=usd/old.leverage
            open_risk+=usd/old.price*(max(0,old.side*(mark-stop))+2*(FEE+slip)*mark)
        seed=max(0,equity-3);target=seed/3;ct,lot,mn,mx=ins[r.symbol]
        qty=math.floor(target/(r.expected*ct*(1/r.leverage+FEE)*lot))*lot
        nominal=qty*ct*r.expected
        if not mn<=qty<=mx or nominal/r.leverage<.97*target or nominal*(1/r.leverage+FEE)>seed-used:continue
        if nominal*r.distance>min(.005*seed,.02*seed-open_risk):continue
        pos[key]=dict(row=r,qty=qty,notional=qty*ct*r.price,planned_notional=nominal)
        days[dk]+=1;high_slots=max(high_slots,len(pos))
    settle(end)
    assert not pos and abs(cash-150-sum(x['usd'] for x in ledger))<1e-7
    result=metrics(ledger);result.update(max_simultaneous=high_slots,observations=sum(samples.values()))
    return result,ledger

def ordered(df):
    d=df.copy();d['scalp']=d['rule'].isin(SPECS);d['common']=~d['rule'].isin({'trend_long','rank_short'})
    return {(g,mode,bool(stress)):list(rows.sort_values(
               ['signal','scalp','common','quality','symbol','rule'] if g=='schedule' else ['signal','rule','quality','symbol'],
               ascending=[True,True,True,False,True,True] if g=='schedule' else [True,True,False,True]).itertuples(index=False))
            for (g,mode,stress),rows in d.groupby(['group','mode','stress'])}
def clean(v):
    if isinstance(v,(np.floating,float)):return round(float(v),6) if np.isfinite(v) else None
    if isinstance(v,(np.integer,int)):return int(v)
    if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
    if isinstance(v,list):return [clean(x) for x in v]
    return v

def select():
    df=pd.read_pickle(CACHE/'variants.pkl')
    by=ordered(df[(df.clock<SPLIT)&(~df.stress)]);audit=[];frozen={}
    for g in GROUPS:
        pool=[]
        for f in FILTERS:
            for mode in EXITS:
                result,_=simulate(by[g,mode,False],f,mode,START,SPLIT,g,False)
                row=dict(group=g,filter=f,exit_mode=mode,**result);audit.append(row)
                if (f,mode)!=('base','current') and result['n']>=12 and result['days']>=5:pool.append(row)
        ranked=sorted(pool,key=lambda r:(-r['without_biggest_usd'],-r['final']))
        entry=[r for r in ranked if r['exit_mode']=='current' and r['filter']!='base']
        frozen[g]={'overall':{k:ranked[0][k] for k in ('filter','exit_mode')} if ranked else None,
                   'entry_only':entry[0]['filter'] if entry else None}
    (HERE/'frozen.json').write_text(json.dumps(frozen,indent=2))
    pd.DataFrame(audit).to_csv(HERE/'selection.csv',index=False)
    print(json.dumps(frozen))
def evaluate():
    freeze=json.loads((HERE/'frozen.json').read_text());df=pd.read_pickle(CACHE/'variants.pkl');by=ordered(df)
    summary={};full_grid=[];ledgers={};paired=[];individual=[]
    for g in GROUPS:
        summary[g]={}
        chosen=freeze[g]['overall'];pick=(chosen['filter'],chosen['exit_mode']) if chosen else None
        for period,a,b in [('selection',START,SPLIT),('test',SPLIT,END),('all',START,END)]:
            for stress in (False,True):
                table={}
                for f in FILTERS:
                    for mode in EXITS:
                        result,ledger=simulate(by[g,mode,stress],f,mode,a,b,g,stress)
                        full_grid.append(dict(group=g,period=period,stress=stress,filter=f,exit_mode=mode,**result))
                        if (f,mode) in {('base','current'),pick,(freeze[g]['entry_only'],'current')}:
                            table[f+'/'+mode]=clean(result)
                            if not stress and period in ('all','test'):
                                ledgers[g+'/'+period+'/'+f+'/'+mode]=clean(ledger)
                if g=='schedule':
                    result,ledger=simulate(by[g,'current',stress],'base','current',a,b,g,stress,live_gate=True)
                    table['base/current/live_gate']=clean(result)
                summary[g][period+('_stress' if stress else '')]=table
        # Isolate exit changes on the baseline executed cohort. Freeze each original quantity;
        # these paired exits do not consume a new portfolio slot or reinvest released capital.
        for period,a,b in [('test',SPLIT,END),('all',START,END)]:
            baseline,ledger=simulate(by[g,'current',False],'base','current',a,b,g,False)
            for mode in EXITS:
                alt={r.id:r for r in by[g,mode,False]}
                sample=[dict(old,usd=old['notional']*alt[old['id']].net,net_r=alt[old['id']].net/alt[old['id']].distance,
                            mfe_r=alt[old['id']].mfe/alt[old['id']].distance) for old in ledger]
                stats=metrics(sample);stats['net_usdt']=sum(x['usd'] for x in sample)
                paired.append(dict(group=g,period=period,exit_mode=mode,**stats))
        if pick:
            for period,a,b in [('all',START,END),('test',SPLIT,END)]:
                for key in sorted({r.rule for r in by[g,pick[1],False]}):
                    result,_=simulate(by[g,pick[1],False],pick[0],pick[1],a,b,g,False,rule=key)
                    individual.append(dict(group=g,period=period,filter=pick[0],mode=pick[1],rule=key,**result))
    (HERE/'results.json').write_text(json.dumps(summary,indent=2))
    (CACHE/'ledgers.json').write_text(json.dumps(ledgers))
    pd.DataFrame(full_grid).to_csv(HERE/'comparisons.csv',index=False)
    pd.DataFrame(paired).to_csv(HERE/'matched_exits.csv',index=False)
    pd.DataFrame(individual).to_csv(HERE/'individual.csv',index=False)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('step',choices=['select','evaluate']);args=ap.parse_args()
    select() if args.step=='select' else evaluate()

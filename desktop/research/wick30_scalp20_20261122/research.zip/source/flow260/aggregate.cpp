// Stream the original OKX monthly/daily CSVs. Only records in requested minutes are retained.
#include <algorithm>
#include <array>
#include <charconv>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <limits>
#include <string_view>
#include <vector>

struct Flow { double buy=0, sell=0; int64_t count=0; };
struct Candle { double volume=0, low=std::numeric_limits<double>::infinity(), high=0; };
struct Trade { int64_t ts,id; double px; };

template<class T> bool number(std::string_view s,T& out) {
    auto r=std::from_chars(s.data(),s.data()+s.size(),out);
    return r.ec==std::errc{} && r.ptr==s.data()+s.size();
}
int main(int argc,char**argv) {
    if(argc!=6) return 2;
    const int64_t first=std::stoll(argv[1]),last=std::stoll(argv[2]); // integer UTC minutes
    std::vector<unsigned char> masks(last-first,0);
    std::ifstream manifest(argv[3]);
    int64_t minute;int flags; while(manifest>>minute>>flags) {
        if(minute<first||minute>=last) return 3;
        masks[minute-first]|=flags;
    }
    std::vector<std::array<Flow,60>> flows;
    std::vector<Candle> candles;
    std::vector<int> index(masks.size(),-1);
    for(size_t k=0;k<masks.size();k++) if(masks[k]) {
        index[k]=static_cast<int>(candles.size()); candles.emplace_back(); flows.emplace_back();
    }
    std::ofstream trades(std::string(argv[4])+".ticks",std::ios::binary);
    char line[1024];
    while(std::fgets(line,sizeof(line),stdin)) {
        std::string_view s(line);
        if(s.substr(0,16)=="instrument_name,") continue;
        std::array<std::string_view,6> c;
        size_t start=0;
        for(size_t i=0;i<c.size();++i) {
            auto end=s.find(',',start);
            if(end==std::string_view::npos) {
                end=s.find_first_of("\r\n",start);
                if(i!=5||end==std::string_view::npos) return 4;
            }
            c[i]=s.substr(start,end-start);start=end+1;
        }
        int64_t ts;
        if(!number(c[5],ts))return 5;
        const auto slot=ts/60000-first;
        if(slot<0||slot>=static_cast<int64_t>(masks.size())||!masks[slot])continue;
        double px,sz;int64_t id;
        if(!number(c[3],px)||!number(c[4],sz)||px<=0||sz<=0||!std::isfinite(px*sz))return 6;
        const int i=index[slot];auto& bar=candles[i];
        bar.volume+=sz;bar.low=std::min(bar.low,px);bar.high=std::max(bar.high,px);
        if(masks[slot]&1) {
            auto& v=flows[i][ts/1000%60];
            if(c[2]=="buy")v.buy+=px*sz;else if(c[2]=="sell")v.sell+=px*sz;else return 7;
            ++v.count;
        }
        if(masks[slot]&2) {
            if(!number(c[1],id))return 8;
            Trade t{ts,id,px}; trades.write(reinterpret_cast<const char*>(&t),sizeof(t));
        }
    }
    if(std::ferror(stdin)||!trades.good())return 9;
    std::ofstream out(std::string(argv[4])+".flow",std::ios::binary);
    std::ofstream cov(argv[5]);cov.precision(17);
    for(size_t k=0;k<masks.size();++k) if(masks[k]) {
        auto& bar=candles[index[k]];int64_t time=first+static_cast<int64_t>(k);
        cov<<time<<' '<<bar.volume<<' '<<(bar.volume?bar.low:0.)<<' '<<bar.high<<'\n';
        if(masks[k]&1)for(int j=0;j<60;++j) {
            auto v=flows[index[k]][j];int64_t sec=time*60+j;
            out.write(reinterpret_cast<const char*>(&sec),8);
            out.write(reinterpret_cast<const char*>(&v.buy),8);
            out.write(reinterpret_cast<const char*>(&v.sell),8);
            out.write(reinterpret_cast<const char*>(&v.count),8);
        }
    }
    return out.good()&&cov.good()?0:10;
}

"""Re-evaluate the rolling 30-bar reversal with first-trigger tick prefixes."""
import json
import pickle
from pathlib import Path
import numpy as np
import pandas as pd
from data import BASE,CACHE,DAYBASE,DAYSET,END,FLOW,LAST_DAY,M,START,STUDY
from signals import Probe,Setup
from bb_filter import close_bands,preceding_decline_and_pause,within_retest_window
from prints import Prints

def evaluate():
    previous=pd.read_pickle(FLOW/'cache/candidates.pkl').query("group=='wick' and rule.str.contains('reversal')",engine='python').set_index(['symbol','rule','signal'])
    newset=pickle.loads((DAYSET/'cache/setups.pkl').read_bytes())
    result=[]
    for name,base,folder in [('old',BASE,STUDY),('new',DAYBASE,DAYSET)]:
        labels=pd.read_csv(DAYSET/f'cache/bb_{name}.csv')
        for sym,block in labels[labels.signal>=START].groupby('symbol'):
            five=np.load(folder/f'target_cache/recent/{sym}-5.npy')
            mean,std=close_bands(five)
            instrument=Prints(sym)
            for r in block.itertuples():
                side=1 if r.rule.endswith('long') else -1
                j=(r.signal-base)//(5*M)
                anchor=r.anchor
                ordinal=j-anchor
                key=(sym,r.rule,r.signal)
                if name=='old':
                    old=previous.loc[key]
                    atr,tick=old.atr,old.tick
                    width,nt=(.2,1) if side==1 else (.35,2)
                    level=five[anchor,2] if side==1 else -five[anchor,1]
                    band=max(3*tick,width*atr);depart=level+band+max(tick,.12*atr)
                    setup=Setup('reversal',side,anchor,(anchor+1)*5,(anchor+31)*5,level,atr,tick,band,nt*tick,depart,side*five[anchor,3]>=depart,0,'')
                else:
                    setup=next(s for s,spec in newset[sym] if s.source==anchor and s.rule==r.rule)
                    atr,tick=setup.atr,setup.tick
                prefix=None
                if ordinal==1 and r.approach:
                    prefix=[];det=Probe(setup);hit=None
                    begin=base+(anchor+1)*5*M
                    for k in range((begin-BASE)//M,(r.signal-BASE)//M+1):
                        ts,px=instrument.minute(k)
                        end=ts.searchsorted(r.signal,side='right')
                        for t,p in zip(ts[:end],px[:end]):
                            prefix.append(p)
                            if det.observe(j,side*five[j,0],side*p,side*p) is not None:
                                hit=t
                                break
                        if hit is not None:break
                    assert hit==r.signal,(sym,r.signal,hit,ordinal)
                    if name=='old':assert abs(prefix[-1]-old.ref)<tick/10
                count,approach,pause=preceding_decline_and_pause(five,mean,std,anchor,j,side,atr,observed_prices=prefix)
                ok=bool(approach and pause)
                assert not r.eligible or ok
                result.append(dict(symbol=sym,rule=r.rule,signal=r.signal,ordinal=ordinal,approach=approach,pause=pause,qualifies=ok,old_qualifies=r.eligible))
    df=pd.DataFrame(result);df.to_csv(CACHE/'reversal_signals.csv',index=False)
    print(df.groupby('rule').qualifies.agg(['sum','size']).to_string(),flush=True)
if __name__=='__main__':evaluate()

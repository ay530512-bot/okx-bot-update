"""Synthetic chronological regression tests, including strict invalidation and both sides."""
from dataclasses import replace
import unittest
import numpy as np

from signals import MINUTE,Setup,Probe,tick_event,minute_event

def setup(family="reversal",side=1):
    # Long first wick low 100; reflected short has first wick high 110.
    level = 100. if side==1 else -110.
    return Setup(family,side,0,5,10,level,2.,.1,.6,.2,level+1.,True,1.,"standard")

def fixture(path,side=1):
    prices = np.asarray(path,dtype="f8")
    op = np.full((12,6),105.)
    op[:,4]=1.
    op[5:10,0]=prices[0]
    if side==-1:
        op[:,:4]=210.-op[:,:4]
        prices=210.-prices
    ts=5*MINUTE+np.arange(len(path))*100
    return op,ts,prices

class TestTouch(unittest.TestCase):
    def test_second_wick_before_old_high(self):
        for side in (1,-1):
            b,ts,p=fixture([101.3,100.7,100.4,100.2,100.3,100.4,104],side)
            i,ext=tick_event(setup(side=side),b,ts,p,0)
            self.assertEqual(i,5)
            self.assertAlmostEqual(side*ext,100.2 if side==1 else 109.8)
            self.assertLess(ts[i],6*MINUTE)

    def test_equal_and_breached_first_wick_fail(self):
        for side in (1,-1):
            for extreme in (100.,99.9):
                b,ts,p=fixture([101.5,extreme,100.3,101.7],side)
                self.assertIsNone(tick_event(setup(side=side),b,ts,p,0))

    def test_adjacent_prints_from_first_visit_do_not_count(self):
        b,ts,p=fixture([100.5,100.3,100.5,100.55])
        self.assertIsNone(tick_event(replace(setup(),armed=False),b,ts,p,0))

    def test_new_wick_needs_an_open_above_low(self):
        s=setup()
        p=Probe(s)
        self.assertIsNone(p.observe(1,100.1,100.2,100.2))
        self.assertIsNone(p.observe(1,100.1,100.4,100.4))

    def test_trend_touches_average_and_turns_in_both_directions(self):
        for side in (1,-1):
            b,ts,p=fixture([101.8,100.6,100.25,100.05,99.9,100.,100.1,101.9],side)
            i,ext=tick_event(setup("trend",side),b,ts,p,0)
            self.assertEqual(i,6)
            self.assertAlmostEqual(side*ext,99.9 if side==1 else 110.1)

    def test_reversal_does_not_require_average_but_trend_does(self):
        b,ts,p=fixture([101.4,100.4,100.6,101.3])
        self.assertIsNotNone(tick_event(setup(),b,ts,p,0))
        self.assertIsNone(tick_event(setup("trend"),b,ts,p,0))

    def test_trend_deep_cross_and_overshoot(self):
        for path in ([101.8,99.3,100.1],[101.8,100.0,101.8]):
            b,ts,p=fixture(path)
            self.assertIsNone(tick_event(setup("trend"),b,ts,p,0))

    def test_wick_occurs_before_later_breach(self):
        b,ts,p=fixture([101.3,100.2,100.4,99.8,101.2])
        self.assertEqual(tick_event(setup(),b,ts,p,0)[0],2)
        b[5,:5] = [101.3,101.3,99.8,101.2,200]
        self.assertIsNone(minute_event(setup(),b))

    def test_minute_proxy_observes_close_only(self):
        b,ts,p=fixture([101.3,100.3,100.5])
        b[5,:5]=[101.3,101.3,100.3,100.5,10]
        b[6,0]=100.5
        self.assertEqual(minute_event(setup(),b)[:2],(5,100.5))
        self.assertAlmostEqual(minute_event(setup(),b)[2],100.3)
        b[6,0]=102.
        self.assertIsNone(minute_event(setup(),b))

if __name__=="__main__":
    unittest.main()

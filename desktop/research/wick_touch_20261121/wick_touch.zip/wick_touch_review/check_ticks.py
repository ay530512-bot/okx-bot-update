"""Verify the intrabar definition against a fixed public trade-print sample."""
from datetime import datetime,timezone
import json
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

from signals import PLAN,ROOT,MINUTE,dates,location,meta,setups,minute_event,tick_event
from public_ticks import CACHE
from tick_replay import public_path

ZONE = ZoneInfo("Asia/Seoul")

def read_sample(symbol, days):
    # OKX labels the archive by UTC+8 calendar day. Filter using its actual timestamps.
    columns = ["created_time","trade_id","price"]
    notes,parts = [],[]
    for day in days:
        trades = pd.read_csv(CACHE/f"{symbol}-{day}.zip",usecols=columns)
        if trades.trade_id.duplicated().any():
            raise ValueError("Duplicate exchange trade IDs")
        parts.append(trades)
        notes.append(dict(file_day=day,trades=len(trades),first_ms=int(trades.created_time.min()),
                          last_ms=int(trades.created_time.max())))
    combined = pd.concat(parts,ignore_index=True).sort_values(["created_time","trade_id"],kind="stable")
    if combined.trade_id.duplicated().any():
        raise ValueError("Overlapping archive files")
    return combined.created_time.to_numpy(),combined.price.to_numpy(),notes


def main():
    sample = PLAN["tick_sample"]
    base = dates("recent")[0]
    rows, files = [],{}
    compared = 0
    for symbol in sample["symbols"]:
        ts,prices,files[symbol] = read_sample(symbol,sample["file_dates"])
        # Use only full observation windows for which trade prints were requested.
        start = int((pd.Timestamp(sample["file_dates"][0],tz="Asia/Shanghai").timestamp()*1000-base)//MINUTE)
        end = start+1440*len(sample["file_dates"])
        bars = np.asarray(np.load(location("recent")/f"{symbol}-1.npy",mmap_mode="r"))
        opens5 = np.ascontiguousarray(np.load(location("recent")/f"{symbol}-5.npy",mmap_mode="r")[:,0])
        prefix = np.flatnonzero(np.diff(ts)<0)
        assert len(prefix)==0 and ts[0]>=base+start*MINUTE and ts[-1]<base+end*MINUTE
        # Every nonzero-volume minute used for examples must have public trades, including the OHLC extrema.
        ix = (ts-base)//MINUTE
        grouped = pd.DataFrame({"m":ix,"p":prices}).groupby("m")["p"].agg(["min","max"])
        expected = np.flatnonzero(bars[start:end,4]>0)+start
        if not np.array_equal(grouped.index.to_numpy(),expected):
            raise ValueError(symbol+" missing or extra active one-minute bars in tick files")
        if not (np.allclose(grouped["min"],bars[expected,2],rtol=1e-10,atol=1e-15)
                and np.allclose(grouped["max"],bars[expected,1],rtol=1e-10,atol=1e-15)):
            raise ValueError(symbol+" unmatched candle/trade extrema")
        with np.errstate(invalid="ignore",divide="ignore"):
            for s in setups("recent",symbol,meta()[symbol],(start,end)):
                if s.profile!="standard" or s.start<start or s.end>end:
                    continue
                exact = tick_event(s,bars,ts,prices,base)
                native, details = public_path(s,bars,opens5,ts,prices,base,45,.0005)
                assert bool(native)==bool(exact), "Native and reference touch decisions differ"
                if exact:
                    assert int(details[0])==ts[exact[0]] and abs(details[2]-s.side*exact[1])<1.e-6*s.tick
                compared += 1
                minute = minute_event(s,bars)
                row = dict(symbol=symbol,rule=s.rule,source=int((base//MINUTE)+5*s.source),
                           exact=exact is not None,minute=minute is not None)
                if exact is not None:
                    n,extreme=exact
                    row.update(trigger_ms=int(ts[n]),trigger_price=float(prices[n]),level=float(s.side*s.level),
                               wick=float(extreme*s.side),decision_kst=datetime.fromtimestamp(ts[n]/1000,ZONE).isoformat(timespec="milliseconds"),
                               seconds_before_5m_close=float((300000-int(ts[n])%300000)/1000))
                if minute is not None:
                    row["proxy_ms"]=int(base+(minute[0]+1)*MINUTE)
                rows.append(row)
    table = pd.DataFrame(rows)
    result = {"kind":"Mechanics, all hours, both sides, standard profile; signal counts, not fills or returns.",
              "archives":files,"matched_native_reference_setups":compared,"trade_prints":sum(d["trades"] for v in files.values() for d in v),"rules":{}}
    audit = table[table.exact].sort_values(["trigger_ms","symbol"])
    for rule,g in table.groupby("rule"):
        both = g[g.exact & g.minute]
        result["rules"][rule] = dict(setups=len(g),tick_signals=int(g.exact.sum()),minute_signals=int(g.minute.sum()),
            both=len(both),only_tick=int((g.exact & ~g.minute).sum()),only_minute=int((~g.exact & g.minute).sum()))
    result["first_example_each"] = []
    for _,g in audit.groupby("rule"):
        row = g.iloc[0]
        result["first_example_each"].append({k:row[k] for k in ["symbol","rule","decision_kst","level","wick","trigger_price","seconds_before_5m_close"]})
    result["median_seconds_before_5m_close"] = float(audit.seconds_before_5m_close.median()) if len(audit) else None
    (ROOT/"tick-check.json").write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="archives"},ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()

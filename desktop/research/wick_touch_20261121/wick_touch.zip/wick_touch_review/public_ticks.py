"""Fetch the prespecified sample of public OKX executed trades."""
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
import json
from pathlib import Path
import time
from urllib.request import Request, urlopen
from zipfile import ZipFile

HOME = Path(__file__).resolve().parent
CACHE = Path("tick_cache")

def archive(symbol, day):
    path = CACHE / f"{symbol}-{day}.zip"
    if path.exists():
        return path
    url = ("https://static.okx.com/cdn/okex/traderecords/trades/daily/" + day.replace("-", "")
           + f"/{symbol}-USDT-SWAP-trades-{day}.zip")
    for attempt in range(3):
        try:
            with urlopen(Request(url, headers={"User-Agent":"public-market-replay"}), timeout=35) as source:
                data = source.read()
            with ZipFile(BytesIO(data)) as zipped:
                if zipped.testzip() is not None:
                    raise ValueError("Corrupt archive")
            tmp = path.with_suffix(".part")
            tmp.write_bytes(data)
            tmp.replace(path)
            return path
        except OSError:
            if attempt == 2:
                raise
            time.sleep(1 + attempt)

if __name__ == "__main__":
    CACHE.mkdir(exist_ok=True)
    sample = json.loads((HOME/"plan.json").read_text())["tick_sample"]
    jobs = [(s, d) for s in sample["symbols"] for d in sample["file_dates"]]
    with ThreadPoolExecutor(5) as pool:
        for path in pool.map(lambda p: archive(*p), jobs):
            print(path, path.stat().st_size, flush=True)

"""Check native touch/replay against the readable chronological reference in both directions."""
import unittest
import numpy as np

from signals import MINUTE,tick_event
from test_touch import setup,fixture
from tick_replay import public_path

class TickPath(unittest.TestCase):
    def test_mirrored_rejection_and_no_prefill_profit(self):
        for side in (1,-1):
            for family,path in (("reversal",[101.6,100.4,100.2,100.4,100.5,101.9,101.1,101.0,99.0,98.9]),
                                ("trend",[101.6,100.05,99.9,100.1,100.2,101.6,100.2,100.,99.0])):
                s=setup(family,side)
                bars,ts,px=fixture(path,side)
                pure=tick_event(s,bars,ts,px,0)
                status,r=public_path(s,bars,np.ascontiguousarray(bars[::5,0]),ts,px,0,45,.0005)
                self.assertEqual(status,2)
                self.assertEqual(r[0],ts[pure[0]])
                self.assertAlmostEqual(r[2],side*pure[1])
                self.assertGreater(r[3],r[0])
                self.assertGreater(r[4],r[3])
                self.assertAlmostEqual(r[7],side*(r[9]/r[5]-1)-.0005*(1+r[9]/r[5]))

    def test_adverse_gap_is_booked_after_the_order(self):
        s=setup()
        b,ts,px=fixture([101.4,100.2,100.4,98.,97.9,102.0])
        st,r=public_path(s,b,np.ascontiguousarray(b[::5,0]),ts,px,0,45,.0005)
        self.assertEqual(st,2)
        self.assertEqual(r[3],ts[3])
        self.assertEqual(r[4],ts[4])
        self.assertLess(r[7],0)
        self.assertEqual(r[6],0)

    def test_no_fill_at_duplicate_millisecond(self):
        s=setup()
        b,ts,px=fixture([101.4,100.2,100.4,100.9,100.6,99.,98.9])
        ts[3]=ts[2]
        st,r=public_path(s,b,np.ascontiguousarray(b[::5,0]),ts,px,0,45,.0005)
        self.assertEqual(st,2)
        self.assertEqual(r[3],ts[4])
        self.assertAlmostEqual(r[5],100.6*1.0005)

    def test_timeout_and_invalidating_touch(self):
        s=setup()
        b,ts,px=fixture([101.4,100.2,100.4,100.5,100.4,100.4])
        ts[-1]+=45*MINUTE
        st,r=public_path(s,b,np.ascontiguousarray(b[::5,0]),ts,px,0,45,.0005)
        self.assertEqual(st,2)
        self.assertEqual(r[4],ts[-1])
        b,ts,px=fixture([101.4,100.0,100.4,101.4])
        self.assertEqual(public_path(s,b,np.ascontiguousarray(b[::5,0]),ts,px,0,45,.0005)[0],0)

if __name__=="__main__":
    unittest.main()

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>

// All stream indices are chronological. Price history beyond the current print is used only for fills and exits.
extern "C" int touch_trade(const int64_t* ts, const double* px, int n, int lo, int hi,
        const double* opens5, int64_t base, int side, int reversal, int armed,
        double level, double atr, double tick, double lower, double upper,
        double step, double departure, int hold, double slip, double* out) {
    const double eps=tick*1.e-5, chase=std::max(3*tick,.25*atr),fee=.0005;
    int current_bar=-1, trigger=-1;
    double extreme=std::numeric_limits<double>::infinity();
    for(int i=lo;i<hi;++i) {
        double p=side*px[i];
        if(p<lower-eps) return 0;
        if(!armed) {
            if(p>=departure-eps) armed=1;
            continue;
        }
        int bar=static_cast<int>((ts[i]-base)/300000);
        if(bar!=current_bar) { current_bar=bar; extreme=std::numeric_limits<double>::infinity(); }
        if(p<=upper+eps) extreme=std::min(extreme,p);
        if(!std::isfinite(extreme)) continue;
        double rise=p-extreme, wick=std::min(side*opens5[bar],p)-extreme;
        if(rise+eps<step || wick+eps<tick) continue;
        if(rise>chase+eps || (!reversal && wick>std::max(3*tick,.25*atr)+eps)) return 0;
        trigger=i;
        break;
    }
    if(trigger<0) return 0;
    out[0]=ts[trigger]; out[1]=px[trigger]; out[2]=side*extreme;
    int enter=static_cast<int>(std::upper_bound(ts+trigger,ts+n,ts[trigger])-ts);
    if(enter>=n) return 1;
    double price=px[enter]*(1+side*slip);
    double support=reversal?level:extreme;
    double initial=side*std::floor((support-std::max(2*tick,.25*atr))/tick+1.e-9)*tick;
    double risk=side*(price-initial), stop=initial;
    if(side*(px[trigger]*(1+side*slip)-initial)<=0) return 1;
    // A gap through the protective stop after a market order is sent still counts.
    int exit=(risk<=0) ? static_cast<int>(std::upper_bound(ts+enter,ts+n,ts[enter])-ts) : -1;
    int64_t deadline=ts[enter]+hold*60000LL;
    for(int i=enter+1;exit<0 && i<n;++i) {
        if(ts[i]>=deadline) {exit=i;break;}
        double p=px[i];
        if(side*(p-stop)<=0) {
            exit=static_cast<int>(std::upper_bound(ts+i,ts+n,ts[i])-ts);
            break;
        }
        if(side*(p-price)>=risk) {
            double raw=(p-side*risk)/tick;
            double next=(side==1?std::floor(raw+1.e-10):std::ceil(raw-1.e-10))*tick;
            if(side*(next-stop)>0) stop=next;
        }
    }
    if(exit<0 || exit>=n) return 1;
    double exit_price=px[exit]*(1-side*slip);
    out[3]=ts[enter]; out[4]=ts[exit]; out[5]=price; out[6]=std::max(0.,risk)/price;
    out[7]=side*(exit_price-price)/price-fee*(1+exit_price/price);
    out[8]=initial; out[9]=exit_price;
    return 2;
}

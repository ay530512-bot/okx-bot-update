"""Animate public trade prints up to the actual simulated wick entry. Cases selected without P&L."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image,ImageDraw,ImageFont

from check_ticks import read_sample
from signals import MINUTE, PLAN, ROOT, dates, ema, location, meta, setups, tick_event
from tick_replay import configs,locations

BASE=dates("recent")[0]
BG,FG,DIM,GRID="#12181E","#F5F6F4","#A6B7C2","#34434C"
UP,DOWN,GOLD,BLUE="#55C59D","#EC8291","#F3C363","#92DEFA"
FONT="/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
BOLD="/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
F={n:ImageFont.truetype(BOLD if n>=19 else FONT,n,index=1) for n in (12,13,15,17,20,25)}
PICKS=[("wick_touch_reversal_long","BREV","반전 롱"),
       ("wick_touch_reversal_short","INIT","반전 숏"),
       ("wick_touch_trend_long","BONK","추세 눌림 롱"),
       ("wick_touch_trend_short","LINK","추세 반등 숏")]

def kst(ts,fmt):
    return pd.Timestamp(int(ts),unit="ms",tz="UTC").tz_convert("Asia/Seoul").strftime(fmt)

def chapter(rule,sym,title,trade,ts,px):
    c=configs()[rule]
    path=pd.read_pickle(locations("recent",sym)[2])
    row=path[(~path.stress)&(path.rule==rule)&(path.fill==trade["entry"])].iloc[0]
    trigger=int(row.signal)
    fill=int(row["fill"])
    minute=(trigger-BASE)//MINUTE
    bars=np.asarray(np.load(location("recent")/f"{sym}-1.npy",mmap_mode="r"))
    five=np.asarray(np.load(location("recent")/f"{sym}-5.npy",mmap_mode="r"))
    with np.errstate(invalid="ignore",divide="ignore"):
        for s in setups("recent",sym,meta()[sym],(minute-200,minute+1)):
            if s.profile!=c["profile"] or s.rule!=rule or not s.start<=minute<s.end: continue
            exact=tick_event(s,bars,ts,px,BASE)
            if exact and ts[exact[0]]==trigger: break
        else: raise ValueError((rule,sym,trigger))
    endbar=minute//5
    rev=s.family=="reversal"
    begin=min(s.source-5,endbar-12) if rev else endbar-13
    src=BASE+s.source*5*MINUTE
    center=BASE+endbar*5*MINUTE
    history_start=max(BASE+begin*5*MINUTE,src-3*MINUTE) if rev else center-4*5*MINUTE
    step1=np.linspace(history_start,center,9,endpoint=False,dtype="int64").tolist()
    step2=np.linspace(center,trigger,8,endpoint=False,dtype="int64").tolist()
    seen=sorted(set(step1+step2+[trigger,fill,fill+2500]))
    end=len(seen)-1
    early,latest=begin,endbar
    price_step=meta()[sym]["tickSz"].rstrip("0")
    digits=len(price_step.split(".")[-1]) if "." in price_step else 0
    fmt=lambda v:f"{v:.{digits}f}"
    avg=ema(five[:,3],20)
    start_idx=np.searchsorted(ts,center)
    end_idx=np.searchsorted(ts,seen[-1],side="right")
    partial=px[start_idx:end_idx]
    bottom=min(five[early:latest,2].min(),partial.min())
    top=max(five[early:latest,1].max(),partial.max())
    if not rev:
        bottom=min(bottom,min(avg[early-1:latest]));top=max(top,max(avg[early-1:latest]))
    padding=max(s.tick*3,(top-bottom)*.15)
    bottom-=padding;top+=padding
    x0,x1=24,626
    spacing=(x1-x0)/(endbar-begin+2)
    x=lambda j:int(x0+(j-begin+.55)*spacing)
    yp=lambda p:int(285-(p-bottom)*181/(top-bottom))
    pictures=[];delays=[]
    for t in seen:
        img=Image.new("RGB",(736,383),BG);d=ImageDraw.Draw(img)
        def text(xy,msg,n=15,color=FG,anchor="la"):
            d.text(xy,msg,font=F[n],fill=color,anchor=anchor)
        text((20,8),title,25); text((716,19),sym+" / USDT   ·   "+kst(t,"%m.%d   %H:%M:%S")+" KST",15,DIM,"ra")
        text((20,51),("첫 꼬리와 두 번째 꼬리" if rev else "눌림이 닿은 5분 EMA20"),17,GOLD)
        text((716,55),"5분봉  ·  공개 체결로 재생",13,DIM,"ra")
        for level in np.linspace(bottom,top,4):
            y=yp(level);d.line((x0,y,x1,y),fill=GRID)
            text((635,y),fmt(level),12,DIM,"lm")
        active=int((t-BASE)//(5*MINUTE))
        if not rev:
            pts=[(x(j),yp(avg[j-1])) for j in range(begin,min(active,endbar)+1)]
            if len(pts)>1:d.line(pts,fill=GOLD,width=2)
        for j in range(begin,min(active,endbar)+1):
            if j<active:
                op,hi,lo,cl=five[j,:4]
            else:
                first,last=np.searchsorted(ts,[BASE+j*5*MINUTE,t+1])
                vals=px[first:last]
                if not len(vals):continue
                op,hi,lo,cl=five[j,0],max(vals),min(vals),vals[-1]
            col=UP if cl>=op else DOWN
            xx=x(j);hw=max(2,int(spacing*.29))
            d.line((xx,yp(hi),xx,yp(lo)),fill=col,width=2)
            a,b=sorted((yp(op),yp(cl)));d.rectangle((xx-hw,a,xx+hw,max(b,a+1)),fill=col)
        if rev and t>=src+5*MINUTE:
            y=yp(s.side*s.level);xx=x(s.source)
            for j in range(xx,x1,11): d.line((j,y,min(x1,j+6),y),fill=GOLD,width=1)
            d.ellipse((xx-5,y-5,xx+5,y+5),outline=GOLD,width=2)
        if t>=trigger:
            xx=x(endbar);wy=yp(row.wick);y=yp(row.ref)
            d.ellipse((xx-7,wy-7,xx+7,wy+7),outline=BLUE,width=2)
            d.polygon([(xx+8,y),(xx+16,y-4),(xx+16,y+4)],fill=FG)
        text((x(begin),298),kst(BASE+begin*5*MINUTE,"%H:%M"),12,DIM,"ma")
        text((x(endbar),298),kst(center,"%H:%M"),12,DIM,"ma")
        if t>=fill:
            msg=f"모의 체결  {fmt(row.price)}"
        elif t>=trigger:
            msg=f"꼬리 끝 {fmt(row.wick)}에서 되돌아선 가격  {fmt(row.ref)}"
        elif rev and t>=src+5*MINUTE:
            msg=("첫 저점" if s.side==1 else "첫 고점")+f" {fmt(s.side*s.level)}  ·  두 번째 시험을 기다리는 중"
        elif rev:
            msg="거래량이 늘어난 첫 꼬리가 형성되는 구간"
        else:
            msg="이평선에 다가오는 가격"
        text((20,326),msg,20, BLUE if t>=trigger else FG)
        text((20,362),"노란색은 기준 가격  ·  하늘색 원은 되돌아선 꼬리  ·  흰 화살표는 신호 가격",12,DIM)
        pictures.append(img.convert("P",palette=Image.Palette.ADAPTIVE,colors=64))
        delays.append(1400 if t in (trigger,fill) else 850 if t==seen[end] else 220)
    return pictures,delays

if __name__=="__main__":
    ledger=json.loads((ROOT/"recent-ticks-BREV-BONK-INIT-LINK-ledger.json").read_text())
    frames=[];durations=[]
    sample=PLAN["tick_sample"]["file_dates"]
    for rule,sym,name in PICKS:
        ts,px,_=read_sample(sym,sample)
        trade=min((r for r in ledger if r["rule"]==rule and r["symbol"]==sym and ts[0]<=r["entry"]<ts[-1]),key=lambda r:r["entry"])
        f,d=chapter(rule,sym,name,trade,ts,px)
        frames.extend(f);durations.extend(d)
    frames[0].save(ROOT/"entries.gif",save_all=True,append_images=frames[1:],duration=durations,loop=0,optimize=True,disposal=1)
    print(len(frames),(ROOT/"entries.gif").stat().st_size)

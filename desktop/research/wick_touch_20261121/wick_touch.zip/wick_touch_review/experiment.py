"""Reprice fixed wick entries and evaluate separate and shared 150 USDT accounts."""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

from signals import COINS, MINUTE, PLAN, ROOT, dates, location, meta, minute_signals
from inputs import PERIODS, prepare
from evaluate import CONTRACTS, METRICS, limits, score
from paths import lib
from portfolio import replay

RULES = tuple("wick_touch_"+r for r in ("reversal_long","reversal_short","trend_long","trend_short"))
from evaluate import OLD
assert set(RULES).isdisjoint(OLD)
FIELDS = ["signal","entry","exit","coin","price","dist","net"]
ENGINE = lib()


def write(name, data):
    path = ROOT/name
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+"\n")
    os.replace(tmp,path)


def fingerprint():
    return {n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in ("signals.py","experiment.py","plan.json")}


def build(section):
    raw = minute_signals(section)
    instruments = meta()
    epoch = dates(section)[0]//MINUTE
    for stress in ([False] if section=="development" else [False,True]):
        records = []
        for (symbol,side),g in raw.groupby(["symbol","side"],sort=False):
            bars = np.ascontiguousarray(np.load(location(section)/f"{symbol}-1.npy",mmap_mode="r"))
            orders = np.ascontiguousarray(g[["clock","ref","atr","stop"]].to_numpy(dtype="f8"))
            out = np.empty((len(g),7))
            ENGINE.paths(bars,len(bars),orders,len(g),int(side),5,0,float(instruments[symbol]["tickSz"]),
                         .001 if stress else .0005,.0005,int(stress),out)
            for col,hold in ((3,45),(5,120)):
                ok = np.isfinite(out[:,col+1])
                part = g.loc[ok,["rule","profile","coin","source","level","probe"]].copy()
                part["hold"] = hold
                part["signal"] = g.loc[ok,"clock"].to_numpy()+epoch
                part["entry"] = out[ok,0]+epoch
                part["exit"] = out[ok,col]+epoch
                part["price"] = out[ok,1]
                part["dist"] = out[ok,2]
                part["net"] = out[ok,col+1]
                records.append(part)
        frame = (pd.concat(records,ignore_index=True).sort_values("entry",kind="stable")
                 if records else pd.DataFrame(columns=["rule","profile","hold",*FIELDS]))
        frame.to_pickle(ROOT/(section+("-stress" if stress else "")+".pkl"))
        print(section,stress,len(raw),len(frame),flush=True)


class Book:
    def __init__(self, section, stress=False):
        self.stress = stress
        frame = pd.read_pickle(ROOT/(section+("-stress" if stress else "")+".pkl"))
        self.groups = {(rule,prof,hold):np.ascontiguousarray(group[FIELDS].to_numpy(dtype="f8"))
                       for (rule,prof,hold),group in frame.groupby(["rule","profile","hold"],sort=False)}
        for r,p,h in itertools.product(RULES,PLAN["profiles"],PLAN["holds_min"]):
            self.groups.setdefault((r,p,h),np.empty((0,len(FIELDS))))

    @staticmethod
    def key(cfg):
        return tuple(cfg[k] for k in ("rule","profile","hold"))

    def single(self,cfg,interval):
        rows = self.groups[self.key(cfg)]
        out = np.zeros(8)
        ENGINE.single(rows,len(rows),CONTRACTS,*interval,cfg["start"],cfg["end"],540,cfg["cap"],
                      cfg["hold"],10,0,.0005,.001 if self.stress else .0005,out)
        stats = dict(zip(METRICS,map(float,out)))
        for k in ("trades","wins","active_days"):
            stats[k] = int(stats[k])
        stats["net_pct"] = 100*(stats["final"]/150-1)
        return stats


def freeze():
    book = Book("development")
    a,b = map(limits,PLAN["development"])
    val = limits(PLAN["selection"])
    selected = {}
    for rule in RULES:
        ranked = []
        for prof,hold,(start,end) in itertools.product(PLAN["profiles"],PLAN["holds_min"],PLAN["sessions_kst"]):
            cfg = dict(rule=rule,profile=prof,hold=hold,start=start,end=end,cap=PLAN["cap_per_kst_day_per_rule"])
            x,y = book.single(cfg,a),book.single(cfg,b)
            adequate = min(x["trades"],y["trades"])>=8
            passed = (adequate and min(x["net_pct"],y["net_pct"])>0
                      and x["final"]+y["final"]-300>max(x["largest_gain"],y["largest_gain"]))
            ranked.append(dict(config=cfg,development=[x,y],adequate=adequate,passed=passed,score=score(x,y)))
        ranked.sort(key=lambda r:(r["passed"],r["adequate"],r["score"]),reverse=True)
        seen,shortlist = set(),[]
        for r in ranked:
            sig = tuple((x["trades"],round(x["final"],8),round(x["closed_dd_pct"],8)) for x in r["development"])
            if sig in seen:
                continue
            seen.add(sig)
            v = book.single(r["config"],val)
            r["validation"] = v
            r["qualified_before_test"] = r["passed"] and v["net_pct"]>0 and v["trades"]>=10
            shortlist.append(r)
            if len(shortlist)==3:
                break
        selected[rule] = max(shortlist,key=lambda r:(r["qualified_before_test"],r["validation"]["trades"]>=10,
                                                      r["validation"]["net_pct"]-.18*r["validation"]["closed_dd_pct"],r["score"]))
    write("frozen.json",dict(inputs=fingerprint(),selected=selected))
    print([(r,x["config"],x["qualified_before_test"]) for r,x in selected.items()],flush=True)


def evaluate(section):
    frozen = json.loads((ROOT/"frozen.json").read_text())
    assert frozen["inputs"]==fingerprint(), "Frozen signal or selection rules changed"
    configs = [r["config"] for r in frozen["selected"].values()]
    interval = limits(PERIODS[section])
    results = {}
    for stress in (False,True):
        book = Book(section,stress)
        individual = {c["rule"]:book.single(c,interval) for c in configs}
        joint = replay(book,configs,section)
        ledger = joint.pop("ledger")
        assert joint["trades"]==len(ledger)
        if not stress:
            write(section+"-trades.json",ledger)
            for c in configs:
                check = replay(book,[c],section)
                truth = individual[c["rule"]]
                assert check["trades"]==truth["trades"] and abs(check["final"]-truth["final"])<1e-7
        eligible = [c for c in configs if frozen["selected"][c["rule"]]["qualified_before_test"]
                    and individual[c["rule"]]["net_pct"]>=10 and individual[c["rule"]]["trades"]>=15]
        passing = replay(book,eligible,section) if eligible else dict(final=150.0,net_pct=0.0,trades=0)
        passing.pop("ledger",None)
        results["stress" if stress else "base"] = dict(individual=individual,all_four=joint,
                eligible_rules=[c["rule"] for c in eligible],eligible_joint=passing)
        print(section,stress,joint, [(r,round(t["net_pct"],2),t["trades"]) for r,t in individual.items()],flush=True)
    write(section+"-summary.json",dict(span=PERIODS[section],**results))


if __name__=="__main__":
    p = argparse.ArgumentParser()
    p.add_argument("action",choices=["build","freeze","evaluate","forward"])
    p.add_argument("section",nargs="?")
    p.add_argument("--fetch",action="store_true",help="Fetch updated public data for the forward end date before replay")
    args = p.parse_args()
    if args.action=="build":
        build(args.section)
    elif args.action=="freeze":
        freeze()
    elif args.action=="evaluate":
        evaluate(args.section)
    elif args.action=="forward":
        from datetime import date,datetime,timedelta
        from zoneinfo import ZoneInfo
        import subprocess,sys
        end = date.fromisoformat(args.section)
        if end>datetime.now(ZoneInfo("Asia/Seoul")).date():
            p.error("Only completed KST dates can be used")
        section = "forward_"+end.isoformat()
        PERIODS[section] = ((end-timedelta(days=60)).isoformat(),end.isoformat())
        if args.fetch:
            subprocess.run([sys.executable,"timing_research/fetch_public.py","--start",PERIODS[section][0],"--end",end.isoformat()],check=True)
        location(section).mkdir(parents=True,exist_ok=True)
        instruments=meta()
        base,start,finish=dates(section)
        for sym in COINS:
            _,coverage=prepare((section,sym))
            ins=instruments[sym]
            listed=int(ins.get("listTime") or 0)
            expired=int(ins.get("expTime") or 0)
            active=max(start,listed)<min(finish,expired or finish)
            allowed_tail=max(0,(finish-expired+MINUTE-1)//MINUTE) if expired else 0
            if coverage["missing_inside"] or coverage["missing_tail"]>allowed_tail or (active and not coverage["valid_minutes"]):
                raise ValueError("Missing active history: "+sym)
        build(section)
        evaluate(section)

"""Decompose the same simulated fills and quantities into price movement and costs."""
import json
import pandas as pd
from signals import ROOT, COINS
from tick_replay import locations

def main():
    ledger=json.loads((ROOT/"recent-ticks-all-ledger.json").read_text())
    frame=pd.concat([pd.read_pickle(locations("recent",sym)[2]) for sym in COINS],ignore_index=True)
    lookup={(r.rule,r.symbol,int(r.fill)):r for r in frame[~frame.stress].itertuples()}
    columns=["gross_price_usdt","fees_usdt","slippage_usdt","funding_usdt","net_usdt","notional_usdt"]
    total=dict.fromkeys(columns,0.)
    rules={}
    for trade in ledger:
        r=lookup[trade["rule"],trade["symbol"],trade["entry"]]
        # This ledger has no zero-net fills; otherwise the recorded quantity would be required.
        if abs(r.net)<=1e-12:
            raise ValueError("The quantity of a zero-return trade cannot be reconstructed from net PnL")
        nominal=trade["net_usdt"]/r.net
        quantity=nominal/r.price
        entry=r.price/(1+r.side*.0005)
        exit=r.exit_price/(1-r.side*.0005)
        gross=quantity*r.side*(exit-entry)
        fee=quantity*.0005*(r.price+r.exit_price)
        slip=gross-quantity*r.side*(r.exit_price-r.price)
        funding=nominal*sum(r.funding)
        net=trade["net_usdt"]
        assert abs(gross-fee-slip+funding-net)<1e-8
        per_rule=rules.setdefault(r.rule,dict.fromkeys(columns,0.))
        for key,value in zip(columns,(gross,fee,slip,funding,net,nominal)):
            total[key]+=value
            per_rule[key]+=value
    output=dict(valuation="Same fills and quantities, unadjusted public prints for gross. An attribution of this run.",
                aggregate=total,by_rule=rules)
    (ROOT/"costs.json").write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")

if __name__=="__main__":
    main()

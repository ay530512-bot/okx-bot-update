"""Cache and verify trade prints for the study dates, using the public daily/monthly files."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, timedelta
import os
from pathlib import Path
import shutil
import time
from urllib.request import Request,urlopen
from zipfile import ZipFile

from signals import COINS, PLAN

def periods(start, end):
    d = start-timedelta(days=1)  # KST midnight is 23:00 by the archive's UTC+8 date.
    while d<end:
        next_month=(d.replace(day=28)+timedelta(days=4)).replace(day=1)
        if d.day==1 and next_month<=end:
            yield d.strftime("%Y-%m")
            d=next_month
        else:
            yield d.isoformat()
            d+=timedelta(days=1)

def get(job):
    sym,period=job
    file=Path("tick_cache")/f"{sym}-{period}.zip"
    if file.is_file():
        return file
    name=f"{sym}-USDT-SWAP-trades-{period}.zip"
    freq="daily" if len(period)==10 else "monthly"
    url=f"https://static.okx.com/cdn/okex/traderecords/trades/{freq}/{period.replace('-','')}/{name}"
    for k in range(4):
        try:
            tmp=file.with_suffix(".download")
            with urlopen(Request(url,headers={"User-Agent":"public-market-wick-replay"}),timeout=55) as src,tmp.open("wb") as dest:
                shutil.copyfileobj(src,dest,length=262144)
            with ZipFile(tmp) as z:
                if not any(n.endswith(".csv") for n in z.namelist()):
                    raise ValueError("No trade CSV in "+name)
            os.replace(tmp,file)
            return file
        except OSError:
            if k==3: raise
            time.sleep(1+k)

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--symbols",nargs="+",default=PLAN["tick_sample"]["symbols"])
    p.add_argument("--start",type=date.fromisoformat,default=date.fromisoformat(PLAN["recent"][0]))
    p.add_argument("--end",type=date.fromisoformat,default=date.fromisoformat(PLAN["recent"][1]))
    args=p.parse_args()
    names=COINS if args.symbols==["all"] else args.symbols
    Path("tick_cache").mkdir(exist_ok=True)
    jobs=[(s,d) for d in periods(args.start,args.end) for s in names]
    with ThreadPoolExecutor(12) as pool:
        f=[pool.submit(get,j) for j in jobs]
        total=0
        for i,x in enumerate(as_completed(f),1):
            total+=x.result().stat().st_size
            if i%25==0 or i==len(f):
                print(i,len(f),round(total/1e6,1),"MB",flush=True)

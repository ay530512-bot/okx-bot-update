"""Replay the direct wick entry and trailing stop on chronological public prints."""
import argparse
from bisect import bisect_right
import ctypes
from datetime import date,timedelta
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import subprocess
from zipfile import ZipFile

import numpy as np
import pandas as pd
from signals import PLAN,ROOT,COINS,MINUTE,dates,location,meta,setups
from inputs import PERIODS
from tick_inputs import periods

CACHE=Path("tick_cache")
LIB=CACHE/"wick_path.so"
SOURCE=ROOT/"tick_path.cpp"
I=ctypes.c_int
F=ctypes.c_double
TIME=ctypes.c_int64
DOUBLE=np.ctypeslib.ndpointer(dtype=np.float64,flags="C_CONTIGUOUS")
LONG=np.ctypeslib.ndpointer(dtype=np.int64,flags="C_CONTIGUOUS")
VERSION=hashlib.sha256(b"".join((ROOT/n).read_bytes() for n in
    ("signals.py","frozen.json","tick_replay.py","tick_path.cpp","tick_inputs.py"))).hexdigest()[:12]

@lru_cache(maxsize=1)
def dll():
    d=ctypes.CDLL(str(LIB.resolve()))
    d.touch_trade.argtypes=[LONG,DOUBLE,I,I,I,DOUBLE,TIME,I,I,I,F,F,F,F,F,F,F,I,F,DOUBLE]
    d.touch_trade.restype=I
    return d

def configs():
    return {k:r["config"] for k,r in json.loads((ROOT/"frozen.json").read_text())["selected"].items()}

def in_session(ts,c):
    hr=((int(ts)//MINUTE+540)//60)%24
    return (hr-c["start"])%24<(c["end"]-c["start"])%24

def span_of(period):
    d=date.fromisoformat(period if len(period)==10 else period+"-01")
    e=(d+timedelta(days=1)) if len(period)==10 else ((d.replace(day=28)+timedelta(days=4)).replace(day=1))
    return tuple(int(pd.Timestamp(k,tz="Asia/Shanghai").timestamp()*1000) for k in (d,e))

def locations(section,symbol):
    stem=CACHE/(section+"-"+symbol+"-"+VERSION)
    return tuple(Path(str(stem)+tail) for tail in ("-time.npy","-px.npy","-paths.pkl","-coverage.json"))

def eligible_setups(section,symbol,bars):
    base,start,finish=dates(section)
    first=(start-base)//MINUTE
    last=(finish-base)//MINUTE
    n=len(bars)
    needed=np.zeros(n,dtype=bool)
    pos=np.arange(n)
    next_active=np.minimum.accumulate(np.where(bars[:,4]>0,pos,n)[::-1])[::-1]
    tst=base+pos*MINUTE
    hours=((tst//MINUTE+540)//60)%24
    selected=configs()
    active=[]
    with np.errstate(invalid="ignore",divide="ignore"):
        for s in setups(section,symbol,meta()[symbol]):
            c=selected[s.rule]
            if s.profile!=c["profile"]:
                continue
            a=max(s.start,first)
            b=min(s.end,last-c["hold"])
            if a>=b or not np.any((hours[a:b]-c["start"])%24<(c["end"]-c["start"])%24):
                continue
            # Price outside the band for every minute means no underlying trade could have touched it.
            view=bars[s.start:s.end]
            adverse=(view[:,2] if s.side==1 else -view[:,1])
            favorable=(view[:,1] if s.side==1 else -view[:,2])
            eps=s.tick*1.e-5
            if not np.any((adverse<=s.upper+eps)&(favorable>=s.lower-eps)):
                continue
            active.append(s)
            end=min(n-1,s.end+c["hold"]+1)
            # A time-stop/market fill can land in a later minute if there were no prints at the deadline.
            end=min(n,int(next_active[end])+2)
            needed[s.start:end]=True
    return active,needed

def read_prices(section,symbol,bars,needed):
    time_file,px_file,_,_=locations(section,symbol)
    base,start,finish=dates(section)
    parts=[]
    period=PERIODS[section]
    for tag in periods(date.fromisoformat(period[0]),date.fromisoformat(period[1])):
        a,b=span_of(tag)
        if not needed[max(0,(a-base)//MINUTE):min(len(needed),(b-base)//MINUTE)].any():
            continue
        file=CACHE/f"{symbol}-{tag}.zip"
        with ZipFile(file) as z:
            for name in sorted(n for n in z.namelist() if n.endswith(".csv")):
                with z.open(name) as source:
                    for chunk in pd.read_csv(source,usecols=["created_time","trade_id","price"],
                            dtype={"created_time":"int64","trade_id":"int64","price":"float64"},chunksize=400000):
                        t=chunk.created_time.to_numpy()
                        m=(t-base)//MINUTE
                        ok=(m>=0)&(m<len(needed))&needed[np.clip(m,0,len(needed)-1)]
                        if ok.any():
                            parts.append((t[ok],chunk.trade_id.to_numpy()[ok],chunk.price.to_numpy()[ok]))
    if parts:
        t,trade,px=(np.concatenate(arrays) for arrays in zip(*parts))
        del parts
        if np.any(t[1:]<t[:-1]) or np.any((t[1:]==t[:-1])&(trade[1:]<trade[:-1])):
            order=np.lexsort((trade,t))
            t,trade,px=t[order],trade[order],px[order]
        if np.any((t[1:]==t[:-1])&(trade[1:]==trade[:-1])):
            raise ValueError(symbol+" duplicate public trades")
        ix=(t-base)//MINUTE
        first=np.r_[0,np.flatnonzero(ix[1:]!=ix[:-1])+1]
        minute=ix[first]
        expected=np.flatnonzero(needed&(bars[:,4]>0))
        if not np.array_equal(minute,expected):
            diff=np.setxor1d(minute,expected)
            raise ValueError(f"{symbol}: active-minute discrepancy in {len(diff)} bars, first {diff[:5]}")
        lo=np.minimum.reduceat(px,first)
        hi=np.maximum.reduceat(px,first)
        mismatch=(~np.isclose(lo,bars[expected,2],rtol=1e-9,atol=1e-15)
                 |~np.isclose(hi,bars[expected,1],rtol=1e-9,atol=1e-15))
        if mismatch.any():
            raise ValueError(f"{symbol}: inconsistent trade extrema for {mismatch.sum()} active minutes, first {expected[mismatch][:5]}")
    else:
        t=np.empty(0,dtype="int64")
        px=np.empty(0,dtype="float64")
        if np.any(needed&(bars[:,4]>0)):
            raise ValueError(symbol+" lacks tick coverage")
    np.save(time_file,t)
    np.save(px_file,px)
    return t,px

def public_path(s,bars,op5,ts,px,base,hold,slip):
    lo,hi=np.searchsorted(ts,[base+s.start*MINUTE,base+s.end*MINUTE])
    out=np.full(10,np.nan)
    status=dll().touch_trade(ts,px,len(ts),int(lo),int(hi),op5,base,s.side,int(s.family=="reversal"),int(s.armed),
                    s.level,s.atr,s.tick,s.lower,s.upper,s.step,s.depart,hold,slip,out)
    return status,out

def prepare_symbol(job):
    section,symbol=job
    time_file,px_file,out_file,coverage_file=locations(section,symbol)
    if coverage_file.is_file() and out_file.is_file() and time_file.is_file() and px_file.is_file():
        return json.loads(coverage_file.read_text())
    base,start,finish=dates(section)
    bars=np.asarray(np.load(location(section)/f"{symbol}-1.npy",mmap_mode="r"))
    op5=np.ascontiguousarray(np.load(location(section)/f"{symbol}-5.npy",mmap_mode="r")[:,0])
    active,needed=eligible_setups(section,symbol,bars)
    ts,px=read_prices(section,symbol,bars,needed)
    selected=configs()
    funding=np.flatnonzero(bars[:,5]!=0)
    ft=base+funding*MINUTE
    events=[]
    count=0
    for s in active:
        c=selected[s.rule]
        for stress in (False,True):
            status,v=public_path(s,bars,op5,ts,px,base,c["hold"],.001 if stress else .0005)
            if not status or not in_session(v[0],c) or v[0]<start or v[0]>=finish-c["hold"]*MINUTE:
                continue
            if not stress: count+=1
            if status<2 or v[4]>=finish:
                continue
            ids=funding[np.searchsorted(ft,v[3],side="right"):np.searchsorted(ft,v[4],side="right")]
            carry=-s.side*bars[ids,0]*bars[ids,5]/v[5]
            events.append(dict(rule=s.rule,symbol=symbol,side=s.side,quality=s.quality,stress=stress,
                 signal=int(v[0]),ref=v[1],wick=v[2],fill=int(v[3]),exit=int(v[4]),price=v[5],risk=v[6],
                 net=float(v[7]+carry.sum()),stop=v[8],exit_price=v[9],tick=s.tick,
                 funding_t=(base+ids*MINUTE).tolist(),funding=carry.tolist()))
    pd.DataFrame(events).to_pickle(out_file)
    report=dict(symbol=symbol,public_trades_in_covered_windows=len(ts),covered_active_minutes=int((needed&(bars[:,4]>0)).sum()),
                setups=len(active),session_triggers=count,possible_fills=sum(not r["stress"] for r in events))
    coverage_file.write_text(json.dumps(report))
    return report

class Market:
    def __init__(self,section):
        self.section=section
        self.instruments=meta()

    @lru_cache(maxsize=40)
    def tape(self,symbol):
        t,p,*_=locations(self.section,symbol)
        return np.load(t,mmap_mode="r"),np.load(p,mmap_mode="r")

    def mark_and_stop(self,r,decision):
        if decision<=r["fill"]:
            return r["price"],r["stop"]
        ts,px=self.tape(r["symbol"])
        # Only use prints strictly earlier than a simultaneous multi-instrument decision.
        a,b=np.searchsorted(ts,[r["fill"],decision])
        if b<=a:
            return r["price"],r["stop"]
        mark=px[b-1]
        peak=(np.max if r["side"]==1 else np.min)(px[a:b])
        stop=r["stop"]
        risk=r["risk"]*r["price"]
        if r["side"]*(peak-r["price"])>=risk:
            raw=(peak-r["side"]*risk)/r["tick"]
            improved=(math.floor(raw+1e-10) if r["side"]==1 else math.ceil(raw-1e-10))*r["tick"]
            if r["side"]*(improved-stop)>0:
                stop=improved
        return mark,stop

def account(rows,mkt,stress):
    cash=150.
    open_positions={}
    daily={}
    ledger=[]
    fee=.0005
    slip=.001 if stress else .0005
    peak=150.
    drawdown=0.
    count=0
    def book_closed(t):
        nonlocal cash,peak,drawdown
        for rule,r in sorted(list(open_positions.items()),key=lambda pair:pair[1]["exit"]):
            if r["exit"]>t:
                break
            pnl=r["notional"]*r["net"]
            cash+=pnl
            peak=max(peak,cash)
            drawdown=max(drawdown,1-cash/peak)
            ledger.append(dict(rule=rule,symbol=r["symbol"],entry=r["fill"],exit=r["exit"],net_usdt=pnl))
            del open_positions[rule]
    for r in rows:
        now=r["signal"]
        book_closed(now)
        code=r["rule"]
        day=(now+9*3600000)//86400000
        if code in open_positions or any(p["symbol"]==r["symbol"] for p in open_positions.values()) or daily.get((code,day),0)>=4:
            continue
        equity=cash
        margin=open_risk=0.
        for p in open_positions.values():
            mark,stop=mkt.mark_and_stop(p,now)
            accrued=sum(p["funding"][:bisect_right(p["funding_t"],now)])
            nominal=p["notional"]
            equity+=nominal*(p["side"]*(mark/p["price"]-1)-fee+accrued)
            margin+=nominal/10
            open_risk+=nominal/p["price"]*(max(0.,p["side"]*(mark-stop))+2*(fee+slip)*mark)
        eq=max(0.,equity-3)
        budget=min(.005*eq,max(0.,.02*eq-open_risk))
        # Calculate quantity at the trigger price known when the order is sent.
        expected=r["ref"]*(1+r["side"]*slip)
        fractional=r["side"]*(expected-r["stop"])/expected
        if fractional<=0: continue
        nominal=min(eq*.10*10,budget/(fractional+2*(fee+slip)))
        ins=mkt.instruments[r["symbol"]]
        ct,lot,mn,mx=(float(ins[k]) for k in ("ctVal","lotSz","minSz","maxMktSz"))
        quantity=math.floor(nominal/(ct*expected*lot)+1e-12)*lot
        if not mn<=quantity<=mx or quantity*ct*expected*(.10+fee)>eq-margin:
            continue
        nominal=quantity*ct*r["price"]
        open_positions[code]=dict(r,notional=nominal)
        daily[code,day]=daily.get((code,day),0)+1
        count=max(count,len(open_positions))
    book_closed(2**62)
    assert not open_positions and abs(cash-150-sum(x["net_usdt"] for x in ledger))<1e-7
    return dict(final=cash,net_pct=100*(cash/150-1),trades=len(ledger),wins=sum(r["net_usdt"]>0 for r in ledger),
                closed_drawdown_pct=100*drawdown,max_open=count,ledger=ledger)

def run(section,symbols,workers):
    if not LIB.is_file() or SOURCE.stat().st_mtime>LIB.stat().st_mtime:
        subprocess.run(["g++","-std=c++17","-O3","-fPIC","-shared",str(SOURCE),"-o",str(LIB)],check=True)
    with ProcessPoolExecutor(workers) as pool:
        coverage=list(pool.map(prepare_symbol,[(section,s) for s in symbols]))
    frames=[pd.read_pickle(locations(section,s)[2]) for s in symbols]
    pool=pd.concat([f for f in frames if len(f)],ignore_index=True) if any(len(f) for f in frames) else pd.DataFrame()
    mkt=Market(section)
    output=dict(span=PERIODS[section],universe=symbols,coverage=coverage)
    fixed=configs()
    for stress in (False,True):
        events=(pool[pool.stress==stress].sort_values(["signal","rule","quality","symbol"],
                    ascending=[True,True,False,True]).to_dict("records") if len(pool) else [])
        individual={}
        for rule in fixed:
            one=account([r for r in events if r["rule"]==rule],mkt,stress)
            one.pop("ledger")
            individual[rule]=one
        combined=account(events,mkt,stress)
        ledger=combined.pop("ledger")
        tag="all" if set(symbols)==set(COINS) else "-".join(symbols)
        label="stress" if stress else "base"
        output[label]=dict(individual=individual,all_four=combined)
        if not stress:
            (ROOT/(section+"-ticks-"+tag+"-ledger.json")).write_text(json.dumps(ledger,indent=2)+"\n")
        print(label,combined,[(k,round(v["net_pct"],2)) for k,v in individual.items()],flush=True)
    (ROOT/(section+"-ticks-"+tag+".json")).write_text(json.dumps(output,indent=2,allow_nan=False)+"\n")

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--symbols",nargs="+",default=PLAN["tick_sample"]["symbols"])
    p.add_argument("--section",default="recent")
    p.add_argument("--end",type=date.fromisoformat,help="New completed 60-day period after preparing the candle inputs")
    p.add_argument("--workers",type=int,default=3)
    args=p.parse_args()
    if args.end:
        from datetime import datetime
        from zoneinfo import ZoneInfo
        if args.end>datetime.now(ZoneInfo("Asia/Seoul")).date():
            p.error("Only completed KST dates can be used")
        args.section="forward_"+args.end.isoformat()
        PERIODS[args.section]=((args.end-timedelta(days=60)).isoformat(),args.end.isoformat())
    run(args.section,COINS if args.symbols==["all"] else args.symbols,args.workers)

"""Two distinct wick tests, or one pullback to an average. No swing-break entry."""
from dataclasses import dataclass
import json
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(Path.cwd()/"target_research"))
from inputs import COINS, MINUTE, dates, location
from paths import meta
from patterns import ema, roll, shift

PLAN = json.loads((ROOT/"plan.json").read_text())


@dataclass(frozen=True)
class Setup:
    family: str
    side: int
    source: int             # completed five-minute candle index
    start: int              # minute indexes, inclusive / exclusive
    end: int
    level: float            # prices are signed, so both sides reject a low
    atr: float
    tick: float
    band: float
    step: float
    depart: float
    armed: bool
    quality: float
    profile: str

    @property
    def rule(self):
        return "wick_touch_" + self.family + ("_long" if self.side == 1 else "_short")

    @property
    def lower(self):
        return self.level + self.tick if self.family == "reversal" else self.level - self.band

    @property
    def upper(self):
        return self.level + (self.band if self.family=="reversal" else self.tick)

    @property
    def chase(self):
        return max(3*self.tick, .25*self.atr)


def setups(section, symbol, instrument, period=None):
    folder = location(section)
    five = np.load(folder / f"{symbol}-5.npy", mmap_mode="r")
    parent = np.load(folder / f"{symbol}-15.npy", mmap_mode="r")
    op, high, low, close, volume = five[:, :5].T
    base, start_ms, end_ms = dates(section)
    start = (start_ms-base)//MINUTE if period is None else period[0]
    end = (end_ms-base)//MINUTE if period is None else period[1]
    tick = float(instrument["tickSz"])
    i = np.arange(len(five))
    j15 = np.maximum(0, (i+1)//3-1)  # last fully closed 15m bar at a setup's decision time
    close15 = parent[:,3]
    fast, slow = ema(close15,20), ema(close15,50)
    slope = (fast-shift(fast,3))[j15]
    change = (close15-shift(close15,3))[j15]
    avg5 = ema(close,20)
    prev = shift(close)
    tr = np.maximum.reduce((high-low, abs(high-prev), abs(low-prev)))
    atr = roll(tr,14,"mean")
    prev_atr = shift(atr)
    relative = volume/shift(roll(volume,20,"mean"))
    turnover = roll(volume*close*float(instrument["ctVal"]),12,"sum")
    ready = ((roll(np.isfinite(close).astype(float),100,"sum")==100)
             & ((roll(np.isfinite(close15).astype(float),55,"sum")==55)[j15])
             & (tick/close<=.0005) & (turnover>=60000)
             & (atr/close>=.0014) & (atr/close<=.04) & (volume>0))
    # Include previously armed setups that might reach the requested interval.
    span = ((i+1)*5 < end) & ((i+1)*5+180 > start)
    for side in (1,-1):
        floor, top = (low,high) if side==1 else (-high,-low)
        last = side*close
        wick = (np.minimum(side*op,last)-floor)/(top-floor)
        reversal = (ready & (side*slope<0) & (side*change<0) & (wick>=1/3)
                    & (relative>=1.5) & (volume>shift(volume)) & np.isfinite(prev_atr)
                    & (floor<=shift(roll(floor,4,"min"))+.10*prev_atr)
                    & (shift(roll(top,12,"max"))-floor>=1.5*prev_atr))
        regime = (ready & (side*slope>0) & (side*(fast[j15]-slow[j15])>0)
                  & (side*(close15[j15]-fast[j15])>0))
        local_high = roll(top,4,"max")
        anchor_list = np.flatnonzero(reversal & span)
        for profile, params in PLAN["profiles"].items():
            width, ticks = params["zone_atr"], params["bounce_ticks"]
            for n,j in enumerate(anchor_list):
                a = float(atr[j])
                band = max(3*tick,width*a)
                departure = floor[j]+band+max(tick,.12*a)
                begin = int((j+1)*5)
                stop = min(begin+180,len(five)*5)
                if n+1 < len(anchor_list):
                    stop = min(stop,int((anchor_list[n+1]+1)*5))
                yield Setup("reversal",side,int(j),begin,stop,float(floor[j]),a,tick,
                            band,ticks*tick,float(departure),last[j]>=departure,
                            float(min(relative[j],5)+wick[j]),profile)
            band = np.maximum(3*tick,width*atr)
            # Everything here is known before the pullback candle opens.
            candidates = (regime & (last>side*avg5+band)
                          & (local_high>=side*avg5+band+.30*atr)
                          & ((i+2)*5>start) & ((i+1)*5<end) & (i+1<len(five)))
            for j in np.flatnonzero(candidates):
                j1 = j+1
                level = side*avg5[j]
                # Lossless range index only: if no price in the next candle can enter
                # this band, no tick inside it can trigger. Later lows cannot veto an earlier entry.
                if floor[j1]>level+tick+tick*1e-5 or top[j1]<level-band[j]-tick*1e-5:
                    continue
                yield Setup("trend",side,int(j),int(j1*5),int((j1+1)*5),float(level),
                            float(atr[j]),tick,float(band[j]),ticks*tick,0.,True,
                            float(abs(fast[j15[j]]-slow[j15[j]])/atr[j]),profile)


class Probe:
    """One local rejection, observable as prices arrive. Feed signed low then observed price."""
    def __init__(self, setup):
        self.s = setup
        self.armed = setup.armed
        self.done = False
        self.bar = -1
        self.low = np.inf

    def observe(self, index5, opening5, low, last):
        s = self.s
        eps = s.tick*1e-5
        if self.done:
            return None
        if low < s.lower-eps:
            self.done = True
            return None
        if not self.armed:
            self.armed = last >= s.depart-eps
            return None
        if self.bar != index5:
            self.bar = index5
            self.low = np.inf
        if low <= s.upper+eps:
            self.low = min(self.low, low)
        if not math.isfinite(self.low):
            return None
        wick = min(opening5,last)-self.low
        rise = last-self.low
        if rise+eps<s.step or wick+eps<s.tick:
            return None
        self.done = True
        if rise>s.chase+eps or (s.family=="trend" and wick>max(3*s.tick,.25*s.atr)+eps):
            return None
        return self.low


def minute_event(s, bars):
    probe = Probe(s)
    for k in range(s.start,min(s.end,len(bars)-1)):
        op,high,low,close,vol = bars[k,:5]
        if not np.isfinite(close):
            return None
        if vol<=0:
            continue
        adverse = low if s.side==1 else -high
        if not probe.armed and s.side*op>=s.depart:
            probe.armed = True
        extreme = probe.observe(k//5,s.side*bars[k-k%5,0],adverse,s.side*close)
        if extreme is not None:
            # The last price of the observed minute is known only at its end.
            nxt = bars[k+1,0]*s.side
            if not np.isfinite(nxt) or nxt<s.lower-s.tick*1e-5 or nxt-extreme>s.chase+s.tick*1e-5:
                return None
            return k, float(close), extreme
        if probe.done:
            return None
    return None


def tick_event(s, bars, ts, prices, base_ms):
    probe = Probe(s)
    lo,hi = np.searchsorted(ts,[base_ms+s.start*MINUTE,base_ms+s.end*MINUTE])
    for n in range(int(lo),int(hi)):
        clock = int((ts[n]-base_ms)//MINUTE)
        px = s.side*prices[n]
        extreme = probe.observe(clock//5,s.side*bars[clock-clock%5,0],px,px)
        if extreme is not None:
            return n, extreme
        if probe.done:
            return None
    return None


def minute_signals(section):
    instruments = meta()
    rows = []
    for symbol in COINS:
        bars = np.asarray(np.load(location(section)/f"{symbol}-1.npy",mmap_mode="r"))
        with np.errstate(invalid="ignore",divide="ignore"):
            for s in setups(section,symbol,instruments[symbol]):
                hit = minute_event(s,bars)
                if hit is None:
                    continue
                minute,ref,extreme = hit
                support = s.level if s.family=="reversal" else extreme
                stop = s.side*np.floor((support-max(2*s.tick,.25*s.atr))/s.tick+1.e-9)*s.tick
                rows.append(dict(rule=s.rule,profile=s.profile,mode="touch",clock=minute+1,ref=ref,
                                 atr=s.atr,stop=stop,side=s.side,symbol=symbol,coin=COINS.index(symbol),
                                 quality=s.quality,source=s.source,level=s.side*s.level,probe=s.side*extreme))
    keys = ["rule","profile","clock"]
    if not rows:
        return pd.DataFrame(columns=keys+["mode","ref","atr","stop","side","symbol","coin","quality","source","level","probe"])
    return (pd.DataFrame(rows).sort_values(keys+["quality","symbol"],ascending=[True]*3+[False,True])
            .drop_duplicates(keys).reset_index(drop=True))

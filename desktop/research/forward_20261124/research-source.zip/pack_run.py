"""Bundle a reproducible closed-day snapshot with bounded-size Git blobs."""
from pathlib import Path
import hashlib,json,zipfile
OUT=Path('publish');OUT.mkdir(exist_ok=True)
def pack(name,paths):
    arc=Path('day')/(name+'.zip');idx=[]
    with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for src in sorted(paths):
            if src.is_file():
                info=zipfile.ZipInfo(str(src),(2026,11,24,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
                z.writestr(info,src.read_bytes())
    blob=arc.read_bytes()
    for j in range(0,len(blob),216000):
        x=blob[j:j+216000];part=OUT/f'{name}.zip.part{j//216000:03d}';part.write_bytes(x)
        idx.append(dict(file=part.name,bytes=len(x),sha256=hashlib.sha256(x).hexdigest()))
    (OUT/(name+'.json')).write_text(json.dumps(dict(bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),parts=idx),indent=1))
if __name__=='__main__':
    import sys
    if sys.argv[1]=='market':
        pack('market',list(Path('day/cache').glob('*'))+[Path('day/archive_status.json')])
    elif sys.argv[1]=='execution':
        pack('execution',list(Path('day/ticks').glob('*.gz'))+list(Path('day/development_ticks').glob('*.gz')))
    elif sys.argv[1]=='evidence':
        files=list(Path('day/result').glob('*.json'))+list(Path('day/paths').glob('*.json'))+list(Path('day/diagnostics').rglob('*'))+list(Path('day/pc290').rglob('*.json'))+list(Path('day/timing').rglob('*.json'))
        files += [Path('day')/name for name in ('accounts.json','state.json','input_checks.json','exact_markouts.json','range_scan.json','scan.json','pc331_closed_offers.json')]
        pack('evidence',files)

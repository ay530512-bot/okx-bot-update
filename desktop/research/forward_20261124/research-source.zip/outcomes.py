"""Price the previously frozen forward controls. All decision times and data are inside the closed KST date."""
from adapter import *
import math
from collections import defaultdict

FEE=.0005
@lru_cache(4096)
def first(sym,ts):
    if ts>=E:raise ValueError('next fill outside closed-day inputs')
    m=ts//M*M
    store=ROOT/'day/ticks'
    if (store/f'{sym}-{m}.json.gz').exists():
        for row in tape(sym,m):
            if row[0]>=ts:return row
    sec=ts//1000*1000
    secondfile=store/f'secondtrades-{sym}-{sec}.json.gz'
    if secondfile.is_file():
        for row in json.load(gzip.open(secondfile)):
            if row[0]>=ts:return row
    key=store/f'boundary-{sym}-{ts}.json.gz'
    if key.exists():return json.load(gzip.open(key))['next']
    from cache_day import api
    inst=sym+'-USDT-SWAP';previous=api('market/history-trades',instId=inst,type=2,after=int(ts),limit=1)[0]
    idx=int(previous['tradeId']);nxt=api('market/history-trades',instId=inst,type=1,after=idx+2,limit=1)[0]
    row=[int(nxt['ts']),int(nxt['tradeId']),float(nxt['px']),float(nxt['sz']),nxt['side']]
    if row[1]!=idx+1 or int(previous['ts'])>=ts or not ts<=row[0]<E:raise ValueError('boundary is unverified')
    key.write_bytes(gzip.compress(json.dumps(dict(previous=previous,next=row)).encode(),mtime=0));return row

def path(sym,ev,slip,band):
    rule,side,t,q,stop,quality,deadline,lev,arm,gap=ev
    d=data(sym);meta=d['instrument'][0];tick=float(meta['tickSz'])
    fill,tid,raw,*_=first(sym,t+int('scalp' not in rule))
    if (rule.startswith('selected_') and fill-t>M) or (deadline>0 and fill>=deadline):return dict(skip='late_fill')
    if not deadline:deadline=fill+(45 if rule=="trend_long" else 120 if rule.startswith(("bb_","trend_")) else 150)*M
    expected=q*(1+side*slip);entry=raw*(1+side*slip);risk=side*(entry-stop)
    live=side*stop;best=worst=side*raw;hit=None;reason=None
    def ratchet(fav):
        if fav-side*entry<arm*risk:return live
        return max(live,math.floor((fav-gap*risk)/tick+1e-10)*tick)
    def minute_prices(k):
        nonlocal best,worst,live
        if (ROOT/f'day/ticks/{sym}-{k}.json.gz').exists() or sym not in ('DOGE','XRP','ZEC','BREV'):
            yield from tape(sym,k);return
        from selective import seconds,prints
        for second in seconds(sym,k):
            clock=int(second[0])
            if clock+1000<=fill or not float(second[5]):continue
            low,high=sorted([side*float(second[2]),side*float(second[3])])
            if clock>fill and clock+1000<=deadline and low>ratchet(max(best,high)):
                best=max(best,high);worst=min(worst,low);live=ratchet(best);continue
            yield from prints(sym,second)
    if risk<=0:hit=first(sym,fill+1);reason='initial_stop'
    for k in range(fill//M*M,min(E,deadline+M),M):
        if hit:break
        r=bars1(sym)[k]
        if float(r[5])<=0:continue
        low,high=sorted([side*float(r[2]),side*float(r[3])])
        if k>fill and k+M<=deadline and low>ratchet(max(best,high)):
            best=max(best,high);worst=min(worst,low);live=ratchet(best);continue
        for clock,num,p,*_ in minute_prices(k):
            if num<=tid:continue
            if clock>=deadline:
                hit=[clock,num,p];reason='upper_band' if band else 'time';break
            worst=min(worst,side*p);best=max(best,side*p)
            if side*p<=live:
                hit=first(sym,clock+1);reason='initial_stop' if live==side*stop else 'trailing_stop';break
            live=ratchet(best)
    if not hit:
        if deadline>=E:
            # Value open risk at the last completed mark, retain as carry, do not book a sale.
            px=float(d['mark1m'][-1][4]);hit=[E,None,px];reason='carry_mark'
        else:hit=first(sym,deadline);reason='upper_band' if band else 'time'
    et,eid,eraw=hit[:3];close=eraw*(1-side*slip);gross=side*(eraw-raw)
    mark={int(r[0]):float(r[1]) for r in d['mark1m']}
    funding=sum(-side*float(r['realizedRate'])*mark[int(r['fundingTime'])] for r in d['funding'] if fill<int(r['fundingTime'])<=et)
    fee=FEE*(entry+close);drag=gross-side*(close-entry)
    marks={}
    for n in (5,15,30):
        boundary=(t+n*M)//M*M
        marks[n]=100*side*(float(bars1(sym)[boundary-M][4])/q-1) if boundary<=E else None
    level=lev
    if rule.startswith('selected_'):
        level=max(3,min(int(float(meta['lever'])),lev,5,math.floor(.015/(side*(q-stop)/q+.002)+1e-12)))
    return dict(symbol=sym,rule=rule,side=side,t=t,q=q,stop=stop,quality=quality,entry=entry,raw=raw,fill=fill,entry_id=tid,
        exit_price=close,exit=et,exit_id=eid,raw_exit=eraw,reason=reason,level=level,expected=expected,
        distance=side*(expected-stop)/expected+2*(FEE+slip),gross_unit=gross,fee_unit=fee,slippage_unit=drag,
        funding_unit=funding,net_unit=gross-fee-drag+funding,markouts_pct=marks,mfe_pct=100*max(0,best-side*raw,side*eraw-side*raw)/raw,
        mae_pct=100*max(0,side*raw-worst,side*raw-side*eraw)/raw,deadline=deadline,final_stop=side*live)
def run_symbol(sym):
    dest=ROOT/'day/paths'/f'{sym}.json'
    if dest.is_file():return
    d=json.loads((ROOT/'day/result'/f'{sym}.json').read_bytes());book=[]
    if 'events' not in d:return
    band={r['t']:r['band'] for r in d['scalp_observations']}
    for e in d['events']:
        variants={}
        for k,s in [('base',.0005),('stress',.001)]:
            try:variants[k]=path(sym,e,s,band.get(e[2],False) if 'scalp' in e[0] else False)
            except Exception as exc:variants[k]={'unverified':repr(exc)}
        if e[0].startswith('selected_'):
            matched=list(e);matched[-2:]=[1.,1.]
            try:variants['one_r']=path(sym,matched,.0005,band.get(e[2],False) if 'scalp' in e[0] else False)
            except Exception as exc:variants['one_r']={'unverified':repr(exc)}
        book.append(dict(event=e,variants=variants))
    (ROOT/'day/paths'/f'{sym}.json').write_text(json.dumps(book))
if __name__=='__main__':
    (ROOT/'day/paths').mkdir(exist_ok=True)
    with ThreadPoolExecutor(8) as pool:list(pool.map(run_symbol,SYMS))

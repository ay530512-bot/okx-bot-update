"""Alternative confirmations after an already observed rejection. Research arms, never live requirements."""
from adapter import *
from paired import run
def timings(sym,h):
    t,s,a,first=h['ts'],h['side'],h['anchor_ms'],h['first'];tick=float(data(sym)['instrument'][0]['tickSz']);bars=bars1(sym)
    end=min(E-M,t+5*M)
    # Only already confirmed three-bar pivots between the first extremum and the direct reaction.
    observed=[(m,r) for m,r in sorted(bars.items()) if a+15*M<=m and m+M<=t]
    levels=[s*float(r[2 if s==1 else 3]) for m,r in observed]
    pivots=[p for i,p in enumerate(levels[1:-1],1) if p>max(levels[i-1],levels[i+1])]
    level=max(pivots,default=None)
    out={'skip':dict(status='no_entry',net=0),'pivot':dict(status='no_prior_pivot' if level is None else 'waiting'),'minute':dict(status='waiting')};last_m=t//M*M
    for m in range(last_m,end+1,M):
        if m>=E:break
        o,hi,lo,c=map(float,bars[m][1:5])
        for ts,tid,p,_,_ in tape(sym,m):
            if tid<=h['trade_id'] or ts>end:continue
            if s*(p-first)<=tick*1e-6:
                for d in out.values():
                    if d['status']=='waiting':d['status']='anchor_breached'
                return out
            if out['pivot']['status']=='waiting' and s*p>=level+tick*(1-1e-7):
                out['pivot']=dict(status='reaction',ts=ts,trade_id=tid,price=p)
        if m+M<=end and m+M>t and out['minute']['status']=='waiting' and s*(c-o)>0 and s*(c-h['second'])>=tick*(1-1e-7):
            # Close is known only at the next boundary. The modeled fill must occur at or after it.
            out['minute']=dict(status='reaction',ts=m+M-1,decision_close_ms=m+M,trade_id=None,price=c)
        if all(d['status']!='waiting' for d in out.values()):break
    for d in out.values():
        if d['status']=='waiting':d['status']='expired'
    return out
def work(sym):
    base=json.loads((ROOT/f'day/pc290/{sym}.json').read_bytes())['events'];events=[];labels={};result=[]
    for h in base:
        try:choices=timings(sym,h)
        except Exception as err:choices={'unverified':repr(err)}
        result.append(dict(direct=h['ts'],side=h['side'],choices=choices))
        for label,v in choices.items():
            if not isinstance(v,dict) or v.get('status')!='reaction':continue
            e=dict(h,**v,source='deployed_wick15',anchor=h['anchor_ms'],atr=h['anchor_atr'])
            events.append(e);labels.setdefault((e['ts'],e['side']),[]).append((h['ts'],label))
    out=run(sym,ROOT/'day/cache',ROOT/'day/ticks',events,ROOT/'frozen/OKX_PC_PACKAGE') if events else []
    for r in out:r['association']=labels[(r['signal'],r['side'])].pop(0)
    (ROOT/f'day/timing/{sym}.json').write_text(json.dumps(dict(choices=result,paired=out),separators=(',',':')))
if __name__=='__main__':
    (ROOT/'day/timing').mkdir(exist_ok=True)
    with ThreadPoolExecutor(5) as pool:list(pool.map(work,SYMS))

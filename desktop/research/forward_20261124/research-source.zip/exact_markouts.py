"""Record the last public print at each exact hypothetical observation horizon."""
from adapter import E, M, ROOT, SYMS, ThreadPoolExecutor, bars1, data
from cache_day import api
from pathlib import Path
import json

def quote(sym, at):
    r=api('market/history-trades',instId=sym+'-USDT-SWAP',type=2,after=at+1,limit=1)[0]
    t=int(r['ts']);p=float(r['px'])
    if t>at or int(r['tradeId'])<=0 or p<=0:
        raise ValueError('invalid observation timestamp or trade')
    m=bars1(sym)[t//M*M]
    if not float(m[3])<=p<=float(m[2]):
        raise ValueError('public trade outside its native candle')
    return [t,int(r['tradeId']),p]

def one(sym):
    rows=json.loads((ROOT/'day/paths'/f'{sym}.json').read_bytes())
    out=[];quotes={}
    for row in rows:
        rule,side,t,signal,*_=row['event']
        for minutes in (5,15,30):
            at=t+minutes*M
            if at>=E:
                obs={'status':'outside_exclusive_end'}
            else:
                if at not in quotes:
                    try:quotes[at]=quote(sym,at)
                    except Exception as exc:quotes[at]={'missing':repr(exc)}
                tick=quotes[at]
                obs=({'last_trade':tick,'signal_to_last_pct':side*100*(tick[2]/signal-1)} if isinstance(tick,list) else tick)
            out.append(dict(rule=rule,symbol=sym,side=side,signal_ms=t,minutes=minutes,at_ms=at,**obs))
    return out

if __name__=='__main__':
    with ThreadPoolExecutor(6) as pool:
        rows=[row for result in pool.map(one,SYMS) for row in result]
    p=ROOT/'day'/'exact_markouts.json'
    p.write_text(json.dumps(rows,separators=(',',':')))

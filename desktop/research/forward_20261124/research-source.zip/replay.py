from adapter import *
from signals import setups,Probe
from scalp import wick_flags,exit_boundary
from bb_filter import close_bands,preceding_decline_and_pause
def examine(sym):
    one,five,_=arrays(sym);inst=data(sym)['instrument'][0];tick=float(inst['tickSz'])
    md,sd=close_bands(five);o,h,l,c,v=five[:,:5].T;pr=pd.Series(c).shift()
    atr=pd.Series(np.maximum.reduce([h-l,abs(h-pr),abs(l-pr)])).rolling(14).mean().to_numpy()
    vol=pd.Series(c*v);turn=(vol.rolling(3).sum()/(vol.shift(3).rolling(12).sum()/4)).to_numpy()
    green,red,rv=wick_flags(five,tick);counts=Counter();events=[];scalp_obs=[]
    for j in np.flatnonzero(green):
        t=BASE+(j+1)*5*M
        if not S<=t<E:continue
        n,band=exit_boundary(red,j);a=float(atr[j]);q=float(c[j]);anchor=float(l[j]);hr=int((t//3600000+9)%24)
        ev=indicators([[0,*r] for r in five[j-31:j+1,:5]],1,a)
        from pc_sizing import round_stop,leverage_for
        st=round_stop(anchor-max(2*tick,.15*a),tick,1);lev=leverage_for(dict(ev,stop=st),q,float(inst['lever'])) if ev else 0
        scalp_obs.append(dict(t=int(t),hour=hr,close=q,lev=lev,n=n,band=band))
        if lev:events.append(('base_scalp',1,int(t),q,st,float(rv[j]),int(t+n*5*M),lev,1.,1.))
        if not 4<=hr<8 or a/q<.0035 or (md[j]+2*sd[j])/q-1<.005:continue
        peers=[float(bars1(x)[t-M][4])>float(bars1(x)[t-16*M][4]) for x in SYMS if x!=sym]
        if np.mean(peers)<.55:continue
        rr=tape(sym,int(t-M));total=sum(r[2]*r[3] for r in rr)
        if len(rr)<5 or total<=0 or sum(r[2]*r[3] for r in rr if r[4]=='buy')<.58*total:continue
        events.append(('selected_scalp',1,int(t),q,round_stop(anchor-max(2*tick,.075*a),tick,1),float(rv[j]),int(t+n*5*M),indicator_level(ev),1.25,.75))
    for s in setups('session',sym,inst):
        side=s.side
        if s.family=='trend':
            if s.profile!='standard' or s.start<K:continue
            from pc_sizing import round_stop,leverage_for
            hour=((BASE+s.start*M)//3600000+9)%24
            if not (8<=hour<12 if side==1 else 0<=hour<4):continue
            det=Probe(s)
            for k in range(s.start,s.end):
                if not one[k,4]:continue
                lo,hi=sorted((side*one[k,1],side*one[k,2]));eps=tick*1e-5
                if hi<s.lower-eps:break
                if lo>s.upper+eps and not np.isfinite(det.low):continue
                for t,tid,px,_,_ in tape(sym,BASE+k*M):
                    j=k//5;trigger=det.observe(j,side*five[j,0],side*px,side*px)
                    if trigger is not None:
                        st=round_stop(side*(trigger-max(2*tick,.25*s.atr)),tick,side)
                        ev=indicators([[0,*r] for r in five[j-32:j,:5]],side,s.atr)
                        lv=leverage_for(dict(ev,stop=st),px,float(inst['lever'])) if ev and side*(px-st)>0 else 0
                        counts['trend_reaction']+=1
                        if lv:events.append(('trend_long' if side==1 else 'trend_short',side,t,px,st,s.quality,0,lv,1.,1.))
                    if det.done:break
                if det.done:break
            continue
        if s.family!='reversal' or s.profile!=('standard' if side==-1 else 'narrow'):continue
        if not preceding_decline_and_pause(five,md,sd,s.source,s.source+1,side,s.atr,observed_prices=[])[1]:continue
        end=min(s.end,(s.source+31)*5,len(one))
        def eligible(k):
            hour=((BASE+k*M)//3600000+9)%24
            j=k//5-1
            if k<K or not one[k,4]:return False,False
            return ((16<=hour<20 if side==1 else 12<=hour<16),
                    side==-1 and 8<=hour<12 and atr[j]/one[k,2]>=.006 and turn[j]>=1.25)
        if not any(any(eligible(k)) for k in range(s.start,end)):continue
        counts['eligible_anchor_windows']+=1
        obs=Probe(s)
        for k in range(s.start,end):
            if not one[k,4]:continue
            lo,hi=sorted((side*one[k,1],side*one[k,2]))
            if hi<s.lower-tick*1e-5:break
            if not obs.armed and lo>=s.lower-tick*1e-5 and hi<s.depart-tick*1e-5:continue
            if lo>s.upper+tick*1e-5 and (obs.bar!=k//5 or not math.isfinite(obs.low)):
                if not obs.armed and hi>=s.depart-tick*1e-5:obs.armed=True
                continue
            rr=tape(sym,BASE+k*M)
            for idx,(t,tid,p,_,_) in enumerate(rr):
                j=k//5
                extreme=obs.observe(j,side*five[j,0],side*p,side*p)
                base,selected=eligible(k)
                if extreme is not None and (base or selected):
                    prefix=[r[2] for m in range(j*5,k) for r in tape(sym,BASE+m*M)]+[r[2] for r in rr[:idx+1]] if j==s.source+1 else None
                    if preceding_decline_and_pause(five,md,sd,s.source,j,side,s.atr,observed_prices=prefix)[2]:
                        from pc_sizing import round_stop,leverage_for
                        history=[[0,*r] for r in five[j-32:j,:5]]
                        if base:
                            st=round_stop(side*(s.level-max(2*tick,.15*s.atr)),tick,side)
                            ev=indicators(history,side,s.atr)
                            lv=leverage_for(dict(ev,stop=st),p,float(inst['lever'])) if ev and side*(p-st)>0 else 0
                            counts['base_bollinger_reaction']+=1
                            if lv:events.append(('bb_long' if side==1 else 'bb_short',side,t,p,st,s.quality,0,lv,1.,1.))
                        if selected and atr[j-1]/p>=.006:
                            ev=indicators(history,side,atr[j-1])
                            if ev:events.append(('selected_short',side,t,p,round_stop(-s.level+max(2*tick,.075*s.atr),tick,-1),s.quality,0,indicator_level(ev),2.5,1.5))
                if obs.done:break
            if obs.done:break
    return dict(events=events,scalp_observations=scalp_obs,counts=counts)
if __name__=='__main__':
    make_arrays()
    def one(sym):
        p=ROOT/'day/result'/f'{sym}.json'
        try:res=examine(sym)
        except Exception as e:res={'unverified':repr(e)}
        p.write_text(json.dumps(res,default=lambda x:x.item()))
    with ThreadPoolExecutor(8) as ex:list(ex.map(one,SYMS))

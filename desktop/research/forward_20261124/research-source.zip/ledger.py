"""Continuous public research accounts. On the first registered day the opening NAV is 150."""
from outcomes import *
from decimal import Decimal
def classify(opening,closing):
    start,end=Decimal(str(opening)),Decimal(str(closing))
    if end<start*Decimal('1.05'):return 'below'
    if end>start*Decimal('1.10'):return 'above'
    return 'inside'

@lru_cache(None)
def marks(sym):
    return {int(r[0]):float(r[4]) for r in data(sym)['mark1m']}
def prior(sym,t):
    k=t//M*M
    if k==t:return float(bars1(sym)[k-M][4])
    rows=[a[2] for a in tape(sym,k) if a[0]<t]
    return rows[-1] if rows else float(bars1(sym)[k-M][4])
def carry(e,t):
    return sum(-e['side']*float(r['realizedRate'])*float(data(e['symbol'])['mark1m'][(int(r['fundingTime'])-S)//M][1]) for r in data(e['symbol'])['funding'] if e['fill']<int(r['fundingTime'])<=t)
def simulate(allrows,group,variant,lock,window=None,opening=150.):
    slip=.001 if variant=='stress' else .0005
    rows=sorted((r for r in allrows if r['event'][0] in group and (window is None or int((r['event'][2]//3600000+9)%24)//4==window)),key=lambda r:(r['event'][2],r['event'][0],-r['event'][5],r['symbol']))
    cash=peak=opening;dd=0.;book=[];live={};count=Counter();skips=Counter();ix=0;locked=False;close_nav=opening;
    def settle(t):
        nonlocal cash
        for key,p in list(live.items()):
            e=p['e']
            if e['exit']<=t and e['reason']!='carry_mark':
                cash+=p['net'];book.append(p);del live[key]
    def value(p,px,t,liquid):
        e=p['e']
        if t<=e['fill']:return 0.
        x=px*(1-e['side']*slip) if liquid else px
        return p['units']*(e['side']*(x-e['entry'])-FEE*(e['entry']+(x if liquid else 0))+carry(e,t))
    try:
        for tm in range(S,E+M,M):
            settle(tm)
            nav=cash+sum(value(p,marks(k)[tm-M],tm,True) for k,p in live.items()) if live else cash
            peak=max(peak,nav);dd=max(dd,1-nav/peak)
            if tm==E:close_nav=nav;break
            if lock and not locked and nav>=opening*1.075:
                locked=True
                for sym,p in live.items():
                    e=p['e'];rt,_,px,*_=first(sym,max(tm,e['fill'])+1)
                    if rt>=e['exit']:continue
                    x=px*(1-e['side']*slip)
                    gross=e['side']*(px-e['raw'])
                    fees=FEE*(e['entry']+x)
                    funding=carry(e,rt)
                    drag=gross-e['side']*(x-e['entry'])
                    e.update(exit=rt,raw_exit=px,exit_price=x,reason='account_lock',gross_unit=gross,
                             fee_unit=fees,slippage_unit=drag,funding_unit=funding,net_unit=gross-drag-fees+funding)
                    p['net']=p['units']*e['net_unit']
                    p['stress_same_exit_qty']=p['units']*(gross-.001*(e['raw']+px)-FEE*(e['raw']*(1+e['side']*.001)+px*(1-e['side']*.001))+funding)
                    p['stress_same_qty']=None
            while ix<len(rows) and rows[ix]['event'][2]<tm+M:
                row=rows[ix];ix+=1;rule,_,t,*_=row['event'];sym=row['symbol'];settle(t)
                if locked or sym in live or any(p['e']['rule']==rule for p in live.values()) or count[rule]>=4 or len(live)>=3:
                    skips['lock' if locked else 'daily_cap' if count[rule]>=4 else 'occupied']+=1;continue
                e=row['variants'][('base' if variant=='full_slot' else variant)]
                if 'unverified' in e:raise ValueError((sym,rule,t,e))
                if 'skip' in e:skips[e['skip']]+=1;continue
                e=e.copy();lev=e['level'];ct,lot,minq,maxq=[float(data(sym)['instrument'][0][key]) for key in ('ctVal','lotSz','minSz','maxMktSz')]
                equity=cash;used=openrisk=0.
                for k,p in live.items():
                    old=p['e']
                    if old['fill']>=t:used+=p['planned']*(1/old['level']+FEE);openrisk+=p['planned']*old['distance'];continue
                    px=prior(k,t);equity+=value(p,px,t,False);used+=p['margin']
                    # Initial stop puts a proven upper bound on current risk (trailing only tightens).
                    openrisk+=p['units']*(max(0,old['side']*(px-old['stop']))+2*(FEE+slip)*px)
                funds=max(0,equity-3);risk=.005*funds
                if .02*funds-openrisk<risk:raise ValueError('exact overlapping trailing risk required')
                slot=funds/3;planned=slot/(1/lev+FEE);caps={'slot':planned,'risk':risk/e['distance'],'free':max(0,funds-used)/(1/lev+FEE)}
                capped=rule.startswith('selected_') and variant!='full_slot'
                if variant=='full_slot' and (abs(e['q']-e['stop'])/e['q']+.002)*3>.015+1e-12:
                    skips['full_slot_risk']+=1;continue
                if capped:planned=min(caps.values())
                qty=math.floor(planned/(e['expected']*ct*lot))*lot
                notional=qty*ct*e['expected'];units=qty*ct
                if not minq<=qty<=maxq or (not capped and notional/lev<.97*slot):skips['lot_or_full_slot']+=1;continue
                if notional*e['distance']>risk+1e-12 or notional*(1/lev+FEE)>funds-used+1e-12:skips['risk_or_funds']+=1;continue
                count[rule]+=1
                stress=row['variants']['stress'];stress_net=units*stress['net_unit'] if 'net_unit' in stress else None
                live[sym]=dict(e=e,qty=qty,units=units,planned=notional,margin=units*e['entry']/lev,net=units*e['net_unit'],binding=min(caps,key=caps.get) if capped else 'slot',stress_same_qty=stress_net,
                    stress_same_exit_qty=units*(e['gross_unit']-.001*(e['raw']+e['raw_exit'])-FEE*(e['raw']*(1+e['side']*.001)+e['raw_exit']*(1-e['side']*.001))+e['funding_unit']),
                    one_r_same_qty=(units*row['variants']['one_r']['net_unit'] if 'net_unit' in row['variants'].get('one_r',{}) else None))
        assert abs(close_nav-(cash+sum(value(p,marks(k)[E-M],E,True) for k,p in live.items())))<1e-7
        ret=100*(close_nav/opening-1)
        return dict(opening=opening,closing=close_nav,pct=ret,status=classify(opening,close_nav),admissions=sum(count.values()),completed=len(book),skips=skips,locked=locked,max_drawdown_minute_pct=100*dd,book=book,carry=list(live.values()))
    except (KeyError,IndexError,ValueError) as err:return dict(opening=opening,closing=None,status='missing',reason=repr(err),partial_closed=book)
def main():
    inputs={s:json.loads((ROOT/'day/result'/f'{s}.json').read_bytes()) for s in SYMS}
    missing=[s for s in SYMS if 'events' not in inputs[s]]
    rows=[]
    for sym in SYMS:
        if sym in missing:continue
        dest=ROOT/'day/paths'/f'{sym}.json'
        if dest.exists():
            paths=json.loads(dest.read_bytes())
        else:
            paths=[dict(event=e,variants={k:{'unverified':'eligible trade path still unresolved'} for k in ('base','stress','one_r')}) for e in inputs[sym]['events']]
        rows.extend(dict(r,symbol=sym) for r in paths)
    groups={'selected_short':['selected_short'],'selected_scalp':['selected_scalp'],'selected_shared':['selected_scalp','selected_short'],
        'trend_long':['trend_long'],'trend_short':['trend_short'],'five_families':['trend_long','trend_short','bb_long','bb_short','base_scalp'],'bb_long':['bb_long'],'bb_short':['bb_short'],'bb_shared':['bb_long','bb_short'],'scalp_long':['base_scalp'],'three_shared':['bb_long','bb_short','base_scalp']}
    before=None
    if SESSION!='2026-11-23':
        if 'OKX_PREVIOUS_ACCOUNT_STATE' in os.environ:
            before=json.loads(Path(os.environ['OKX_PREVIOUS_ACCOUNT_STATE']).read_bytes())
            if before['exclusive_end_ms']!=S or before['cohort']!='nov22-frozen':raise ValueError('wrong preceding account state')
    out={}
    for name,g,window in [(name,g,None) for name,g in groups.items()]+[(f'scalp_{4*w:02d}',['base_scalp'],w) for w in range(6)]:
        out[name]={}
        for v,l in [('base',False),('stress',False)]+([('base',True),('stress',True),('one_r',False),('full_slot',False)] if name.startswith('selected') else []):
            key=v+('_lock' if l else '')
            previous=before['books'][name][key] if before else {}
            opening=150 if SESSION=='2026-11-23' else previous.get('closing')
            if missing or opening is None or previous.get('carry'):
                result=dict(status='missing',closing=None,missing_symbols=missing,reason='coverage, prior closing NAV or carry reconciliation')
            else:result=simulate(rows,g,v,l,window,opening)
            out[name][key]=result
    (ROOT/'day/accounts.json').write_text(json.dumps(out,separators=(',',':')))
    (ROOT/'day/state.json').write_text(json.dumps(dict(cohort='nov22-frozen',date=SESSION,exclusive_end_ms=E,books=out),separators=(',',':')))
if __name__=='__main__':main()

"""Provenance, history sensitivities and cutoff invariants before account reconstruction."""
from adapter import *
from hashlib import sha256
import zipfile,ast
def main():
    results={};checks=[]
    for sym in SYMS:
        merged={int(r[0]):float(r[4]) for src in (json.load(gzip.open(PREVIOUS/f'{sym}.json.gz')),data(sym)) for r in src['15m']}
        def states(key):
            r=pd.Series({t:v for t,v in sorted(merged.items()) if t>=key});f=r.ewm(span=20,adjust=False).mean();slow=r.ewm(span=50,adjust=False).mean()
            return pd.DataFrame({'slope':f-f.shift(3),'stack':f-slow,'above':r-f}).loc[S-180*M:E-1]
        short=states(BASE);long=states(min(merged))
        results[sym]=dict(sign_disagreements={c:int(sum(np.sign(short[c])!=np.sign(long[c]))) for c in short},disagreement_bars=[dict(open_ms=int(t),metric=c) for c in short for t in short.index[np.sign(short[c])!=np.sign(long[c])]],min_warm_hours=(S-min(merged))/3600000,finite_warm_hours=(S-BASE)/3600000)
    release=zipfile.ZipFile(ROOT/'repo/desktop/releases/okx_pc_r20600.zip')
    source={}
    for module,names in [('pc_timing',['indicators','round_stop']),('pc_sizing',['indicator_level','leverage_for']),('pc_monthly',['ema','strength'])]:
        tree=ast.parse(release.read(f'OKX_PC_PACKAGE/runtime/{module}.py'))
        for f in tree.body:
            if getattr(f,'name','') not in names:continue
            f.body=[n for n in f.body if not isinstance(n,(ast.ImportFrom,ast.Import))];source[f.name]=ast.dump(f)
    t=ast.parse((ROOT/'frozen/OKX_PC_PACKAGE/runtime/pc_sizing.py').read_text())
    for f in t.body:
        if getattr(f,'name','') in source:
            f.body=[n for n in f.body if not isinstance(n,(ast.ImportFrom,ast.Import))]
            checks.append({'function':f.name,'ast_equal_ignoring_local_imports':ast.dump(f)==source[f.name]})
    (ROOT/'day/input_checks.json').write_text(json.dumps(dict(history=results,sizing_source=checks),indent=1))
if __name__=='__main__':main()

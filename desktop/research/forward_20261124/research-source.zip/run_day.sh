set -eu
export PYTHONWARNINGS=ignore
until test -f day/cache/coverage.json; do sleep 4; done
python study/check.py day/cache
python study/scan.py "${OKX_KST_DAY:-2026-11-23}" day/cache frozen/OKX_PC_PACKAGE day/scan.json &
scan_pid=$!
python replay.py
python outcomes.py
python ledger.py
wait "$scan_pid"

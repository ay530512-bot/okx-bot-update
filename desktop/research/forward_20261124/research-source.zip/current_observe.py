"""Replay only the current PC release's completed-candle offer stream on confirmed bars."""
from pathlib import Path
from bisect import bisect_right
from collections import Counter
import sys,gzip,json
p=Path('latest/OKX_PC_PACKAGE')
sys.path[:0]=[str(p/'runtime'),str(p/'core'),'study']
from cache_day import SYMBOLS
from pc_candidates import signals
from pc_extra_entries import trend_side,FIVE,QUARTER
from pc_flow_watch import HISTORY5
from pc_symbol_flow import pace
from pc_wick_alert import HISTORY
def run():
    coverage=json.loads(Path('day/cache/coverage.json').read_bytes())
    out={}
    for sym in SYMBOLS:
        data=json.load(gzip.open(f'day/cache/{sym}.json.gz'))
        previous=json.load(gzip.open(f'study/20261122/cache/{sym}.json.gz'))
        for frame in ('5m','15m'):
            merged={int(r[0]):r for r in previous[frame]+data[frame]};data[frame]=[merged[t] for t in sorted(merged)]
        market={k:[(int(r[0]),*map(float,r[1:6])) for r in data[k]] for k in ('5m','15m')}
        times={k:[r[0] for r in v] for k,v in market.items()}
        def closed(k,t,step,n):
            i=bisect_right(times[k],t-step)
            return market[k][max(0,i-n):i]
        events=[];counts=Counter()
        for t in range(coverage['start_ms'],coverage['end_exclusive_ms'],FIVE):
            five=closed('5m',t,FIVE,HISTORY5);speed=pace(five,t)['pace']
            step=FIVE if speed=='fast' else QUARTER
            if t%step:continue
            rows=five if step==FIVE else closed('15m',t,QUARTER,HISTORY)
            bias=trend_side(rows) if step==QUARTER else 0
            for hit in signals(rows,step,float(data['instrument'][0]['tickSz'])):
                if step==QUARTER and hit['variant'] in ('breakout','pullback','retest','cloud') and bias!=hit['side']:
                    counts['bias_filter']+=1;continue
                events.append([t,step,hit['variant'],hit['side'],hit['price'],hit['first']])
        out[sym]=dict(counts=counts,events=events)
    Path('day/pc331_closed_offers.json').write_text(json.dumps(out,separators=(',',':')))
if __name__=='__main__':run()

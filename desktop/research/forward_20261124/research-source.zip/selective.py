"""OHLCV-reconciled subminute trade retrieval for busy minutes; candles only prune impossible triggers."""
from adapter import *
from cache_day import api
import tempfile
def read(name,fn):
    key=ROOT/'day/ticks'/(name+'.json.gz')
    if key.exists():return json.load(gzip.open(key))
    value=fn()
    with tempfile.NamedTemporaryFile(dir=key.parent,delete=False) as f:
        f.write(gzip.compress(json.dumps(value,separators=(',',':')).encode(),mtime=0))
    os.replace(f.name,key);return value
def reconcile(ohlc,vol,ref):
    if not math.isclose(vol,float(ref[5]),rel_tol=1e-7,abs_tol=1e-9):raise ValueError('native volume mismatch')
    if vol and any(not math.isclose(a,float(b),rel_tol=1e-9,abs_tol=1e-15) for a,b in zip(ohlc,ref[1:5])):raise ValueError('native OHLC mismatch')
def seconds(sym,m):
    def fetch():
        page=api('market/history-candles',instId=sym+'-USDT-SWAP',bar='1s',after=int(m+M),limit=60)
        rows=sorted([r for r in page if r[-1]=='1' and m<=int(r[0])<m+M],key=lambda r:int(r[0]))
        if [int(r[0]) for r in rows]!=list(range(m,m+M,1000)):raise ValueError('incomplete native seconds')
        x=[list(map(float,r[1:6])) for r in rows if float(r[5])];res=[x[0][0],max(r[1] for r in x),min(r[2] for r in x),x[-1][3]] if x else []
        reconcile(res,sum(r[4] for r in x),bars1(sym)[m]);return rows
    return read(f'seconds-{sym}-{m}',fetch)
def prints(sym,bar):
    sec=int(bar[0])
    def fetch():
        out={};cursor={'type':2,'after':sec+1000}
        while True:
            page=api('market/history-trades',instId=sym+'-USDT-SWAP',limit=100,**cursor)
            if not page:break
            for r in page:
                t,i=int(r['ts']),int(r['tradeId'])
                if sec<=t<sec+1000:out[i]=[t,i,float(r['px']),float(r['sz']),r['side']]
            if min(int(r['ts']) for r in page)<sec:break
            i=min(int(r['tradeId']) for r in page)
            if cursor['type']==1 and i>=cursor['after']:raise ValueError('stalled trade cursor')
            cursor={'type':1,'after':i}
        x=sorted(out.values(),key=lambda r:(r[0],r[1]))
        if any(b[1]!=a[1]+1 for a,b in zip(x,x[1:])):raise ValueError('unordered individual prints')
        v=[r[2] for r in x];reconcile([v[0],max(v),min(v),v[-1]] if v else [],sum(r[3] for r in x),bar);return x
    return read(f'secondtrades-{sym}-{sec}',fetch)

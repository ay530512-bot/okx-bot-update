import ast,zipfile,pathlib
root=pathlib.Path('repo/desktop/research')
def member(path,key):return zipfile.ZipFile(root/path).read(key).decode()
def defs(src,names):return '\n\n'.join(ast.unparse(x) for x in ast.parse(src).body if getattr(x,'name','') in names)
w='wick_touch_20261121/wick_touch.zip'
p='wick_touch_review/'
lib=pathlib.Path('lib')
(lib/'plan.json').write_text(member(w,p+'plan.json'))
(lib/'signals.py').write_text('from dataclasses import dataclass\nimport math,json,numpy as np,pandas as pd\nfrom pathlib import Path\nfrom adapter import dates,location,MINUTE\nPLAN=json.loads(Path(__file__).with_name("plan.json").read_text())\n'+defs(member('target10_20261121/replay.zip','target_research/patterns.py'),{'shift','roll','ema'})+'\n'+defs(member(w,p+'signals.py'),{'Setup','Probe','setups'}))
(lib/'scalp.py').write_text('import numpy as np,pandas as pd\n'+defs(member('wick30_scalp20_20261122/research.zip','source/scalp.py'),{'wick_flags','exit_boundary'}))
(lib/'bb_filter.py').write_bytes((root/'wick30_scalp20_20261122/bb_filter.py').read_bytes())

"""Replay direct/30-second re-test at matched risk. Keep the separately frozen A/B/C date label."""
from adapter import *
from paired import run
from pc_sizing import round_stop
def branches(sym):
    root=ROOT/'day';source=json.loads((root/'pc290'/f'{sym}.json').read_bytes());tick=float(data(sym)['instrument'][0]['tickSz'])
    events=[];meta={}
    for hit in source['events']:
        for timing in ('direct','retest'):
            if timing=='retest' and hit['retest']['status']!='reaction':continue
            e=dict(hit,**(hit['retest'] if timing=='retest' else {}))
            e.update(status='reaction',source='deployed_wick15',anchor=e['anchor_ms'],atr=e['anchor_atr'])
            events.append(e);ref=e['price'];s=e['side'];stop=round_stop(e['first']-s*max(2*tick,.15*e['atr']),tick,s)
            meta[e['ts']]=dict(timing=timing,direct_signal=hit['ts'],room=s*(e['midpoint20']-ref)>=max(.006*ref,2*abs(ref-stop)),floor=abs(ref-stop)>=.002*ref,reference=ref)
    if events:
        rows=run(sym,root/'cache',root/'ticks',events,ROOT/'frozen/OKX_PC_PACKAGE')
        for r in rows:r.update(meta[r['signal']])
    else:rows=[]
    (root/'pc290'/f'{sym}.paired.json').write_text(json.dumps(rows,separators=(',',':')))
if __name__=='__main__':
    with ThreadPoolExecutor(6) as pool:list(pool.map(branches,SYMS))

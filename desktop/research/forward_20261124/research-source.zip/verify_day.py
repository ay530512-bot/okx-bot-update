"""Cross-check the saved research paths, directional pricing, files and daily account identity."""
from pathlib import Path
import hashlib,math,json
from collections import Counter
D=Path('day')
def main():
    def read(p):return json.loads(p.read_bytes())
    c=read(D/'cache/coverage.json');S=c['start_ms'];E=c['end_exclusive_ms']
    from ledger import classify
    assert [classify(150,n) for n in (150,157.4999999,157.5,165,165.0000001)]==['below','below','inside','inside','above']
    checks=Counter();unknown=Counter()
    for p in (D/'paths').glob('*.json'):
        for event in read(p):
            for name,r in event['variants'].items():
                if 'entry' not in r:
                    unknown[r.get('unverified',r.get('skip'))]+=1;continue
                assert S<=r['t']<=r['fill']<=r['exit']<=E
                assert r['exit']<E or r['reason']=='carry_mark'
                assert math.isclose(r['side']*(r['raw_exit']-r['raw']),r['gross_unit'],abs_tol=1e-11)
                assert math.isclose(r['net_unit'],r['gross_unit']-r['fee_unit']-r['slippage_unit']+r['funding_unit'],abs_tol=1e-11)
                checks['ordered_directional_costed_paths']+=1
    for group,variants in read(D/'accounts.json').items():
        for v,r in variants.items():
            if r['status']=='missing':
                assert r.get('closing') is None;unknown['missing_account']+=1;continue
            assert r['opening']>0 and r['admissions']==len(r['book'])+len(r['carry'])
            if not r['carry']:assert math.isclose(r['closing'],r['opening']+sum(p['net'] for p in r['book']),abs_tol=1e-7)
            prev=r['opening'];assert math.isclose(r['pct'],100*(r['closing']/prev-1),abs_tol=1e-9)
            assert r['status']==classify(r['opening'],r['closing'])
            for trade in r['book']:
                assert 3<=trade['e']['level']<=5 and trade['qty']>0 and trade['margin']>0
            checks['accounts_reconciled']+=1
    for s,d in c['symbols'].items():assert hashlib.sha256((D/'cache'/f'{s}.json.gz').read_bytes()).hexdigest()==d['sha256']
    exact=read(D/'exact_markouts.json')
    diagnostics=read(D/'diagnostics/summary.json')
    assert len(exact)==3*sum(len(read(p)) for p in (D/'paths').glob('*.json'))
    assert diagnostics['opportunities']==sum(diagnostics[k]['n'] for k in ('net_win','net_loss','flat'))
    for row in exact:
        assert row['at_ms']==row['signal_ms']+row['minutes']*60000
        if 'last_trade' in row:
            assert row['last_trade'][0]<=row['at_ms']<E and row['last_trade'][2]>0
            checks['exact_horizon_trades']+=1
        else:
            unknown[row.get('status','missing_horizon_trade')]+=1
    checks['cache_digests']=len(c['symbols'])
    Path('publish/verification.json').write_text(json.dumps({'checks':checks,'unverified':unknown},indent=1))
if __name__=='__main__':main()

"""PC290 account admission from its frozen source; mark-second paths labelled as public approximations."""
import ast,zipfile
from collections import defaultdict
from types import SimpleNamespace as Row
from datetime import datetime,timedelta,timezone
from adapter import *
from ledger import prior
FEE=.0005;KST=timezone(timedelta(hours=9))
src=zipfile.ZipFile(ROOT/'repo/desktop/research/pc290/timing.zip').read('research/replay.py')
code=ast.Module([f for f in ast.parse(src).body if getattr(f,'name','') in ('simulate','qualifies','components','date')],type_ignores=[])
exec(compile(code,'pc290/research/replay.py','exec'))
gates=['room','dry','turn'];meta={};events=[]
class Accrued:
    def __getitem__(self,key):
        _,sym,t=key;d=data(sym);acc=incl=0.
        for r in d['funding']:
            ft=int(r['fundingTime']);amt=float(r['realizedRate'])*float(d['mark1m'][(ft-S)//M][1]);acc+=amt*(ft<t);incl+=amt*(ft<=t)
        return prior(sym,t),acc,incl
marks=Accrued()
def pre_flow(sym,h):
    def rr(lo,hi):return [r for m in range(lo//M*M,hi,M) for r in tape(sym,m) if lo<=r[0]<hi]
    side=h['side'];ts=h['signal'];a=h['anchor'];aligned='buy' if side==1 else 'sell'
    def amounts(rows):
        return sum(r[2]*r[3] for r in rows),sum(r[2]*r[3] for r in rows if r[4]==aligned)
    grid=ts//10000*10000
    old=rr(grid-M,grid-10000);new=rr(grid-10000,grid);x,y=amounts(old);z,w=amounts(new)
    turn=len(old)>=5 and len(new)>=5 and z>0 and x>0 and w/z>=.52 and w/z-y/x>=.15
    if turn:return False,True
    prev=rr(ts-M,ts)
    if len(prev)<5:return False,False
    x,y=amounts(prev);needed=(x-y)*15/.65
    # The completed anchor is already in the past. Its adverse amount is nonnegative,
    # so reaching the threshold early proves the same gate as summing all 15 minutes.
    adverse=0.
    for m in range(a,a+15*M,M):
        z,w=amounts(rr(m,m+M));adverse+=z-w
        if adverse>0 and adverse>=needed:return True,False
    return False,False
def main():
    gaps=[];diagnostics=[]
    for sym in SYMS:
        d=data(sym)['instrument'][0];meta[sym]=tuple(float(d[k]) for k in ('ctVal','lotSz','minSz','maxMktSz'))
        base=json.loads((ROOT/f'day/pc290/{sym}.json').read_bytes())
        for gap in base['unverified']:gaps.append(dict(symbol=sym,**gap))
        raw=json.loads((ROOT/f'day/pc290/{sym}.paired.json').read_bytes())
        for h in raw:
            if h.get('skip') in ('original_risk_admission','indicator_history','day_deadline','crossed_structural_stop'):
                diagnostics.append(dict(symbol=sym,t=h['signal'],skip=h['skip']));continue
            if 'net' not in h.get('B',{}):
                gaps.append(dict(symbol=sym,t=h['signal'],side=h['side'],timing=h.get('timing'),reason='mark/entry path or size unverified'));continue
            b=h['B'];units=b['qty_contracts']*meta[sym][0];dry=turn=False
            if h['room'] and h['timing']=='direct':
                try:dry,turn=pre_flow(sym,h)
                except Exception as ex:gaps.append(dict(symbol=sym,t=h['signal'],side=h['side'],case='room_flow',reason=repr(ex)))
            mask=int(h['room'])+2*int(dry)+4*int(turn)
            events.append(Row(symbol=sym,phase='forward',timing=h['timing'],side=h['side'],signal=h['signal'],reference=h['reference'],raw=h['fill_ref'][2],fill=h['fill_ref'][0],exit=b['exit_time'],exit_raw=b['exit_raw'],fund=b['funding']/units,lev=h['leverage'],stop=b['first_stop'],mask=mask))
    events.sort(key=lambda e:(e.signal,e.symbol,e.side))
    out={}
    for case in ('immediate','room','room_cost_floor','room_flow','retest_room'):
        for scope,side in [('long',1),('short',-1),('shared',0)]:
            bad=[r for r in gaps if (not side or r.get('side') in (side,None)) and r.get('case') in (case,None) and r.get('timing') in ('retest' if case=='retest_room' else 'direct',None)]
            if bad:out[f'{scope}_{case}']=dict(status='unverified',reasons=bad);continue
            try:
                stats,trades,days=simulate(case,side,S,E);out[f'{scope}_{case}']=dict(stats=stats,book=trades,days=days)
            except Exception as ex:out[f'{scope}_{case}']=dict(status='unverified',reason=repr(ex))
    (ROOT/'day/pc290/accounts.json').write_text(json.dumps(dict(source='PC 2.9.0 comparator First independent KST day; completed 1s mark updates with public tradable execution, modeled costs; not private fills',gaps=gaps,skips=diagnostics,accounts=out),separators=(',',':')))
if __name__=='__main__':main()

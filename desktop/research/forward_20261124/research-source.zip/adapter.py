from pathlib import Path
import sys,json,gzip,math,os
import numpy as np,pandas as pd
from functools import lru_cache
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'study'),str(ROOT/'lib'),str(ROOT/'frozen/OKX_PC_PACKAGE/runtime')]
from cache_day import SYMBOLS
from direct_ticks import minute as market_minute
from pc_sizing import indicators,indicator_level
SESSION=os.environ.get('OKX_KST_DAY','2026-11-23')
S=int(pd.Timestamp(SESSION,tz='Asia/Seoul').timestamp()*1000)
PREVIOUS=Path(os.environ['OKX_PRIOR_CACHE']) if 'OKX_PRIOR_CACHE' in os.environ else ROOT/'study/20261122/cache'
if json.loads((PREVIOUS/'coverage.json').read_bytes())['end_exclusive_ms']!=S: raise ValueError('previous cache must end at the requested KST midnight')
M=MINUTE=60000;DAY=1440*M;E=S+DAY;BASE=S-45*60*M;K=(S-BASE)//M
SYMS=SYMBOLS
def dates(section):return BASE,S,E
def location(section):return ROOT/'arrays'
@lru_cache(None)
def data(sym):return json.load(gzip.open(ROOT/'day/cache'/f'{sym}.json.gz'))
@lru_cache(None)
def bars1(sym):
    prior=json.load(gzip.open(PREVIOUS/f'{sym}.json.gz'))['1m'];return {int(r[0]):r for r in prior+data(sym)['1m']}
def arrays(sym):return [np.load(location(None)/f'{sym}-{i}.npy') for i in (1,5,15)]
def make_arrays():
    for sym in SYMS:
        d=data(sym);rates={int(x['fundingTime']):float(x['realizedRate']) for x in d['funding']}
        for name,n in [('1m',1),('5m',5),('15m',15)]:
            earlier=json.load(gzip.open(PREVIOUS/f'{sym}.json.gz'))
            a=bars1(sym) if n==1 else {int(r[0]):r for r in earlier[name]+d[name]}
            out=[[*(float(x) for x in a[t][1:6]),rates.get(t,0)] if t in a else [np.nan]*6 for t in range(BASE,E,n*M)]
            if n>1 and not np.isfinite(out).all(): raise ValueError((sym,name,'indicator warmup gap'))
            np.save(location(None)/f'{sym}-{n}.npy',out)
@lru_cache(500)
def tape(sym,t):return market_minute(sym,t,bars1(sym),ROOT/'day/ticks')

"""PC 2.9.0 original 15m detector and its predeclared 30-second non-chasing retest."""
from pathlib import Path
import json,gzip,sys
from concurrent.futures import ThreadPoolExecutor
from bisect import bisect_right
root=Path('.');pkg=root/'pc290ref/OKX_PC_PACKAGE'
sys.path[:0]=[str(pkg/'runtime'),str(pkg/'core'),'study']
from pc_wick_alert import Detector,oriented,STEP
from direct_ticks import minute,M
from cache_day import SYMBOLS
def run(sym):
    d=json.load(gzip.open(f'day/cache/{sym}.json.gz'))
    raw={int(r[0]):r for r in d['1m']};end=max(raw)+M;start=end-1440*M
    bars=[(int(r[0]),*map(float,r[1:6])) for r in d['15m']]
    tick=float(d['instrument'][0]['tickSz']);ds={s:Detector(tick) for s in (1,-1)}
    for s,det in ds.items():det.seed([oriented(b,s) for b in bars if b[0]<start])
    events=[];gaps=[]
    def trades(m):return minute(sym,m,raw,root/'day/ticks')
    def timing(hit,s):
        limit=min(hit['ts']+30000,(hit['ts']//STEP+1)*STEP-1);last=s*hit['price'];tested=False
        for m in range(hit['ts']//M*M,limit+1,M):
            for ts,tid,p,_,_ in trades(m):
                if tid<=hit['trade_id'] or ts>limit:continue
                v=s*p
                if v<=s*hit['first']+tick*1e-6:return {'status':'first_broken'}
                if abs(v-last)<tick*1e-6:continue
                if v<=s*hit['second']+tick*1e-6:tested=True
                if tested and v>=last+tick*(1-1e-6):
                    if v>s*hit['price']+tick*1e-6:return {'status':'chase'}
                    return dict(status='reaction',ts=ts,trade_id=tid,price=p)
                last=v
        return {'status':'window_elapsed'}
    for i,b in enumerate(bars):
        if b[0]<start:continue
        for side,det in ds.items():
            r=oriented(b,side);a=det.anchor;t=b[0]
            if a and r[3]<=a.zone+det.eps and (a.away or r[2]>=a.depart-det.eps):
                try:
                    for m in range(t,t+STEP,M):
                        if det.anchor is None:break
                        for ts,tid,p,_,_ in trades(m):
                            h=det.trade(ts,tid,side*p,covered_from_open=True)
                            if h:
                                h.update(price=p,first=side*h['first'],second=side*h['second'],side=side)
                                h['midpoint20']=sum(x[4] for x in bars[i-20:i])/20
                                h['retest']=timing(h,side)
                                events.append(h);break
                except Exception as exc:
                    gaps.append(dict(anchor=a.stamp,window=t,side=side,reason=repr(exc)));det.anchor=None
            det.closed(r)
    return dict(events=events,unverified=gaps)
def main():
    def work(s):
        p=root/'day/pc290'/f'{s}.json'
        out=run(s);p.write_text(json.dumps(out,separators=(',',':')))
    with ThreadPoolExecutor(5) as pool:list(pool.map(work,SYMBOLS))
if __name__=='__main__':main()

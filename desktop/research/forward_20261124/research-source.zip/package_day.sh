set -eu
while [ ! -s day/exact_markouts.json ] || [ ! -s day/accounts.json ] || [ ! -s day/diagnostics/summary.json ] || [ ! -s day/pc290/accounts.json ] || [ ! -s day/timing/matched_qty.json ]; do sleep 4; done
python ledger.py
python verify_day.py
python close_run.py
python pack_run.py execution
python pack_run.py evidence
python - <<'PY'
from pathlib import Path
import zipfile
sources=sorted([*Path('.').glob('*.py'),Path('run_day.sh'),Path('package_day.sh')])
with zipfile.ZipFile('publish/research-source.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sources:
        zi=zipfile.ZipInfo(str(p),(2026,11,24,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(zi,p.read_bytes())
PY
python publish/restore.py publish verify_restore
python - <<'PY'
import json,hashlib,pathlib
for root in ('day/cache','day/ticks','day/paths','day/result','day/diagnostics','day/pc290','day/timing','day/development_ticks'):
 for p in pathlib.Path(root).glob('*'):
  assert p.read_bytes()==(pathlib.Path('verify_restore')/p).read_bytes(),p
print('all cached evidence round-tripped')
PY

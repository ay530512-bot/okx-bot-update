"""Index the verified public day, marking held-out, descriptive and private ledgers separately."""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone,timedelta
import hashlib,json,subprocess
R=Path('day');P=Path('publish')
def read(p):return json.loads(p.read_bytes())
def pct(a,b):return 100*(b/a-1)
def main():
    cov=read(R/'cache/coverage.json');books=read(R/'accounts.json')
    summary={}
    for name,variants in books.items():
        snap={}
        for key,r in variants.items():
            if r.get('closing') is None:snap[key]=r;continue
            ledger=r['book'];pnls=[p['net'] for p in ledger];g=defaultdict(float);cost=Counter()
            for p in ledger:
                e=p['e'];g[e['symbol']]+=p['net']
                for x in ('gross','fee','slippage','funding'):cost[x]+=p['units']*e[x+'_unit']
                assert abs(e['net_unit']*p['units']-p['net'])<1e-7
            wins=[v for v in pnls if v>0];loss=[v for v in pnls if v<0]
            snap[key]=dict(opening=r['opening'],closing=r['closing'],net_pct=r['pct'],status=r['status'],opened=r['admissions'],closed=len(ledger),carry_count=len(r.get('carry',[])),fees_and_pnl=cost,
                n_win=len(wins),n_loss=len(loss),win_frac=len(wins)/len(pnls) if pnls else None,mean_win=sum(wins)/len(wins) if wins else None,mean_loss=sum(loss)/len(loss) if loss else None,
                mean_pnl=sum(pnls)/len(pnls) if pnls else None,realized_net_without_largest=sum(pnls)-max([0,*pnls]),realized_net_without_best_symbol=sum(pnls)-max([0,*g.values()]),
                mdd_completed_minute_mark_pct=r['max_drawdown_minute_pct'],same_qty_same_exit_stress_net=sum(p['stress_same_exit_qty'] for p in ledger),
                same_qty_replayed_stress_net=sum(p['stress_same_qty'] for p in ledger) if all(p['stress_same_qty'] is not None for p in ledger) else None,admission_counts=r['skips'])
        summary[name]=snap
    scan=read(R/'scan.json');alt=read(R/'range_scan.json');regimes=Counter();offers=Counter()
    for v in scan.values():regimes.update(v['counts'])
    for v in read(R/'pc331_closed_offers.json').values():offers.update(e[2] for e in v['events'])
    historic=read(R/'pc290/accounts.json');dev=read(P/'development_check.json')
    fixed=read(Path('repo/desktop/pc_latest.json'));base=Path('repo/desktop/releases')/f"okx_pc_r{fixed['revision']}.zip"
    assert fixed['sha256']==hashlib.sha256(base.read_bytes()).hexdigest()
    info=dict(session_kst=cov['day_kst'],start_ms=cov['start_ms'],end_exclusive_ms=cov['end_exclusive_ms'],registered_session_index=1,record_utc=datetime.now(timezone.utc).isoformat(),
        data_kind='OKX public, simulated same-venue swap execution. No private fills or PC 2.15 shadow database.',
        price_sources=['https://www.okx.com/api/v5/market/history-trades','https://www.okx.com/api/v5/market/history-candles','https://www.okx.com/api/v5/market/history-mark-price-candles','https://www.okx.com/api/v5/public/funding-rate-history','https://www.okx.com/api/v5/public/instruments'],
        market_coverage=dict(symbols=len(cov['symbols']),bars_by_instrument={'1m':1440,'5m':288,'15m':96,'1H':24,'mark1m':1440},native_confirmed=True,funding_coverage='Settled rates checked back to KST open, entries at timestamps of actual exposure only.',execution='Fetched necessary trades ordered by timestamp and trade ID. Checked candle OHLCV; whole-minute safe skips only for unambiguous paths. The second UTC+8 daily archive for the session was unpublished at collection.',metadata_asof='Query time after the KST close. No private order queue or historical L2 execution guarantee.'),
        research_registration_commit='07b015f77e21d8c6564d03e03d015503e54cdabe',input_history_check='45-hour warm-up versus all 89 cached hours, 2 EMA-stack sign differences on pre-08:00 completed contexts, outside the fixed EMA entry windows. Slope and above-EMA comparisons agreed. See input_checks.json.',release_registry_commit='5db7882cbb75ab5560732026e8470cfd990b1831',current_release=fixed,current_release_published_kst='2026-11-23T23:43:45+09:00',closed_candle_comparator=dict(offers_by_rule=offers,method='Within this exact package replayed closed-candle detector at the appropriate product pace, at ideal coverage. Includes offers before registry publication as descriptive only. Intrabar/private order admission and actual historical returns not observed.'),
        registered_controls={'11_22_originals':summary,'pc290':historic['accounts']},matched_counterfactuals='evidence.zip day/diagnostics, day/timing, and day/pc290. Individual event outcomes are not a portfolio.',
        historical_60_event_diagnostic='Separate previously inspected 22-instrument mock sample, 8 winners and 52 losers. Do not pool with current events.',
        historical_13_rule_timetable='retired; no observation, nomination, promotion, deployment or restoration',
        pace_scan=dict(registered_true_range=regimes,range_only_fast_periods=sum(r['counts'].get('fast',0) for r in alt.values()),independent_windows=sum(len(v['native_fast_tick_windows']) for v in scan.values()),range_only_windows=sum(len(v['native_fast_tick_windows']) for v in alt.values()),scope='11/23 is an observation under the 11/23 registration, not an independent performance date. Window counts are not fills.'),
        first_whole_eligible={'nov22_frozen':'2026-11-23','matched_ABC_and_native_speed':'2026-11-24','cadence_and_direct_high_low_speed':'2026-11-25'},
        decision='Research only. 1 of 60 prospective days for November 22 protocols; no qualified change. Incomplete source-day outcomes are not zero or qualified.',next='Continue each matched book from the preceding state. Evaluate November 24 only after the KST midnight close. Use the preregistered matched-speed code on that date; first eligible November 25 for next_protocol. Keep historical/retired routes and live alert/position management separate.',
        development_gate=dev['counts'])
    info['daily_gate_audit']={
        'registered_primary_date':'2026-11-23',
        'inside':[k for k,v in summary.items() if v['base'].get('status')=='inside'],
        'below':[k for k,v in summary.items() if v['base'].get('status')=='below'],
        'above':[k for k,v in summary.items() if v['base'].get('status')=='above'],
        'missing':[k for k,v in summary.items() if v['base'].get('status')=='missing'],
        'meaning':'A verified miss on any date rules out satisfying every date in this specific fixed 60-day cohort. Keep accumulating the predeclared cohort without restarting its balance. Evaluate separately registered changes only from their own prospective start.'}
    (P/'run.json').write_text(json.dumps(info,indent=1,ensure_ascii=False,allow_nan=False))
if __name__=='__main__':main()

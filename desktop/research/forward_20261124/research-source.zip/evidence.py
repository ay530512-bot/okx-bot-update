"""Same-event counterfactuals and causal indicator snapshots, never used to select these fills."""
from outcomes import *
from scalp import wick_flags,exit_boundary
from statistics import median
from bisect import bisect_right
from pc_sizing import round_stop,strength
def context(sym,t,s):
    out={};d=data(sym)
    for frame,step in [('1m',M),('5m',5*M),('15m',15*M),('1H',60*M)]:
        bars=[r for r in d[frame] if int(r[0])+step<=t][-160:]
        if len(bars)<30:out[frame]={'history':len(bars)};continue
        a=np.array([list(map(float,r[1:6])) for r in bars])
        o,h,l,c,v=a.T;r=h[-1]-l[-1];atr=np.mean(np.maximum(h[-14:],c[-15:-1])-np.minimum(l[-14:],c[-15:-1]))
        avg=pd.Series(c).ewm(span=20,adjust=False).mean().to_numpy()
        rv=v[-1]/np.mean(v[-21:-1]) if np.mean(v[-21:-1]) else None
        out[frame]=dict(history=len(bars),last_closed_ms=int(bars[-1][0])+step,aligned_body_pct=100*s*(c[-1]/o[-1]-1),lower_wick_frac=(min(o[-1],c[-1])-l[-1])/r if r else None,
          upper_wick_frac=(h[-1]-max(o[-1],c[-1]))/r if r else None,close_location=(c[-1]-l[-1])/r if r else None,relative_volume=rv,atr_pct=100*atr/c[-1],ema20=avg[-1],
          aligned_slope=s*(avg[-1]-avg[-4])/atr if atr else None,rsi14=strength(list(c)),previous_low=min(l[-21:-1]),previous_high=max(h[-21:-1]),setting_low=l[-1],setting_high=h[-1])
    return out
def one(sym):
    inp=json.loads((ROOT/'day/paths'/f'{sym}.json').read_bytes());out=[]
    for row in inp:
        e=row['event'];b=row['variants']['base']
        if 'entry' not in b:continue
        rule,s,t,q,*_=e;tick=float(data(sym)['instrument'][0]['tickSz'])
        other=list(e);other[1]=-s
        risk=s*(b['entry']-b['stop']);entry=b['raw']*(1-s*.0005)
        other[4]=round_stop(entry+s*risk,tick,s)  # Inward tick rounding caps the mirrored price risk.
        band=False
        if 'scalp' in rule:
            five=arrays(sym)[1].copy()
            five[:,[0,1,2,3]]=-five[:,[0,2,1,3]]
            _,exit_flag,_=wick_flags(five,tick);n,band=exit_boundary(exit_flag,(t-BASE)//(5*M)-1);other[6]=t+n*5*M
        try:
            reverse=path(sym,other,.0005,band)
            if 'fill' in reverse:assert reverse['fill']==b['fill'] and reverse['entry_id']==b['entry_id']
        except Exception as exc:reverse={'unverified':repr(exc)}
        clock=t//10000*10000
        try:
            rr=[r for m in range((clock-M)//M*M,clock,M) for r in tape(sym,m) if clock-M<=r[0]<clock]
            old=[r for r in rr if r[0]<clock-10000];now=[r for r in rr if r[0]>=clock-10000]
            def share(rs):
                v=sum(r[2]*r[3] for r in rs);return sum(r[2]*r[3] for r in rs if (r[4]=='buy')==(s==1))/v if v else None
            a=share(old);z=share(now);minute=t//M*M
            votes=[s*(float(bars1(x)[minute-M][4])-float(bars1(x)[minute-16*M][4]))>0 for x in SYMS if x!=sym]
            breadth=np.mean(votes)
            flow=dict(n50=len(old),n10=len(now),share50=a,share10=z,breadth=breadth,
              aligned=bool(z is not None and z>=.60 and breadth>=.6),absorption=bool(len(old)>=5 and len(now)>=5 and a<=.4 and z>=.6 and abs(old[-1][2]-old[0][2])<=risk/4 and s*(now[-1][2]-now[0][2])>=tick*(1-1e-7)))
        except Exception as exc:flow={'unverified':repr(exc)}
        out.append(dict(rule=rule,side=s,signal=t,symbol=sym,original=b,opposite=reverse,no_entry_unit=0,
            reverse_rounding_distortion=abs((-s)*(entry-other[4])-risk),pre=context(sym,t,s),pressure=flow))
    (ROOT/'day/diagnostics'/f'{sym}.json').write_text(json.dumps(out))
def summaries():
    rows=[r for s in SYMS for r in json.loads((ROOT/'day/diagnostics'/f'{s}.json').read_bytes())];summary={}
    for group,bucket in [('net_win',[r for r in rows if r['original']['net_unit']>0]),('net_loss',[r for r in rows if r['original']['net_unit']<0]),('flat',[r for r in rows if r['original']['net_unit']==0])]:
        info={}
        for frame in ('1m','5m','15m','1H'):
            info[frame]={}
            for key in ('aligned_body_pct','relative_volume','atr_pct','aligned_slope','rsi14','lower_wick_frac','upper_wick_frac','close_location'):
                vals=[r['pre'][frame].get(key) for r in bucket];vals=[x for x in vals if x is not None]
                info[frame][key]={'n':len(vals),'q25_50_75':list(np.quantile(vals,[.25,.5,.75])) if vals else []}
        summary[group]=dict(n=len(bucket),distribution=info)
        if not bucket:continue
        import matplotlib;matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        e=sorted(bucket,key=lambda r:(r['signal'],r['symbol'],r['rule']))[0];b=e['original'];t=e['signal']
        start=t-60*M;end=min(E,max(t+30*M,b['exit']+5*M))
        rr=[v for k,v in sorted(bars1(e['symbol']).items()) if start<=k<end]
        fig,ax=plt.subplots(figsize=(8,3.7));ax.plot([(int(r[0])+M-t)/M for r in rr],[float(r[4]) for r in rr],lw=1)
        ax.scatter([(b['fill']-t)/M,(b['exit']-t)/M],[b['entry'],b['exit_price']],c=['#167a44','#a73030'],s=32)
        ax.axhline(b['stop'],ls=':',lw=.8,color='gray');kst=pd.Timestamp(t,unit='ms',tz='UTC').tz_convert('Asia/Seoul')
        ax.set_title(f"{e['symbol']} {e['rule']} | {kst:%Y-%m-%d %H:%M:%S} KST");ax.set_xlabel('Minutes from signal');ax.set_ylabel('USDT');fig.tight_layout();fig.savefig(ROOT/'day/diagnostics'/f'{group}.png');plt.close(fig)
    matched=[r for r in rows if 'net_unit' in r['opposite']]
    summary.update(opportunities=len(rows),matched_directions=len(matched),both_loss=sum(max(r['original']['net_unit'],r['opposite']['net_unit'])<0 for r in matched),original_gross_positive_net_negative=sum(r['original']['gross_unit']>0>r['original']['net_unit'] for r in rows),unit='One base-asset unit in both directions. Use originating account lot count and contract value to obtain USDT. Overlapping research rules may represent the same signal. No causal inference.')
    (ROOT/'day/diagnostics/summary.json').write_text(json.dumps(summary,indent=1))
if __name__=='__main__':
    (ROOT/'day/diagnostics').mkdir(exist_ok=True)
    with ThreadPoolExecutor(6) as pool:list(pool.map(one,SYMS))
    summaries()

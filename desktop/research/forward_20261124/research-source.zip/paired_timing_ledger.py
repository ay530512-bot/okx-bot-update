"""Normalize later confirmations to the same contracts only in retrospective matched comparisons."""
from collections import defaultdict
from pathlib import Path
import json
def read(p):return json.loads(p.read_bytes())
def main():
    paths=Path('day/pc290');result=[]
    for p in sorted(paths.glob('*.paired.json')):
        sym=p.stem.split('.')[0];group=defaultdict(dict)
        for e in read(p):
            group[(e['direct_signal'],e['side'])][e['timing']]=e
        info=read(Path(f'day/timing/{sym}.json'))
        for e in info['paired']:
            direct,key=e['association'];group[(direct,e['side'])][key]=e
        for (t,side),alternates in group.items():
            direct=alternates['direct'];row=dict(symbol=sym,side=side,direct_signal=t,skip_net=0,paired={})
            for key,other in alternates.items():
                if key=='direct':continue
                left=direct.get('B',{});right=other.get('B',{})
                if 'net' not in left or 'net' not in right:row['paired'][key]={'status':'unverified_or_not_admissible'};continue
                q=min(left['qty_contracts'],right['qty_contracts'])
                def sized(r):return {k:r[k]*q/r['qty_contracts'] for k in ('gross','fee','slippage','funding','net','stressed_net_same_quantity')}
                a=sized(left);b=sized(right);row['paired'][key]=dict(contracts=q,direct=a,alternative=b,net_change=b['net']-a['net'])
            result.append(row)
    Path('day/timing/matched_qty.json').write_text(json.dumps(dict(scope='Matched event analysis only. Common conservative size is for comparing execution on a pair; live admissions cannot use future confirmation. Missing arms are not trades.',opportunities=result),separators=(',',':')))
if __name__=='__main__':main()

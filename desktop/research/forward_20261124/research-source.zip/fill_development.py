"""Resolve development gate coverage from closed public minutes in the existing development date."""
import sys,json,gzip,lzma,zipfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from collections import Counter
sys.path.insert(0,'study')
from direct_ticks import minute
from cadence import evaluate
from intrabar_range import pace
from bisect import bisect_right
def main():
    root=Path('study/20261122');dst=Path('day/development_ticks');dst.mkdir(exist_ok=True)
    with zipfile.ZipFile(root/'session_20261122.zip') as z:all_e=json.loads(z.read('result/event_paths.json'))
    def process(sym):
        pre=json.loads(lzma.decompress((root/'tape'/f'{sym}.json.xz').read_bytes())); data=json.load(gzip.open(root/'cache'/f'{sym}.json.gz'));c={int(r[0]):r for r in data['1m']};times=[int(r[0]) for r in data['5m']]
        rows=[]
        for e in (r for r in all_e if r['sym']==sym):
            ts=e['signal'];end=ts//5000*5000;clock=ts//300000*300000;at=bisect_right(times,clock-300000);speed=pace(data['5m'][max(0,at-40):at],clock)
            if (e['source']=='native_fast_direct' and speed!='fast') or (e['source']=='deployed_wick15' and speed!='normal'):
                dec={'status':'other_speed'}
            else:
                dec=evaluate(ts,e['side'],[],lambda *_:False)
                if dec['status']=='missing_input':
                    try:
                        ticks=[]
                        for m in range((end-90000)//60000*60000,end,60000):
                            k=f'{sym}-{m}.json.gz'
                            ticks.extend(pre[k] if k in pre else minute(sym,m,c,dst))
                        dec=evaluate(ts,e['side'],ticks,lambda *_:True)
                    except Exception as ex:dec['reason']=repr(ex)
            rows.append(dict(symbol=sym,signal=ts,side=e['side'],source=e['source'],reference_true_range_speed=e['native_pace'],speed=speed,decision=dec,existing_exit_net=e.get('B',{}).get('net')))
        return rows
    with ThreadPoolExecutor(5) as pool:rows=[r for a in pool.map(process,sorted({e['sym'] for e in all_e})) for r in a]
    counts=Counter(r['decision']['status'] for r in rows)
    Path('publish/development_check.json').write_text(json.dumps(dict(date='2026-11-22',role='development, matched event checks only; never independent',counts=counts,
       paired_verified_B_net_by_gate={g:dict(n=len(v),net_sum=sum(v)) for g in counts for v in [[r['existing_exit_net'] for r in rows if r['decision']['status']==g and r['existing_exit_net'] is not None]]},rows=rows),separators=(',',':')))
if __name__=='__main__':main()

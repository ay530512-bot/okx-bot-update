"""Small path regressions independent of the historical sample."""
import unittest
import numpy as np
from paths import lib
from evaluate import CONTRACTS

class Execution(unittest.TestCase):
    def setUp(self):
        self.candles=np.tile(np.array([100.,100.2,99.8,100.,1.,0.]),(160,1));self.dll=lib()
    def market(self,side,stop,*,retest=0):
        row=np.array([[0.,100.,1.,stop]],dtype='f8');out=np.empty((1,7));self.dll.paths(self.candles,len(self.candles),row,1,side,5,retest,.01,0.,0.,0,out);return out[0]
    def passive(self,side,quote,stop):
        row=np.array([[0.,quote,stop]],dtype='f8');out=np.empty((1,7));self.dll.resting_paths(self.candles,len(self.candles),row,1,side,5,.01,0.,0.,0,out);return out[0]
    def test_stop_first_both_directions(self):
        self.candles[0,1:3]=103.,97.
        for side,sl in ((1,99),(-1,101)):
            x=self.market(side,sl);self.assertEqual(x[3],1);self.assertAlmostEqual(x[4],-.01)
    def test_trailing_then_funding(self):
        self.candles[2]=[100.,103.,99.8,102.6,10.,.001];self.candles[3]=[102.5,102.8,101.8,102.,10.,0.]
        x=self.market(1,99);self.assertEqual(x[3],4);self.assertAlmostEqual(x[4],.019)
    def test_confirmed_retest_uses_next_open(self):
        self.candles[0]=[100.,100.1,99.6,99.7,1.,0.];self.candles[1]=[99.7,100.,99.5,99.8,1.,0.];self.candles[2,0]=99.85
        self.assertEqual(self.market(1,98,retest=1)[0],2)
        self.candles[0,2]=97.5;self.assertTrue(np.isnan(self.market(1,98,retest=1)[0]))
    def test_no_fill_on_touch_or_prior_high(self):
        self.candles[1,2]=99.;self.assertTrue(np.isnan(self.passive(1,99,98)[0]))
        self.candles[1]=[100.,105.,98.95,99.1,5.,0.];x=self.passive(1,99,98);self.assertEqual(x[0],1);self.assertGreater(x[3],2)
    def test_no_passive_when_marketable_or_filled_and_stopped(self):
        self.candles[1]=[98.9,101,96,99,1.,0.];self.assertTrue(np.isnan(self.passive(1,99,98)[0]))
        self.candles[1,0]=100.;x=self.passive(1,99,98);self.assertEqual(x[3],2);self.assertAlmostEqual(x[4],-1/99)
    def test_single_actual_balance_and_no_overlap(self):
        ins=np.array([[1,.01,.01,10000]],dtype='f8');rows=np.array([[100,100,120,0,100,.01,.02],[110,110,130,0,100,.01,.1],[130,130,145,0,100,.01,-.01]],dtype='f8')
        out=np.empty(8);self.dll.single(rows,3,ins,0,1440,0,20,540,4,45,10,0,.0005,.0005,out);self.assertEqual(out[0],2);self.assertAlmostEqual(out[1],150+.61*100*.02-.61*100*.01)

if __name__=='__main__':unittest.main()

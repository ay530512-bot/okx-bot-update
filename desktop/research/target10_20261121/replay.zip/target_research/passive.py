"""Select a resting-order symbol before observing any subsequent price or fill."""
import argparse,warnings
import numpy as np
import pandas as pd
from inputs import COINS,MINUTE,dates,location
from patterns import shift,roll,sym_features,cross_inputs
from paths import meta
NAMES=('limit_range','limit_trend','limit_wick','limit_dislocation','limit_flush')

def run(section,n):
    folder=location(section);base,start,end=dates(section);instruments=meta();(r3,_,_),(r12,q12,_),_=cross_inputs(folder,n);size=len(r3);ts=base+(np.arange(size)+1)*n*MINUTE;clock=(ts-base)//MINUTE
    labels=[(name,side,level) for name in NAMES for side in (1,-1) for level in (0,1)];best={k:(np.full(size,-np.inf),np.full(size,-1,dtype=np.int16),np.zeros(size),np.zeros(size),np.zeros(size),np.zeros(size)) for k in labels}
    for sym in sorted(COINS):
        ix=COINS.index(sym);tick=float(instruments[sym]['tickSz']);ct=float(instruments[sym]['ctVal']);v=np.load(folder/f'{sym}-{n}.npy',mmap_mode='r');o,h,l,c,vol,rate,age,p,atr,rv,e12,e36,vwap,sq=sym_features(v)
        eff=np.abs(c-shift(c,12))/roll(abs(c-p),12,'sum');turn=roll(vol*c*ct,60//n,'sum');base_ok=(ts>=start)&(ts<end)&(roll(np.isfinite(c),96,'sum')==96)&(h>l)&(atr/c>=.0024)&(atr/c<.04)&(turn>=90000)&(tick/c<=.0005)&(vol>0)
        for side in (1,-1):
            # In transformed prices the trade is always long. Convert back only at the order boundary.
            px=side*c;first=side*o;floor=l if side==1 else -h;top=h if side==1 else -l
            low6=roll(floor,6,'min');low12=roll(floor,12,'min');prev_low=shift(roll(floor,12,'min'),3)
            trail_wick=(np.minimum(px,first)-floor)/(h-l);rank=q12[:,ix] if side==1 else 1-q12[:,ix];rel=side*r12[:,ix]*c/atr
            trend=(side*(e12-e36)>0)&(side*(e12-shift(e12,4))>0);dist=side*(c-e12)/atr
            held=(floor>prev_low)&(floor-prev_low<=1.4*atr)&(floor<=shift(roll(floor,3,'min')))&(px<first)&(trail_wick>=.23)&(shift(roll(top,8,'max'))-floor>1.3*atr)
            wick_pulse=roll(np.minimum(px,first)-floor,12,'max')/atr
            for name,fire,score,anchor,struct in [
                ('limit_range',(eff<.42)&(abs(dist)<1.8),np.clip((roll(top,12,'max')-low12)/atr,0,6)-eff,low6+.15*atr,low12),
                ('limit_trend',trend&(dist>-.5)&(dist<1.8),side*(e12-e36)/atr+.2*np.minimum(rv,4),np.maximum(low6,side*e12-.45*atr),low6),
                ('limit_wick',held&(rv>=.8),trail_wick+.25*np.minimum(rv,6),floor+.15*atr,prev_low),
                ('limit_dislocation',(rank<=.15)&(rel<-1.3)&(rv>=1.2),-rel+trail_wick,px-.85*atr,floor),
                ('limit_flush',(wick_pulse>=.65)&(eff<.65)&(rv>=.6),np.minimum(wick_pulse,5)+.22*np.minimum(rv,5),px-1.55*atr,low6)]:
                for depth in (0,1):
                    quote=np.minimum(px-.50*atr,anchor)-depth*.65*atr
                    stop=np.minimum(quote-.95*atr,struct-.40*atr)
                    limit_price=side*quote;stop_price=side*stop
                    limit_price=(np.floor(limit_price/tick+1e-10) if side==1 else np.ceil(limit_price/tick-1e-10))*tick
                    stop_price=(np.floor(stop_price/tick+1e-10) if side==1 else np.ceil(stop_price/tick-1e-10))*tick
                    gap=side*(c-limit_price);risk=side*(limit_price-stop_price)
                    ok=base_ok&fire&(gap>2*tick)&(gap<4.5*atr)&(risk>2*tick)&(risk<=4.5*atr)&(risk/limit_price<=.06)&np.isfinite(score)
                    ranking,symbol,ref,atr_out,q,st=best[(name,side,depth)];hits=np.flatnonzero(ok&(score>ranking));ranking[hits]=score[hits];symbol[hits]=ix;ref[hits]=c[hits];atr_out[hits]=atr[hits];q[hits]=limit_price[hits];st[hits]=stop_price[hits]
    result=[]
    for (name,side,depth),(rank,symbol,ref,atr,q,st) in best.items():
        hits=np.flatnonzero(symbol>=0);result.append(pd.DataFrame(dict(clock=clock[hits].astype('int32'),rule=name+('_long' if side==1 else '_short'),side=np.int8(side),level=np.int8(depth),bar=np.int8(n),sym=symbol[hits],quality=rank[hits],ref=ref[hits],atr=atr[hits],quote=q[hits],stop=st[hits])))
    df=pd.concat(result,ignore_index=True);df.to_pickle(folder/f'passive-{n}.pkl');print(section,n,'resting proposals',len(df),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section');ap.add_argument('bar',type=int);args=ap.parse_args()
    with np.errstate(divide='ignore',invalid='ignore'),warnings.catch_warnings():
        warnings.simplefilter('ignore',category=RuntimeWarning);run(args.section,args.bar)

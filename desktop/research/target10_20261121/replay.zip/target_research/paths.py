"""Compile and use a deterministic one-minute execution model."""
import argparse,ctypes,json,subprocess
from pathlib import Path
import numpy as np
import pandas as pd
from inputs import COINS,MINUTE,dates,location
D=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS'); I=ctypes.c_int; F=ctypes.c_double
SOURCE=Path(__file__).with_name('engine.cpp');SO=Path('target_cache/engine.so').resolve()

def lib():
    dll=ctypes.CDLL(str(SO));dll.paths.argtypes=[D,I,D,I,I,I,I,F,F,F,I,D];dll.paths.restype=None
    dll.resting_paths.argtypes=[D,I,D,I,I,I,F,F,F,I,D];dll.resting_paths.restype=None
    dll.single.argtypes=[D,I,D,I,I,I,I,I,I,I,I,I,F,F,D];dll.single.restype=None
    return dll

def meta():
    source=json.loads(Path('ins.json').read_text())['data']; selected={i['instId'].split('-')[0]:i for i in source if i['instId'].endswith('-USDT-SWAP')};return {s:selected[s] for s in COINS}

def simulations(section,stress=False,passive=False):
    folder=location(section);base,*_=dates(section);epoch=base//MINUTE
    dll=lib();instruments=meta();result=[]
    for n in (5,15):
        label='passive' if passive else 'signals';df=pd.read_pickle(folder/f'{label}-{n}.pkl')
        for (s,side),g in df.groupby(['sym','side'],sort=False):
            coin=COINS[s];bars=np.ascontiguousarray(np.load(folder/(coin+'-1.npy'),mmap_mode='r'));tick=float(instruments[coin]['tickSz']);specs=np.ascontiguousarray(g[['clock','quote','stop'] if passive else ['clock','ref','atr','stop']].to_numpy(),dtype='f8')
            for wait in ((2,) if passive else (0,1)):
                out=np.empty((len(g),7))
                if passive:dll.resting_paths(bars,len(bars),specs,len(g),int(side),n,tick,.001 if stress else .0005,.0005,int(stress),out)
                else:dll.paths(bars,len(bars),specs,len(g),int(side),n,wait,tick,.001 if stress else .0005,.0005,int(stress),out)
                for col,hold in [(3,45),(5,120)]:
                    valid=np.isfinite(out[:,col+1]);x=g.loc[valid,['rule','bar','level','sym','side','quality']].copy();x['wait']=np.int8(wait);x['hold']=np.int16(hold);x['signal']=(specs[valid,0]+epoch).astype('int32');x['entry']=(out[valid,0]+epoch).astype('int32');x['exit']=(out[valid,col]+epoch).astype('int32');x['price']=out[valid,1];x['dist']=out[valid,2];x['net']=out[valid,col+1];result.append(x)
    x=pd.concat(result,ignore_index=True);x['rule']=x['rule'].astype('category');x.sort_values(['entry','signal','quality','sym'],ascending=[True,True,False,True],inplace=True,ignore_index=True);root='limits' if passive else 'hypotheses';x.to_pickle(folder/(root+('-stress' if stress else '')+'.pkl'));print(section,'stress',stress,'priced paths',len(x),flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section');ap.add_argument('--stress',action='store_true');ap.add_argument('--passive',action='store_true');a=ap.parse_args()
    if a.section=='compile':subprocess.run(['g++','-std=c++17','-O3','-fPIC','-shared',str(SOURCE),'-o',str(SO)],check=True)
    else:simulations(a.section,a.stress,a.passive)

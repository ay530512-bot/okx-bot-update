"""Rebuild the actual PC 2.5.0 signals before grid evaluation (no private API)."""
from pathlib import Path
import sys
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()/'timing_research'))
import replay
if __name__=='__main__':
    replay.CACHE=Path('target_cache/legacy');replay.CACHE.mkdir(parents=True,exist_ok=True)
    replay.run(SimpleNamespace(start='2026-03-03',end='2026-08-30',fee=.0005,slip=.0005,
                               close_only=False,workers=4,out='target_cache/old_development.pkl'))

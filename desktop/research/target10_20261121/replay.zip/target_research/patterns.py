"""Evaluate completed-bar directional hypotheses; rank using only information known at the close."""
import argparse
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from inputs import COINS,MINUTE,HOUR,dates,location

NAMES=('channel_break','liquidity_sweep','ema_pullback','vwap_reentry','relative_rotation','shock_reclaim','volatility_squeeze','settled_funding','relative_extreme','session_range')

def shift(v,n=1):return pd.Series(v).shift(n).to_numpy()
def roll(v,n,method):return getattr(pd.Series(v).rolling(n,min_periods=n),method)().to_numpy()
def ema(v,n):return pd.Series(v).ewm(span=n,adjust=False,min_periods=n).mean().to_numpy()
def sym_features(v):
    o,h,l,c,vol,rate,age=v.T;p=shift(c)
    tr=np.maximum.reduce((h-l,abs(h-p),abs(l-p)));atr=shift(roll(tr,14,'mean'));rv=vol/shift(roll(vol,20,'mean'));e12=ema(c,12);e36=ema(c,36)
    vw=roll((c+h+l)/3*vol,32,'sum')/roll(vol,32,'sum');bb=roll(c,20,'std')/roll(c,20,'mean');squeeze=shift(bb)<.85*shift(roll(bb,60,'median'))
    return o,h,l,c,vol,rate,age,p,atr,rv,e12,e36,vw,squeeze

def cross_inputs(folder,n):
    close=np.column_stack([np.load(folder/f'{s}-{n}.npy',mmap_mode='r')[:,3] for s in COINS]);frame=pd.DataFrame(close)
    def relative(k):
        ret=frame.pct_change(k,fill_method=None);market=ret.median(axis=1,skipna=True)
        rel=ret.sub(market,axis=0);return rel.to_numpy(),ret.rank(axis=1,pct=True,method='average').to_numpy(),market.to_numpy()
    return relative(3),relative(12),relative(36)

def generate(section,n):
    folder=location(section);base,start,end=dates(section);ins={i['instId'].split('-')[0]:i for i in json.loads(Path('ins.json').read_text())['data'] if i['instId'].endswith('-USDT-SWAP')}
    (r3,q3,market3),(r12,q12,_),(r36,q36,_)=cross_inputs(folder,n)
    size=len(r3);ts=base+(np.arange(size)+1)*n*MINUTE;source=(ts-base)//MINUTE;labels=[(name,side,level) for name in NAMES for side in (1,-1) for level in (0,1)]
    best={k:(np.full(size,-np.inf),np.full(size,-1,dtype=np.int16),np.zeros(size),np.zeros(size),np.zeros(size)) for k in labels}
    sess=((ts-n*MINUTE+9*HOUR)//(8*HOUR));offset=((ts-n*MINUTE+9*HOUR)%(8*HOUR))//(n*MINUTE)
    for sym in sorted(COINS):
        idx=COINS.index(sym);tick=float(ins[sym]['tickSz']);ct=float(ins[sym]['ctVal']);v=np.load(folder/f'{sym}-{n}.npy',mmap_mode='r');o,h,l,c,vol,f_rate,f_age,p,atr,rv,e12,e36,vwap,squeeze=sym_features(v)
        hi12=shift(roll(h,12,'max'));lo12=shift(roll(l,12,'min'));hi24=shift(roll(h,24,'max'));lo24=shift(roll(l,24,'min'))
        turn=roll(vol*c*ct,60//n,'sum');run=roll(np.isfinite(c).astype(float),96,'sum')==96
        base_ok=run&(ts>=start)&(ts<end)&(atr/c>=.0014)&(atr/c<=.04)&(tick/c<=.0005)&(turn>=60000)&(h>l)&(vol>0)
        # Session extrema only become usable after the first 30 minutes of the known eight-hour block.
        session_high=pd.Series(np.where(offset<30//n,h,np.nan)).groupby(sess).cummax().groupby(sess).ffill().to_numpy()
        session_low=pd.Series(np.where(offset<30//n,l,np.nan)).groupby(sess).cummin().groupby(sess).ffill().to_numpy()
        for side in (1,-1):
            ext=l if side==1 else h;opposite=h if side==1 else l; z=side*(c-vwap)/atr;tpos=side*(c-e12)/atr
            location_close=np.where(h>l,(c-l if side==1 else h-c)/(h-l),0);tail=(np.minimum(o,c)-l if side==1 else h-np.maximum(o,c))/(h-l)
            trend=(side*(e12-e36)>0)&(side*(e12-shift(e12,4))>0); fav=side*(c-o)>0
            strong12=q12[:,idx] if side==1 else 1-q12[:,idx];strong36=q36[:,idx] if side==1 else 1-q36[:,idx]
            strong3=q3[:,idx] if side==1 else 1-q3[:,idx];rel3=side*r3[:,idx]*c/atr;rel12=side*r12[:,idx]*c/atr
            prior_band=hi24 if side==1 else lo24; prior_small=hi12 if side==1 else lo12; fail_level=lo12 if side==1 else hi12
            baseline=side*(c-prior_band)/atr;recovered=side*(c-fail_level)/atr; overshoot=side*(fail_level-ext)/atr
            recoil=side*(c-shift(c,3))/atr;band=side*(c-vwap)/atr
            channel=(baseline>0)&(baseline<1.65)&fav&(rv>=1.1)&(location_close>=.65)
            sweep=(overshoot>.08)&(recovered>.10)&(tail>=.23)&(rv>=1.05)&(location_close>=.58)
            touch=side*(ext-e12)/atr
            pull=trend&(touch<=.15)&(touch>=-1.7)&(tpos>.10)&(tpos<1.6)&fav&(side*(c-shift(opposite))>0)
            vwap_re=(shift(z)<-1.6)&(band>-1.6)&(band<.25)&fav&(location_close>=.58)&(rv>=.85)
            rotation=(strong36>=.76)&(shift(rel3)<-.23)&(side*(c-p)>.12*atr)&fav&(location_close>=.55)&(side*market3>-.015)
            shock=(shift(strong3)<=.15)&(shift(rel3)<-1.1)&fav&(location_close>=.55)&(rv>=1)&(side*(c-p)>.12*atr)
            sq=squeeze&(side*(c-prior_small)>.05*atr)&(rv>=1.4)&(location_close>=.62)&fav
            funding=(side*f_rate<-.00010)&(f_age>=0)&(f_age<=120)&fav&(location_close>=.58)&(side*(c-p)>.1*atr)
            extreme=(strong12<=.15)&(rel12<-1.6)&(rv>=1.1)&(tail>=.15)
            wall=session_high if side==1 else session_low
            session=(offset>=30//n)&(offset<=180//n)&(side*(p-wall)<=0)&(side*(c-wall)>.10*atr)&fav&(rv>=1.15)&(location_close>=.65)
            candidates=[(channel,np.abs(baseline)+np.log1p(rv),2),
                        (sweep,overshoot+tail+np.log1p(rv),1),
                        (pull,side*(e12-e36)/atr+location_close,4),
                        (vwap_re,-shift(z)+location_close,3),
                        (rotation,strong36-shift(rel3)+location_close,3),
                        (shock,-shift(rel3)+tail+location_close,3),
                        (sq,side*(c-prior_small)/atr+np.log1p(rv),2),
                        (funding,-side*f_rate*1000+location_close,3),
                        (extreme,-rel12+tail+np.log1p(rv),2),
                        (session,side*(c-wall)/atr+np.log1p(rv),2)]
            pad=np.maximum.reduce([np.full(size,2*tick),.40*atr,shift(roll((np.minimum(o,c)-l if side==1 else h-np.maximum(o,c)),12,'median'))]);stops={}
            for look in (1,2,3,4):
                anchor=roll(ext,look,'min' if side==1 else 'max') if look>1 else ext
                raw=(anchor-side*pad)/tick;stops[look]=(np.floor(raw+1e-10) if side==1 else np.ceil(raw-1e-10))*tick
            for name,(fire,score,look) in zip(NAMES,candidates):
                stop=stops[look];dist=side*(c-stop);ok=base_ok&fire&(dist>=.65*atr)&(dist<=4.5*atr)&(dist/c<=.06)&(stop>0)&np.isfinite(score)
                strict=(rv>=1.5)&(atr/c>=.0027)&(location_close>=.62)
                for level in (0,1):
                    rank,syms,ref,atrs,st=best[(name,side,level)];hits=np.flatnonzero(ok&(strict if level else True)&(score>rank));rank[hits]=score[hits];syms[hits]=idx;ref[hits]=c[hits];atrs[hits]=atr[hits];st[hits]=stop[hits]
    frames=[]
    for (name,side,level),(rank,syms,ref,atrs,st) in best.items():
        ix=np.flatnonzero(syms>=0)
        frames.append(pd.DataFrame(dict(clock=source[ix].astype('int32'),rule=name+('_long' if side==1 else '_short'),side=np.int8(side),level=np.int8(level),bar=np.int8(n),sym=syms[ix],quality=rank[ix],ref=ref[ix],atr=atrs[ix],stop=st[ix])))
    df=pd.concat(frames,ignore_index=True);df.to_pickle(folder/f'signals-{n}.pkl');print(n,'minute frame',len(df),'ranked opportunities',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section');ap.add_argument('bar',type=int,choices=(5,15));args=ap.parse_args()
    with np.errstate(divide='ignore',invalid='ignore'),warnings.catch_warnings():
        warnings.simplefilter('ignore',category=RuntimeWarning);generate(args.section,args.bar)

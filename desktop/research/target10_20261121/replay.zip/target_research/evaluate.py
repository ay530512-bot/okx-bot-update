"""Rank hypotheses without the recent test. Each setting trades one 150 USDT balance."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
from inputs import COINS, MINUTE, stamp, dates, location
from replay import m,sc,timing,lengths
from paths import lib,meta

PLAN=json.loads(Path(__file__).with_name('plan.json').read_text());CACHE=Path('target_cache')
OLD=dict(m.WINDOWS,**{k:(v[1],v[2]) for k,v in sc.SPECS.items()})
SESSIONS=[(h,(h+8)%24 or 24) for h in range(0,24,4)]+[(0,12),(12,24)]
METRICS=('trades','final','closed_dd_pct','wins','largest_gain','gains','losses','active_days')

def limits(pair):return tuple(stamp(v)//MINUTE for v in pair)

def contract_table():
    ins=meta();return np.ascontiguousarray([[float(ins[s][k]) for k in ('ctVal','lotSz','minSz','maxMktSz')] for s in COINS])
CONTRACTS=contract_table()

class Events:
    def __init__(self,section,stress=False,passive=False):
        self.section=section;self.stress=stress;self.passive=passive;self.groups={};self.dll=lib()
        root='limits' if passive else 'hypotheses';f=location(section)/(root+('-stress' if stress else '')+'.pkl');frame=pd.read_pickle(f)
        self.new_routes=sorted(map(str,frame.rule.unique()))
        for group,x in frame.groupby(['rule','bar','level','wait','hold'],observed=True,sort=False):
            self.groups[group]=np.ascontiguousarray(x[['signal','entry','exit','sym','price','dist','net']].to_numpy(dtype='f8'))
        del frame
        file={'development':CACHE/'old_development.pkl','recent':Path('timing_cache/opportunities.pkl'),'earlier':CACHE/'old_earlier.pkl'}[section]
        if stress:file={'recent':CACHE/'old_recent_stress.pkl','earlier':CACHE/'old_earlier_stress.pkl','development':CACHE/'old_development_stress.pkl'}[section]
        self.old_routes=[]
        if not passive and file.exists():
            ys=pd.read_pickle(file);start,end=map(lambda i:i//MINUTE,dates(section)[1:]);ys=ys[(ys.entry>=start*MINUTE)&(ys.entry<end*MINUTE)].copy();ys['sym']=ys.symbol.map({s:i for i,s in enumerate(COINS)});ys['entry']=(ys.entry//MINUTE).astype('int64');ys['signal']=ys.entry;ys['exit']=(ys.exit//MINUTE).astype('int64');ys['dist']=(ys.price-ys.stop).abs()/ys.price
            for (rule,hold),g in ys.groupby(['rule','hold'],sort=False):
                for i,mode in enumerate(timing.FILTERS):
                    x=g[(g['mask']&(1<<i))!=0].drop_duplicates('entry',keep='first')
                    self.groups[(rule,mode,hold)]=np.ascontiguousarray(x[['signal','entry','exit','sym','price','dist','net']].to_numpy(dtype='f8'))
            self.old_routes=sorted(ys.rule.unique())

    def configs(self,route):
        if route in OLD:
            wins=list(dict.fromkeys([OLD[route],*[(h,h+4) for h in range(0,24,4)],*SESSIONS]));caps=list(dict.fromkeys([sc.SPECS[route][-1] if route in sc.SPECS else 1,4]))
            for mode in timing.FILTERS:
                for hold in lengths(route):
                    for a,b in wins:
                        for cap in caps:yield dict(rule=route,mode=mode,hold=hold,start=a,end=b,cap=cap)
        else:
            for bar in (5,15):
                for level in (0,1):
                    for wait in ((2,) if self.passive else (0,1)):
                        for hold in (45,120):
                            for a,b in SESSIONS:yield dict(rule=route,bar=bar,level=level,wait=wait,hold=hold,start=a,end=b,cap=4)

    def key(self,c):
        if c['rule'] in OLD:return (c['rule'],c['mode'],c['hold'])
        return tuple(c[k] for k in ('rule','bar','level','wait','hold'))

    def evaluate(self,c,span):
        group=self.groups.get(self.key(c));out=np.zeros(8)
        if group is None:out[1]=150.
        else:self.dll.single(group,len(group),CONTRACTS,*span,c['start'],c['end'],0 if c['rule'] in OLD and c['rule'] not in sc.SPECS else 540,c['cap'],c['hold'],5 if c['rule'] in m.RESERVED else 10,int(self.passive),.0005,.001 if self.stress else .0005,out)
        stats=dict(zip(METRICS,map(float,out)));stats['net_pct']=(out[1]/150-1)*100
        for k in ('trades','wins','active_days'):stats[k]=int(stats[k])
        return stats


def score(a,b):return min(a['net_pct'],b['net_pct'])+.25*(a['net_pct']+b['net_pct'])-.20*max(a['closed_dd_pct'],b['closed_dd_pct'])

def freeze(db):
    split=list(map(limits,PLAN['development']));valid=limits(PLAN['selection_validation']);table=[];frozen={};shortlist={};refs={}
    for route in [*db.old_routes,*db.new_routes]:
        ranked=[]
        for c in db.configs(route):
            a,b=(db.evaluate(c,period) for period in split)
            enough=min(a['trades'],b['trades'])>=8;passing=enough and min(a['net_pct'],b['net_pct'])>0 and a['final']+b['final']-300>max(a['largest_gain'],b['largest_gain'])
            row=dict(config=c,a=a,b=b,development_pass=bool(passing),development_score=float(score(a,b)));ranked.append(row)
            table.append(dict(**c,dev1_net=a['net_pct'],dev2_net=b['net_pct'],dev1_trades=a['trades'],dev2_trades=b['trades'],development_pass=passing))
        ranked.sort(key=lambda r:(r['development_pass'],min(r['a']['trades'],r['b']['trades'])>=8,r['development_score']),reverse=True)
        unique=set();pool=[]
        for row in ranked:
            signature=tuple((r['trades'],round(r['final'],7),round(r['closed_dd_pct'],7)) for r in [row['a'],row['b']]);
            if signature in unique:continue
            unique.add(signature);v=db.evaluate(row['config'],valid);row['validation']=v;row['prequalified']=bool(row['development_pass'] and v['trades']>=10 and v['net_pct']>0);pool.append(row)
            if len(pool)==3:break
        pool.sort(key=lambda r:(r['prequalified'],r['validation']['trades']>=10,r['validation']['net_pct']-.18*r['validation']['closed_dd_pct'],r['development_score']),reverse=True)
        frozen[route]=pool[0];shortlist[route]=pool
        if route in OLD:refs[route]=sum(1 for r in ranked if r['development_pass'])
    suffix='limit' if db.passive else 'target'
    pd.DataFrame(table).to_csv(CACHE/('development_limit.csv' if db.passive else 'development.csv'),index=False)
    obj=dict(plan_sha256=hashlib.sha256(Path(__file__).with_name('plan.json').read_bytes()).hexdigest(),configuration_count=len(table),shortlist_count=sum(map(len,shortlist.values())),frozen=frozen,shortlist=shortlist)
    (CACHE/f'frozen_{suffix}.json').write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');print('evaluated',len(table),'prequalified',[(k,round(r['validation']['net_pct'],2)) for k,r in frozen.items() if r['prequalified']]);print('validation top',sorted([(r['validation']['net_pct'],k,r['development_pass']) for k,r in frozen.items()],reverse=True)[:10]);return obj


def test(db):
    suffix='limit' if db.passive else 'target';frozen=json.loads((CACHE/f'frozen_{suffix}.json').read_text());assert frozen['plan_sha256']==hashlib.sha256(Path(__file__).with_name('plan.json').read_bytes()).hexdigest();span=tuple(x//MINUTE for x in dates(db.section)[1:]);result={}
    for name,r in frozen['frozen'].items():
        if db.key(r['config']) not in db.groups:continue
        st=db.evaluate(r['config'],span);result[name]={**st,'prequalified':r['prequalified'],'recent_target':bool(st['net_pct']>=10 and st['trades']>=15)}
    out=CACHE/(db.section+('-limits' if db.passive else '')+('-stress' if db.stress else '')+'-scores.json');out.write_text(json.dumps(result,indent=2,allow_nan=False));print(db.section,'stress',db.stress,'top by net',sorted([(round(v['net_pct'],3),k,v['trades'],v['prequalified']) for k,v in result.items()],reverse=True)[:10]);print('individual eligible',[(k,v['net_pct']) for k,v in result.items() if v['recent_target'] and v['prequalified']]);return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section');ap.add_argument('--stress',action='store_true');ap.add_argument('--passive',action='store_true');args=ap.parse_args();src=Events(args.section,args.stress,args.passive)
    if args.section=='development' and not args.stress:freeze(src)
    else:test(src)

"""Run the data and replay stages from a study directory containing the PC 2.5.0 package."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys


def run(script, *args):
    subprocess.run([sys.executable, script, *args], check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fetch", action="store_true", help="Download public OKX data first")
    parser.add_argument("--workers", default="4")
    args = parser.parse_args()
    os.environ["OPENBLAS_NUM_THREADS"] = "1"
    os.environ["OMP_NUM_THREADS"] = "1"
    os.environ["MKL_NUM_THREADS"] = "1"
    cache = Path("target_cache")
    cache.mkdir(exist_ok=True)
    if args.fetch:
        for begin, end in [("2026-03-03", "2026-08-30"), ("2026-09-22", "2026-11-21")]:
            run("timing_research/fetch_public.py", "--start", begin, "--end", end)
    shutil.copyfile("reference/instruments.json", "ins.json")
    run("target_research/paths.py", "compile")
    run("target_research/test_replay.py", "-q")
    run("target_research/legacy.py")
    recent = ["--start", "2026-09-22", "--end", "2026-11-21", "--workers", args.workers]
    run("timing_research/replay.py", *recent, "--out", "timing_cache/opportunities.pkl")
    run("timing_research/replay.py", *recent, "--slip", ".001", "--close-only",
        "--out", "target_cache/old_recent_stress.pkl")
    for section in ("development", "recent"):
        run("target_research/inputs.py", section, "--workers", args.workers)
        for frame in ("5", "15"):
            run("target_research/patterns.py", section, frame)
            run("target_research/passive.py", section, frame)
        for ordering in ([], ["--passive"]):
            run("target_research/paths.py", section, *ordering)
            run("target_research/evaluate.py", section, *ordering)
            if section == "recent":
                run("target_research/paths.py", section, *ordering, "--stress")
                run("target_research/evaluate.py", section, *ordering, "--stress")
        run("target_research/meta.py", section)
    run("target_research/portfolio.py", "recent")
    run("target_research/portfolio.py", "recent", "--stress")


if __name__ == "__main__":
    main()

#include <algorithm>
#include <cmath>
#include <limits>

// Input candles: open, high, low, close, volume, settled funding rate.
extern "C" void paths(const double* bars, int n, const double* signals, int count,
                      int side, int frame, int retest, double tick, double slip,
                      double fee, int close_trail, double* out) {
    const double missing=std::numeric_limits<double>::quiet_NaN();
    for(int k=0;k<count;++k) {
        const double* s=signals+4*k; double* result=out+7*k;
        std::fill(result,result+7,missing);
        const int first=int(s[0]); const double ref=s[1], atr=s[2], stop=s[3];
        int enter=first; double validation=ref;
        if (first<0 || first>=n) continue;
        if (retest) {
            enter=-1; const double level=ref-side*.35*atr;
            for (int j=first; j<std::min(n-1,first+std::min(10,frame)); ++j) {
                const double* b=bars+6*j;
                if(!std::isfinite(b[3]) || (side==1 ? b[2]<=stop : b[1]>=stop)) break;
                if((side==1? b[2]<=level:b[1]>=level) && side*(b[3]-level)>=0 && side*(b[3]-b[0])>0) {
                    enter=j+1; validation=b[3];break;
                }
            }
            if(enter<0) continue;
        }
        const double price=bars[6*enter]*(1+side*slip),risk=side*(price-stop);
        if(!std::isfinite(price) || risk<=0 || std::abs(price-validation)>.5*atr || side*(price-ref)>.8*atr) continue;
        result[0]=enter;result[1]=price;result[2]=risk/price;
        double sl=stop,carry=0.;
        for(int j=enter;j<std::min(n,enter+120);++j) {
            const double* b=bars+6*j;
            if(!std::isfinite(b[3])) break;
            if(j>enter) carry-=side*b[0]*b[5];
            const double adverse=side==1?b[2]:b[1];
            const double favorable=close_trail?b[3]:(side==1?b[1]:b[2]);
            bool closed=side*(adverse-sl)<=0;
            double exit=closed?(side==1?std::min(b[0],sl):std::max(b[0],sl)):b[3];
            if(!closed && side*(favorable-price)>=risk) {
                const double raw=(favorable-side*risk)/tick;
                const double next=(side==1?std::floor(raw+1.e-10):std::ceil(raw-1.e-10))*tick;
                if(side*(next-sl)>0) {
                    sl=next;
                    if(!close_trail && side*(b[3]-sl)<=0) { closed=true;exit=sl; }
                }
            }
            int held=j-enter+1;
            if(closed || held==45 || held==120) {
                exit*=1-side*slip;const double net=(side*(exit-price)+carry-fee*(price+exit))/price;
                if(held==45 || (closed && held<=45)){result[3]=j+1;result[4]=net;}
                if(held==120 || closed){result[5]=j+1;result[6]=net;}
                if(closed) break;
            }
        }
    }
}

// A single rule's actual portfolio gets one position at a time. Timestamps are minutes since the epoch.
// Each observation: signal, fill, exit, symbol index, fill price, fractional stop distance, all-in net return.
extern "C" void single(const double* obs,int n,const double* instruments,int start,int end,
                       int begin_hour,int end_hour,int day_offset,int cap,int hold,int lev,int resting,
                       double fee,double slip,double* out) {
    double balance=150.,peak=150.,dd=0.,winner=0.,profits=0.,losses=0.;
    int previous=-1,last_day=-1,fills=0,count=0,wins=0,active_days=0;
    for(int k=0;k<n;k++) {
        const double* row=obs+7*k;
        if(!std::isfinite(row[6]))continue;
        int t=int(row[1]),signal=int(row[0]);
        if(signal<start || t>=end-hold || t<previous || (resting && signal<previous) || int(row[2])>end)continue;
        const int width=(end_hour-begin_hour+24)%24;
        int hr=((t+540)/60)%24,sh=((signal+540)/60)%24;
        if((hr-begin_hour+24)%24>=width || (sh-begin_hour+24)%24>=width) continue;
        int day=(t+day_offset)/1440;
        if(day!=last_day){fills=0;last_day=day;}
        if(fills>=cap)continue;
        double equity=balance-3.;if(equity<=0)break;
        const double* ins=instruments+4*int(row[3]);double unit=ins[0]*ins[1]*row[4];
        double nominal=std::min(equity*.1*lev,equity*.005/(row[5]+2*(fee+slip)));
        double lots=std::floor(nominal/unit+1.e-12);double quantity=lots*ins[1];
        if(quantity<ins[2] || quantity>ins[3])continue;
        nominal=lots*unit;if(nominal/lev+nominal*fee>equity)continue;
        previous=int(row[2]);if(!fills)++active_days;++fills;++count;
        double pnl=nominal*row[6];balance+=pnl;winner=std::max(winner,pnl);
        if(pnl>0){++wins;profits+=pnl;}else{losses-=pnl;}
        peak=std::max(peak,balance);dd=std::max(dd,1-balance/peak);
    }
    out[0]=count;out[1]=balance;out[2]=dd*100;out[3]=wins;out[4]=winner;out[5]=profits;out[6]=losses;out[7]=active_days;
}

// A limit can fill only after resting; a favorable high/low from the fill minute is not known to follow that fill.
extern "C" void resting_paths(const double* bars, int n, const double* signals, int count,
                              int side,int frame,double tick,double slip,double fee,int stress,double* out) {
    const double missing=std::numeric_limits<double>::quiet_NaN();
    for(int k=0;k<count;k++) {
        const double* s=signals+3*k;double* row=out+k*7;std::fill(row,row+7,missing);
        const int signal=int(s[0]), sent=signal+1;const double entry=s[1],stop=s[2];
        if(sent>=n || signal<0) continue;
        const double* before=bars+6*signal;const double opening=bars[6*sent];
        if(!std::isfinite(before[3]) || !std::isfinite(opening) || side*(opening-entry)<=2*tick || (side==1?before[2]<=stop:before[1]>=stop))continue;
        const double penetration=std::max((stress?4:2)*tick,entry*(stress?.0005:.0002));
        int enter=-1;
        for(int j=sent;j<std::min(n,signal+std::min(10,frame));j++) {
            const double* b=bars+6*j;if(!std::isfinite(b[3]))break;
            if(side==1 ? b[2]<=entry-penetration : b[1]>=entry+penetration){enter=j;break;}
        }
        if(enter<0)continue;
        const double risk=side*(entry-stop);if(risk<=0) continue;
        row[0]=enter;row[1]=entry;row[2]=risk/entry;double sl=stop,carry=0.;
        for(int j=enter;j<std::min(n,enter+120);j++) {
            const double* b=bars+6*j;if(!std::isfinite(b[3]))break;
            if(j>enter)carry-=side*b[0]*b[5];
            const double adverse=side==1?b[2]:b[1];
            const double favorable=(j==enter || stress)?b[3]:(side==1?b[1]:b[2]);
            bool closed=side*(adverse-sl)<=0;
            double exit=closed?(side==1?std::min(sl,b[0]):std::max(sl,b[0])):b[3];
            if(!closed && side*(favorable-entry)>=risk){
                const double raw=(favorable-side*risk)/tick;
                const double next=(side==1?std::floor(raw+1.e-10):std::ceil(raw-1.e-10))*tick;
                if(side*(next-sl)>0){sl=next;if(j!=enter && !stress && side*(b[3]-sl)<=0){closed=true;exit=sl;}}
            }
            const int held=j-enter+1;
            if(closed || held==45 || held==120){
                exit*=1-side*slip;
                const double net=(side*(exit-entry)+carry-fee*(entry+exit)-slip*entry)/entry;
                if(held==45 || (closed && held<=45)){row[3]=j+1;row[4]=net;}
                if(held==120 || closed){row[5]=j+1;row[6]=net;}
                if(closed)break;
            }
        }
    }
}

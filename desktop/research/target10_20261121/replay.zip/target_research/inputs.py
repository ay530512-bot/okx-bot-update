"""Verified public data cache for a continuous KST study interval."""
import argparse
from concurrent.futures import ProcessPoolExecutor
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
sys.path.insert(0,str(Path.cwd()/'timing_research'))
from replay import COINS, MINUTE, HOUR, DAY, bars_from_archive, rates, agg, stamp

PERIODS={'development':('2026-03-03','2026-08-30'),'recent':('2026-09-22','2026-11-21'),'earlier':('2026-01-01','2026-03-02')}

def location(section):return Path('target_cache')/section

def dates(section):
    start,end=map(stamp,PERIODS[section]);return (start-4*DAY)//DAY*DAY,start,end

def prepare(job):
    section,symbol=job;folder=location(section);base,start,end=dates(section)
    df=bars_from_archive(symbol,base,end);fr=rates(symbol)
    funding=np.zeros(len(df));ix=[(t-base)//MINUTE for t in fr if base<=t<end];vals=[fr[t] for t in fr if base<=t<end]
    funding[ix]=vals;fund_rows=sorted(t for t in fr if start<=t<end)
    np.save(folder/(symbol+'-1.npy'),np.ascontiguousarray(np.column_stack((df.to_numpy(),funding)),dtype=np.float64))
    latest=pd.Series(np.nan,index=df.index,dtype=float)
    for t in sorted(fr):
        if base<=t+MINUTE<end:latest.loc[t+MINUTE]=fr[t]
    for minutes in [5,15]:
        q=agg(df,minutes); asof=q.index+minutes*MINUTE; known=latest.ffill().reindex(asof).to_numpy()
        prep=pd.Series(np.where(latest.notna(),df.index,np.nan),index=df.index).ffill().reindex(asof).to_numpy()
        age=(asof.to_numpy()-prep)/MINUTE
        np.save(folder/(symbol+f'-{minutes}.npy'),np.column_stack((q.to_numpy(),known,age)))
    xs=df.close.loc[start:end-MINUTE];good=xs.dropna();active_missing=0 if good.empty else int(xs.loc[good.index[0]:good.index[-1]].isna().sum());right_missing=0 if good.empty else int((end-MINUTE-good.index[-1])/MINUTE)
    return symbol,dict(valid_minutes=len(good),missing_inside=active_missing,missing_tail=right_missing,first=int(good.index[0]) if not good.empty else None,funding_records=len(fund_rows),max_funding_gap_h=max((b-a for a,b in zip(fund_rows,fund_rows[1:])),default=0)/HOUR)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section',choices=PERIODS);ap.add_argument('--workers',type=int,default=4);a=ap.parse_args();loc=location(a.section);loc.mkdir(parents=True,exist_ok=True)
    with ProcessPoolExecutor(a.workers) as pool:result=dict(pool.map(prepare,[(a.section,s) for s in COINS]))
    (loc/'coverage.json').write_text(json.dumps(result,indent=2));print(a.section,'instruments',len(result),'internal gaps', {s:v['missing_inside'] for s,v in result.items() if v['missing_inside']},'active short coverage',[(k,v['valid_minutes']) for k,v in result.items() if v['valid_minutes']<(dates(a.section)[2]-dates(a.section)[1])//MINUTE-100],flush=True)

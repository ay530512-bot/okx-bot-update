"""Frozen, pooled indicator model for market entry; no per-symbol or future-dependent features."""
import argparse,json,warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from inputs import COINS,MINUTE,dates,location
from patterns import NAMES, sym_features, cross_inputs, shift,roll
from evaluate import CACHE,PLAN,SESSIONS,Events,CONTRACTS,METRICS,limits
from paths import lib

MODEL_PLAN=json.loads(Path(__file__).with_name('plan_model.json').read_text())

def feature_set(section):
    folder=location(section);base,*_=dates(section);allrows=[];allfeatures=[]
    paths=pd.read_pickle(folder/'hypotheses.pkl');paths=paths[(paths['level']==0)&(paths['wait']==0)]
    ids=['rule','bar','sym','signal']; targets=paths.pivot(index=ids,columns='hold',values='net')
    fill=paths.drop_duplicates(ids).set_index(ids)[['price','dist','entry']]
    exitat=paths.pivot(index=ids,columns='hold',values='exit'); targets.columns=['net'+str(j) for j in targets];exitat.columns=['exit'+str(j) for j in exitat];actual=fill.join(targets).join(exitat)
    for n in (5,15):
        candidates=pd.read_pickle(folder/f'signals-{n}.pkl');candidates=candidates[candidates.level==0].copy();candidates['signal']=(base//MINUTE+candidates.clock).astype('int64')
        (r3,q3,m3),(r12,q12,m12),(r36,q36,_)=cross_inputs(folder,n)
        for (ci,side),g in candidates.groupby(['sym','side'],sort=False):
            v=np.load(folder/f'{COINS[ci]}-{n}.npy',mmap_mode='r');o,h,l,c,vol,rate,age,prev,atr,rv,e12,e36,vwap,squeeze=sym_features(v);ix=(g.clock.to_numpy()//n-1).astype(int)
            range_=np.maximum(h-l,c*1.e-12);k=g.signal.to_numpy();tag=[x.rsplit('_',1)[0] for x in g.rule.astype(str)];weights=(k+540)%1440/1440*2*np.pi
            base_features=[np.log1p(np.maximum(0,rv)),np.log(np.maximum(1.e-8,atr/c)),side*(e12-e36)/atr,side*(e12-shift(e12,4))/atr,side*(c-e12)/atr,side*(c-vwap)/atr,side*(c-o)/range_,(c-l if side==1 else h-c)/range_,range_/atr,side*(c-prev)/atr,side*(c-shift(c,3))/atr,side*(c-shift(c,12))/atr,abs(c-shift(c,12))/roll(abs(c-prev),12,'sum'),side*r3[:,ci]*c/atr,side*r12[:,ci]*c/atr,side*(q12[:,ci]-.5),side*(q36[:,ci]-.5),side*m3*c/atr,side*m12*c/atr,side*rate*10000,np.minimum(age,480)/480,squeeze.astype(float)]
            features=np.column_stack([*[a[ix] for a in base_features],side*(g.ref.to_numpy()-g.stop.to_numpy())/g.atr.to_numpy(),np.sin(weights),np.cos(weights),np.full(len(g),float(n==15)),*[np.asarray(tag)==name for name in NAMES]])
            # Fixed clipping bounds; the test distribution never sets scaling parameters.
            features=np.nan_to_num(np.clip(features,-12,12),nan=0.,posinf=12,neginf=-12).astype('f4');allfeatures.append(features);allrows.append(g.merge(actual,how='left',left_on=ids,right_index=True)[['rule','bar','side','sym','signal','price','dist','entry','net45','net120','exit45','exit120']])
    return pd.concat(allrows,ignore_index=True),np.vstack(allfeatures)

def single(rows,c,span,stress=False):
    out=np.zeros(8);lib().single(rows,len(rows),CONTRACTS,*span,c['start'],c['end'],540,c['cap'],c['hold'],10,0,.0005,.001 if stress else .0005,out);d=dict(zip(METRICS,map(float,out)));d['net_pct']=(out[1]/150-1)*100
    for k in ('trades','wins','active_days'):d[k]=int(d[k])
    return d

def models(x,y):
    return [('ridge',make_pipeline(StandardScaler(),Ridge(alpha=150)).fit(x,y)),('boost',HistGradientBoostingRegressor(max_iter=60,max_leaf_nodes=7,min_samples_leaf=150,l2_regularization=12,learning_rate=.045,early_stopping=False,random_state=1).fit(x,y))]

def ranked(pred,r,gate,h):
    need=(pred>=gate);g=r.loc[need].assign(score=pred[need]);g=g.sort_values(['signal','score','rule','sym'],ascending=[True,False,True,True]).drop_duplicates('signal',keep='first');g=g[g['net'+str(h)].notna()];return np.ascontiguousarray(g[['signal','entry','exit'+str(h),'sym','price','dist','net'+str(h)]].to_numpy(dtype='f8'))

def generate(section):
    der=CACHE/'meta_input_dev.pkl'
    if der.exists(): rr,xx=pd.read_pickle(der)
    else:
        rr,xx=feature_set('development');pd.to_pickle((rr,xx),der)
    start,cut=limits(MODEL_PLAN['training']);r,x=(rr,xx) if section=='development' else feature_set(section)
    groups={};stress_groups={};thresholds={};stressed=None
    if section!='development' and (location(section)/'hypotheses-stress.pkl').exists():
        fp=pd.read_pickle(location(section)/'hypotheses-stress.pkl');fp=fp[(fp['level']==0)&(fp['wait']==0)]
        ids=['rule','bar','sym','signal'];levels=fp.drop_duplicates(ids).set_index(ids)[['price','dist','entry']]
        for h in (45,120):
            measured=fp[fp.hold==h].set_index(ids)[['net','exit']].rename(columns={'net':'net'+str(h),'exit':'exit'+str(h)})
            levels=levels.join(measured)
        stressed=r[['rule','bar','sym','signal','side']].merge(levels,how='left',left_on=ids,right_index=True);assert len(stressed)==len(r)
    for side in (1,-1):
        use=r.side.to_numpy()==side;rt=r.loc[use];xt=x[use]
        for h in (45,120):
            take=(rr.side==side)&(rr.signal>=start)&(rr.signal<cut-h)&(rr['exit'+str(h)]<=cut)&rr['net'+str(h)].notna()
            y=(rr.loc[take,'net'+str(h)]/(rr.loc[take,'dist']+.002)).clip(-2,4).to_numpy(dtype='f8');inp=xx[take]
            for name,reg in models(inp,y):
                pred=reg.predict(xt);train_pred=reg.predict(inp);p95=max(.02,float(np.quantile(train_pred,.95)));thresholds[str((side,h,name))]=p95
                for lvl,gate in enumerate([.02,p95]):
                    groups[side,h,name,lvl]=ranked(pred,rt,gate,h)
                    if stressed is not None:stress_groups[side,h,name,lvl]=ranked(pred,stressed.loc[use],gate,h)
    if stress_groups:pd.to_pickle((stress_groups,thresholds),location(section)/'meta-stress-groups.pkl')
    pd.to_pickle((groups,thresholds),location(section)/'meta-groups.pkl');return groups

def dev(groups):
    tr=limits(MODEL_PLAN['selection']);va=limits(MODEL_PLAN['validation']);allconfigs=0;frozen={}
    for side in (1,-1):
        rank=[]
        for (s,h,model,level),rows in groups.items():
            if s!=side:continue
            for a,b in SESSIONS:
                for cap in (4,8):
                    c=dict(rule='indicator_model_'+('long' if side==1 else 'short'),side=int(side),model=model,level=level,hold=h,start=a,end=b,cap=cap);allconfigs+=1
                    stat=single(rows,c,tr);good=bool(stat['trades']>=8 and stat['final']-150>stat['largest_gain']);rank.append(dict(config=c,development=stat,development_pass=good))
        rank.sort(key=lambda r:(r['development_pass'],r['development']['trades']>=8,r['development']['net_pct']-.2*r['development']['closed_dd_pct']),reverse=True);pool=[];ids=set()
        for it in rank:
            d=it['development'];ident=(d['trades'],round(d['final'],7),round(d['closed_dd_pct'],7))
            if ident in ids:continue
            ids.add(ident);c=it['config'];v=single(groups[side,c['hold'],c['model'],c['level']],c,va);it['validation']=v;it['prequalified']=bool(it['development_pass'] and v['trades']>=10 and v['net_pct']>0);pool.append(it)
            if len(pool)==3:break
        pool.sort(key=lambda r:(r['prequalified'],r['validation']['trades']>=10,r['validation']['net_pct']-.18*r['validation']['closed_dd_pct']),reverse=True);frozen[pool[0]['config']['rule']]=pool[0]
    (CACHE/'frozen_model.json').write_text(json.dumps(dict(frozen=frozen,configuration_count=allconfigs),indent=2));print('model development + selection',[(k,r['prequalified'],r['development']['net_pct'],r['validation']['net_pct']) for k,r in frozen.items()],flush=True)

def test(groups,section,stress=False):
    frozen=json.loads((CACHE/'frozen_model.json').read_text())['frozen'];out={};span=tuple(v//MINUTE for v in dates(section)[1:]);
    for k,row in frozen.items():
        c=row['config'];d=single(groups[c['side'],c['hold'],c['model'],c['level']],c,span,stress);d.update(prequalified=row['prequalified'],recent_target=bool(d['net_pct']>=10 and d['trades']>=15));out[k]=d
    (CACHE/(section+('-stress' if stress else '')+'-model-scores.json')).write_text(json.dumps(out,indent=2));print(section,'model test',[(k,v['net_pct'],v['trades']) for k,v in out.items()]);

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section');a=ap.parse_args()
    with np.errstate(divide='ignore',invalid='ignore'),warnings.catch_warnings():
        warnings.simplefilter('ignore',category=RuntimeWarning);g=generate(a.section);dev(g) if a.section=='development' else test(g,a.section)
        extra=location(a.section)/'meta-stress-groups.pkl'
        if a.section!='development' and extra.exists():test(pd.read_pickle(extra)[0],a.section,True)

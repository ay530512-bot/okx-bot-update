"""Attribute holding-period profitability and compare position sizing on the same market data."""
import json
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / "target_research"))
from inputs import COINS, MINUTE, dates, location
from evaluate import CACHE, CONTRACTS, Events
from portfolio_review import replay
from replay import m, sc, timing

FEE = SLIP = 0.0005
PERIOD = "recent"
OUTPUT = ROOT / "entry_size_review"


def read(path):
    return json.loads(path.read_text())


def frozen_rules():
    rules = {}
    for option in ("target", "limit", "model"):
        rules.update(read(CACHE / f"frozen_{option}.json")["frozen"])
    return [r["config"] for r in rules.values() if r["prequalified"]]


def describe_trades(trades, bars_by_symbol, epoch):
    measurements = []
    for t in trades:
        side = int(t["side"])
        price = t["entry_price"]
        units = t["notional"] / price
        funding_per_unit = t["funding"] / units
        net_per_unit = t["net_usdt"] / units
        exit_fill = (net_per_unit + (side + FEE) * price - funding_per_unit) / (side - FEE)
        raw_entry = price / (1 + side * SLIP)
        raw_exit = exit_fill / (1 - side * SLIP)
        gross = side * (raw_exit - raw_entry) * units
        fees = FEE * (price + exit_fill) * units
        slippage = side * (price - raw_entry + raw_exit - exit_fill) * units
        assert abs(t["net_usdt"] - (gross - fees - slippage + t["funding"])) < 1e-8
        row = dict(t, raw_entry=raw_entry, raw_exit=raw_exit, gross=gross, fees=fees,
                   slippage=slippage, margin_pct=100 * t["margin"] / t["seed"])
        bars = bars_by_symbol[t["symbol"]]
        start = t["entry"] - epoch
        assert math.isclose(raw_entry, bars[start, 0], rel_tol=1e-10)
        exit_index = t["exit"] - epoch - 1
        high, low = bars[exit_index, 1:3]
        assert low - 1e-8*price <= raw_exit <= high + 1e-8*price
        settlement_bars = bars[start+1:exit_index+1]
        funding_check = -side*units*np.sum(settlement_bars[:, 0]*settlement_bars[:, 5])
        assert math.isclose(t["funding"], funding_check, abs_tol=1e-9)
        # Fixed clocks measure the directional signal even when the original position exited earlier.
        for minutes in (5, 15, 30):
            row[f"direction_{minutes}m_pct"] = 100 * side * (bars[start + minutes - 1, 3] / raw_entry - 1)
        measurements.append(row)
    return pd.DataFrame(measurements)


def main():
    db = Events(PERIOD)
    cfg = frozen_rules()
    folder = location(PERIOD)
    model = pd.read_pickle(folder / "meta-groups.pkl")[0]
    epoch = dates(PERIOD)[0] // MINUTE
    bars = {symbol: np.load(folder / f"{symbol}-1.npy", mmap_mode="r") for symbol in COINS}
    original = read(CACHE / "recent-portfolio.json")
    scenarios = {}
    entry = {}
    for name, cap, stop_budget in [
        ("current", .10, True),
        ("third_cap_same_risk", 1 / 3, True),
        ("fixed_third_without_stop_budgets", 1 / 3, False),
    ]:
        result = replay(db, cfg, PERIOD, model, margin_cap=cap, risk_limited=stop_budget)
        table = describe_trades(result["ledger"], bars, epoch)
        stats = {k: v for k, v in result.items() if k != "ledger"}
        stats.update(
            avg_margin=table.margin.mean(), median_margin=table.margin.median(),
            min_margin=table.margin.min(), max_margin=table.margin.max(),
            median_pct_of_allocatable=table.margin_pct.median(),
            median_stop_distance_pct=100 * table.stop_distance.median(),
            gross=table.gross.sum(), fees=table.fees.sum(), slippage=table.slippage.sum(),
            funding=table.funding.sum(), binding=table.binding.value_counts().to_dict(),
        )
        signatures = [(t["rule"], t["symbol"], t["entry"], t["exit"]) for t in result["ledger"]]
        reference = [(t["rule"], t["symbol"], t["entry"], t["exit"]) for t in original["ledger"]]
        stats["same_trade_sequence"] = signatures == reference
        if name == "current":
            assert stats["same_trade_sequence"] and abs(result["final"] - original["final"]) < 1e-9
            assert np.allclose(table.net_usdt, [t["net_usdt"] for t in original["ledger"]])
            for horizon in (5, 15, 30):
                moves = table[f"direction_{horizon}m_pct"]
                entry[str(horizon)] = dict(count=len(moves), median_pct=moves.median(),
                    mean_pct=moves.mean(), favorable=int((moves > 0).sum()), above_20bp=int((moves > .2).sum()))
            table.to_csv(OUTPUT / "trades.csv", index=False)
        scenarios[name] = stats

    # Replay the single trade admitted by the distributed PC's fresh rolling history.
    admitted = read(ROOT / "timing_cache/forward_final.json")["trades"]
    opportunities = pd.read_pickle(ROOT / "timing_cache/opportunities.pkl")
    deployed = []
    for begin, end, rule, symbol, net_usdt in admitted:
        rows = opportunities[(opportunities["entry"] == begin) & (opportunities.rule == rule) &
                             (opportunities.symbol == symbol) & (opportunities["exit"] == end) &
                             (opportunities.hold == timing.policies()[rule]["minutes"])]
        assert len(rows) == 1
        r = rows.iloc[0]
        lev = 5 if rule in m.RESERVED else 10
        notional = net_usdt / r.net
        ct, lot, minimum, maxqty = CONTRACTS[COINS.index(symbol)]
        distance = abs(r.price - r.stop) / r.price
        budget = min(147 * .10 * lev, 147 * .005 / (distance + 2 * (FEE + SLIP)))
        q = math.floor(budget / (ct * r.price * lot) + 1e-12) * lot
        assert minimum <= q <= maxqty and math.isclose(q * ct * r.price, notional)
        deployed.append(dict(rule=rule, symbol=symbol, kst=pd.Timestamp(begin, unit="ms", tz="UTC").tz_convert("Asia/Seoul").isoformat(),
                             entry_price=r.price, initial_stop=r.stop, margin=notional/lev, notional=notional,
                             leverage=lev, stop_distance_pct=distance*100, net_usdt=net_usdt))

    # Keep the same exit, 08–20 KST session, daily position cap and all costs. Only change the entry confirmation.
    wick = {}
    live = timing.policies()["scalp_higher"]
    for label in ("reclaim", "trend", "volume", "momentum"):
        variant = dict(rule="scalp_higher", mode=label, hold=live["minutes"], start=live["start"],
                       end=live["end"], cap=sc.SPECS["scalp_higher"][-1])
        wick[label] = db.evaluate(variant, [x // MINUTE for x in dates(PERIOD)[1:]])
    output = dict(period_kst=["2026-09-22", "2026-11-21 (exclusive)"],
                  scenarios=scenarios, direction_at_fixed_clocks=entry, deployed_fills=deployed,
                  fixed_window_wick_test=wick)
    (OUTPUT / "summary.json").write_text(json.dumps(output, indent=2, allow_nan=False) + "\n")
    print(json.dumps(output, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()

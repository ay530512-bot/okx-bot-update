"""Replay the portfolio frozen on development/validation. One balance, one position per rule and symbol."""
import argparse,collections,json,math
from pathlib import Path
import numpy as np
import pandas as pd
from inputs import COINS,MINUTE,dates,location
from evaluate import Events,OLD,CONTRACTS,CACHE
from replay import m,sc


def replay(db,configurations,section,model_groups=None,*,margin_cap=.10,risk_limited=True):
    folder=location(section);base,start,finish=dates(section);epoch=base//MINUTE;start//=MINUTE;finish//=MINUTE;fee=.0005;slip=.001 if db.stress else .0005
    if any(v['rule'].startswith('limit_') for v in configurations):raise ValueError('multirule passive portfolio requires resting-order reservation model')
    rates_and_prices={i:np.load(folder/(s+'-1.npy'),mmap_mode='r') for i,s in enumerate(COINS)}
    metadata=json.loads(Path('ins.json').read_text())['data'];ticks={i:float(next(r['tickSz'] for r in metadata if r['instId']==s+'-USDT-SWAP')) for i,s in enumerate(COINS)}
    if section=='recent':legacy_file=CACHE/'old_recent_stress.pkl' if db.stress else Path('timing_cache/opportunities.pkl')
    elif section=='development':legacy_file=CACHE/'old_development.pkl'
    else:legacy_file=CACHE/'old_earlier.pkl'
    sides={}
    if any(v['rule'] in OLD for v in configurations):
        z=pd.read_pickle(legacy_file);sides={(int(r.entry)//MINUTE,r.rule,r.symbol):int(r.side) for r in z.drop_duplicates(['entry','rule','symbol']).itertuples()}
    events=collections.defaultdict(list)
    for cfg in configurations:
        rule=cfg['rule'];rows=(model_groups[cfg['side'],cfg['hold'],cfg['model'],cfg['level']] if rule.startswith('indicator_model') else db.groups[db.key(cfg)])
        for sig,t,xt,coin,price,risk,net in rows:
            if not np.isfinite(net):continue
            sig,t,xt,coin=map(int,(sig,t,xt,coin));width=(cfg['end']-cfg['start'])%24
            if sig<start or t>=finish-cfg['hold'] or xt>finish or any((((v+540)//60)%24-cfg['start'])%24>=width for v in (t,sig)):continue
            side=sides[(sig,rule,COINS[coin])] if rule in OLD else (1 if rule.endswith('_long') else -1)
            events[t].append((rule not in m.RESERVED,rule,sig,coin,price,risk,net,xt,side,cfg['cap']))
    cash=peak=150.;dd=0.;pos={};days=collections.Counter();ledger=[];max_open=0
    def equity(t,field):return cash+sum(p['notional']*p['side']*(rates_and_prices[p['coin']][t-epoch,field]/p['price']-1) for p in pos.values())
    for t in range(start,finish+1):
        for k,p in list(pos.items()):
            if p['exit']==t:
                pnl=p['notional']*p['net'];cash+=pnl-p['booked']
                ledger.append(dict(rule=k,symbol=COINS[p['coin']],side=p['side'],entry=p['time'],exit=t,entry_price=p['price'],net_usdt=pnl,
                                   notional=p['notional'],margin=p['margin'],leverage=p['leverage'],seed=p['seed'],
                                   stop_distance=p['risk']/p['price'],funding=p['funding'],binding=p['binding']))
                del pos[k]
        if t==finish:break
        for p in pos.values():
            bar=rates_and_prices[p['coin']][t-epoch]
            if t>p['time'] and bar[5]!=0:
                amt=-p['side']*p['notional']*bar[0]/p['price']*bar[5];cash+=amt;p['booked']+=amt;p['funding']+=amt
        for _,k,sig,coin,price,dist,net,xt,side,cap in sorted(events.get(t,())):
            day=(t+(540 if k not in OLD or k in sc.SPECS else 0))//1440
            if k in pos or any(p['coin']==coin for p in pos.values()) or days[day,k]>=cap:continue
            if len(pos)>=10 or (k in m.RESERVED and m.RESERVED.intersection(pos)) or (k not in m.RESERVED and sum(x not in m.RESERVED for x in pos)>=9):continue
            eq=max(0.,equity(t,0)-3);lev=5 if k in m.RESERVED else 10;open_risk=0.;margin=0.
            for p in pos.values():
                mark=rates_and_prices[p['coin']][t-epoch,0];margin+=p['margin'];open_risk+=p['notional']/p['price']*(max(0,(mark-p['stop'])*p['side'])+2*(fee+slip)*mark)
            nominal=eq*margin_cap*lev
            binding='margin_cap'
            if risk_limited:
                risk_budget=min(.005*eq,max(0.,.02*eq-open_risk))
                risk_notional=risk_budget/(dist+2*(fee+slip))
                if risk_notional<nominal:
                    nominal=risk_notional
                    binding='trade_stop_budget' if risk_budget==.005*eq else 'portfolio_stop_budget'
            ct,lot,mn,mx=CONTRACTS[coin];qty=math.floor(nominal/(ct*price*lot)+1e-12)*lot
            if qty<mn or qty>mx:continue
            nominal=qty*ct*price
            if nominal/lev+nominal*fee>eq-margin:continue
            cost=-nominal*fee;cash+=cost;days[day,k]+=1;pos[k]=dict(coin=coin,side=side,time=t,exit=xt,price=price,risk=dist*price,stop=price-side*dist*price,notional=nominal,margin=nominal/lev,net=net,booked=cost,funding=0.,seed=eq,leverage=lev,binding=binding);max_open=max(len(pos),max_open)
        for p in pos.values():
            bar=rates_and_prices[p['coin']][t-epoch];side=p['side'];fav=bar[3] if db.stress else bar[1] if side==1 else bar[2]
            if side*(fav-p['price'])>=p['risk']:
                tick=ticks[p['coin']];raw=(fav-side*p['risk'])/tick;level=(math.floor(raw+1.e-10) if side==1 else math.ceil(raw-1.e-10))*tick
                if side*(level-p['stop'])>0:p['stop']=level
        eq=equity(t,3);peak=max(peak,eq);dd=max(dd,1-eq/peak)
    assert not pos and abs(cash-150-sum(r['net_usdt'] for r in ledger))<1.e-6
    return dict(final=float(cash),net_pct=float(100*(cash/150-1)),trades=len(ledger),wins=sum(bool(r['net_usdt']>0) for r in ledger),max_close_dd_pct=float(dd*100),max_open=max_open,ledger=ledger)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('section');ap.add_argument('--stress',action='store_true');args=ap.parse_args();db=Events(args.section,args.stress);rules=json.loads((CACHE/'frozen_target.json').read_text())['frozen'];rules.update(json.loads((CACHE/'frozen_limit.json').read_text())['frozen']);model=json.loads((CACHE/'frozen_model.json').read_text())['frozen'];rules.update(model);cfg=[r['config'] for r in rules.values() if r['prequalified']];groups=None
    if any(c['rule'].startswith('indicator_model') for c in cfg):
        groups=pd.read_pickle(location(args.section)/('meta-stress-groups.pkl' if args.stress else 'meta-groups.pkl'))[0]
    out=replay(db,cfg,args.section,groups);(CACHE/(args.section+('-stress' if args.stress else '')+'-portfolio.json')).write_text(json.dumps(out,indent=2));print('prequalified portfolio',[(c['rule']) for c in cfg],{k:v for k,v in out.items() if k!='ledger'})

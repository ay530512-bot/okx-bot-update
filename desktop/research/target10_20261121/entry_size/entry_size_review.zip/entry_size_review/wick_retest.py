"""Compare a single causal retest with the deployed higher-low signal, holding schedule and costs fixed."""
import json
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path.cwd() / "target_research"))
from inputs import COINS, MINUTE, dates, location
from evaluate import CONTRACTS, Events, PLAN, limits
from replay import fill_path, sc, timing

ROUTE = "scalp_higher"
FEE = SLIP = 0.0005
WINDOW = timing.policies()[ROUTE]


def in_window(t):
    hour = (t + 540) // 60 % 24
    return WINDOW["start"] <= hour < WINDOW["end"]


def after_retest(bars, index, level, second_low, reference, atr):
    # Only completed one-minute candles can confirm a retest. Fill at the subsequent open.
    for j in range(index, index + 5):
        op, _, low, close = bars[j, :4]
        if not np.isfinite(close) or low < second_low:
            return j + 1, None
        if low > level + .15 * atr or close < level or close <= op:
            continue
        price = bars[j + 1, 0] * (1 + SLIP)
        if not np.isfinite(price) or abs(price - close) > .5 * atr or price > reference + .5 * atr:
            return j + 1, None
        return j + 1, price
    return index + 5, None


def run(section, blocks, symbols):
    db = Events(section)
    directory = location(section)
    epoch = dates(section)[0] // MINUTE
    prices = {s: np.load(directory / f"{s}-1.npy", mmap_mode="r") for s in COINS}
    funding = {s: {int(i): p[i, 5] for i in np.flatnonzero(p[:, 5])} for s, p in prices.items()}
    file = Path("timing_cache/opportunities.pkl") if section == "recent" else Path("target_cache/old_development.pkl")
    all_rows = pd.read_pickle(file)
    rows = all_rows[(all_rows.rule == ROUTE) & (all_rows.hold == WINDOW["minutes"]) &
                    ((all_rows["mask"] & (1 << timing.FILTERS.index(WINDOW["filter"]))) != 0)]
    # Legacy scanner ranks symbols by relative volume on the original close.
    rows = rows.sort_values(["entry","rv","symbol"], ascending=[True,False,True]).drop_duplicates("entry")
    cases = []
    for row in rows.itertuples():
        t = int(row.entry // MINUTE)
        if not in_window(t):
            continue
        symbol = row.symbol
        bars = prices[symbol]
        i = t - epoch
        if i < 99 or i + 35 >= len(bars):
            continue
        closed = np.column_stack((np.arange(i-99, i)*MINUTE, bars[i-99:i, :5])).tolist()
        pair = sc.higher_pair(closed, len(closed)-1)
        if not pair:
            raise ValueError(f"Stored signal and candle pattern disagree for {symbol} at {t}")
        second = closed[pair[1]]
        atr = sc.atr(closed, len(closed)-1)
        next_i, price = after_retest(bars, i, second[2], second[3], closed[-1][4], atr)
        end_wait = epoch + next_i
        result = None
        if price is not None and price > row.stop and in_window(end_wait):
            instrument = symbols[symbol]
            paths = fill_path(next_i, bars[:, :5], 1, price, row.stop, float(instrument["tickSz"]),
                (WINDOW["minutes"],), funding[symbol], FEE, SLIP, False)
            if paths:
                exit_i, net = paths[WINDOW["minutes"]]
                result = (price, row.stop, net, epoch + exit_i, COINS.index(symbol))
        cases.append((t, end_wait, result))

    output = {}
    for block in blocks:
        start, end = limits(block)
        balance = 150.
        trade_count = wins = 0
        next_free = start
        day_filled = None
        for t, end_wait, sample in cases:
            day = (t + 540) // 1440
            if t < max(start, next_free) or end_wait >= end - WINDOW["minutes"] or day_filled == day:
                continue
            next_free = end_wait
            if sample is None:
                continue
            price, stop, net, exit_t, coin = sample
            ct, lot, minimum, maximum = CONTRACTS[coin]
            seed = balance - 3
            budget = min(seed * .10 * 10, seed * .005 / ((price - stop)/price + 2*(FEE+SLIP)))
            contracts = math.floor(budget / (price * ct * lot) + 1.e-12) * lot
            if not minimum <= contracts <= maximum:
                continue
            pnl = contracts * ct * price * net
            balance += pnl
            trade_count += 1
            wins += int(pnl > 0)
            next_free = exit_t
            day_filled = day
        variants = {}
        for filter_name in ("reclaim", "trend"):
            config = dict(rule=ROUTE, mode=filter_name, hold=WINDOW["minutes"], start=WINDOW["start"], end=WINDOW["end"], cap=1)
            variants[filter_name] = db.evaluate(config, (start,end))
        output[block[0]] = dict(end_exclusive=block[1], immediate=variants["reclaim"], ema20=variants["trend"],
                                retest=dict(trades=trade_count, wins=wins, final=balance, net_pct=(balance/150-1)*100))
    return output


if __name__ == "__main__":
    symbols = {r["instId"].split("-")[0]: r for r in json.loads(Path("ins.json").read_text())["data"]
               if r["instId"].endswith("-USDT-SWAP")}
    results = run("development", [*PLAN["development"], PLAN["selection_validation"]], symbols)
    results.update(run("recent", [PLAN["recent_test"]], symbols))
    Path("entry_size_review/wick.json").write_text(json.dumps(results, indent=2, allow_nan=False)+"\n")
    for start, row in results.items():
        print(start, [(k, v["trades"], round(v["net_pct"],2)) for k,v in row.items() if isinstance(v, dict)])

"""Replay only the observed opportunities. All timestamps are exchange UTC milliseconds."""
import csv
import gzip
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace as Row
from zipfile import ZipFile
from io import StringIO

ROOT=Path(__file__).resolve().parent
FEE=.0005
DAY=86400000
KST=timezone(timedelta(hours=9))
def ts(day):return int(datetime.fromisoformat(day).replace(tzinfo=KST).timestamp()*1000)
def cutoff(stamp):return ((stamp+32400000)//DAY+1)*DAY-32400000-60000
def date(stamp):return datetime.fromtimestamp(stamp/1000,KST).date().isoformat()

with ZipFile(ROOT/'public_replay_inputs.zip') as src:
    def rows(name):
        raw=gzip.decompress(src.read(name))
        return list(csv.DictReader(StringIO(raw.decode('utf-8-sig'))))
    gates=json.loads(src.read('gates.json'))
    meta=json.loads(src.read('instruments.json'))
    raw=rows('events.csv.gz')
    marks={(r['phase'],r['symbol'],int(r['stamp'])):tuple(float(r[k]) for k in ('px','fund_before','fund_fill_minute')) for r in rows('marks.csv.gz')}
fix={(e['symbol'],e['cutoff']):e for e in json.loads((ROOT/'cutoff_prints.json').read_text())}
book=defaultdict(dict)
for r in raw:
    if r['timing'] not in ('direct','retest') or r['trail'] not in ('base','one_6h'):continue
    for k in ('side','signal','fill','exit','lev','hold','mask'):r[k]=int(r[k])
    for k in ('reference','raw','stop','exit_raw','fund'):r[k]=float(r[k])
    book[(r['phase'],r['timing'],r['symbol'],r['side'],r['signal'])][r['trail']]=r
events=[]
for group in book.values():
    r=group.get('one_6h') or group['base']
    # These observed stops finish strictly before their historical time limit.
    assert r['exit']-r['fill']<(r['hold']-1)*60000
    end=cutoff(r['signal'])
    if max(r['signal'],r['fill'])>=end:continue
    if r['exit']>=end:
        replacement=fix[r['symbol'],end]
        r.update(exit=replacement['fill_ms'],exit_raw=replacement['price'],fund=replacement['fund_per_unit'])
        assert date(r['exit'])==date(r['signal'])
    events.append(Row(**r))
events.sort(key=lambda e:(e.signal,e.symbol,e.side))
CASES=('immediate','room','room_cost_floor','room_flow','retest_room')
def qualifies(e,case):
    if (e.timing=='retest')!=(case=='retest_room'):return False
    def has(g):return bool(e.mask & (1<<gates.index(g)))
    if case=='immediate':return True
    if not has('room'):return False
    if case=='room_cost_floor':return abs(e.reference-e.stop)>=.002*e.reference
    if case=='room_flow':return has('dry') or has('turn')
    return True
def components(e,unit,slip):
    ep=e.raw*(1+e.side*slip);xp=e.exit_raw*(1-e.side*slip)
    gross=unit*e.side*(e.exit_raw-e.raw)
    cost=unit*FEE*(ep+xp);skid=unit*slip*(e.exit_raw+e.raw);funding=unit*e.fund
    return gross,cost,skid,funding,gross-cost-skid+funding

def simulate(case,side,a,b):
    balance=150.;peak=150.;dd=0;active=[];ledger=[];daily=defaultdict(float)
    def settle(stamp):
        nonlocal balance,peak,dd
        for pos in sorted(active[:],key=lambda p:p.e.exit):
            e=pos.e
            if e.exit>stamp:break
            gross,fee,slip,fund,net=components(e,pos.units,FEE)
            stress=components(e,pos.units,2*FEE)[-1]
            balance+=net;peak=max(peak,balance);dd=max(dd,100*(1-balance/peak))
            daily[date(e.exit)]+=net
            ledger.append(dict(symbol=e.symbol,side=e.side,signal=e.signal,fill=e.fill,exit=e.exit,
                        units=pos.units,contracts=pos.contracts,margin=pos.margin,initial_risk=pos.risk,
                        gross=gross,fees=fee,slippage=slip,funding=fund,net=net,stress=stress,balance=balance))
            active.remove(pos)
    for e in events:
        if not (a<=e.signal<b) or (side and e.side!=side) or not qualifies(e,case):continue
        settle(e.signal)
        if len(active)>=3 or any(p.e.symbol==e.symbol for p in active):continue
        eq=balance;reserved_risk=reserved_margin=0.
        for p in active:
            old=p.e;reserved_risk+=p.risk;reserved_margin+=p.margin
            if e.signal<=old.fill:eq-=p.units*p.entry*.002;continue
            close,acc,_=marks[old.phase,old.symbol,e.signal];base=marks[old.phase,old.symbol,old.fill][2]
            fund=-old.side*(acc-base) if (e.signal-1)//60000>old.fill//60000 else 0.
            xp=close*(1-old.side*FEE)
            eq+=p.units*(old.side*(xp-p.entry)-FEE*(xp+p.entry)+fund)
        seed=eq-3;target=seed/3
        if seed<=0:continue
        ct,lot,minimum,maximum=meta[e.symbol];ref=e.reference*(1+e.side*FEE);ep=e.raw*(1+e.side*FEE)
        qty=math.floor(target/(1/e.lev+FEE)/(ref*ct*lot)+1e-12)*lot
        notional=qty*ct*ref
        if qty<minimum or qty>maximum or notional/e.lev<target*.97:continue
        risk=notional*(max(0.,e.side*(ref-e.stop)/ref)+.002)
        if risk>min(.005*seed,.02*seed-reserved_risk)+1e-10 or notional*(1/e.lev+FEE)>seed-reserved_margin+1e-8:continue
        units=qty*ct
        active.append(Row(e=e,units=units,contracts=qty,entry=ep,margin=units*ep/e.lev,risk=units*(max(0.,e.side*(ep-e.stop))+.002*ep)))
    settle(b);assert not active
    by_sym=defaultdict(float)
    for r in ledger:by_sym[r['symbol']]+=r['net']
    net=balance-150;daily_eq=150.;target_days=0;outcomes=[]
    for t in range(a,b,DAY):
        d=date(t);pnl=daily[d];ret=100*pnl/daily_eq;daily_eq+=pnl
        target_days+=int(5<=ret<=10)
        outcomes.append(dict(day=d,net=pnl,equity=daily_eq,return_pct=ret))
    assert abs(daily_eq-balance)<1e-8
    hi=max([0.]+[r['net'] for r in ledger])
    return dict(trades=len(ledger),wins=sum(r['net']>0 for r in ledger),days=len({date(r['fill']) for r in ledger}),
                equity=balance,net=net,realized_mdd_pct=dd,net_less_best=net-hi,
                net_less_best_symbol=net-max([0.]+list(by_sym.values())),same_qty_stress=sum(r['stress'] for r in ledger),
                target_days=target_days,calendar_days=(b-a)//DAY),ledger,outcomes

def write_csv(path,items):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=items[0]);w.writeheader();w.writerows(items)
def run():
    spans={'front':('2026-09-22','2026-10-22'),'back':('2026-10-22','2026-11-21'),
           'full':('2026-09-22','2026-11-21'),'nov21':('2026-11-21','2026-11-22')}
    results=[];books=[];daily=[];pairs=[]
    for span,(a,b) in spans.items():
        start,end=ts(a),ts(b)
        for scope,direction in [('shared',0),('long',1),('short',-1)]:
            for case in CASES:
                info,ledger,days=simulate(case,direction,start,end)
                k=dict(period=span,scope=scope,case=case)
                results.append({**k,**info})
                if span in ('full','nov21'):
                    books.extend({**k,**r} for r in ledger)
                    daily.extend({**k,**r} for r in days)
            if scope!='shared':continue
            _,base,_=simulate('immediate',0,start,end)
            for case in CASES:
                kept=[]
                for trade in base:
                    matching=[e for e in events if e.symbol==trade['symbol'] and e.side==trade['side'] and qualifies(e,case) and
                        (0<=e.signal-trade['signal']<=30000 if case=='retest_room' else e.signal==trade['signal'])]
                    assert len(matching)<=1
                    if not matching:continue
                    e=matching[0];u=trade['units'];ref=e.reference*(1+e.side*FEE)
                    # Identical contracts; never allow greater projected loss than the original planned trade.
                    if case=='retest_room' and (max(0.,e.side*(ref-e.stop))+.002*ref)*u > trade['initial_risk']+1e-8:continue
                    kept.append(components(e,u,FEE)[-1])
                pairs.append(dict(period=span,case=case,original_fills=len(base),kept=len(kept),same_qty_net=sum(kept)))
    write_csv(ROOT/'accounts.csv',results);write_csv(ROOT/'paired.csv',pairs)
    for filename,data in [('ledger.csv.gz',books),('daily.csv.gz',daily)]:
        with gzip.open(ROOT/filename,'wt',newline='') as f:
            w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
    for r in results:
        if r['scope']=='shared' and r['period'] in ('front','back','full','nov21'):
            print(r['period'],r['case'],r['trades'],r['wins'],round(r['equity'],3),round(r['same_qty_stress'],3),r['target_days'])
if __name__=='__main__':run()

"""Whole-position forward replay from ordered marks and trades, with externally audited stream coverage."""
from bisect import bisect_left, bisect_right
from math import isfinite
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from market_inputs import close_time

def replay(side, reaction_ms, stop, tick, trades, marks, coverage_end_ms, *, slip=.0005, fee=.0005, funding=()):
    """trades=(ms,trade_id,price), marks=(ms,mark), funding=(settlement_ms,rate,mark).
    Supply gap-checked streams through coverage_end_ms. Missing coverage is not a settled trade.
    """
    if side not in (-1,1) or not all(isfinite(x) and x>0 for x in (tick,stop)):
        raise ValueError('invalid side or price')
    cut=close_time(reaction_ms)
    if reaction_ms>=cut:return {'status':'entry_window_closed'}
    if any((a[0],a[1])>=(b[0],b[1]) for a,b in zip(trades,trades[1:])) or any(a[0]>b[0] for a,b in zip(marks,marks[1:])):
        raise ValueError('unordered input')
    stamps=[t[0] for t in trades]
    i=bisect_right(stamps,reaction_ms)
    if i==len(trades) or stamps[i]>coverage_end_ms:return {'status':'missing_entry_coverage'}
    at,_,raw=trades[i]
    if at>=cut or at-reaction_ms>60000:return {'status':'no_timely_entry'}
    ep=raw*(1+side*slip);risk=side*(ep-stop);active=stop;trigger=cut;reason='day_close'
    if risk<=0:
        trigger=at;reason='invalid_fill'
    else:
        rounding=ROUND_FLOOR if side==1 else ROUND_CEILING
        step=Decimal(str(tick))
        for ms,mark in marks:
            if ms<=at:continue
            if ms>=cut or ms>coverage_end_ms:break
            if side*(mark-active)<=0:
                trigger=ms;reason='initial' if active==stop else 'trail';break
            if side*(mark-ep)>=risk:
                candidate=float((Decimal(str(mark-side*risk))/step).to_integral_value(rounding=rounding)*step)
                if side*(candidate-active)>0:active=candidate
    j=bisect_left(stamps,trigger) if reason=='day_close' else bisect_right(stamps,trigger)
    if j>=len(stamps) or stamps[j]>coverage_end_ms:
        return {'status':'open_or_missing_exit_coverage','fill_ms':at,'stop':active}
    end,_,out=trades[j];xp=out*(1-side*slip)
    carry=-side*sum(rate*mark for ms,rate,mark in funding if at<ms<=end)
    return dict(status='closed',reason=reason,fill_ms=at,exit_ms=end,entry_raw=raw,exit_raw=out,
                gross_per_unit=side*(out-raw),fees_per_unit=fee*(ep+xp),slippage_per_unit=slip*(raw+out),
                funding_per_unit=carry,net_per_unit=side*(xp-ep)-fee*(ep+xp)+carry)

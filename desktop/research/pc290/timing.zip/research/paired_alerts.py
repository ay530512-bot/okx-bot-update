"""Replay a further touch on the ten observed alerts using the original raw-print/mark audit."""
import json
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from market_inputs import ROOT, STEP, get

def run(signal_root):
    sys.path.insert(0,str(signal_root.resolve()))
    from analyze import protect  # Original 5x audit. Require a protective exit before any time limit.
    from points import next_tick
    a=json.loads((signal_root/'cache/analysis.json').read_text())
    points=json.loads((signal_root/'cache/points.json').read_text())
    def one(o):
        sym=o['sym'];side=o['side'];event=points[sym]['signal']['trade'];t,tid,entry=event
        data=json.loads((signal_root/'cache'/f'{sym}-core.json').read_text())
        _,_,_,_,first,second,*_=data['signal']
        first=side*float(first);second=side*float(second);tick=o['tick'];eps=tick*1e-6
        previous=side*entry;tested=False;last=tid;reaction=None
        marks={int(k):v for k,v in json.loads((signal_root/'cache'/f'{sym}-mark.json').read_text()).items()}
        direct_t,_,direct_px=next_tick(sym,t+1)
        assert t<direct_t<=t+60000
        direct=protect(sym,direct_px,direct_t,side,o['stop'],tick,marks,o['funding'])
        assert direct['reason'] in ('initial','trail')
        out=dict(symbol=sym,original_roe=o['protect']['roe'],direct_roe=direct['roe'],
                 direct_fill_ms=direct_t,direct_fill_px=direct_px,direct_exit_ms=direct['fill_time'],
                 status='window_elapsed')
        limit=min(t+30000,((t//STEP)+1)*STEP-1)
        while True:
            page=get('market/history-trades',instId=sym+'-USDT-SWAP',type=1,after=last+101,limit=100)
            rr=sorted((int(r['tradeId']),int(r['ts']),float(r['px'])) for r in page if int(r['tradeId'])>last)
            assert rr and rr[0][0]==last+1,(sym,last)
            for i,ts,p in rr:
                assert i==last+1;last=i
                if reaction is not None:
                    if ts<=reaction:continue
                    if ts-reaction>60000:return dict(out,status='no_timely_fill')
                    risk=side*(p*(1+side*.0005)-o['stop'])
                    if risk<=0:return dict(out,status='fill_beyond_stop')
                    exit=protect(sym,p,ts,side,o['stop'],tick,marks,o['funding'])
                    assert exit['reason'] in ('initial','trail'),(sym,exit)
                    return dict(out,status='filled',reaction_ms=reaction,fill_ms=ts,fill_px=p,
                                exit_ms=exit['fill_time'],exit=exit['reason'],retest_roe=exit['roe'],
                                same_qty_roe_on_direct_margin=exit['roe']*p/direct_px)
                if ts>limit:return out
                px=side*p
                if px<=first+eps:return dict(out,status='first_wick_broken')
                if abs(px-previous)<eps:continue
                if px<=second+eps:tested=True
                if tested and px>=previous+tick-eps:
                    if px>side*entry+eps:return dict(out,status='higher_cost_chase')
                    reaction=ts
                previous=px
    with ThreadPoolExecutor(4) as pool:return list(pool.map(one,a))
if __name__=='__main__':
    result=run(Path(sys.argv[1]));(ROOT/'paired_alerts.json').write_text(json.dumps(result,indent=2)+'\n')
    print([(r['symbol'],r['status'],round(r.get('retest_roe',0),2)) for r in result])

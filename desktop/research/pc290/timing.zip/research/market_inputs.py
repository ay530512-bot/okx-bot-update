"""Collect only public OKX data. See README for local research inputs."""
import csv
import gzip
import hashlib
import json
import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
STEP = 900_000
MINUTE = 60_000
DAY = 86_400_000
OFFSET = 32_400_000
LOCK = threading.Lock()
next_request = 0.

def close_time(ts):
    return ((ts + OFFSET) // DAY + 1) * DAY - OFFSET - MINUTE

def get(route, **params):
    global next_request
    url = 'https://www.okx.com/api/v5/' + route + '?' + urlencode(sorted(params.items()))
    cache = ROOT.parent / 'public' / (hashlib.sha256(url.encode()).hexdigest() + '.json')
    if cache.is_file():
        return json.loads(cache.read_text())['data']
    cache.parent.mkdir(exist_ok=True)
    for attempt in range(6):
        with LOCK:
            time.sleep(max(0, next_request - time.monotonic()))
            next_request = time.monotonic() + .16
        try:
            request = Request(url, headers={'User-Agent':'Mozilla/5.0 (intraday public research)'})
            with urlopen(request, timeout=15) as response: data = json.load(response)
            if data['code'] != '0': raise ValueError(data.get('msg'))
            cache.write_text(json.dumps(data, separators=(',',':')))
            return data['data']
        except (OSError, ValueError):
            if attempt == 5: raise
            time.sleep(1 + attempt)

def trades_before(inst, ts):
    return get('market/history-trades', instId=inst,type=2,after=ts,limit=100)

def past_minute(inst, end):
    page = trades_before(inst,end)
    assert page and all(int(x['ts']) < end for x in page)
    rows = list(page)
    while len(page) == 100 and int(rows[-1]['ts']) >= end - MINUTE:
        page = get('market/history-trades',instId=inst,type=1,after=rows[-1]['tradeId'],limit=100)
        if page:
            assert int(page[0]['tradeId']) < int(rows[-1]['tradeId'])
        rows.extend(page)
    assert rows and (int(rows[-1]['ts']) < end-MINUTE or len(page)<100)
    return [r for r in rows if end-MINUTE<=int(r['ts'])<end]

def ten_features(record):
    inst=record['sym']+'-USDT-SWAP'
    t=record['entry_trade_ts']; bar=t//STEP*STEP; px=record['signal_px']; side=record['side']
    rows=get('market/history-candles',instId=inst,bar='15m',after=bar,limit=25)
    bars={int(r[0]):float(r[4]) for r in rows if r[8]=='1'}
    closes=[bars[x] for x in range(bar-20*STEP,bar,STEP)]
    stop=record['stop']; risk=abs(px-stop); room=side*(sum(closes)/20-px)
    end=t//10000*10000; prints=past_minute(inst,end)
    def flow(lo,hi):
        rr=[r for r in prints if lo<=int(r['ts'])<hi]
        values=[float(r['px'])*float(r['sz']) for r in rr]; same='buy' if side==1 else 'sell'
        total=sum(values)
        return [len(rr), sum(v for r,v in zip(rr,values) if r['side']==same)/total if total else None]
    n1,v1=flow(end-10000,end);n0,v0=flow(end-MINUTE,end-10000)
    return dict(symbol=record['sym'],side=side,signal_ms=t,entry=px,stop=stop,center=sum(closes)/20,
                room_pct=room/px*100,risk_pct=risk/px*100,room=room>=max(.006*px,2*risk),
                cost_floor=risk>=.002*px,window_end=end,n10=n1,n50=n0,same10=v1,same50=v0,
                turn=n0>=5 and n1>=5 and v1>=.52 and v1-v0>=.15,
                exit_ms=record['protect']['fill_time'],net_roe_5x=record['protect']['roe'],exit=record['protect']['reason'],
                later_snapshot_roe=record['end']['roe'],skip=record['skip'])
def close_print(item):
    sym,stamp,early,late=item;inst=sym+'-USDT-SWAP';prior=trades_before(inst,stamp)
    assert prior and int(prior[0]['ts'])<stamp
    prev=int(prior[0]['tradeId'])
    hits=get('market/history-trades',instId=inst,type=1,after=prev+2,limit=1)
    assert hits and int(hits[0]['tradeId'])==prev+1 and int(hits[0]['ts'])>=stamp
    rates=get('public/funding-rate-history',instId=inst,after=late+1,limit=100)
    assert rates and min(int(r['fundingTime']) for r in rates)<=early
    # These four boundary cases have no settlement between entry and the original close.
    assert not any(early<int(r['fundingTime'])<=max(late,int(hits[0]['ts'])) for r in rates)
    return dict(symbol=sym,cutoff=stamp,fill_ms=int(hits[0]['ts']),trade_id=prev+1,
                previous_ms=int(prior[0]['ts']),price=float(hits[0]['px']),fund_per_unit=0.)
def build(prior, alerts):
    with gzip.open(prior/'evidence/events.csv.gz','rt') as f: rows=list(csv.DictReader(f))
    boundaries={}
    for r in rows:
        if r['timing'] not in ('direct','retest') or r['trail'] not in ('base','one_6h'):continue
        ts=int(r['fill']);cut=close_time(int(r['signal']));old=int(r['exit'])
        if ts<cut<=old:
            key=(r['symbol'],cut);lo,hi=boundaries.get(key,(ts,old));boundaries[key]=min(ts,lo),max(old,hi)
    with ThreadPoolExecutor(4) as pool:
        ten=list(pool.map(ten_features,json.loads(alerts.read_text())))
        cutoff=list(pool.map(close_print,[(s,t,a,b) for (s,t),(a,b) in sorted(boundaries.items())]))
    (ROOT/'alert_features.json').write_text(json.dumps(ten,indent=2)+'\n')
    (ROOT/'cutoff_prints.json').write_text(json.dumps(cutoff,indent=2)+'\n')
    print('Captured',len(ten),'alerts and',len(cutoff),'boundary fills',flush=True)
if __name__=='__main__':
    build(Path(sys.argv[1]),Path(sys.argv[2]))

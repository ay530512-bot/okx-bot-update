from data import *
from functools import lru_cache
import bisect

def pack(row):
    return (int(row['ts']),int(row['tradeId']),float(row['px']))

@lru_cache(maxsize=10000)
def preceding(sym,bound):
    items=get('market/history-trades',instId=sym+'-USDT-SWAP',type=2,after=bound,limit=100)
    return sorted((pack(x) for x in items),key=lambda it:it[1])

@lru_cache(maxsize=10000)
def second_tape(sym,sec):
    assert sec%1000==0
    batch=preceding(sym,sec+1000)
    assert batch and batch[-1][0]<sec+1000
    allrows=list(batch)
    while allrows[0][0]>=sec and len(batch)==100:
        batch=sorted((pack(x) for x in get('market/history-trades',instId=sym+'-USDT-SWAP',type=1,after=allrows[0][1],limit=100)),key=lambda it:it[1])
        if not batch:break
        assert batch[-1][1]<allrows[0][1]
        allrows=batch+allrows
    valid=[x for x in allrows if sec<=x[0]<sec+1000]
    return valid

@lru_cache(maxsize=10000)
def next_tick(sym,ts):
    # Find the final print strictly before the order; its immediate successor is the fill proxy.
    a=preceding(sym,ts)
    prior=a[-1]
    assert prior[0]<ts
    inst=sym+'-USDT-SWAP'
    nxt=get('market/history-trades',instId=inst,type=1,after=prior[1]+2,limit=1)
    if nxt:
        pt=pack(nxt[0])
        if pt[1]==prior[1]+1 and pt[0]>=ts:return pt
    for span in [2_000,10_000,60_000,300_000]:
        a=preceding(sym,ts+span)
        if a[-1][0]<ts:continue
        if a[0][0]>=ts:
            seek=a[0][1]
            for j in range(200):
                page=sorted((pack(x) for x in get('market/history-trades',instId=inst,type=1,after=seek,limit=100)),key=lambda it:it[1])
                if not page:break
                a=list(page)+a
                if a[0][0]<ts:break
                seek=a[0][1]
        assert a[0][0]<ts
        return next(row for row in a if row[0]>=ts)
    raise ValueError((sym,ts,'no price in 5 minutes'))

def work(x):
    sym,label,t,ref=x
    if label=='signal':
        rows=second_tape(sym,t)
        exact=[p for p in rows if abs(p[2]-ref)<ref*1e-10]
        assert exact,(sym,t,ref,rows)
        return (sym,label,t,exact[0],len(exact))
    return (sym,label,t,next_tick(sym,t),1)

if __name__=='__main__':
    jobs=[]
    for sym,s,when,anchor,first,second,ref,reason in INPUT:
        t=at(when)
        for label,q in [('signal',t),('entry',t+1000),('delay5',t+5000),('m5',t+5*M),('m15',t+15*M),('m30',t+30*M),('end',END)]:
            jobs.append((sym,label,q,float(ref)))
    rows={}
    with ThreadPoolExecutor(10) as pool:
        for sym,name,stamp,trade,count in pool.map(work,jobs):
            rows.setdefault(sym,{})[name]=dict(request=stamp,trade=trade,count=count)
            if name=='end':print('verified alert and subsequent timestamps',sym,flush=True)
    (CACHE/'points.json').write_text(json.dumps(rows))

from datetime import datetime,timedelta,timezone
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import threading
import time
import urllib.parse
import urllib.request

HERE=Path(__file__).resolve().parent
CACHE=HERE/'cache'
CACHE.mkdir(exist_ok=True)
KST=timezone(timedelta(hours=9))
def at(hms):
    return int(datetime.fromisoformat('2026-11-22T'+hms).replace(tzinfo=KST).timestamp()*1000)
def clock(ts):
    return datetime.fromtimestamp(ts/1000,KST).strftime('%H:%M:%S')
END=at('16:50:00')
M=60000
INPUT=[
 ('DGAI',-1,'08:47:10','08:15:00','0.8148','0.8123','0.8121','risk'),
 ('PNUT',-1,'08:49:06','08:30:00','0.02617','0.02615','0.02614','spread'),
 ('RAVE',1,'11:39:06','11:15:00','0.1107','0.1109','0.1110','risk'),
 ('AKE',1,'12:25:15','12:00:00','0.003110','0.003160','0.003185','risk'),
 ('ALLO',1,'12:35:53','12:15:00','0.12058','0.12061','0.12063','spread'),
 ('JELLYJELLY',1,'12:52:10','12:30:00','0.03597','0.03600','0.03605','risk'),
 ('AI',-1,'13:31:30','13:15:00','0.01524','0.01517','0.01516','risk'),
 ('CT',1,'14:35:15','14:15:00','0.12750','0.12775','0.12776','risk'),
 ('CP',-1,'16:03:02','15:45:00','0.006311','0.006298','0.006297','stale'),
 ('ZRO',1,'16:16:03','14:15:00','1.1502','1.1521','1.1523','stale')]
API='https://www.okx.com/api/v5/'
def get(route,**params):
    query=urllib.parse.urlencode(sorted(params.items()))
    key=hashlib.sha256((route+'?'+query).encode()).hexdigest()[:20]
    dest=CACHE/(route.rsplit('/',1)[-1]+'-'+params.get('instId','OKX')+'-'+key+'.json')
    if dest.exists():return json.loads(dest.read_text())['data']
    delay=0.65
    for attempt in range(6):
        try:
            rq=urllib.request.Request(API+route+'?'+query,headers={'User-Agent':'Mozilla/5.0 (historical signal analysis)'})
            with urllib.request.urlopen(rq,timeout=18) as result:
                doc=json.load(result)
            if doc['code']!='0':raise ValueError((doc['code'],doc['msg']))
            tmp=dest.with_suffix('.'+str(threading.get_ident())+'.tmp')
            tmp.write_text(json.dumps(doc,separators=(',',':')));tmp.replace(dest)
            return doc['data']
        except Exception:
            if attempt==5:raise
            time.sleep(delay);delay*=1.7

def pricebars(inst,bar,first,last,route='market/history-candles'):
    # OKX returns newest to oldest, with start timestamps strictly before after.
    cursor=last+1
    rows={}
    while cursor>first:
        rr=get(route,instId=inst,bar=bar,after=cursor,limit=300 if route.endswith('history-candles') else 100)
        if not rr:break
        for r in rr:
            if r[-1]=='1': rows[int(r[0])]=list(map(float,r[1:5]))
        oldest=min(int(x[0]) for x in rr)
        if oldest>=cursor:raise ValueError('candle cursor stalled')
        cursor=oldest
    return {k:v for k,v in rows.items() if first<=k<=last}

def core(e):
    sym,s,when,a,*_=e;t=at(when);anchor=at(a);inst=sym+'-USDT-SWAP'
    flo=t//M*M
    bundle={}
    def candles():
        bars=pricebars(inst,'1m',flo-M,END+M)
        required=set(range(flo-M,END+M,M))
        if required-bars.keys():raise ValueError((sym,'missing minute',len(required-bars.keys())))
        return bars
    def atrbars():
        bars=pricebars(inst,'15m',anchor-15*15*M,anchor)
        assert set(range(anchor-15*15*M,anchor+1,15*M))<=bars.keys()
        return bars
    def metadata():
        r=get('public/instruments',instType='SWAP',instId=inst)
        assert len(r)==1 and r[0]['instId']==inst
        return {k:r[0][k] for k in ['instId','tickSz','ctVal','lotSz']}
    def funding():
        rates=get('public/funding-rate-history',instId=inst,after=END+1,limit=10)
        needed=[(int(r['fundingTime']),float(r['realizedRate'] or r['fundingRate'])) for r in rates if t<int(r['fundingTime'])<=END]
        amounts=[]
        for ts,rate in sorted(needed):
            marks=pricebars(inst,'1m',ts,ts,'market/history-mark-price-candles')
            assert ts in marks
            amounts.append((ts,rate,marks[ts][0]))
        assert rates and min(int(r['fundingTime']) for r in rates)<=t
        return amounts
    for key,fn in [('bars',candles),('atrbars',atrbars),('instrument',metadata),('funding',funding)]:
        bundle[key]=fn()
    bundle['signal']=e
    (CACHE/(sym+'-core.json')).write_text(json.dumps(bundle,separators=(',',':')))
    print('verified market inputs',sym,len(bundle['bars']),len(bundle['funding']),flush=True)

if __name__=='__main__':
    with ThreadPoolExecutor(8) as pool:list(pool.map(core,INPUT))

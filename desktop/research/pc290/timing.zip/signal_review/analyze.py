from data import *
from points import next_tick,preceding,second_tape
from decimal import Decimal,ROUND_FLOOR,ROUND_CEILING
from functools import lru_cache

FEE=0.0005
SLIP=0.0005
LEV=5
def rounded(value,tick,side):
    p=Decimal(str(value));step=Decimal(str(tick))
    return float((p/step).to_integral_value(rounding=ROUND_FLOOR if side==1 else ROUND_CEILING)*step)

def roe(side,p0,entry_ms,p1,exit_ms,funding):
    entry=p0*(1+side*SLIP);exit=p1*(1-side*SLIP)
    carry=-side*sum(rate*mark for tm,rate,mark in funding if entry_ms<tm<=exit_ms)
    return 100*LEV*(side*(exit-entry)-FEE*(entry+exit)+carry)/entry

@lru_cache(maxsize=4000)
def seconds(sym,kind,m):
    path='market/history-'+('mark-price-' if kind=='mark' else '')+'candles'
    rows=get(path,instId=sym+'-USDT-SWAP',bar='1s',after=m+M,limit=60)
    arr={int(r[0]):list(map(float,r[1:5]))+([float(r[5])] if kind=='last' else []) for r in rows if r[-1]=='1'}
    assert set(range(m,m+M,1000))==set(arr),(sym,kind,m,len(arr))
    return arr

def first_hard_touch(sym,at_entry,end,side,stop,mb):
    # Include only fully post-entry OHLC seconds. A touch in the initial fractional
    # second is counted only if its close is already over the boundary.
    start=at_entry//1000*1000
    for m in range(start//M*M,end//M*M+1,M):
        if m>=end:break
        O,H,L,C=mb[m]
        if side*(L if side==1 else H)>side*stop+1e-12:continue
        for k,row in sorted(seconds(sym,'mark',m).items()):
            if k+1000<=at_entry or k+1000>end:continue
            adverse=row[2 if side==1 else 1] if k>=at_entry else row[3]
            if side*(adverse-stop)<=1e-12:return k+1000
    return None

def protect(sym,raw,entry_ms,side,stop,tick,mb,funding):
    price=raw*(1+side*SLIP);risk=side*(price-stop)
    assert risk>0 and tick>0
    deadline=min(END,entry_ms+6*3600000);active=stop
    def candidate(px):
        if side*(px-price)<risk:return active
        p=rounded(px-side*risk,tick,side)
        return max(active,p) if side==1 else min(active,p)
    for m in range(entry_ms//M*M,deadline//M*M+1,M):
        if m>=deadline:break
        oo,hi,lo,cc=mb[m]
        best=hi if side==1 else lo;worst=lo if side==1 else hi
        if side*(candidate(best)-active)<=1e-12 and side*(worst-active)>1e-12:continue
        for k,row in sorted(seconds(sym,'mark',m).items()):
            stamp=k+1000
            if stamp<=entry_ms or stamp>deadline:continue
            # At the start of this second the previous stop already exists on the exchange.
            # While protection is running, raises are modeled at each second's close.
            bad=row[2 if side==1 else 1] if k>=entry_ms else row[3]
            if side*(bad-active)<=1e-12:
                px=next_tick(sym,stamp)
                return dict(reason='initial' if abs(active-stop)<tick*1e-5 else 'trail',trigger=stamp,
                            fill_time=px[0],fill_raw=px[2],active=active,roe=roe(side,raw,entry_ms,px[2],px[0],funding))
            active=candidate(row[3])
    if deadline<END:
        px=next_tick(sym,deadline)
        return dict(reason='six_hours',trigger=deadline,fill_time=px[0],fill_raw=px[2],active=active,roe=roe(side,raw,entry_ms,px[2],px[0],funding))
    last=preceding(sym,END+1)[-1]
    return dict(reason='open',trigger=END,fill_time=last[0],fill_raw=last[2],active=active,roe=roe(side,raw,entry_ms,last[2],END,funding))

def run(e):
    sym,side,when,anchor,first,second,ref,skip=e;raw=float(ref);t=at(when)
    z=json.loads((CACHE/(sym+'-core.json')).read_text())
    point=json.loads((CACHE/'points.json').read_text())[sym]
    entry=tuple(point['signal']['trade']);assert entry[2]==raw and t<=entry[0]<t+1000
    delayed=point['entry']['trade']
    mb={int(k):v for k,v in json.loads((CACHE/(sym+'-mark.json')).read_text()).items()}
    ab={int(k):v for k,v in z['atrbars'].items()};anc=at(anchor)
    assert abs(ab[anc][2 if side==1 else 1]-float(first))<=float(z['instrument']['tickSz'])*1e-6
    tr=[]
    for k in range(anc-13*15*M,anc+1,15*M):
        op,hi,lo,cl=ab[k];prev=ab[k-15*M][3]
        tr.append(max(hi-lo,abs(hi-prev),abs(lo-prev)))
    tick=float(z['instrument']['tickSz']);atr=sum(tr)/14
    stop=rounded(float(first)-side*max(.15*atr,2*tick),tick,side)
    f=z['funding']
    out=dict(sym=sym,side=side,time=when,skip=skip,signal_px=raw,tick=tick,atr=atr,stop=stop,
             entry_trade_ts=entry[0],found_in_second=point['signal']['count'],delayed_entry=delayed, funding=f)
    for label in ['m5','m15','m30','end']:
        cutoff=point[label]['request'];first_after=point[label]['trade']
        # Last actually observed print at the cutoff. Never use a subsequent print.
        last=preceding(sym,cutoff+1 if first_after[0]==cutoff else cutoff)[-1]
        assert last[0]<=cutoff
        out[label]=dict(timestamp=cutoff,raw=last[2],last_print=last[0],age_sec=(cutoff-last[0])/1000,
            roe=roe(side,raw,entry[0],last[2],cutoff,f),delayed_roe=roe(side,delayed[2],delayed[0],last[2],cutoff,f),
            price_change=side*(last[2]/raw-1)*100)
    out['protect']=protect(sym,raw,entry[0],side,stop,tick,mb,f)
    h=first_hard_touch(sym,entry[0],END,side,stop,mb)
    out['hard_touch']=h
    if h:
        fill=next_tick(sym,h)
        out['fixed_exit']=dict(when=h,fill_time=fill[0],raw=fill[2],roe=roe(side,raw,entry[0],fill[2],fill[0],f))
    else:out['fixed_exit']=dict(when=END,fill_time=out['end']['last_print'],raw=out['end']['raw'],roe=out['end']['roe'])
    (CACHE/(sym+'-analysis.json')).write_text(json.dumps(out,indent=2))
    print(sym,'15/30/end/guard',*[round(out[k]['roe'],2) for k in ['m15','m30','end','protect']],out['protect']['reason'],flush=True)
    return out

if __name__=='__main__':
    with ThreadPoolExecutor(8) as pool:output=list(pool.map(run,INPUT))
    (CACHE/'analysis.json').write_text(json.dumps(output,indent=2))

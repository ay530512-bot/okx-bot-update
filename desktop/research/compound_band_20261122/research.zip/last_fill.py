"""Resolve the newest archive-unpublished day using only OHLC-safe skips and verified OKX trades."""
import json
import math
import os
import pickle
from pathlib import Path
import numpy as np
import pandas as pd
from events import ROOT,CACHE,STUDY,SYMS,M,DAY,END,BASE,Market,EXITS,close_bands,preceding_decline_and_pause
from last_scan import DAYSET,DAYBASE,LAST_END,arrays,indicators,indicator_level,Probe
from prints import Prints

def replay():
    ins={x['instId'].split('-')[0]:x for x in json.loads((DAYSET/'ins.json').read_text())['data'] if x['instId'].endswith('-USDT-SWAP')}
    prefs={int(x['rule']):x for x in json.loads((CACHE/'frozen.json').read_text()) if x['qualified'] and x['size']==1}
    jobs=pickle.loads((CACHE/'day_requirements.pkl').read_bytes())
    allclose=np.stack([arrays(s)[0][:,3] for s in SYMS])
    results=[];tested=[]
    for sym,(setups,scalps) in jobs.items():
        old=Market(sym);new=Prints(sym);one,five,_=arrays(sym);meta=ins[sym];tick=float(meta['tickSz']);mid,std=close_bands(five)
        o,h,l,c,v=five[:,:5].T;prev=pd.Series(c).shift().to_numpy()
        atr=pd.Series(np.maximum.reduce([h-l,abs(h-prev),abs(l-prev)])).rolling(14).mean().to_numpy()
        vol=pd.Series(c*v);turn=(vol.rolling(3).sum()/(vol.shift(3).rolling(12).sum()/4)).to_numpy()
        def minute(k):
            t=DAYBASE+k*M
            if t<END:
                x=(t-BASE)//M;sl=old.p[old.off[x]:old.off[x+1]]
                return sl['ts'],sl['px']
            return new.minute((t-BASE)//M)
        def first(t):
            for k in range((t-DAYBASE)//M,len(one)):
                if not one[k,4]:continue
                times,px=minute(k);i=times.searchsorted(t)
                if i<len(px):return int(k),int(i),int(times[i]),float(px[i])
            raise ValueError((sym,t,'no following trade'))
        def gate(rule,t,quote):
            p=prefs[rule];side=1 if rule in (0,2,4) else -1;j=(t-DAYBASE)//(5*M)-1;k=(t-DAYBASE)//M
            if not END<=t<LAST_END or ((t//3600000+9)%24-p['h'])%24>=p['width']:return False
            if p['gate']==3:return atr[j]/quote>=.006 and turn[j]>=1.25
            if p['gate'] in (1,4):
                target=mid[j] if rule<2 else mid[j]+side*2*std[j]
                if atr[j]/quote<.0035 or side*(target/quote-1)<.005:return False
            if p['gate'] in (2,4):
                tm=DAYBASE+(k-1)*M;minute(k-1)
                paths=[DAYSET/f'cache/minutes/{sym}-{tm}.json',ROOT.parent/f'bb30/cache/{sym}-{tm}.json']
                raw=json.loads(next(f for f in paths if f.is_file()).read_text())
                total=sum(r[2]*r[3] for r in raw);d=side*(allclose[:,k-1]/allclose[:,k-16]-1);d[SYMS.index(sym)]=np.nan;valid=d[np.isfinite(d)]
                return len(raw)>=5 and total>0 and sum(r[2]*r[3] for r in raw if r[4]==('buy' if side==1 else 'sell'))/total>=.58 and len(valid)>=20 and np.mean(valid>0)>=.55
            return True
        signals=[]
        for rule,s,end in setups:
            obs=Probe(s);side=s.side;eps=tick*1e-5;hit=None
            for k in range(s.start,end):
                op,high,low,close,v=one[k,:5]
                if v<=0:continue
                lo,hi=(low,high) if side==1 else (-high,-low)
                if hi<s.lower-eps:break
                if not obs.armed and lo>=s.lower-eps and hi<s.depart-eps:continue
                if lo>s.upper+eps and (obs.bar!=k//5 or not math.isfinite(obs.low)):
                    if not obs.armed and hi>=s.depart-eps:obs.armed=True
                    continue
                times,px=minute(k)
                for index,(t,price) in enumerate(zip(times,px)):
                    extreme=obs.observe(k//5,side*five[k//5,0],side*price,side*price)
                    if extreme is not None:
                        hit=(int(t),float(price),side*extreme,k,index)
                        break
                    if obs.done:break
                if obs.done:break
            if hit:
                t,price,level,k,index=hit
                if not gate(rule,t,price):continue
                if s.family=='reversal':
                    j=k//5;prefix=None
                    if j==s.source+1:prefix=[v for m in range(j*5,k+1) for v in (minute(m)[1][:index+1] if m==k else minute(m)[1])]
                    if not preceding_decline_and_pause(five,mid,std,s.source,j,side,s.atr,observed_prices=prefix)[2]:continue
                signals.append((rule,t,price,side*s.level if s.family=='reversal' else level,s.atr,s.quality,0))
        for j,n,quality in scalps:
            t=DAYBASE+(j+1)*5*M
            if gate(4,t,c[j]):signals.append((4,t,c[j],l[j],atr[j],quality,t+n*5*M))
        for rule,t,quote,anchor,volatility,quality,close_time in signals:
            p=prefs[rule];side=1 if rule in (0,2,4) else -1
            start,i0,fill,raw=first(t if rule==4 else t+1)
            if fill-t>M:continue
            j=(t-DAYBASE)//(M*5)-1;ev=indicators([[0,*x] for x in five[j-31:j+1,:5]],side,atr[j])
            if not ev:continue
            levmax=min(int(float(meta['lever'])),indicator_level(ev),5)
            pad=(.075,.25 if rule in (2,3) else .15,.35)[p['pad']]
            stop=side*math.floor((side*anchor-max(2*tick,pad*volatility))/tick+1e-9)*tick
            lev0=min(levmax,int(math.floor(.015/(side*(quote-stop)/quote+.002)+1e-12)));lev=max(3,lev0)
            pol=EXITS[p['mode']]
            assert pol['type']=='price' and pol['name']!='quick_failure','extend raw price/swing replay for a different frozen model'
            for st,slip in [(False,.0005),(True,.001)]:
                entry=raw*(1+side*slip);expected=quote*(1+side*slip)
                r=side*(entry-stop);live=side*stop;best=side*raw;exit_t=None
                deadline=close_time if rule==4 else fill+pol['minutes'][0 if rule<2 else 1 if rule==2 else 2]*M
                def raise_stop(x,lvl):
                    return max(lvl,math.floor((x-pol['gap_r']*r)/tick+1e-10)*tick) if x-side*entry>=pol['arm_r']*r else lvl
                if r<=0:_,_,exit_t,exit_raw=first(fill+1)
                for k in range(start,(deadline-DAYBASE)//M+1):
                    if exit_t is not None:break
                    if not one[k,4]:continue
                    best_possible=max(best,side*one[k,1 if side==1 else 2]);raised=raise_stop(best_possible,live)
                    if k!=start and DAYBASE+(k+1)*M<=deadline and side*one[k,2 if side==1 else 1]>raised:
                        best=best_possible;live=raised;continue
                    ts,px=minute(k);a=i0+1 if k==start else 0
                    for clock,px0 in zip(ts[a:],px[a:]):
                        if clock>=deadline:exit_t=int(clock);exit_raw=float(px0);break
                        if side*px0<=live:
                            _,_,exit_t,exit_raw=first(int(clock)+1);break
                        best=max(best,side*px0);live=raise_stop(best,live)
                if exit_t is None:_,_,exit_t,exit_raw=first(deadline)
                close=exit_raw*(1-side*slip);ix=np.arange((fill-DAYBASE)//M+1,(exit_t-DAYBASE)//M+1)
                carry=-side*float(np.sum(one[ix,0]*one[ix,5]))/entry
                results.append(dict(rule=rule,sym=sym,signal=t,fill=fill,exit=exit_t,raw=raw,exit_raw=exit_raw,entry=entry,
                                    net=side*(close/entry-1)-.0005*(1+close/entry)+carry,carry=carry,expected=expected,
                                    lev=lev,lev0=lev0,stop=stop,distance=side*(expected-stop)/expected+2*(.0005+slip),
                                    ct=float(meta['ctVal']),lot=float(meta['lotSz']),minq=float(meta['minSz']),maxq=float(meta['maxMktSz']),
                                    cap=p['cap'],side=side,quality=quality,stress=st))
        tested.append(dict(symbol=sym,prepossible_setups=len(setups)+len(scalps),eligible=len(signals)))
    (CACHE/'latest.json').write_text(json.dumps(dict(day='2026-11-21',symbols=31,examined=tested,paths=results),indent=2))
    print('latest',tested,'paths',len(results))
if __name__=='__main__':replay()

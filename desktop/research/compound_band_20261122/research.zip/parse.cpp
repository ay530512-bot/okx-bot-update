// Preserve exchange ordering and reconcile complete minute totals and extrema.
// Each archive line is instrument, trade ID, side, price, size, timestamp.
#include <cstdio>
#include <cstdint>
#include <charconv>
#include <string_view>
#include <vector>
#include <cfloat>
#include <cmath>
#include <algorithm>
#include <string>
#include <array>

struct Print { int64_t time; double price; };
struct Minute { double low=DBL_MAX, high=0, volume=0, buy=0, sell=0; int64_t n=0; };
struct Tie { int64_t id; double price; };
template<class T> bool parse(std::string_view s,T& value) {
    auto v=std::from_chars(s.data(),s.data()+s.size(),value);
    return v.ec==std::errc{} && v.ptr==s.data()+s.size();
}
int main(int argc,char**argv) {
    if(argc!=5)return 1;
    const int64_t from=std::stoll(argv[1]),to=std::stoll(argv[2]);
    std::vector<Minute> bars((to-from)/60000);
    FILE *out=fopen(argv[3],"wb");if(!out)return 2;
    setvbuf(out,nullptr,_IOFBF,1<<20);setvbuf(stdin,nullptr,_IOFBF,1<<20);
    std::vector<Tie> tied;int64_t timestamp=-1;
    auto flush=[&](){
        if(!std::is_sorted(tied.begin(),tied.end(),[](auto a,auto b){return a.id<b.id;}))
            std::sort(tied.begin(),tied.end(),[](auto a,auto b){return a.id<b.id;});
        int64_t last=-1;for(auto r:tied) {
            if(r.id<=last)return false;
            Print p{timestamp,r.price};if(fwrite(&p,sizeof(p),1,out)!=1)return false;last=r.id;
        }
        tied.clear();return true;
    };
    char line[600];
    while(fgets(line,sizeof(line),stdin)) {
        std::string_view s(line);
        if(s.substr(0,16)=="instrument_name,")continue;
        std::array<std::string_view,6> f;size_t start=0;
        for(int i=0;i<6;i++) {
            auto end=i==5?s.find_first_of(",\r\n",start):s.find(',',start);
            if(end==s.npos)return 3;
            f[i]=s.substr(start,end-start);start=end+1;
        }
        int64_t t,id;double price,size;
        if(!parse(f[5],t))return 4;
        if(t<from||t>=to)continue;
        if(!parse(f[1],id)||!parse(f[3],price)||!parse(f[4],size)||!(price>0&&size>0))return 5;
        if(t!=timestamp){if(t<timestamp||!flush())return 6;timestamp=t;}
        tied.push_back({id,price});
        auto &m=bars[(t-from)/60000];
        m.low=std::min(m.low,price);m.high=std::max(m.high,price);m.volume+=size;m.n++;
        if(f[2]=="buy")m.buy+=price*size;else if(f[2]=="sell")m.sell+=price*size;else return 7;
    }
    if(ferror(stdin)||!flush()||fclose(out)!=0)return 8;
    FILE*m=fopen(argv[4],"wb");if(!m)return 9;
    return fwrite(bars.data(),sizeof(Minute),bars.size(),m)==bars.size()&&fclose(m)==0?0:10;
}

"""Walk-forward training uses no outcome from the subsequent chronological interval."""
import ctypes as C
import json
import os
import subprocess
from functools import lru_cache
import numpy as np
import pandas as pd
from events import ROOT,CACHE,STUDY,SYMS,BASE,START,END,M,DAY,RULES,meta
SPLIT=START+30*DAY
FIELDS=[(k,'<i8') for k in ('signal','fill','exit','id')]+[(k,'<f8') for k in ('expected','entry','distance','net','boundary','ct','lot','minq','maxq')]+[(k,'<i4') for k in ('level','flags','coin','reserved')]
DTYPE=np.dtype(FIELDS,align=True)
PAD=['tight','reference','wide']
MODES=['baseline','early_net','runner','atr_runner','swing_runner','quick_failure']
GATES=['original','room','pressure','expansion','room_pressure']
STATS=['trades','active_days','final','half','drawdown_usd','biggest','wins','inside','positive_days','worst_pct','best_pct']
assert DTYPE.itemsize==120
@lru_cache(maxsize=1)
def source():
    chunks=[];arrs=[];ins=meta()
    for sym in SYMS:
        folder=CACHE/sym
        df=pd.read_pickle(folder/'events.pkl').copy().reset_index(drop=True);z=np.load(folder/'out.npz')
        df['coin']=SYMS.index(sym);df['local']=np.arange(len(df));df['sym']=sym
        for k,key in [('ct','ctVal'),('lot','lotSz'),('minq','minSz'),('maxq','maxMktSz')]:df[k]=float(ins[sym][key])
        one=np.load(STUDY/f'target_cache/recent/{sym}-1.npy',mmap_mode='r')
        boundaries=START+((df.fill.to_numpy()-START)//DAY+1)*DAY
        indx=(boundaries-BASE)//M-1
        df['mid_px']=one[indx,3]
        ix=np.flatnonzero(one[:,5]!=0);time=BASE+ix*M
        cumulative=np.r_[0.,np.cumsum(one[ix,0]*one[ix,5])]
        df['mid_carry']=cumulative[time.searchsorted(boundaries,'left')]-cumulative[time.searchsorted(df.fill,'right')]
        chunks.append(df);arrs.append({k:z[k] for k in z.files})
    df=pd.concat(chunks,ignore_index=True)
    order=df.sort_values(['signal','rule','quality','sym'],ascending=[True,True,False,True]).index.to_numpy()
    return df.iloc[order].reset_index(drop=True),{k:np.concatenate([v[k] for v in arrs])[order] for k in arrs[0]}
def make_cases(pad,mode,stress,source_data=None):
    df,z=source() if source_data is None else source_data
    slip=.001 if stress else .0005
    a=np.empty(len(df),dtype=DTYPE);s=df.side.to_numpy();quote=df.quote.to_numpy();stop=z['stops'][:,pad]
    raw=df.raw.to_numpy();expected=quote*(1+s*slip);entry=raw*(1+s*slip)
    exit_px=z['raw'][:,pad,mode,int(stress)]*(1-s*slip);at=z['end'][:,pad,mode,int(stress)]
    net=s*(exit_px/entry-1)-.0005*(1+exit_px/entry)+z['carry'][:,pad,mode,int(stress)]
    structural=s*(quote-stop)/quote
    level=np.minimum(df.lev.to_numpy(),np.floor(.015/(structural+.002)+1e-12)).astype('int32')
    a['level']=np.where(level>=3,level,0)
    for k in ('signal','fill','id','ct','lot','minq','maxq','flags','coin'):a[k]=df[k]
    a['expected']=expected;a['entry']=entry;a['exit']=at;a['net']=net
    a['distance']=s*(expected-stop)/expected+2*(.0005+slip)
    mark=df.mid_px.to_numpy()*(1-s*slip)
    a['boundary']=s*(mark/entry-1)-.0005*(1+mark/entry)-s*df.mid_carry.to_numpy()/entry
    a['reserved']=0
    assert np.isfinite(a['net']).all() and np.all(a['distance']>0)
    return a
@lru_cache(maxsize=1)
def sc():
    dll=C.CDLL(str(CACHE/'search.so'));fn=dll.single
    fn.argtypes=[C.c_void_p,C.c_int,C.c_int64,C.c_int64]+[C.c_int]*6+[C.c_void_p];fn.restype=None
    return fn
def run_single(rows,start,end,gate,h,width,cap,size,purge):
    out=np.empty(11)
    sc()(rows.ctypes.data,len(rows),start,end,1<<gate,h,width,cap,int(size),purge,out.ctypes.data)
    return dict(zip(STATS,out))
def main():
    subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC',str(ROOT/'search.cpp'),'-o',str(CACHE/'search.so')],check=True)
    df,_=source();typ=df.rule.to_numpy()
    results=[]
    for pad in range(3):
        for mode in range(6):
            allrows=make_cases(pad,mode,False)
            for rule in range(5):
                rows=allrows[typ==rule]
                for gate in range(5):
                    for h in range(0,24,4):
                        for width in (4,8):
                            for cap in (4,8):
                                for size in (0,1):
                                    r=run_single(rows,START,SPLIT,gate,h,width,cap,size,180)
                                    results.append(dict(rule=rule,pad=pad,mode=mode,gate=gate,h=h,width=width,cap=cap,size=size,**r))
    out=pd.DataFrame(results)
    out.to_csv(CACHE/'training.csv.gz',index=False)
    picks=[]
    for (size,rule),g in out.groupby(['size','rule']):
        sample=g[(g.trades>=12)&(g.active_days>=7)].copy()
        sample['qualified']=(sample.half>150)&(sample.final>sample.half)&(sample.final-sample.biggest>150)
        sample['score']=sample.final-150-sample.biggest-sample.drawdown_usd
        winner=sample.sort_values(['qualified','inside','score','pad','mode','gate','h','width','cap'],ascending=[False,False,False,True,True,True,True,True,True]).iloc[0]
        picks.append(winner.to_dict())
    sel=pd.DataFrame(picks);sel.to_json(CACHE/'frozen.json',orient='records',indent=2,double_precision=15)
    print(len(out),'training configurations;',len(df),'signals; selected',len(sel),flush=True)
    print(sel[['size','rule','qualified','pad','mode','gate','h','width','cap','trades']].to_string(index=False))
if __name__=='__main__':main()

"""Find last-day raw-data requirements before transaction replay of the frozen primary."""
import os
import json
import pickle
import numpy as np
import pandas as pd
from pathlib import Path
from events import ROOT,CACHE,BASE,START,END,M,DAY,SYMS,CFG,EXITS,meta,close_bands,wick_flags,exit_boundary,preceding_decline_and_pause,setups
from data import DAYSET
from inputs import PERIODS
from pc_sizing import indicator_level
from pc_timing import indicators
from signals import Probe
from functools import lru_cache
from concurrent.futures import ThreadPoolExecutor
import math
DAYBASE=(END-4*DAY)//DAY*DAY
LAST_END=END+DAY
def arrays(sym):
    return [np.load(DAYSET/f'exchange_frames/target_cache/recent/{sym}-{k}.npy') for k in (1,5,15)]
def make():
    os.chdir(DAYSET/'exchange_frames')
    PERIODS['recent']=('2026-11-21','2026-11-22')
    ins={x['instId'].split('-')[0]:x for x in json.loads((DAYSET/'ins.json').read_text())['data'] if x['instId'].endswith('-USDT-SWAP')}
    prefs={int(x['rule']):x for x in json.loads((CACHE/'frozen.json').read_text()) if x['qualified'] and x['size']==1}
    allcl=np.stack([arrays(s)[0][:,3] for s in SYMS])
    jobs={}
    for si,sym in enumerate(SYMS):
        one,five,quarter=arrays(sym)
        mid,std=close_bands(five)
        o,h,l,c,v=five[:,:5].T;prev=pd.Series(c).shift().to_numpy()
        atr=pd.Series(np.maximum.reduce([h-l,abs(h-prev),abs(l-prev)])).rolling(14).mean().to_numpy()
        turn=pd.Series(c*v);ratio=(turn.rolling(3).sum()/(turn.shift(3).rolling(12).sum()/4)).to_numpy()
        tick=float(ins[sym]['tickSz']);green,red,rv=wick_flags(five,tick)
        def possible(rule,k):
            p=prefs[rule];t=DAYBASE+k*M;hr=(t//3600000+9)%24;j=k//5-1
            if not END<=t<LAST_END or (hr-p['h'])%24>=p['width'] or one[k,4]<=0:return False
            side=1 if rule in (0,2,4) else -1
            observed=one[k,2] if side==1 else one[k,1]
            target=mid[j] if rule<2 else mid[j]+side*2*std[j]
            if p['gate'] in (1,4) and (atr[j]/one[k,2]<.0035 or side*(target/observed-1)<.005):return False
            if p['gate']==3 and (atr[j]/one[k,2]<.006 or ratio[j]<1.25):return False
            if p['gate'] in (2,4):
                d=side*(allcl[:,k-1]/allcl[:,k-16]-1);d[si]=np.nan;d=d[np.isfinite(d)]
                if len(d)<20 or np.mean(d>0)<.55:return False
            return True
        selected=[]
        with np.errstate(divide='ignore',invalid='ignore'):
            for s in setups('recent',sym,ins[sym]):
                rev=s.family=='reversal';rule=(0 if rev else 2)+(s.side<0)
                if rule not in prefs or s.profile!=('narrow' if rev and s.side==1 else 'standard'):continue
                if rev and not preceding_decline_and_pause(five,mid,std,s.source,s.source+1,s.side,s.atr,observed_prices=[])[1]:continue
                end=min(s.end,(s.source+31)*5 if rev else s.end,len(one))
                if any(possible(rule,k) for k in range(s.start,end)):
                    selected.append((rule,s,end))
        scalps=[]
        if 4 in prefs:
            for j in np.flatnonzero(green):
                t=DAYBASE+(j+1)*5*M
                if not END<=t<LAST_END:continue
                k=(j+1)*5;p=prefs[4];hr=(t//3600000+9)%24
                if (hr-p['h'])%24>=p['width']:continue
                # At a completed scalp close, quote is known even before the next minute's first print.
                if p['gate'] in (1,4) and (atr[j]/c[j]<.0035 or (mid[j]+2*std[j])/c[j]-1<.005):continue
                if p['gate']==3 and (atr[j]/c[j]<.006 or ratio[j]<1.25):continue
                d=allcl[:,k-1]/allcl[:,k-16]-1;d[si]=np.nan
                if p['gate'] in (2,4) and np.nanmean(d[np.isfinite(d)]>0)<.55:continue
                count,_=exit_boundary(red,j)
                scalps.append((int(j),int(count),float(rv[j])))
        if selected or scalps:jobs[sym]=(selected,scalps)
    with (CACHE/'day_requirements.pkl').open('wb') as f:pickle.dump(jobs,f)
    print({s:(len(g),len(c)) for s,(g,c) in jobs.items()})
if __name__=='__main__':make()

"""Independently replay the qualified chronological fills, trade by trade, without OHLC shortcuts."""
import json
import math

import pandas as pd

from account import CACHE, market, selected_rows
from events import EXITS, M


def main():
    configs=[r for r in json.loads((CACHE/'frozen.json').read_text()) if r['qualified'] and r['size']==1]
    rows={r['id']:r for r in selected_rows(configs,False)}
    book=pd.read_csv(CACHE/'same_contracts.csv')
    checked=0
    for fill in book.itertuples():
        e=rows[fill.id]
        tape=market(e['sym'])
        s=e['side']
        cfg=EXITS[e['mode']]
        deadline=e['deadline'] if e['rule']==4 else e['fill']+cfg['minutes'][0]*M
        i=e['fi']
        risk=s*(e['entry']-e['stop'])
        assert risk>0
        for arm,gap,target in ((cfg['arm_r'],cfg['gap_r'],fill.configured_exit),(1,1,fill.reference_exit)):
            live=s*e['stop']
            peak=s*e['raw']
            end_idx=tape.at(deadline)
            observed=int(tape.p[end_idx]['ts'])
            for print0 in tape.p[i+1:end_idx]:
                signed=s*float(print0['px'])
                if signed<=live:
                    observed=int(tape.p[tape.at(int(print0['ts']),True)]['ts'])
                    break
                peak=max(peak,signed)
                if peak-s*e['entry']>=arm*risk:
                    live=max(live,math.floor((peak-gap*risk)/tape.tick+1e-10)*tape.tick)
            assert observed==target,(fill.id,observed,target)
            checked+=1
    print(checked,'price-path exits match unaccelerated chronological public prints.')


if __name__=='__main__':
    main()

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <cstddef>
struct Print {int64_t ts;double px;};
struct Out {int64_t exit;double active,best;int32_t why;int32_t reserved;};
constexpr int64_t M=60000;
extern "C" int64_t reaction(const Print*p,int64_t a,int64_t b,const double*opening,int64_t base,
        int side,int trend,int armed,double lower,double upper,double depart,double step,double atr,double tick,double*extreme) {
    int bar=-1;double low=INFINITY,eps=tick*1e-5,chase=std::max(3*tick,.25*atr);
    for(int64_t i=a;i<b;i++){
        double px=side*p[i].px;
        if(px<lower-eps)return -1;
        if(!armed){armed=px>=depart-eps;continue;}
        int j=(p[i].ts-base)/(5*M);
        if(j!=bar){bar=j;low=INFINITY;}
        if(px<=upper+eps)low=std::min(low,px);
        if(!std::isfinite(low))continue;
        double rise=px-low,wick=std::min(side*opening[j],px)-low;
        if(rise+eps<step||wick+eps<tick)continue;
        if(rise>chase+eps||(trend&&wick>std::max(3*tick,.25*atr)+eps))return -1;
        *extreme=side*low;return i;
    }
    return -1;
}
inline int64_t after(const Print*p,int64_t lo,int64_t n,int64_t t){
    return std::upper_bound(p+lo,p+n,t,[](int64_t x,const Print&r){return x<r.ts;})-p;
}
// If probe>0, stop before the first print at or after probe and return only the known
// stop/peak as of that boundary; the same logic drives open-risk checks.
extern "C" void path(const Print*p,int64_t n,const int64_t*off,const double*one,const double*sw,
        int64_t base,int nmin,int64_t entry,int side,double stop,double atr,double tick,
        double slip,double arm,double gap,int mode,int64_t deadline,int64_t probe,Out*out){
    const double ep=p[entry].px*(1+side*slip),se=side*ep,risk=se-side*stop;
    const double be=side*ep*(1+side*.0005)/((1-side*slip)*(1-side*.0005));
    double active=side*stop,best=side*p[entry].px;
    const int64_t last=probe>0?std::min(probe,deadline):deadline;
    const int64_t failure=p[entry].ts+15*M;
    bool checked=false;
    auto write=[&](int64_t i,int reason){
        out->exit=std::min(i,n-1);out->why=i>=n?5:reason;out->active=side*active;out->best=side*best;out->reserved=0;
    };
    if(risk<=0){write(after(p,entry,n,p[entry].ts),1);return;}
    auto raised=[&](double favorable,double old,int k){
        if(favorable-se<arm*risk)return old;
        double v=mode==1?favorable-gap*atr:mode==2?sw[k/5]:favorable-gap*risk;
        if((mode==1||mode==2) && favorable>=be+tick)v=std::max(v,be);
        return std::max(old,std::floor(v/tick+1e-10)*tick);
    };
    for(int k=(p[entry].ts-base)/M;k<nmin;k++){
        int64_t lo=std::max(entry+1,off[k]),hi=off[k+1];
        if(lo>=hi)continue;
        int64_t tm=base+(int64_t)k*M;
        if(mode==2&&tm>p[entry].ts)active=raised(best,active,k);
        bool full=lo==off[k]&&tm+M<=last;
        if(mode==3&&!checked&&tm+M>failure)full=false;
        double favorable=side*(side==1?one[k*5+1]:one[k*5+2]);
        double worst=side*(side==1?one[k*5+2]:one[k*5+1]);
        double future_best=std::max(best,favorable),possible=raised(future_best,active,k);
        if(full&&worst>possible){active=possible;best=future_best;continue;}
        for(int64_t i=lo;i<hi;i++){
            if(p[i].ts>=last){write(i,probe>0&&probe<=deadline?0:3);return;}
            double v=side*p[i].px;
            if(v<=active){write(after(p,i,n,p[i].ts),active==side*stop?1:2);return;}
            if(mode==3&&!checked&&p[i].ts>=failure){
                checked=true;
                if(best-se<.45*risk){write(after(p,i,n,p[i].ts),4);return;}
            }
            best=std::max(best,v);
            active=raised(best,active,k);
        }
    }
    write(n,5);
}

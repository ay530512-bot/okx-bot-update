"""Build the most recent 60-day ledger and reprice identical filled contracts."""
import json
import math

import numpy as np
import pandas as pd

from account import CACHE, DAY, END, M, START, market, run, selected_rows
from events import EXITS, SYMS
from search import SPLIT, source


def append_verified_day(stats, days, book, latest):
    # This extension only applies to an empty day after positions in these slots expire.
    # A non-empty day requires a portfolio rerun on joined chronological tapes.
    assert latest['symbols'] == len(SYMS) == 31
    assert latest['day'] == '2026-11-21' and not latest['paths']
    assert all(row['exit'] < END for row in book)
    terminal = stats['final']
    assert math.isclose(terminal, 150 + sum(row['usd'] for row in book), abs_tol=1e-7)
    extra = dict(day=latest['day'], opening=terminal, closing=terminal,
                 net_pct=0., inside=False, locked=False)
    days = pd.concat([days, pd.DataFrame([extra])], ignore_index=True)
    assert np.allclose(days.opening.iloc[1:], days.closing.iloc[:-1], rtol=0, atol=1e-10)
    compounded = 150 * np.prod(1 + days.net_pct.to_numpy() / 100)
    assert abs(compounded - terminal) < 1e-8
    assert days.net_pct.between(5, 10, inclusive='both').equals(days.inside)
    stats = dict(stats, days=len(days), flat=stats['flat'] + 1, below=stats['below'] + 1)
    stats.update(first=days.day.iloc[0], last=days.day.iloc[-1],
                 pnl_without_best_fill=float(terminal-150-stats['best_fill']))
    if book:
        by_symbol = pd.DataFrame(book).groupby('symbol').usd.sum()
        stats['pnl_without_best_symbol'] = float(terminal-150-max(0, by_symbol.max()))
    return stats, days


def paired(rows, book, configs):
    # Hold the marked fills, individual quantities, original pad and maximum holding time fixed.
    # Swap only the trailing trigger and trailing distance to the reference +1R/1R.
    df, _ = source()
    all_events = df.set_index('id').to_dict('index')
    modeled = {e['id']: e for e in rows}
    reference = {}
    for cfg in configs:
        rule, policy = int(cfg['rule']), int(cfg['mode'])
        reference[rule] = len(EXITS)
        EXITS.append(dict(EXITS[policy], name='reference_paired', type='price', arm_r=1., gap_r=1.))
    observations = []
    for fill in book:
        symbol, rule, key = fill['symbol'], fill['rule'], fill['id']
        tape = market(symbol)
        event = all_events[key]
        active = modeled[key]
        units = fill['qty'] * event['ct']
        side, stop, entry = event['side'], fill['initial_stop'], fill['entry']
        policy = active['mode']
        original = tape.path(event, stop, policy, .0005)
        assert (tape.p[original.exit]['ts'], original.why) == (fill['exit'], fill['why'])
        out = tape.path(event, stop, reference[rule], .0005)
        mark = tape.p[out.exit]
        end, price = int(mark['ts']), float(mark['px'])*(1-side*.0005)
        carry = tape.funding(event['fill'], end, side, entry)*entry*units
        ref_net = units*(side*(price-entry)-.0005*(entry+price))+carry
        details = dict(id=key, symbol=symbol, rule=rule, signal=event['signal'],
                       quantity=fill['qty'], margin=fill['margin'], configured_net=fill['usd'],
                       reference_net=ref_net, difference=fill['usd']-ref_net,
                       reference_exit=end, configured_exit=fill['exit'],
                       gross=fill['gross'], fees=fill['fees'], slippage=fill['slippage'], funding=fill['funding'])
        for horizon in (5, 15, 30):
            i = tape.at(event['signal']+horizon*M, strict=True)-1
            px = float(tape.p[i]['px'])
            details['directional_pct_'+str(horizon)+'m'] = 100*side*(px/event['quote']-1)
        observations.append(details)
    return pd.DataFrame(observations)


def main():
    latest = json.loads((CACHE/'latest.json').read_text())
    configs = [r for r in json.loads((CACHE/'frozen.json').read_text()) if r['qualified'] and r['size']==1]
    assert {r['rule'] for r in configs} == {1, 4}
    coverage = [json.loads((CACHE/s/'checked.json').read_text()) for s in SYMS]
    (CACHE/'coverage.json').write_text(json.dumps(coverage))
    result = dict(frozen_historical_windows=True, earliest_whole_prospective_day_kst='2026-11-23',
                  contracts=len(coverage), verified_minutes_per_contract=86400,
                  archived_prints_including_warmup=sum(r['prints'] for r in coverage), periods={})
    output_days = []
    output_fills = []
    groups={'shared':configs, 'reversal_short':[r for r in configs if r['rule']==1],
            'scalp_long':[r for r in configs if r['rule']==4],
            'shared_full_slot_same_rules':[dict(r,size=0) for r in configs]}
    for group, group_configs in groups.items():
        for stress in (False, True):
            rows = selected_rows(group_configs, stress)
            for period, start in [('latest60',START+DAY),('chronological31',SPLIT),('continuous61',START)]:
                stats, days, book = run(rows, start, END, stress, True)
                stats, days = append_verified_day(stats, days, book, latest)
                key = f'{group}_{period}_'+('stress' if stress else 'base')
                result['periods'][key] = stats
                output_days.append(days.assign(cohort=group,period=period,stress=stress))
                if group=='shared' and period=='latest60' and not stress:
                    result['latest60_at_training_cutoff'] = float(days.loc[days.day=='2026-10-21','closing'].iloc[0])
                if group=='shared' and not stress:
                    output_fills.extend(dict(i,period=period) for i in book)
                if group=='shared' and period=='chronological31' and not stress:
                    comparison=paired(rows,book,configs)
                    comparison.to_csv(CACHE/'same_contracts.csv',index=False)
                    result['paired_on_chronological_fills'] = comparison[
                        ['configured_net','reference_net','difference']].sum().to_dict()
    pd.concat(output_days).to_csv(CACHE/'newest_daily.csv.gz',index=False)
    pd.DataFrame(output_fills).to_csv(CACHE/'newest_shared_fills.csv.gz',index=False)
    (CACHE/'summary.json').write_text(json.dumps(result,indent=2))
    for period in ('latest60','chronological31','continuous61'):
        stats=result['periods']['shared_'+period+'_base']
        print(period,stats['final'],stats['inside'],stats['filled'],stats['best'],stats['flat'],flush=True)
    print('paired',result['paired_on_chronological_fills'],flush=True)


if __name__=='__main__':
    main()

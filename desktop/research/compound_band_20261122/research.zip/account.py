"""Continuous 150 USDT portfolio, with real print exits and optional daily profit lock."""
import json
import math
from collections import Counter
from functools import lru_cache
import numpy as np
import pandas as pd
from events import Market,ROOT,CACHE,START,END,BASE,M,DAY,SYMS
from search import source,make_cases,SPLIT

@lru_cache(maxsize=32)
def market(sym):return Market(sym)

@lru_cache(maxsize=36)
def case_table(pad,mode,stress):
    return make_cases(pad,mode,stress)

def selected_rows(prefs,stress):
    df,z=source()
    out=[];hours=(df.signal.to_numpy()//3600000+9)%24
    for f in prefs:
        rule,pad,mode,gate,h,width=[int(f[k]) for k in ('rule','pad','mode','gate','h','width')]
        mask=(df.rule.to_numpy()==rule)&((hours-h)%24<width)&((df['flags'].to_numpy()&(1<<gate))!=0)
        subset=df.loc[mask]
        table=case_table(pad,mode,stress)
        for i,e in zip(subset.index,subset.to_dict('records')):
            c=table[i];e.update(level=int(c['level']),stop=float(z['stops'][i,pad]),mode=mode,cap=int(f['cap']),size=int(f['size']),
                                 expected=float(c['expected']),entry=float(c['entry']),distance=float(c['distance']),net=float(c['net']),
                                 exit=int(c['exit']),exit_raw=float(z['raw'][i,pad,mode,int(stress)]),why=int(z['why'][i,pad,mode,int(stress)]),
                                 carry=float(z['carry'][i,pad,mode,int(stress)]))
            out.append(e)
    return sorted(out,key=lambda e:(e['signal'],e['rule'],-e['quality'],e['sym']))

def mark(e,t):
    tape=market(e['sym']);i=tape.at(t)-1
    return float(tape.p[i]['px']) if i>=0 else e['raw']

def holding(p,t,slip,liquidating,boundary):
    e=p['ev']
    if t<=e['fill']:return 0.
    m=market(e['sym']);s=e['side'];px=m.one[(t-BASE)//M-1,3] if boundary else mark(e,t)
    carry=m.funding(e['fill'],t-1,s,e['entry'])
    if liquidating:
        q=px*(1-s*slip)
        fraction=s*(q/e['entry']-1)-.0005*(1+q/e['entry'])+carry
    else:fraction=s*(px/e['entry']-1)-.0005+carry
    return fraction*p['notional']

def run(rows,start,end,stress=False,lock=True,seed=150.,record=True):
    slip=.001 if stress else .0005
    cash=seed;opening=seed;positions={};book=[];days=[];counts=Counter()
    at=0;locked=False;locks=0;peak=seed;drawdown=0.;max_slots=0
    rows=[dict(e) for e in rows if start<=e['signal']<end]
    def settle(t,inclusive=False):
        nonlocal cash
        for key,p in sorted(list(positions.items()),key=lambda v:v[1]['ev']['exit']):
            e=p['ev']
            if e['exit']>t or (not inclusive and e['exit']==t):break
            usd=p['notional']*e['net'];cash+=usd
            units=p['qty']*e['ct'];s=e['side'];q=e['exit_raw']*(1-s*slip)
            gross=s*(e['exit_raw']-e['raw'])*units;fees=.0005*(e['entry']+q)*units
            slippage=gross-s*(q-e['entry'])*units;carry=e['carry']*p['notional']
            assert abs(usd-(gross-fees-slippage+carry))<1e-7
            book.append(dict(id=e['id'],rule=e['rule'],symbol=e['sym'],signal=e['signal'],fill=e['fill'],exit=e['exit'],
                side=s,lev=p['lev'],qty=p['qty'],margin=p['notional']/p['lev'],gross=gross,fees=fees,slippage=slippage,
                funding=carry,usd=usd,why=e['why'],size=e['size'],entry=e['entry'],exit_price=q,initial_stop=e['stop']))
            del positions[key]
    def liquid(t):
        return cash+sum(holding(p,t,slip,True,True) for p in positions.values())
    def protect(t):
        nonlocal locks,locked
        locks+=1;locked=True
        for p in positions.values():
            e=p['ev'];m=market(e['sym'])
            i=m.at(max(t,e['fill']),True)
            if i>=len(m.p) or m.p[i]['ts']>=e['exit']:continue
            e['exit']=int(m.p[i]['ts']);e['exit_raw']=float(m.p[i]['px'])
            q=e['exit_raw']*(1-e['side']*slip);e['carry']=m.funding(e['fill'],e['exit'],e['side'],e['entry'])
            e['net']=e['side']*(q/e['entry']-1)-.0005*(1+q/e['entry'])+e['carry'];e['why']=6
    for tm in range(start,end+M,M):
        settle(tm)
        nav=liquid(tm);peak=max(peak,nav);drawdown=max(drawdown,1-nav/peak)
        if tm>start and (tm-start)%DAY==0:
            pct=100*(nav/opening-1)
            days.append(dict(day=pd.Timestamp(tm-DAY,unit='ms',tz='UTC').tz_convert('Asia/Seoul').date().isoformat(),
                opening=opening,closing=nav,net_pct=pct,inside=bool(5-1e-10<=pct<=10+1e-10),locked=locked))
            opening=nav;locked=False
        if tm==end:break
        if lock and not locked and nav>=opening*1.075-1e-12:protect(tm)
        while at<len(rows) and rows[at]['signal']<tm+M:
            e=rows[at];at+=1;t=e['signal'];key=e['rule'];dk=((t+9*3600000)//DAY,key)
            settle(t,True)
            if locked or key in positions or counts[dk]>=e['cap'] or len(positions)>=3 or any(p['ev']['sym']==e['sym'] for p in positions.values()):continue
            if not e['size'] and not e['level']:continue
            equity=cash;used=risk=0.
            for p in positions.values():
                old=p['ev']
                if old['fill']>=t:
                    used+=p['planned']*(1/p['lev']+.0005);risk+=p['planned']*old['distance'];continue
                equity+=holding(p,t,slip,False,False);px=mark(old,t)
                live=market(old['sym']).path(old,old['stop'],old['mode'],slip,probe=t).active
                used+=p['notional']/p['lev']
                risk+=p['units']*(max(0,old['side']*(px-live))+2*(.0005+slip)*px)
            funds=max(0,equity-3);target=funds/3;lev=max(3,e['level'])
            maxrisk=max(0,min(.005*funds,.02*funds-risk))
            nominal=target/(1/lev+.0005)
            if e['size']:nominal=min(nominal,maxrisk/e['distance'],max(0,funds-used)/(1/lev+.0005))
            qty=math.floor(nominal/(e['expected']*e['ct']*e['lot']))*e['lot']
            planned=qty*e['ct']*e['expected']
            if not e['minq']<=qty<=e['maxq'] or (not e['size'] and planned/lev<.97*target):continue
            if planned*e['distance']>maxrisk+1e-12 or planned*(1/lev+.0005)>funds-used+1e-12:continue
            positions[key]=dict(ev=e,qty=qty,units=qty*e['ct'],notional=qty*e['ct']*e['entry'],planned=planned,lev=lev)
            counts[dk]+=1;max_slots=max(max_slots,len(positions))
    assert len(days)==(end-start)//DAY
    d=pd.DataFrame(days);net=d.net_pct
    stats=dict(final=float(d.closing.iloc[-1]),days=len(d),inside=int(d.inside.sum()),below=int((net<5-1e-10).sum()),
               above=int((net>10+1e-10).sum()),positive=int((net>1e-10).sum()),flat=int((net.abs()<1e-10).sum()),
               filled=len(book),locks=locks,max_slots=max_slots,worst=float(net.min()),best=float(net.max()),drawdown_pct=100*drawdown,
               gross=sum(p['gross'] for p in book),fees=sum(p['fees'] for p in book),slip=sum(p['slippage'] for p in book),
               carry=sum(p['funding'] for p in book),best_fill=max([0.,*(p['usd'] for p in book)]))
    assert stats['inside']+stats['below']+stats['above']==len(d)
    if not positions:assert abs(cash-seed-sum(p['usd'] for p in book))<1e-7
    return stats,d,book

def main():
    prefs=json.loads((CACHE/'frozen.json').read_text())
    cohorts={}
    for sz,name in [(0,'full_slot'),(1,'capped')]:
        group=[f for f in prefs if f['size']==sz]
        passed=[f for f in group if f['qualified']]
        cohorts[name+'_selected' if passed else name+'_diagnostic']=passed or group
        for f in group:cohorts[f'{name}_{int(f["rule"])}']=[f]
    # Identical entries and exits of primary choices, only position sizing changes.
    top=[f for f in prefs if f['size']==1 and f['qualified']]
    if top:cohorts['matched_full_slot']=[dict(f,size=0) for f in top]
    stats=[];books=[];days=[]
    for name,configs in cohorts.items():
        for stress in (False,True):
            rows=selected_rows(configs,stress)
            for lock in (False,True):
                for phase,begin,finish in [('development',START,SPLIT),('chronological_test',SPLIT,END),('continuous',START,END)]:
                    st,d,book=run(rows,begin,finish,stress,lock)
                    tag=dict(cohort=name,stress=stress,lock=lock,phase=phase)
                    stats.append(dict(tag,**st))
                    if lock and not stress:
                        days.append(d.assign(**tag))
                        if phase=='chronological_test':books.extend(dict(tag,**b) for b in book)
        print(name,flush=True)
    pd.DataFrame(stats).to_csv(CACHE/'accounts.csv',index=False)
    pd.concat(days).to_csv(CACHE/'daily.csv.gz',index=False)
    pd.DataFrame(books).to_csv(CACHE/'fills.csv.gz',index=False)
    print('done',len(stats),flush=True)
if __name__=='__main__':main()

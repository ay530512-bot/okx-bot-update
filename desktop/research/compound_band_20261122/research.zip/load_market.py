"""Archive the ordered, read-only market tapes used by the experiment."""
import os
import json
import sys
import shutil
import subprocess
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
CACHE=ROOT/'cache'
STUDY=Path(os.environ.get('PC_STUDY',ROOT.parent/'study')).resolve()
SOURCE=STUDY/'tick_cache'
SYMS=sorted(f.name.split('-')[0] for f in (STUDY/'target_cache/recent').glob('*-1.npy'))
M=60000
DAY=1440*M
def kst(s):return int(pd.Timestamp(s,tz='Asia/Seoul').timestamp()*1000)
START=kst('2026-09-22');END=kst('2026-11-21')
BASE=(START-4*DAY)//DAY*DAY
PSTART=kst('2026-09-21')+3600000  # first locally available archive, Sep 21 at 00:00 UTC+8
TIMES=np.dtype([('ts','<i8'),('px','<f8')])
MINUTES=np.dtype([(k,'<f8') for k in ('lo','hi','vol','buy','sell')]+[('n','<i8')])
def collect(sym):
    folder=CACHE/sym;folder.mkdir(exist_ok=True)
    tape=folder/'public.bin';mp=folder/'minute.bin'
    if (folder/'checked.json').exists():return
    files=sorted(SOURCE.glob(sym+'-2026-*.zip'))
    proc=subprocess.Popen([str(CACHE/'parse'),str(PSTART),str(END),str(tape),str(mp)],stdin=subprocess.PIPE)
    hashes=[]
    try:
        for file in files:
            with ZipFile(file) as z:
                for name in sorted(k for k in z.namelist() if k.endswith('.csv')):
                    hashes.append([file.name,z.getinfo(name).CRC])
                    with z.open(name) as s:shutil.copyfileobj(s,proc.stdin,1<<20)
        proc.stdin.close()
        if proc.wait():raise ValueError((sym,'archive reader',proc.returncode))
    except BaseException:
        proc.kill();proc.wait();raise
    raw=np.memmap(mp,dtype=MINUTES,mode='r')
    bars=np.load(STUDY/f'target_cache/recent/{sym}-1.npy',mmap_mode='r')
    original=bars[(PSTART-BASE)//M:(END-BASE)//M]
    good=np.isclose(raw['vol'],original[:,4],rtol=1e-7,atol=1e-7)
    good&=(original[:,4]==0)|(np.isclose(raw['lo'],original[:,2],rtol=1e-9,atol=1e-15)&np.isclose(raw['hi'],original[:,1],rtol=1e-9,atol=1e-15))
    test=np.arange(len(original))>=(START-PSTART)//M
    if not good[test].all():raise ValueError((sym,'volume/OHLC',np.flatnonzero(test&~good)[:12]))
    assert tape.stat().st_size==16*raw['n'].sum()
    extra=dict(symbol=sym,prints=int(raw['n'].sum()),minutes_verified=int(test.sum()),archives=hashes)
    (folder/'checked.json').write_text(json.dumps(extra))
    print(sym,extra['prints'],flush=True)
if __name__=='__main__':
    subprocess.run(['g++','-O3','-std=c++17',str(ROOT/'parse.cpp'),'-o',str(CACHE/'parse')],check=True)
    with ProcessPoolExecutor(5) as pool:list(pool.map(collect,SYMS))

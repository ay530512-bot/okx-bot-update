#include <algorithm>
#include <cmath>
#include <array>
#include <cstdint>
struct Case {
    int64_t signal,fill,exit,id;
    double expected,entry,distance,net,boundary,ct,lot,minq,maxq;
    int32_t level,flags,coin,reserved;
};
extern "C" void single(const Case*rows,int n,int64_t start,int64_t finish,int mask,int hour,
       int width,int cap,int resized,int purge,double *o){
    constexpr int64_t DAY=86400000, M=60000;
    int nd=(finish-start)/DAY;std::array<double,128> change{};std::array<int,128> count{};
    double cash=150,peak=150,dd=0,biggest=0;int64_t busy=-1;int trades=0, wins=0;
    for(int i=0;i<n;i++){
        auto&r=rows[i];
        if(r.signal<start||r.signal>=finish-purge*M||r.exit>=finish||r.signal<busy||!(r.flags&mask))continue;
        int d=(r.signal-start)/DAY;
        int hod=(r.signal/3600000+9)%24;
        if((hod-hour+24)%24>=width||count[d]>=cap||(!resized&&!r.level))continue;
        int lev=std::max(r.level,3);
        double seed=std::max(0.,cash-3),target=seed/3;
        double proposed=target/(1./lev+.0005);
        if(resized)proposed=std::min(proposed,.005*seed/r.distance);
        double qty=std::floor(proposed/(r.expected*r.ct*r.lot))*r.lot;
        double nominal=qty*r.ct*r.expected;
        if(qty<r.minq||qty>r.maxq||(!resized&&nominal/lev<.97*target)||nominal*r.distance>.005*seed+1.e-12)continue;
        double invested=qty*r.ct*r.entry,pnl=invested*r.net;
        int e=(r.exit-start)/DAY,f=(r.fill-start)/DAY;if(e<0||e>=nd||f<0||f>=nd)continue;
        if(e==f)change[e]+=pnl;else {change[f]+=invested*r.boundary;change[e]+=pnl-invested*r.boundary;}
        cash+=pnl;peak=std::max(peak,cash);dd=std::max(dd,peak-cash);biggest=std::max(biggest,pnl);
        trades++;count[d]++;wins+=pnl>0;busy=r.exit;
    }
    double running=150,half=150,minpct=1.e9,maxpct=-1.e9;int active=0,inside=0,positive=0;
    for(int d=0;d<nd;d++){
        double pct=change[d]/running*100;running+=change[d];inside+=pct>=5.-1e-10&&pct<=10.+1e-10;positive+=pct>1e-10;
        minpct=std::min(minpct,pct);maxpct=std::max(maxpct,pct);active+=count[d]>0;
        if(d+1==nd/2)half=running;
    }
    o[0]=trades;o[1]=active;o[2]=cash;o[3]=half;o[4]=dd;o[5]=biggest;o[6]=wins;o[7]=inside;o[8]=positive;o[9]=minpct;o[10]=maxpct;
}

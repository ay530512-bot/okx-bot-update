"""Locate the original immediate wick events at all hours, then price the registered exits."""
import ctypes as C
import json
import math
import os
import sys
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd
from load_market import ROOT,CACHE,STUDY,START,END,BASE,PSTART,M,DAY,SYMS,TIMES,MINUTES

OLD=Path(os.environ.get('PC_WICK30_SOURCE',ROOT.parent/'bb30')).resolve()
sys.path.insert(0,str(OLD))
from data import indicators
from pc_sizing import indicator_level
from bb_filter import close_bands,preceding_decline_and_pause
from scalp import wick_flags,exit_boundary
from signals import setups
from paths import meta

CFG=json.loads((ROOT/'plan.json').read_text())
EXITS=CFG['exits']
RULES=['reversal_long','reversal_short','trend_long','trend_short','scalp_long']
D=C.c_double;I=C.c_int;L=C.c_int64;P=C.c_void_p
class Output(C.Structure):
    _fields_=[('exit',L),('active',D),('best',D),('why',I),('reserved',I)]
def ptr(a):return a.ctypes.data
@lru_cache(maxsize=1)
def native():
    d=C.CDLL(str(CACHE/'paths.so'))
    d.reaction.argtypes=[P,L,L,P,L,I,I,I,D,D,D,D,D,D,C.POINTER(D)];d.reaction.restype=L
    d.path.argtypes=[P,L,P,P,P,L,I,L,I,D,D,D,D,D,D,I,L,L,C.POINTER(Output)];d.path.restype=None
    return d
@lru_cache(maxsize=1)
def breadth():
    common=np.column_stack([np.load(STUDY/f'target_cache/recent/{s}-1.npy',mmap_mode='r')[:,3] for s in SYMS])
    earlier=np.roll(common,15,axis=0);good=np.isfinite(earlier)&np.isfinite(common)
    return (common>earlier)&good,(common<earlier)&good,good

class Market:
    def __init__(self,sym):
        self.sym=sym;self.meta=meta()[sym];self.tick=float(self.meta['tickSz'])
        self.p=np.memmap(CACHE/sym/'public.bin',mode='r',dtype=TIMES)
        self.activity=np.memmap(CACHE/sym/'minute.bin',mode='r',dtype=MINUTES)
        self.one=np.ascontiguousarray(np.load(STUDY/f'target_cache/recent/{sym}-1.npy')[:,:5])
        self.five=np.load(STUDY/f'target_cache/recent/{sym}-5.npy')
        self.rate=np.load(STUDY/f'target_cache/recent/{sym}-1.npy',mmap_mode='r')[:,5]
        self.settled=np.flatnonzero(self.rate!=0)
        self.off=np.zeros(len(self.one)+1,dtype=np.int64)
        self.m0=(PSTART-BASE)//M;self.off[self.m0+1:]=np.cumsum(self.activity['n'])
        self.opening=np.ascontiguousarray(self.five[:,0])
        self.mean,self.std=close_bands(self.five)
        o,h,l,c,v=self.five[:,:5].T
        previous=pd.Series(c).shift().to_numpy()
        self.atr=pd.Series(np.maximum.reduce((h-l,abs(h-previous),abs(l-previous)))).rolling(14).mean().to_numpy()
        pad=np.maximum(2*self.tick,.1*self.atr)
        self.swing={s:np.ascontiguousarray(pd.Series(l if s==1 else -h).rolling(3).min().shift().to_numpy()-pd.Series(pad).shift().to_numpy()) for s in (1,-1)}
        turnover=pd.Series(c*v)
        recent=turnover.rolling(3).sum();self.turn_ratio=(recent/(turnover.shift(3).rolling(12).sum()/4)).to_numpy()
        self.green,self.red,self.rv=wick_flags(self.five,self.tick)
    def at(self,ts,strict=False):
        if ts>=END:return len(self.p)
        k=max(0,(ts-BASE)//M);lo,hi=self.off[k:k+2]
        return int(lo+self.p['ts'][lo:hi].searchsorted(ts,'right' if strict else 'left'))
    def path(self,event,stop,policy,slip,probe=0):
        side=event['side'];e=EXITS[policy];mode=['price','atr','swing'].index(e['type'])
        if e['name']=='quick_failure':mode=3
        family=event['rule'];slot=0 if family<2 else 1 if family==2 else 2 if family==3 else 3
        deadline=event['deadline'] if family==4 else event['fill']+e['minutes'][slot]*M
        out=Output()
        native().path(ptr(self.p),len(self.p),ptr(self.off),ptr(self.one),ptr(self.swing[side]),BASE,len(self.one),
                      event['fi'],side,stop,event['atr'],self.tick,slip,e['arm_r'],e.get('gap_r',e.get('gap_atr',0.)),mode,deadline,probe,C.byref(out))
        return out
    def funding(self,t,u,side,entry):
        a=(t-BASE)//M+1;b=(u-BASE)//M
        ix=self.settled[self.settled.searchsorted(a):self.settled.searchsorted(b,'right')]
        return float(-side*np.sum(self.one[ix,0]*self.rate[ix])/entry)
    def signals(self):
        found=[];sidx=SYMS.index(self.sym);up,down,valid=breadth()
        @lru_cache(maxsize=None)
        def level(j,s):
            atr=self.atr[j]
            ev=indicators([[0,*row] for row in self.five[j-31:j+1,:5]],s,atr)
            return min(5,int(float(self.meta['lever'])),indicator_level(ev)) if ev else 0
        def add(typ,side,t,fi,quote,anchor,atr,q,deadline):
            if fi>=len(self.p) or not START<=t<END:return
            fill=int(self.p[fi]['ts'])
            if fill-t>60000:return
            k=(t-BASE)//M;j=(t-BASE)//(5*M)-1
            lev=level(j,side)
            if lev<3:return
            act=self.activity[k-1-self.m0];total=act['buy']+act['sell']
            align=up if side==1 else down
            other_count=int(valid[k-1].sum()-int(valid[k-1,sidx]))
            same=int(align[k-1].sum()-int(align[k-1,sidx]))
            flow=(total>0 and act['n']>=5 and act['buy' if side==1 else 'sell']/total>=.58 and other_count>=20 and same/other_count>=.55)
            target=self.mean[j] if typ<2 else self.mean[j]+side*2*self.std[j]
            room=self.atr[j]/quote>=.0035 and side*(target/quote-1)>=.005
            expansion=self.atr[j]/quote>=.006 and self.turn_ratio[j]>=1.25
            flags=1|int(room)*2|int(flow)*4|int(expansion)*8|int(room and flow)*16
            found.append(dict(sym=self.sym,rule=typ,side=side,signal=int(t),fi=int(fi),fill=fill,raw=float(self.p[fi]['px']),
                              quote=float(quote),anchor=float(anchor),atr=float(atr),quality=float(q),lev=lev,flags=flags,deadline=int(deadline)))
        with np.errstate(divide='ignore',invalid='ignore'):
            for s in setups('recent',self.sym,self.meta):
                rev=s.family=='reversal';side=s.side;i=s.source
                if s.profile!=('narrow' if rev and side==1 else 'standard'):continue
                if rev:
                    count,approach,_=preceding_decline_and_pause(self.five,self.mean,self.std,i,i+1,side,s.atr,observed_prices=[])
                    if not approach:continue
                a=int(self.off[s.start]);b=int(self.off[min(s.end,(i+31)*5 if rev else s.end,len(self.one))])
                if a>=b:continue
                # Lossless bounds: skip spans whose price range never touches the eligible zone.
                view=self.one[s.start:min(s.end,(i+31)*5 if rev else s.end),:]
                low,high=(view[:,2],view[:,1]) if side==1 else (-view[:,1],-view[:,2])
                if not np.any((low<=s.upper+self.tick*1e-5)&(high>=s.lower-self.tick*1e-5)):continue
                ext=D()
                ix=native().reaction(ptr(self.p),a,b,ptr(self.opening),BASE,side,int(not rev),int(s.armed),s.lower,s.upper,s.depart,s.step,s.atr,self.tick,C.byref(ext))
                if ix<0:continue
                t=int(self.p[ix]['ts']);j=(t-BASE)//(5*M)
                if rev:
                    seq=self.p['px'][a:ix+1] if j==i+1 else None
                    if not preceding_decline_and_pause(self.five,self.mean,self.std,i,j,side,s.atr,observed_prices=seq)[2]:continue
                typ=(0 if rev else 2)+(side<0)
                add(typ,side,t,self.at(t,True),self.p[ix]['px'],side*s.level if rev else ext.value,s.atr,s.quality,0)
        for j in np.flatnonzero(self.green):
            t=BASE+(int(j)+1)*5*M
            if not START<=t<END:continue
            n,_=exit_boundary(self.red,j)
            add(4,1,t,self.at(t),self.five[j,3],self.five[j,2],self.atr[j],self.rv[j],t+n*5*M)
        events=pd.DataFrame(found).sort_values(['signal','rule','quality'],ascending=[True,True,False]).drop_duplicates(['signal','rule'])
        events['id']=sidx*1000000+np.arange(len(events))
        return events
def run(sym):
    if (CACHE/sym/'out.npz').exists():return
    m=Market(sym);df=m.signals();n=len(df)
    df.to_pickle(CACHE/sym/'events.pkl')
    shape=(n,3,6,2)
    end=np.zeros(shape,dtype=np.int64);raw=np.zeros(shape);carry=np.zeros(shape);why=np.zeros(shape,dtype=np.int8)
    stops=np.zeros((n,3))
    for i,e in enumerate(df.to_dict('records')):
        for j,pad in enumerate((.075,.25 if e['rule'] in (2,3) else .15,.35)):
            side=e['side'];sup=side*e['anchor']-max(2*m.tick,pad*e['atr'])
            stop=side*math.floor(sup/m.tick+1e-9)*m.tick;stops[i,j]=stop
            for k in range(6):
                for z,slip in enumerate((.0005,.001)):
                    out=m.path(e,stop,k,slip)
                    trade=m.p[out.exit];t=int(trade['ts']);px=float(trade['px'])
                    end[i,j,k,z]=t;raw[i,j,k,z]=px;why[i,j,k,z]=out.why
                    carry[i,j,k,z]=m.funding(e['fill'],t,side,e['raw']*(1+side*slip))
    np.savez(CACHE/sym/'out.npz',end=end,raw=raw,carry=carry,why=why,stops=stops)
    print(sym,n,flush=True)

if __name__=='__main__':
    with ProcessPoolExecutor(5) as pool:list(pool.map(run,SYMS))

"""Explain contract limits for the selected 60-day fills; stress exactly the original contracts."""
import json
import math

import pandas as pd

from account import CACHE, selected_rows


def main():
    cfg=[r for r in json.loads((CACHE/'frozen.json').read_text()) if r['qualified'] and r['size']==1]
    rows={r['id']:r for r in selected_rows(cfg,False)}
    stressed={r['id']:r for r in selected_rows(cfg,True)}
    book=pd.read_csv(CACHE/'newest_shared_fills.csv.gz').query("period=='latest60'").sort_values('signal')
    balance=150.
    preceding_exit=0
    result=[]
    for b in book.itertuples():
        assert b.signal>preceding_exit
        e=rows[b.id]
        f=stressed[b.id]
        funds=balance-3.
        caps={'slot':funds/3/(1/b.lev+.0005),'initial_risk':.005*funds/e['distance'],
              'free_margin':funds/(1/b.lev+.0005)}
        binding=min(caps,key=caps.get)
        lot=e['lot']
        qty=math.floor(caps[binding]/(e['expected']*e['ct']*lot))*lot
        assert math.isclose(qty,b.qty,abs_tol=1e-10)
        stress_net=b.qty*e['ct']*f['entry']*f['net']
        result.append(dict(id=b.id,rule=b.rule,symbol=b.symbol,signal=b.signal,opening=balance,
                           lev=b.lev,notional_slot_limit=caps['slot'],notional_risk_limit=caps['initial_risk'],
                           notional_free_limit=caps['free_margin'],binding=binding,contract_value=e['ct'],
                           contract_lot=lot,qty=qty,margin=b.margin,gross=b.gross,fees=b.fees,slippage=b.slippage,
                           funding=b.funding,net=b.usd,stress_same_qty=stress_net))
        balance+=b.usd
        preceding_exit=b.exit
    table=pd.DataFrame(result)
    table.to_csv(CACHE/'position_constraints.csv',index=False)
    stats=dict(binding_counts={k:int(n) for k,n in table.binding.value_counts().items()},
               contracts_unchanged_stressed_pnl_usdt=float(table.stress_same_qty.sum()),
               base_realized_net_usdt=float(table.net.sum()))
    (CACHE/'sizing.json').write_text(json.dumps(stats,indent=2))
    print(stats)


if __name__=='__main__':
    main()
